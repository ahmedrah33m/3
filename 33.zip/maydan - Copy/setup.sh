#!/bin/bash
# ============================================
# ميدان - سكربت الإعداد الأولي
# يُشغّل مرة واحدة بعد فك الضغط
# ============================================

set -e

PROJECT_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
cd "$PROJECT_DIR"

echo "═══════════════════════════════════════════"
echo "  ميدان - سكربت الإعداد الأولي"
echo "  المسار: $(pwd)"
echo "═══════════════════════════════════════════"
echo ""

# 1. التحقق من Node.js
echo "【1/7】 التحقق من Node.js..."
if ! command -v node &>/dev/null; then
    echo "  ✗ Node.js غير مثبت!"
    echo "  يرجى تثبيت Node.js 18+ من: https://nodejs.org"
    exit 1
fi
echo "  ✓ Node.js: $(node -v)"

# 2. تنظيف الكاش
echo ""
echo "【2/7】 تنظيف الكاش..."
rm -rf .next node_modules/.cache
echo "  ✓ تم التنظيف"

# 3. تنظيف الملفات المتعارضة
echo ""
echo "【3/7】 تنظيف تعارضات المجلدات الأبوية..."
PARENT_DIR="$(dirname "$PROJECT_DIR")"
for DIR in "$PARENT_DIR" "$(dirname "$PARENT_DIR")" "$HOME"; do
    [ "$DIR" = "$PROJECT_DIR" ] && continue
    rm -f "$DIR/package-lock.json" 2>/dev/null
    rm -rf "$DIR/node_modules/next" "$DIR/node_modules/react" "$DIR/node_modules/react-dom" 2>/dev/null
done
echo "  ✓ اكتمل"

# 4. تثبيت الاعتماديات
echo ""
echo "【4/7】 تثبيت الاعتماديات..."
npm install --legacy-peer-deps 2>&1 | tail -3
echo "  ✓ تم التثبيت"

# 5. تشغيل PostgreSQL عبر Docker
echo ""
echo "【5/7】 تشغيل قاعدة البيانات..."
if command -v docker &>/dev/null; then
    # التأكد أن Docker يعمل
    if docker info &>/dev/null; then
        echo "  تشغيل PostgreSQL عبر Docker..."
        docker compose -f docker-compose.dev.yml up -d db 2>&1
        echo "  انتظار تشغيل PostgreSQL..."
        for i in $(seq 1 30); do
            if docker compose -f docker-compose.dev.yml exec -T db pg_isready -U maydan &>/dev/null; then
                echo "  ✓ PostgreSQL جاهز"
                break
            fi
            sleep 1
        done
    else
        echo "  ⚠️ Docker لا يعمل. تأكد من تثبيت وتشغيل Docker."
        echo "  إذا كان PostgreSQL مثبتاً محلياً، تأكد أنه يعمل على المنفذ 5432."
        echo "  إذا لم يكن مثبتاً، ثبّت Docker ثم أعد تشغيل هذا السكربت."
    fi
else
    # التحقق من PostgreSQL محلي
    if command -v pg_isready &>/dev/null && pg_isready -h localhost -p 5432 &>/dev/null; then
        echo "  ✓ PostgreSQL محلي يعمل"
    else
        echo "  ⚠️ لم يتم العثور على Docker أو PostgreSQL."
        echo "  يرجى تثبيت Docker من: https://docs.docker.com/get-docker/"
        echo "  ثم أعد تشغيل: bash setup.sh"
        exit 1
    fi
fi

# 6. توليد Prisma Client + إنشاء الجداول
echo ""
echo "【6/7】 إعداد قاعدة البيانات..."
npx prisma generate 2>&1 | tail -2
npx prisma db push --force-reset 2>&1 | tail -3
echo "  ✓ تم إنشاء الجداول"

# 7. تعبئة البيانات التجريبية
echo ""
echo "【7/7】 تعبئة البيانات التجريبية..."
npx tsx prisma/seed.ts 2>&1 | tail -5
echo "  ✓ تم التعبئة"

echo ""
echo "═══════════════════════════════════════════"
echo "  ✓ الإعداد اكتمل بنجاح!"
echo ""
echo "  لتشغيل المشروع:"
echo "    npm run dev"
echo ""
echo "  حسابات تجريبية:"
echo "    owner@midaniq.com  /  SeedPass1!"
echo "    admin@midaniq.com  /  SeedPass1!"
echo "═══════════════════════════════════════════"