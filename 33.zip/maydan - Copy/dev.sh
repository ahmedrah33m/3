#!/bin/bash
# ============================================
# ميدان - سكربت التشغيل الآمن
# يستخدم webpack (ليس Turbopack) لتجنب خطأ HMR
# ============================================

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
PARENT_DIR="$(dirname "$PROJECT_DIR")"

echo "═══════════════════════════════════════════"
echo "  ميدان - تشغيل آمن (webpack + PostgreSQL)"
echo "═══════════════════════════════════════════"

# 0. التحقق من ملف .env
echo ""
echo "【0/9】 التحقق من ملف .env..."
if [ ! -f "$PROJECT_DIR/.env" ]; then
  echo "  ⚠️  ملف .env غير موجود"
  if [ -f "$PROJECT_DIR/.env.dev-template" ]; then
    echo "  → إنشاء .env من .env.dev-template (قيم تطوير آمنة)..."
    cp "$PROJECT_DIR/.env.dev-template" "$PROJECT_DIR/.env"
    echo "  ✓ تم إنشاء .env بقيم افتراضية للتطوير المحلي"
  elif [ -f "$PROJECT_DIR/.env.example" ]; then
    echo "  → إنشاء .env من .env.example..."
    cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env"
    echo "  ⚠️  يجب تعديل .env بقيم حقيقية (خاصة DATABASE_URL و JWT_SECRET)"
  fi
else
  # Check if .env has placeholder values
  if grep -q "CHANGE_ME" "$PROJECT_DIR/.env" 2>/dev/null; then
    echo "  ⚠️  ملف .env يحتوي على قيم CHANGE_ME — قد لا يعمل التطبيق"
    echo "  → يمكنك استخدام .env.dev-template: cp .env.dev-template .env"
  elif grep -qE "^DATABASE_URL=.*maydan_secure_password" "$PROJECT_DIR/.env" 2>/dev/null; then
    echo "  ✓ ملف .env موجود ويستخدم القيم الافتراضية للتطوير"
  else
    echo "  ✓ ملف .env موجود"
  fi
fi

# 1. التحقق من PostgreSQL
echo ""
echo "【1/9】 التحقق من PostgreSQL..."

PG_READY=false

if command -v pg_isready &>/dev/null; then
    if pg_isready -h localhost -p 5432 &>/dev/null; then
        echo "  ✓ PostgreSQL يعمل على localhost:5432"
        PG_READY=true
    fi
fi

if [ "$PG_READY" = false ] && command -v docker &>/dev/null; then
    if docker ps --format '{{.Names}}' | grep -q postgres 2>/dev/null; then
        echo "  ✓ PostgreSQL يعمل عبر Docker"
        PG_READY=true
    elif [ -f "$PROJECT_DIR/docker-compose.yml" ]; then
        echo "  تشغيل PostgreSQL عبر Docker Compose..."
        docker compose -f "$PROJECT_DIR/docker-compose.yml" up -d db 2>/dev/null || true
        sleep 3
        if docker ps --format '{{.Names}}' | grep -q postgres 2>/dev/null; then
            echo "  ✓ PostgreSQL يعمل عبر Docker"
            PG_READY=true
        fi
    fi
fi

if [ "$PG_READY" = false ]; then
    echo "  ⚠️  PostgreSQL غير متاح - تأكد من تشغيله"
fi

# 2. إيقاف أي عملية قديمة على المنفذ 3300
echo ""
echo "【2/9】 إيقاف العمليات القديمة..."
fuser -k 3300/tcp 2>/dev/null && echo "  ✓ تم إيقاف المنفذ 3300" || echo "  - المنفذ 3300 حر"

# 3. حذف كاش .next
echo ""
echo "【3/9】 حذف كاش .next..."
if [ -d "$PROJECT_DIR/.next" ]; then
  rm -rf "$PROJECT_DIR/.next"
  echo "  ✓ تم حذف .next"
else
  echo "  - لا يوجد كاش"
fi

# 4. التحقق من ملف next واعادته اذا كان تالف
echo ""
echo "【4/9】 التحقق من ملف next..."
NEXT_BIN="$PROJECT_DIR/node_modules/next/dist/bin/next"
if [ -f "$NEXT_BIN" ]; then
  # التحقق: هل الملف يحتوي على JavaScript ام bash？
  FIRST_LINE=$(head -1 "$NEXT_BIN" 2>/dev/null)
  SECOND_LINE=$(sed -n '2p' "$NEXT_BIN" 2>/dev/null)

  if echo "$SECOND_LINE" | grep -q 'basedir=' 2>/dev/null; then
    echo "  ⚠️  ملف next تالف (يحتوي على bash بدل JavaScript)"
    echo "  → إعادة تثبيت next..."
    cd "$PROJECT_DIR"
    rm -rf "$PROJECT_DIR/node_modules/next"
    npm install --save-exact next@16.2.9 2>&1 | tail -3 || npm install 2>&1 | tail -3
    echo "  ✓ تم إعادة تثبيت next"
  elif echo "$FIRST_LINE" | grep -q '\r' 2>/dev/null; then
    echo "  ⚠️  ملف next يحتوي على CRLF line endings"
    sed -i 's/\r$//' "$NEXT_BIN"
    echo "  ✓ تم إصلاح line endings"
  else
    echo "  ✓ ملف next سليم"
  fi
else
  echo "  ⚠️  ملف next غير موجود - تثبيت الحزم..."
  cd "$PROJECT_DIR"
  npm install 2>&1 | tail -3
fi

# 5. تنظيف تعارضات node_modules الأب
echo ""
echo "【5/9】 تنظيف تعارضات node_modules الأب..."
CLEANED=0
if [ -d "$PARENT_DIR/node_modules/next" ] && [ "$PARENT_DIR" != "$PROJECT_DIR" ]; then
  rm -rf "$PARENT_DIR/node_modules/next"
  echo "  ✓ حذف next من المجلد الأب"
  CLEANED=1
fi
if [ -d "$PARENT_DIR/node_modules/react" ] && [ "$PARENT_DIR" != "$PROJECT_DIR" ]; then
  rm -rf "$PARENT_DIR/node_modules/react"
  echo "  ✓ حذف react من المجلد الأب"
  CLEANED=1
fi
if [ -d "$PARENT_DIR/node_modules/react-dom" ] && [ "$PARENT_DIR" != "$PROJECT_DIR" ]; then
  rm -rf "$PARENT_DIR/node_modules/react-dom"
  echo "  ✓ حذف react-dom من المجلد الأب"
  CLEANED=1
fi
if [ $CLEANED -eq 0 ]; then
  echo "  - لا توجد تعارضات"
fi

# 6. تنظيف بيانات Ad المؤدية
echo ""
echo "【6/9】 تنظيف بيانات Ad المؤدية..."
cd "$PROJECT_DIR"
source .env 2>/dev/null || true
PG_USER=$(echo "$DATABASE_URL" | sed -n 's|.*://\([^:]*\):.*|\1|p')
PG_PASS=$(echo "$DATABASE_URL" | sed -n 's|.*://[^:]*:\([^@]*\)@.*|\1|p')
PG_HOST=$(echo "$DATABASE_URL" | sed -n 's|.*@\([^:]*\):.*|\1|p')
PG_PORT=$(echo "$DATABASE_URL" | sed -n 's|.*:\([0-9]*\)/.*|\1|p')
PG_DB=$(echo "$DATABASE_URL" | sed -n 's|.*/\([^?]*\).*|\1|p')

export PGPASSWORD="$PG_PASS"

if command -v psql &>/dev/null; then
  psql -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d "$PG_DB" -c "UPDATE \"Ad\" SET \"advertiserId\" = NULL WHERE \"advertiserId\" IS NOT NULL AND \"advertiserId\" NOT IN (SELECT id FROM \"AdvertiserAccount\");" 2>/dev/null && echo "  ✓ تم تنظيف بيانات Ad المؤدية" || echo "  - لم يتم تنظيف (قد لا توجد بيانات مؤدية)"
else
  echo "  - psql غير متوفر (تخطي التنظيف)"
fi

# 7. توليد Prisma + دفع Schema
echo ""
echo "【7/9】 توليد Prisma + دفع Schema..."
cd "$PROJECT_DIR"
npx prisma@6.19.2 generate 2>&1 | tail -1 || echo "  - تم التوليد مسبقاً"
npx prisma@6.19.2 db push --accept-data-loss 2>&1 | tail -20 || echo "  ⚠️  فشل دفع Schema — جرّب: npx prisma db push --accept-data-loss"

# 8. تشغيل الخادم
echo ""
echo "═══════════════════════════════════════════"
echo "【8/9】 تشغيل الخادم..."
echo "═══════════════════════════════════════════"

exec npx next dev -p 3300
