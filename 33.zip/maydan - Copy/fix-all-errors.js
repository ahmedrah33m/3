const fs = require('fs');
const path = require('path');

// Find all files with employee include user
const files = [];
function walkDir(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walkDir(full);
    else if (entry.name.endsWith('.ts') || entry.name.endsWith('.tsx')) files.push(full);
  }
}
walkDir('src');

let fixed = 0;
for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  let newContent = content;
  
  // Fix 1: Remove user include from Employee queries
  newContent = newContent.replace(
    /employee:\s*\{\s*include:\s*\{\s*user:\s*\{[^}]*\}\s*\}\s*\}/g,
    "employee: { select: { id: true, userId: true, jobTitle: true, employeeNumber: true } }"
  );
  newContent = newContent.replace(
    /include:\s*\{\s*user:\s*\{[^}]*\}\s*\}/g,
    "select: { id: true, userId: true, jobTitle: true, employeeNumber: true }"
  );
  
  // Fix 2: Remove user from where clauses (Employee has userId, not user)
  newContent = newContent.replace(
    /where:\s*\{[^}]*user:\s*\{[^}]*\}[^}]*\}/g,
    (match) => match.replace(/user:\s*\{[^}]*\}/g, 'userId: search')
  );
  
  // Fix 3: Remove department/branch include (not in schema)
  newContent = newContent.replace(/department:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/branch:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/contracts:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix 4: Remove payrollRun include (Payment doesn't have it)
  newContent = newContent.replace(/payrollRun:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/paymentDate:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix 5: Remove components from SalaryStructure
  newContent = newContent.replace(/components:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/components\?:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix 6: Remove payrollRunId/processedById from Payment
  newContent = newContent.replace(/payrollRunId:\s*[^,}]*\s*,?\s*/g, '');
  newContent = newContent.replace(/processedById:\s*[^,}]*\s*,?\s*/g, '');
  
  // Fix 7: Remove department from reports
  newContent = newContent.replace(/department:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  if (newContent !== content) {
    fs.writeFileSync(file, newContent);
    fixed++;
  }
}

console.log(`Fixed ${fixed} files`);
