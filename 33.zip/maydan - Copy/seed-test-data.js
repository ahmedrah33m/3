const { PrismaClient } = require('@prisma/client');
const { scryptSync, randomBytes } = require('crypto');

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const hash = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

async function main() {
  const prisma = new PrismaClient();
  
  console.log('=== Creating test data ===\n');
  
  // Check if user exists
  const existing = await prisma.user.findFirst();
  if (existing) {
    console.log('Test data already exists!');
    console.log('User:', existing.email);
    await prisma.$disconnect();
    return;
  }
  
  // Create test company
  const company = await prisma.company.create({
    data: {
      name: 'شركة ميدان التجريبية',
      ownerId: 'temp'
    }
  });
  console.log('✅ Company created:', company.id);
  
  // Create test user
  const user = await prisma.user.create({
    data: {
      email: 'admin@maydan.iq',
      name: 'Admin User',
      password: hashPassword('password123'),
      role: 'OWNER',
      emailVerified: true,
      companyId: company.id
    }
  });
  console.log('✅ User created:', user.id, user.email);
  
  // Update company with correct owner
  await prisma.company.update({
    where: { id: company.id },
    data: { ownerId: user.id }
  });
  console.log('✅ Company owner updated');
  
  // Create test employee
  const employee = await prisma.employee.create({
    data: {
      userId: user.id,
      companyId: company.id,
      jobTitle: 'مدير النظام',
      employmentType: 'FULL_TIME',
      status: 'ACTIVE',
      startDate: new Date(),
      salary: 2000000
    }
  });
  console.log('✅ Employee created:', employee.id);
  
  await prisma.$disconnect();
  console.log('\n=== Test data created successfully ===');
  console.log('Login: admin@maydan.iq');
  console.log('Password: password123');
}

main().catch(console.error);
