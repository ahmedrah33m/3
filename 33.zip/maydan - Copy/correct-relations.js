const fs = require('fs');

const baseContent = fs.readFileSync('prisma/schema.base.prisma', 'utf8');

const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

const baseModels = parseModels(baseContent);
console.log('Base models:', baseModels.size);

const baseNames = new Set([...baseModels.keys()]);

const allNewModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [name, lines] of parseModels(content)) {
    if (!baseNames.has(name) && name !== 'Payment') {
      allNewModels.set(name, lines);
    }
  }
}
console.log('New models:', allNewModels.size);

// Build reverse relations with proper @relation("Name") on both sides
const reverseSpecs = new Map(); // targetModel -> [{ field, sourceModel, relationName }]

for (const [modelName, modelLines] of allNewModels) {
  for (const line of modelLines) {
    const match = line.match(/^\s+(\w+)\s+(\w+)(\??)\s*@relation/);
    if (match && baseNames.has(match[2])) {
      const fieldName = match[1];
      const targetModel = match[2];
      const isOptional = match[3] === '?';
      const isList = line.includes(`${match[2]}[]`);
      
      if (!reverseSpecs.has(targetModel)) reverseSpecs.set(targetModel, []);
      
      // Generate unique relation name
      const relationName = `${modelName}_${fieldName}`;
      
      // Determine reverse field name (plural of source model)
      const reverseField = modelName.charAt(0).toLowerCase() + modelName.slice(1) + 's';
      
      reverseSpecs.get(targetModel).push({
        field: reverseField,
        sourceModel: modelName,
        relationName: relationName,
        isList: !isList, // If original is single, reverse is list
        isOptional: isOptional
      });
    }
  }
}

console.log('Models needing reverse relations:', reverseSpecs.size);

// Add reverse relations to existing models
let totalAdded = 0;
for (const [modelName, specs] of reverseSpecs) {
  const modelLines = baseModels.get(modelName);
  if (!modelLines) continue;
  
  // Get existing field names
  const existingFields = new Set();
  for (const line of modelLines) {
    const fieldMatch = line.trim().match(/^(\w+)\s+/);
    if (fieldMatch && !line.trim().startsWith('model ') && !line.trim().startsWith('@@')) {
      existingFields.add(fieldMatch[1]);
    }
  }
  
  // Filter out specs that already exist
  const missingSpecs = specs.filter(s => !existingFields.has(s.field));
  
  if (missingSpecs.length > 0) {
    const closingIdx = modelLines.length - 1;
    const newRels = missingSpecs.map(s => {
      const listStr = s.isList ? '[]' : (s.isOptional ? '?' : '');
      return `  ${s.field} ${s.sourceModel}${listStr} @relation("${s.relationName}")`;
    });
    modelLines.splice(closingIdx, 0, '', '  // Back-relations (new systems)', ...newRels);
    totalAdded += missingSpecs.length;
  }
}

console.log('Reverse relations added:', totalAdded);

// Rebuild schema
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

for (const [name, lines] of baseModels) {
  output.push(...lines);
  output.push('');
}

output.push('// ============================================');
output.push('// New Models');
output.push('// ============================================');
output.push('');

for (const [name, lines] of allNewModels) {
  output.push(...lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
