#!/bin/bash
# ============================================
# Maydan Al-Iqtisad - Production Setup Script
# ميدان الاقتصاد - سكريبت إعداد الإنتاج
# ============================================
set -e

echo "🚀 Maydan Al-Iqtisad - Production Setup"
echo "========================================"

PROJECT_DIR="$HOME/maydan"

# Step 1: Environment
echo ""
echo "📋 Step 1: Setting up environment..."
cd "$PROJECT_DIR"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "✅ Created .env from .env.example"
  echo "⚠️  Please edit .env with your production values"
else
  echo "✅ .env already exists"
fi

# Generate JWT secret
JWT_SECRET=$(openssl rand -hex 32)
if grep -q "JWT_SECRET=change" .env 2>/dev/null || ! grep -q "JWT_SECRET" .env 2>/dev/null; then
  sed -i "s/JWT_SECRET=.*/JWT_SECRET=$JWT_SECRET/" .env 2>/dev/null || echo "JWT_SECRET=$JWT_SECRET" >> .env
  echo "✅ Generated JWT_SECRET"
fi

# Step 2: Docker Compose
echo ""
echo "📋 Step 2: Starting database..."
docker compose up -d postgres pgbouncer
echo "⏳ Waiting for database..."
sleep 15

# Step 3: Prisma Migrations
echo ""
echo "📋 Step 3: Running database migrations..."
npx prisma migrate deploy
echo "✅ Migrations complete"

# Step 4: Build
echo ""
echo "📋 Step 4: Building Next.js application..."
npm install
JWT_SECRET=$(grep JWT_SECRET .env | cut -d= -f2) npx next build
echo "✅ Build complete"

# Step 5: Seed Dictionary
echo ""
echo "📋 Step 5: Seeding dictionary terms..."
npx tsx prisma/seed-dictionary.ts
echo "✅ Dictionary seeded"

# Step 6: Start application
echo ""
echo "📋 Step 6: Starting services..."
docker compose up -d app cloudflared
echo "✅ All services started"

# Step 7: Install cloudflared as system service (alternative)
echo ""
echo "📋 Step 7: Cloudflare Tunnel..."
if command -v cloudflared &> /dev/null; then
  echo "✅ cloudflared already installed"
else
  echo "Installing cloudflared..."
  sudo curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared
  sudo chmod +x /usr/local/bin/cloudflared
  echo "✅ cloudflared installed"
fi

# Step 8: Verify
echo ""
echo "📋 Step 8: Verification..."
sleep 5
if curl -s -o /dev/null http://localhost:3300 2>/dev/null; then
  echo "✅ Server is running on port 3300"
else
  echo "⚠️  Server not responding on port 3300"
fi

echo ""
echo "🎉 Setup Complete!"
echo ""
echo "📊 Service Commands:"
echo "  docker compose ps          - Check service status"
echo "  docker compose logs app     - View app logs"
echo "  docker compose logs cloudflared - View tunnel logs"
echo "  docker compose restart app  - Restart the app"
echo ""
echo "🌐 Your site: https://midaniq.com"
