# 🚀 نشر ميدان الاقتصاد - دليل التشغيل الدائم
# Maydan Al-Iqtisad - Permanent Deployment Guide

## المتطلبات
- خادم Linux مع Docker و Docker Compose
- اسم نطاق مربوط بـ Cloudflare
- Cloudflare Tunnel Token (من Cloudflare Zero Trust dashboard)

## ⚠️ تنبيه أمني
**لا تُصلّب أبداً أسراراً (كلمات مرور، tokens، API keys) في الكود أو الـ scripts أو الـ docs.**
استخدم دائماً متغيرات البيئة (`.env`).

---

## الخطوة 1: نسخ الملفات
```bash
# انسخ ملفات المشروع إلى الخادم
scp maydan-v9.zip user@YOUR_SERVER_IP:~/
ssh user@YOUR_SERVER_IP
cd ~
unzip maydan-v9.zip -d maydan
cd maydan
```

## الخطوة 2: إعداد متغيرات البيئة
```bash
cp .env.example .env
# عدّل .env واملأ كل القيم المطلوبة:
# - JWT_SECRET (openssl rand -base64 48)
# - POSTGRES_PASSWORD
# - S3_ACCESS_KEY / S3_SECRET_KEY
# - CLOUDFLARE_TUNNEL_TOKEN
# - GOOGLE_CLIENT_ID / SECRET
# - SMTP credentials
# - Payment gateway credentials
nano .env
```

## الخطوة 3: تشغيل قاعدة البيانات
```bash
# تشغيل PostgreSQL و PgBouncer عبر Docker
docker compose up -d postgres pgbouncer
# انتظر حتى تبدأ قاعدة البيانات
sleep 10
# تشغيل migrations
npx prisma migrate deploy
# (أو npx prisma db push إذا لا توجد migrations كاملة)
```

## الخطوة 4: بناء المشروع
```bash
npm install
npx next build
```

## الخطوة 5: إدراج مصطلحات القاموس
```bash
npx tsx prisma/seed-dictionary.ts
```

## الخطوة 6: تشغيل المشروع بشكل دائم
```bash
# الخيار أ: عبر Docker Compose (موصى به)
docker compose up -d app

# الخيار ب: عبر Systemd
sudo cp scripts/maydan.service /etc/systemd/system/
sudo systemctl enable maydan
sudo systemctl start maydan
```

## الخطوة 7: تشغيل Cloudflare Tunnel

### تثبيت cloudflared
```bash
curl -fsSL https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared
chmod +x /usr/local/bin/cloudflared
```

### الحصول على Tunnel Token
1. اذهب إلى [Cloudflare Zero Trust Dashboard](https://one.dash.cloudflare.com/)
2. Networks → Tunnels → Create a tunnel
3. اختر Cloudflared كنوع النفق
4. أعطِ اسماً للنفق (مثلاً `midan9`)
5. انسخ الـ token المعروض (يبدأ بـ `eyJ...`)

### تشغيل كخدمة دائمة
```bash
# ضع الـ token في متغير بيئة (لا تُصلّبه في الكوماند!)
export CLOUDFLARE_TUNNEL_TOKEN="your_token_here"

# تثبيت كخدمة systemd
sudo cloudflared service install "$CLOUDFLARE_TUNNEL_TOKEN"

# أو تشغيل يدوي عبر maydan.sh (يقرأ من .env)
bash ~/maydan/maydan.sh start
```

### إعداد Public Hostname
في لوحة تحكم Cloudflare:
1. اذهب إلى Zero Trust > Networks > Tunnels
2. اختر النفق الخاص بك
3. أضف Public Hostname:
   - Subdomain: `midan9` (أو ما تفضله)
   - Domain: نطاقك في Cloudflare
   - Service: `http://localhost:3300`

## إدارة الخدمات
```bash
# تشغيل/إيقاف
bash ~/maydan/maydan.sh start
bash ~/maydan/maydan.sh stop
bash ~/maydan/maydan.sh status

# عرض السجلات
bash ~/maydan/maydan.sh logs server
bash ~/maydan/maydan.sh logs tunnel

# إدراج مصطلحات القاموس
bash ~/maydan/maydan.sh seed-dictionary
```

---

## 🔐 إدارة الأسرار

### تدوير الأسرار (عند الاشتباه بتسريب)
```bash
# شغّل سكريبت التدوير (يولّد أسراراً جديدة)
bash scripts/rotate-secrets.sh

# اتبع التعليمات لتحديث كل الخدمات الخارجية
```

### تنظيف git history (إذا سُرّب .env سابقاً)
```bash
# استخدم BFG Repo-Cleaner (انظر scripts/rotate-secrets.sh للتفاصيل)
java -jar bfg.jar --delete-files .env midan9.git
git reflog expire --expire=now --all
git gc --prune=now --aggressive
git push --force
```

---

## 📋 Checklist قبل الإطلاق

- [ ] `.env` يحتوي كل القيم المطلوبة (راجع `.env.example`)
- [ ] `JWT_SECRET` جديد (min 32 char) ولم يُستخدم من قبل
- [ ] `POSTGRES_PASSWORD` قوي ومختلف عن الافتراضي
- [ ] `CLOUDFLARE_TUNNEL_TOKEN` من tunnel جديد (ليس المسروق)
- [ ] Google OAuth credentials جديدة من Google Cloud Console
- [ ] SMTP credentials صحيحة
- [ ] Payment gateway credentials (ZainCash, QiCard, Mastercard) صحيحة
- [ ] `npx prisma migrate deploy` يعمل بدون أخطاء
- [ ] `npm run build` يعمل بدون أخطاء
- [ ] Health check يرجع 200: `curl http://localhost:3300/api/health`
- [ ] HTTPS يعمل عبر Cloudflare Tunnel
- [ ] Backups مجدولة (scripts/setup-backup-cron.sh)
