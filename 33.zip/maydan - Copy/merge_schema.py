#!/usr/bin/env python3
"""Merge missing models from source into checkpoint 005."""

import re

def extract_models(content):
    models = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^model\s+(\w+)\s*\{', line)
        if m:
            if current:
                models[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        models[current] = '\n'.join(lines)
    return models

def extract_enums(content):
    enums = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^enum\s+(\w+)\s*\{', line)
        if m:
            if current:
                enums[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        enums[current] = '\n'.join(lines)
    return enums

def get_relations(model_text):
    relations = []
    for line in model_text.split('\n'):
        m = re.match(r'\s+(\w+)\s+(\w+)\??\s+@relation\("([^"]+)"', line)
        if m:
            relations.append({'field': m.group(1), 'target': m.group(2), 'name': m.group(3)})
    return relations

# Read schemas
with open('../maydan/prisma/schema.prisma', 'r') as f:
    source = f.read()

with open('prisma/checkpoints/005-all-systems-merged.prisma', 'r') as f:
    checkpoint = f.read()

source_models = extract_models(source)
checkpoint_models = extract_models(checkpoint)

# Find models in source NOT in checkpoint
missing = {name: text for name, text in source_models.items() if name not in checkpoint_models}

print(f"Checkpoint: {len(checkpoint_models)} models")
print(f"Source: {len(source_models)} models")
print(f"Missing from checkpoint: {len(missing)}")

# Add missing models to checkpoint
for name, text in missing.items():
    checkpoint_models[name] = text

# Add reverse relations for missing models
for model_name, model_text in missing.items():
    relations = get_relations(model_text)
    for rel in relations:
        target = rel['target']
        relation_name = rel['name']
        if target in checkpoint_models:
            target_text = checkpoint_models[target]
            if f'{model_name}[]' in target_text or f'{model_name}?' in target_text:
                continue
            lines = target_text.rstrip().split('\n')
            if lines and lines[-1].strip() == '}':
                lines = lines[:-1]
            lines.append(f'  {model_name.lower()}s {model_name}[] @relation("{relation_name}")')
            lines.append('}')
            checkpoint_models[target] = '\n'.join(lines)

# Build final schema
final = []
header_match = re.search(r'(.*?)^model\s', checkpoint, re.DOTALL | re.MULTILINE)
if header_match:
    final.append(header_match.group(1))

for name in sorted(checkpoint_models):
    final.append(checkpoint_models[name])

with open('prisma/schema.prisma', 'w') as f:
    f.write('\n\n'.join(final))

print(f"\n✅ Final: {len(checkpoint_models)} models")
