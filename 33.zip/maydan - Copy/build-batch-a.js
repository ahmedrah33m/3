/**
 * Subsystem-by-subsystem schema builder
 * Batch A: Payroll System
 * 
 * Rules:
 * - No manual reverse relations
 * - Use prisma format to auto-add reverse relations
 * - Validate after each batch
 */

const fs = require('fs');

// Read the clean original schema
const originalSchema = fs.readFileSync('prisma/schema.prisma', 'utf8');

// Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.push({ name: currentModel, lines: currentLines });
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.push({ name: currentModel, lines: currentLines });
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.push({ name: currentModel, lines: currentLines });
  return models;
}

const originalModels = parseModels(originalSchema);
console.log('Original models:', originalModels.length);

// Get existing model names
const existingNames = new Set(originalModels.map(m => m.name));

// Read payroll additions (excluding Payment)
const payrollContent = fs.readFileSync('prisma/schema-additions-payroll.prisma', 'utf8');
const payrollModels = parseModels(payrollContent);
console.log('Payroll models in file:', payrollModels.length);

// Filter out Payment (already exists) and any other existing models
const newPayrollModels = payrollModels.filter(m => !existingNames.has(m.name));
console.log('New payroll models to add:', newPayrollModels.length);

// Add new models to original
const allModels = [...originalModels, ...newPayrollModels];

// Rebuild schema
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

for (const model of allModels) {
  output.push(...model.lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Schema rebuilt with', allModels.length, 'models total');
