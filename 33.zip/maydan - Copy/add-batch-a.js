/**
 * إضافة النماذج الجديدة فقط (بدون علاقات عكسية)
 * ثم نستخدم prisma format لإضافة العلاقات تلقائياً
 */

const fs = require('fs');

// قراءة الملف الأصلي
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');
const originalLines = originalContent.split('\n');

// قراءة دفعة Payroll فقط
const payrollContent = fs.readFileSync('prisma/schema-additions-payroll.prisma', 'utf8');
const payrollLines = payrollContent.split('\n');

// استخراج نماذج Payroll
function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.push({ name: currentModel, lines: currentLines });
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.push({ name: currentModel, lines: currentLines });
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.push({ name: currentModel, lines: currentLines });
  return models;
}

const payrollModels = parseModels(payrollContent);
console.log('نماذج Payroll:', payrollModels.length);

// التحقق من النماذج الموجودة
const existingModels = new Set();
for (const line of originalLines) {
  const match = line.trim().match(/^model (\w+) \{/);
  if (match) existingModels.add(match[1]);
}

// تصفية النماذج الجديدة فقط (غير موجودة أصلاً)
// و تجاهل Payment لأنه موجود
const newModels = payrollModels.filter(m => !existingModels.has(m.name) && m.name !== 'Payment');
console.log('نماذج Payroll الجديدة:', newModels.length);

// إضافة النماذج الجديدة في نهاية الملف
let output = originalContent.trimEnd() + '\n\n';
output += '// ============================================\n';
output += '// Batch A: Payroll System\n';
output += '// ============================================\n\n';

for (const model of newModels) {
  output += model.lines.join('\n') + '\n\n';
}

fs.writeFileSync('prisma/schema.prisma', output);
console.log('تم إضافة نماذج Payroll');
