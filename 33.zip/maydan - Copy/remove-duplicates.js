const fs = require('fs');

let content = fs.readFileSync('prisma/schema.prisma', 'utf8');
const lines = content.split('\n');

// إيجاد النماذج المكررة وحذفها
const models = new Map();
let currentModel = null;
let currentLines = [];
let braceCount = 0;

for (const line of lines) {
  const match = line.match(/^model (\w+) \{/);
  if (match) {
    if (currentModel) {
      models.set(currentModel, currentLines);
    }
    currentModel = match[1];
    currentLines = [line];
    braceCount = 1;
  } else if (currentModel) {
    currentLines.push(line);
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    if (braceCount === 0) {
      models.set(currentModel, currentLines);
      currentModel = null;
      currentLines = [];
    }
  }
}
if (currentModel) models.set(currentModel, currentLines);

console.log('Total models (including duplicates):', models.size);

// إعادة بناء الملف بدون تكرار
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

for (const [name, lines] of models) {
  output.push(...lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
