const fs = require('fs');

// Read original
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');

// Read all addition files
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

// Parse models from content (handles nested braces properly)
function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    
    // Skip comments and empty lines outside models
    if (!currentModel && (trimmed.startsWith('//') || trimmed === '')) {
      continue;
    }
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) {
        models.push({ name: currentModel, lines: currentLines });
      }
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.push({ name: currentModel, lines: currentLines });
        currentModel = null;
        currentLines = [];
      }
    }
  }
  
  if (currentModel) {
    models.push({ name: currentModel, lines: currentLines });
  }
  
  return models;
}

// Parse original
const originalModels = parseModels(originalContent);
console.log('Original models:', originalModels.length);

// Parse additions
let additionModels = [];
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  additionModels = additionModels.concat(parseModels(content));
}
console.log('Addition models:', additionModels.length);

// Find model names in original
const originalNames = new Set(originalModels.map(m => m.name));

// Filter out models that already exist in original
const newModels = additionModels.filter(m => !originalNames.has(m.name));
console.log('New models to add:', newModels.length);

// Find models in original that need back-relations
// (models that are referenced by new models)
const modelsNeedingBackRelations = new Set();
for (const model of newModels) {
  for (const line of model.lines) {
    // Check for relation fields that reference existing models
    const relationMatch = line.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
    if (relationMatch) {
      const referencedModel = relationMatch[2];
      if (originalNames.has(referencedModel)) {
        modelsNeedingBackRelations.add(referencedModel);
      }
    }
  }
}
console.log('Models needing back-relations:', modelsNeedingBackRelations.size);

// Add back-relations to original models
const backRelationMap = {};
for (const model of newModels) {
  for (const line of model.lines) {
    const relationMatch = line.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
    if (relationMatch) {
      const fieldName = relationMatch[1];
      const referencedModel = relationMatch[2];
      if (originalNames.has(referencedModel)) {
        if (!backRelationMap[referencedModel]) {
          backRelationMap[referencedModel] = [];
        }
        backRelationMap[referencedModel].push(line.trim());
      }
    }
  }
}

// Rebuild schema with back-relations added to original models
const lines = originalContent.split('\n');
const output = [];
let currentModel = null;
let braceCount = 0;
let inModel = false;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const trimmed = line.trim();
  
  const match = trimmed.match(/^model (\w+) \{/);
  if (match) {
    currentModel = match[1];
    inModel = true;
    braceCount = 1;
    output.push(line);
    continue;
  }
  
  if (inModel) {
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    
    if (braceCount === 0 && line.includes('}')) {
      // Model is closing - add back-relations if needed
      const backRels = backRelationMap[currentModel];
      if (backRels && backRels.length > 0) {
        // Check if back-relations already exist
        const modelStart = output.findIndex(l => l.includes(`model ${currentModel} {`));
        const modelContent = output.slice(modelStart).join('\n');
        
        for (const rel of backRels) {
          const fieldName = rel.split(' ')[0];
          if (!modelContent.includes(fieldName)) {
            output.push('  ' + rel);
          }
        }
      }
      
      output.push(line);
      inModel = false;
      currentModel = null;
      continue;
    }
    
    output.push(line);
    continue;
  }
  
  output.push(line);
}

// Add new models at the end
output.push('');
output.push('// ============================================');
output.push('// New Models from Additions');
output.push('// ============================================');
output.push('');

for (const model of newModels) {
  output.push(...model.lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
