const fs = require('fs');

const base = fs.readFileSync('prisma/schema.base.prisma', 'utf8');
const baseLines = base.split('\n');

// Get existing model names
const existing = new Set();
for (const line of baseLines) {
  const m = line.trim().match(/^model (\w+) \{/);
  if (m) existing.add(m[1]);
}
console.log('Existing models:', existing.size);

// Parse new models from additions
function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let cur = null, brace = 0;
  for (const line of lines) {
    const t = line.trim();
    if (t.startsWith('//') || t === '') continue;
    const m = t.match(/^model (\w+) \{/);
    if (m) {
      if (cur) models.push(cur);
      cur = { name: m[1], lines: [line], rels: [] };
      brace = 1;
    } else if (cur) {
      cur.lines.push(line);
      brace += (line.match(/\{/g)||[]).length - (line.match(/\}/g)||[]).length;
      // Fixed regex: match @relation with optional spaces
      const rm = t.match(/^\s+(\w+)\s+(\w+)(\??)\s+@relation/);
      if (rm) {
        cur.rels.push({ field: rm[1], target: rm[2], opt: rm[3]==='?', list: t.includes(rm[2]+'[]') });
      }
      if (brace === 0) { models.push(cur); cur = null; }
    }
  }
  if (cur) models.push(cur);
  return models;
}

const newModels = parseModels(fs.readFileSync('prisma/schema-additions-payroll.prisma', 'utf8'))
  .concat(parseModels(fs.readFileSync('prisma/schema-additions-employment-verification.prisma', 'utf8')))
  .concat(parseModels(fs.readFileSync('prisma/schema-additions-onboarding.prisma', 'utf8')))
  .concat(parseModels(fs.readFileSync('prisma/schema-additions-live-rooms.prisma', 'utf8')))
  .filter(m => !existing.has(m.name) && m.name !== 'Payment');

console.log('New models:', newModels.length);

// Build reverse relations map
const reverseMap = {};
for (const m of newModels) {
  for (const r of m.rels) {
    if (existing.has(r.target)) {
      if (!reverseMap[r.target]) reverseMap[r.target] = [];
      const relName = m.name + '_' + r.field;
      const revField = m.name.charAt(0).toLowerCase() + m.name.slice(1) + 's';
      reverseMap[r.target].push({ field: revField, source: m.name, relName, isList: !r.list });
    }
  }
}
console.log('Models needing reverse relations:', Object.keys(reverseMap).length);

// Build output
const output = [];
let curModel = null, brace = 0;

for (let i = 0; i < baseLines.length; i++) {
  const line = baseLines[i];
  const t = line.trim();
  
  const m = t.match(/^model (\w+) \{/);
  if (m) {
    curModel = m[1];
    brace = 1;
    output.push(line);
    continue;
  }
  
  if (curModel) {
    brace += (line.match(/\{/g)||[]).length - (line.match(/\}/g)||[]).length;
    output.push(line);
    
    if (brace === 0 && line.includes('}')) {
      // Add reverse relations before closing brace
      const revs = reverseMap[curModel];
      if (revs) {
        output.push('  // Reverse relations (new systems)');
        for (const r of revs) {
          output.push(`  ${r.field} ${r.source}${r.isList?'[]':'?'} @relation("${r.relName}")`);
        }
      }
      curModel = null;
    }
    continue;
  }
  
  output.push(line);
}

// Add new models at end
output.push('');
output.push('// ============================================');
output.push('// New Models');
output.push('// ============================================');
output.push('');

for (const m of newModels) {
  output.push(...m.lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done! Total models:', existing.size + newModels.size);
