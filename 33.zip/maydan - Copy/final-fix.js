const fs = require('fs');

// Read original
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');

// Parse all models from additions
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

// Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

const originalModels = parseModels(originalContent);
const additionModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [name, lines] of parseModels(content)) {
    additionModels.set(name, lines);
  }
}

console.log('Original models:', originalModels.size);
console.log('Addition models:', additionModels.size);

// Find new models that don't exist in original
const newModels = [];
for (const [name, lines] of additionModels) {
  if (!originalModels.has(name)) {
    newModels.push({ name, lines });
  }
}
console.log('New models to add:', newModels.length);

// Add new models to original
let output = originalContent.trimEnd() + '\n\n';
output += '// ============================================\n';
output += '// New Models from Additions\n';
output += '// ============================================\n\n';

for (const { name, lines } of newModels) {
  output += lines.join('\n') + '\n\n';
}

fs.writeFileSync('prisma/schema.prisma', output);
console.log('Written schema.prisma');

// Now add back-relations using a different approach
// Read the new content
let schemaContent = fs.readFileSync('prisma/schema.prisma', 'utf8');
const schemaLines = schemaContent.split('\n');

// For each existing model that has new relations pointing to it, add back-relations
// We need to find the closing brace of each model and insert before it

// Map of models that need back-relations
const needsBackRelations = {
  'Employee': ['employmentContracts EmploymentContract[]','salaryStructures SalaryStructure[]','allowances Allowance[]','deductions Deduction[]','bonuses Bonus[]','overtimes Overtime[]','attendances Attendance[]','leaveRecords LeaveRecord[]','payrollEmployees PayrollEmployee[]','adjustments Adjustment[]','employeeDocuments EmployeeDocument[]','employeeOnboardings EmployeeOnboarding[]','employmentVerifications EmploymentVerification[]'],
  'Company': ['employmentContracts EmploymentContract[]','salaryStructures SalaryStructure[]','salaryComponents SalaryComponent[]','allowances Allowance[]','deductions Deduction[]','bonuses Bonus[]','overtimes Overtime[]','shifts Shift[]','attendances Attendance[]','leavePolicies LeavePolicy[]','leaveRecords LeaveRecord[]','payrollPeriods PayrollPeriod[]','payrollRuns PayrollRun[]','payrollEmployees PayrollEmployee[]','payslips Payslip[]','payrollHistories PayrollHistory[]','payrollRules PayrollRule[]','taxRules TaxRule[]','adjustments Adjustment[]','employeeDocuments EmployeeDocument[]','onboardingTemplates OnboardingTemplate[]','onboardingTasks OnboardingTask[]','employeeOnboardings EmployeeOnboarding[]','payrollPayments PayrollPayment[]'],
  'User': ['employmentVerifications EmploymentVerification[]','employeeDocuments EmployeeDocument[]','onboardingNotes OnboardingNote[]','employeeOnboardings EmployeeOnboarding[] @relation("OnboardingAssignedTo")','liveRoomNotifications LiveRoomNotification[]','liveRoomHistories LiveRoomHistory[]','liveRoomReactions LiveRoomReaction[]','liveRoomModerationLogs LiveRoomModerationLog[] @relation("ModerationTarget")','liveRoomModerationActions LiveRoomModerationLog[] @relation("ModerationAction")','liveRoomInvitesSent LiveRoomInvite[] @relation("InviteSender")','liveRoomInvitesReceived LiveRoomInvite[] @relation("InviteRecipient")'],
  'LiveRoom': ['liveRoomNotifications LiveRoomNotification[]','liveRoomModerationLogs LiveRoomModerationLog[]','liveRoomHistories LiveRoomHistory[]','liveRoomReactions LiveRoomReaction[]','liveRoomInvites LiveRoomInvite[]'],
  'PayrollRun': ['payments PayrollPayment[]'],
  'OnboardingTemplate': ['onboardingTasks OnboardingTask[]','employeeOnboardings EmployeeOnboarding[]'],
  'OnboardingTask': ['dependentTasks OnboardingTask[] @relation("TaskDependency")','taskInstances OnboardingTaskInstance[]'],
  'EmployeeOnboarding': ['taskInstances OnboardingTaskInstance[]','onboardingNotes OnboardingNote[]'],
  'Shift': ['attendances Attendance[]'],
  'LeavePolicy': ['leaveRecords LeaveRecord[]'],
};

// Process schema line by line
const result = [];
let currentModel = null;
let braceCount = 0;
let inModel = false;

for (let i = 0; i < schemaLines.length; i++) {
  const line = schemaLines[i];
  const trimmed = line.trim();
  
  // Check for model start
  const modelMatch = trimmed.match(/^model (\w+) \{/);
  if (modelMatch) {
    currentModel = modelMatch[1];
    inModel = true;
    braceCount = 1;
    result.push(line);
    continue;
  }
  
  if (inModel) {
    // Count braces
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    
    // Check if this line closes the model (contains })
    if (braceCount === 0 && line.includes('}')) {
      // Add back-relations before closing brace
      const rels = needsBackRelations[currentModel];
      if (rels) {
        // Check if relations already exist in model
        const modelStart = result.findIndex(l => l.includes(`model ${currentModel} {`));
        const modelContent = result.slice(modelStart).join('\n');
        
        const missingRels = rels.filter(r => {
          const fieldName = r.split(' ')[0];
          return !modelContent.includes(fieldName);
        });
        
        if (missingRels.length > 0) {
          result.push('  // Back-relations');
          for (const rel of missingRels) {
            result.push('  ' + rel);
          }
        }
      }
      
      result.push(line);
      inModel = false;
      currentModel = null;
      continue;
    }
    
    result.push(line);
    continue;
  }
  
  result.push(line);
}

fs.writeFileSync('prisma/schema.prisma', result.join('\n'));
console.log('Done!');
