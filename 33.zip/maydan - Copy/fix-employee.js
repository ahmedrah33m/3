const fs = require('fs');

let content = fs.readFileSync('prisma/schema.prisma', 'utf8');
const lines = content.split('\n');

// Find Employee model and fix duplicate relations
let i = 0;
while (i < lines.length) {
  if (lines[i].trim() === 'model Employee {') {
    // Found Employee model
    const modelStart = i;
    let modelEnd = i + 1;
    let braceCount = 1;
    
    // Find end of model
    while (modelEnd < lines.length && braceCount > 0) {
      if (lines[modelEnd].includes('{')) braceCount++;
      if (lines[modelEnd].includes('}')) braceCount--;
      if (braceCount > 0) modelEnd++;
    }
    
    // Extract model content
    const modelLines = lines.slice(modelStart, modelEnd + 1);
    
    // Find and remove duplicate relations at the top (before id)
    const idLine = modelLines.findIndex(l => l.trim().startsWith('id '));
    const firstRelLine = modelLines.findIndex(l => l.includes('@relation'));
    
    if (firstRelLine !== -1 && firstRelLine < idLine) {
      // There are relation lines before id - they are duplicates
      // Remove them
      const cleanedModel = [];
      let inTopRels = true;
      for (const line of modelLines) {
        if (inTopRels && line.includes('@relation')) {
          continue; // Skip top relations
        }
        if (line.trim().startsWith('id ')) {
          inTopRels = false;
        }
        cleanedModel.push(line);
      }
      
      // Replace model in lines
      lines.splice(modelStart, modelEnd - modelStart + 1, ...cleanedModel);
    }
    
    break;
  }
  i++;
}

fs.writeFileSync('prisma/schema.prisma', lines.join('\n'));
console.log('Fixed Employee model');
