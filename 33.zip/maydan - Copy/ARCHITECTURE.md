# توثيق معمارية النظام — ميدان المنصة المهنية

<div dir="rtl">

## 🏗️ نظرة عامة

**ميدان** هي منصة مهنية عراقية متكاملة تربط الخبراء والأكاديميين والباحثين والطلاب والمؤسسات والشركات وصناع القرار. تركز على الاقتصاد العراقي مع دعم متعدد اللغات (عربي/إنجليزي/كردي).

---

## 🛠️ التقنيات المستخدمة

| الطبقة | التقنية | الإصدار |
|--------|---------|---------|
| **Frontend** | Next.js (App Router) | 16.2.7 |
| **UI Framework** | React | 19.0.0 |
| **Language** | TypeScript | 5.x |
| **Styling** | Tailwind CSS | 4.x |
| **Components** | shadcn/ui + Radix UI | متعدد |
| **State Management** | Zustand + TanStack Query | 5.x + 5.82 |
| **Backend** | Next.js API Routes (Route Handlers) | — |
| **Edge** | Next.js Edge Middleware | — |
| **Database** | PostgreSQL + Prisma ORM | 14+ / 6.19.2 |
| **Cache** | Redis (ioredis) | 6+ / 5.11 |
| **Auth** | JWT (jose) + bcryptjs + CSRF double-submit | 6.2.3 / 3.0.3 |
| **AI** | z-ai-web-dev-sdk | 0.0.17 |
| **Storage** | MinIO/S3 (AWS SDK) — fallback to local | 3.600 |
| **Realtime** | SSE + WebSocket | socket.io 4.8 |
| **Email** | Nodemailer (SMTP) | 8.0.10 |
| **Validation** | Zod | 4.0.2 |
| **Forms** | React Hook Form + @hookform/resolvers | 7.60 / 5.1 |
| **Charts** | Recharts | 2.15.4 |
| **Markdown** | react-markdown + @mdxeditor | 10.1 / 3.39 |
| **PDF** | pdfjs-dist + html2pdf.js | 4.8 / 0.14 |
| **Animations** | Framer Motion | 12.23 |
| **DnD** | @dnd-kit/core | 6.3.1 |

---

## 📁 بنية المشروع

```
13/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── (main)/                   # المسارات المحمية (تتطلب تسجيل دخول)
│   │   │   ├── admin/                # لوحة المدير
│   │   │   ├── dashboard/            # لوحة المستخدم
│   │   │   ├── articles/             # المقالات + تفاصيل المقال
│   │   │   ├── discussions/          # النقاشات
│   │   │   ├── economy/              # الأدوات الاقتصادية
│   │   │   │   ├── map/              # خريطة اقتصادية
│   │   │   │   ├── calendar/         # تقويم اقتصادي
│   │   │   │   ├── converter/        # محول عملات
│   │   │   │   ├── charts/           # رسوم بيانية
│   │   │   │   ├── market/           # أسواق
│   │   │   │   ├── ai-assistant/     # مساعد AI اقتصادي
│   │   │   │   └── indicators/       # مؤشرات
│   │   │   ├── jobs/                 # وظائف + سير ذاتية + متقدمين
│   │   │   │   ├── candidate/        # لوحة المرشح
│   │   │   │   └── employer/         # لوحة صاحب العمل
│   │   │   ├── learning/             # مسارات التعلم
│   │   │   ├── academy/              # أكاديمية
│   │   │   ├── profile/[id]/         # ملف شخصي
│   │   │   ├── experts/              # خبراء
│   │   │   ├── expert-market/        # سوق الخبراء
│   │   │   ├── consultations/        # استشارات
│   │   │   ├── messages/             # رسائل مباشرة
│   │   │   ├── chat-rooms/           # غرف دردشة
│   │   │   ├── wallet/               # محفظة
│   │   │   ├── finance/              # تمويل
│   │   │   ├── investment-bank/      # بنك استثماري
│   │   │   ├── bookmarks/            # محفوظات
│   │   │   ├── notifications/        # إشعارات
│   │   │   ├── polls/                # استطلاعات
│   │   │   ├── questions/            # أسئلة وأجوبة
│   │   │   ├── quizzes/              # اختبارات
│   │   │   ├── research/             # أبحاث
│   │   │   ├── events/               # أحداث
│   │   │   ├── achievements/         # إنجازات
│   │   │   ├── leaderboard/          # لوحة المتصدرين
│   │   │   ├── dictionary/           # قاموس اقتصادي
│   │   │   ├── cv-builder/           # بناء سيرة ذاتية
│   │   │   ├── ai-assistant/         # مساعد AI
│   │   │   ├── connections/          # اتصالات
│   │   │   ├── create-post/          # إنشاء منشور
│   │   │   ├── write/                # محرر مقالات
│   │   │   ├── search/               # بحث
│   │   │   ├── tags/[tag]/           # تصفح حسب وسم
│   │   │   ├── owner-panel/          # لوحة المالك
│   │   │   ├── owner/                # إدارة المالك
│   │   │   ├── company-dashboard/    # لوحة الشركة
│   │   │   ├── consultant-dashboard/ # لوحة المستشار
│   │   │   ├── premium/              # اشتراك مدفوع
│   │   │   └── verify-certificate/   # التحقق من شهادة
│   │   ├── [locale]/                 # نسخة متعددة اللغات (stub)
│   │   ├── api/                      # API Routes
│   │   │   ├── auth/                 # مصادقة (login, register, 2FA, OAuth)
│   │   │   ├── admin/                # مسارات المدير (40+ route)
│   │   │   ├── articles/             # مقالات
│   │   │   ├── ai/                   # ذكاء اصطناعي
│   │   │   ├── economy/              # اقتصاد
│   │   │   ├── jobs/                 # وظائف
│   │   │   ├── users/                # مستخدمين
│   │   │   ├── notifications/        # إشعارات (SSE)
│   │   │   ├── payments/             # مدفوعات
│   │   │   ├── push/                 # إشعارات Web Push
│   │   │   ├── academy/              # أكاديمية
│   │   │   ├── assessment/           # تقييمات
│   │   │   ├── chat-rooms/           # غرف دردشة (SSE)
│   │   │   ├── consultations/        # استشارات
│   │   │   ├── conversations/        # محادثات
│   │   │   ├── dictionary/           # قاموس
│   │   │   ├── events/               # أحداث
│   │   │   ├── expert-market/        # سوق الخبراء
│   │   │   ├── finance/              # مالية
│   │   │   ├── follows/              # متابعة
│   │   │   ├── investment-bank/      # بنك استثمار
│   │   │   ├── mentorship/           # إرشاد
│   │   │   ├── polls/                # استطلاعات
│   │   │   ├── posts/                # منشورات
│   │   │   ├── profile/              # ملف شخصي
│   │   │   ├── questions/            # أسئلة
│   │   │   ├── reputation/           # سمعة
│   │   │   ├── research/             # أبحاث
│   │   │   ├── security/             # أمان (حذف حساب)
│   │   │   ├── uploads/              # رفع ملفات
│   │   │   └── ...                   # المزيد
│   │   ├── login/                    # صفحة الدخول
│   │   ├── register/                 # صفحة التسجيل
│   │   ├── layout.tsx                # الـ layout الجذري
│   │   ├── page.tsx                  # الصفحة الرئيسية
│   │   ├── sitemap.ts                # خريطة الموقع
│   │   ├── global-error.tsx          # معالج الأخطاء العامة
│   │   └── error.tsx                 # معالج الأخطاء
│   ├── components/                   # مكونات React
│   │   ├── ui/                       # مكونات shadcn/ui الأساسية (60+ مكون)
│   │   ├── admin/                    # مكونات لوحة الإدارة
│   │   ├── security/                 # مكونات الأمان
│   │   ├── profile/                  # مكونات الملف الشخصي
│   │   └── ...                       # مكونات متخصصة
│   ├── lib/                          # مكتبات ومساعدات
│   │   ├── security/                 # وحدات الأمان (30+ ملف)
│   │   │   ├── csrf.ts
│   │   │   ├── session-manager.ts
│   │   │   ├── brute-force-guard.ts
│   │   │   ├── api-firewall.ts
│   │   │   ├── bot-detection.ts
│   │   │   ├── csp-builder.ts
│   │   │   ├── encryption-at-rest.ts
│   │   │   ├── webauthn.ts
│   │   │   ├── zero-trust.ts
│   │   │   └── ...
│   │   ├── features/                 # ميزات الأعمال (100+ ملف)
│   │   │   ├── oil-revenue.ts
│   │   │   ├── dinar-tracker.ts
│   │   │   ├── fact-checker.ts
│   │   │   ├── economic-sentiment.ts
│   │   │   ├── auto-briefings.ts
│   │   │   ├── tipping-system.ts
│   │   │   ├── escrow-service.ts
│   │   │   ├── subscription-engine.ts
│   │   │   ├── webhook-manager.ts
│   │   │   ├── _archived/            # ميزات مؤرشفة
│   │   │   └── ...
│   │   ├── social/                   # ميزات اجتماعية (15+ ملف)
│   │   │   ├── voice-rooms.ts
│   │   │   ├── debate-rooms.ts
│   │   │   ├── collaborative-editing.ts
│   │   │   ├── direct-messages-enhanced.ts
│   │   │   ├── article-series.ts
│   │   │   ├── live-qa.ts
│   │   │   ├── mentorship.ts
│   │   │   └── ...
│   │   ├── economic/                 # أدوات اقتصادية
│   │   │   ├── isx-ticker.ts         # سوق العراق للأوراق المالية
│   │   │   ├── gdp-tracker.ts
│   │   │   ├── inflation-calculator.ts
│   │   │   ├── currency-analytics.ts
│   │   │   └── oil-dashboard.ts
│   │   ├── ai/                       # وحدات الذكاء الاصطناعي
│   │   │   ├── content-quality-scorer.ts
│   │   │   ├── sentiment-engine.ts
│   │   │   ├── trend-predictor.ts
│   │   │   └── smart-search.ts
│   │   ├── platform/                 # منصة (feature flags, caching)
│   │   ├── payment/                  # بوابات دفع
│   │   ├── locales/                  # ترجمات (ar, en, ku)
│   │   ├── auth.ts                   # نظام المصادقة
│   │   ├── db.ts                     # اتصال Prisma
│   │   ├── redis.ts                  # اتصال Redis
│   │   ├── cache.ts                  # طبقة الكاش
│   │   ├── email.ts                  # خدمة البريد
│   │   ├── moderation.ts             # إشراف على المحتوى
│   │   ├── security-middleware.ts    # middleware أمان
│   │   └── ...
│   ├── services/                     # طبقة الخدمات (business logic)
│   │   ├── article.service.ts
│   │   ├── comment.service.ts
│   │   ├── discussion.service.ts
│   │   ├── job.service.ts
│   │   ├── job-application.service.ts
│   │   ├── payment.service.ts
│   │   ├── cv-bank.service.ts
│   │   ├── message.service.ts
│   │   └── notification.service.ts
│   ├── repositories/                 # نمط Repository (وصول البيانات)
│   │   └── index.ts
│   ├── hooks/                        # React hooks مخصصة
│   │   ├── useChatSSE.ts
│   │   ├── useNotificationsSSE.ts
│   │   ├── usePushNotifications.ts
│   │   ├── useReadingStreak.ts
│   │   ├── useWalletBalance.ts
│   │   ├── useCsrf.ts
│   │   ├── useContentTranslation.ts
│   │   ├── use-mobile.ts
│   │   └── use-toast.ts
│   ├── types/                        # تعريفات الأنواع
│   │   └── index.ts
│   ├── __tests__/                    # اختبارات Vitest
│   │   ├── auth.test.ts
│   │   ├── cache.test.ts
│   │   ├── moderation.test.ts
│   │   ├── rate-limit.test.ts
│   │   └── ...
│   ├── middleware.ts                 # Edge middleware (CSRF + rate-limit + auth)
│   ├── globals.css                   # الأنماط العامة
│   └── globals.d.ts                  # تعريفات الأنواع العامة
├── prisma/
│   ├── schema.prisma                 # مخطط قاعدة البيانات (227 نموذج)
│   ├── seed.ts                       # بذر البيانات
│   ├── seed-standalone.ts            # بذر مستقل
│   ├── seed-comprehensive.ts         # بذر شامل
│   ├── seed-dictionary.ts            # بذر القاموس الاقتصادي
│   └── migrations/                   # migrations
├── public/                           # ملفات ثابتة
│   ├── uploads/                      # ملفات مرفوعة (gitignored)
│   ├── manifest.json                 # PWA manifest
│   ├── sw.js                         # Service Worker
│   ├── logo.svg, logo.png, logo.jpg
│   ├── favicon.ico
│   └── offline.html                  # صفحة وضع عدم الاتصال
├── docs/                             # توثيق
├── scripts/                          # سكريبتات تشغيل وصيانة
├── examples/                         # أمثلة (websocket)
├── middleware.ts                     # (محذوف — كان يتعارض مع src/middleware.ts)
├── next.config.ts                    # إعدادات Next.js
├── tsconfig.json                     # إعدادات TypeScript
├── eslint.config.mjs                 # إعدادات ESLint
├── tailwind.config.ts                # إعدادات Tailwind
├── postcss.config.js                 # إعدادات PostCSS
├── vitest.config.ts                  # إعدادات Vitest
├── docker-compose.yml                # إنتاج Docker
├── docker-compose.dev.yml            # تطوير Docker
├── Dockerfile                        # صورة الإنتاج
├── Dockerfile.notification           # خدمة إشعارات منفصلة
├── Caddyfile                         # إعدادات Caddy (reverse proxy)
├── postgres.conf                     # إعدادات PostgreSQL
├── package.json                      # الاعتماديات
└── .env.example                      # قالب البيئة
```

---

## 🔐 آلية المصادقة (Authentication Flow)

### 1. التسجيل / تسجيل الدخول

```
User → POST /api/auth/register
  ├─ التحقق من المدخلات (Zod schema)
  ├─ فحص rate-limiting (5 محاولات/ساعة)
  ├─ فحص bot-detection (User-Agent, fingerprint)
  ├─ hash كلمة المرور (bcrypt)
  ├─ إنشاء user في PostgreSQL
  ├─ إنشاء verification code (6 digits, يُرسل بالإيميل)
  └─ Response: { success: true, requiresVerification: true }

User → POST /api/auth/verify-email
  ├─ التحقق من code
  └─ تحديث user.emailVerified = true

User → POST /api/auth/login
  ├─ فحص brute-force (account-lockout بعد 5 محاولات فاشلة)
  ├─ مقارنة كلمة المرور
  ├─ فحص 2FA (إن مفعّل)
  ├─ توليد JWT (jose) — يحوي: userId, role, sessionId
  ├─ set cookie: maydan_session (HttpOnly, Secure, SameSite=Strict)
  ├─ توليد CSRF token + cookie (double-submit)
  ├─ تسجيل في UserSession (للمتابعة)
  └─ Response: { success: true, user: {...} }
```

### 2. حماية الطلبات اللاحقة

```
Request → Edge Middleware (src/middleware.ts)
  ├─ 0. Bot/scanner early reject (paths مثل /wp-admin, /.env) → 410 Gone
  ├─ 0a. /uploads/* → rewrite إلى /api/uploads (للتحكم Content-Type)
  ├─ 0b. Skip static assets
  ├─ 1. ensureCsrfCookie (إن لم توجد، يُولّد واحدة)
  ├─ 2. لـ /api/*:
  │    ├─ Rate-limit: 10,000 req/min لكل IP
  │    ├─ CSRF verification: مقارنة X-CSRF-Token header مع cookie
  │    └─ إضافة X-RateLimit-* headers
  └─ 3. للصفحات المحمية (/dashboard, /admin, ...):
       ├─ فحص maydan_session cookie
       ├─ verifyToken (JWT verification على Edge)
       ├─ isTokenBlacklistedEdge (فحص JWT blacklist)
       └─ Admin check (للـ /admin, /owner-panel)
```

### 3. تسجيل الخروج

```
User → POST /api/auth/logout
  ├─ إضافة JWT إلى blacklist (Redis)
  ├─ حذف UserSession من PostgreSQL
  └─ مسح cookie maydan_session
```

---

## 🗄️ آلية عمل قاعدة البيانات

### Prisma Schema (227 نموذج)

النماذج الرئيسية:
- **User** — المستخدم (مع حقول OAuth, 2FA, CV Bank, إلخ)
- **Article** — المقالات (مع category, status, analytics)
- **Discussion** + **DiscussionReply** — النقاشات
- **Question** + **Answer** — أسئلة وأجوبة
- **Job** + **JobApplication** — وظائف
- **Consultation** + **ConsultationMessage** — استشارات
- **Event** + **EventRegistration** — أحداث
- **Wallet** + **WalletTransaction** — محفظة
- **Notification** + **NotificationPreference** — إشعارات
- **Payment** + **TopUpRequest** + **WithdrawalRequest** — مدفوعات
- **ExpertProfile** + **ExpertService** — ملفات الخبراء
- **LearningPath** + **Lesson** + **Enrollment** — تعليم
- **Research** + **ResearchProject** — أبحاث

### استراتيجية الكاش (Redis)

```typescript
// src/lib/cache.ts
- L1: Memory cache (Map) — TTL 60s
- L2: Redis cache — TTL 5min
- L3: PostgreSQL
- Cache invalidation على writes
```

### أنماط الاستعلام

```typescript
// Repository pattern (src/repositories/index.ts)
class ArticleRepository {
  async findMany(...) {
    const cached = await cache.get<Article[]>(key)
    if (cached) return cached
    const items = await db.article.findMany(...)
    await cache.set(key, items, 300)
    return items
  }
}

// Service pattern (src/services/article.service.ts)
class ArticleService {
  async create(input, userId) {
    // 1. validate
    // 2. authorize
    // 3. create in DB
    // 4. invalidate cache
    // 5. send notifications
    // 6. return
  }
}
```

---

## 🔔 نظام الإشعارات اللحظية

### SSE (Server-Sent Events)

```
Client → GET /api/notifications/stream
  ├─ فحص JWT
  ├─ set headers: Content-Type: text/event-stream, Cache-Control: no-cache
  ├─ keep-alive ping كل 30s
  └─ Listen على Redis pub/sub channel: notifications:user:<userId>

Server (any service) → notificationService.send(userId, type, data)
  ├─ INSERT INTO Notification
  ├─ PUBLISH notifications:user:<userId> { ...event }
  └─ (optional) send push notification via Web Push API
```

### Web Push (اختياري)

```typescript
// src/hooks/usePushNotifications.ts
- تسجيل Service Worker
- طلب إذن الإشعارات
- توليد VAPID keys
- POST /api/push/subscribe → يحفظ PushSubscription في PostgreSQL
- إرسال إشعارات عبر web-push library
```

---

## 💾 نظام التخزين (Storage)

### استراتيجية متعددة الطبقات

```typescript
// src/lib/storage.ts
1. Production: MinIO/S3 (AWS SDK)
   - رفع ملفات إلى bucket
   - توليد presigned URLs
   - دعم image optimization عبر Sharp

2. Development fallback: local filesystem
   - public/uploads/<type>/<uuid>.<ext>
   - يُخدم عبر /uploads/* (middleware rewrite)
```

### معالجة الصور

```typescript
// src/lib/image-utils.ts + image-compression.ts
- Sharp لـ resize/optimize
- توليد blurhash لكل صورة (لـ placeholder)
- تحويل إلى WebP/AVIF
- حفظ metadata في قاعدة البيانات
```

---

## 🤖 نظام الذكاء الاصطناعي

### z-ai-web-dev-sdk

```typescript
// src/lib/ai-utils.ts
- chat completion (محادثة)
- image generation
- web search
- vision (تحليل صور)
- speech-to-text (ASR)
- text-to-speech (TTS)
```

### الاستخدامات

1. **مساعد AI اقتصادي** (`/economy/ai-assistant`) — محادثة مع AI عن الاقتصاد العراقي
2. **مساعد كتابة** (`/write`) — تحسين المقالات
3. **تحليل المشاعر** (`src/lib/ai/sentiment-engine.ts`) — تحليل تعليقات المستخدمين
4. **تقييم جودة المحتوى** (`src/lib/ai/content-quality-scorer.ts`)
5. **توصيات ذكية** (`src/lib/recommendations.ts`)
6. **ترجمة تلقائية** (`src/lib/translate.ts`)
7. **إشراف AI** (`src/lib/moderation-ai.ts`) — كشف محتوى غير مناسب
8. **تلخيص** — تلخيص المقالات الطويلة

---

## 🛡️ طبقات الأمان

### 1. Edge Layer (middleware.ts)

- Rate-limiting per IP (10K req/min)
- CSRF double-submit cookie
- Bot detection (User-Agent + path-based)
- JWT verification at edge
- Token blacklist check (Redis)
- Route-level auth guard

### 2. API Layer (Route Handlers)

- Input validation (Zod schemas)
- Authorization checks (role-based)
- Audit logging (`src/lib/audit.ts`)
- Request integrity check (HMAC for webhooks)

### 3. Service Layer (services/)

- Business logic validation
- Permission checks
- Transaction management
- Email notification triggers

### 4. Data Layer (Prisma)

- Field-level encryption (AES-256-GCM) for PII
- Soft deletes (deletedAt)
- Optimistic concurrency (version fields)
- Indexes for performance

### 5. Security Modules (lib/security/)

```
├── api-firewall.ts          # جدار حماية API
├── api-key-manager.ts       # إدارة API keys
├── api-scanner.ts           # فحص API للاختراق
├── audit-enhanced.ts        # تدقيق محسّن
├── audit-trail.ts           # مسار التدقيق
├── bot-detection.ts         # كشف البوتات
├── brute-force-guard.ts     # منع هجمات القوة الغاشمة
├── content-injection-guard.ts
├── cors-config.ts           # إعدادات CORS
├── csp-builder.ts           # بناء CSP
├── data-classification.ts   # تصنيف البيانات
├── data-leak-prevention.ts  # منع تسريب البيانات
├── data-masking.ts          # إخفاء البيانات الحساسة
├── device-fingerprint.ts    # بصمة الجهاز
├── dos-protection.ts        # حماية DoS
├── email-change-flow.ts     # تدفق تغيير البريد
├── encryption-at-rest.ts    # تشفير at-rest
├── geo-access-control.ts    # تحكم جغرافي
├── input-validation.ts      # التحقق من المدخلات
├── ip-reputation.ts         # سمعة IP
├── login-anomaly.ts         # كشف شذوذ تسجيل الدخول
├── magic-links.ts           # روابط سحرية
├── password-policy.ts       # سياسة كلمات المرور
├── permission-engine.ts     # محرك الصلاحيات
├── request-integrity.ts     # سلامة الطلبات
├── security-headers.ts      # ترويسات أمان
├── session-hardening.ts     # تقوية الجلسات
├── session-manager.ts       # مدير الجلسات
├── tiered-rate-limit.ts     # rate-limit متدرج
├── webauthn.ts              # مصادقة WebAuthn
└── zero-trust.ts            # بنية الثقة الصفرية
```

---

## 🌐 تدفق البيانات (Data Flow)

### مثال: إنشاء مقال جديد

```
1. User → POST /api/articles (مع CSRF token)
   │
2. Edge Middleware:
   ├─ Rate-limit check ✓
   ├─ CSRF verify ✓
   └─ Pass to API route
   │
3. API Route (src/app/api/articles/route.ts):
   ├─ authenticate(req) → استخراج userId من JWT
   ├─ validateInput(data, articleSchema) → Zod validation
   ├─ authorize(userId, 'article:create') → فحص الصلاحية
   └─ articleService.create(data, userId)
   │
4. Article Service (src/services/article.service.ts):
   ├─ Generate slug
   ├─ Hash tags
   ├─ db.article.create({ data: {...} }) → Prisma
   ├─ cache.invalidate('articles:*') → Redis
   ├─ audit.log(userId, 'article:create', articleId) → AuditLog
   ├─ notificationService.notifyFollowers(userId, ...) → Redis pub/sub
   └─ return article
   │
5. API Route → Response:
   └─ { success: true, article: {...} }
   │
6. Client (React):
   ├─ queryClient.invalidateQueries(['articles']) → refetch
   ├─ toast.success('تم نشر المقال')
   └─ router.push('/articles/' + article.id)
```

---

## 🚀 النشر (Deployment)

### Docker Production

```yaml
# docker-compose.yml
services:
  app:              # Next.js standalone
    build: .
    ports: ["3300:3300"]
    env_file: .env
  
  postgres:         # PostgreSQL 16
    image: postgres:16-alpine
    volumes: [pgdata:/var/lib/postgresql/data]
  
  redis:            # Redis 7
    image: redis:7-alpine
  
  minio:            # MinIO (S3-compatible)
    image: minio/minio
    volumes: [minio_data:/data]
  
  caddy:            # Reverse proxy + auto HTTPS
    image: caddy:2-alpine
    ports: ["80:80", "443:443"]
  
  notification-service:  # Separate service for heavy notification work
    build:
      dockerfile: Dockerfile.notification
```

### Build Process

```bash
npm run build
# 1. next build → .next/
# 2. cp -r .next/static .next/standalone/.next/
# 3. cp -r public .next/standalone/
# Output: .next/standalone/ (self-contained, ~50MB)
```

---

## 📊 الأداء والمقياسات

### تحسينات الأداء

1. **Standalone output** — يُنتج خادم Node.js مستقل بدون node_modules كامل
2. **Image optimization** — Sharp + AVIF/WebP + blurhash placeholders
3. **Redis caching** — L2 cache layer للاستعلامات المتكررة
4. **Database indexing** — فهارس GIN على حقول البحث النصي
5. **Code splitting** — dynamic imports للصفحات الثقيلة
6. **Edge middleware** — CSRF + auth على Edge قبل وصول الطلب
7. **Connection pooling** — PgBouncer في الإنتاج
8. **CDN** — Caddy + MinIO للملفات الثابتة

### المقياسات المستهدفة (لـ 100K مستخدم)

- **Concurrent users**: 5,000-10,000
- **API response time**: < 200ms (p95)
- **Database connections**: 50 (pool)
- **Cache hit ratio**: > 90%
- **Image load time**: < 100ms (CDN)

---

## 📚 المراجع

- `README.md` — نظرة عامة
- `DEPLOY.md` — دليل النشر
- `SECURITY-ALERT.md` — تنبيهات أمنية
- `SECURITY-FIXES-P0.md` — إصلاحات أمنية حرجة
- `FIXES-REPORT.md` — تقرير الإصلاحات السابق
- `FIXES-REPORT-V2.md` — **تقرير الإصلاحات الحالي (الأحدث)**
- `docs/AUDIT-REPORT.md` — تقرير التدقيق
- `docs/storage-architecture-100k.md` — معمارية التخزين لـ 100K مستخدم
- `docs/backup-restore-guide.md` — دليل النسخ الاحتياطي
- `docs/MIGRATION.md` — دليل migrations
- `ARCHITECTURE.md` — **هذا الملف**

</div>
