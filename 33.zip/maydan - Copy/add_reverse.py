#!/usr/bin/env python3
"""
Add reverse relations for new models only.
For each new model, find its relations to existing models and add reverse.
"""

import re

def extract_models(content):
    models = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^model\s+(\w+)\s*\{', line)
        if m:
            if current:
                models[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        models[current] = '\n'.join(lines)
    return models

def get_relations(model_text):
    relations = []
    for line in model_text.split('\n'):
        m = re.match(r'\s+(\w+)\s+(\w+)\??\s+@relation\("([^"]+)"', line)
        if m:
            relations.append({
                'field': m.group(1),
                'target': m.group(2),
                'name': m.group(3)
            })
    return relations

# Read schemas
with open('../maydan/prisma/schema.prisma', 'r') as f:
    source = f.read()

with open('prisma/checkpoints/005-all-systems-merged.prisma', 'r') as f:
    checkpoint = f.read()

source_models = extract_models(source)
checkpoint_models = extract_models(checkpoint)

# New models (in checkpoint but not in source)
new_models = {name: text for name, text in checkpoint_models.items() if name not in source_models}

print(f"Source models: {len(source_models)}")
print(f"New models: {len(new_models)}")

# For each new model, find its relations to source models
# and add reverse relations
updated_source = dict(source_models)

for new_name, new_text in new_models.items():
    relations = get_relations(new_text)
    for rel in relations:
        target = rel['target']
        relation_name = rel['name']
        
        if target in updated_source:
            target_text = updated_source[target]
            
            # Check if reverse relation already exists
            if f'{new_name}[]' in target_text or f'{new_name}?' in target_text:
                continue
            
            # Add reverse relation
            field_name = new_name.lower() + 's'
            lines = target_text.rstrip().split('\n')
            if lines and lines[-1].strip() == '}':
                lines = lines[:-1]
            lines.append(f'  {field_name} {new_name}[] @relation("{relation_name}")')
            lines.append('}')
            updated_source[target] = '\n'.join(lines)
            print(f"  Added {new_name}[] to {target}")

# Build final schema
final = []
header_match = re.search(r'(.*?)^model\s', source, re.DOTALL | re.MULTILINE)
if header_match:
    final.append(header_match.group(1))

# Add source models (updated)
for name in sorted(updated_source):
    final.append(updated_source[name])

# Add new models
final.append('\n// ============================================')
final.append('// New Models (HR + Payroll + Live + Verification)')
final.append('// ============================================\n')

for name in sorted(new_models):
    final.append(checkpoint_models[name])

with open('prisma/schema.prisma', 'w') as f:
    f.write('\n\n'.join(final))

print(f"\n✅ Final: {len(updated_source) + len(new_models)} models")
