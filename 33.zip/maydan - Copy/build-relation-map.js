const fs = require('fs');

// Read base schema
const baseContent = fs.readFileSync('prisma/schema.base.prisma', 'utf8');

// Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

const baseModels = parseModels(baseContent);
console.log('=== Base Schema ===');
console.log('Total models:', baseModels.size);

// Read all addition files
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

// Parse new models from additions
const allNewModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  const models = parseModels(content);
  for (const [name, lines] of models) {
    if (!baseModels.has(name) && name !== 'Payment') {
      allNewModels.set(name, lines);
    }
  }
}

console.log('\n=== New Models (not in base) ===');
console.log('Total new models:', allNewModels.size);

// Build relation map
console.log('\n=== Relation Map ===');
console.log('Format: NewModel.fieldName -> TargetModel\n');

const relationMap = new Map(); // targetModel -> [{ fromModel, fromField, isList, isOptional }]

for (const [modelName, modelLines] of allNewModels) {
  console.log(`\n${modelName}:`);
  
  for (const line of modelLines) {
    const match = line.match(/^\s+(\w+)\s+(\w+)(\??)\s*@relation/);
    if (match) {
      const fieldName = match[1];
      const targetModel = match[2];
      const isOptional = match[3] === '?';
      const isList = line.includes(`${targetModel}[]`);
      
      console.log(`  ${fieldName} -> ${targetModel}${isList ? '[]' : isOptional ? '?' : ''}`);
      
      if (baseModels.has(targetModel)) {
        if (!relationMap.has(targetModel)) {
          relationMap.set(targetModel, []);
        }
        relationMap.get(targetModel).push({
          fromModel: modelName,
          fromField: fieldName,
          isList,
          isOptional
        });
      }
    }
  }
}

console.log('\n\n=== Reverse Relations Needed ===');
console.log('Format: ExistingModel needs [field: NewModel[]]\n');

for (const [targetModel, relations] of relationMap) {
  console.log(`${targetModel}:`);
  
  // Group by fromModel to determine if we need list or single
  const grouped = new Map();
  for (const rel of relations) {
    if (!grouped.has(rel.fromModel)) {
      grouped.set(rel.fromModel, []);
    }
    grouped.get(rel.fromModel).push(rel);
  }
  
  for (const [fromModel, rels] of grouped) {
    // If multiple relations from same model, we might need different field names
    const listRels = rels.filter(r => r.isList);
    const singleRels = rels.filter(r => !r.isList);
    
    if (singleRels.length > 0) {
      console.log(`  ${singleRels[0].fromField}: ${fromModel}[] (reverse of single relations)`);
    }
    if (listRels.length > 0) {
      for (const rel of listRels) {
        console.log(`  ${rel.fromField}: ${fromModel}[] (reverse of list relation)`);
      }
    }
  }
}
