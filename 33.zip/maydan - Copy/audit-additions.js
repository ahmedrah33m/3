const fs = require('fs');

// Read base schema
const base = fs.readFileSync('prisma/schema.base.prisma', 'utf8');

// Get existing model names and their relations
const existingModels = new Set();
for (const line of base.split('\n')) {
  const m = line.trim().match(/^model (\w+) \{/);
  if (m) existingModels.add(m[1]);
}
console.log('Existing models:', existingModels.size);

// Parse new models from additions
function parseNew(content) {
  const lines = content.split('\n');
  const models = [];
  let cur = null, brace = 0;
  for (const line of lines) {
    const t = line.trim();
    if (t.startsWith('//') || t === '') continue;
    const m = t.match(/^model (\w+) \{/);
    if (m) {
      if (cur) models.push(cur);
      cur = { name: m[1], lines: [line], relations: [], fields: [], indexes: [], uniques: [] };
      brace = 1;
    } else if (cur) {
      cur.lines.push(line);
      brace += (line.match(/\{/g)||[]).length - (line.match(/\}/g)||[]).length;
      
      // Check for relation fields
      const rm = t.match(/^\s+(\w+)\s+(\w+)(\??)\s*@relation/);
      if (rm) {
        cur.relations.push({ field: rm[1], target: rm[2], optional: rm[3]==='?', list: t.includes(rm[2]+'[]') });
      }
      
      // Check for scalar fields
      const fm = t.match(/^\s+(\w+)\s+(\w+)(\??)/);
      if (fm && !t.includes('@relation') && !t.startsWith('@@')) {
        cur.fields.push({ name: fm[1], type: fm[2], optional: fm[3]==='?' });
      }
      
      // Check for indexes
      if (t.startsWith('@@index')) cur.indexes.push(t);
      if (t.startsWith('@@unique')) cur.uniques.push(t);
      
      if (brace === 0) { models.push(cur); cur = null; }
    }
  }
  if (cur) models.push(cur);
  return models;
}

const files = [
  { name: 'payroll', content: fs.readFileSync('prisma/schema-additions-payroll.prisma', 'utf8') },
  { name: 'verification', content: fs.readFileSync('prisma/schema-additions-employment-verification.prisma', 'utf8') },
  { name: 'onboarding', content: fs.readFileSync('prisma/schema-additions-onboarding.prisma', 'utf8') },
  { name: 'live', content: fs.readFileSync('prisma/schema-additions-live-rooms.prisma', 'utf8') },
];

const allNewModels = [];
for (const f of files) {
  const models = parseNew(f.content);
  console.log(`\n${f.name}: ${models.length} models`);
  allNewModels.push(...models);
}

// Filter out existing and Payment
const newModels = allNewModels.filter(m => !existingModels.has(m.name) && m.name !== 'Payment');
console.log(`\nTotal new models: ${newModels.length}`);

// Build relation map
console.log('\n=== Relation Map ===');
const relationMap = [];

for (const m of newModels) {
  for (const r of m.relations) {
    const relationName = `${m.name}_${r.field}`;
    const reverseField = m.name.charAt(0).toLowerCase() + m.name.slice(1) + 's';
    
    relationMap.push({
      source: m.name,
      sourceField: r.field,
      target: r.target,
      optional: r.optional,
      list: r.list,
      relationName: relationName,
      reverseField: reverseField,
      isExistingTarget: existingModels.has(r.target),
    });
    
    if (existingModels.has(r.target)) {
      console.log(`${m.name}.${r.field} -> ${r.target} (@relation("${relationName}"))`);
    }
  }
}

console.log(`\nTotal relations: ${relationMap.length}`);
console.log(`Relations to existing models: ${relationMap.filter(r => r.isExistingTarget).length}`);
