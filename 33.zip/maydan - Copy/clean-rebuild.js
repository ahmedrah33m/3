const fs = require('fs');

const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');

const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.push({ name: currentModel, lines: currentLines });
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.push({ name: currentModel, lines: currentLines });
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.push({ name: currentModel, lines: currentLines });
  return models;
}

const originalModels = parseModels(originalContent);
console.log('Original models:', originalModels.length);

const originalNames = new Set(originalModels.map(m => m.name));

const allNewModels = [];
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  const models = parseModels(content);
  for (const model of models) {
    if (!originalNames.has(model.name)) {
      allNewModels.push(model);
    }
  }
}
console.log('New models to add:', allNewModels.length);

// Build output - modify existing models to add back-relations
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

// For each existing model, check if it needs back-relations
for (const model of originalModels) {
  // Find @relation fields in new models that reference this model
  const reverseRels = [];
  
  for (const newModel of allNewModels) {
    for (const line of newModel.lines) {
      const match = line.match(/^\s+(\w+)\s+(\w+)(\??)\s*@relation/);
      if (match && match[2] === model.name) {
        const fieldName = match[1];
        const isList = line.includes(`${match[2]}[]`);
        // Reverse: if original is list, reverse is single; if original is single, reverse is list
        if (isList) {
          reverseRels.push(`${fieldName} ${newModel.name}?`);
        } else {
          reverseRels.push(`${fieldName} ${newModel.name}[]`);
        }
      }
    }
  }
  
  if (reverseRels.length > 0) {
    // Check if these fields already exist
    const existingFields = new Set();
    for (const line of model.lines) {
      const fieldMatch = line.trim().match(/^(\w+)\s+/);
      if (fieldMatch && !line.trim().startsWith('model ') && !line.trim().startsWith('@@')) {
        existingFields.add(fieldMatch[1]);
      }
    }
    
    const missingRels = reverseRels.filter(r => !existingFields.has(r.split(' ')[0]));
    
    if (missingRels.length > 0) {
      const closingIdx = model.lines.length - 1;
      const newLines = [...model.lines];
      newLines.splice(closingIdx, 0, '', '  // Back-relations', ...missingRels.map(r => '  ' + r));
      output.push(...newLines);
    } else {
      output.push(...model.lines);
    }
  } else {
    output.push(...model.lines);
  }
  output.push('');
}

output.push('// ============================================');
output.push('// New Models');
output.push('// ============================================');
output.push('');

for (const model of allNewModels) {
  output.push(...model.lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
