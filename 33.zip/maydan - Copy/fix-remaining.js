const fs = require('fs');
const path = require('path');

function walkDir(dir, files = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walkDir(full, files);
    else if (entry.name.endsWith('.ts') || entry.name.endsWith('.tsx')) files.push(full);
  }
  return files;
}

const files = walkDir('src');
let fixed = 0;

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  let newContent = content;
  
  // Fix: Remove all user includes from Employee queries
  newContent = newContent.replace(/user:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix: Remove department/branch/contracts includes
  newContent = newContent.replace(/department:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/branch:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/contracts:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix: Remove payrollRun/paymentDate includes
  newContent = newContent.replace(/payrollRun:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/paymentDate:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix: Remove components from SalaryStructure
  newContent = newContent.replace(/components:\s*\{[^}]*\}\s*,?\s*/g, '');
  newContent = newContent.replace(/components\?:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix: Remove payrollRunId/processedById from Payment
  newContent = newContent.replace(/payrollRunId:\s*[^,}]*\s*,?\s*/g, '');
  newContent = newContent.replace(/processedById:\s*[^,}]*\s*,?\s*/g, '');
  
  // Fix: Remove user from where clauses
  newContent = newContent.replace(/user:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  // Fix: Remove user from select
  newContent = newContent.replace(/user:\s*\{[^}]*\}\s*,?\s*/g, '');
  
  if (newContent !== content) {
    fs.writeFileSync(file, newContent);
    fixed++;
  }
}

console.log(`Fixed ${fixed} files`);
