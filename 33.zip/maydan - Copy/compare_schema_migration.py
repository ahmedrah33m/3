#!/usr/bin/env python3
"""Compare schema.prisma with migration.sql and generate diff report."""

import re
import sys

def extract_models_from_schema(schema_file):
    """Extract models from schema.prisma."""
    models = {}
    with open(schema_file, 'r') as f:
        content = f.read()
    
    current = None
    for line in content.split('\n'):
        m = re.match(r'^model\s+(\w+)\s*\{', line)
        if m:
            current = m.group(1)
            models[current] = []
        elif current and line.strip() and not line.strip().startswith('//') and not line.strip().startswith('@@'):
            models[current].append(line.strip())
        elif current and line.strip() == '}':
            current = None
    
    return models

def extract_tables_from_migration(migration_file):
    """Extract tables from migration.sql."""
    tables = {}
    with open(migration_file, 'r') as f:
        content = f.read()
    
    current = None
    for line in content.split('\n'):
        m = re.match(r'CREATE TABLE\s+"(\w+)"', line)
        if m:
            current = m.group(1)
            tables[current] = []
        elif current and line.strip().startswith('"'):
            tables[current].append(line.strip())
        elif current and ';' in line:
            current = None
    
    return tables

def extract_enums_from_schema(schema_file):
    """Extract enums from schema.prisma."""
    enums = {}
    with open(schema_file, 'r') as f:
        content = f.read()
    
    current = None
    for line in content.split('\n'):
        m = re.match(r'^enum\s+(\w+)\s*\{', line)
        if m:
            current = m.group(1)
            enums[current] = []
        elif current and line.strip() and not line.strip().startswith('//'):
            enums[current].append(line.strip())
        elif current and line.strip() == '}':
            current = None
    
    return enums

def extract_enums_from_migration(migration_file):
    """Extract enums from migration.sql."""
    enums = {}
    with open(migration_file, 'r') as f:
        content = f.read()
    
    pattern = r'CREATE TYPE\s+"(\w+)"\s+AS\s+ENUM\s+\(([^)]+)\)'
    for m in re.finditer(pattern, content):
        name = m.group(1)
        values = [v.strip().strip("'") for v in m.group(2).split(',')]
        enums[name] = values
    
    return enums

# Extract data
print("Extracting data from schema...")
schema_models = extract_models_from_schema('prisma/schema.prisma')
schema_enums = extract_enums_from_schema('prisma/schema.prisma')

print("Extracting data from migration...")
migration_tables = extract_tables_from_migration('prisma/migrations/20260831000000_full_schema/migration.sql')
migration_enums = extract_enums_from_migration('prisma/migrations/20260831000000_full_schema/migration.sql')

# Find differences
schema_model_names = set(schema_models.keys())
migration_table_names = set(migration_tables.keys())

only_in_schema = schema_model_names - migration_table_names
only_in_migration = migration_table_names - schema_model_names
in_both = schema_model_names & migration_table_names

schema_enum_names = set(schema_enums.keys())
migration_enum_names = set(migration_enums.keys())

only_enums_in_schema = schema_enum_names - migration_enum_names
only_enums_in_migration = migration_enum_names - schema_enum_names

# Generate report
report = f"""# Schema ↔ Migration Diff Report

## Summary
- Schema Models: {len(schema_model_names)}
- Migration Tables: {len(migration_table_names)}
- Models in both: {len(in_both)}
- Only in Schema: {len(only_in_schema)}
- Only in Migration: {len(only_in_migration)}
- Schema Enums: {len(schema_enum_names)}
- Migration Enums: {len(migration_enum_names)}
- Enums in both: {len(schema_enum_names & migration_enum_names)}
- Only in Schema Enums: {len(only_enums_in_schema)}
- Only in Migration Enums: {len(only_enums_in_migration)}

## Models only in Schema ({len(only_in_schema)})
{chr(10).join(f'- {m}' for m in sorted(only_in_schema))}

## Models only in Migration ({len(only_in_migration)})
{chr(10).join(f'- {m}' for m in sorted(only_in_migration))}

## Enums only in Schema ({len(only_enums_in_schema)})
{chr(10).join(f'- {e}' for e in sorted(only_enums_in_schema))}

## Enums only in Migration ({len(only_enums_in_migration)})
{chr(10).join(f'- {e}' for e in sorted(only_enums_in_migration))}

## Field Differences (Models in both)
"""

# Compare fields for models in both
field_diffs = []
for model_name in sorted(in_both):
    schema_fields = set(schema_models[model_name])
    migration_fields = set(migration_tables[model_name])
    
    only_schema_fields = schema_fields - migration_fields
    only_migration_fields = migration_fields - schema_fields
    
    if only_schema_fields or only_migration_fields:
        field_diffs.append({
            'model': model_name,
            'only_schema': only_schema_fields,
            'only_migration': only_migration_fields
        })

if field_diffs:
    for diff in field_diffs[:20]:  # Show first 20
        report += f"\n### {diff['model']}\n"
        if diff['only_schema']:
            report += f"- Only in Schema: {', '.join(sorted(diff['only_schema'])[:5])}\n"
        if diff['only_migration']:
            report += f"- Only in Migration: {', '.join(sorted(diff['only_migration'])[:5])}\n"
else:
    report += "\nNo field differences found.\n"

# Write report
with open('docs/schema-migration-diff.md', 'w') as f:
    f.write(report)

print(report)
print("\n✅ Report saved to docs/schema-migration-diff.md")
