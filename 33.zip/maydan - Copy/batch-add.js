/**
 * Phase 4-7: Add models subsystem by subsystem
 * Rule: Add new models + back-relations to existing models
 * After EACH batch: prisma format → prisma validate → prisma generate
 */

const fs = require('fs');

// Helper: Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

// Helper: Rebuild schema from models map
function rebuildSchema(originalContent, modelsMap, newModelNames) {
  const lines = originalContent.split('\n');
  const output = [];
  let currentModel = null;
  let braceCount = 0;
  let inModel = false;
  const processedModels = new Set();

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      currentModel = match[1];
      inModel = true;
      braceCount = 1;
      processedModels.add(currentModel);
      
      // Output model with potential back-relations
      const modelLines = modelsMap.get(currentModel);
      if (modelLines) {
        output.push(...modelLines);
      } else {
        output.push(line);
      }
      continue;
    }
    
    if (inModel) {
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        inModel = false;
        currentModel = null;
      }
      continue;
    }
    
    output.push(line);
  }

  // Add new models at the end
  output.push('');
  output.push('// ============================================');
  output.push('// New Models');
  output.push('// ============================================');
  output.push('');

  for (const [name, lines] of modelsMap) {
    if (!processedModels.has(name)) {
      output.push(...lines);
      output.push('');
    }
  }

  return output.join('\n');
}

// Read current schema
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');
const currentModels = parseModels(originalContent);
console.log('Current models:', currentModels.size);

// Read all addition files
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

const allNewModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [name, lines] of parseModels(content)) {
    if (!currentModels.has(name)) {
      allNewModels.set(name, lines);
    }
  }
}
console.log('New models to add:', allNewModels.size);

// Determine back-relations needed for existing models
// For each @relation in new models, add reverse relation to existing model
const backRelationsToAdd = new Map(); // modelName -> Set of relation lines

for (const [modelName, modelLines] of allNewModels) {
  for (const line of modelLines) {
    // Match @relation fields: "  fieldName ModelName @relation(...)"
    const match = line.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
    if (match) {
      const fieldName = match[1];
      const referencedModel = match[2];
      
      // Only add back-relation if referenced model exists in original schema
      if (currentModels.has(referencedModel)) {
        if (!backRelationsToAdd.has(referencedModel)) {
          backRelationsToAdd.set(referencedModel, new Set());
        }
        
        // Determine if it's a list or single relation based on the field
        const isList = line.includes(`${referencedModel}[]`);
        const isOptional = line.includes(`${referencedModel}?`) || line.includes(`${referencedModel}[]?`);
        
        // Build the reverse relation line
        const relationName = fieldName + 's'; // Simple pluralization
        let reverseLine;
        if (isList) {
          reverseLine = `${fieldName} ${modelName}[]`;
        } else {
          reverseLine = `${fieldName} ${modelName}?`;
        }
        
        backRelationsToAdd.get(referencedModel).add(reverseLine);
      }
    }
  }
}

console.log('Existing models needing back-relations:', backRelationsToAdd.size);

// Add back-relations to existing models in the map
for (const [modelName, rels] of backRelationsToAdd) {
  const existingLines = currentModels.get(modelName);
  if (existingLines) {
    // Check if back-relations already exist
    const modelContent = existingLines.join('\n');
    const newRels = [...rels].filter(r => {
      const fieldName = r.split(' ')[0];
      return !modelContent.includes(fieldName);
    });
    
    if (newRels.length > 0) {
      // Insert before closing brace
      const closingIdx = existingLines.length - 1;
      existingLines.splice(closingIdx, 0, '', '  // Back-relations', ...newRels.map(r => '  ' + r));
      currentModels.set(modelName, existingLines);
    }
  }
}

// Add new models to the map
for (const [name, lines] of allNewModels) {
  currentModels.set(name, lines);
}

// Rebuild schema
const newSchema = rebuildSchema(originalContent, currentModels, new Set([...allNewModels.keys()]));
fs.writeFileSync('prisma/schema.prisma', newSchema);
console.log('Schema rebuilt!');
