#!/usr/bin/env python3
"""
Add reverse relations for new models by finding each target model's closing brace
and inserting before it.
"""

import re

def find_model_bounds(content, model_name):
    """Find the start and end line numbers of a model."""
    lines = content.split('\n')
    start = None
    end = None
    brace_count = 0
    
    for i, line in enumerate(lines):
        if re.match(r'^model\s+' + model_name + r'\s*\{', line):
            start = i
            brace_count = 1
            continue
        if start is not None:
            brace_count += line.count('{') - line.count('}')
            if brace_count == 0:
                end = i
                break
    
    return start, end

def get_relations(model_text):
    """Extract relations from a model."""
    relations = []
    for line in model_text.split('\n'):
        m = re.match(r'\s+(\w+)\s+(\w+)\??\s+@relation\("([^"]+)"', line)
        if m:
            relations.append({
                'field': m.group(1),
                'target': m.group(2),
                'name': m.group(3)
            })
    return relations

def extract_models(content):
    """Extract all models."""
    models = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^model\s+(\w+)\s*\{', line)
        if m:
            if current:
                models[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        models[current] = '\n'.join(lines)
    return models

# Read schema
with open('prisma/schema.prisma', 'r') as f:
    schema = f.read()

# Extract models
models = extract_models(schema)

# New models (added from checkpoint)
new_model_names = ['Adjustment', 'Allowance', 'Attendance', 'Bonus', 'Deduction', 
    'EmployeeDocument', 'EmployeeOnboarding', 'EmploymentContract', 
    'EmploymentVerification', 'EmploymentVerificationLog', 'EmploymentVerificationToken',
    'LeavePolicy', 'LeaveRecord', 'LiveRoomHistory', 'LiveRoomInvite', 
    'LiveRoomModerationLog', 'LiveRoomNotification', 'LiveRoomReaction',
    'OnboardingNote', 'OnboardingTask', 'OnboardingTaskInstance', 'OnboardingTemplate',
    'Overtime', 'PayrollEmployee', 'PayrollHistory', 'PayrollPeriod', 'PayrollRule', 
    'PayrollRun', 'Payslip', 'SalaryComponent', 'SalaryStructure', 'Shift', 'TaxRule']

# For each new model, find its relations and add reverse to target
lines = schema.split('\n')

for new_name in new_model_names:
    if new_name not in models:
        continue
    new_text = models[new_name]
    relations = get_relations(new_text)
    
    for rel in relations:
        target = rel['target']
        relation_name = rel['name']
        
        # Find target model in lines
        target_start, target_end = find_model_bounds('\n'.join(lines), target)
        
        if target_start is None or target_end is None:
            continue
        
        # Check if reverse relation already exists in target
        target_text = '\n'.join(lines[target_start:target_end+1])
        if f'{new_name}[]' in target_text or f'{new_name}?' in target_text:
            continue
        
        # Insert reverse relation before closing brace
        reverse_line = f'  {new_name.lower()}s {new_name}[] @relation("{relation_name}")'
        lines.insert(target_end, reverse_line)
        
        # Update end line for subsequent insertions
        target_end += 1

# Write back
with open('prisma/schema.prisma', 'w') as f:
    f.write('\n'.join(lines))

print("✅ Done! Reverse relations added.")
