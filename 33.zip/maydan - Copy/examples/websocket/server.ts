/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * ميدان - خدمة الإشعارات الفورية (Midan Notification WebSocket Service)
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * خدمة منفصلة بجانب موقع Next.js تُسلّم الإشعارات الفورية عبر WebSocket.
 *
 *  - WebSocket (Socket.io) على المنفذ 3003 — يتصل به المتصفح (frontend) بعد
 *    الحصول على ws-token من `GET /api/auth/ws-token`.
 *  - HTTP API على المنفذ 3004 — تستقبل الإشعارات من خادم Next.js
 *    (`POST /emit`, `POST /broadcast`, `POST /emit-admin`) بمصادقة
 *    `X-Internal-Secret` المطابقة لـ INTERNAL_API_SECRET.
 *  - Redis Pub/Sub لتوزيع الأحداث عبر عدة نسخ من الخدمة (horizontal scale):
 *    النسخة التي تستقبل /emit تنشر على قناة `notif:ws:user:{userId}` وكل
 *    نسخة مشتركة تُعيد بثّها للمقبس المتصل لديها.
 *  - المصادقة: يتصل المتصفح بـ `auth: { token }` حيث token = ws-token (JWT)
 *    يُوقَّع بـ JWT_SECRET بنفس الطريقة المستخدمة في `src/lib/auth.ts`.
 *
 * الاتصال بالبيئة:
 *   JWT_SECRET              — مطلوب (نفس مفتاح التطبيق للتحقق من ws-token)
 *   INTERNAL_API_SECRET     — مطلوب (مصادقة /emit من خادم Next.js)
 *   REDIS_URL               — اختياري (Pub/Sub؛ بدونها تعمل نسخة واحدة محلياً)
 *   NOTIFICATION_WS_PORT    — منفذ Socket.io (الافتراضي 3003)
 *   NOTIFICATION_API_PORT   — منفذ HTTP API (الافتراضي 3004)
 *   CORS_ORIGIN             — أصل مسموح للمتصفح (الافتراضي * في التطوير)
 * ═══════════════════════════════════════════════════════════════════════════════
 */

import { createServer } from 'http'
import { Server, Socket } from 'socket.io'
import Redis from 'ioredis'
import { jwtVerify } from 'jose'

// ═══════════════════════════════════════════════════════════════════════════════
// البيئة (Environment)
// ═══════════════════════════════════════════════════════════════════════════════

const WS_PORT = parseInt(process.env.NOTIFICATION_WS_PORT || '3003', 10)
const API_PORT = parseInt(process.env.NOTIFICATION_API_PORT || '3004', 10)
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*'
const INTERNAL_API_SECRET = process.env.INTERNAL_API_SECRET || ''
const REDIS_URL = process.env.REDIS_URL || ''
const JWT_SECRET = process.env.JWT_SECRET || ''

function getJwtKey(): Uint8Array {
  if (!JWT_SECRET || JWT_SECRET.length < 32) {
    console.warn('[WS] ⚠️ JWT_SECRET not set or too short — using development fallback. DO NOT use in production.')
    return new TextEncoder().encode('maydan-dev-only-secret-do-not-use-in-production-32ch')
  }
  return new TextEncoder().encode(JWT_SECRET)
}

// ═══════════════════════════════════════════════════════════════════════════════
// Redis Pub/Sub (اختياري — للتوسع الأفقي)
// ═══════════════════════════════════════════════════════════════════════════════

let publisher: Redis | null = null
let subscriber: Redis | null = null

const CHANNEL_USER = (userId: string) => `notif:ws:user:${userId}`
const CHANNEL_BROADCAST = 'notif:ws:broadcast'
const CHANNEL_ADMIN = 'notif:ws:admin'

async function initRedis(): Promise<void> {
  if (!REDIS_URL) return
  try {
    publisher = new Redis(REDIS_URL, { lazyConnect: true, maxRetriesPerRequest: 3 })
    subscriber = new Redis(REDIS_URL, { lazyConnect: true, maxRetriesPerRequest: 3 })
    await Promise.all([publisher.connect(), subscriber.connect()])

    // أي حدث يصله عبر Redis نعيد بثّه للمقابس المتصلة محلياً
    subscriber.on('pmessage', (_pattern: string, channel: string, message: string) => {
      try {
        const data = JSON.parse(message)
        if (channel === CHANNEL_BROADCAST) {
          io.emit(data.event, data.payload)
        } else if (channel === CHANNEL_ADMIN) {
          io.to(ADMIN_ROOM).emit(data.event, data.payload)
        } else if (channel.startsWith('notif:ws:user:')) {
          const userId = channel.slice('notif:ws:user:'.length)
          io.to(USER_ROOM(userId)).emit(data.event, data.payload)
        }
      } catch (error) {
        console.error('[WS] Redis message parse error:', error)
      }
    })

    await subscriber.psubscribe(`${CHANNEL_BROADCAST}`, `${CHANNEL_ADMIN}`, `notif:ws:user:*`)
    console.log('[WS] Redis Pub/Sub connected — multi-instance mode enabled')
  } catch (error) {
    console.warn('[WS] Redis unavailable — running in single-instance mode:', error instanceof Error ? error.message : error)
    publisher = null
    subscriber = null
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Socket.io — WebSocket للمتصفح
// ═══════════════════════════════════════════════════════════════════════════════

const httpWs = createServer()
const io = new Server(httpWs, {
  path: '/socket.io',
  cors: {
    origin: CORS_ORIGIN,
    methods: ['GET', 'POST'],
    credentials: true,
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

const USER_ROOM = (userId: string) => `user:${userId}`
const ADMIN_ROOM = 'admins'

/**
 * تحقق من ws-token (JWT موقّع بـ JWT_SECRET) ونطابق payload في src/lib/auth.ts
 */
async function verifyWsToken(token: string): Promise<{ userId: string; email?: string; role?: string } | null> {
  try {
    const { payload } = await jwtVerify(token, getJwtKey(), {
      algorithms: ['HS256'],
      issuer: 'midan-al-iqtisad',
      audience: 'midan-users',
    })
    const userId = (payload.userId || payload.sub) as string | undefined
    if (!userId) return null
    return {
      userId,
      email: payload.email as string | undefined,
      role: payload.role as string | undefined,
    }
  } catch {
    return null
  }
}

io.use(async (socket: Socket, next) => {
  try {
    const token =
      (socket.handshake.auth?.token as string) ||
      (socket.handshake.query?.token as string) ||
      ''
    if (!token) {
      return next(new Error('unauthorized: missing ws-token'))
    }
    const user = await verifyWsToken(token)
    if (!user) {
      return next(new Error('unauthorized: invalid or expired ws-token'))
    }
    socket.data.user = user
    next()
  } catch (error) {
    next(error instanceof Error ? error : new Error('unauthorized'))
  }
})

io.on('connection', (socket: Socket) => {
  const user = socket.data.user as { userId: string; role?: string }
  console.log(`[WS] User connected: ${user.userId} (socket ${socket.id})`)

  socket.join(USER_ROOM(user.userId))
  if (user.role === 'admin' || user.role === 'superadmin' || user.role === 'owner') {
    socket.join(ADMIN_ROOM)
  }

  socket.on('subscribe', (channels: string[]) => {
    if (Array.isArray(channels)) {
      channels.forEach((c) => socket.join(String(c)))
    }
  })

  socket.on('unsubscribe', (channels: string[]) => {
    if (Array.isArray(channels)) {
      channels.forEach((c) => socket.leave(String(c)))
    }
  })

  socket.on('error', (error: Error) => {
    console.error(`[WS] Socket error (${socket.id}):`, error.message)
  })

  socket.on('disconnect', () => {
    console.log(`[WS] User disconnected: ${user.userId} (socket ${socket.id})`)
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// HTTP API — يستقبل الإشعارات من خادم Next.js
// ═══════════════════════════════════════════════════════════════════════════════

const httpApi = createServer(async (req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', CORS_ORIGIN)
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Internal-Secret')
  res.setHeader('Content-Type', 'application/json')

  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    return res.end()
  }

  const url = (req.url || '').split('?')[0]

  // Health check (يُستخدم في docker-compose healthcheck)
  if (req.method === 'GET' && url === '/health') {
    res.writeHead(200)
    return res.end(JSON.stringify({ status: 'ok', wsPort: WS_PORT, apiPort: API_PORT }))
  }

  // جميع نقاط البث تتطلب مصادقة X-Internal-Secret
  if (!INTERNAL_API_SECRET) {
    res.writeHead(500)
    return res.end(JSON.stringify({ success: false, error: 'INTERNAL_API_SECRET not configured' }))
  }

  const secret = req.headers['x-internal-secret'] as string | undefined
  if (!secret || secret !== INTERNAL_API_SECRET) {
    res.writeHead(401)
    return res.end(JSON.stringify({ success: false, error: 'unauthorized' }))
  }

  if (req.method !== 'POST') {
    res.writeHead(405)
    return res.end(JSON.stringify({ success: false, error: 'method_not_allowed' }))
  }

  // قراءة الـ body
  const chunks: Buffer[] = []
  req.on('data', (chunk: Buffer) => chunks.push(chunk))
  req.on('end', async () => {
    try {
      const raw = Buffer.concat(chunks).toString('utf8')
      const body = raw ? JSON.parse(raw) : {}

      const { event, payload } = body as { event?: string; payload?: unknown }
      if (!event) {
        res.writeHead(400)
        return res.end(JSON.stringify({ success: false, error: 'event is required' }))
      }

      const serialized = JSON.stringify({ event, payload: payload ?? null })

      if (url === '/emit') {
        const { userId } = body as { userId?: string }
        if (!userId) {
          res.writeHead(400)
          return res.end(JSON.stringify({ success: false, error: 'userId is required' }))
        }
        // بث محلي
        io.to(USER_ROOM(userId)).emit(event, payload ?? null)
        // نشر للنسخ الأخرى
        if (publisher) {
          await publisher.publish(CHANNEL_USER(userId), serialized).catch(() => {})
        }
        console.log(`[WS] /emit → user:${userId} (${event})`)
        res.writeHead(200)
        return res.end(JSON.stringify({ success: true }))
      }

      if (url === '/broadcast') {
        io.emit(event, payload ?? null)
        if (publisher) {
          await publisher.publish(CHANNEL_BROADCAST, serialized).catch(() => {})
        }
        console.log(`[WS] /broadcast → all (${event})`)
        res.writeHead(200)
        return res.end(JSON.stringify({ success: true }))
      }

      if (url === '/emit-admin') {
        io.to(ADMIN_ROOM).emit(event, payload ?? null)
        if (publisher) {
          await publisher.publish(CHANNEL_ADMIN, serialized).catch(() => {})
        }
        console.log(`[WS] /emit-admin → admins (${event})`)
        res.writeHead(200)
        return res.end(JSON.stringify({ success: true }))
      }

      res.writeHead(404)
      return res.end(JSON.stringify({ success: false, error: 'not_found' }))
    } catch (error) {
      console.error('[WS] API error:', error)
      res.writeHead(500)
      res.end(JSON.stringify({ success: false, error: 'internal_error' }))
    }
  })
})

// ═══════════════════════════════════════════════════════════════════════════════
// الإقلاع وإيقاف التشغيل الآمن
// ═══════════════════════════════════════════════════════════════════════════════

async function start(): Promise<void> {
  await initRedis()
  httpWs.listen(WS_PORT, () => {
    console.log(`[WS] WebSocket server listening on port ${WS_PORT}`)
  })
  httpApi.listen(API_PORT, () => {
    console.log(`[WS] HTTP API listening on port ${API_PORT} (/emit, /broadcast, /emit-admin, /health)`)
  })
}

start().catch((error) => {
  console.error('[WS] Failed to start notification service:', error)
  process.exit(1)
})

function shutdown(signal: string): void {
  console.log(`[WS] Received ${signal}, shutting down...`)
  io.close(() => {
    httpWs.close()
    httpApi.close()
    if (subscriber) subscriber.disconnect()
    if (publisher) publisher.disconnect()
    process.exit(0)
  })
  // مهلة أمان للإغلاق القسري
  setTimeout(() => process.exit(0), 5000).unref()
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
