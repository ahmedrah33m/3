#!/usr/bin/env python3
"""
midan-fix-seed.py — Robust one-shot patch for the Midan seed.ts FK violation.

What this script does:
  1. Locates prisma/seed.ts (from CWD or first arg)
  2. Backs it up to prisma/seed.ts.bak.<timestamp>
  3. Replaces the broken deleteMany block with TRUNCATE ... CASCADE
     (PostgreSQL) + an FK-safe ordered deleteMany fallback (SQLite)
  4. Creates scripts/diagnose-articles.ts (so the diagnostic command works)
  5. Prints next-step instructions

Usage:
  python3 midan-fix-seed.py            # patches ./prisma/seed.ts
  python3 midan-fix-seed.py /path      # patches /path/prisma/seed.ts

After running this script:
  npm run db:seed                      # re-seed (will now succeed)
  npx tsx scripts/diagnose-articles.ts # verify
  npm run dev                          # restart server
"""

import os
import re
import sys
import shutil
from datetime import datetime
from pathlib import Path

# ─── Config ─────────────────────────────────────────────────────────────────
START_MARKER = "  // Clear existing data"
END_MARKER = "  await prisma.user.deleteMany()"

REPLACEMENT = '''  // ─────────────────────────────────────────────────────────────
  // Reset database — robust, idempotent, FK-order-independent
  // ─────────────────────────────────────────────────────────────
  // The previous implementation called prisma.user.deleteMany() after a handful
  // of sibling deleteMany() calls, but the schema has ~250 models — many of
  // them (AuditLog, Notification, Message, Connection, Follow, Post,
  // PromotionCampaign, …) reference User WITHOUT onDelete: Cascade. Trying to
  // delete User while those tables still hold rows triggers:
  //   Foreign key constraint violated on the constraint: AuditLog_adminId_fkey
  // and aborts the seed halfway — leaving the DB in a broken state where the
  // User table retains stale rows (with stale articlesCount) while the Article
  // table is already empty. That is exactly the bug pattern users see when
  // the profile sidebar shows "N مقالات" but the Articles tab is empty.
  //
  // Fix: use PostgreSQL TRUNCATE … CASCADE to wipe ALL public tables in a
  // single statement. This (a) bypasses FK ordering entirely, (b) is much
  // faster than per-table deleteMany on large datasets, (c) is idempotent.
  // For SQLite (dev fallback) we keep the explicit ordered deleteMany list,
  // extended with the previously-missing AuditLog/Notification/Message/etc.
  // ─────────────────────────────────────────────────────────────

  const isPostgres = (process.env.DATABASE_URL || '').startsWith('postgres')

  if (isPostgres) {
    console.log('🧹 PostgreSQL detected — TRUNCATE all tables (CASCADE)...')
    const tables = await prisma.$queryRawUnsafe<{ tablename: string }[]>(`
      SELECT tablename
      FROM pg_tables
      WHERE schemaname = 'public'
        AND tablename <> '_prisma_migrations'
      ORDER BY tablename;
    `)
    await prisma.$executeRawUnsafe('SET session_replication_role = replica;')
    try {
      const tableNames = tables.map((t) => `"${t.tablename}"`).join(', ')
      if (tableNames) {
        await prisma.$executeRawUnsafe(`TRUNCATE TABLE ${tableNames} CASCADE;`)
      }
      console.log(`  ✓ Truncated ${tables.length} tables`)
    } finally {
      await prisma.$executeRawUnsafe('SET session_replication_role = origin;')
    }
  } else {
    console.log('🧹 SQLite detected — ordered deleteMany (FK-safe order)...')
    await prisma.auditLog.deleteMany()
    await prisma.notification.deleteMany()
    await prisma.message.deleteMany()
    await prisma.conversationParticipant.deleteMany()
    await prisma.conversation.deleteMany()
    await prisma.connection.deleteMany()
    await prisma.follow.deleteMany()
    await prisma.userActivityLog.deleteMany()
    await prisma.userActivity.deleteMany()
    await prisma.passwordResetCode.deleteMany()
    await prisma.userSession.deleteMany()
    await prisma.systemError.deleteMany()
    await prisma.errorReport.deleteMany()
    await prisma.securityEvent.deleteMany()
    await prisma.apiKeyRecord.deleteMany()
    await prisma.accountDeletionRequest.deleteMany()
    await prisma.passwordChangeLog.deleteMany()
    await prisma.profileView.deleteMany()
    await prisma.profileViewLog.deleteMany()
    await prisma.readingListItem.deleteMany()
    await prisma.readingList.deleteMany()
    await prisma.post.deleteMany()
    await prisma.repost.deleteMany()
    await prisma.promotionCampaign.deleteMany()
    await prisma.ad.deleteMany()
    await prisma.advertiserAccount.deleteMany()
    await prisma.payment.deleteMany()
    await prisma.invoice.deleteMany()
    await prisma.walletTransaction.deleteMany()
    await prisma.wallet.deleteMany()
    await prisma.subscription.deleteMany()
    await prisma.commission.deleteMany()
    await prisma.referral.deleteMany()
    await prisma.pushSubscription.deleteMany()
    await prisma.quizAnswer.deleteMany()
    await prisma.quizOptionRecord.deleteMany()
    await prisma.quizAttempt.deleteMany()
    await prisma.quizQuestion.deleteMany()
    await prisma.quiz.deleteMany()
    await prisma.userLessonProgress.deleteMany()
    await prisma.lesson.deleteMany()
    await prisma.learningPath.deleteMany()
    await prisma.articleTag.deleteMany()
    await prisma.hashtag.deleteMany()
    await prisma.economicTerm.deleteMany()
    await prisma.like.deleteMany()
    await prisma.discussionReply.deleteMany()
    await prisma.discussionMedia.deleteMany()
    await prisma.discussion.deleteMany()
    await prisma.comment.deleteMany()
    await prisma.articleMedia.deleteMany()
    await prisma.article.deleteMany()
    await prisma.job.deleteMany()
    await prisma.siteSettings.deleteMany()
    await prisma.pricingConfig.deleteMany()
    await prisma.paymentDestination.deleteMany()
    await prisma.user.deleteMany()
    console.log('  ✓ Cleared all tables in FK-safe order')
  }'''

DIAGNOSE_TS = '''/**
 * diagnose-articles.ts
 *
 * Diagnostic — answers: "Why does profile show 'N مقالات' but Articles tab is empty?"
 *
 * Run:  npx tsx scripts/diagnose-articles.ts
 */
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('\\n🔬 Midan — articles diagnostic\\n')

  const [userCount, articleCount, publishedCount] = await Promise.all([
    prisma.user.count(),
    prisma.article.count(),
    prisma.article.count({ where: { status: 'PUBLISHED', deletedAt: null } }),
  ])
  console.log(`Users:                    ${userCount}`)
  console.log(`Articles (total):         ${articleCount}`)
  console.log(`Articles (PUBLISHED):     ${publishedCount}`)

  if (publishedCount === 0) {
    console.log('\\n⚠️  No PUBLISHED articles in the database.')
    console.log('   This is why every profile shows "لا توجد مقالات".')
  }

  console.log('\\n─ Per-user articlesCount vs actual PUBLISHED count ─')
  const users = await prisma.user.findMany({
    select: {
      id: true,
      name: true,
      articlesCount: true,
      articles: {
        where: { status: 'PUBLISHED', deletedAt: null },
        select: { id: true, title: true, publishedAt: true, createdAt: true },
      },
    },
    take: 50,
  })

  let driftCount = 0
  for (const u of users) {
    const actual = u.articles.length
    const cached = u.articlesCount || 0
    if (actual !== cached) {
      driftCount++
      console.log(`  ✗ ${u.id.padEnd(20)} | cached=${cached}  actual=${actual}  ← DRIFT`)
    } else if (cached > 0) {
      console.log(`  ✓ ${u.id.padEnd(20)} | cached=${cached}  actual=${actual}`)
      for (const a of u.articles) {
        console.log(`      • ${a.title.slice(0, 60)}  (publishedAt=${a.publishedAt?.toISOString() || 'null'})`)
      }
    }
  }

  if (driftCount > 0) {
    console.log(`\\n❌ ${driftCount} user(s) have stale articlesCount.`)
    console.log('   Fix: re-run `npm run db:seed` (now using TRUNCATE CASCADE).')
  } else if (publishedCount > 0) {
    console.log('\\n✅ All counters are in sync.')
  } else {
    console.log('\\n✓ Counters are in sync (but DB is empty — run the seed).')
  }

  console.log('')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })
'''


def main():
    # ─── Locate project root ────────────────────────────────────────────────
    if len(sys.argv) > 1:
        project_root = Path(sys.argv[1]).resolve()
    else:
        project_root = Path.cwd()

    seed_path = project_root / "prisma" / "seed.ts"
    if not seed_path.exists():
        print(f"✗ لم يتم العثور على {seed_path}")
        print("  نفّذ هذا السكربت من جذر المشروع (حيث يوجد package.json).")
        sys.exit(1)

    print("═══════════════════════════════════════════")
    print("  ميدان — إصلاح عطل seed + Articles")
    print("═══════════════════════════════════════════\n")

    # ─── 1. Read seed.ts ────────────────────────────────────────────────────
    src = seed_path.read_text(encoding="utf-8")
    print(f"✓ قراءة {seed_path}")

    # ─── 2. Check if already patched ────────────────────────────────────────
    if "TRUNCATE TABLE" in src and "session_replication_role" in src:
        print("⚠️  seed.ts يبدو أنه مُعَدَّل مسبقاً (يحتوي TRUNCATE TABLE) — تخطي التعديل")
    else:
        # ─── 3. Backup ────────────────────────────────────────────────────
        backup = seed_path.with_suffix(
            f".ts.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        shutil.copy2(seed_path, backup)
        print(f"✓ نسخة احتياطية: {backup}")

        # ─── 4. Find markers ─────────────────────────────────────────────
        start_idx = src.find(START_MARKER)
        if start_idx == -1:
            print(f"✗ لم يتم العثور على بداية الكتلة: {START_MARKER!r}")
            print("  ربما تم تعديل seed.ts بطريقة مختلفة. طبّق التعديل يدوياً.")
            sys.exit(1)

        end_idx = src.find(END_MARKER, start_idx)
        if end_idx == -1:
            print(f"✗ لم يتم العثور على نهاية الكتلة: {END_MARKER!r}")
            sys.exit(1)
        end_idx_after = end_idx + len(END_MARKER)

        # ─── 5. Apply replacement ────────────────────────────────────────
        new_src = src[:start_idx] + REPLACEMENT + src[end_idx_after:]
        seed_path.write_text(new_src, encoding="utf-8")
        print("✓ تم تعديل seed.ts (deleteMany → TRUNCATE CASCADE)")

    # ─── 6. Create scripts/diagnose-articles.ts ───────────────────────────
    scripts_dir = project_root / "scripts"
    scripts_dir.mkdir(exist_ok=True)
    diag_path = scripts_dir / "diagnose-articles.ts"
    diag_path.write_text(DIAGNOSE_TS, encoding="utf-8")
    print(f"✓ تم إنشاء {diag_path}")

    # ─── 7. Next steps ────────────────────────────────────────────────────
    print("\n═══════════════════════════════════════════")
    print("  ✓ اكتمل التعديل — الخطوات التالية:")
    print("═══════════════════════════════════════════\n")
    print("  1. أعد تشغيل seed (سيتم مسح كل البيانات وإعادة إنشائها):")
    print("       npm run db:seed\n")
    print("  2. شغّل التشخيص للتأكد:")
    print("       npx tsx scripts/diagnose-articles.ts\n")
    print("  3. أعد تشغيل الخادم:")
    print("       npm run dev\n")
    print("  4. افتح المتصفح: http://localhost:3300/profile/user_owner")
    print("     يجب أن ترى مقالات فعلية في تبويب 'المقالات'\n")


if __name__ == "__main__":
    main()
