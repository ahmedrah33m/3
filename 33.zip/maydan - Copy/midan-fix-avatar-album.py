#!/usr/bin/env python3
"""
midan-fix-avatar-album.py — Apply the "profile image album" feature.

What this script does:
  1. Locates the project root (from CWD or first arg)
  2. Backs up target files before overwriting
  3. Copies the new files:
       - schema-additions-profile-image.prisma → user appends to schema.prisma
       - src/app/api/users/[id]/profile-images/route.ts (NEW)
       - src/app/api/upload/route.ts (PATCHED — records to album)
       - src/components/profile/ProfileImageGallery.tsx (NEW)
       - src/components/profile/ProfileHeader.tsx (PATCHED — adds album button)
       - src/components/profile/ProfileView.tsx (PATCHED — wires onImageApplied)
  4. Reminds user to:
       - Append the ProfileImage model to prisma/schema.prisma
       - Add the relation to the User model
       - Run `npx prisma db push && npx prisma generate`
       - Restart `npm run dev`

Usage:
  python3 midan-fix-avatar-album.py            # patches ./ (CWD)
  python3 midan-fix-avatar-album.py /path      # patches /path
"""

import os
import sys
import shutil
from datetime import datetime
from pathlib import Path

# Files to copy: (source_relative_to_fix_dir, target_relative_to_project_root, is_new)
FILES = [
    # New: ProfileImage Prisma model documentation (user appends manually)
    (
        "schema-additions-profile-image.prisma",
        "prisma/schema-additions-profile-image.prisma",
        True,
    ),
    # New: API route for the album
    (
        "src/app/api/users/[id]/profile-images/route.ts",
        "src/app/api/users/[id]/profile-images/route.ts",
        True,
    ),
    # Patched: upload route now records avatar/cover to album automatically
    (
        "src/app/api/upload/route.ts",
        "src/app/api/upload/route.ts",
        False,
    ),
    # New: gallery component
    (
        "src/components/profile/ProfileImageGallery.tsx",
        "src/components/profile/ProfileImageGallery.tsx",
        True,
    ),
    # Patched: adds album button + onImageApplied prop
    (
        "src/components/profile/ProfileHeader.tsx",
        "src/components/profile/ProfileHeader.tsx",
        False,
    ),
    # Patched: wires onImageApplied callback
    (
        "src/components/profile/ProfileView.tsx",
        "src/components/profile/ProfileView.tsx",
        False,
    ),
]


def main():
    # ─── Locate project root ────────────────────────────────────────────────
    if len(sys.argv) > 1:
        project_root = Path(sys.argv[1]).resolve()
    else:
        project_root = Path.cwd()

    fix_dir = Path(__file__).resolve().parent

    print("═══════════════════════════════════════════════════════")
    print("  ميدان — إضافة ألبوم صور البروفايل")
    print("═══════════════════════════════════════════════════════\n")

    # Verify project root has the expected structure
    if not (project_root / "package.json").exists():
        print(f"✗ لم يتم العثور على package.json في {project_root}")
        print("  نفّذ هذا السكربت من جذر المشروع.")
        sys.exit(1)

    if not (project_root / "prisma" / "schema.prisma").exists():
        print(f"✗ لم يتم العثور على prisma/schema.prisma في {project_root}")
        sys.exit(1)

    print(f"✓ جذر المشروع: {project_root}")
    print(f"✓ مصدر الإصلاحات: {fix_dir}\n")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backups_made = []
    files_copied = []

    for src_rel, dst_rel, is_new in FILES:
        src = fix_dir / src_rel
        dst = project_root / dst_rel

        if not src.exists():
            print(f"✗ مفقود في الحزمة: {src_rel}")
            sys.exit(1)

        # Create parent directories
        dst.parent.mkdir(parents=True, exist_ok=True)

        # Backup if target exists (and isn't already a backup)
        if dst.exists() and not dst_rel.endswith(".bak"):
            backup = dst.with_suffix(
                dst.suffix + f".bak.{timestamp}"
            )
            shutil.copy2(dst, backup)
            backups_made.append(str(backup))

        # Copy
        shutil.copy2(src, dst)
        files_copied.append(dst_rel)
        action = "جديد" if is_new else "مُحدَّث"
        print(f"  ✓ [{action}] {dst_rel}")

    # ─── Schema check ───────────────────────────────────────────────────────
    schema_path = project_root / "prisma" / "schema.prisma"
    schema_src = schema_path.read_text(encoding="utf-8")

    print("\n─ التحقق من Prisma schema ─")
    has_model = "model ProfileImage" in schema_src
    has_relation = "profileImages ProfileImage[]" in schema_src

    if has_model and has_relation:
        print("  ✓ model ProfileImage موجود + العلاقة موجودة في User")
    else:
        if not has_model:
            print("  ⚠️  model ProfileImage غير موجود في schema.prisma")
            print("     يجب إضافته يدوياً من ملف:")
            print(f"       prisma/schema-additions-profile-image.prisma")
        if not has_relation:
            print("  ⚠️  علاقة profileImages غير موجودة في model User")
            print("     أضف هذا السطر داخل model User:")
            print("       profileImages ProfileImage[] @relation(\"ProfileImageOwner\")")

        print("\n  بعد إضافة النموذج والعلاقة، شغّل:")
        print("    npx prisma db push")
        print("    npx prisma generate")

    # ─── Summary ────────────────────────────────────────────────────────────
    print(f"\n═══════════════════════════════════════════════════════")
    print(f"  ✓ اكتمل التطبيق")
    print(f"═══════════════════════════════════════════════════════\n")
    print(f"  النسخ الاحتياطية: {len(backups_made)} ملف")
    for b in backups_made:
        print(f"    • {b}")
    print(f"\n  الملفات المنسوخة: {len(files_copied)} ملف\n")

    print("─ الخطوات التالية ─")
    if not (has_model and has_relation):
        print("  1) أضف model ProfileImage إلى prisma/schema.prisma")
        print("     (راجع prisma/schema-additions-profile-image.prisma للنموذج الكامل)")
        print("  2) أضف العلاقة داخل model User:")
        print("       profileImages ProfileImage[] @relation(\"ProfileImageOwner\")")
        print("  3) شغّل:")
        print("       npx prisma db push")
        print("       npx prisma generate")
        print("  4) أعد تشغيل الخادم:")
        print("       npm run dev")
    else:
        print("  1) أعد تشغيل الخادم:")
        print("       npm run dev")

    print("\n  5) افتح: http://localhost:3300/profile/user_owner")
    print("  6) جرّب الميزة:")
    print("     - ارفع صورة بروفايل جديدة")
    print("     - ارفع صورة ثانية وثالثة")
    print("     - اضغط زر 'الألبوم' أسفل الصورة الدائرية")
    print("     - سترى كل الصور السابقة مع possibility اختيار أي منها")
    print("     - الصورة الحالية محددة بعلامة ✓ زرقاء")
    print("     - يمكن حذف صورة قديمة (ما عدا الحالية) بـ أيقونة 🗑")


if __name__ == "__main__":
    main()
