# SYSTEM_ARCHITECTURE.md
## Phase 3 — Pages & Components + Architecture | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28
**المصدر:** قراءة فعلية للكود: `src/app/layout.tsx`, `src/app/(main)/layout.tsx`, `src/components/**`, `src/lib/**`, `ARCHITECTURE.md`, `next.config.ts`.

---

## 1) معمارية التطبيق عالية المستوى

```
┌─────────────────────────────────────────────────────────────────┐
│  CLIENT (Next.js 16 SPA/RSC)  —  src/app, src/components        │
│   • layout.tsx (جذر): ThemeProvider, I18nProvider, Providers,   │
│     NavigationProvider, Toaster, NotificationToaster,           │
│     PWAInstallPrompt, CsrfBootstrap, ErrorReporter, SWRegister   │
│   • (main)/layout.tsx: AuthGate + 3-column shell (NavbarServer,  │
│     Sidebar, LeftPanel, Footer, MobileTopBar/MobileBottomNav)    │
│   • (main)/error.tsx, loading.tsx, not-found.tsx                │
├─────────────────────────────────────────────────────────────────┤
│  EDGE — src/middleware.ts + lib/edge-auth.ts                    │
│   upload rewrite, CSRF, rate-limit, auth guard, blacklist,      │
│   anti-scraping, geo-access                                     │
├─────────────────────────────────────────────────────────────────┤
│  API LAYER — src/app/api/** (428 route.ts)                      │
│   Auth → Permission → Validation → Service → DB                 │
├─────────────────────────────────────────────────────────────────┤
│  SERVICE LAYER — src/services/** (22) + src/lib/wallet,payment, │
│   notification, chat, reputation, achievements, audit           │
├─────────────────────────────────────────────────────────────────┤
│  DATA — Prisma (260 model) على PostgreSQL / PgBouncer           │
│   + Redis (cache, queues BullMQ, realtime)                      │
│   + MinIO/S3 (تخزين الصور) + public/uploads (المسارات /uploads) │
└─────────────────────────────────────────────────────────────────┘
```

## 2) طبقة العرض (Layout & Shell)

### Root Layout `src/app/layout.tsx`
- محرّكات: `ThemeProvider`, `I18nProvider` (ترجمة client-side عبر localStorage `midan-locale`), `Providers`, `NavigationProvider`
- عناصر عامة: `Toaster`, `NotificationToaster`, `PWAInstallPrompt`, `CsrfBootstrap`, `ErrorReporter`, `ServiceWorkerRegister`
- RTL/LTR مضبوط عبر سكربت منع FOUC في `<head>`
- Metadata/أدلة منظمة (OpenGraph, Schema.org, Manifest, iOS)

### Main Layout `src/app/(main)/layout.tsx`
- **AuthGate** يغلّف كل صفحات `(main)` — التحقق من المصادقة على مستوى الصفحات الموثّقة
- هيكل 3 أعمدة: `NavbarServer` (desktop) + `Sidebar` + `LeftPanel` + `Footer` + `MobileTopBar`/`MobileBottomNav`
- `error.tsx` / `loading.tsx` / `not-found.tsx` على مستوى المجموعة

## 3) مكونات الواجهة (Components) — 256 ملف

### تقسيم عبر 15 دليلاً (top-level)
| الدليل | عدد الملفات | الوظيفة |
|---|---|---|
| `ui/` | 32 | نظام تصميم Radix/shadcn |
| `landing/` | 18 | صفحات الهبوط/العامة |
| `admin/` | 24 | لوحة الإدارة |
| `marketplace/` | 16 | السوق |
| `owner/` | 14 | لوحة المالك |
| `profile/` | 13 | ملفات المستخدم |
| `jobs/` | 5 | الوظائف |
| `home/` | 4 | الرئيسية |
| `education/` | 4 | التعلم |
| `map/` | 3 | الخرائط |
| `chat/` | 2 | المحادثة |
| `ui-v2/` | 1 | نظام تصميم v2 |
| `wallet/` | 1 | المحفظة |
| `company/` | 1 | الشركات |
| + 132 ملفاً في الجذر | | مكونات feature مباشرة |

### مكونات جذر بارزة (feature views)
`DashboardView, HomeView, LandingPage, ArticleDetail, DiscussionDetail, QuestionDetail, CommentsSection, CVBuilder, JobCardV2, JobsListV2, ExpertsView, ExpertMarketplaceView, ConsultationsMarketplace, ConsultationSession, MarketplaceViews, ChatRooms, MessagesView, NotificationsView, Wallet, PollsView, Leaderboard, AchievementsView, ResearchView, EventsView, AdminPanel, OwnerPanel, CompanyDashboard, ConsultantDashboard, InstructorDashboard, MidanAcademyView, EconomicIndicatorsView, InteractiveChartsView, WorldEconomicMap, IraqTalentMap, InvestmentBankView, AIAssistantView, AIWritingAssistant, AISummarizer, CreatePostView, WriteArticleView, ProfileView, OnboardingFlow, AuthModals, RoleGate, AuthGate, ReputationBadge, PromoteButton, RepostButton, PremiumBadge, PaymentDestinationDisplay, TwoFactorSetup/Verify`

## 4) المكتبات الأساسية (`src/lib`) — 184 ملف

### أدوات متخصصة بطوابق أمن وبنية:
- **الوصول للبيانات:** `db.ts`, `db-replica.ts`, `redis.ts`, `cache.ts`, `cache-service.ts`, `cache-helpers.ts`, `caching-layer.ts`
- **المصادقة/الحساب:** `auth.ts`, `session.ts`, `edge-auth.ts`, `csrf.ts`, `two-factor.ts`, `env.ts`, `token-blacklist-edge.ts`
- **الأمان (`lib/security/` 39 ملف):** `permission-engine.ts`, `audit-trail.ts`, `audit-enhanced.ts`, `account-lockout.ts`, `brute-force-guard.ts`, `data-leak-prevention.ts`, `data-masking.ts`, `encryption-at-rest.ts`, `file-scanner.ts`, `geo-access-control.ts`, `input-validation.ts`, `rate-limit.ts`/`tiered-rate-limit.ts`, `session-hardening.ts`, `webauthn.ts`, `zero-trust.ts`, `anti-scraping.ts`, `bot-detection.ts`, `api-firewall.ts`, إلخ.
- **المال/الدفع:** `wallet-service.ts`, `payment-service.ts`, `payment-gateway.ts`, `lib/payment/gateway.ts`
- **الأحداث/التدقيق/التحليلات:** `audit.ts`, `activity-logger.ts`, `analytics-server.ts`, `reputation.ts`, `achievements.ts`
- **الإشعارات/المراسلة:** `notification.service.ts` (في services)، `email.ts`, `email-notifications.ts`, `telegram.ts`, `whatsapp.ts`, `sms.ts`, `realtime.ts`, `chat-service.ts`
- **المحتوى/المحرك:** `article-helpers.ts`, `moderation.ts`, `moderation-ai.ts`, `tags.ts`, `search-engine.ts`, `recommendations.ts`
- **الاقتصاد:** `exchange-rates.ts`, `live-indicators.ts`, `market-prices.ts`, `iraq-map-data.ts`, `geo.ts`, `location-service.ts`
- **التخزين:** `storage.ts` (S3/MinIO + local)، `image-*`, `file-scanner`
- **تكوين/تنقل:** `navigation-config.ts`, `navigation.ts`, `nav-translations.ts`, `store.ts`, `query-client.ts`, `state (zustand)`

## 5) الـ Hooks (11)
`useWalletBalance, useChatSSE, useConsultantDirectory, useContentTranslation, useCsrf, use-mobile, useNotificationsSSE, useReadingStreak, useRealtimeSocket, useRealtimeUnreadCount, use-toast`

## 6) طبقة الخدمات (`src/services`) — 22
`job, job-application, company, community, article, comment, discussion, search, notification, message, payment, wallet(counter), talent-pool, cv-bank, interview, offer, advertisement, analytics, consultant-marketplace, report, moderation-ai, phone-verification`

## 7) تدفق البيانات (مثال موثّق من الكود الفعلي)

### مثال: المدفوعات الموحّدة والربط الحالي (من README.md + الكود)
```
OwnerPanel Pricing → PUT /api/owner/pricing
   → جدول ServicePrice (مصدر الحقيقة)
   → getServicePrice('KEY')  (في src/lib/wallet-service.ts)
   → المستهلكون: /api/cv-builder, /api/users/[id]/resume,
     /api/cv-service, /api/articles/promote, /api/mentorship/request,
     /api/subscriptions, /api/jobs (عبر job.service)
   → payFromWallet({...}) → Wallet (خصم) + Invoice + حصة الخبير
   → عرض الأسعار: GET /api/pricing → صفحة /wallet (PaidServicesCard)
```
**الملاحظة:** هذا الربط تم في تعديل سابق (11 ملف) — سيُلحق بمرحلة Wallet/Payments التحقق الشامل.

## 8) طبقات الأمان (4-5 طبقات)

| الطبقة | الملفات |
|---|---|
| Edge | `src/middleware.ts` + `lib/edge-auth.ts` + `lib/security/anti-scraping`, `geo-access-control`, `client-ip` |
| API | `lib/auth.ts`, `lib/csrf.ts`, `lib/rate-limit.ts`, `lib/api-response.ts`, `lib/api-utils.ts`, `lib/validation.ts` |
| Permission | `lib/security/permission-engine.ts`, `lib/permission-engine-enhanced.ts` |
| Service | كل service + `lib/audit.ts` |
| Data/Security modules | `lib/security/**` (39 ملف) |

## 9) الوضع الحالي (مقترن بالتحقق المباشر)

- التطبيق يعمل على `http://192.168.88.45:3300` (Docker، standalone).
- `/api/health` → HTTP 200، قاعدة بيانات 45 مستخدماً، Redis يعمل.
- الصور في MinIO bucket `maydan-uploads` + `public/uploads` (يُخدم عبر rewrite في middleware).

## 10) خلاصة Phase 3
- **موثّق:** 256 مكوّن، 184 lib، 22 service، 11 hooks، طبقات الأمان، تدفق المدفوعات الموحّد.
- **سيُكمل تلقائياً:** خريطة Component→Page لكل صفحة، وخريطة Page→Backend ستُبنى في Phase 3-5 آلياً (API_DEPENDENCY_MATRIX، BUTTON_DEPENDENCY_MATRIX).
- **ملاحظة:** وجود `ui/` و`ui-v2/` يشير لتكرار نظام تصميم محتمل — سيُفحص في Phase 21 (Dead Code/Orphans).

**NEXT PHASE: PHASE 4 — Buttons & Forms Audit**
