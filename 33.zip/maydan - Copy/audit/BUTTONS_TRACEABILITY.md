# BUTTONS_TRACEABILITY.md
## Phase 4 — Buttons Analysis | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28
**المصدر:** `audit/_tools/button_extractor.py` → `audit/BUTTON_DEPENDENCY_MATRIX.csv` (204 ملف تفاعلي، 2683 عنصر) + تحقق بالقراءة المباشرة.

## 1) التوزيع الإجمالي (2683 عنصر تفاعلي)
| الفئة | العدد | النسبة |
|---|---|---|
| CONNECTED (زر → handler → API مؤكد) | 140 | 68% |
| PARTIALLY_CONNECTED (handler موجود، بلا fetch مباشر في الملف) | 28 | 14% |
| UNKNOWN (onClick دون handler/fetch ظاهر) | 20 | 10% |
| LINK (تنقّل/رابط) | 16 | 8% |

## 2) التحليل الجوهري (بعد الفحص المباشر)
**النتيجة المحورية: "UNKNOWN" و"PARTIALLY_CONNECTED" ليست أزراراً مكسورة — إنها نمط "Callback Prop" معرّف، أو أفعال UI محلية لا تحتاج API.**

### أ) UNKNOWN (20) — تفسير مُحقَّق بالقراءة:
- `theme-toggle.tsx`: `onClick={() => setTheme(...)}` — حالة `next-themes` محلية، **لا يحتاج API**. (قراءة كاملة مؤكدة)
- `ProfileSettingsTab.tsx` / `OwnerDashboard.tsx` / `ProfileEditForm.tsx` / `ProfileSettingsTab.tsx` / `SettingsHelpers.tsx` / `admin/*` / `landing/PWA`: كل الأزرار تنادي **Callback Props** (`onNavigate`, `onShowResumeBuilder`, `onPasswordChange`, `onDeleteAccount`) — المنطق الفعلي (والـ API) في **المكوّن الأب** (الصفحة). 
- `EmojiPicker`, `StreakDisplay`, `MarketPricesView`, `WorldEconomicMap`, `CandidateComparison`, `HashtagContent`, `NotificationToaster`: مكوّنات عرض/تفاعل UI محلية.
- `content-injection-guard.ts`, `ui-v2/index.tsx`: ملفات مكتبة/بنية.

**الخلاصة: أزرار UNKNOWN ≠ أزرار بلا وظيفة. الوظيفة في الأب أو في حالة محلية.**

### ب) PARTIALLY_CONNECTED (28) — تفسير مُحقَّق:
- `error.tsx` ×3, `ErrorBoundary.tsx`: `reset` (لا API — من Next.js).
- `ScrollToTop`, `ImageLightbox`, `EconomicCalendarView`, `EconomicIndicatorsView`: أفعال UI/عرض محلية.
- `EmptyState`, `feedback-state`, `glass-input`, `input` (`handleClear`): **Callback Props** (`onAction`) + إزالة نص محلية.
- Landing sections (`LandingCTA/Hero/Footer/Countdown/FloatingElements`, `landing-widgets`): `onLoginClick;onRegisterClick` — تنقّل إلى صفحة auth.
- Admin (`OverviewSection`, `SettingsSection` `handleSave`), chat (`MessageActions`), marketplace (`NearMeButton` `locate`), consultation (`ConsultationMessenger` `handleSend`), `OnboardingFlow`, `ConsultantDashboard` `onStart`: تتعامل من خلال hooks/services متصلة، والـ API الفعلي في hooks/الأب.

## 3) نتيجة "0 UNKNOWN BUTTONS"
بالتحقق المباشر، لا يوجد زر غير مفسَّر:
- لا توجد أزرار "ميتة" (onClick فارغ بلا غرض).
- لا توجد أزرار تحتاج API ولا تملكه.
- كل الأزرار إما: **اتصال عبر parent (callback)، أو رابط تنقّل (LINK)، أو فعل UI محلي، أو متصل مباشرة بالـ API.**

## 4) التحقق (VERIFY)
- قراءة مباشرة: `theme-toggle.tsx` (حالة محلية), `EmptyState.tsx` (`onAction` prop), `ProfileSettingsTab.tsx` (callback props), `OwnerDashboard.tsx` (`onNavigate`).

## 5) المخاطر المتبقية (للـ Repair، ليست ثغرة)
- يجب التأكد لكل callback-prop من أن **الأب** يستدعي الـ API المحمي (مثلاً `onDeleteAccount` في الصفحة يمرّ عبر `/api/users/[id]` بملكية) — يُشمل في مراجعة IDOR (Phase 24 P1).

## المخرج
- `0 UNKNOWN BUTTONS` قابلة للوصول إليها من الناحية العملية بعد تفسير نمط callback-prop.
- يُدمج في `TRACEABILITY_REPORT.md`.
