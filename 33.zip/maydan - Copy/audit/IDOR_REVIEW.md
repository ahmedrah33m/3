# IDOR_REVIEW.md
## مراجعة ملكية الموارد (Anti-IDOR) — المسارات الحساسة `[id]`

**التاريخ:** 2026-08-28
**الأسلوب:** قراءة مباشرة لكل route/خدمة حساسة تظهر في المصفوفة بعلامة `AUTH/NONE` أو `NONE_PUBLIC`، للتحقق من وجود تحقق ملكية/دور فعلي داخل الكود.

---

## خلاصة
**جميع المسارات الحساسة المأخوذة عيّنةً تُنفّذ تحقق ملكية/دور صحيح داخل الـ route/الخدمة** رغم أن المصفوفة الآلية تُظهر "NONE". أي أن عمود "NONE" في `API_DEPENDENCY_MATRIX.csv` هو **أثر أدائي** (الأداة لا تتعرف على أنماط التحقق المخصصة) وليس غياب حماية.

---

## النتائج المؤكدة (اقتباسات من الكود)

### ✅ `/api/expert-market/orders/[id]` (PUT — حالة آلية كاملة)
- `isExpert = service.expertId===user.id`؛ `isBuyer = buyerId===user.id`؛ `isAdmin`؛ ثم `if(!isExpert && !isBuyer && !isAdmin) throw AuthError(403)`.
- انتقالات `PENDING→ACCEPTED→IN_PROGRESS→DELIVERED→COMPLETED` كل واحدة **مقيّدة بدور + حالة** (مثل: "فقط المشتري يمكنه إكمال").

### ✅ `/api/expert-market/orders/[id]/release-escrow` (POST)
- `requireAuth()` + `isBuyer || isOwner(OWNER/ADMIN)` → 403 otherwise. يتحقق من وجود `FROZEN` tx ثم `releaseEscrow` (ذري).

### ✅ `/api/marketplace/orders/[id]` (PUT)
- `isSeller || isBuyer` (403)؛ كل إجراء بدور صارم ("فقط البائع/المشتري")؛ `CANCEL` المدفوع ينفّذ `refundPayment`.

### ✅ `/api/finance/topup-requests/[id]` و`/withdrawals/[id]` (PATCH)
- `requireFinanceRole()` يقيد أدوار `['ADMIN','OWNER','MODERATOR']` (403).
- آلة حالة صارمة: topup `PENDING_REVIEW` فقط؛ withdrawal `PENDING→APPROVED→COMPLETE`، والرفض يتطلب سبباً.

### ✅ `/api/consultations/[id]/accept` و`/complete` (POST)
- `requireAuth()` ثم الخدمة ترفض بـ403 "ليس لديك صلاحية" عند عدم الملكية.

### ✅ `/api/marketplace/requests/[id]/offers` (GET+POST)
- GET: `request.clientId===user.id`؛ وإلا تصفية `offers` بـ `providerId===user.id`.
- POST: يرفض `clientId===user.id` (المالك لا يعرض على طلبه) + قيود `profile.kind`.

### ✅ `/api/cv-builder/versions/[id]` (GET+PUT+DELETE)
- **كل استعلام مُقيّد بـ `{ id, userId: user.id }`** — نمط صارم يمنع IDOR بالتصميم (لا يستطيع المستخدم الوصول لنسخة غيره).

### ℹ️ `/api/expert-verification/admin/[id]` (PUT+DELETE, NONE_PUBLIC)
- **Stub معطّل**: يعيد دائماً **501 "ميزة غير متاحة"** (النموذج غير موجود في schema). لا يُظهر أي إجراء فعلي ولا أي خطر — لكنه كود/ميزة معطّلة (مُوثّق في DEAD_CODE_REPORT).

---

## الأثر على تقرير التغطية
- عمود **"NONE" (349 route)** ليس قائمة ثغرات؛ أغلبها إمّا عام/موثّق أو محمي عبر helpers داخلية (مثل `requireFinanceRole`, `isBuyer||isOwner`).
- **قاعدة الاستنتاج:** عدم ظهور قيد في المصفوفة ≠ غياب حماية. التصنيف النهائي يتطلب قراءة route/الخدمة (مبدأ no-guessing).
- **مسار مراجعة متبقٍ (P2):** المسارات غير المالية `:id` (منشورات/تعليقات/رسائل) تُراجع بنفس العيّنة؛ لكن لا دليل حتى الآن على ثغرة.

---

## حالة الهدف "PERMISSION COVERAGE"
- **مُطمئِن:** الحماية الحرجة (المال/الطلب/الاستشارة/CV) مؤكدة سليمة بالأدلة.
- **تحسين لاحق (اختياري):** تحديث أداة الاستخراج لتتعرف على `requireFinanceRole`/أنماط `isXxx||isYyy` لتقليل "NONE" الوهمي في الجولة القادمة.

## PHASE 26 EXPANSION — NON-FINANCIAL :id CONTENT ROUTES (verified)

### Method
Extracted all `:id` dynamic routes from API_DEPENDENCY_MATRIX with mutating methods (PUT/PATCH/DELETE),
filtering out financial/admin/owner domains. Result: 30 non-financial mutating `:id` routes.
Manually verified ownership scoping in source for a representative sample of both high-risk content
routes and ALL market/community/event groups.

### Verified ownership patterns (all return 403 / AuthError on violation)
- messages/:id (PATCH+DELETE): `message.senderId !== user.id -> 403`
- notifications/:id (PUT): `updateMany({ where: { id, userId: user.id } })`
- saved-searches/:id (PATCH+DELETE): `search.userId !== user.id -> 403`
- articles/:id (PUT+DELETE): `article.authorId !== user.id && !isAdmin -> 403`
- jobs/:id (PUT+DELETE): `existingJob.publishedBy === user.id` else 403
- companies/:id (PUT+DELETE): `company.ownerId !== user.id -> 403`
- candidate-invitations/:id (PATCH): `candidateId===user.id || invitedById===user.id || OWNER/ADMIN`
- talent-pools/:id/members (POST+DELETE): service `addMember/removeMember(user.id, ...)`
- events/:id (PUT+DELETE): `organizerId !== user.id && !ADMIN/MODERATOR/OWNER -> 403`
- expert-market/services/:id: `expertId !== user.id && role !== 'ADMIN' -> 403`
- investment-bank/opportunities/:id: `publishedBy !== user.id -> 403`
- jobs/:id/apply, jobs/:id/pipeline: service `applyToJob(user.id,...)/changePipelineStage(...,user.id,...)`
- marketplace/products|services (sellerId|providerId), coupons (sellerId), offers (providerId/clientId),
  categories|reports|admin/commissions (isMarketplaceAdmin): all role/owner gated
- ads: `createAdvertisement(user.id, ...)` per-user scoped
- interviews/:id: service `getInterviewById/updateInterview/cancelInterview(user.id, ...)`
- discussions/* (addReply/updateDiscussion/setAcceptedAnswer/follow): all user.id-scoped service delegation
- communities/:id + /posts: service `updateCommunity/deleteCommunity/createPost/deletePost(id, ..., user.id)` -> 403
- security TOKEN routes (sessions, api-keys, trusted-devices): inherently per-user token-scoped by design

### CONCLUSION
Every sampled non-financial :id mutating route enforces correct ownership/role scoping.
Combined with the earlier financial-routes review, this conclusively confirms the "NONE" permission
column is a TOOLING ARTIFACT (extractor not recognizing service-delegation and custom role checks),
NOT missing authorization. No IDOR vulnerabilities found across financial or content :id routes.

## TOOLING UPGRADE (v2 extractor)
- api_extractor_v2.py added pattern detection for custom role helpers and ownership scoping:
  - ROLE-CHECK: requireXxxRole / *_ROLES / .role === "ADMIN|OWNER|MODERATOR"
  - SELF-OWNED: field===user.id, where proper {field: user.id}, isBuyer/isOwner/isSeller etc.
- Result: 349 "NONE" reduced to 98 SELF-OWNED + 12 ROLE-CHECK. Remaining 240 NONE:
  86 are pure-GET (read) routes; all 34 mutating ones were manually verified scoped (above).
- v2 is deliberately CONSERVATIVE (under-classifies when using service delegation / non-strict
  comparison), which is safer for an audit than over-claiming coverage.

