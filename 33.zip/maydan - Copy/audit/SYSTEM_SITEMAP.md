# SYSTEM_SITEMAP.md
## Phase 2 — Architecture & Sitemap | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28
**المصدر:** جرد تلقائي لملفات `src/app/**/page.tsx` على السيرفر الجديد (`/home/ahmed/maydan`)

## 1) نظرة عامة

- إجمالي الصفحات (**page.tsx**): **124**
- مجموعات الصفحات: `(main)/` (45 مساحة موثّقة) + `login`, `register`, والجذر `page.tsx`
- آلية التوجيه: كل الصفحات داخل `(main)/` بدون segment لغة؛ `next.config.ts` rewrite يجرّد بادئة `/:locale(en|ar|fr|tr|ur)/` إلى المسار الأصلي (باستثناء قائمة localesOnlyPages المحفوظة).

## 2) تصنيف الصفحات حسب الدور (Role)

| الفئة | العدد |
|---|---|
| PUBLIC | 55 |
| AUTHENTICATED | 23 |
| USER | 6 |
| COMPANY | 14 |
| EXPERT | 1 |
| PROVIDER | 5 |
| ADMIN | 18 |
| OWNER | 2 |

## 3) فهرس الصفحات الكامل (124)

| # | Route | المجال (Domain) | الوالد (Parent) | الدور (Role) |
|---|-------|-----------------|-----------------|--------------|
| 1 | `/login` | login | `-` | PUBLIC |
| 2 | `/academy` | academy | `-` | PUBLIC |
| 3 | `/achievements` | achievements | `-` | PUBLIC |
| 4 | `/admin` | admin | `-` | ADMIN |
| 5 | `/admin/ads` | admin | `admin` | ADMIN |
| 6 | `/admin/analytics` | admin | `admin` | ADMIN |
| 7 | `/admin/audit-logs` | admin | `admin` | ADMIN |
| 8 | `/admin/auto-publish` | admin | `admin` | ADMIN |
| 9 | `/admin/companies` | admin | `admin` | ADMIN |
| 10 | `/admin/consultations` | admin | `admin` | ADMIN |
| 11 | `/admin/content` | admin | `admin` | ADMIN |
| 12 | `/admin/experts` | admin | `admin` | ADMIN |
| 13 | `/admin/finance` | admin | `admin` | ADMIN |
| 14 | `/admin/jobs` | admin | `admin` | ADMIN |
| 15 | `/admin/marketplace` | admin | `admin` | ADMIN |
| 16 | `/admin/moderation` | admin | `admin` | ADMIN |
| 17 | `/admin/scrape` | admin | `admin` | ADMIN |
| 18 | `/admin/security` | admin | `admin` | ADMIN |
| 19 | `/admin/settings` | admin | `admin` | ADMIN |
| 20 | `/admin/users` | admin | `admin` | ADMIN |
| 21 | `/ai-assistant` | ai-assistant | `-` | AUTHENTICATED |
| 22 | `/analytics` | analytics | `-` | AUTHENTICATED |
| 23 | `/articles` | articles | `-` | PUBLIC |
| 24 | `/articles/[id]` | articles | `articles` | PUBLIC |
| 25 | `/bookmarks` | bookmarks | `-` | AUTHENTICATED |
| 26 | `/chat-rooms` | chat-rooms | `-` | AUTHENTICATED |
| 27 | `/communities` | communities | `-` | PUBLIC |
| 28 | `/communities/[id]` | communities | `communities` | PUBLIC |
| 29 | `/companies` | companies | `-` | PUBLIC |
| 30 | `/companies/[id]` | companies | `companies` | PUBLIC |
| 31 | `/company-dashboard` | company-dashboard | `-` | COMPANY |
| 32 | `/company/register` | company | `company` | COMPANY |
| 33 | `/connections` | connections | `-` | AUTHENTICATED |
| 34 | `/consultant-dashboard` | consultant-dashboard | `-` | EXPERT |
| 35 | `/consultations` | consultations | `-` | PUBLIC |
| 36 | `/control-center` | control-center | `-` | COMPANY |
| 37 | `/control-center/branches` | control-center | `control-center` | COMPANY |
| 38 | `/control-center/employees` | control-center | `control-center` | COMPANY |
| 39 | `/control-center/organization` | control-center | `control-center` | COMPANY |
| 40 | `/control-center/system` | control-center | `control-center` | COMPANY |
| 41 | `/create-post` | create-post | `-` | AUTHENTICATED |
| 42 | `/cv-builder` | cv-builder | `-` | AUTHENTICATED |
| 43 | `/dashboard` | dashboard | `-` | AUTHENTICATED |
| 44 | `/dictionary` | dictionary | `-` | PUBLIC |
| 45 | `/discussions` | discussions | `-` | PUBLIC |
| 46 | `/discussions/[id]` | discussions | `discussions` | PUBLIC |
| 47 | `/economy/ai-assistant` | economy | `economy` | PUBLIC |
| 48 | `/economy/calendar` | economy | `economy` | PUBLIC |
| 49 | `/economy/charts` | economy | `economy` | PUBLIC |
| 50 | `/economy/converter` | economy | `economy` | PUBLIC |
| 51 | `/economy/indicators` | economy | `economy` | PUBLIC |
| 52 | `/economy/map` | economy | `economy` | PUBLIC |
| 53 | `/economy/market` | economy | `economy` | PUBLIC |
| 54 | `/events` | events | `-` | PUBLIC |
| 55 | `/expert-market` | expert-market | `-` | PUBLIC |
| 56 | `/experts` | experts | `-` | PUBLIC |
| 57 | `/finance` | finance | `-` | AUTHENTICATED |
| 58 | `/finance/invoices` | finance | `finance` | PUBLIC |
| 59 | `/finance/transactions` | finance | `finance` | PUBLIC |
| 60 | `/investment-bank` | investment-bank | `-` | PUBLIC |
| 61 | `/investment/investors` | investment | `investment` | PUBLIC |
| 62 | `/investment/opportunities` | investment | `investment` | PUBLIC |
| 63 | `/investment/partnerships` | investment | `investment` | PUBLIC |
| 64 | `/jobs` | jobs | `-` | PUBLIC |
| 65 | `/jobs/candidate/applied` | jobs | `jobs/candidate` | USER |
| 66 | `/jobs/candidate/interviews` | jobs | `jobs/candidate` | USER |
| 67 | `/jobs/candidate/offers` | jobs | `jobs/candidate` | USER |
| 68 | `/jobs/candidate/profile` | jobs | `jobs/candidate` | USER |
| 69 | `/jobs/candidate/resume` | jobs | `jobs/candidate` | USER |
| 70 | `/jobs/candidate/saved` | jobs | `jobs/candidate` | USER |
| 71 | `/jobs/cv-bank` | jobs | `jobs` | PUBLIC |
| 72 | `/jobs/dashboard` | jobs | `jobs` | PUBLIC |
| 73 | `/jobs/employer` | jobs | `jobs` | COMPANY |
| 74 | `/jobs/employer/applicants` | jobs | `jobs/employer` | COMPANY |
| 75 | `/jobs/employer/applicants/[jobId]/kanban` | jobs | `jobs/employer/applicants/[jobId]` | COMPANY |
| 76 | `/jobs/employer/interviews` | jobs | `jobs/employer` | COMPANY |
| 77 | `/jobs/employer/jobs` | jobs | `jobs/employer` | COMPANY |
| 78 | `/jobs/employer/reports` | jobs | `jobs/employer` | COMPANY |
| 79 | `/jobs/employer/settings` | jobs | `jobs/employer` | COMPANY |
| 80 | `/jobs/[id]` | jobs | `jobs` | PUBLIC |
| 81 | `/jobs/new` | jobs | `jobs` | PUBLIC |
| 82 | `/leaderboard` | leaderboard | `-` | PUBLIC |
| 83 | `/learn` | learn | `-` | PUBLIC |
| 84 | `/learning` | learning | `-` | PUBLIC |
| 85 | `/learning/certificates` | learning | `learning` | PUBLIC |
| 86 | `/learning/dictionary` | learning | `learning` | PUBLIC |
| 87 | `/learning/[id]` | learning | `learning` | PUBLIC |
| 88 | `/learning/paths` | learning | `learning` | PUBLIC |
| 89 | `/learning/quizzes` | learning | `learning` | PUBLIC |
| 90 | `/marketplace` | marketplace | `-` | AUTHENTICATED |
| 91 | `/marketplace/admin` | marketplace | `marketplace` | ADMIN |
| 92 | `/marketplace/dashboard` | marketplace | `marketplace` | PROVIDER |
| 93 | `/marketplace/products` | marketplace | `marketplace` | AUTHENTICATED |
| 94 | `/marketplace/products/[id]` | marketplace | `marketplace/products` | AUTHENTICATED |
| 95 | `/marketplace/providers` | marketplace | `marketplace` | PROVIDER |
| 96 | `/marketplace/providers/[id]` | marketplace | `marketplace/providers` | PROVIDER |
| 97 | `/marketplace/requests` | marketplace | `marketplace` | AUTHENTICATED |
| 98 | `/marketplace/requests/[id]` | marketplace | `marketplace/requests` | AUTHENTICATED |
| 99 | `/marketplace/requests/new` | marketplace | `marketplace/requests` | AUTHENTICATED |
| 100 | `/marketplace/services` | marketplace | `marketplace` | AUTHENTICATED |
| 101 | `/marketplace/services/[id]` | marketplace | `marketplace/services` | AUTHENTICATED |
| 102 | `/marketplace/stores` | marketplace | `marketplace` | PROVIDER |
| 103 | `/marketplace/stores/[id]` | marketplace | `marketplace/stores` | PROVIDER |
| 104 | `/messages` | messages | `-` | AUTHENTICATED |
| 105 | `/notifications` | notifications | `-` | AUTHENTICATED |
| 106 | `/owner` | owner | `-` | OWNER |
| 107 | `/owner-panel` | owner-panel | `-` | OWNER |
| 108 | `/polls` | polls | `-` | PUBLIC |
| 109 | `/premium` | premium | `-` | AUTHENTICATED |
| 110 | `/profile/[id]` | profile | `profile` | PUBLIC |
| 111 | `/profile/me` | profile | `profile` | AUTHENTICATED |
| 112 | `/questions` | questions | `-` | PUBLIC |
| 113 | `/questions/[id]` | questions | `questions` | PUBLIC |
| 114 | `/quizzes` | quizzes | `-` | PUBLIC |
| 115 | `/quizzes/[id]` | quizzes | `quizzes` | PUBLIC |
| 116 | `/research` | research | `-` | PUBLIC |
| 117 | `/search` | search | `-` | PUBLIC |
| 118 | `/tags/[tag]` | tags | `tags` | PUBLIC |
| 119 | `/verify-certificate` | verify-certificate | `-` | PUBLIC |
| 120 | `/wallet` | wallet | `-` | AUTHENTICATED |
| 121 | `/write` | write | `-` | AUTHENTICATED |
| 122 | `/write/[id]` | write | `write` | PUBLIC |
| 123 | `/page.tsx` | page.tsx | `-` | PUBLIC |
| 124 | `/register` | register | `-` | PUBLIC |

## 4) ملاحظات هيكلية (Phase 2)

- **PUBLIC**: تسجيل الدخول/التسجيل والجذر + صفحات تصفح عامة (articles, jobs list, experts, companies list, search, dictionary, economy, questions, discussions, leaderboard, marketplace browsing, communities).
- **AUTHENTICATED (مستخدم موثّق عام)**: dashboard, profile/me, wallet, finance, messages, notifications, bookmarks, connections, premium, create-post, write, cv-builder, chat-rooms, ai-assistant, analytics, polls, tags.
- **COMPANY**: company/register, company-dashboard, control-center/*, jobs/employer/* (jobs, applicants+kanban, interviews, reports, settings).
- **EXPERT**: consultant-dashboard, consultations.
- **PROVIDER (سوق)**: marketplace/dashboard, marketplace/stores/*, marketplace/requests/*.
- **ADMIN**: admin/* (users, companies, jobs, finance, content, moderation, security, audit-logs, ads, analytics, experts, consultations, marketplace, scrape, settings, auto-publish).
- **OWNER**: owner, owner-panel.

**ملاحظة دقة التصنيف:** التصنيف حسب المسار يعكس المساحة الوظيفية المقصودة؛ التحقق الدقيق من الصلاحية الفعلية لكل صفحة يتم في PHASE 8 (Permissions) عبر قراءة كود الحماية في middleware وكل page.

**NEXT PHASE: PHASE 3 — Pages & Components (SYSTEM_ARCHITECTURE.md)**
