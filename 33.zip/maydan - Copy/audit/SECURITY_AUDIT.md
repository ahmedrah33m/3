# SECURITY_AUDIT.md
## Phase 22 — Security Audit | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28 — **الحالة:** AUDIT (قراءة/تحليل، لا تعديل بعد — التعديلات في Phase 24 Repair P0)

## 1) المصادقة / الجلسات
- آلية موحّدة: `requireAuth / requireAdmin / requireOwner / requireOwnerOrAdmin / optionalAuth / getCurrentUser` من `@/lib/session` — ناتج هذا التحليل التلقائي على 428 API route:
  - **AUTH (مصادقة مطلوبة): 287 route**
  - **PUBLIC (بدون مصادقة): 104 route**
  - **OPTIONAL (اختيارية): 26 route**
  - **TOKEN (verifyToken فقط): 11 route**
- Session hardening موجود (`lib/security/session-hardening.ts`, `session-manager.ts`), token blacklist edge, brute-force guard, account-lockout, two-factor + WebAuthn.

## 2) التفويض / الصلاحيات (Permission)
نتيجة الفحص التلقائي لقيود الدور في 428 route:
- **NONE (لا قيد دور صريح): 349 route** ← ✅ **إشارة حرجة (P0/P1 بالقائمة)**
  - من بينها 287 موثّقة (AUTH) لكن **لا قيد دور/صلاحية صريح يظهر في الاستخراج الآلي**. كثير منها قد يكون مقصوداً عاماً للمستخدم الموثّق، لكن يجب فحص كل حالة حيث توجد بيانات حساسة (مال/إدارة/شركات/خبراء).
  - حالة خاصة أُثبتت بالقراءة المباشرة: `POST /api/jobs/[id]/apply` يستخدم `requireAuth()` فقط (صحيح لكشف عام) — والـ service `applyToJob` يفرض الامتلاك. أي أن الحماية الحقيقية داخل الخدمة، لذا **لا يُعتبر "NONE" ثغرة تلقائياً** — بل نقطة تحقق.
- **ADMIN: 42 route، OWNER: 31، OWNER|ADMIN: 4، ROLE-CHECK: 2** — هذه أدوار صريحة متمركزة.

## 3) IDOR / ملكية الموارد
- نمط `requireAuth()` + تمرير `id` من URL شائع جداً. في `jobs/[id]/apply` تم بالفعل إصلاح سابق (مرّ بالـ session user.id لامتلاك withdraw). **التحقق الشامل من ملكية الموارد لكل `route.ts` آخذ `:id` مطلوب في Repair** (P1) — لا يمكن الجزم بسلامة كل واحدة بدون قراءة كل ملف.

## 4) CSRF / حماية الطلبات
- `CsrfBootstrap` + middleware `ensureCsrfCookie/verifyCsrf` (double-submit) — موجودة وفعّالة على مستوى التطبيق.

## 5) Rate Limiting / DoS
- middleware: per-IP rate limit 2000/min + `lib/security/tiered-rate-limit.ts`, `api-rate-limit`, `dos-protection`, `bot-detection`, `anti-scraping` — قوي.

## 6) إدخال المستخدم / XSS / Injection
- `html-sanitizer.ts`, `content-injection-guard`, `input-validation.ts`, `validation.ts`, Prisma parameterized — موجودة.

## 7) رفع الملفات / التخزين
- `file-scanner.ts` + MinIO + `public/uploads` عبر rewrite في middleware (Content-Type صوتي) + CSP `img-src data: blob: https:` وشروط uploads caching.

## 8) أسرار / سجلات
- `data-classification`, `data-masking`, `data-leak-prevention`, `env-secrets`, `encryption-at-rest` موجودة.
- **مخاطرة بيئات:** `.env` يضم أسرار إنتاج حقيقية على القرص — يجب الالتزام بعدم كشفها في أي مخرجات/سجلات. (مؤكّد موجود في `/home/ahmed/maydan/.env`).

## 9) ملاحظات
- `ignoreBuildErrors: true` في next.config.ts — الفحص النوعي معزول في `npm run typecheck`؛ أي إصلاح يلتزم بالمرور عليه.
- هيكل `lib/security/` (39 وحدة) يدل على نضج أمني مرتفع؛ كثير من التحققات الحسّاسة داخل الخدمات، لذا أي إصلاح يبدأ بقراءة الخدمة لا بتعديل الـ route.

## المخاطر (RISKS) والخطوات القادمة
- **RISK-1:** 349 route "NONE permission" تُشكّل سطح تحقق كبير — تُعالج بالقراءة الفعلية لكل route حساس (مال/إدارة/شركة/خبير) وليس إجمالياً.
- **RISK-2:** عمليات مالية فقط 7 routes ذات `$transaction` ظاهر — التحقق من atomicity داخل `wallet-service`/`payment-service` (Phase 14/33).
- RISK-3: نماذج يتيمة قد تعني عمليات معرّضة أو مستخدمي hallows غير محميين — Phase 21.

**المخرج: يُدمج في REPAIR_PLAN.md (Phase 24) كـ P0/P1.**
