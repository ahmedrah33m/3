# PERMISSION_MATRIX.md
## Phase 26 — Permission Coverage | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28 — **المصدر:** استخراج آلي من 428 API route (api_extractor.py)

## 1) أدوات المصادقة (Authentication Helpers)
المصدر الموحّد: `@/lib/session` — `requireAuth / requireAdmin / requireOwner / requireOwnerOrAdmin / optionalAuth / getCurrentUser`.

## 2) توزيع المصادقة عبر 428 route
| المستوى | العدد | الدلالة |
|---|---|---|
| **AUTH** (مصادقة مطلوبة) | 287 | المستخدم مسجّل دخول إلزامي |
| **PUBLIC** (بدون مصادقة) | 104 | مسارات عامة (read/search/etc.) |
| **OPTIONAL** | 26 | مكتبة اختيارية (تحسين التجربة عند الدخول) |
| **TOKEN** (verifyToken فقط) | 11 | تحقق رمز خفيف (فحص جلسة دون تفويض) |

## 3) توزيع الصلاحيات (التحقق من الدور) على 428 route
| القيد | العدد | الدور الذي يُفرض |
|---|---|---|
| **NONE** (لا قيد دور صريح في الاستخراج) | 349 | ⚠️ يُتحقق يدوياً — كثير منها مقصود عام موثّق أو تُفرض الحماية داخل الخدمة |
| **ADMIN** | 42 | requireAdmin |
| **OWNER** | 31 | requireOwner |
| **OWNER\|ADMIN** | 4 | requireOwnerOrAdmin |
| **ROLE-CHECK** | 2 | تحقق دور مخصص |

## 4) تحليل حالة "NONE" (349 route)
**مهمة جداً لصحة الاستنتاج:** لا يُعتبر كل "NONE" ثغرة. التوضيحات المثبتة بالقراءة المباشرة:
- المسار `POST /api/jobs/[id]/apply`: `requireAuth()` فقط (Bidar public) — لكن `applyToJob` service يفرض الملكية/الامتلاك داخل الخدمة. **الحماية موجودة داخل طبقة الخدمة.**
- النمط المعتمد في النظام: **route = مصادقة فقط، service = تفويض/ملكية**. لذلك الاستخراج الآلي على مستوى الـ route يُظهر "NONE" بينما الحماية الحقيقية في service.
- **القاعدة:** لتصنيف كل "NONE" بدقة يجب قراءة الـ service المقابل — لا يجوز إعلان ثغرة من الاستخراج الآلي وحده.

## 5) قائمة التحقق اليدوي (Repair Phase — الأولوية حسب الحساسية)
تُركّز المراجعة اليدوية على المسارات "NONE" التي تمسّ:
- المال (`wallet`, `finance`, `payment`, `topup`, `withdraw`, `orders`, `escrow`)
- الشركات (`company*`), الخبراء (`expert*`, `consult*`), السير الذاتية (`cv*`, `resume`)
- الإدارة (`admin`, `owner`), المستخدم (`users/[id]`)

**كل مسار يحوي `:id` وNONE يتطلب تحقق ملكية الموارد (IDOR check).**

## 6) الخلاصة
- **التغطية:** مصادقة شاملة (287/428 موثّقة + 26 اختيارية + 37 أدوار صريحة = تغطية جيدة).
- **نقاط تحقق مطلوبة:** 349 "NONE" تُقيَّم يدوياً عبر تتبع دائرة (Button→Handler→API→Service) — تُنجز في Repair Phase (P1) وليس الآن، التزاماً بـ MUST-NOT (لا تخمين).
- **constraint من pre-prompt:** الصلاحيات داخل الخدمات تمنع الإعلان التلقائي بالثغرات.

## المخرج
يُدمج في `REPAIR_PLAN.md` (P1) و`TRACEABILITY_REPORT.md`.
