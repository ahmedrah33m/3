# DATABASE_RELATION_MAP.md
## Phase 7 — Database Audit | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28
**المصدر:** تحليل تلقائي لـ `prisma/schema.prisma` (260 model) + مسح شامل لـ `src/**` (1099 ملف TS/TSX) للوصول الفعلي عبر `db.<model>`.

---

## 1) خلاصة قاعدة البيانات

| البند | القيمة |
|---|---|
| Prisma Clients | `db` (من `@/lib/db`) عبر singleton + امتداد تشفير `encryptionExtension` |
| قاعدة البيانات | PostgreSQL 15 (عبر PgBouncer pool + DIRECT) |
| إجمالي الـ Models | **260** |
| إجمالي الـ Enums | 22 |
| Models مستخدمة (`db.<model>` لا تستخدم) | **204** |
| **Models يتيمة (لا يُشار إليها بـ `db.<model>` إطلاقاً)** | **56** |
| Models منخفضة الاستخدام (مرجع 1-2 فقط) | **134** |

---

## 2) الوصول إلى البيانات (Data Access Layer)

- العميل الموحّد `db` في `src/lib/db.ts` مع `globalForPrisma` singleton و shutdown handlers.
- امتداد `encryptionExtension` — تشفير حقل-على-حقل عند الراحة (auto encrypt/decrypt).
- الوصول النمطي: `db.<modelLowercase>` داخل services/routes.
- **ملاحظة منهجية:** "اليتيمة" هنا تعني عدم وجود مرجع مباشر `db.<model>`؛ لكن النماذج قد تُصل عبر relations المضمّنة (مثل `user.company`) أو raw queries — لذا كل حالة تُرشَّح في Phase 21 (Dead Code) بأدوات trace دقيقة قبل الحذف.

---

## 3) النماذج اليتيمة المحتملة (56) — تُراجَع في Phase 21/28

AchievementChain, AiLog, ApiKeyRecord, Assignment, AssignmentSubmission, Badge, CompanyTest, CompanyTestResult, ContentAnalysis, CourseCoupon, CourseFavorite, CourseNote, CourseReview, CvCoverLetter, CvJobMatch, CvRecommendation, CvTemplate, DataRoomFile, EconomicAlert, ErrorReport, EventGalleryItem, EventSession, EventSpeaker, EventSponsor, EventSurvey, ExpertVerification, InvestmentMatch, JobScreeningQuestion, LearningPoint, LessonDiscussion, Newsletter, NewsletterSubscription, PasswordChangeLog, PeerReview, PublishAnalytics, QuestionBankItem, QuestionBookmark, QuestionBounty, QuestionCommunity, ResearchCitation, ResearchFunding, ResearchProject, ResearchWorkspace, ScreeningAnswer, SecurityEvent, SkillAssessment, SkillPassportEntry, TermCalculator, TermQuiz, UserCompanyRole, UserMilestone, UserReputation, UserSocialLink, UserSpecialization, WebAuthnCredential, WorkspaceMember

### ملاحظات أولية على اليتيمة:
- **أمن/هوية:** `ApiKeyRecord`, `SecurityEvent`, `WebAuthnCredential`, `PasswordChangeLog`, `UserCompanyRole` — قد تُستخدم عبر مكتبات/ميدل وير غير `db.<model>` المباشر؛ يجب فحص الوصول غير المباشر قبل الحذف.
- **محتوى/تعلم:** `Assignment`, `Badge`, `CourseReview`, `LessonDiscussion`, `QuestionBankItem`, `SkillAssessment` — إما غير مبنية بعد أو مكتملة عبر Relations.
- **استثمار/بحث:** `DataRoomFile`, `InvestmentMatch`, `ResearchProject`, `WorkspaceMember` — نطاقات قد تكون معطّلة في الواجهة.

---

## 4) النماذج المرجعية الحسّاسة (المستخدمة بكثافة)

- `db.user` (50)، `db.jobApplication` (22)، `db.discussion` (19)، `db.offer` (14)، `db.job` (12)، `db.company` (12)، `db.interview` (11)، `db.consultation`، `db.community`، `db.report`، `db.cvBankSubscription`، `db.notification`، `db.article`، `db.walletTransaction`، `db.analyticsEvent` — هذه هي العمود الفقري للأعمال.

---

## 5) الاتجاهات الرئيسية المكتشفة

1. **Financial atomicity:** مسح شامل وجد أن **7 فقط** من 428 مسار API تستخدم `prisma.$transaction` (النمط القياسي Atomicity). من بينها: `polls/[id]/vote`, `reposts`, `likes`, `follows`, `users/[id]/profile-images`, `owner/topup`, `owner/withdrawals`. **أغلب العمليات المالية (wallet/pay, withdraw, refund, transfer, bookings) لا تظهر TX مباشرة** — مُدرَج كإشارة P0/P1 في Repair Plan (يجب التحقق من أن `wallet-service`/`payment-service` تعالج atomicity داخلياً عبر `$transaction`).
2. **$transaction داخل services:** يجب فحص `src/lib/wallet-service.ts` و`payment-service.ts` لأن الحماية الحقيقية للتزامن قد تكون داخل الخدمة لا داخل route — لا يُنعت التعديل قبل قراءة تلك الخدمات (القاعدة: لا تخمين).
3. **النماذج غير المترابطة في الواجهة:** النطاقات (Research, Investment, Debates, CollabDocs, Badges) لديها نماذج كثيرة منخفضة/يتيمة — ما قد يدل على Flows غير مكتملة أو معطّلة (Phase 29 Static Data + Phase 21 Orphans).

---

## 6) المصادر الآلية
- `audit/_tools/api_extractor.py` → `audit/API_DEPENDENCY_MATRIX.csv` (428 route)
- `audit/_tools/core_analysis2.py` → بيانات النماذج اليتيمة/المستخدمة

**NEXT: تُربط هذه النتائج في REPAIR_PLAN.md (Phase 24-28) ومرحلة Dead Code (Phase 21).**
