# PAYMENT_TRACEABILITY.md
## Phase 30 — Payment Traceability | منصة ميدان (Midan Platform)

**التاريخ:** 2026-08-28 — **الحالة:** VERIFIED (مؤكدة بالقراءة المباشرة للخدمة)

## الخلاصة
التدفق المالي بأكمله محمي بالذّرّة (Atomic) عبر طبقة الخدمة لا عبر route. **لا توجد ثغرة overdraw/سرقة محفظة في المسار الأساسي.** (تصحيح لإشارة "7 TX routes فقط" — كانت قراءة route-level وليست service-level.)

## التسلسل الموثّق (من القراءة المباشرة)

1. **الواجهة** → button/UI → handler `POST /api/wallet/pay`
2. **الرحلة**: PricingConfig → ServicePrice → `getServicePrice(serviceKey)` → `payFromWallet()`
3. **`payFromWallet` (src/lib/wallet-service.ts:338) — الحماية الكاملة:**
   - **Idempotency (Redis):** مفتاح `{userId}:{serviceType}:{serviceId}` يمنع الشحن المكرر من الطلب المكرر.
   - **`db.$transaction`**: كل الخطوات داخل معاملة واحدة (line 359).
   - **القفل/الخصم الذري:** `tx.wallet.updateMany({ where: { userId, balance: { gte: amount+frozen } }, data: { balance: {decrement}, totalSpent: {increment} } })` — شرط `WHERE` داخل الـ UPDATE نفسه، فيستحيل تجاوز الرصيد حتى مع مدفوعات متزامنة (يلغي الحاجة لقفل الصف يدوياً).
   - **الحجز (frozen):** إشارة إلى `frozenBalance` تُخصم من `availableBalance` قبل التحقق.
   - **العمولة:** `getCommissionConfig(serviceType)` → `commissionAmount = amount * platformPercent/100`، `providerAmount = amount - commission` — تسجَّل داخل المعاملة.
   - **`WalletTransaction` (SPEND)** مع `reference: PAY-...` فريد + **`Invoice`** — يُنشآن معاً بشكل ذرّي (تتبع كامل لكل دفعة).
   - نتيجة محفوظة في Redis idempotency (إعادة الطلب تُرجع نفس النتيجة).

## دوال المحفظة المحمية بـ `$transaction` (مؤكّدة بقراءة مصفوفة line→function)
| الوظيفة | السطر | الحماية |
|---|---|---|
| `payFromWallet` | 359 | $transaction + idempotency + خصم ذرّي |
| `approveTopUp` | 590 | $transaction |
| `rejectTopUp` | 671 | $transaction |
| `createWithdrawalRequest` | 729 | $transaction |
| `approveWithdrawal` | 791 | $transaction |
| `rejectWithdrawal` | 886 | $transaction |
| `redeemGiftCard` | 929 | $transaction |
| `adjustWallet` | 1130 | $transaction |
| `refundPayment` | 1316 | $transaction |
| `releaseEscrow` | 1387 | $transaction |
| `transferFunds` | 1435 | $transaction |

**مجموع `$transaction` داخل `wallet-service.ts` = 11.**

## تتبع صفقة افتراضية (نقطة-بنقطة)
```
UI(شراء) → POST /api/wallet/pay → handler(requireAuth) → payFromWallet
   → idempotency(Redis) → $transaction
       → getCommissionConfig(PricingConfig) → getServicePrice(ServicePrice)
       → خصم ذرّي من Wallet (الشرط المعدِّل)
       → WalletTransaction(SPEND, reference فريد)
       → Invoice(invoiceNumber PW-...)
   → إرجاع PAY-... (walletTxId) للواجهة → تحديث حالة الزر
```
**كل حلقة في السلسلة traceable وقابلة للتدقيق (Audit trail) عبر `WalletTransaction` + `Invoice` + `reference`.**

## التحقق من هوية الخبير (hisse) في الشراء
- `ExpertServiceOrder` / `Consultation` / إلخ عبر `serviceId` + `providerId` الممرَّر إلى `payFromWallet` → `relatedUserId` + `providerAmount` — تُسجَّل الحصة ضمن المعاملة.

## نقاط تحقق إضافية (توصية / غير محسوبة ثغرة)
- `payment-service.ts` (132 سطراً) عبارة عن طبقة تنسيق رفيعة تُفوّض إلى `wallet-service`؛ لاحظ عدم وجود `$transaction` مباشر فيها — مقبول لأن الذرّية في الخدمة المستهدفة، لكن يُنصح بعمل اختبار تكامل للتزامن (GiftCard/Withdrawal) في Phase 33/34.
- مسارات `topup` (شحن) تتطلب موافقة يدوية (`approveTopUp`) — مناسبة للرقابة المالية.

## المخرج
- **تشفير محافظ/عمليات = AT RISK: لا** — مؤكّد الاشتراك السليم.
- يُدمج في `TRACEABILITY_REPORT.md` و`REPAIR_PLAN.md` (لا إصلاح مطلوب للمسار الأساسي).
