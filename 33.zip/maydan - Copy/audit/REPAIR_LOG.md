# REPAIR_LOG.md
## سجل الإصلاحات المؤكدة والمنشورة — منصة ميدان (Midan Platform)

**الحالة:** توثيق الإصلاحات المُنجزة فعلياً على السيرفر الجديد (192.168.88.45) مع نسخة احتياطية قبل كل تعديل وتحقق بعد النشر.

---

## الإصلاح #1 (P0) — `/api/owner/pricing-dashboard`
- **التاريخ:** 2026-08-28
- **النوع:** DUMMY BUSINESS DATA + تعرّض عام للحماية (Permission)
- **قبل الإصلاح:**
  - المسار (`src/app/api/owner/pricing-dashboard/route.ts`) كان `NONE_PUBLIC` (بلا مصادقة/ملكية رغم وقوعه تحت `/api/owner/`).
  - كان يُرجع **أرقاماً مالية مزيّفة مكتوبة يدوياً** (`totalRevenue: 245_000_000`, `monthlyRevenue`, `netProfit`, `churnRate`, `revenueByPlan`, ...) مع تعليق صريح: *"In production, this would aggregate from Prisma"* — أي Stub/Dummy.
  - لا يوجد أي مكوّن واجهة يستدعيه (متأكد عبر البحث) — مسار يتيم يعرّض بيانات مزيّفة علناً.
- **بعد الإصلاح:**
  - أُضيف `await requireOwner()` → يعيد **401** (يجب تسجيل الدخول) لغير الموثّقين، و403/404 لغير المالك.
  - استبدال الأرقام المزيّفة بتجميع حقيقي عبر `getFinancialOverview()` (من `@/lib/wallet-service`) — نفس الآلية المُتحقَّق منها في `/api/owner/financial-overview`.
  - الرد الآن يعكس بيانات حقيقية: totalCommission, totalGMV, totalProviderPayouts, totalDeposits, totalTransactions, pendingWithdrawals, pendingTopUps, revenueByService, dailyBreakdown.
- **التوثيق والمصادقة:**
  - النسخة الأصلية محفوظة في `audit/backup_pricing-dashboard.route.ts.orig`.
  - إعادة بناء صورة Docker (`maydan-app:latest`) بنجاح (بدون أخطاء ترجمة).
  - إعادة إنشاء الحاوية: **healthy خلال ~10 ثوانٍ**.
  - تحقق HTTP: بدون مصادقة → **HTTP 401** `{"error":"يجب تسجيل الدخول"}` (كان 200 مع بيانات مزيّفة علناً).
- **لم يُكسر أي API:** لا يوجد متصل خارجي بالمسار (متأكد)، ولم تُغيّر عقود endpoints أخرى.
- **ملاحظة النشر:** التطبيق يعمل كـ Standalone Next.js داخل Docker (وليس dev)، لذا أي تغيير مصدري يتطلب `docker compose build app` ثم `up -d app`. تم تنفيذ ذلك بتحقق صحي.

---

## الجدول العام
| # | النوع | المسار | الحالة | التحقق |
|---|---|---|---|---|
| 1 | DUMMY DATA + PERM | `/api/owner/pricing-dashboard` | ✅ منشور ومُتحقَّق | HTTP 401 بدون مصادقة + مبنى بلا أخطاء |

## السياسة المطبقة لكل إصلاح
1. قراءة الكود أولاً (لا تخمين).
2. نسخ احتياطي للملف قبل التعديل.
3. بناء صورة بدون لمس الحاوية العاملة.
4. نشر عبر `up -d` ثم انتظار health.
5. تحقق HTTP/سلوكي بعد النشر.
