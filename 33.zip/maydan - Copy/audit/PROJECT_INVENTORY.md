# PROJECT_INVENTORY.md — جرد المشروع الكامل
## Phase 1 — Project Inventory | منصة ميدان (Midan Economic-Professional Platform)

**التاريخ:** 2026-08-28
**السيرفر (النسخة العاملة):** 192.168.88.45 — `/home/ahmed/maydan`
**البيئة:** Production (Docker Compose) — يعمل على `http://192.168.88.45:3300/`
**الوضع:** التطبيق يعمل الآن، قاعدة البيانات 45 مستخدمـاً، الصور في MinIO، PostgreSQL + PgBouncer + Redis healthy.

---

## 1) خلاصة النظام

| البند | القيمة |
|---|---|
| اسم الحزمة | `midan-platform` |
| الإصدار | `0.2.0` |
| النوع | منصة مهنية-اقتصادية متعددة اللغات (ar/en/fr/tr/ur) بإدارة الرواتب/الوظائف/الاقتصاد/الاستثمار |
| Next.js | `^16.2.7` |
| React | `^19.0.0` |
| TypeScript | `^5` (strict، ignoreBuildErrors مفعّل — الفحص عبر `npm run typecheck`) |
| Prisma | `^6.19.2` + adapter `@prisma/adapter-pg` |
| قاعدة البيانات | PostgreSQL 15 (عبر PgBouncer pool + direct) |
| الكاش/قوائم الانتظار | Redis (ioredis) + BullMQ |
| الإشعارات اللحظية | Socket.IO + SSE + Web Push |
| التخزين | S3/MinIO + محلي `public/uploads` |
| إخراج البناء | standalone (Next.js `output: "standalone"`) |

---

## 2) عدادات الحجم (Phase 1 Inventory numbers)

| المقياس | العدد |
|---|---|
| إجمالي ملفات `src` | **1102** |
| إجمالي أسطر TS/TSX | **226,090** (بما فيها app/API) |
| صفحات الواجهة (page.tsx تحت app) | **124** |
| صفحات الواجهة الفعلية المقدَّرة (مع route groups + dynamic) | ~**547** (مرجع التطوير) |
| API Route Handlers (route.ts تحت api) | **428** |
| مكونات `src/components` | **256 ملف** |
| ملفات `src/lib` | **184** |
| ملفات `src/services` | **22** |
| `src/repositories` | 1 ملف (`index.ts`) |
| `src/hooks` | **11** |
| `src/scripts` | 2 (jobs-worker، scraper-worker) |
| ملفات `src/__tests__` | 20 |
| Prisma Models | **260** |
| Prisma Enums | **22** |
| ملف JSON بيانات | 1 (`world-countries.json`) |

---

## 3) بنية الأدلة (top-level تحت src/)

```
src/
├── app/            → 124 page.tsx + 428 route.ts + middleware.ts
├── components/     → 256 ملف (UI + feature components)
├── hooks/          → 11 hooks (realtime/SSE/socket، CSRF، translation…)
├── lib/            → 184 ملف (core + ai + economic + payment + security + social + platform…)
├── services/       → 22 خدمة (طبقة business logic)
├── repositories/   → index.ts (طبقة الوصول للبيانات)
├── data/           → world-countries.json
├── scripts/        → workers (BullMQ jobs, scraper)
├── types/          → 1 ملف (تعريفات)
├── __tests__/      → 20 ملف اختبار (Vitest)
├── fonts/          → (خطوط)
```

### src/lib (subdirs)
`ai`, `design-system`, `economic`, `jobs`, `locales`, `payment`, `platform`, `security`, `social`

### src/services (22 خدمة)
advertisement, analytics, article, comment, community, company, consultation-marketplace, counter, cv-bank, discussion, interview, job-application, job, message, moderation-ai, notification, offer, payment, phone-verification, report, search, talent-pool

---

## 4) مجموعات الصفحات (Route Groups) — 52 مساحة رئيسية

### غير موثّقة/خارج (main): `login`, `register`, `api`

### `(main)` — المساحات الموثّقة (45):
academy, achievements, admin, ai-assistant, analytics, articles, bookmarks, chat-rooms, communities, companies, company, company-dashboard, connections, consultant-dashboard, consultations, control-center, create-post, cv-builder, dashboard, dictionary, discussions, economy, events, expert-market, experts, finance, investment, investment-bank, jobs, leaderboard, learn, learning, marketplace, messages, notifications, owner, owner-panel, polls, premium, profile, questions, quizzes, research, search, tags, verify-certificate, wallet, write

---

## 5) API Namespaces (99 مساحة معرفة name تحت api)

academy, achievements, activity-log, admin, ads, advertiser, ai, analytics, articles, assessment, auth, bookmarks, cache, candidate-invitations, candidates, chat-rooms, comments, commissions, communities, companies, company, company-reviews, connections, consultations, coupons, cv-bank, cv-builder, cv-service, dashboard, debug, dictionary, discussions, download, economic, economy, education, errors, events, expert-market, expert-verification, feed, finance, follows, hashtags, health, images, interviews, investment-bank, iraq-map, jobs, landing-stats, leaderboard, likes, map, marketplace, mentorship, messages, moderation, notifications, offers, owner, payment, payment-destination, payment-gateways, payment-info, payments, polls, posts, pricing, professional-profile, promote, push, questions, recommendations, referrals, reports, reposts, reputation, research, saved-searches, search, security, seed, settings, subscription, subscriptions, talent-pools, translate, tts, u, uploads, users, wallet

---

## 6) نماذج Prisma (260 Model)

أهم الفئات (تصنيف أولي):
- **الهوية/الحسابات:** User, UserSession, ProfileImage, PasswordResetCode, WebAuthnCredential, Referral/ReferralCode, AccountDeletionRequest, PasswordChangeLog, UserCompanyRole
- **الملفات المهنية (CV):** CvVersion, CvAnalytics, CvFile, CvTemplate, CvJobMatch, CvRecommendation, CvCoverLetter, SkillGraph, CvBankSubscription, CvBankSearchLog
- **الوظائف:** Job, JobApplication, SavedJob, JobMessage, JobSocialShare, JobScreeningQuestion, ScreeningAnswer, ApplicationStageChange, CandidateNote, CandidateRating, SavedCandidate, CandidateInvitation, SavedSearch, Interview, InterviewEvaluation, Offer, Employee, TalentPool, TalentPoolMember, PipelineStage
- **الشركات:** Company, CompanyReview, CompanyTest, CompanyTestResult, CompanyFreePeriod, UserCompanyRole
- **الاقتصاد:** SalaryData, EconomicTerm, EconomicAlert, AutoBriefing, InvestmentOpportunity, DistressedProject, Partnership
- **الاستثمار:** InvestorProfile, InvestorFavorite, InvestmentMeeting, DataRoomFile, InvestmentMatch
- **الخبراء/الاستشارات:** ExpertService, ExpertServiceOrder, Consultation, ConsultationMessage, ExpertProfile, ExpertBooking, ExpertReview, ExpertFavorite, ExpertVerification, ExpertWorkspace, ConsultingRequest, ConsultingOffer
- **المحتوى:** Article, ArticleTag, ArticleMedia, ArticleSeries, SeriesArticle, ArticleView, ArticleAnalytics, Hashtag, Post, Repost, Comment, Like, Report
- **الأسئلة/النقاشات:** Question, Answer, QuestionVote, QuestionTag, QuestionComment, QuestionBounty, QuestionBookmark, QuestionCommunity, QuestionUpvote, Discussion, DiscussionReply, DiscussionReplyVote, DiscussionEvent
- **التعلم/الاختبارات:** LearningPath, CourseSection, Lesson, Enrollment, CourseReview, CourseCoupon, CourseOrder, CourseFavorite, CourseNote, LessonDiscussion, UserLessonProgress, Quiz, QuizQuestion, QuizAttempt, QuizOptionRecord, QuizAnswer, Assessment, AssessmentQuestion, AssessmentAttempt, AssessmentAnswer, Certification
- **المهارات/الإنجازات:** SkillPassport, SkillPassportEntry, UserSkill, UserSpecialization, Achievement, UserAchievement, AchievementChain, Badge, UserBadge, SeasonalChallenge, HonorBoard, LearningPoint, UserLearningProfile, PersonalizedRecommendation, UserMilestone, SkillAssessment
- **التوظيف/العلاقات:** Connection, Follow, ReputationPoint, UserReputation
- **السوق:** MarketplaceCategory, MarketplaceProfile, MarketplaceStore, MarketplaceService, MarketplaceProduct, MarketplaceReview, MarketplaceOrder, MarketplaceCoupon, MarketplaceServiceRequest, MarketplaceOffer, MarketplaceFavorite
- **الإعلانات/الترويج:** Ad, AdvertiserAccount, PromotionCampaign, PromotionCampaign, Commission, CommissionConfig
- **المالية/المحفظة:** Wallet, WalletTransaction, TopUpRequest, GiftCard, WithdrawalRequest, Invoice, Payment, PricingConfig, ServicePrice, PaymentDestination, Coupon, CouponUsage
- **الاشتراك:** Subscription, SubscriptionPlan, PushSubscription
- **البحث:** Research, ResearchTag, ResearcherProfile, ResearchCitation, StudyRequest, ResearchProject, ResearchFunding, ResearchWorkspace, WorkspaceMember, PeerReview, QaSession, QaQuestion, QaParticipant
- **الفعاليات:** Event, EventRegistration, EventSpeaker, EventSponsor, EventSession, EventCertificate, EventSurvey, EventGalleryItem
- **المراسلة/المحادثة:** Message, MessageReaction, MessageReadReceipt, ChatRoom, ChatRoomMessage, Conversation, ConversationParticipant
- **الأمان/التدقيق:** AuditLog, SecurityEvent, ApiKeyRecord, SystemError, SystemHealth, ErrorReport, UserActivityLog, UserActivity, AIOperationLog, AiLog, AnalyticsEvent
- **المجتمعات:** Community, CommunityMember, CommunityPost, VoiceRoom, RoomParticipant, Debate, DebateArgument (DebateVote)
- **القراءة/النشر:** ReadingList, ReadingListItem, Story, StoryView, Newsletter, NewsletterSubscription, PublishChannel, PublishLog, PublishAnalytics
- **التمويل الرقمي:** CvBankSubscription, CvBankSearchLog, CvJobMatch
- **نماذج فرعية/مساندة:** Notification, NotificationPreference, AutomatedContent/ContentAnalysis, ScheduledContent, ProfileView, ProfileViewLog, Recommendation

### Enums (22):
`UserRole ArticleCategory ArticleStatus LikeType ConnectionStatus DiscussionCategory NotificationType SubscriptionPlan MarketplaceProfileKind MarketplacePricingMethod MarketplaceProductCondition MarketplaceOrderStatus MarketplaceRequestStatus MarketplaceOfferStatus MarketplaceReviewTarget PipelineStage CvBankTier ContactMethod MessageType SubscriptionStatus LessonDifficulty CompanySize`

---

## 7) بيئة التشغيل والتطبيق (scripts)

| الأمر | الوظيفة |
|---|---|
| `npm run dev` | تشغيل dev عبر dev.sh |
| `npm run build` | next build + copy-standalone |
| `npm run start` | تشغيل standalone على PORT=3300 HOSTNAME=0.0.0.0 |
| `npm run typecheck` | tsc --noEmit (الفحص النوعي المعتمد) |
| `npm run lint` | eslint . |
| `npm run test` | vitest run (20 ملف اختبار) |
| `db:push / db:generate / db:migrate / db:reset / db:seed` | إدارة Prisma |
| `jobs:worker / jobs:worker:dev` | BullMQ worker |
| `notif:build / notif:start` | خدمة الإشعارات المنفصلة |
| `create-admin` | إنشاء مدير |

---

## 8) المتغيرات البيئية (مرجع `.env.example` — 8.6KB)

فئات رئيسية: DATABASE_URL / DIRECT_URL، REDIS_URL، MINIO (S3) keys، JWT_SECRET / ENCRYPTION_KEY / INTERNAL_API_SECRET، CSRF_SECRET / SESSION_SECRET، NEXT_PUBLIC_APP_URL / NEXT_PUBLIC_SITE_URL / CORS_ORIGIN / S3_PUBLIC_URL، Telegram/Push، SMTP، إلخ.

### ملاحظات بيئة النشر الحالية (من التعديلات السابقة)
- `DATABASE_URL` → عبر `pgbouncer:5432` (pool)
- `DIRECT_URL` → عبر `postgres:5432`
- `REDIS_URL = redis://redis:6379`
- MinIO keys: `maydan_admin_2026` / `MaydanS3_StrongKey_8f2c91ab473d`
- `NEXT_PUBLIC_APP_URL / SITE_URL / CORS_ORIGIN / S3_PUBLIC_URL` = placeholder `https://midaniq.com` (النطاق النهائي لم يُحدَّد — يمنع تفعيل Caddy 80/443 حتى يُقدَّم)
- `APP_REPLICAS=1`
- Cloudflared معطّل في compose (يستخدم Caddy)

---

## 9) طبقات الأمان/البنية (من middleware.ts + ARCHITECTURE.md)

- Hybrid routing: `(main)/` بدون segment لغة + rewrite to strips `/:locale`, مع قائمة استثناء localesOnlyPages.
- **Edge layer (middleware.ts)**: upload rewrite, CSRF double-submit, per-IP rate limit (2000/min), route-level auth guard, blacklist token, anti-scraping, geo-access-control.
- **API layer → Service layer → Data layer (Prisma)**.
- بنية ARchitecture.md تسرد 4-5 طبقات أمان.
- CSP في next.config.ts مع `frame-ancestors 'none'`, HSTS, uploads caching immutable, sw.js no-cache.

---

## 10) ملاحظات أولية عن "قِيم" / مجالات خطر محتملة (Phase 1 — لا تعديل بعد)

1. **قراءة `.env`** تحتوي أسرار إنتاج حقيقية (موجودة الآن بالفعل) — يجب عدم كشفها في أي مخرجات.
2. **`ignoreBuildErrors: true`** — فحص النوع معزول في `typecheck`؛ أي تكامل يجب الالتزام بالفحص `npm run typecheck`.
3. **428 route API لكن تصنيف الحجم كبير** — سيُبنى `API_DEPENDENCY_MATRIX` لاحقاً في مراحل متقدمة (تلقائياً).
4. **وثائق قديمة بخصوص أعداد (227 نموذج)** تختلف عن الحالي (260) — سيُحدَّث لاحقاً في مرحلة التوثيق.
5. **`cache/`, `docs/`, `examples/`، ملفات بخلفية تاريخية (FIXES-REPORT, DEVELOPMENT-REPORT, SIDEBAR-UPDATE…)** — مرشحة لمرحلة تنظيف منفصلة (لا تُمس هنا).
6. **الترجمة client-side عبر localStorage** — معنى أن المحتوى يُخدَم بالعربية/الإنجليزية حسب الإعداد المحلي.
7. النطاق placeholder (midaniq.com) — لا يعيق التدقيق.

---

## 11) أعراف يجب الالتزام بها طوال المراحل
- لا إعادة كتابة شاملة؛ أقل تغييرات ممكنة.
- قراءة الكود/الاستدعاءات/imports/routes قبل أي تعديل؛ ممنوع التخمين.
- ممنوع TODO/FIXME/Coming Soon/mock/fake في الإنتاج.
- لا كسر API حالية.
- كل زر قابل للتتبع (Button→Handler→API→Auth→Permission→Validation→Service→Database→Transaction→Notification→Audit→Analytics→Cache→UI).
- بعد كل مرحلة: STOP/REPORT/VERIFY/TEST/DOCUMENT/CONTINUE.
- الفحص النوعي `npm run typecheck` قبل اعتبار أي تعديل صحيحاً.

---

## 12) مقاييس تحقق المرحلة 1 (Inventory)
- ✔ تعداد الملفات والأدلة والـ models والـ enums والـ routes.
- ✔ تحديد طبقات البنية والمكتبات والـ scripts وenv vars.
- ✔ تحديد مجموعات الصفحات ومساحات API.
- ⏳ لم يُنفَّذ بعد: Sitemap (Phase 2)، Page→Backend Map (Phase 3)، وكل مرحلة لاحقة.

**NEXT PHASE: PHASE 2 — SYSTEM_SITEMAP.md**
