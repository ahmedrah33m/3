# DEAD_CODE_REPORT.md
## Phase 21 — Dead Code / النماذج اليتيمة | منصة ميدان

**التاريخ:** 2026-08-28
**الأسلوب:** تحليل نصّي شامل لكل مستودع (src + prisma + seed + الصياغة) لنماذج 260، مع فصل "يتيمة فعلياً" عن "مستخدَمة بطريقة غير مباشرة".

---

## 1) المنهجية
- الكشف الأوّلي: النماذج التي لا يوجد لها أي مرجع مباشر `db.<model>` في `src/` → 56 نموذجاً (من `core_analysis2.py`).
- التحقق المعمّق (`orphan_deep.py`): بحث **نصّي كامل** (أي ذكر للنموذج بأي صيغة) في كل الملفات (src, prisma, seed, sql, types).
- النتيجة: انهيار القائمة إلى **يتيمة حقيقية** مقابل **إيجابيات كاذبة**.

---

## 2) النماذج اليتيمة المؤكدة (تُرجع الـ db.<model> ولم يرد ذكرها إلا في schema، لا كود/سيّد/أنواع)
هذه مرشّحات **حقيقية** للحذف/العزل (غير مبنية أو معطّلة):

AchievementChain, AssignmentSubmission, CompanyTest, CompanyTestResult, CourseCoupon, CourseFavorite, CourseNote, CourseReview, CvCoverLetter, CvJobMatch, CvRecommendation, CvTemplate, DataRoomFile, EventGalleryItem, EventSurvey, InvestmentMatch, LearningPoint, LessonDiscussion, QuestionBankItem, QuestionBookmark, QuestionBounty, QuestionCommunity, ResearchCitation, ResearchFunding, SkillAssessment, SkillPassportEntry, TermCalculator, TermQuiz, UserMilestone, UserReputation

> **≈ 30 نموذجاً** — لا يوجد معالج/خدمة/واجهة تقرؤها أو تكتبها. معظمها لنطاقات غير مفعّلة (Research, Investment, Events, Education, Quiz, Cv advanced, Skills).

---

## 3) إيجابيات كاذبة (مستخدَمة بطريقة غير مباشرة — تُستبعد من "يتيمة")
| النموذج | الدليل |
|---|---|
| `Badge` | 171 مرجعاً (admin dashboards, analytics, etc.) — مستخدَم عبر العلاقات |
| `ExpertVerification` | حقيقية (routes `expert-verification/admin`) لكن فيها MOCK |
| `EventSpeaker/Session/Sponsor` | مستخدَمة في EventsView |
| `WebAuthnCredential` | مستخدَم في `lib/security/webauthn.ts` |
| `ApiKeyRecord/SecurityEvent/ErrorReport/PasswordChangeLog` | في `prisma/seed.ts` (تُكتب لاحقاً) |
| `ResearchProject` | في `src/types/index.ts` |

---

## 4) ملاحظات إضافية (stubs غير موصولة)
- نماذج تظهر فقط في ملفات `prisma/schema-additions-*.prisma` (لم تُدمج في الكود):
  `JobScreeningQuestion`, `ScreeningAnswer`, `UserCompanyRole`, `PeerReview`, `ResearchWorkspace`, `WorkspaceMember`, `PublishAnalytics`
  → **ميزات مخطط لها/غير مبنية** تؤكد أن الـ schema يضم جداول كثيرة بلا تنفيذ.
- `prisma/seed.ts` يزرع سجلات لـ (Badge, ApiKeyRecord, SecurityEvent, ErrorReport, PasswordChangeLog) دون وجود دالة قراءة عبرها → **كتابة بلا قراءة** (بيانات مكدّسة بلا استخدام) — توصية للتطبيق.

---

## 5) التوصية (لا تُنفَّذ الآن تلقائياً — تدخل في صلاحية Owner)
- **لا تحذف فوراً:** حتى النماذج "اليتيمة المؤكدة" يُنصح بالاحتفاظ بها إذا كانت نطاقات مخططاً لها (Roadmap).
- **الخطوة الآمنة التالية:** إنشاء قائمة FIFO بمراجعة Owner لتصنيف كل نموذج (احتفاظ/إزالة/إكمالFeature).
- **أثر على 0 BROKEN CORE FLOWS:** لا شيء من النماذج اليتيمة يشارك في flow أساسي (لم يرد ذكره في كود) → لا خطر كسر.

## 6) حالتها مقابل الأهداف
- لا تُعتبر "يتيمة" = ثغرة؛ هي **انتفاخ Schema** (ميزات غير مبنية) — تُوثَّق للتنظيف المتأني خلف Owner، وليس إزالة عشوائية (التزاماً بـ MUST-NOT).
