#!/usr/bin/env python3
import os, re

BASE='/home/ahmed/maydan'
SRC=BASE+'/src'

sc=open(BASE+'/prisma/schema.prisma',encoding='utf-8').read()
models=[m for m in re.findall(r'^model\s+(\w+)', sc, re.M)]
model_set=set(models)

# known orphan list from core_analysis2 (db.<model> never referenced)
orphans = set('AchievementChain AiLog ApiKeyRecord Assignment AssignmentSubmission Badge CompanyTest CompanyTestResult ContentAnalysis CourseCoupon CourseFavorite CourseNote CourseReview CvCoverLetter CvJobMatch CvRecommendation CvTemplate DataRoomFile EconomicAlert ErrorReport EventGalleryItem EventSession EventSpeaker EventSponsor EventSurvey ExpertVerification InvestmentMatch JobScreeningQuestion LearningPoint LessonDiscussion Newsletter NewsletterSubscription PasswordChangeLog PeerReview PublishAnalytics QuestionBankItem QuestionBookmark QuestionBounty QuestionCommunity ResearchCitation ResearchFunding ResearchProject ResearchWorkspace ScreeningAnswer SecurityEvent SkillAssessment SkillPassportEntry TermCalculator TermQuiz UserCompanyRole UserMilestone UserReputation UserSocialLink UserSpecialization WebAuthnCredential WorkspaceMember'.split())

def walk(root):
    for dp,dn,fn in os.walk(root):
        if 'node_modules' in dp or '.git' in dp: continue
        for f in fn:
            if f.endswith(('.ts','.tsx','.js','.sql','.prisma','.json')):
                yield os.path.join(dp,f)

# gather all file contents once
contents={}
for fp in walk(BASE):
    try: contents[fp]=open(fp,encoding='utf-8',errors='replace').read()
    except: pass

print("MODEL | any-textual-ref | ref-count | first-locations")
for m in sorted(orphans):
    refs=[]
    low=m[0].lower()+m[1:]
    for fp,s in contents.items():
        if re.search(r'\b'+re.escape(m)+r'\b', s) or re.search(r'\b'+re.escape(low)+r'\b', s):
            refs.append(os.path.relpath(fp,BASE))
    # dedup
    refs=sorted(set(refs))
    print(f"{m} | {len(refs)} | {refs[:4]}")
