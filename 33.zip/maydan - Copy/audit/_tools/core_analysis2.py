#!/usr/bin/env python3
# Corrected model usage analysis — models accessed as `db.<lowercase>`
import os, re
from collections import Counter

BASE='/home/ahmed/maydan/src'
sc=open('/home/ahmed/maydan/prisma/schema.prisma',encoding='utf-8').read()
models=[m for m in re.findall(r'^model\s+(\w+)', sc, re.M)]
# also enums might look like models — filter to top-level model blocks
model_set={m for m in re.findall(r'^model\s+(\w+)', sc, re.M)}

def walk(root):
    for dp,dn,fn in os.walk(root):
        if 'node_modules' in dp: continue
        for f in fn:
            if f.endswith(('.ts','.tsx')): yield os.path.join(dp,f)

usage=Counter(); used_in={}
allfiles=list(walk(BASE))
print("files scanned:", len(allfiles))
for fp in allfiles:
    try: s=open(fp,encoding='utf-8',errors='replace').read()
    except: continue
    for m in model_set:
        low=m[0].lower()+m[1:]
        if re.search(r'\bdb\.'+low+r'\b', s):
            usage[m]+=1
            used_in.setdefault(m,[]).append(os.path.relpath(fp,'/home/ahmed/maydan'))

orphans=[m for m in sorted(model_set) if usage[m]==0]
low=[(m,usage[m]) for m in model_set if 0<usage[m]<=2]
print("models:",len(model_set),"used:",len(usage),"orphans(db.<model> never referenced):",len(orphans))
print("\nORPHAN MODELS:")
print(", ".join(orphans) if orphans else "none")
print("\nLOW-USAGE (<=2):")
for m,c in sorted(low,key=lambda x:(x[1],x[0])): print(f"  {m}: {c}")
