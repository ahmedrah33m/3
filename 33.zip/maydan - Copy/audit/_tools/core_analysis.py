#!/usr/bin/env python3
# Core audit analysis: model usage, financial/audit/notification wiring signal
import os, re, csv
from collections import Counter, defaultdict

BASE='/home/ahmed/maydan/src'

# ----- 1) Model usage across src (routes+services+lib+components) -----
model_names=None
# parse prisma schema model names
sc=open('/home/ahmed/maydan/prisma/schema.prisma',encoding='utf-8').read()
models=[m for m in re.findall(r'^model\s+(\w+)', sc, re.M)]

def walk(root):
    for dp,dn,fn in os.walk(root):
        for f in fn:
            if f.endswith(('.ts','.tsx')):
                yield os.path.join(dp,f)

usage=Counter()
used_in={}
for fp in walk(BASE):
    try:
        s=open(fp,encoding='utf-8',errors='replace').read()
    except: continue
    rel=os.path.relpath(fp,'/home/ahmed/maydan')
    for m in models:
        # prisma.<model> OR .<lowercased>
        if re.search(r'prisma\.'+m+r'\b', s):
            usage[m]+=1
            used_in.setdefault(m,[]).append(rel)

orphans=[m for m in models if usage[m]==0]
low=[(m,usage[m]) for m in models if 0<usage[m]<=2]
print("models:",len(models),"used:",len(usage),"orphans(zero refs via prisma.):",len(orphans))
print("\nORPHAN MODELS (no prisma.<model> reference in src):")
print(", ".join(orphans))
print("\nLOW-USAGE MODELS (<=2 refs):")
for m,c in sorted(low,key=lambda x:x[1]): print(f"  {m}: {c}")

# ----- 2) Financial wiring: routes calling wallet/payment service + tx -----
print("\n=== WALLET/PAYMENT related route dirs ===")
for dp,dn,fn in os.walk(BASE+'/app/api'):
    if 'route.ts' in fn:
        fp=os.path.join(dp,'route.ts')
        s=open(fp,encoding='utf-8',errors='replace').read()
        if any(k in s for k in ['wallet-service','WalletTransaction','payFromWallet','$transaction','payment-service']):
            rel=os.path.relpath(fp,'/home/ahmed/maydan')
            tx='TX' if '$transaction' in s else ''
            ws='WALLET' if ('wallet-service' in s or 'payFromWallet' in s or 'WalletTransaction' in s) else ''
            ps='PAY' if 'payment-service' in s else ''
            print(f" {rel} {tx} {ws} {ps}".strip())
import os as _o
