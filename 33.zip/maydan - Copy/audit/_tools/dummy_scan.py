#!/usr/bin/env python3
import os, re

BASE='/home/ahmed/maydan/src'

def walk(root):
    for dp,dn,fn in os.walk(root):
        if 'node_modules' in dp: continue
        for f in fn:
            if f.endswith('.ts') and ('api' in dp or 'service' in dp or 'lib' in dp):
                yield os.path.join(dp,f)

# patterns indicating dummy/placeholder business data
markers = [
    (r"in\s+production[^,\n]{0,40}would", "IN_PRODUCTION_WOULD"),
    (r"TODO[\s:]+(real|actual|dummy|fill|implement)", "TODO_REAL"),
    (r"placeholder|dummy\s+data|fake\s+data|mock\s+data", "PLACEHOLDER"),
    (r"(totalRevenue|monthlyRevenue|netProfit|churnRate|activeSubscriptions)\s*[:=]\s*\d[\d_]{3,}", "HARDCODED_FIN"),
    (r"//\s*mock|//\s*fake|//\s*stub", "MOCK_COMMENT"),
]

hits=[]
for fp in walk(BASE):
    try: s=open(fp,encoding='utf-8',errors='replace').read()
    except: continue
    found=[]
    for pat,tag in markers:
        if re.search(pat, s, re.I): found.append(tag)
    if found:
        hits.append((fp, found))

print("files with dummy/placeholder markers:", len(hits))
for fp,tags in sorted(hits):
    rel=fp.replace('/home/ahmed/maydan/','')
    print(f"  {rel}  -> {','.join(tags)}")
