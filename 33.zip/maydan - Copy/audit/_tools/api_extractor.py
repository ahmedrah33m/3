#!/usr/bin/env python3
# API Dependency Extractor — scans all route.ts under app/api and builds matrix CSV
import os, re, csv, sys

BASE = '/home/ahmed/maydan/src/app/api'
OUT  = '/home/ahmed/maydan/audit/API_DEPENDENCY_MATRIX.csv'

# collect all service names from services dir (file basenames)
services_dir = '/home/ahmed/maydan/src/services'
service_names = set()
for fn in os.listdir(services_dir):
    if fn.endswith('.ts'):
        service_names.add(fn.replace('.ts','').replace('.service',''))

# lib files that act as services (wallet/payment/notification etc)
extra_services = {
  'wallet-service','payment-service','payment-gateway','notification','chat-service',
  'search-engine','reputation','achievements','audit','activity-logger','analytics-server',
  'tryParse','recommendations'}

GUARD_RE = re.compile(r'(\brequireAuth\b|\brequireAdmin\b|\brequireOwner\b|\brequireOwnerOrAdmin\b|\boptionalAuth\b|\bgetCurrentUser\b|\brequireRole\b|\bhasRole\b|\bverifyToken\b)')
SERVICE_RE = re.compile(r'[@/]services/(\w+)|from\s+["\']@/(services/(\w+))|@/services/')
NOTIF_IMPORT = re.compile(r'import\b[^;]*?notification[^;]*?;', re.I)

rows = []
header = ["Endpoint","Method","Auth","Permission","Transaction","Services","Models","Notification","Status"]

for root, dirs, files in os.walk(BASE):
    if 'route.ts' not in files:
        continue
    route_path = os.path.relpath(root, BASE)
    # build URL path
    path_parts = []
    for seg in route_path.split(os.sep):
        if seg.startswith('[') and seg.endswith(']'):
            path_parts.append(':'+seg[1:-1])
        else:
            path_parts.append(seg)
    url = '/api/' + '/'.join(path_parts)
    fpath = os.path.join(root, 'route.ts')
    try:
        src = open(fpath, encoding='utf-8', errors='replace').read()
    except Exception:
        continue

    # methods — route handlers exported as `export async function GET(`, `export function POST(`
    methods = []
    for m in ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS']:
        if re.search(r'export\s+(?:async\s+)?function\s+'+m+r'\s*\(', src) or re.search(r'export\s+const\s+'+m+r'\s*=', src):
            methods.append(m)
    method = '+'.join(methods) if methods else '?'

    # auth guards
    guards = set(GUARD_RE.findall(src))
    auth = 'NONE_PUBLIC'
    perm = 'NONE'
    if guards:
        auth = 'AUTH'
        if 'requireAdmin' in guards: perm = 'ADMIN'
        elif 'requireOwner' in guards: perm = 'OWNER'
        elif 'requireOwnerOrAdmin' in guards: perm = 'OWNER|ADMIN'
        elif 'requireRole' in guards or 'hasRole' in guards: perm = 'ROLE-CHECK'
        # auth guard but no permission
    if 'getCurrentUser' in guards or 'optionalAuth' in guards:
        if auth=='AUTH' and 'require' not in str(guards):
            auth = 'OPTIONAL'
    if 'verifyToken' in guards and 'require' not in str(guards):
        auth = 'TOKEN'

    # transaction (prisma.$transaction)
    has_tx = '$transaction' in src

    # services
    svc = set()
    for s in service_names:
        if s in src:
            svc.add(s)
    for es in extra_services:
        if es in src:
            svc.add(es)
    # also service import via @/services/x
    for mm in re.finditer(r'@/services/([\w\-]+)', src):
        svc.add(mm.group(1))
    # lib/wallet-service style
    for mm in re.finditer(r'@/lib/([\w\-]+(?:service)?)', src):
        nm = mm.group(1)
        if 'service' in nm or 'engine' in nm or nm in extra_services:
            svc.add(nm)

    # models: prisma.<model> or model names appearing uppercase in PrismaClient field access
    models = set()
    for mm in re.finditer(r'\bprisma\.([a-zA-Z][a-zA-Z0-9_]{1,40})', src):
        models.add(mm.group(1))
    if 'prisma' in src and not models:
        models.add('?')

    # notification
    notif = 'YES' if (NOTIF_IMPORT.search(src) or 'notification' in src.lower() and ('notif' in src.lower())) else ''

    rows.append([url, method, auth, perm, 'TX' if has_tx else '', ';'.join(sorted(svc)), ';'.join(sorted(models)), notif, 'ACTIVE'])

# write CSV
with open(OUT,'w',encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(header)
    for r in rows:
        w.writerow(r)

print("routes:", len(rows))
print("auth breakdown:")
from collections import Counter
c = Counter([r[2] for r in rows])
for k,v in c.items(): print(" ", k, v)
print("perm breakdown:")
c2 = Counter([r[3] for r in rows])
for k,v in c2.items(): print(" ", k, v)
print("with tx:", Counter([r[4] for r in rows]).get('TX',0))
