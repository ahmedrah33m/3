#!/usr/bin/env python3
# API Dependency Extractor (v2) — extended to recognize ownership/role patterns
import os, re, csv

BASE = '/home/ahmed/maydan/src/app/api'
OUT  = '/home/ahmed/maydan/audit/API_DEPENDENCY_MATRIX.csv'

services_dir = '/home/ahmed/maydan/src/services'
service_names = set()
for fn in os.listdir(services_dir):
    if fn.endswith('.ts'):
        service_names.add(fn.replace('.ts','').replace('.service',''))

extra_services = {
  'wallet-service','payment-service','payment-gateway','notification','chat-service',
  'search-engine','reputation','achievements','audit','activity-logger','analytics-server',
  'tryParse','recommendations'}

GUARD_RE = re.compile(r'(\brequireAuth\b|\brequireAdmin\b|\brequireOwner\b|\brequireOwnerOrAdmin\b|\boptionalAuth\b|\bgetCurrentUser\b|\brequireRole\b|\bhasRole\b|\bverifyToken\b)')
SERVICE_RE = re.compile(r'[@/]services/(\w+)|from\s+["\']@/(services/(\w+))|@/services/')
NOTIF_IMPORT = re.compile(r'import\b[^;]*?notification[^;]*?;', re.I)

# custom role helpers (any require/check with Role in name, or role-array membership)
ROLE_HELPER_RE = re.compile(r'require\w*Role\b|ensure\w*Role\b|FINANCE_ROLES\b|\w+_ROLES\b|\.role\s*===?\s*"(?:ADMIN|OWNER|MODERATOR)"')
# ownership / self-scoping evidence: comparisons of a resource field to user.id, or where{...userId:user.id}
OWNER_RE = re.compile(
    r'(?:\.(?:userId|ownerId|authorId|senderId|buyerId|sellerId|expertId|creatorId|publishedBy|clientId|providerId|invitedById|candidateId)\s*===?\s*user\.id'
    r'|where:\s*\{[^}]*?(?:userId|ownerId|authorId|senderId|buyerId|sellerId)\s*:\s*user\.id'
    r'|(?:isBuyer|isOwner|isSeller|isExpert|isPublisher|isAdmin)\b'
    r'|(?:authorId|ownerId|userId)\s*!==\s*user\.id)'
)
FIND_SCOPED_RE = re.compile(r'(?:findFirst|findUnique|findMany|updateMany|deleteMany|delete)\s*\([^)]*where:\s*\{[^}]*user\.id')

rows = []
header = ["Endpoint","Method","Auth","Permission","Transaction","Services","Models","Notification","Status"]

for root, dirs, files in os.walk(BASE):
    if 'route.ts' not in files:
        continue
    route_path = os.path.relpath(root, BASE)
    path_parts = []
    for seg in route_path.split(os.sep):
        if seg.startswith('[') and seg.endswith(']'):
            path_parts.append(':'+seg[1:-1])
        else:
            path_parts.append(seg)
    url = '/api/' + '/'.join(path_parts)
    fpath = os.path.join(root, 'route.ts')
    try:
        src = open(fpath, encoding='utf-8', errors='replace').read()
    except Exception:
        continue

    methods = []
    for m in ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS']:
        if re.search(r'export\s+(?:async\s+)?function\s+'+m+r'\s*\(', src) or re.search(r'export\s+const\s+'+m+r'\s*=', src):
            methods.append(m)
    method = '+'.join(methods) if methods else '?'

    guards = set(GUARD_RE.findall(src))
    auth = 'NONE_PUBLIC'
    perm = 'NONE'
    if guards:
        auth = 'AUTH'
        if 'requireAdmin' in guards: perm = 'ADMIN'
        elif 'requireOwner' in guards: perm = 'OWNER'
        elif 'requireOwnerOrAdmin' in guards: perm = 'OWNER|ADMIN'
        elif 'requireRole' in guards or 'hasRole' in guards: perm = 'ROLE-CHECK'
    if 'getCurrentUser' in guards or 'optionalAuth' in guards:
        if auth=='AUTH' and 'require' not in str(guards):
            auth = 'OPTIONAL'
    if 'verifyToken' in guards and 'require' not in str(guards):
        auth = 'TOKEN'

    # ---- v2: detect custom role helpers and ownership scoping when perm is still NONE ----
    if perm == 'NONE':
        if ROLE_HELPER_RE.search(src):
            perm = 'ROLE-CHECK'
        elif OWNER_RE.search(src) or FIND_SCOPED_RE.search(src):
            perm = 'SELF-OWNED'

    has_tx = '$transaction' in src

    svc = set()
    for s in service_names:
        if s in src: svc.add(s)
    for es in extra_services:
        if es in src: svc.add(es)
    for mm in re.finditer(r'@/services/([\w\-]+)', src):
        svc.add(mm.group(1))
    for mm in re.finditer(r'@/lib/([\w\-]+(?:service)?)', src):
        nm = mm.group(1)
        if 'service' in nm or 'engine' in nm or nm in extra_services:
            svc.add(nm)

    models = set()
    for mm in re.finditer(r'\bprisma\.([a-zA-Z][a-zA-Z0-9_]{1,40})', src):
        models.add(mm.group(1))
    if 'prisma' in src and not models:
        models.add('?')

    notif = 'YES' if (NOTIF_IMPORT.search(src) or 'notification' in src.lower() and ('notif' in src.lower())) else ''

    rows.append([url, method, auth, perm, 'TX' if has_tx else '', ';'.join(sorted(svc)), ';'.join(sorted(models)), notif, 'ACTIVE'])

with open(OUT,'w',encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f); w.writerow(header); w.writerows(rows)

print("routes:", len(rows))
from collections import Counter
print("perm breakdown:")
for k,v in sorted(Counter([r[3] for r in rows]).items()): print(" ", k, v)
print("auth breakdown:")
for k,v in sorted(Counter([r[2] for r in rows]).items()): print(" ", k, v)
