#!/usr/bin/env python3
# Button Dependency Extractor — scans components + app for interactive elements
import os, re, csv
from collections import Counter

BASE = '/home/ahmed/maydan/src'
OUT  = '/home/ahmed/maydan/audit/BUTTON_DEPENDENCY_MATRIX.csv'

def files_under(root):
    for dp, dn, fn in os.walk(root):
        for f in fn:
            if f.endswith('.tsx') or (f.endswith('.ts')):
                yield os.path.join(dp, f)

# interactive element patterns
BTN_TAG = re.compile(r'<button\b', re.I)
ONCLICK = re.compile(r'\bonClick\s*=\s*\{')
ONSUBMIT = re.compile(r'\bonSubmit\s*=\s*\{')
FETCH_CALL = re.compile(r'\bfetch\s*\(|useMutation|mutate\s*\(|/api/')
API_PAT = re.compile(r'["\'](/api/[^"\']*)["\']')
HANDLER = re.compile(r'(?:onClick|onSubmit)="?\{?\s*([\w$]+)\s*(?:\(|=>|\})')
LINK = re.compile(r'<Link\b|\brouter\.push|\brouter\.replace|href=')

rows = []
status_counter = Counter()

for f in files_under(BASE):
    if '\\.next' in f or 'node_modules' in f:
        continue
    try:
        src = open(f, encoding='utf-8', errors='replace').read()
    except Exception:
        continue
    rel = os.path.relpath(f, '/home/ahmed/maydan')
    nbtn = len(BTN_TAG.findall(src))
    nonclick = len(ONCLICK.findall(src))
    nonsubmit = len(ONSUBMIT.findall(src))
    if nbtn == 0 and nonclick == 0 and nonsubmit == 0:
        continue
    apis = sorted(set(API_PAT.findall(src)))
    has_fetch = bool(FETCH_CALL.search(src))
    has_link = bool(LINK.search(src))
    handlers = sorted(set(HANDLER.findall(src)))
    interactive = nbtn + nonclick + nonsubmit

    # status heuristic
    if has_fetch:
        status = 'CONNECTED'
        status_counter['CONNECTED'] += 1
    elif has_link:
        status = 'LINK'
        status_counter['LINK'] += 1
    elif handlers:
        status = 'PARTIALLY_CONNECTED'
        status_counter['PARTIALLY_CONNECTED'] += 1
    else:
        status = 'UNKNOWN'
        status_counter['UNKNOWN'] += 1

    rows.append([rel, interactive, str(nbtn), str(nonclick), str(nonsubmit),
                 ';'.join(handlers) if handlers else '-',
                 'YES' if has_fetch else '',
                 'YES' if has_link else '',
                 ';'.join(apis) if apis else '-',
                 status])

with open(OUT, 'w', encoding='utf-8-sig', newline='') as fp:
    w = csv.writer(fp)
    w.writerow(['Source File', 'Interactive Elements', 'Buttons', 'onClick', 'onSubmit',
                'Handlers', 'Fetches/API', 'Has Link/Navigation', 'APIs Called', 'Status'])
    for r in rows:
        w.writerow(r)

print("component/page files with interactive elements:", len(rows))
print("total interactive elements:", sum(r[1] for r in rows))
print("status breakdown:")
for k, v in status_counter.items():
    print("  ", k, v)
