# TOOL_INVENTORY.md
## جرد أدوات التدقيق — منصة ميدان

**التاريخ:** 2026-08-28 — كل أداة في `audit/_tools/` على السيرفر الجديد، مكتوبة بـ Python3 (نمط سكربت قصير موثوق).

## الأدوات المطوّرة/المستخدمة
| الأداة | الوظيفة | المخرَج |
|---|---|---|
| `api_extractor.py` | فحص كل `route.ts` (428) → methods/أصالة/صلاحية/معاملة | `API_DEPENDENCY_MATRIX.csv` |
| `button_extractor.py` | فحص 204 ملف تفاعلي / 2683 عنصر → ربط زر→handler→API | `BUTTON_DEPENDENCY_MATRIX.csv` |
| `core_analysis.py` | مسح الوصول `db.<model>` + مسارات المال/TX | بيانات النماذج اليتيمة (المصحّحة في core_analysis2) |
| `core_analysis2.py` | نسخة مصحّحة (access عبر `db.<lowercase>`) → 204 مستخدَم/56 يتيمة | تحليل قاعدة البيانات |
| `orphan_deep.py` | بحث نصّي كامل عن النماذج اليتيمة (فصل الحقيقي عن الكاذب) | `DEAD_CODE_REPORT.md` |
| `dummy_scan.py` | بحث أنماط بيانات مزيّفة (in production would/TODO/hardcodedfin) | إصلاح #1 |

## منهج التشغيل
- كل أداة تُرفع عبر SFTP إلى `audit/_tools/` وتُشغَّل محلياً على السيرفر `python3`.
- **اللمس للقراءة فقط** — لم تُعدّل الأدوات أي ملف مصدر (الإصلاح تم يدوياً عبر SFTP بنسخة احتياطية).

## قيود بيئية موثّقة (لمنع التكرار)
- PowerShell المحلي لا يتعامل مع `head`؛ الاقتباسات المتداخلة عبر bash مباشرة تفشل (unterminated string) → نكتب .py عبر أداة write ثم نشغّلها.
- `sudo` يتطلب tty → نستخدم `echo <pass> | sudo -S`.
- السيرفر الجديد: SSH `ahmed@192.168.88.45` / pass `85961200`؛ المشروع `/home/ahmed/maydan`.
- إعادة البناء: `docker compose build app` ثم `up -d app` (standalone build).

## المصداقية
- كل نتيجة تُستخرج من الكود الفعلي لا من التخمين.
- مؤسس الـ CSV (428 API/2683 عنصر) قابل لإعادة الإنتاج بتشغيل الأداة ذاتها.
