/**
 * Batch C: Employment Verification
 */

const fs = require('fs');

// قراءة الملف الحالي
const currentContent = fs.readFileSync('prisma/schema.prisma', 'utf8');

// قراءة نماذج Verification
const verificationContent = fs.readFileSync('prisma/schema-additions-employment-verification.prisma', 'utf8');

// استخراج النماذج
function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.push({ name: currentModel, lines: currentLines });
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.push({ name: currentModel, lines: currentLines });
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.push({ name: currentModel, lines: currentLines });
  return models;
}

const verificationModels = parseModels(verificationContent);
console.log('نماذج Verification:', verificationModels.length);

// التحقق من النماذج الموجودة
const existingModels = new Set();
for (const line of currentContent.split('\n')) {
  const match = line.trim().match(/^model (\w+) \{/);
  if (match) existingModels.add(match[1]);
}

// تصفية النماذج الجديدة فقط
const newModels = verificationModels.filter(m => !existingModels.has(m.name));
console.log('نماذج Verification الجديدة:', newModels.length);

// إضافة النماذج الجديدة
let output = currentContent.trimEnd() + '\n\n';
output += '// ============================================\n';
output += '// Batch C: Employment Verification\n';
output += '// ============================================\n\n';

for (const model of newModels) {
  output += model.lines.join('\n') + '\n\n';
}

fs.writeFileSync('prisma/schema.prisma', output);
console.log('تم إضافة نماذج Verification');
