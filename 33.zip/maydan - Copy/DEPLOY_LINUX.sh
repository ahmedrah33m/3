#!/bin/bash
# ============================================
# Deploy latest code on Linux server
# Run this ON the Linux server
# ============================================

set -e
cd /home/ahmedr/maydan

echo "═══════════════════════════════════════════"
echo "  ميدان - تحديث الكود على الخادم"
echo "═══════════════════════════════════════════"

# 1. Stop current server
echo ""
echo "【1/6】 إيقاف الخادم..."
fuser -k 3300/tcp 2>/dev/null && echo "  ✓ تم إيقاف المنفذ 3300" || echo "  - المنفذ 3300 حر"
sleep 2

# 2. Fix node_modules (broken by chmod)
echo ""
echo "【2/6】 إعادة تثبيت node_modules..."
if [ -d "node_modules" ]; then
    rm -rf node_modules package-lock.json
    echo "  ✓ تم حذف node_modules التالفة"
fi
npm install 2>&1 | tail -5
echo "  ✓ تم تثبيت الحزم"

# 3. Fix broken symlinks
echo ""
echo "【3/6】 إصلاح الحزم..."
chmod +x node_modules/.bin/* 2>/dev/null || true
echo "  ✓ تم الإصلاح"

# 4. Generate Prisma client
echo ""
echo "【4/6】 توليد Prisma..."
npx prisma generate 2>&1 | tail -3 || echo "  - تم التوليد مسبقاً"

# 5. Push schema
echo ""
echo "【5/6】 دفع Schema..."
npx prisma db push --accept-data-loss 2>&1 | tail -5 || echo "  ⚠️  فشل دفع Schema"

# 6. Start server
echo ""
echo "═══════════════════════════════════════════"
echo "【6/6】 تشغيل الخادم..."
echo "═══════════════════════════════════════════"
nohup npx next dev -p 3300 > /tmp/midan.log 2>&1 &
echo "  ✓ تم تشغيل الخادم على المنفذ 3300"
echo ""
echo "  للتحقق: curl http://localhost:3300"
echo "  للسجلات: tail -f /tmp/midan.log"
