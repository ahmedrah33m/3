const fs = require('fs');

// Read original schema
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');

// Read all addition files
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

// Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

const originalModels = parseModels(originalContent);
console.log('Original models:', originalModels.size);

const additionModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [name, lines] of parseModels(content)) {
    additionModels.set(name, lines);
  }
}
console.log('Addition models:', additionModels.size);

// Find new models that don't exist in original
const originalNames = new Set([...originalModels.keys()]);
const newModels = [];
for (const [name, lines] of additionModels) {
  if (!originalNames.has(name)) {
    newModels.push({ name, lines });
  }
}
console.log('New models to add:', newModels.length);

// Find models that need back-relations
const needsBackRelations = new Set();
for (const model of newModels) {
  for (const line of model.lines) {
    const match = line.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
    if (match) {
      const referencedModel = match[2];
      if (originalNames.has(referencedModel)) {
        needsBackRelations.add(referencedModel);
      }
    }
  }
}
console.log('Models needing back-relations:', needsBackRelations.size);

// Rebuild schema - keep original order, add new at end
const lines = originalContent.split('\n');
const output = [];
let currentModel = null;
let braceCount = 0;
let inModel = false;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const trimmed = line.trim();
  
  const match = trimmed.match(/^model (\w+) \{/);
  if (match) {
    currentModel = match[1];
    inModel = true;
    braceCount = 1;
    output.push(line);
    continue;
  }
  
  if (inModel) {
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    
    if (braceCount === 0 && line.includes('}')) {
      // Model is closing - add back-relations if needed
      if (needsBackRelations.has(currentModel)) {
        // Find the model lines in output
        const modelStart = output.findIndex(l => l.includes(`model ${currentModel} {`));
        const modelContent = output.slice(modelStart);
        
        // Check if back-relations already exist
        const hasBackRelations = modelContent.some(l => l.includes('// Back-relations'));
        
        if (!hasBackRelations) {
          // Get the relations from new models
          const relations = [];
          for (const nm of newModels) {
            for (const nl of nm.lines) {
              const relMatch = nl.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
              if (relMatch && relMatch[2] === currentModel) {
                relations.push('  ' + nl.trim());
              }
            }
          }
          
          if (relations.length > 0) {
            output.push('  // Back-relations');
            output.push(...relations);
          }
        }
      }
      
      output.push(line);
      inModel = false;
      currentModel = null;
      continue;
    }
    
    output.push(line);
    continue;
  }
  
  output.push(line);
}

// Add new models at the end
output.push('');
output.push('// ============================================');
output.push('// New Models from Additions');
output.push('// ============================================');
output.push('');

for (const model of newModels) {
  output.push(...model.lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
