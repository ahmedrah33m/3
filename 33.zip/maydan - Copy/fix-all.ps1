$root = "C:\Users\AR\Desktop\New folder (5)\maydan - Copy\src\lib\features"
$files = Get-ChildItem -Path $root -Filter "*.ts" | Where-Object { -not $_.Name.Contains('index') }

$fixed = @()
$skipped = @()

foreach ($file in $files) {
  $path = $file.FullName
  $content = Get-Content -Path $path -Raw -Encoding UTF8
  $original = $content
  $changed = $false

  # ---------- PATTERN 1: Fix duplicate id: string; id: string ----------
  if ($content -match '\bid:\s*string;\s*id:\s*string') {
    $content = $content -replace '\bid:\s*string;\s*id:\s*string;', 'id: string;'
    $changed = $true
  }

  # ---------- PATTERN 2: Fix duplicate createdAt: any; createdAt: Date ----------
  if ($content -match 'createdAt:\s*any;\s*createdAt:\s*Date') {
    $content = $content -replace 'createdAt:\s*any;\s*createdAt:\s*Date', 'createdAt: Date'
    $changed = $true
  }

  # ---------- PATTERN 3: Add uid definition if uid() is used but not defined ----------
  $hasUidUsage = $content -match '\buid\(\)'
  $hasUidDef = $content -match '(const uid|function uid|import.*uid)'

  if ($hasUidUsage -and -not $hasUidDef) {
    # Check if randomBytes is already imported
    $hasRandomBytesImport = $content -match "import.*randomBytes.*from 'crypto'"

    if (-not $hasRandomBytesImport) {
      # Look for the position to insert — after existing imports or after the comment header
      if ($content -match "import \{ getRedis \} from '@/lib/redis';") {
        # Standard template: has getRedis import
        $content = $content -replace "import \{ getRedis \} from '@/lib/redis';",
          "import { getRedis } from '@/lib/redis';`r`nimport { randomBytes } from 'crypto';`r`n`r`nconst uid = (): string => randomBytes(8).toString('hex');"
      } elseif ($content -match "import .+ from '.+';") {
        # Has some other import but not getRedis
        $lastImport = [regex]::Match($content, "import .+ from '.+';", 'RightToLeft')
        if ($lastImport.Success) {
          $pos = $lastImport.Index + $lastImport.Length
          $insert = "`r`nimport { randomBytes } from 'crypto';`r`n`r`nconst uid = (): string => randomBytes(8).toString('hex');"
          $content = $content.Substring(0, $pos) + $insert + $content.Substring($pos)
        }
      } else {
        # No imports at all — add after the comment block
        $content = $content -replace '(// =+\r?\n// [^\n]+\r?\n// =+\r?\n)',
          "`$1import { randomBytes } from 'crypto';`r`n`r`nconst uid = (): string => randomBytes(8).toString('hex');`r`n"
      }
    } else {
      # Has randomBytes but no uid def
      $content = $content -replace "(import \{ randomBytes \} from 'crypto';)",
        "`$1`r`n`r`nconst uid = (): string => randomBytes(8).toString('hex');"
    }
    $changed = $true
  }

  # ---------- PATTERN 4: Fix single-quoted template literals 'prefix-${uid()}' → backticks ----------
  # Match 'something-${uid()}' — single-quoted string containing template expression
  $singleQuoteTpl = [regex]::Match($content, "'([^']*)\$\{uid\(\)\}'")
  if ($singleQuoteTpl.Success -and -not ($singleQuoteTpl.Value -match "^'[^']*'\s*$")) {
    # Simpler approach: just replace common pattern
    $content = $content -replace "'([a-zA-Z0-9_-]+)\$\{uid\(\)\}'", '`$1${uid()}`'
    $changed = $true
  }

  # Broader pattern: any '...${...}' with single quotes
  if ($content -match "'[^']*\$\{[^}]+\}[^']*'") {
    # Replace 'something-${expr}' with `something-${expr}`
    $content = [regex]::Replace($content, "'([^']*(?:\$\{[^}]+\})[^']*)'", '`$1`')
    $changed = $true
  }

  # ---------- PATTERN 5: Add missing getRedis import ----------
  $hasGetRedisUsage = $content -match '\bgetRedis\(\)'
  $hasGetRedisImport = $content -match "import \{ getRedis \} from '@/lib/redis'"

  if ($hasGetRedisUsage -and -not $hasGetRedisImport) {
    # Add after comment block or after existing imports
    $lastImportMatch = [regex]::Match($content, "^import .+ from '.+';", 'RightToLeft')
    if ($lastImportMatch.Success) {
      $pos = $lastImportMatch.Index + $lastImportMatch.Length
      $insert = "`r`nimport { getRedis } from '@/lib/redis';"
      $content = $content.Substring(0, $pos) + $insert + $content.Substring($pos)
    } else {
      # No imports — add after comment
      $content = $content -replace '(// =+\r?\n// [^\n]+\r?\n// =+\r?\n)',
        "`$1import { getRedis } from '@/lib/redis';`r`n"
    }
    $changed = $true
  }

  # ---------- PATTERN 6: Fix behavior-anomaly.ts RedisClient type ----------
  if ($content -match "redis:\s*Awaited<ReturnType<typeof getRedis>>\s*\|\s*null") {
    $content = $content -replace "redis:\s*Awaited<ReturnType<typeof getRedis>>\s*\|\s*null", 'redis: RedisClient'
    # Add type alias if not present
    if (-not ($content -match 'type RedisClient')) {
      $content = $content -replace "(import \{ getRedis \} from '@/lib/redis';)",
        "`$1`r`n`r`ntype RedisClient = NonNullable<Awaited<ReturnType<typeof getRedis>>>"
    }
    $changed = $true
  }

  # ---------- Save if changed ----------
  if ($changed) {
    $content = $content -replace "`r`n`r`n`r`n", "`r`n`r`n"
    $content = $content -replace "`r`n`r`n`r`n", "`r`n`r`n"
    Set-Content -Path $path -Value $content -Encoding UTF8 -NoNewline
    $fixed += $file.Name
    Write-Host "✓ Fixed: $($file.Name)" -ForegroundColor Green
  } else {
    $skipped += $file.Name
  }
}

Write-Host "`nDone! Fixed: $($fixed.Count) files | Skipped: $($skipped.Count) files" -ForegroundColor Cyan
if ($fixed.Count -gt 0) {
  Write-Host "`nFixed files:" -ForegroundColor Yellow
  $fixed | ForEach-Object { Write-Host "  - $_" }
}
