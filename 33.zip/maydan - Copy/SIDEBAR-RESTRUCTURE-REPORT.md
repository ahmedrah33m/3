# SIDEBAR RESTRUCTURE REPORT
**MIDAN — FINAL SIDEBAR IA / NAVIGATION RESTRUCTURE**

---

## Before Sections (الوضع السابق)

| # | Section | Notes |
|----|----------|-------|
| 1 | الرئيسية 🏠 | عنصر واحد |
| 2 | استكشاف 🔎 | search / experts / companies / jobs / research |
| 3 | التقويم 🗓️ | قسم مستقل بعنصر واحد |
| 4 | الاقتصاد 📊 | **مزدحم**: intelligence, pulse, research-hub, data-room, investment, reputation, recommendations, feed, tasks, files, social, live, ai, bi, converter, market, indicators, calendar, map, charts |
| 5 | المجتمع 💬 | posts, discussions, questions, polls, communities, chat-rooms |
| 6 | المسار المهني 💼 | cv-builder, applications, interviews, my-cv, passport |
| 7 | الخبراء والاستشارات 🧠 | consultations, expert-market |
| 8 | التعليم 🎓 | academy, paths, quizzes, certificates, dictionary |
| 9 | المعرفة والمحتوى 📝 | articles, create, events |
| 10 | سوق ميدان 🛒 | home, services, products, stores, providers, requests |
| 11 | الاستثمار 📈 | bank, opportunities, investors, partnerships |
| 12 | ميدان AI 🤖 | قسم مستقل غير موجودة له CSS |
| 13 | المالية 💰 | wallet, transactions, invoices, subscriptions |
| 14 | حسابي 👤 | dashboard, profile, bookmarks, achievements, leaderboard, notifications (مع badge عددي), settings |
| — | مركز الإدارة 🛡️ | MODERATOR/ADMIN/OWNER |
| — | لوحة المالك 👑 | OWNER |

---

## After Sections (الوضع الجديد — 12 قسمًا فقط)

1. 🔎 **استكشاف** — الشركات، الوظائف (حُذف "البحث المتقدم": شريط البحث في الهيدر / صفحة /search مستقلة)
2. 📊 **الاقتصاد** — الذكاء الاقتصادي، نبض الاقتصاد العراقي، المؤشرات الاقتصادية، أسعار السوق، محول العملات، التقويم الاقتصادي، خريطة الاقتصاد العراقي، الرسوم البيانية
3. 💬 **المجتمع** — المنشورات، الشبكة الاجتماعية، النقاشات، الأسئلة والأجوبة، استطلاعات الرأي، المجتمعات، غرف المحادثة، Midan Live
4. 💼 **المسار المهني** — بناء السيرة الذاتية، طلبات التوظيف، المقابلات، السيرة الذاتية الخاصة بي، الجواز المهني، السمعة المهنية
5. 🧠 **الخبراء والاستشارات** — الخبراء، الاستشارات، سوق الخبراء
6. 🎓 **التعليم** — أكاديمية ميدان، مسارات التعلم، الاختبارات، الشهادات، القاموس الاقتصادي
7. 📝 **المعرفة والمحتوى** — إنشاء محتوى، الأبحاث والدراسات، مركز الأبحاث، الأحداث والمؤتمرات
8. 🛒 **سوق ميدان** — السوق، المنتجات، الخدمات، المتاجر، مقدمو الخدمات، طلباتي
9. 📈 **الاستثمار** — بنك الفرص الاستثمارية، الفرص الاستثمارية، المستثمرون، الشراكات، غرف البيانات
10. 🧰 **أدوات ميدان** — التقويم، المهام، الملفات، محرك التوصيات، Midan AI
11. 💰 **المالية** — المحفظة، المعاملات، الفواتير، الاشتراكات
12. 👤 **حسابي** — لوحة التحكم، الملف الشخصي، المحفوظات، الإنجازات، لوحة المتصدرين، الإشعارات، الإعدادات

+ 🛡️ **مركز الإدارة** (MODERATOR/ADMIN/OWNER) و👑 **لوحة المالك** (OWNER) — منفصلان.
+ سياقيًا: 🏢 **إدارة الشركة** (أعضاء الشركة فقط) و🧠 **لوحة المستشار** (EXPERT فقط).

---

## Moved (نُقل)

| من | إلى | العنصر |
|-----|-----|--------|
| الاقتصاد | المجتمع | Social (الشبكة الاجتماعية) |
| الاقتصاد | المجتمع | Midan Live |
| الاقتصاد | المسار المهني | Reputation (السمعة المهنية) |
| الاقتصاد | المعرفة والمحتوى | Research Hub (مركز الأبحاث) |
| الاقتصاد | الاستثمار | Data Room (غرف البيانات) |
| الاقتصاد | أدوات ميدان | Calendar / Tasks / Files / Recommendations / AI |
| الاقتصاد | الرئيسية | My Economic Feed (حُذفت الصفحة لاحقًا — لا فائدة منها، وأُزيل رابطها تمامًا) |

## Merged (دُمج)

| العنصر | إلى |
|---------|-----|
| قسم "التقويم" المستقل | أدوات ميدان (التقويم) |
| قسم "ميدان AI" المستقل | أدوات ميدان (Midan AI) |
| عنصر "My Economic Feed" | حُذف بالكامل (لا فائدة من صفحة /feed) |
| عنصر/قسم "Investment" المكرر | قسم الاستثمار الموحّد |

## Removed from main sidebar (أُزيل من الـ Sidebar العام)

- **🏠 الرئيسية / الصفحة الرئيسية** — أُزيل القسم بالكامل: الاسم/الشعار في الهيدر يقود إلى الصفحة الرئيسية مباشرة، فلا حاجة لعنصر جانبي مكرّر.
- **البحث المتقدم** — أُزيل من "استكشاف": شريط البحث موجود في الهيدر، وصفحة `/search` مستقلة.
- **BI (ذكاء الأعمال)** — أصبح سياقيًا (Company Dashboard / مركز الإدارة). الـ Route `/bi` باقٍ.
- **My Economic Feed** — حُذفت الصفحة (No route) ورابطها من كل الأقسام.
- جميع **الأرقام** (badge الإشعارات، عدّاد عناصر القسم، رسائل البوتوم ناف).

## Contextualized (أصبح سياقيًا)

- 🏢 **إدارة الشركة** (لوحة الشركة، الموظفون، الرواتب، التوظيف، التقارير) — تظهر فقط لـ `userType === 'company'`.
- 🧠 **لوحة المستشار** — تظهر فقط لدور EXPERT.
- 🛡️ **مركز الإدارة** — MODERATOR/ADMIN/OWNER فقط.
- 👑 **لوحة المالك** — OWNER فقط.
- **لوحة المتجر / لوحة التشغيل** للبائع — لا تُثقِل الـ Sidebar العام (تُدار داخل سوق ميدان).

---

## Numeric Badges

### Before
- `الإشعارات` في حسابي: badge عددي حي (unreadCount + 99+).
- عدّاد كل قسم: عدد عناصر القسم بجانب عنوانه (e.g. `8`).
- البوتوم ناف الجوال: badge عددي للرسائل.
- NavItem.badge → عائد للحساب في الـ Sidebar.

### After
- لا أرقام في الـ Sidebar نهائيًا (Desktop + Mobile).
- العدّاد الحقيقي للإشعارات باقٍ في الواجهات المسموحة فقط: **Topbar / Notification Center / Messages page / Dashboard**.
- `NavItem.badge` بقي كـ API للمنصّة لكنه لا يُعرض في الـ Sidebar (أُزيل من كل عناصر الـ Sidebar).
- البوتوم ناف: نقطة حمراء صغيرة بدون رقم.

---

## Duplicate IDs

### Before
| Duplicate | الموقع |
|-----------|--------|
| `investment` | قسم الاستثمار (section.id) + عنصر داخل الاقتصاد (item.id) |
| `ai` | قسم ميدان AI (section.id) + عنصر داخل الاقتصاد (item.id) |

### After
- **لا تكرار IDs إطلاقًا.** كل `section.id` وكل `item.id` فريدة (مُتحقّق في الاختبارات).
- أُعيدت التسمية: `economy-investment` (حذف)، `investment-bank`, `investment-data-room`, `tools-*`, `community-live`, `community-social`, `career-reputation`, `knowledge-research-hub` … إلخ. (عُنصر `home-feed` حُذف مع صفحة /feed).
- قسم AI → `tools` بعناصره `tools-calendar/tasks/files/recommendations/ai`.

---

## Duplicate Hrefs

### Before
- `/articles` في المجتمع (المنشورات) + المعرفة (المقالات) — لا، بل تقريبًا تم حله: المقالات لم تعد مكررة.
- `/jobs` في استكشاف + المسار المهني.
- تكرار مفاهيمي: `research` في استكشاف + `research-hub` في الاقتصاد.

### After
- **كل Route في أقسام المستخدم فريد** — لا عنصران لنفس الـ href:
  - `/jobs` → استكشاف فقط (رحلة المرشح في المسار المهني عبر `/jobs/candidate/*`).
  - `/articles` → المجتمع (المنشورات) فقط.
  - `/experts` → الخبراء والاستشارات فقط.
  - `/research` → المعرفة والمحتوى فقط (مع `research-hub` كـ route مختلف).
- أُبلغ عن كل النتائج أعلاه كما في الاختبارات (لا duplicates في الـ user sections؛ والـ admin/owner لها routes منفصلة تمامًا).

---

## Desktop: ✅ PASS
- 12 قسمًا فقط، مطوية افتراضيًا وتُفتح تلقائيًا عند Route نشط داخلها (قسم الرئيسية أُزيل — الهيدر يوصل لها).
- لا عدّادات، لا أرقام، Badges نصية (NEW فقط) بدون إفراط.
- أقسام سياقية (شركة/مستشار) + إدارة + مالك حسب الصلاحية.
- Source of truth واحد: `navigation-config.ts`.

## Mobile: ✅ PASS
- `MobileNavDrawer` أُعيدت كتابته لاستخدام نفس `navigation-config.ts` (أُزيلت كل القوائم الـ hardcoded والتكرارات القديمة مثل `/quizzes`، `/dictionary`، `/owner-panel` لأي Admin).
- نفس سلوك الـ collapse/expand والفتح التلقائي.
- البوتوم ناف الجوال بلا أرقام.

## TypeScript: ✅ PASS
`npm run typecheck` → **0 errors**

## Build: ✅ PASS
`npm run build` → **Compiled successfully** (بدون `ignoreBuildErrors`)، copy-standalone تم.

## Tests: ✅ PASS
`npm test` → **21 files / 299 tests passed** (عدد الاختبارات ارتفع من 280 إلى 299 بإضافة 19 تأكيدًا جديدًا للتنقل بإجمالي 10 مجموعات اختبار)
- أُضيفت 10 مجموعات اختبار للهيكل الجديد: IDs فريدة، لا duplicate hrefs، لا badges رقمية، gating الإدارة/المالك/السياقي، وفتح الأقسام عبر `/learning/*`، `/investment/*`، `/social/*`، وأدوات ميدان.

---

## Remaining Issues (ملاحظات)

1. **تفعيل البادج عددي** — `NavItem.badge` بـَقي في الأنواع، لكن أي عنصر Sidebar مستقبلي لا يجب أن يعرض رقمًا.
2. **`/learning` (الرئيسية)** — عند زيارة `/learning` مباشرة لا يُفتح قسم التعليم لأن عناصر القسم على `/learning/*`. إن رغبت بتفعيل ذلك، أضف عنصر `learning-home → /learning`.
3. **طلبات الاستثمار** — لم يُضف عنصرًا لأن لا Route موجود له في النظام حاليًا (الفرص/بنك الفرص يغطّي ذلك).
4. **أقسام سياقية أوسع (HR/Payroll/حضور/إجازات/عقود)** — أضفنا جوهر الوظائف (موظفون/رواتب/توظيف/تقارير) بروoutes موجودة فعلًا؛ باقي الأدوات (حضور، إجازات، عقود) داخل `company-dashboard` ويمكن إبرازها لاحقًا حسب الدور.
5. **CSS themes** — أُعيد استخدام مجموعات الألوان الموجودة مسبقًا (economy/community/platform/…)؛ لم أضف ألوانًا جديدة لتفادي الإزعاج البصري. يمكن إضافة `.accordion-tools` لاحقًا إن رغبت.