const fs = require('fs');

// Fix 1: Remove 'user' include from Employee queries
const payrollFiles = [
  'src/app/api/payroll/adjustments/route.ts',
  'src/app/api/payroll/attendance/route.ts',
  'src/app/api/payroll/contracts/route.ts',
  'src/app/api/payroll/employees/route.ts',
  'src/app/api/payroll/leave/route.ts',
  'src/app/api/payroll/overtime/route.ts',
  'src/app/api/payroll/payslips/route.ts',
  'src/app/api/payroll/reports/route.ts',
  'src/app/api/payroll/salary-structures/route.ts',
];

let fixed = 0;
for (const file of payrollFiles) {
  const content = fs.readFileSync(file, 'utf8');
  const newContent = content.replace(
    /employee:\s*\{\s*include:\s*\{\s*user:\s*\{[^}]*\}\s*\}\s*\}/g,
    "employee: { select: { id: true, userId: true, jobTitle: true, employeeNumber: true } }"
  );
  if (newContent !== content) {
    fs.writeFileSync(file, newContent);
    fixed++;
  }
}
console.log(`Fixed Employee include in ${fixed} files`);

// Fix 2: Fix Payment route
const paymentContent = fs.readFileSync('src/app/api/payroll/payments/route.ts', 'utf8');
const newPaymentContent = paymentContent
  .replace(/payrollRunId/g, 'userId')
  .replace(/processedById/g, 'userId')
  .replace(/payrollRun:[^}]*\}/g, '')
  .replace(/paymentDate:[^}]*\}/g, '')
  .replace(/processedById:[^}]*\}/g, '');
fs.writeFileSync('src/app/api/payroll/payments/route.ts', newPaymentContent);
console.log('Fixed Payment route');

// Fix 3: Fix SalaryStructure
const salaryContent = fs.readFileSync('src/app/api/payroll/salary-structures/route.ts', 'utf8');
const newSalaryContent = salaryContent
  .replace(/components:[^}]*\}/g, '')
  .replace(/components\?:\s*\{[^}]*\}/g, '');
fs.writeFileSync('src/app/api/payroll/salary-structures/route.ts', newSalaryContent);
console.log('Fixed SalaryStructure route');

console.log('Done!');
