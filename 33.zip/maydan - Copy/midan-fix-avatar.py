#!/usr/bin/env python3
"""
midan-fix-avatar.py — Patch ProfileView.tsx to fix the avatar/cover upload bug.

What this script does:
  1. Locates src/components/ProfileView.tsx (from CWD or first arg)
  2. Backs it up to ProfileView.tsx.bak.<timestamp>
  3. Replaces it with the patched version (bundled alongside this script)
  4. Prints next-step instructions

Usage:
  python3 midan-fix-avatar.py            # patches ./src/components/ProfileView.tsx
  python3 midan-fix-avatar.py /path      # patches /path/src/components/ProfileView.tsx

After running this script:
  npm run dev                            # restart dev server (or Ctrl+C then re-run)
"""

import os
import sys
import shutil
from datetime import datetime
from pathlib import Path

# The patched file is shipped alongside this script:
#   midan-fixes-avatar/src/components/profile/ProfileView.tsx
PATCHED_REL = Path("src/components/profile/ProfileView.tsx")
TARGET_REL = Path("src/components/ProfileView.tsx")


def find_patched_file() -> Path:
    """Locate the patched ProfileView.tsx shipped next to this script."""
    script_dir = Path(__file__).resolve().parent
    candidates = [
        script_dir / PATCHED_REL,
        script_dir / "midan-fixes-avatar" / PATCHED_REL,
    ]
    for c in candidates:
        if c.exists():
            return c
    # Fall back: maybe this script is inside midan-fixes-avatar/
    return script_dir / PATCHED_REL


def main():
    # ─── Locate project root ────────────────────────────────────────────────
    if len(sys.argv) > 1:
        project_root = Path(sys.argv[1]).resolve()
    else:
        project_root = Path.cwd()

    target_path = project_root / TARGET_REL
    patched_path = find_patched_file()

    print("═══════════════════════════════════════════")
    print("  ميدان — إصلاح عطل تغيير صورة البروفايل")
    print("═══════════════════════════════════════════\n")

    if not target_path.exists():
        print(f"✗ لم يتم العثور على {target_path}")
        print("  نفّذ هذا السكربت من جذر المشروع (حيث يوجد package.json).")
        sys.exit(1)

    if not patched_path.exists():
        print(f"✗ لم يتم العثور على النسخة المُصلَّحة: {patched_path}")
        print("  تأكد أن ملف ProfileView.tsx المُصلَّح بجانب هذا السكربت في:")
        print(f"    {PATCHED_REL}")
        sys.exit(1)

    print(f"✓ الهدف:       {target_path}")
    print(f"✓ المُصدر:      {patched_path}")
    print(f"  الحجم:        {patched_path.stat().st_size:,} bytes")
    print(f"  الأسطر:       {sum(1 for _ in patched_path.open(encoding='utf-8')):,}")

    # ─── 1. Backup ──────────────────────────────────────────────────────────
    backup = target_path.with_suffix(
        f".tsx.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    )
    shutil.copy2(target_path, backup)
    print(f"\n✓ نسخة احتياطية: {backup}")

    # ─── 2. Replace ─────────────────────────────────────────────────────────
    shutil.copy2(patched_path, target_path)
    print(f"✓ تم استبدال {TARGET_REL} بالنسخة المُصلَّحة")

    # ─── 3. Verify ──────────────────────────────────────────────────────────
    src = target_path.read_text(encoding="utf-8")
    checks = [
        ("handleImageChange function", "handleImageChange"),
        ("immediate PUT /api/users/[id]", "Persist to DB immediately"),
        ("articles preservation merge", "prev.articles"),
        ("client-side validation", "file.type.startsWith"),
        ("compression fallback", "compression failed, using original"),
    ]
    print("\n─ التحقق من الإصلاحات ─")
    all_ok = True
    for label, marker in checks:
        present = marker in src
        symbol = "✓" if present else "✗"
        print(f"  {symbol} {label}")
        if not present:
            all_ok = False

    if not all_ok:
        print("\n⚠️  بعض الإصلاحات غير موجودة في الملف المُصدري.")
        print("   تأكد أن ProfileView.tsx بجانب السكربت هو النسخة المُصلَّحة.")
        sys.exit(1)

    # ─── 4. Next steps ─────────────────────────────────────────────────────
    print("\n═══════════════════════════════════════════")
    print("  ✓ اكتمل الإصلاح — الخطوات التالية:")
    print("═══════════════════════════════════════════\n")
    print("  1) أعد تشغيل الخادم:")
    print("       npm run dev\n")
    print("  2) افتح المتصفح: http://localhost:3300/profile/user_owner\n")
    print("  3) جرّب تغيير الصورة الشخصية:")
    print("     - اضغط على الصورة الدائرية")
    print("     - اختر صورة (JPG أو PNG أو WebP، أقل من 20MB)")
    print("     - يجب أن ترى toast 'تم تحديث الصورة الشخصية'")
    print("     - الصورة تتحدث فوراً في البروفايل + الشريط الجانبي\n")
    print("  4) افتح DevTools (F12) → Console لرؤية:")
    print("     [uploadImage] ✓ avatar uploaded → /uploads/avatar/xyz.webp\n")


if __name__ == "__main__":
    main()
