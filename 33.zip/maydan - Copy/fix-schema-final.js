const fs = require('fs');

// Read all files
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

// Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) {
        models.set(currentModel, currentLines);
      }
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  
  if (currentModel) {
    models.set(currentModel, currentLines);
  }
  
  return models;
}

// Parse all models
const originalModels = parseModels(originalContent);
console.log('Original models:', originalModels.size);

const additionModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  const models = parseModels(content);
  for (const [name, lines] of models) {
    additionModels.set(name, lines);
  }
}
console.log('Addition models:', additionModels.size);

// Back-relations to add
const backRelations = {
  'Employee': [
    'employmentContracts EmploymentContract[]',
    'salaryStructures SalaryStructure[]',
    'allowances Allowance[]',
    'deductions Deduction[]',
    'bonuses Bonus[]',
    'overtimes Overtime[]',
    'attendances Attendance[]',
    'leaveRecords LeaveRecord[]',
    'payrollEmployees PayrollEmployee[]',
    'adjustments Adjustment[]',
    'employeeDocuments EmployeeDocument[]',
    'employeeOnboardings EmployeeOnboarding[]',
    'employmentVerifications EmploymentVerification[]',
  ],
  'Company': [
    'employmentContracts EmploymentContract[]',
    'salaryStructures SalaryStructure[]',
    'salaryComponents SalaryComponent[]',
    'allowances Allowance[]',
    'deductions Deduction[]',
    'bonuses Bonus[]',
    'overtimes Overtime[]',
    'shifts Shift[]',
    'attendances Attendance[]',
    'leavePolicies LeavePolicy[]',
    'leaveRecords LeaveRecord[]',
    'payrollPeriods PayrollPeriod[]',
    'payrollRuns PayrollRun[]',
    'payrollEmployees PayrollEmployee[]',
    'payslips Payslip[]',
    'payrollHistories PayrollHistory[]',
    'payrollRules PayrollRule[]',
    'taxRules TaxRule[]',
    'adjustments Adjustment[]',
    'employeeDocuments EmployeeDocument[]',
    'onboardingTemplates OnboardingTemplate[]',
    'onboardingTasks OnboardingTask[]',
    'employeeOnboardings EmployeeOnboarding[]',
    'payrollPayments PayrollPayment[]',
  ],
  'User': [
    'employmentVerifications EmploymentVerification[]',
    'employeeDocuments EmployeeDocument[]',
    'onboardingNotes OnboardingNote[]',
    'employeeOnboardings EmployeeOnboarding[] @relation("OnboardingAssignedTo")',
    'liveRoomNotifications LiveRoomNotification[]',
    'liveRoomHistories LiveRoomHistory[]',
    'liveRoomReactions LiveRoomReaction[]',
    'liveRoomModerationLogs LiveRoomModerationLog[] @relation("ModerationTarget")',
    'liveRoomModerationActions LiveRoomModerationLog[] @relation("ModerationAction")',
    'liveRoomInvitesSent LiveRoomInvite[] @relation("InviteSender")',
    'liveRoomInvitesReceived LiveRoomInvite[] @relation("InviteRecipient")',
  ],
  'LiveRoom': [
    'liveRoomNotifications LiveRoomNotification[]',
    'liveRoomModerationLogs LiveRoomModerationLog[]',
    'liveRoomHistories LiveRoomHistory[]',
    'liveRoomReactions LiveRoomReaction[]',
    'liveRoomInvites LiveRoomInvite[]',
  ],
  'PayrollRun': [
    'payments PayrollPayment[]',
  ],
  'OnboardingTemplate': [
    'onboardingTasks OnboardingTask[]',
    'employeeOnboardings EmployeeOnboarding[]',
  ],
  'OnboardingTask': [
    'dependentTasks OnboardingTask[] @relation("TaskDependency")',
    'taskInstances OnboardingTaskInstance[]',
  ],
  'EmployeeOnboarding': [
    'taskInstances OnboardingTaskInstance[]',
    'onboardingNotes OnboardingNote[]',
  ],
  'Shift': [
    'attendances Attendance[]',
  ],
  'LeavePolicy': [
    'leaveRecords LeaveRecord[]',
  ],
};

// Add back-relations to existing models
for (const [modelName, rels] of Object.entries(backRelations)) {
  const existingLines = originalModels.get(modelName);
  if (existingLines) {
    // Check if back-relations already exist
    const hasBackRelations = existingLines.some(l => l.includes('// Back-relations'));
    if (!hasBackRelations) {
      // Add back-relations before closing brace
      const closingIndex = existingLines.length - 1;
      const newLines = ['', '  // Back-relations', ...rels.map(r => '  ' + r)];
      existingLines.splice(closingIndex, 0, ...newLines);
      originalModels.set(modelName, existingLines);
    }
  }
}

// Add new models that don't exist in original
for (const [name, lines] of additionModels) {
  if (!originalModels.has(name)) {
    originalModels.set(name, lines);
  }
}

// Rebuild schema
const originalLines = originalContent.split('\n');
const output = [];
let currentModel = null;
let braceCount = 0;

for (let i = 0; i < originalLines.length; i++) {
  const line = originalLines[i];
  const trimmed = line.trim();
  
  const match = trimmed.match(/^model (\w+) \{/);
  if (match) {
    currentModel = match[1];
    braceCount = 1;
    output.push(line);
    continue;
  }
  
  if (currentModel) {
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    
    if (braceCount === 0) {
      // Model ended - add back-relations
      const modelLines = originalModels.get(currentModel);
      if (modelLines) {
        // Check if model has back-relations
        const hasBackRelations = modelLines.some(l => l.includes('// Back-relations'));
        if (hasBackRelations) {
          // Output model with back-relations
          output.push(...modelLines.slice(1, -1)); // Skip first and last line
          output.push('  // Back-relations');
          const backRelLines = modelLines.slice(modelLines.findIndex(l => l.includes('// Back-relations')) + 1);
          output.push(...backRelLines);
        } else {
          output.push(...modelLines.slice(1, -1));
        }
      }
      output.push('}');
      currentModel = null;
      continue;
    }
    
    continue;
  }
  
  output.push(line);
}

// Add new models at the end
for (const [name, lines] of originalModels) {
  // Check if model was already output
  if (!originalContent.includes(`model ${name} {`)) {
    output.push('');
    output.push(...lines);
  }
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
