#!/usr/bin/env python3
"""
Complete schema merge: source (319) + checkpoint 005 new models (37) = 356
With ALL reverse relations properly added.
"""

import re

def extract_models(content):
    models = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^model\s+(\w+)\s*\{', line)
        if m:
            if current:
                models[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        models[current] = '\n'.join(lines)
    return models

def extract_enums(content):
    enums = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^enum\s+(\w+)\s*\{', line)
        if m:
            if current:
                enums[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        enums[current] = '\n'.join(lines)
    return enums

def get_all_relations(model_text):
    """Get all relations from a model."""
    relations = []
    for line in model_text.split('\n'):
        m = re.match(r'\s+(\w+)\s+(\w+)\??\s+@relation\("([^"]+)"', line)
        if m:
            relations.append({
                'field': m.group(1),
                'target': m.group(2),
                'name': m.group(3),
                'optional': '?' in line.split('@relation')[0]
            })
    return relations

def add_reverse_relation(target_text, source_model, relation_name, optional=True):
    """Add a reverse relation to a target model."""
    lines = target_text.rstrip().split('\n')
    if lines and lines[-1].strip() == '}':
        lines = lines[:-1]
    
    # Determine field name (pluralized source model name)
    field_name = source_model.lower() + 's'
    
    # Check if already exists
    for line in lines:
        if f'{source_model}[]' in line or f'{source_model}?' in line:
            return target_text  # Already exists
    
    # Add the reverse relation
    lines.append(f'  {field_name} {source_model}[] @relation("{relation_name}")')
    lines.append('}')
    return '\n'.join(lines)

# Read schemas
with open('../maydan/prisma/schema.prisma', 'r') as f:
    source = f.read()

with open('prisma/checkpoints/005-all-systems-merged.prisma', 'r') as f:
    checkpoint = f.read()

source_models = extract_models(source)
source_enums = extract_enums(source)
checkpoint_models = extract_models(checkpoint)
checkpoint_enums = extract_enums(checkpoint)

# Start with checkpoint models (has the new models with proper relations)
final_models = dict(checkpoint_models)

# Add models from source that are NOT in checkpoint
for name, text in source_models.items():
    if name not in final_models:
        final_models[name] = text

# Add enums from source that are NOT in checkpoint
final_enums = dict(checkpoint_enums)
for name, text in source_enums.items():
    if name not in final_enums:
        final_enums[name] = text

print(f"Final models: {len(final_models)}")
print(f"Final enums: {len(final_enums)}")

# Now add reverse relations for ALL models
# For each model, find its relations and add reverse to target
for model_name, model_text in list(final_models.items()):
    relations = get_all_relations(model_text)
    for rel in relations:
        target = rel['target']
        relation_name = rel['name']
        if target in final_models:
            final_models[target] = add_reverse_relation(
                final_models[target], model_name, relation_name, rel['optional']
            )

# Build final schema
final = []

# Header
header_match = re.search(r'(.*?)^model\s', checkpoint, re.DOTALL | re.MULTILINE)
if header_match:
    final.append(header_match.group(1))

# Add enums
for name in sorted(final_enums):
    final.append(final_enums[name])

# Add models section
final.append('\n// ============================================')
final.append('// All Models')
final.append('// ============================================\n')

for name in sorted(final_models):
    final.append(final_models[name])

with open('prisma/schema.prisma', 'w') as f:
    f.write('\n\n'.join(final))

print(f"\n✅ Final schema: {len(final_models)} models, {len(final_enums)} enums")
