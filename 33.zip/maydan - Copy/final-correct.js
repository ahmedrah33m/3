const fs = require('fs');

const baseContent = fs.readFileSync('prisma/schema.base.prisma', 'utf8');

const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

const baseModels = parseModels(baseContent);
console.log('Base models:', baseModels.size);

const baseNames = new Set([...baseModels.keys()]);

const allNewModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [name, lines] of parseModels(content)) {
    if (!baseNames.has(name) && name !== 'Payment') {
      allNewModels.set(name, lines);
    }
  }
}
console.log('New models to add:', allNewModels.size);

// Build reverse relations with UNIQUE field names
const reverseRelations = new Map();

for (const [modelName, modelLines] of allNewModels) {
  for (const line of modelLines) {
    const match = line.match(/^\s+(\w+)\s+(\w+)(\??)\s*@relation/);
    if (match) {
      const fieldName = match[1];
      const targetModel = match[2];
      if (baseNames.has(targetModel)) {
        if (!reverseRelations.has(targetModel)) {
          reverseRelations.set(targetModel, []);
        }
        // Use unique field name: {modelName}{FieldName}
        // e.g., EmploymentContract employee -> employmentContractEmployee
        const uniqueFieldName = modelName.charAt(0).toLowerCase() + modelName.slice(1) + fieldName.charAt(0).toUpperCase() + fieldName.slice(1);
        reverseRelations.get(targetModel).push({
          field: uniqueFieldName,
          type: modelName,
          isList: !line.includes(`${targetModel}[]`) // If original is single, reverse is list
        });
      }
    }
  }
}

console.log('Models needing reverse relations:', reverseRelations.size);

// Add reverse relations to existing models
let totalAdded = 0;
for (const [modelName, rels] of reverseRelations) {
  const modelLines = baseModels.get(modelName);
  if (!modelLines) continue;
  
  // Get existing field names
  const existingFields = new Set();
  for (const line of modelLines) {
    const fieldMatch = line.trim().match(/^(\w+)\s+/);
    if (fieldMatch && !line.trim().startsWith('model ') && !line.trim().startsWith('@@')) {
      existingFields.add(fieldMatch[1]);
    }
  }
  
  const missingRels = rels.filter(r => !existingFields.has(r.field));
  
  if (missingRels.length > 0) {
    const closingIdx = modelLines.length - 1;
    const newRels = missingRels.map(r => 
      `  ${r.field} ${r.type}${r.isList ? '[]' : '?'}`
    );
    modelLines.splice(closingIdx, 0, '', '  // Back-relations (new systems)', ...newRels);
    totalAdded += missingRels.length;
  }
}

console.log('Reverse relations added:', totalAdded);

// Rebuild schema
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

for (const [name, lines] of baseModels) {
  output.push(...lines);
  output.push('');
}

output.push('// ============================================');
output.push('// New Models (Payroll, Verification, Onboarding, Live)');
output.push('// ============================================');
output.push('');

for (const [name, lines] of allNewModels) {
  output.push(...lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
