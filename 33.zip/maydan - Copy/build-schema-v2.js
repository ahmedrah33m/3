/**
 * Complete schema builder v2
 * Adds all 37 new models + all reverse relations to existing models
 */

const fs = require('fs');

// Read base schema
let lines = fs.readFileSync('prisma/schema.base.prisma', 'utf8').split('\n');

// Find end of a model given its name
function findModelEnd(modelName, linesArr) {
  const pattern = new RegExp(`^model ${modelName} \\\\w+ \\\\{`);
  let startIdx = -1;
  for (let i = 0; i < linesArr.length; i++) {
    if (linesArr[i].trim().match(pattern)) {
      startIdx = i;
      break;
    }
  }
  if (startIdx === -1) return -1;
  let depth = 0;
  for (let i = startIdx; i < linesArr.length; i++) {
    const t = linesArr[i].trim();
    if (t.includes('{')) depth++;
    if (t.includes('}')) depth--;
    if (depth === 0 && t === '}') return i;
  }
  return -1;
}

// All reverse relations to add to existing models
const reverseRelations = {
  Employee: [
    '  employmentContracts EmploymentContract[] @relation("EmploymentContractEmployee")',
    '  salaryStructures SalaryStructure[] @relation("SalaryStructureEmployee")',
    '  allowances Allowance[] @relation("AllowanceEmployee")',
    '  deductions Deduction[] @relation("DeductionEmployee")',
    '  bonuses Bonus[] @relation("BonusEmployee")',
    '  overtimes Overtime[] @relation("OvertimeEmployee")',
    '  attendances Attendance[] @relation("AttendanceEmployee")',
    '  leaveRecords LeaveRecord[] @relation("LeaveRecordEmployee")',
    '  payrollEmployees PayrollEmployee[] @relation("PayrollEmployeeEmployee")',
    '  payslips Payslip[] @relation("PayslipEmployee2")',
    '  payrollHistories PayrollHistory[] @relation("PayrollHistoryEmployee")',
    '  adjustments Adjustment[] @relation("AdjustmentEmployee2")',
    '  employeeDocuments EmployeeDocument[] @relation("EmployeeDocumentEmployee")',
    '  employeeOnboardings EmployeeOnboarding[] @relation("EmployeeOnboardingEmployee")',
    '  onboardingTaskInstances OnboardingTaskInstance[] @relation("OnboardingTaskInstanceEmployee")'
  ],
  Company: [
    '  employmentContracts EmploymentContract[] @relation("EmploymentContractCompany")',
    '  salaryStructures SalaryStructure[] @relation("SalaryStructureCompany")',
    '  salaryComponents SalaryComponent[] @relation("SalaryComponentCompany")',
    '  allowances Allowance[] @relation("AllowanceCompany")',
    '  deductions Deduction[] @relation("DeductionCompany")',
    '  bonuses Bonus[] @relation("BonusCompany")',
    '  overtimes Overtime[] @relation("OvertimeCompany")',
    '  shifts Shift[] @relation("ShiftCompany")',
    '  attendances Attendance[] @relation("AttendanceCompany")',
    '  leavePolicies LeavePolicy[] @relation("LeavePolicyCompany")',
    '  leaveRecords LeaveRecord[] @relation("LeaveRecordCompany")',
    '  payrollPeriods PayrollPeriod[] @relation("PayrollPeriodCompany")',
    '  payrollRuns PayrollRun[] @relation("PayrollRunCompany")',
    '  payrollEmployees PayrollEmployee[] @relation("PayrollEmployeeCompany")',
    '  payslips Payslip[] @relation("PayslipCompany")',
    '  payrollHistories PayrollHistory[] @relation("PayrollHistoryCompany")',
    '  payrollRules PayrollRule[] @relation("PayrollRuleCompany")',
    '  taxRules TaxRule[] @relation("TaxRuleCompany")',
    '  adjustments Adjustment[] @relation("AdjustmentCompany")',
    '  employeeDocuments EmployeeDocument[] @relation("EmployeeDocumentCompany")',
    '  onboardingTemplates OnboardingTemplate[] @relation("OnboardingTemplateCompany")',
    '  onboardingTasks OnboardingTask[] @relation("OnboardingTaskCompany")',
    '  employeeOnboardings EmployeeOnboarding[] @relation("EmployeeOnboardingCompany")'
  ],
  Offer: [
    '  employmentContract EmploymentContract? @relation("EmploymentContractOffer")'
  ],
  User: [
    '  employmentVerifications EmploymentVerification[] @relation("EmploymentVerificationUser")',
    '  employeeOnboardings EmployeeOnboarding[] @relation("OnboardingAssignedTo")',
    '  liveRooms LiveRoom[] @relation("LiveRoomHost")',
    '  liveRoomParticipants LiveRoomParticipant[] @relation("LiveRoomParticipantUser")',
    '  liveRoomMessages LiveRoomMessage[] @relation("LiveRoomMessageUser")',
    '  liveTranscripts LiveTranscript[] @relation("LiveTranscriptSpeaker")',
    '  liveRoomNotifications LiveRoomNotification[] @relation("LiveRoomNotificationUser")',
    '  liveRoomModerationLogs LiveRoomModerationLog[] @relation("ModerationTarget")',
    '  liveRoomModerationActions LiveRoomModerationLog[] @relation("ModerationAction")',
    '  liveRoomHistories LiveRoomHistory[] @relation("LiveRoomHistoryUser")',
    '  liveRoomReactions LiveRoomReaction[] @relation("LiveRoomReactionUser")',
    '  liveRoomInvitesSent LiveRoomInvite[] @relation("InviteSender")',
    '  liveRoomInvitesReceived LiveRoomInvite[] @relation("InviteRecipient")'
  ]
};

// Insert reverse relations (process in reverse order of line numbers to preserve indices)
const insertions = [];
for (const [modelName, rels] of Object.entries(reverseRelations)) {
  const endIdx = findModelEnd(modelName, lines);
  if (endIdx === -1) {
    console.log(`WARNING: Could not find model ${modelName}`);
    continue;
  }
  insertions.push({ idx: endIdx, rels });
}

// Sort by index descending to preserve positions
insertions.sort((a, b) => b.idx - a.idx);

for (const { idx, rels } of insertions) {
  lines.splice(idx, 0, ...rels);
}

console.log(`Inserted reverse relations for ${insertions.length} models`);

// All new models to append at the end
const newModels = [];

newModels.push(`model EmploymentContract {
  id                String   @id @default(cuid())
  employeeId        String?
  companyId         String
  offerId           String?  @unique
  contractType      String   @default("FULL_TIME")
  contractNumber    String?  @unique
  startDate         DateTime
  endDate           DateTime?
  probationMonths   Int      @default(3)
  probationEndDate  DateTime?
  terminationDate   DateTime?
  terminationReason String?
  baseSalary        Decimal  @db.Decimal(18, 3)
  salaryCurrency    String   @default("IQD")
  paymentFrequency  String   @default("MONTHLY")
  paymentMethod     String   @default("BANK_TRANSFER")
  workingHours      String?
  benefits          Json?
  leavePolicyId     String?
  attachments       Json?
  companySignedAt   DateTime?
  companySignedById String?
  employeeSignedAt  DateTime?
  employeeSignature String?
  companySignature  String?
  version           Int      @default(1)
  parentContractId  String?
  status            String   @default("DRAFT")
  contractFileUrl   String?
  createdById       String
  approvedById      String?
  approvedAt        DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee? @relation("EmploymentContractEmployee", fields: [employeeId], references: [id], onDelete: SetNull)
  company           Company  @relation("EmploymentContractCompany", fields: [companyId], references: [id], onDelete: Cascade)
  offer             Offer?   @relation("EmploymentContractOffer", fields: [offerId], references: [id], onDelete: SetNull)
  @@index([employeeId])
  @@index([companyId])
  @@index([offerId])
  @@index([status])
  @@index([startDate])
}`);

newModels.push(`model SalaryStructure {
  id                String   @id @default(cuid())
  employeeId        String
  contractId        String
  companyId         String
  effectiveFrom     DateTime
  effectiveTo       DateTime?
  isActive          Boolean  @default(true)
  baseSalary        Decimal  @db.Decimal(18, 3)
  currency          String   @default("IQD")
  totalAllowances   Decimal  @default(0) @db.Decimal(18, 3)
  totalDeductions   Decimal  @default(0) @db.Decimal(18, 3)
  grossSalary       Decimal  @default(0) @db.Decimal(18, 3)
  netSalary         Decimal  @default(0) @db.Decimal(18, 3)
  createdById       String
  approvedById      String?
  approvedAt        DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee          @relation("SalaryStructureEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  contract          EmploymentContract @relation("SalaryStructureContract", fields: [contractId], references: [id], onDelete: Cascade)
  company           Company           @relation("SalaryStructureCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([employeeId])
  @@index([contractId])
  @@index([companyId])
  @@index([isActive])
  @@index([effectiveFrom])
}`);

newModels.push(`model SalaryComponent {
  id                String   @id @default(cuid())
  salaryStructureId String
  companyId         String
  name              String
  componentType     String
  calculationType   String   @default("FIXED")
  value             Decimal  @db.Decimal(18, 3)
  percentageOf      String?
  formula           String?
  isTaxable         Boolean  @default(true)
  isMandatory       Boolean  @default(false)
  displayOrder      Int      @default(0)
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  salaryStructure   SalaryStructure @relation("SalaryComponentStructure", fields: [salaryStructureId], references: [id], onDelete: Cascade)
  company           Company         @relation("SalaryComponentCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([salaryStructureId])
  @@index([companyId])
  @@index([componentType])
}`);

newModels.push(`model Allowance {
  id                String   @id @default(cuid())
  salaryStructureId String
  employeeId        String
  companyId         String
  name              String
  allowanceType     String
  amount            Decimal  @db.Decimal(18, 3)
  isPercentage      Boolean  @default(false)
  percentageValue   Decimal? @db.Decimal(5, 2)
  isTaxable         Boolean  @default(true)
  isRecurring       Boolean  @default(true)
  effectiveFrom     DateTime
  effectiveTo       DateTime?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  salaryStructure   SalaryStructure @relation("AllowanceStructure", fields: [salaryStructureId], references: [id], onDelete: Cascade)
  employee          Employee        @relation("AllowanceEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company         @relation("AllowanceCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([salaryStructureId])
  @@index([employeeId])
  @@index([companyId])
  @@index([allowanceType])
}`);

newModels.push(`model Deduction {
  id                String   @id @default(cuid())
  salaryStructureId String
  employeeId        String
  companyId         String
  name              String
  deductionType     String
  amount            Decimal  @db.Decimal(18, 3)
  isPercentage      Boolean  @default(false)
  percentageValue   Decimal? @db.Decimal(5, 2)
  isRecurring       Boolean  @default(true)
  effectiveFrom     DateTime
  effectiveTo       DateTime?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  salaryStructure   SalaryStructure @relation("DeductionStructure", fields: [salaryStructureId], references: [id], onDelete: Cascade)
  employee          Employee        @relation("DeductionEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company         @relation("DeductionCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([salaryStructureId])
  @@index([employeeId])
  @@index([companyId])
  @@index([deductionType])
}`);

newModels.push(`model Bonus {
  id                String   @id @default(cuid())
  salaryStructureId String
  employeeId        String
  companyId         String
  name              String
  bonusType         String
  amount            Decimal  @db.Decimal(18, 3)
  isTaxable         Boolean  @default(true)
  isOneTime         Boolean  @default(true)
  effectiveDate     DateTime
  notes             String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  salaryStructure   SalaryStructure @relation("BonusStructure", fields: [salaryStructureId], references: [id], onDelete: Cascade)
  employee          Employee        @relation("BonusEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company         @relation("BonusCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([salaryStructureId])
  @@index([employeeId])
  @@index([companyId])
  @@index([bonusType])
}`);

newModels.push(`model Overtime {
  id                String   @id @default(cuid())
  employeeId        String
  companyId         String
  date              DateTime
  startTime         DateTime
  endTime           DateTime
  durationMinutes   Int
  overtimeType      String   @default("WEEKDAY")
  multiplier        Decimal  @default(1.5) @db.Decimal(3, 1)
  hourlyRate        Decimal  @db.Decimal(18, 3)
  amount            Decimal  @db.Decimal(18, 3)
  status            String   @default("PENDING")
  approvedById      String?
  approvedAt        DateTime?
  notes             String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee @relation("OvertimeEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company  @relation("OvertimeCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([employeeId])
  @@index([companyId])
  @@index([date])
  @@index([status])
}`);

newModels.push(`model Shift {
  id                String   @id @default(cuid())
  companyId         String
  name              String
  startTime         String
  endTime           String
  breakDurationMin  Int      @default(60)
  gracePeriodMin    Int      @default(15)
  lateThresholdMin  Int      @default(15)
  earlyLeaveThresholdMin Int  @default(15)
  workDays          String[]
  isActive          Boolean  @default(true)
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company  @relation("ShiftCompany", fields: [companyId], references: [id], onDelete: Cascade)
  attendances       Attendance[]
  @@index([companyId])
  @@index([isActive])
}`);

newModels.push(`model Attendance {
  id                String   @id @default(cuid())
  employeeId        String
  companyId         String
  shiftId           String?
  date              DateTime @db.Date
  checkIn           DateTime?
  checkOut          DateTime?
  breakStart        DateTime?
  breakEnd          DateTime?
  breakDurationMin  Int      @default(0)
  workDurationMin   Int      @default(0)
  overtimeMin       Int      @default(0)
  lateMin           Int      @default(0)
  earlyLeaveMin     Int      @default(0)
  status            String   @default("PRESENT")
  isHoliday         Boolean  @default(false)
  isWeekend         Boolean  @default(false)
  checkInLat        Decimal? @db.Decimal(10, 8)
  checkInLng        Decimal? @db.Decimal(11, 8)
  checkOutLat       Decimal? @db.Decimal(10, 8)
  checkOutLng       Decimal? @db.Decimal(11, 8)
  checkInLocation   String?
  checkOutLocation  String?
  checkInDevice     String?
  checkOutDevice    String?
  checkInMethod     String?
  checkOutMethod    String?
  approvedById      String?
  approvedAt        DateTime?
  notes             String?
  createdById       String?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee @relation("AttendanceEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company  @relation("AttendanceCompany", fields: [companyId], references: [id], onDelete: Cascade)
  shift             Shift?   @relation("AttendanceShift", fields: [shiftId], references: [id], onDelete: SetNull)
  @@unique([employeeId, date])
  @@index([employeeId])
  @@index([companyId])
  @@index([date])
  @@index([status])
  @@index([shiftId])
}`);

newModels.push(`model LeavePolicy {
  id                String   @id @default(cuid())
  companyId         String
  name              String
  leaveType         String
  daysPerYear       Int
  isPaid            Boolean  @default(true)
  isCarryForward    Boolean  @default(false)
  maxCarryForwardDays Int    @default(0)
  minServiceDays    Int      @default(0)
  gender            String?
  isActive          Boolean  @default(true)
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company  @relation("LeavePolicyCompany", fields: [companyId], references: [id], onDelete: Cascade)
  leaveRecords      LeaveRecord[]
  @@index([companyId])
  @@index([leaveType])
  @@index([isActive])
}`);

newModels.push(`model LeaveRecord {
  id                String   @id @default(cuid())
  employeeId        String
  companyId         String
  leavePolicyId     String
  startDate         DateTime
  endDate           DateTime
  daysCount         Int
  reason            String?
  status            String   @default("PENDING")
  approvedById      String?
  approvedAt        DateTime?
  rejectionReason   String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee   @relation("LeaveRecordEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company    @relation("LeaveRecordCompany", fields: [companyId], references: [id], onDelete: Cascade)
  leavePolicy       LeavePolicy @relation("LeaveRecordPolicy", fields: [leavePolicyId], references: [id], onDelete: Cascade)
  @@index([employeeId])
  @@index([companyId])
  @@index([leavePolicyId])
  @@index([status])
  @@index([startDate])
}`);

newModels.push(`model PayrollPeriod {
  id                String   @id @default(cuid())
  companyId         String
  name              String
  startDate         DateTime
  endDate           DateTime
  paymentDate       DateTime
  status            String   @default("OPEN")
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company  @relation("PayrollPeriodCompany", fields: [companyId], references: [id], onDelete: Cascade)
  payrollRuns       PayrollRun[]
  @@index([companyId])
  @@index([startDate])
  @@index([status])
}`);

newModels.push(`model PayrollRun {
  id                String   @id @default(cuid())
  companyId         String
  payrollPeriodId   String
  name              String
  runDate           DateTime @default(now())
  totalEmployees    Int      @default(0)
  totalGross        Decimal  @default(0) @db.Decimal(18, 3)
  totalAllowances   Decimal  @default(0) @db.Decimal(18, 3)
  totalDeductions   Decimal  @default(0) @db.Decimal(18, 3)
  totalBonuses      Decimal  @default(0) @db.Decimal(18, 3)
  totalOvertime     Decimal  @default(0) @db.Decimal(18, 3)
  totalTax          Decimal  @default(0) @db.Decimal(18, 3)
  totalNet          Decimal  @default(0) @db.Decimal(18, 3)
  status            String   @default("DRAFT")
  reviewedById      String?
  reviewedAt        DateTime?
  approvedById      String?
  approvedAt        DateTime?
  notes             String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company      @relation("PayrollRunCompany", fields: [companyId], references: [id], onDelete: Cascade)
  payrollPeriod     PayrollPeriod @relation("PayrollRunPeriod", fields: [payrollPeriodId], references: [id], onDelete: Cascade)
  payrollEmployees  PayrollEmployee[]
  @@index([companyId])
  @@index([payrollPeriodId])
  @@index([status])
  @@index([runDate])
}`);

newModels.push(`model PayrollEmployee {
  id                String   @id @default(cuid())
  payrollRunId      String
  employeeId        String
  contractId        String
  companyId         String
  baseSalary        Decimal  @db.Decimal(18, 3)
  totalAllowances   Decimal  @default(0) @db.Decimal(18, 3)
  totalBonuses      Decimal  @default(0) @db.Decimal(18, 3)
  totalOvertime     Decimal  @default(0) @db.Decimal(18, 3)
  grossSalary       Decimal  @db.Decimal(18, 3)
  totalDeductions   Decimal  @default(0) @db.Decimal(18, 3)
  totalTax          Decimal  @default(0) @db.Decimal(18, 3)
  netSalary         Decimal  @db.Decimal(18, 3)
  workingDays       Int      @default(0)
  presentDays       Int      @default(0)
  absentDays        Int      @default(0)
  leaveDays         Int      @default(0)
  lateDays          Int      @default(0)
  overtimeHours     Decimal  @default(0) @db.Decimal(8, 2)
  status            String   @default("PENDING")
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  payrollRun        PayrollRun        @relation("PayrollEmployeeRun", fields: [payrollRunId], references: [id], onDelete: Cascade)
  employee          Employee          @relation("PayrollEmployeeEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  contract          EmploymentContract @relation("PayrollEmployeeContract", fields: [contractId], references: [id], onDelete: Cascade)
  company           Company           @relation("PayrollEmployeeCompany", fields: [companyId], references: [id], onDelete: Cascade)
  payslip           Payslip?
  adjustments       Adjustment[]
  @@unique([payrollRunId, employeeId])
  @@index([payrollRunId])
  @@index([employeeId])
  @@index([companyId])
  @@index([status])
}`);

newModels.push(`model Payslip {
  id                String   @id @default(cuid())
  payrollEmployeeId String   @unique
  employeeId        String
  companyId         String
  payrollRunId      String
  payslipNumber     String   @unique
  generatedAt       DateTime @default(now())
  baseSalary        Decimal  @db.Decimal(18, 3)
  totalAllowances   Decimal  @default(0) @db.Decimal(18, 3)
  totalBonuses      Decimal  @default(0) @db.Decimal(18, 3)
  totalOvertime     Decimal  @default(0) @db.Decimal(18, 3)
  grossSalary       Decimal  @db.Decimal(18, 3)
  totalDeductions   Decimal  @default(0) @db.Decimal(18, 3)
  totalTax          Decimal  @default(0) @db.Decimal(18, 3)
  netSalary         Decimal  @db.Decimal(18, 3)
  workingDays       Int      @default(0)
  presentDays       Int      @default(0)
  absentDays        Int      @default(0)
  leaveDays         Int      @default(0)
  lateDays          Int      @default(0)
  overtimeHours     Decimal  @default(0) @db.Decimal(8, 2)
  pdfUrl            String?
  status            String   @default("GENERATED")
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  payrollEmployee   PayrollEmployee @relation("PayslipEmployee", fields: [payrollEmployeeId], references: [id], onDelete: Cascade)
  employee          Employee        @relation("PayslipEmployee2", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company         @relation("PayslipCompany", fields: [companyId], references: [id], onDelete: Cascade)
  payrollRun        PayrollRun      @relation("PayslipRun", fields: [payrollRunId], references: [id], onDelete: Cascade)
  @@index([payrollEmployeeId])
  @@index([employeeId])
  @@index([companyId])
  @@index([payrollRunId])
  @@index([payslipNumber])
}`);

newModels.push(`model PayrollHistory {
  id                String   @id @default(cuid())
  employeeId        String
  companyId         String
  payrollRunId      String
  payslipId         String?
  periodName        String
  periodStart       DateTime
  periodEnd         DateTime
  paymentDate       DateTime
  baseSalary        Decimal  @db.Decimal(18, 3)
  totalAllowances   Decimal  @default(0) @db.Decimal(18, 3)
  totalBonuses      Decimal  @default(0) @db.Decimal(18, 3)
  totalOvertime     Decimal  @default(0) @db.Decimal(18, 3)
  grossSalary       Decimal  @db.Decimal(18, 3)
  totalDeductions   Decimal  @default(0) @db.Decimal(18, 3)
  totalTax          Decimal  @default(0) @db.Decimal(18, 3)
  netSalary         Decimal  @db.Decimal(18, 3)
  createdAt         DateTime @default(now())
  employee          Employee   @relation("PayrollHistoryEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company    @relation("PayrollHistoryCompany", fields: [companyId], references: [id], onDelete: Cascade)
  payrollRun        PayrollRun @relation("PayrollHistoryRun", fields: [payrollRunId], references: [id], onDelete: Cascade)
  @@index([employeeId])
  @@index([companyId])
  @@index([payrollRunId])
  @@index([periodStart])
}`);

newModels.push(`model PayrollRule {
  id                String   @id @default(cuid())
  companyId         String
  name              String
  ruleType          String
  country           String   @default("IQ")
  province          String?
  employeeType      String   @default("ALL")
  effectiveFrom     DateTime
  effectiveTo       DateTime?
  formula           String
  fixedAmount       Decimal? @db.Decimal(18, 3)
  percentage        Decimal? @db.Decimal(5, 2)
  minThreshold      Decimal? @db.Decimal(18, 3)
  maxThreshold      Decimal? @db.Decimal(18, 3)
  brackets          Json?
  isActive          Boolean  @default(true)
  priority          Int      @default(0)
  notes             String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company  @relation("PayrollRuleCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([companyId])
  @@index([ruleType])
  @@index([country])
  @@index([isActive])
  @@index([effectiveFrom])
}`);

newModels.push(`model TaxRule {
  id                String   @id @default(cuid())
  companyId         String
  name              String
  country           String   @default("IQ")
  province          String?
  brackets          Json
  personalExemption Decimal  @default(0) @db.Decimal(18, 3)
  effectiveFrom     DateTime
  effectiveTo       DateTime?
  isActive          Boolean  @default(true)
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company  @relation("TaxRuleCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([companyId])
  @@index([country])
  @@index([isActive])
  @@index([effectiveFrom])
}`);

newModels.push(`model Adjustment {
  id                String   @id @default(cuid())
  payrollEmployeeId String
  employeeId        String
  companyId         String
  adjustmentType    String
  amount            Decimal  @db.Decimal(18, 3)
  reason            String
  reference         String?
  status            String   @default("PENDING")
  approvedById      String?
  approvedAt        DateTime?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  payrollEmployee   PayrollEmployee @relation("AdjustmentEmployee", fields: [payrollEmployeeId], references: [id], onDelete: Cascade)
  employee          Employee        @relation("AdjustmentEmployee2", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company         @relation("AdjustmentCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([payrollEmployeeId])
  @@index([employeeId])
  @@index([companyId])
  @@index([status])
}`);

newModels.push(`model EmploymentVerification {
  id                String   @id @default(cuid())
  userId            String
  companyId         String?
  companyName       String
  companyEmail      String?
  position          String
  department        String?
  employmentType    String   @default("FULL_TIME")
  startDate         DateTime
  endDate           DateTime?
  isCurrentJob      Boolean  @default(false)
  description       String?
  achievements      String?
  referenceName     String?
  referenceEmail    String?
  referencePhone    String?
  referenceTitle    String?
  status            String   @default("PENDING")
  verifiedById      String?
  verifiedAt        DateTime?
  verificationNote  String?
  rejectionReason   String?
  confirmedSalary   Decimal? @db.Decimal(18, 3)
  confirmedPosition String?
  confirmedStartDate DateTime?
  confirmedEndDate  DateTime?
  documents         Json?
  reminderCount     Int      @default(0)
  lastReminderAt    DateTime?
  nextReminderAt    DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  user              User     @relation("EmploymentVerificationUser", fields: [userId], references: [id], onDelete: Cascade)
  @@index([userId])
  @@index([companyId])
  @@index([status])
  @@index([companyEmail])
}`);

newModels.push(`model EmploymentVerificationToken {
  id                String   @id @default(cuid())
  verificationId    String
  token             String   @unique
  purpose           String
  expiresAt         DateTime
  usedAt            DateTime?
  usedById          String?
  createdAt         DateTime @default(now())
  @@index([verificationId])
  @@index([token])
}`);

newModels.push(`model EmploymentVerificationLog {
  id                String   @id @default(cuid())
  verificationId    String
  action            String
  actionById        String?
  details           Json?
  createdAt         DateTime @default(now())
  @@index([verificationId])
}`);

newModels.push(`model EmployeeDocument {
  id                String   @id @default(cuid())
  employeeId        String
  companyId         String
  documentType      String
  documentName      String
  documentUrl       String
  status            String   @default("PENDING")
  verifiedById      String?
  verifiedAt        DateTime?
  notes             String?
  isRequired        Boolean  @default(true)
  dueDate           DateTime?
  submittedAt       DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee @relation("EmployeeDocumentEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company  @relation("EmployeeDocumentCompany", fields: [companyId], references: [id], onDelete: Cascade)
  @@index([employeeId])
  @@index([companyId])
  @@index([documentType])
  @@index([status])
}`);

newModels.push(`model OnboardingTemplate {
  id                String   @id @default(cuid())
  companyId         String
  name              String
  description       String?
  isActive          Boolean  @default(true)
  isDefault         Boolean  @default(false)
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  company           Company  @relation("OnboardingTemplateCompany", fields: [companyId], references: [id], onDelete: Cascade)
  tasks             OnboardingTask[]
  @@index([companyId])
  @@index([isActive])
}`);

newModels.push(`model OnboardingTask {
  id                String   @id @default(cuid())
  templateId        String
  companyId         String
  name              String
  description       String?
  taskType          String
  order             Int      @default(0)
  isRequired        Boolean  @default(true)
  isAutomated       Boolean  @default(false)
  estimatedDays     Int      @default(1)
  assignedToRole    String?
  dependsOnId       String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  template          OnboardingTemplate @relation("OnboardingTaskTemplate", fields: [templateId], references: [id], onDelete: Cascade)
  company           Company             @relation("OnboardingTaskCompany", fields: [companyId], references: [id], onDelete: Cascade)
  dependsOn         OnboardingTask?     @relation("TaskDependency", fields: [dependsOnId], references: [id], onDelete: SetNull)
  @@index([templateId])
  @@index([companyId])
  @@index([taskType])
  @@index([order])
}`);

newModels.push(`model EmployeeOnboarding {
  id                String   @id @default(cuid())
  employeeId        String
  companyId         String
  templateId        String?
  status            String   @default("NOT_STARTED")
  startDate         DateTime?
  targetEndDate     DateTime?
  actualEndDate     DateTime?
  completedPercent  Int      @default(0)
  currentStep       Int      @default(0)
  assignedToId      String?
  managerId         String?
  notes             String?
  cancellationReason String?
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee           @relation("EmployeeOnboardingEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  company           Company            @relation("EmployeeOnboardingCompany", fields: [companyId], references: [id], onDelete: Cascade)
  template          OnboardingTemplate? @relation("EmployeeOnboardingTemplate", fields: [templateId], references: [id], onDelete: SetNull)
  assignedTo        User?              @relation("OnboardingAssignedTo", fields: [assignedToId], references: [id], onDelete: SetNull)
  @@index([employeeId])
  @@index([companyId])
  @@index([status])
  @@index([assignedToId])
}`);

newModels.push(`model OnboardingTaskInstance {
  id                String   @id @default(cuid())
  onboardingId      String
  taskId            String
  employeeId        String
  companyId         String
  status            String   @default("PENDING")
  startDate         DateTime?
  dueDate           DateTime?
  completedAt       DateTime?
  assignedToId      String?
  completedById     String?
  notes             String?
  documentUrl       String?
  formData          Json?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  onboarding        EmployeeOnboarding @relation("OnboardingTaskInstanceOnboarding", fields: [onboardingId], references: [id], onDelete: Cascade)
  task              OnboardingTask     @relation("OnboardingTaskInstanceTask", fields: [taskId], references: [id], onDelete: Cascade)
  employee          Employee           @relation("OnboardingTaskInstanceEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  @@index([onboardingId])
  @@index([taskId])
  @@index([employeeId])
  @@index([status])
}`);

newModels.push(`model OnboardingNote {
  id                String   @id @default(cuid())
  onboardingId      String
  employeeId        String
  companyId         String
  note              String
  noteType          String
  createdById       String
  createdAt         DateTime @default(now())
  @@index([onboardingId])
}`);

newModels.push(`model LiveRoom {
  id                String   @id @default(cuid())
  title             String
  description       String?
  type              String   @default("AUDIO")
  category          String   @default("GENERAL")
  hostId            String
  coHostIds         String[]
  scheduledAt       DateTime?
  startedAt         DateTime?
  endedAt           DateTime?
  duration          Int      @default(0)
  status            String   @default("SCHEDULED")
  streamUrl         String?
  streamKey         String?
  isPrivate         Boolean  @default(false)
  maxParticipants   Int      @default(100)
  isRecording       Boolean  @default(false)
  recordingUrl      String?
  recordingDuration Int      @default(0)
  transcriptText    String?
  transcriptStatus  String   @default("NONE")
  totalViews        Int      @default(0)
  peakViewers       Int      @default(0)
  totalMessages     Int      @default(0)
  isModerated       Boolean  @default(false)
  muteOnJoin        Boolean  @default(false)
  requireApproval   Boolean  @default(false)
  password          String?
  allowedUsers      String[]
  blockedUsers      String[]
  notifyOnStart     Boolean  @default(true)
  createdById       String
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  host              User     @relation("LiveRoomHost", fields: [hostId], references: [id], onDelete: Cascade)
  participants      LiveRoomParticipant[]
  messages          LiveRoomMessage[]
  transcripts       LiveTranscript[]
  notifications     LiveRoomNotification[]
  moderationLogs    LiveRoomModerationLog[]
  roomHistory       LiveRoomHistory[]
  @@index([status])
  @@index([category])
  @@index([hostId])
  @@index([scheduledAt])
  @@index([isPrivate])
}`);

newModels.push(`model LiveRoomParticipant {
  id                String   @id @default(cuid())
  roomId            String
  userId            String
  role              String   @default("LISTENER")
  isMuted           Boolean  @default(false)
  isVideoOn         Boolean  @default(false)
  isScreenSharing   Boolean  @default(false)
  isSpeaking        Boolean  @default(false)
  raisedHand        Boolean  @default(false)
  raisedHandAt      DateTime?
  reactions         Json?
  joinedAt          DateTime @default(now())
  leftAt            DateTime?
  lastActiveAt      DateTime @default(now())
  connectionQuality String?
  deviceInfo        String?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  room              LiveRoom @relation("LiveRoomParticipantRoom", fields: [roomId], references: [id], onDelete: Cascade)
  user              User     @relation("LiveRoomParticipantUser", fields: [userId], references: [id], onDelete: Cascade)
  @@unique([roomId, userId])
  @@index([roomId])
  @@index([userId])
  @@index([leftAt])
}`);

newModels.push(`model LiveRoomMessage {
  id                String   @id @default(cuid())
  roomId            String
  userId            String
  content           String
  messageType       String   @default("TEXT")
  replyToId         String?
  createdAt         DateTime @default(now())
  room              LiveRoom @relation("LiveRoomMessageRoom", fields: [roomId], references: [id], onDelete: Cascade)
  user              User     @relation("LiveRoomMessageUser", fields: [userId], references: [id], onDelete: Cascade)
  replyTo           LiveRoomMessage?  @relation("MessageReply", fields: [replyToId], references: [id], onDelete: SetNull)
  @@index([roomId])
  @@index([userId])
  @@index([createdAt])
}`);

newModels.push(`model LiveTranscript {
  id                String   @id @default(cuid())
  roomId            String
  speakerId         String?
  startMs           Int      @default(0)
  endMs             Int      @default(0)
  text              String
  confidence        Decimal? @db.Decimal(5, 4)
  language          String   @default("ar")
  createdAt         DateTime @default(now())
  room              LiveRoom @relation("LiveTranscriptRoom", fields: [roomId], references: [id], onDelete: Cascade)
  speaker           User?    @relation("LiveTranscriptSpeaker", fields: [speakerId], references: [id], onDelete: SetNull)
  @@index([roomId])
  @@index([speakerId])
  @@index([startMs])
}`);

newModels.push(`model LiveRoomNotification {
  id                String   @id @default(cuid())
  roomId            String
  userId            String
  type              String
  title             String
  message           String
  data              Json?
  isRead            Boolean  @default(false)
  readAt            DateTime?
  createdAt         DateTime @default(now())
  room              LiveRoom @relation("LiveRoomNotificationRoom", fields: [roomId], references: [id], onDelete: Cascade)
  user              User     @relation("LiveRoomNotificationUser", fields: [userId], references: [id], onDelete: Cascade)
  @@index([userId])
  @@index([roomId])
  @@index([isRead])
  @@index([type])
}`);

newModels.push(`model LiveRoomModerationLog {
  id                String   @id @default(cuid())
  roomId            String
  targetUserId      String
  actionById        String
  action            String
  reason            String?
  createdAt         DateTime @default(now())
  room              LiveRoom @relation("LiveRoomModerationLogRoom", fields: [roomId], references: [id], onDelete: Cascade)
  targetUser        User     @relation("ModerationTarget", fields: [targetUserId], references: [id], onDelete: Cascade)
  actionBy          User     @relation("ModerationAction", fields: [actionById], references: [id], onDelete: Cascade)
  @@index([roomId])
  @@index([targetUserId])
  @@index([actionById])
  @@index([action])
}`);

newModels.push(`model LiveRoomHistory {
  id                String   @id @default(cuid())
  roomId            String
  userId            String
  firstJoinedAt     DateTime @default(now())
  lastJoinedAt      DateTime @default(now())
  totalVisits       Int      @default(1)
  totalTimeSpent    Int      @default(0)
  messagesCount     Int      @default(0)
  reactionsCount    Int      @default(0)
  updatedAt         DateTime @updatedAt
  room              LiveRoom @relation("LiveRoomHistoryRoom", fields: [roomId], references: [id], onDelete: Cascade)
  user              User     @relation("LiveRoomHistoryUser", fields: [userId], references: [id], onDelete: Cascade)
  @@unique([roomId, userId])
  @@index([roomId])
  @@index([userId])
}`);

newModels.push(`model LiveRoomReaction {
  id                String   @id @default(cuid())
  roomId            String
  userId            String
  reaction          String
  createdAt         DateTime @default(now())
  room              LiveRoom @relation("LiveRoomReactionRoom", fields: [roomId], references: [id], onDelete: Cascade)
  user              User     @relation("LiveRoomReactionUser", fields: [userId], references: [id], onDelete: Cascade)
  @@unique([roomId, userId, reaction])
  @@index([roomId])
  @@index([userId])
}`);

newModels.push(`model LiveRoomInvite {
  id                String   @id @default(cuid())
  roomId            String
  invitedById       String
  invitedUserId     String
  status            String   @default("PENDING")
  message           String?
  expiresAt         DateTime?
  respondedAt       DateTime?
  createdAt         DateTime @default(now())
  room              LiveRoom @relation("LiveRoomInviteRoom", fields: [roomId], references: [id], onDelete: Cascade)
  invitedBy         User     @relation("InviteSender", fields: [invitedById], references: [id], onDelete: Cascade)
  invitedUser       User     @relation("InviteRecipient", fields: [invitedUserId], references: [id], onDelete: Cascade)
  @@unique([roomId, invitedUserId])
  @@index([roomId])
  @@index([invitedUserId])
  @@index([status])
}`);

console.log(`New models defined: ${newModels.length}`);

// Append all new models at the end
const final = lines.join('\n') + '\n\n// ============================================\n// New Models (from additions)\n// ============================================\n\n' + newModels.join('\n\n');

// Write to schema.prisma
fs.writeFileSync('prisma/schema.prisma', final);
console.log(`Written to schema.prisma`);

// Count models
const modelCount = (final.match(/^model /gm) || []).length;
console.log(`Total models: ${modelCount}`);
