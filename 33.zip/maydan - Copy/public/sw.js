// ميدان الاقتصاد Service Worker v5
// Enhanced PWA support for native-like Android app experience
//
// Strategy:
//  - Navigation requests (HTML pages): network-first, fall back to cache, then offline page
//  - Static assets (_next/static, images, fonts): cache-first with long TTL
//  - API routes: network-first with short TTL cache for offline resilience
//  - Uploaded media: cache-first (stale-while-revalidate) with size limit
//  - Push notification support with Arabic RTL
//  - Background sync for offline post creation
//  - Google Fonts: cache-first for performance

const VERSION = 'midan-v6';
const STATIC_CACHE = `${VERSION}-static`;
const RUNTIME_CACHE = `${VERSION}-runtime`;
const MEDIA_CACHE = `${VERSION}-media`;
const API_CACHE = `${VERSION}-api`;
const FONT_CACHE = `${VERSION}-fonts`;
const OFFLINE_URL = '/offline.html';

// API cache TTL: 2 minutes (short TTL for dynamic data)
const API_CACHE_TTL_MS = 2 * 60 * 1000;

const PRECACHE_URLS = [
  '/',
  '/offline.html',
  '/logo.jpg',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/apple-touch-icon.png',
];

const MAX_MEDIA_ENTRIES = 80; // ~80 images = ~8 MB
const MAX_RUNTIME_ENTRIES = 50;
const MAX_API_ENTRIES = 100;

// ============================================
// Install — precache critical assets
// ============================================
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

// ============================================
// Activate — clean old caches
// ============================================
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((k) => !k.startsWith(VERSION))
          .map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// ============================================
// Helper: check if cached response is still fresh
// ============================================
function isFresh(response) {
  if (!response || !response.headers) return false;
  const dateHeader = response.headers.get('sw-cache-timestamp');
  if (!dateHeader) return true; // no timestamp means cache-first, always use
  const cachedAt = parseInt(dateHeader, 10);
  return (Date.now() - cachedAt) < API_CACHE_TTL_MS;
}

// Helper: add timestamp header to response for TTL tracking
function addTimestampHeader(response) {
  const headers = new Headers(response.headers);
  headers.set('sw-cache-timestamp', Date.now().toString());
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

// ============================================
// Fetch — strategy router
// ============================================
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Handle POST/PUT/DELETE for background sync
  if (request.method !== 'GET') {
    // Only intercept same-origin API mutations
    const url = new URL(request.url);
    if (url.origin === self.location.origin && url.pathname.startsWith('/api/')) {
      event.respondWith(
        fetch(request).catch(() => {
          // Queue for background sync
          return queueBackgroundSync(request);
        })
      );
    }
    return;
  }

  const url = new URL(request.url);

  // Cross-origin Google Fonts — cache-first
  if (url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com') {
    event.respondWith(
      caches.open(FONT_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) return cached;
        try {
          const res = await fetch(request);
          if (res.ok) {
            const clone = res.clone();
            cache.put(request, clone);
          }
          return res;
        } catch {
          return cached || new Response('', { status: 503, statusText: 'غير متصل' });
        }
      })
    );
    return;
  }

  // Same-origin only for remaining strategies
  if (url.origin !== self.location.origin) return;

  // Skip Next.js HMR and dev requests
  if (url.pathname.startsWith('/_next/webpack') || url.pathname.startsWith('/_next/hmr')) return;

  // API routes — network-first with short TTL cache
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      caches.open(API_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        // If cached and still fresh, return it immediately
        if (cached && isFresh(cached)) return cached;

        try {
          const res = await fetch(request);
          if (res.ok) {
            const timestamped = addTimestampHeader(res.clone());
            cache.put(request, timestamped);
            trimCache(API_CACHE, MAX_API_ENTRIES);
          }
          return res;
        } catch {
          // Network failed — return stale cache if available
          if (cached) return cached;
          return new Response(
            JSON.stringify({ error: 'غير متصل بالإنترنت', offline: true }),
            {
              status: 503,
              headers: { 'Content-Type': 'application/json' },
            }
          );
        }
      })
    );
    return;
  }

  // Navigation requests — network-first with offline fallback
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((res) => {
          const clone = res.clone();
          caches.open(RUNTIME_CACHE).then((c) => c.put(request, clone));
          return res;
        })
        .catch(async () => {
          const cached = await caches.match(request);
          return cached || caches.match(OFFLINE_URL);
        })
    );
    return;
  }

  // Next.js static assets (JS, CSS) — cache-first (long-lived)
  if (url.pathname.startsWith('/_next/static/') || url.pathname.startsWith('/_next/image')) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(STATIC_CACHE).then((c) => c.put(request, clone));
          }
          return res;
        });
      })
    );
    return;
  }

  // PWA icons and logos — cache-first
  if (
    url.pathname.match(/\.(png|jpg|jpeg|webp|svg|ico)$/) &&
    (url.pathname.startsWith('/icon-') || url.pathname.startsWith('/logo') || url.pathname.startsWith('/apple-') || url.pathname.startsWith('/favicon'))
  ) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(STATIC_CACHE).then((c) => c.put(request, clone));
          }
          return res;
        });
      })
    );
    return;
  }

  // Uploaded media (/uploads/*) — stale-while-revalidate with size cap
  if (url.pathname.startsWith('/uploads/')) {
    event.respondWith(
      caches.open(MEDIA_CACHE).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) {
          // Refresh in background (stale-while-revalidate)
          fetch(request).then((res) => {
            if (res.ok) cache.put(request, res.clone());
          }).catch(() => {});
          return cached;
        }
        try {
          const res = await fetch(request);
          if (res.ok) {
            cache.put(request, res.clone()).then(() => trimCache(MEDIA_CACHE, MAX_MEDIA_ENTRIES));
          }
          return res;
        } catch {
          return new Response('الصورة غير متوفرة بدون اتصال', { status: 503 });
        }
      })
    );
    return;
  }

  // Other GET requests — stale-while-revalidate
  event.respondWith(
    caches.match(request).then((cached) => {
      const networkFetch = fetch(request).then((res) => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(RUNTIME_CACHE).then((c) => {
            c.put(request, clone);
            trimCache(RUNTIME_CACHE, MAX_RUNTIME_ENTRIES);
          });
        }
        return res;
      }).catch(() => cached);
      return cached || networkFetch;
    })
  );
});

// ============================================
// Background Sync — queue failed mutations for retry
// ============================================
const SYNC_QUEUE_NAME = 'midan-post-queue';

async function queueBackgroundSync(request) {
  // Store the request for later replay
  const body = await request.text();
  const entry = {
    url: request.url,
    method: request.method,
    headers: Object.fromEntries(request.headers.entries()),
    body: body,
    timestamp: Date.now(),
  };

  // Store in IndexedDB-like approach using cache API
  const cache = await caches.open(RUNTIME_CACHE);
  const queueKey = `/__sync_queue__/${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  await cache.put(queueKey, new Response(JSON.stringify(entry), {
    headers: { 'Content-Type': 'application/json' },
  }));

  // Register for background sync if available
  if ('sync' in self.registration) {
    try {
      await self.registration.sync.register(SYNC_QUEUE_NAME);
    } catch {
      // Sync registration failed — will retry on next fetch
    }
  }

  // Return a friendly offline response
  return new Response(
    JSON.stringify({
      success: true,
      queued: true,
      message: 'تم حفظ المنشور وسيتم نشره عند توفر الاتصال بالإنترنت',
    }),
    {
      status: 202,
      headers: { 'Content-Type': 'application/json' },
    }
  );
}

// Background sync event handler
self.addEventListener('sync', (event) => {
  if (event.tag === SYNC_QUEUE_NAME) {
    event.waitUntil(replaySyncQueue());
  }
});

async function replaySyncQueue() {
  const cache = await caches.open(RUNTIME_CACHE);
  const keys = await cache.keys();

  const syncKeys = keys.filter((k) => k.url.includes('/__sync_queue__/'));
  if (syncKeys.length === 0) return;

  for (const key of syncKeys) {
    try {
      const response = await cache.match(key);
      if (!response) continue;

      const entry = await response.json();
      // Skip entries older than 24 hours
      if (Date.now() - entry.timestamp > 24 * 60 * 60 * 1000) {
        await cache.delete(key);
        continue;
      }

      const replayRequest = new Request(entry.url, {
        method: entry.method,
        headers: entry.headers,
        body: entry.body || undefined,
      });

      const res = await fetch(replayRequest);
      if (res.ok) {
        await cache.delete(key);
        // Notify clients that a queued item was successfully synced
        notifyClients({
          type: 'SYNC_COMPLETE',
          message: 'تم نشر المنشور بنجاح',
        });
      }
    } catch {
      // Network still unavailable — will retry on next sync event
      break;
    }
  }
}

// Notify all clients
function notifyClients(message) {
  self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
    clients.forEach((client) => {
      client.postMessage(message);
    });
  });
}

// ============================================
// Trim cache to max entries (LRU-ish)
// ============================================
async function trimCache(cacheName, maxEntries) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length <= maxEntries) return;
  const toDelete = keys.length - maxEntries;
  for (let i = 0; i < toDelete; i++) {
    await cache.delete(keys[i]);
  }
}

// ============================================
// Push notification support (Arabic RTL)
// ============================================
self.addEventListener('push', (event) => {
  if (!event.data) return;

  try {
    const data = event.data.json();
    const title = data.title || 'ميدان الاقتصاد';
    const options = {
      body: data.body || data.message || '',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      image: data.image || undefined,
      vibrate: [100, 50, 100],
      data: {
        url: data.url || '/',
        type: data.type || 'general',
      },
      actions: data.actions || [
        { action: 'open', title: 'فتح' },
        { action: 'dismiss', title: 'إغلاق' },
      ],
      dir: 'rtl',
      lang: 'ar',
      tag: data.tag || `notif-${Date.now()}`,
      renotify: true,
      requireInteraction: data.requireInteraction || false,
    };

    event.waitUntil(
      self.registration.showNotification(title, options)
    );
  } catch {
    // Fallback for non-JSON push data
    event.waitUntil(
      self.registration.showNotification('ميدان الاقتصاد', {
        body: event.data.text() || 'لديك إشعار جديد',
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [100, 50, 100],
        dir: 'rtl',
        lang: 'ar',
        actions: [
          { action: 'open', title: 'فتح' },
          { action: 'dismiss', title: 'إغلاق' },
        ],
      })
    );
  }
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const urlToOpen = event.notification.data?.url || '/';

  // Handle action buttons
  if (event.action === 'dismiss') return;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // If there's already a window open, focus it and navigate
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(urlToOpen);
          return client.focus();
        }
      }
      // Otherwise open a new window
      return self.clients.openWindow(urlToOpen);
    })
  );
});

// ============================================
// Message — allow client to skip waiting & clear caches
// ============================================
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  // Handle cache clear request from client
  if (event.data && event.data.type === 'CLEAR_CACHES') {
    event.waitUntil(
      caches.keys().then((keys) =>
        Promise.all(keys.map((k) => caches.delete(k)))
      )
    );
  }
});