#!/bin/bash
# ============================================
# سكريبت إصلاح قاعدة البيانات وتجهيز بيئة التطوير
# Database Fix & Dev Environment Setup Script
# ============================================
set -e

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "============================================"
echo "  إصلاح قاعدة بيانات ميدان"
echo "  Maydan Database Fix"
echo "============================================"
echo ""

# ── 1. Parse DATABASE_URL from .env ──────────
if [ ! -f ".env" ]; then
    echo -e "${RED}❌ ملف .env غير موجود!${NC}"
    exit 1
fi

DB_URL=$(grep -E '^DATABASE_URL=' .env | grep -v '^#' | head -1 | sed 's/^DATABASE_URL=//' | tr -d '"' | tr -d "'")

if [ -z "$DB_URL" ]; then
    echo -e "${RED}❌ DATABASE_URL غير موجود أو معطّل في .env${NC}"
    echo "تأكد من أن DATABASE_URL غير مسبوق بـ #"
    exit 1
fi

# Parse PostgreSQL URL
DB_URL_CLEAN="${DB_URL#postgresql://}"
DB_URL_CLEAN="${DB_URL_CLEAN#postgres://}"

DB_USER_PASS="${DB_URL_CLEAN%%@*}"
DB_HOST_DB="${DB_URL_CLEAN#*@}"

DB_USER="${DB_USER_PASS%%:*}"
DB_PASS="${DB_USER_PASS#*:}"

DB_HOST_DB_FULL="${DB_HOST_DB%%\?*}"
DB_NAME="${DB_HOST_DB_FULL##*/}"

DB_HOST_PORT="${DB_HOST_DB_FULL%%/*}"
DB_HOST="${DB_HOST_PORT%%:*}"
DB_PORT="${DB_HOST_PORT##*:}"

# Default port if not specified
if [ "$DB_HOST" = "$DB_PORT" ]; then
    DB_PORT="5432"
fi

# Handle case where there's no port
if [ -z "$DB_PORT" ] || [ "$DB_PORT" = "$DB_HOST" ]; then
    DB_PORT="5432"
fi

echo -e "${BLUE}📋 معلومات قاعدة البيانات:${NC}"
echo "  المستخدم:      $DB_USER"
echo "  المضيف:        $DB_HOST"
echo "  المنفذ:        $DB_PORT"
echo "  قاعدة البيانات: $DB_NAME"
echo ""

# ── 2. Clean parent conflicts ───────────────
PARENT_LOCKFILE="$HOME/package-lock.json"
if [ -f "$PARENT_LOCKFILE" ]; then
    echo -e "${YELLOW}⚠️  حذف $PARENT_LOCKFILE (يسبب تعارض tailwindcss)${NC}"
    rm -f "$PARENT_LOCKFILE"
fi
if [ -f "$HOME/package.json" ]; then
    echo -e "${YELLOW}⚠️  حذف $HOME/package.json (يسبب تعارض)${NC}"
    rm -f "$HOME/package.json"
fi
if [ -d "$HOME/node_modules" ]; then
    echo -e "${YELLOW}⚠️  حذف $HOME/node_modules${NC}"
    rm -rf "$HOME/node_modules"
fi

# ── 3. Check/Install PostgreSQL ─────────────
if ! command -v psql &> /dev/null; then
    echo -e "${YELLOW}📦 PostgreSQL غير مثبت — جارٍ التثبيت...${NC}"
    sudo apt-get update -qq
    sudo apt-get install -y -qq postgresql postgresql-contrib
    echo -e "${GREEN}✅ تم تثبيت PostgreSQL${NC}"
else
    echo -e "${GREEN}✅ PostgreSQL موجود${NC}"
fi

# ── 4. Start PostgreSQL ────────────────────
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
    echo -e "${YELLOW}🔄 تشغيل PostgreSQL...${NC}"
    sudo systemctl start postgresql 2>/dev/null || sudo service postgresql start 2>/dev/null || true
    sleep 3
    if pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
        echo -e "${GREEN}✅ PostgreSQL يعمل${NC}"
    else
        echo -e "${RED}❌ فشل تشغيل PostgreSQL${NC}"
        echo "جرّب: sudo systemctl start postgresql"
        exit 1
    fi
else
    echo -e "${GREEN}✅ PostgreSQL يعمل${NC}"
fi

# ── 5. Create user and database ────────────
echo ""
echo -e "${BLUE}📋 إنشاء المستخدم وقاعدة البيانات...${NC}"

USER_EXISTS=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" 2>/dev/null || echo "")

if [ "$USER_EXISTS" = "1" ]; then
    echo -e "${GREEN}✅ المستخدم ${DB_USER} موجود${NC}"
    # Update password in case it changed
    sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" 2>/dev/null || true
    echo -e "${GREEN}✅ تم تحديث كلمة المرور للمستخدم ${DB_USER}${NC}"
else
    sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"
    echo -e "${GREEN}✅ تم إنشاء المستخدم ${DB_USER}${NC}"
fi

DB_EXISTS=$(sudo -u postgres psql -lqt 2>/dev/null | cut -d \| -f 1 | grep -qw "${DB_NAME}" && echo "1" || echo "")

if [ "$DB_EXISTS" = "1" ]; then
    echo -e "${GREEN}✅ قاعدة البيانات ${DB_NAME} موجودة${NC}"
else
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"
    echo -e "${GREEN}✅ تم إنشاء قاعدة البيانات ${DB_NAME}${NC}"
fi

# Grant permissions
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -d "${DB_NAME}" -c "GRANT ALL ON SCHEMA public TO ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -d "${DB_NAME}" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -d "${DB_NAME}" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO ${DB_USER};" 2>/dev/null || true

# ── 6. Fix pg_hba.conf if needed ───────────
echo ""
echo -e "${BLUE}🔐 التحقق من الاتصال...${NC}"

if PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -c "SELECT 1;" &>/dev/null; then
    echo -e "${GREEN}✅ الاتصال بقاعدة البيانات ناجح!${NC}"
else
    echo -e "${YELLOW}⚠️  الاتصال فشل — جارٍ إصلاح pg_hba.conf...${NC}"
    
    PG_HBA=$(sudo -u postgres psql -c "SHOW hba_file;" -t 2>/dev/null | tr -d ' \n')
    
    if [ -n "$PG_HBA" ] && [ -f "$PG_HBA" ]; then
        sudo cp "$PG_HBA" "${PG_HBA}.bak.$(date +%Y%m%d%H%M%S)"
        
        sudo sed -i 's/local\s*all\s*all\s*peer/local   all             all                                     md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*127\.0\.0\.1\/32\s*scram-sha-256/host    all             all             127.0.0.1\/32            md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*::1\/128\s*scram-sha-256/host    all             all             ::1\/128                 md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*127\.0\.0\.1\/32\s*ident/host    all             all             127.0.0.1\/32            md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*::1\/128\s*ident/host    all             all             ::1\/128                 md5/' "$PG_HBA"
        
        sudo systemctl reload postgresql 2>/dev/null || sudo service postgresql reload 2>/dev/null || true
        echo -e "${GREEN}✅ تم تعديل pg_hba.conf${NC}"
        
        sleep 2
        if PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -c "SELECT 1;" &>/dev/null; then
            echo -e "${GREEN}✅ الاتصال ناجح الآن!${NC}"
        else
            echo -e "${RED}❌ الاتصال فشل. راجع: $PG_HBA${NC}"
            exit 1
        fi
    else
        echo -e "${RED}❌ لم يتم العثور على pg_hba.conf${NC}"
        exit 1
    fi
fi

# ── 7. Remove SQLite files ─────────────────
echo ""
echo -e "${BLUE}🧹 حذف ملفات SQLite المتبقية...${NC}"
for f in prisma/dev.db prisma/dev.db-shm prisma/dev.db-wal prisma/dev.db.bak prisma/db/custom.db; do
    if [ -f "$f" ]; then
        rm -f "$f"
        echo -e "${YELLOW}  حذف: $f${NC}"
    fi
done
echo -e "${GREEN}✅ تم التنظيف${NC}"

# ── 8. Install dependencies ────────────────
echo ""
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}📦 تثبيت التبعيات...${NC}"
    npm install
    echo -e "${GREEN}✅ تم تثبيت التبعيات${NC}"
else
    echo -e "${GREEN}✅ node_modules موجود${NC}"
fi

# ── 9. Generate Prisma Client ──────────────
echo ""
echo -e "${YELLOW}🔄 إنشاء Prisma Client...${NC}"
npx prisma generate
echo -e "${GREEN}✅ تم إنشاء Prisma Client${NC}"

# ── 10. Push schema to database ────────────
echo ""
echo -e "${YELLOW}🔄 تحديث هيكل قاعدة البيانات...${NC}"
npx prisma db push --accept-data-loss 2>&1
echo -e "${GREEN}✅ تم تحديث الهيكل${NC}"

# ── 11. Seed database ──────────────────────
echo ""
echo -e "${YELLOW}🔄 إنشاء بيانات تجريبية...${NC}"
if npx prisma db seed 2>&1; then
    echo -e "${GREEN}✅ تم إنشاء البيانات بنجاح${NC}"
else
    echo -e "${YELLOW}⚠️  Seed فشل (راجع الأخطاء أعلاه) — محاولة بديلة بـ tsx...${NC}"
    npx tsx prisma/seed.ts 2>&1 && echo -e "${GREEN}✅ تم إنشاء البيانات (tsx)${NC}" || echo -e "${RED}❌ فشل Seed — شغّل يدوياً: npx tsx prisma/seed.ts${NC}"
fi

# ── 12. Verify ─────────────────────────────
echo ""
echo -e "${BLUE}🔍 التحقق النهائي...${NC}"
USER_COUNT=$(PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -tAc "SELECT COUNT(*) FROM \"User\";" 2>/dev/null || echo "ERROR")

echo "  عدد المستخدمين: $USER_COUNT"

if [[ "$USER_COUNT" =~ ^[0-9]+$ ]] && [ "$USER_COUNT" -gt 0 ]; then
    echo ""
    echo -e "${GREEN}============================================${NC}"
    echo -e "${GREEN}  ✅ الإعداد مكتمل بنجاح!${NC}"
    echo -e "${GREEN}============================================${NC}"
    echo ""
    echo "بيانات الدخول التجريبية:"
    echo "  البريد:      owner@midaniq.com"
    echo "  كلمة المرور:  SeedPass1!"
    echo ""
    echo "لتشغيل المشروع:"
    echo "  npm run dev"
    echo ""
else
    echo ""
    echo -e "${YELLOW}⚠️  قاعدة البيانات جاهزة لكن لا يوجد مستخدمين${NC}"
    echo "شغّل Seed يدوياً:"
    echo "  npx tsx prisma/seed.ts"
    echo ""
fi