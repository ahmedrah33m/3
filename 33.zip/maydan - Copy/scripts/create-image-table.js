const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

const statements = [
  `CREATE TABLE IF NOT EXISTS "Image" (
    "id" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "storagePath" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "userId" TEXT,
    "mimeType" TEXT,
    "format" TEXT,
    "width" INTEGER,
    "height" INTEGER,
    "fileSize" INTEGER,
    "originalSize" INTEGER,
    "savedBytes" INTEGER,
    "savedPercent" DOUBLE PRECISION,
    "variants" JSONB,
    "processed" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Image_pkey" PRIMARY KEY ("id")
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS "Image_url_key" ON "Image"("url")`,
  `CREATE INDEX IF NOT EXISTS "Image_storagePath_idx" ON "Image"("storagePath")`,
  `CREATE INDEX IF NOT EXISTS "Image_userId_idx" ON "Image"("userId")`,
  `CREATE INDEX IF NOT EXISTS "Image_type_idx" ON "Image"("type")`,
  `CREATE INDEX IF NOT EXISTS "Image_createdAt_idx" ON "Image"("createdAt")`,
  `ALTER TABLE "Image" DROP CONSTRAINT IF EXISTS "Image_userId_fkey"`,
  `ALTER TABLE "Image" ADD CONSTRAINT "Image_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE`,
]

async function main() {
  for (const s of statements) {
    await db.$executeRawUnsafe(s)
  }
  console.log('Image table created')
  const t = await db.$queryRawUnsafe(`select to_regclass('public."Image"') as t`)
  console.log('to_regclass:', JSON.stringify(t))
  await db.$disconnect()
}

main().catch((e) => {
  console.log('err:', e.message.slice(0, 400))
  process.exit(1)
})
