#!/bin/bash
# ============================================================
# سكربت تطبيق كلمة المرور الصحيحة وإصلاح الاتصال بقاعدة البيانات
# Apply Correct Password & Fix Database Connection
# ============================================================
#
# كلمة المرور: A859612003Shq!
#
# الاستخدام:
#   cd midanco
#   chmod +x scripts/apply-correct-password.sh
#   ./scripts/apply-correct-password.sh
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info()  { echo -e "${BLUE}ℹ️  $1${NC}"; }
print_ok()    { echo -e "${GREEN}✅ $1${NC}"; }
print_warn()  { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }

# ── المتغيرات ──────────────────────────────────────────────
DB_USER="maydan"
DB_NAME="maydan_db"
DB_PASSWORD="A859612003Shq!"  # كلمة المرور الصحيحة من قاعدة البيانات
DB_HOST="localhost"
DB_PORT="5432"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
ENV_LOCAL="$PROJECT_DIR/.env.local"
ENV_FILE="$PROJECT_DIR/.env"

echo "============================================================"
echo "  تطبيق كلمة المرور الصحيحة وإصلاح الاتصال"
echo "  Apply Correct Password & Fix DB Connection"
echo "============================================================"
echo ""
print_info "Database user: $DB_USER"
print_info "Database name: $DB_NAME"
print_info "Password:      $DB_PASSWORD"
print_info "Host:          $DB_HOST:$DB_PORT"
echo ""

# ── 1. تحديث .env.local ────────────────────────────────────
print_info "1️⃣  Updating .env.local..."

DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME?schema=public&connection_limit=5"
DIRECT_DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME?schema=public&connect_timeout=30"

if [ -f "$ENV_LOCAL" ]; then
    # Backup
    cp "$ENV_LOCAL" "$ENV_LOCAL.bak.$(date +%Y%m%d_%H%M%S)"
    print_ok "Backed up .env.local"

    # Update lines (escape & and ! in sed replacement)
    # Use | as delimiter to avoid issues with / in URL
    sed -i "s|^DATABASE_URL=.*|DATABASE_URL=$DATABASE_URL|" "$ENV_LOCAL"
    sed -i "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=$DIRECT_DATABASE_URL|" "$ENV_LOCAL"
    print_ok "Updated .env.local"
elif [ -f "$ENV_FILE" ]; then
    print_warn ".env.local not found. Updating .env instead..."
    cp "$ENV_FILE" "$ENV_FILE.bak.$(date +%Y%m%d_%H%M%S)"
    sed -i "s|^DATABASE_URL=.*|DATABASE_URL=$DATABASE_URL|" "$ENV_FILE"
    sed -i "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=$DIRECT_DATABASE_URL|" "$ENV_FILE"
    print_ok "Updated .env"
else
    print_error "Neither .env nor .env.local found in $PROJECT_DIR"
    print_info "Creating .env.local from .env.example..."
    if [ -f "$PROJECT_DIR/.env.example" ]; then
        cp "$PROJECT_DIR/.env.example" "$ENV_LOCAL"
        sed -i "s|^DATABASE_URL=.*|DATABASE_URL=$DATABASE_URL|" "$ENV_LOCAL"
        sed -i "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=$DIRECT_DATABASE_URL|" "$ENV_LOCAL"
        print_ok "Created .env.local"
    else
        print_error ".env.example not found. Cannot continue."
        exit 1
    fi
fi

# ── 2. التحقق من PostgreSQL ────────────────────────────────
print_info "2️⃣  Checking PostgreSQL..."

if ! command -v psql &> /dev/null; then
    print_error "psql not found. Install PostgreSQL first:"
    echo "  sudo apt install postgresql postgresql-contrib"
    exit 1
fi

if ! pg_isready -q 2>/dev/null; then
    print_warn "PostgreSQL not running. Attempting to start..."
    sudo systemctl start postgresql 2>/dev/null || \
    sudo service postgresql start 2>/dev/null || true
    sleep 2

    if ! pg_isready -q 2>/dev/null; then
        print_error "PostgreSQL is not running. Start it manually:"
        echo "  sudo systemctl start postgresql"
        echo ""
        echo "After PostgreSQL is running, re-run this script:"
        echo "  ./scripts/apply-correct-password.sh"
        exit 1
    fi
fi
print_ok "PostgreSQL is running"

# ── 3. اختبار الاتصال ──────────────────────────────────────
print_info "3️⃣  Testing connection with password..."

if PGPASSWORD="$DB_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "SELECT current_user, current_database();" 2>&1; then
    print_ok "Connection successful!"
else
    print_warn "Connection as '$DB_USER' failed. Trying to fix..."

    # Try to ensure user exists with correct password
    print_info "Ensuring user '$DB_USER' exists with correct password..."
    if sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1; then
        sudo -u postgres psql -c "ALTER USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
        print_ok "Password updated for existing user '$DB_USER'"
    else
        sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' CREATEDB;"
        print_ok "User '$DB_USER' created"
    fi

    # Ensure database exists
    print_info "Ensuring database '$DB_NAME' exists..."
    if ! sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1; then
        sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
        print_ok "Database '$DB_NAME' created"
    else
        print_ok "Database '$DB_NAME' already exists"
    fi

    # Grant privileges
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO $DB_USER;" 2>/dev/null || true
    sudo -u postgres psql -d "$DB_NAME" -c "ALTER SCHEMA public OWNER TO $DB_USER;" 2>/dev/null || true
    print_ok "Privileges granted"

    # Test connection again
    print_info "Retesting connection..."
    if PGPASSWORD="$DB_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "SELECT current_user, current_database();" 2>&1; then
        print_ok "Connection successful!"
    else
        print_error "Connection still failing. Check pg_hba.conf:"
        echo "  sudo nano /etc/postgresql/*/main/pg_hba.conf"
        echo "Ensure this line exists:"
        echo "  host    all    all    127.0.0.1/32    md5"
        echo "Then reload:"
        echo "  sudo systemctl reload postgresql"
        exit 1
    fi
fi

# ── 4. Prisma generate ─────────────────────────────────────
print_info "4️⃣  Generating Prisma client..."
cd "$PROJECT_DIR"

if [ ! -d "node_modules" ]; then
    print_warn "node_modules not found. Running npm install..."
    npm install
fi

if npx prisma generate 2>&1; then
    print_ok "Prisma client generated"
else
    print_error "prisma generate failed"
    exit 1
fi

# ── 5. Prisma db push ──────────────────────────────────────
print_info "5️⃣  Pushing schema to database..."

if npx prisma db push 2>&1; then
    print_ok "Schema pushed to database"
else
    print_error "prisma db push failed"
    print_info "Common causes:"
    echo "  1. Connection still failing (check .env.local)"
    echo "  2. Schema has errors (check prisma/schema.prisma)"
    echo "  3. Permission denied (run: sudo -u postgres psql -c \"GRANT ALL ON DATABASE maydan_db TO maydan;\")"
    exit 1
fi

# ── 6. ملخص نهائي ──────────────────────────────────────────
echo ""
echo "============================================================"
echo "  ✅ تم إصلاح الاتصال بقاعدة البيانات بنجاح!"
echo "  Database connection fixed successfully!"
echo "============================================================"
echo ""
print_info "Settings applied:"
echo "  User:     $DB_USER"
echo "  Password: $DB_PASSWORD"
echo "  Database: $DB_NAME"
echo "  Host:     $DB_HOST:$DB_PORT"
echo "  URL:      $DATABASE_URL"
echo ""
print_info "Next steps:"
echo "  1. Start dev server:  npm run dev"
echo "  2. Open browser:      http://localhost:3300"
echo "  3. Try logging in — should work now!"
echo ""
print_warn "⚠️  If login still fails after this:"
echo "  - The user 'maydan' in your DB might have a different password."
echo "  - Run: sudo -u postgres psql -c \"ALTER USER maydan WITH PASSWORD 'A859612003Shq!';\""
echo "  - Then restart: npm run dev"
echo ""
print_info "To create an admin user:"
echo "  npm run create-admin"
echo ""
print_info "To seed sample data:"
echo "  npm run db:seed"
echo ""
