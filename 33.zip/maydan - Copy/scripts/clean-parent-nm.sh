#!/bin/bash
# ============================================
# ميدان - تنظيف تعارضات node_modules الأب
# Maydan - Clean parent node_modules conflicts
# ============================================
# يحل مشكلة HMR: "Module factory is not available"
# السبب: Turbopack يحل next من مسارين:
#   [project]/maydan/node_modules/next/  (المشروع)
#   [project]/node_modules/next/          (المجلد الأب)
# الحل: حذف نسخة next من المجلد الأب
# ============================================

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PARENT_DIR="$(dirname "$PROJECT_DIR")"

echo "[Maydan] تنظيف تعارضات node_modules الأب..."

# حذف ملفات package من المجلد الأب
rm -f "$PARENT_DIR/package.json" 2>/dev/null
rm -f "$PARENT_DIR/package-lock.json" 2>/dev/null

# حذف next من node_modules الأب (سبب التعارض الرئيسي)
if [ -d "$PARENT_DIR/node_modules/next" ]; then
  rm -rf "$PARENT_DIR/node_modules/next"
  echo "[Maydan] ✓ تم حذف next من المجلد الأب (سبب تعارض HMR)"
fi

# حذف react و react-dom أيضاً من المجلد الأب (قد يسبب نفس المشكلة)
if [ -d "$PARENT_DIR/node_modules/react" ]; then
  rm -rf "$PARENT_DIR/node_modules/react"
  echo "[Maydan] ✓ تم حذف react من المجلد الأب"
fi

if [ -d "$PARENT_DIR/node_modules/react-dom" ]; then
  rm -rf "$PARENT_DIR/node_modules/react-dom"
  echo "[Maydan] ✓ تم حذف react-dom من المجلد الأب"
fi

# حذف الكاش
rm -rf "$PROJECT_DIR/.next" 2>/dev/null

echo "[Maydan] ✓ تم التنظيف"
