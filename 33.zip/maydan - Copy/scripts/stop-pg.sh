#!/bin/bash
# Stop PostgreSQL Server
PG_BIN=/home/z/my-project/db/pg/install/usr/lib/postgresql/17/bin
PG_DATA=/home/z/my-project/db/pgdata

$PG_BIN/pg_ctl -D $PG_DATA stop
echo "✅ تم إيقاف PostgreSQL"
