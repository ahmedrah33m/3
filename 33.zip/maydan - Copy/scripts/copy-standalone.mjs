import { existsSync, lstatSync, mkdirSync, readdirSync, copyFileSync } from 'node:fs'
import { join, relative, dirname } from 'node:path'

const root = process.cwd()
const standaloneDir = join(root, '.next', 'standalone')

function copyTree(from, to) {
  const stack = [from]
  while (stack.length > 0) {
    const current = stack.pop()
    const entries = readdirSync(current)
    for (const entry of entries) {
      const src = join(current, entry)
      const rel = relative(from, src)
      const dest = join(to, rel)
      const stat = lstatSync(src)
      if (stat.isDirectory()) {
        mkdirSync(dest, { recursive: true })
        stack.push(src)
      } else if (stat.isFile()) {
        mkdirSync(dirname(dest), { recursive: true })
        copyFileSync(src, dest)
      }
    }
  }
}

const jobs = [
  { from: join(root, '.next', 'static'), to: join(standaloneDir, '.next', 'static') },
  { from: join(root, 'public'), to: join(standaloneDir, 'public') },
]

for (const job of jobs) {
  if (!existsSync(job.from)) {
    console.warn(`[copy-standalone] skip: ${job.from} does not exist`)
    continue
  }
  mkdirSync(job.to, { recursive: true })
  copyTree(job.from, job.to)
  console.log(`[copy-standalone] copied ${job.from} -> ${job.to}`)
}
