/**
 * Migration: Fix article visibility issues
 * =========================================
 *
 * Problem 1: `publishedAt` column missing from Article table in dev.db
 *   → listArticles() uses orderBy: [{ publishedAt: 'desc' }] which throws
 *   → /api/users/[id] include.articles orderBy: [{ publishedAt: 'desc' }] also throws
 *   → Result: profile "Articles" tab always shows EmptyArticlesTab
 *
 * Problem 2: `User.articlesCount` is denormalized (set in seed) and drifts
 *   → User sees "10 مقالات" on profile but actually has 0 published
 *   → Counter never decrements when articles are deleted
 *
 * This script:
 *   1. Adds `publishedAt` column if missing
 *   2. Backfills `publishedAt` from `createdAt` for PUBLISHED articles
 *   3. Recomputes `articlesCount` for every user based on actual PUBLISHED, non-deleted articles
 *
 * Usage:
 *   node scripts/migrate-articles.js
 *
 * Or with Prisma:
 *   npx prisma db push   (preferred — syncs schema fully)
 *   npx tsx scripts/migrate-articles.ts
 *
 * Safe to run multiple times (idempotent).
 */

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');

// Locate dev.db — supports both SQLite (dev) and is a no-op for PostgreSQL (prod)
let dbPath;
if (process.env.DATABASE_URL?.startsWith('file:')) {
  dbPath = process.env.DATABASE_URL.replace('file:', '').replace(/^\/+/, '/');
} else if (!process.env.DATABASE_URL || process.env.DATABASE_URL.startsWith('postgres')) {
  // Default to local dev.db if no PostgreSQL URL is set
  dbPath = path.join(process.cwd(), 'prisma', 'dev.db');
} else {
  dbPath = process.env.DATABASE_URL;
}

if (!fs.existsSync(dbPath)) {
  console.log(`[SKIP] SQLite DB not found at ${dbPath}`);
  console.log('       If using PostgreSQL, run: npx prisma db push');
  console.log('       Then run: npx prisma db seed');
  process.exit(0);
}

console.log(`[Migration] Using SQLite DB: ${dbPath}`);
const db = new DatabaseSync(dbPath);

// ─── Step 1: Add publishedAt column if missing ─────────────────────────────
const articleCols = db.prepare("PRAGMA table_info(Article)").all();
const hasPublishedAt = articleCols.some(c => c.name === 'publishedAt');

if (!hasPublishedAt) {
  console.log('[Migration] Step 1: Adding `publishedAt` column to Article table...');
  db.exec(`ALTER TABLE Article ADD COLUMN publishedAt DATETIME;`);
  console.log('[Migration] ✓ Column added.');
} else {
  console.log('[Migration] Step 1: `publishedAt` column already exists — skipping.');
}

// ─── Step 2: Backfill publishedAt from createdAt for PUBLISHED articles ────
console.log('[Migration] Step 2: Backfilling publishedAt for PUBLISHED articles...');
const backfillResult = db.prepare(`
  UPDATE Article
  SET publishedAt = createdAt
  WHERE status = 'PUBLISHED' AND publishedAt IS NULL;
`).run();
console.log(`[Migration] ✓ Updated ${backfillResult.changes} rows.`);

// ─── Step 3: Recompute User.articlesCount ──────────────────────────────────
console.log('[Migration] Step 3: Recomputing User.articlesCount...');
const resetResult = db.prepare(`
  UPDATE User
  SET articlesCount = (
    SELECT COUNT(*) FROM Article a
    WHERE a.authorId = User.id
      AND a.status = 'PUBLISHED'
      AND a.deletedAt IS NULL
  );
`).run();
console.log(`[Migration] ✓ Reset articlesCount for ${resetResult.changes} users.`);

// ─── Step 4: Show summary ──────────────────────────────────────────────────
console.log('\n=== Summary ===');
const totalArticles = db.prepare("SELECT COUNT(*) as cnt FROM Article").get();
const publishedArticles = db.prepare("SELECT COUNT(*) as cnt FROM Article WHERE status='PUBLISHED' AND deletedAt IS NULL").get();
const usersWithArticles = db.prepare("SELECT COUNT(*) as cnt FROM User WHERE articlesCount > 0").get();

console.log(`Total articles: ${totalArticles.cnt}`);
console.log(`Published & visible: ${publishedArticles.cnt}`);
console.log(`Users with at least 1 article: ${usersWithArticles.cnt}`);

console.log('\n=== Top users by articlesCount ===');
const topUsers = db.prepare("SELECT name, articlesCount FROM User WHERE articlesCount > 0 ORDER BY articlesCount DESC LIMIT 10").all();
topUsers.forEach(u => console.log(`  ${u.name}: ${u.articlesCount} مقال`));

db.close();
console.log('\n[Migration] Done ✓');
