#!/bin/bash
# ============================================
# سكريبت الاسترداد التلقائي
# Automatic Restore Script for Maydan Al-Iqtisad
# ============================================
# الاستخدام:
#   bash scripts/restore.sh                          # استرداد تفاعلي
#   bash scripts/restore.sh --latest                 # استرداد آخر نسخة
#   bash scripts/restore.sh --db                     # استرداد قاعدة البيانات فقط
#   bash scripts/restore.sh --db --file <path>       # استرداد من ملف محدد
#   bash scripts/restore.sh --uploads                # استرداد الملفات المرفوعة فقط
#   bash scripts/restore.sh --redis                  # استرداد Redis فقط
#   bash scripts/restore.sh --all                    # استرداد كل شيء
#   bash scripts/restore.sh --list                   # عرض النسخ المتاحة
#   bash scripts/restore.sh --from-s3                # استرداد من السحابة
# ============================================

set -uo pipefail

# ============================================
# كشف البيئة تلقائياً
# ============================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

if [[ -f "$PROJECT_DIR/.env" ]]; then
    set -a; source "$PROJECT_DIR/.env" 2>/dev/null || true; set +a
fi

# كشف نوع البيئة
ENV_MODE="local"
if command -v docker &>/dev/null && docker ps &>/dev/null 2>&1; then
    if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "maydan-postgres"; then
        ENV_MODE="docker"
    fi
fi

# ============================================
# إعدادات - تتكيف مع البيئة والصلاحيات
# ============================================
determine_writable_path() {
    local docker_path="$1"
    local local_path="$2"

    if [[ "$ENV_MODE" == "docker" && -d "$(dirname "$docker_path")" && -w "$(dirname "$docker_path")" ]]; then
        echo "$docker_path"
    elif [[ "$ENV_MODE" == "docker" && -d "$docker_path" && -w "$docker_path" ]]; then
        echo "$docker_path"
    else
        echo "$local_path"
    fi
}

BACKUP_ROOT=$(determine_writable_path "/mnt/hdd/backups" "$PROJECT_DIR/backups")
LOG_DIR=$(determine_writable_path "/mnt/hdd/logs" "$PROJECT_DIR/backups/logs")

if [[ "$ENV_MODE" == "docker" && -d "/mnt/hdd/minio-data/uploads" ]]; then
    UPLOADS_TARGET_DIR="/mnt/hdd/minio-data/uploads"
else
    UPLOADS_TARGET_DIR="$PROJECT_DIR/public/uploads"
fi

# إنشاء مجلد السجلات مبكراً
mkdir -p "$LOG_DIR" 2>/dev/null || {
    LOG_DIR="/tmp/maydan-restore-logs"
    mkdir -p "$LOG_DIR"
}

PG_BACKUP_DIR="$BACKUP_ROOT/postgresql"
UPLOADS_BACKUP_DIR="$BACKUP_ROOT/uploads"
REDIS_BACKUP_DIR="$BACKUP_ROOT/redis"

POSTGRES_CONTAINER="maydan-postgres"
REDIS_CONTAINER="maydan-redis"
MINIO_CONTAINER="maydan-minio"

# إعدادات قاعدة البيانات من .env
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_USER="${DB_USER:-maydan}"
DB_NAME="${DB_NAME:-maydan_db}"
DB_PASSWORD="${DB_PASSWORD:-}"

if [[ -n "${DATABASE_URL:-}" ]]; then
    DB_USER=$(echo "$DATABASE_URL" | sed -n 's|.*://\([^:]*\):.*|\1|p')
    DB_PASSWORD=$(echo "$DATABASE_URL" | sed -n 's|.*://[^:]*:\([^@]*\)@.*|\1|p')
    DB_HOST=$(echo "$DATABASE_URL" | sed -n 's|.*@\([^:]*\):.*|\1|p')
    DB_PORT=$(echo "$DATABASE_URL" | sed -n 's|.*:\([0-9]*\)/.*|\1|p')
    DB_NAME=$(echo "$DATABASE_URL" | sed -n 's|.*/\([^?]*\).*|\1|p')
fi

PG_LOCAL_BIN_DIR="/home/z/my-project/db/pg/install/usr/lib/postgresql/17/bin"
PSQL_LOCAL="$PG_LOCAL_BIN_DIR/psql"
PG_RESTORE_LOCAL="$PG_LOCAL_BIN_DIR/pg_restore"

# إعدادات S3
S3_BUCKET="${S3_BUCKET:-}"
S3_REGION="${S3_REGION:-us-east-1}"
S3_ENDPOINT="${S3_ENDPOINT:-}"

# ============================================
# ألوان
# ============================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

LOG_FILE="$LOG_DIR/restore_$(date +%Y%m%d_%H%M%S).log"
START_TIME=$(date +%s)

# ============================================
# دوال مساعدة
# ============================================
log() {
    local level="$1"; shift
    local msg="$*"
    local ts=$(date '+%Y-%m-%d %H:%M:%S')
    local line="[$ts] [$level] $msg"
    echo "$line"
    # محاولة الكتابة في ملف السجل (لن تفشل العملية إذا لم يتمكن)
    echo "$line" >> "$LOG_FILE" 2>/dev/null || true
}
log_info()    { log "INFO"    "$@"; }
log_success() { log "SUCCESS" "$@"; }
log_warning() { log "WARNING" "$@"; }
log_error()   { log "ERROR"   "$@"; }

print_banner() {
    echo -e "\n${MAGENTA}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${MAGENTA}║     سكريبت الاسترداد - ميدان الاقتصاد          ║${NC}"
    echo -e "${MAGENTA}║     Restore Script - Maydan Al-Iqtisad          ║${NC}"
    echo -e "${MAGENTA}╚══════════════════════════════════════════════════╝${NC}\n"
    echo -e "${BLUE}البيئة: $ENV_MODE${NC}"
    echo -e "${BLUE}قاعدة البيانات: $DB_HOST:$DB_PORT/$DB_NAME${NC}"
    echo -e "${BLUE}مسار النسخ: $BACKUP_ROOT${NC}"
    echo -e "${BLUE}مسار السجلات: $LOG_DIR${NC}\n"
}

check_permissions() {
    # التحقق من إمكانية الكتابة في مجلد النسخ
    if ! touch "$BACKUP_ROOT/.write_test" 2>/dev/null; then
        log_warning "لا يمكن الكتابة في $BACKUP_ROOT"
        # محاولة استخدام مسار بديل
        BACKUP_ROOT="$PROJECT_DIR/backups"
        PG_BACKUP_DIR="$BACKUP_ROOT/postgresql"
        UPLOADS_BACKUP_DIR="$BACKUP_ROOT/uploads"
        REDIS_BACKUP_DIR="$BACKUP_ROOT/redis"
        mkdir -p "$BACKUP_ROOT"
        log_warning "تم التحويل إلى مسار بديل: $BACKUP_ROOT"
    else
        rm -f "$BACKUP_ROOT/.write_test"
    fi

    # تحذير فقط في بيئة Docker بدون root (لا نوقف التنفيذ)
    if [[ "$ENV_MODE" == "docker" && $EUID -ne 0 ]]; then
        log_warning "أنت تعمل بدون صلاحيات root في بيئة Docker"
        log_info "بعض العمليات قد تحتاج sudo (مثل chown, docker restart)"
        log_info "إذا واجهت مشاكل، شغّل: sudo bash scripts/restore.sh"
    fi
}

confirm_action() {
    local msg="$1"
    echo -e "${RED}⚠ تحذير: $msg${NC}"
    echo -e "${YELLOW}هل أنت متأكد؟ اكتب 'MAYDAN' للمتابعة:${NC}"
    read -r confirm
    if [[ "$confirm" != "MAYDAN" ]]; then
        log_info "تم الإلغاء"
        exit 0
    fi
}

# ============================================
# عرض النسخ المتاحة
# ============================================
list_backups() {
    echo -e "\n${CYAN}══════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  النسخ الاحتياطية المتاحة${NC}"
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}\n"

    # عرض نسخ PostgreSQL
    echo -e "${GREEN}▸ PostgreSQL:${NC}"
    local pg_found=false
    for level in hourly daily weekly monthly; do
        local dir="$PG_BACKUP_DIR/$level"
        if [[ -d "$dir" ]]; then
            local count=$(find "$dir" -name "maydan_db_*.sql.gz" 2>/dev/null | wc -l)
            local latest=$(ls -t "$dir"/maydan_db_*.sql.gz 2>/dev/null | head -1)
            if [[ -n "$latest" && $count -gt 0 ]]; then
                local size=$(du -sh "$latest" | cut -f1)
                echo "  [$level] $count نسخة | الأحدث: $(basename "$latest") ($size)"
                pg_found=true
            fi
        fi
    done
    [[ "$pg_found" == "false" ]] && echo "  لا توجد نسخ PostgreSQL"

    # عرض نسخ الملفات المرفوعة
    echo -e "\n${GREEN}▸ الملفات المرفوعة:${NC}"
    local uploads_found=false
    for level in daily weekly monthly; do
        local dir="$UPLOADS_BACKUP_DIR/$level"
        if [[ -d "$dir/uploads_latest" ]]; then
            local size=$(du -sh "$dir/uploads_latest" 2>/dev/null | cut -f1 || echo "?")
            echo "  [$level] uploads_latest/ ($size)"
            uploads_found=true
        fi
    done
    [[ "$uploads_found" == "false" ]] && echo "  لا توجد نسخ ملفات مرفوعة"

    # عرض نسخ Redis
    echo -e "\n${GREEN}▸ Redis:${NC}"
    local redis_found=false
    for level in hourly daily weekly monthly; do
        local dir="$REDIS_BACKUP_DIR/$level"
        if [[ -d "$dir" ]]; then
            local count=$(find "$dir" -name "dump_*.rdb" 2>/dev/null | wc -l)
            local latest=$(ls -t "$dir"/dump_*.rdb 2>/dev/null | head -1)
            if [[ -n "$latest" && $count -gt 0 ]]; then
                local size=$(du -sh "$latest" | cut -f1)
                echo "  [$level] $count نسخة | الأحدث: $(basename "$latest") ($size)"
                redis_found=true
            fi
        fi
    done
    [[ "$redis_found" == "false" ]] && echo "  لا توجد نسخ Redis"

    echo ""
}

# ============================================
# العثور على أحدث نسخة
# ============================================
find_latest_pg_backup() {
    local level="${1:-}"
    local search_dirs=()

    if [[ -n "$level" ]]; then
        search_dirs=("$PG_BACKUP_DIR/$level")
    else
        search_dirs=(
            "$PG_BACKUP_DIR/monthly"
            "$PG_BACKUP_DIR/weekly"
            "$PG_BACKUP_DIR/daily"
            "$PG_BACKUP_DIR/hourly"
        )
    fi

    for dir in "${search_dirs[@]}"; do
        local latest=$(ls -t "$dir"/maydan_db_*.sql.gz 2>/dev/null | head -1)
        if [[ -n "$latest" ]]; then
            echo "$latest"
            return 0
        fi
    done

    return 1
}

find_latest_pg_custom() {
    local search_dirs=(
        "$PG_BACKUP_DIR/monthly"
        "$PG_BACKUP_DIR/weekly"
        "$PG_BACKUP_DIR/daily"
        "$PG_BACKUP_DIR/hourly"
    )

    for dir in "${search_dirs[@]}"; do
        local latest=$(ls -t "$dir"/maydan_db_*.dump 2>/dev/null | head -1)
        if [[ -n "$latest" ]]; then
            echo "$latest"
            return 0
        fi
    done

    return 1
}

find_latest_redis_backup() {
    local search_dirs=(
        "$REDIS_BACKUP_DIR/daily"
        "$REDIS_BACKUP_DIR/hourly"
    )

    for dir in "${search_dirs[@]}"; do
        local latest=$(ls -t "$dir"/dump_*.rdb 2>/dev/null | head -1)
        if [[ -n "$latest" ]]; then
            echo "$latest"
            return 0
        fi
    done

    return 1
}

find_latest_uploads_backup() {
    local search_dirs=(
        "$UPLOADS_BACKUP_DIR/monthly"
        "$UPLOADS_BACKUP_DIR/weekly"
        "$UPLOADS_BACKUP_DIR/daily"
    )

    for dir in "${search_dirs[@]}"; do
        if [[ -d "$dir/uploads_latest" ]]; then
            echo "$dir/uploads_latest"
            return 0
        fi
    done

    return 1
}

# ============================================
# استرداد PostgreSQL
# ============================================
restore_postgresql() {
    local backup_file="$1"

    if [[ ! -f "$backup_file" ]]; then
        log_error "ملف النسخة غير موجود: $backup_file"
        return 1
    fi

    log_info "بدء استرداد PostgreSQL من: $backup_file (بيئة: $ENV_MODE)"
    confirm_action "سيتم استبدال قاعدة البيانات الحالية! قد تفقد بيانات حديثة."

    # إنشاء نسخة احتياطية للبيانات الحالية قبل الاسترداد
    local pre_restore_backup="$BACKUP_ROOT/pre_restore/pg_before_restore_$(date +%Y%m%d_%H%M%S).sql.gz"
    mkdir -p "$(dirname "$pre_restore_backup")"
    log_info "إنشاء نسخة احتياطية للبيانات الحالية قبل الاسترداد..."

    if [[ "$ENV_MODE" == "docker" ]]; then
        docker exec "$POSTGRES_CONTAINER" pg_dump -U "$DB_USER" -d "$DB_NAME" \
            --format=plain --no-owner --no-privileges 2>/dev/null | gzip > "$pre_restore_backup" || true
    else
        local pg_dump_cmd=""
        if [[ -x "$PG_LOCAL_BIN_DIR/pg_dump" ]]; then pg_dump_cmd="$PG_LOCAL_BIN_DIR/pg_dump"
        elif command -v pg_dump &>/dev/null; then pg_dump_cmd="pg_dump"; fi
        if [[ -n "$pg_dump_cmd" ]]; then
            PGPASSWORD="$DB_PASSWORD" "$pg_dump_cmd" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
                --format=plain --no-owner --no-privileges 2>/dev/null | gzip > "$pre_restore_backup" || true
        fi
    fi
    log_success "تم حفظ نسخة ما قبل الاسترداد: $pre_restore_backup"

    # قطع الاتصالات النشطة
    log_info "قطع الاتصالات النشطة بقاعدة البيانات..."
    if [[ "$ENV_MODE" == "docker" ]]; then
        docker exec "$POSTGRES_CONTAINER" psql -U "$DB_USER" -d postgres -c \
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid();" \
            2>/dev/null || true
    else
        local psql_cmd=""
        if [[ -x "$PSQL_LOCAL" ]]; then psql_cmd="$PSQL_LOCAL"
        elif command -v psql &>/dev/null; then psql_cmd="psql"; fi
        if [[ -n "$psql_cmd" ]]; then
            PGPASSWORD="$DB_PASSWORD" "$psql_cmd" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c \
                "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid();" \
                2>/dev/null || true
        fi
    fi

    # حذف وإعادة إنشاء قاعدة البيانات
    log_info "إعادة إنشاء قاعدة البيانات..."
    if [[ "$ENV_MODE" == "docker" ]]; then
        docker exec "$POSTGRES_CONTAINER" psql -U "$DB_USER" -d postgres -c \
            "DROP DATABASE IF EXISTS $DB_NAME;" 2>/dev/null || true
        docker exec "$POSTGRES_CONTAINER" psql -U "$DB_USER" -d postgres -c \
            "CREATE DATABASE $DB_NAME OWNER $DB_USER ENCODING 'UTF8';" 2>/dev/null || true
    else
        local psql_cmd=""
        if [[ -x "$PSQL_LOCAL" ]]; then psql_cmd="$PSQL_LOCAL"
        elif command -v psql &>/dev/null; then psql_cmd="psql"; fi
        if [[ -n "$psql_cmd" ]]; then
            PGPASSWORD="$DB_PASSWORD" "$psql_cmd" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c \
                "DROP DATABASE IF EXISTS $DB_NAME;" 2>>"$LOG_FILE" || true
            PGPASSWORD="$DB_PASSWORD" "$psql_cmd" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c \
                "CREATE DATABASE $DB_NAME OWNER $DB_USER ENCODING 'UTF8';" 2>>"$LOG_FILE" || true
        else
            log_error "psql غير موجود!"
            return 1
        fi
    fi

    # استرداد البيانات
    if [[ "$backup_file" == *.dump ]]; then
        log_info "استرداد من نسخة custom (pg_restore)..."
        if [[ "$ENV_MODE" == "docker" ]]; then
            docker cp "$backup_file" "$POSTGRES_CONTAINER:/tmp/restore.dump"
            docker exec "$POSTGRES_CONTAINER" pg_restore -U "$DB_USER" -d "$DB_NAME" \
                --no-owner --no-privileges --verbose /tmp/restore.dump 2>>"$LOG_FILE" || true
            docker exec "$POSTGRES_CONTAINER" rm -f /tmp/restore.dump
        else
            local pg_restore_cmd=""
            if [[ -x "$PG_RESTORE_LOCAL" ]]; then pg_restore_cmd="$PG_RESTORE_LOCAL"
            elif command -v pg_restore &>/dev/null; then pg_restore_cmd="pg_restore"; fi
            if [[ -n "$pg_restore_cmd" ]]; then
                PGPASSWORD="$DB_PASSWORD" "$pg_restore_cmd" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
                    --no-owner --no-privileges --verbose "$backup_file" 2>>"$LOG_FILE" || true
            fi
        fi
    else
        log_info "استرداد من نسخة SQL مضغوطة..."
        if [[ "$ENV_MODE" == "docker" ]]; then
            gunzip -c "$backup_file" | docker exec -i "$POSTGRES_CONTAINER" \
                psql -U "$DB_USER" -d "$DB_NAME" 2>>"$LOG_FILE" || true
        else
            local psql_cmd=""
            if [[ -x "$PSQL_LOCAL" ]]; then psql_cmd="$PSQL_LOCAL"
            elif command -v psql &>/dev/null; then psql_cmd="psql"; fi
            if [[ -n "$psql_cmd" ]]; then
                gunzip -c "$backup_file" | PGPASSWORD="$DB_PASSWORD" "$psql_cmd" \
                    -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" 2>>"$LOG_FILE" || true
            else
                log_error "psql غير موجود!"
                return 1
            fi
        fi
    fi

    # التحقق من الاسترداد
    local psql_check=""
    if [[ "$ENV_MODE" == "docker" ]]; then
        psql_check="docker exec $POSTGRES_CONTAINER psql -U $DB_USER -d $DB_NAME"
    else
        if [[ -x "$PSQL_LOCAL" ]]; then psql_check="PGPASSWORD=$DB_PASSWORD $PSQL_LOCAL -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME"
        elif command -v psql &>/dev/null; then psql_check="PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME"
        fi
    fi

    if [[ -n "$psql_check" ]]; then
        local table_count=$($psql_check -t -c "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';" 2>/dev/null | tr -d ' ' || echo "?")
        local user_count=$($psql_check -t -c "SELECT count(*) FROM \"User\";" 2>/dev/null | tr -d ' ' || echo "?")
        local article_count=$($psql_check -t -c "SELECT count(*) FROM \"Article\";" 2>/dev/null | tr -d ' ' || echo "?")
        log_success "تم استرداد PostgreSQL بنجاح!"
        log_info "  عدد الجداول: $table_count"
        log_info "  عدد المستخدمين: $user_count"
        log_info "  عدد المقالات: $article_count"
    else
        log_success "تم استرداد PostgreSQL (لا يمكن التحقق - psql غير متاح)"
    fi

    return 0
}

# ============================================
# استرداد الملفات المرفوعة
# ============================================
restore_uploads() {
    local backup_dir="$1"
    local target_dir="${2:-$UPLOADS_TARGET_DIR}"

    if [[ ! -d "$backup_dir" ]]; then
        log_error "مجلد النسخة غير موجود: $backup_dir"
        return 1
    fi

    log_info "بدء استرداد الملفات المرفوعة من: $backup_dir"
    confirm_action "سيتم استبدال الملفات المرفوعة الحالية!"

    # إنشاء نسخة احتياطية للملفات الحالية
    local current_backup="$BACKUP_ROOT/pre_restore/uploads_before_restore_$(date +%Y%m%d_%H%M%S)"
    if [[ -d "$target_dir" ]]; then
        mkdir -p "$current_backup"
        log_info "إنشاء نسخة احتياطية للملفات الحالية..."
        rsync -a "$target_dir/" "$current_backup/" 2>>"$LOG_FILE" || true
        log_success "تم حفظ نسخة ما قبل الاسترداد: $current_backup"
    fi

    # استرداد الملفات
    mkdir -p "$target_dir"
    rsync -av --stats "$backup_dir/" "$target_dir/" 2>>"$LOG_FILE"

    # ضبط الصلاحيات (لن تفشل إذا لم تكن root)
    chown -R 1000:1000 "$target_dir" 2>/dev/null || true
    chmod -R 755 "$target_dir" 2>/dev/null || true

    # إعادة تشغيل MinIO لتحديث الفهرس (Docker فقط)
    if [[ "$ENV_MODE" == "docker" ]] && docker ps --format '{{.Names}}' 2>/dev/null | grep -q "^${MINIO_CONTAINER}$"; then
        log_info "إعادة تشغيل MinIO لتحديث الفهرس..."
        docker restart "$MINIO_CONTAINER" 2>>"$LOG_FILE" || true
    fi

    local size=$(du -sh "$target_dir" | cut -f1)
    local file_count=$(find "$target_dir" -type f | wc -l)

    log_success "تم استرداد الملفات المرفوعة بنجاح!"
    log_info "  الحجم: $size"
    log_info "  عدد الملفات: $file_count"

    return 0
}

# ============================================
# استرداد Redis
# ============================================
restore_redis() {
    local backup_file="$1"

    if [[ ! -f "$backup_file" ]]; then
        log_error "ملف النسخة غير موجود: $backup_file"
        return 1
    fi

    log_info "بدء استرداد Redis من: $backup_file (بيئة: $ENV_MODE)"
    confirm_action "سيتم استبدال بيانات Redis الحالية! سيتم فقدان الكاش الحالي."

    if [[ "$ENV_MODE" == "docker" ]]; then
        if ! docker ps --format '{{.Names}}' 2>/dev/null | grep -q "^${REDIS_CONTAINER}$"; then
            log_error "حاوية Redis ($REDIS_CONTAINER) غير تعمل!"
            return 1
        fi

        local current_rdb="$BACKUP_ROOT/pre_restore/redis_before_restore_$(date +%Y%m%d_%H%M%S).rdb"
        mkdir -p "$(dirname "$current_rdb")"
        docker exec "$REDIS_CONTAINER" redis-cli BGSAVE 2>/dev/null || true
        sleep 3
        docker cp "$REDIS_CONTAINER:/data/dump.rdb" "$current_rdb" 2>/dev/null || true
        log_success "تم حفظ نسخة ما قبل الاسترداد: $current_rdb"

        log_info "إيقاف Redis مؤقتاً..."
        docker exec "$REDIS_CONTAINER" redis-cli SHUTDOWN NOSAVE 2>/dev/null || true
        sleep 2
        docker cp "$backup_file" "$REDIS_CONTAINER:/data/dump.rdb" 2>>"$LOG_FILE"
        log_info "إعادة تشغيل Redis..."
        docker restart "$REDIS_CONTAINER" 2>>"$LOG_FILE"
        sleep 5

        local info=$(docker exec "$REDIS_CONTAINER" redis-cli INFO keyspace 2>/dev/null || echo "فشل")
        local connected=$(docker exec "$REDIS_CONTAINER" redis-cli PING 2>/dev/null || echo "فشل")
        log_success "تم استرداد Redis بنجاح!"
        log_info "  حالة الاتصال: $connected"
        log_info "  معلومات المفاتيح: $info"
    else
        # بيئة محلية
        if ! command -v redis-cli &>/dev/null; then
            log_warning "redis-cli غير مثبت - لا يمكن استرداد Redis (الكاش فقط - غير حرج)"
            return 0
        fi

        if ! redis-cli ping &>/dev/null; then
            log_warning "Redis غير يعمل - تخطي الاسترداد (الكاش فقط)"
            return 0
        fi

        local current_rdb="$BACKUP_ROOT/pre_restore/redis_before_restore_$(date +%Y%m%d_%H%M%S).rdb"
        mkdir -p "$(dirname "$current_rdb")"
        redis-cli BGSAVE &>/dev/null || true
        sleep 3
        local redis_dir=$(redis-cli CONFIG GET dir 2>/dev/null | tail -1 || echo "/var/lib/redis")
        local redis_file=$(redis-cli CONFIG GET dbfilename 2>/dev/null | tail -1 || echo "dump.rdb")
        cp "$redis_dir/$redis_file" "$current_rdb" 2>/dev/null || true
        log_success "تم حفظ نسخة ما قبل الاسترداد: $current_rdb"

        cp "$backup_file" "$redis_dir/$redis_file" 2>>"$LOG_FILE"
        redis-cli SHUTDOWN NOSAVE 2>/dev/null || true
        sleep 2

        log_success "تم استرداد Redis (يحتاج إعادة تشغيل يدوي)"
    fi

    return 0
}

# ============================================
# تنزيل نسخة من السحابة
# ============================================
download_from_s3() {
    local remote_path="$1"
    local local_path="$2"

    if [[ -z "$S3_BUCKET" ]]; then
        log_error "S3_BUCKET غير محدد!"
        return 1
    fi

    local s3_cmd="aws s3 cp"
    if [[ -n "$S3_ENDPOINT" ]]; then
        s3_cmd="aws s3 cp --endpoint-url $S3_ENDPOINT"
    fi

    log_info "تنزيل من S3: $remote_path → $local_path"
    $s3_cmd "s3://$S3_BUCKET/$remote_path" "$local_path" 2>>"$LOG_FILE"
}

restore_from_cloud() {
    log_info "بدء الاسترداد من السحابة..."

    if ! command -v aws &> /dev/null; then
        log_error "AWS CLI غير مثبت! ثبته بـ: apt install awscli"
        return 1
    fi

    # عرض النسخ المتاحة في السحابة
    local s3_ls_cmd="aws s3 ls"
    if [[ -n "$S3_ENDPOINT" ]]; then
        s3_ls_cmd="aws s3 ls --endpoint-url $S3_ENDPOINT"
    fi

    echo -e "${CYAN}النسخ المتاحة في السحابة:${NC}"
    $s3_ls_cmd "s3://$S3_BUCKET/maydan-backups/" 2>/dev/null || true

    echo ""
    echo -e "${YELLOW}أدخل تاريخ النسخة (مثال: 20260610):${NC}"
    read -r backup_date

    local temp_dir="/tmp/cloud_restore_$backup_date"
    mkdir -p "$temp_dir"

    # تنزيل نسخة PostgreSQL
    download_from_s3 "maydan-backups/$backup_date/postgresql/" "$temp_dir/" || true

    # تنزيل نسخة Redis
    download_from_s3 "maydan-backups/$backup_date/redis/" "$temp_dir/" || true

    # تنزيل أرشيف الملفات
    download_from_s3 "maydan-backups/$backup_date/uploads/" "$temp_dir/" || true

    log_info "تم التنزيل إلى: $temp_dir"
    log_info "يمكنك الآن استخدام: bash scripts/restore.sh --db --file $temp_dir/maydan_db_*.sql.gz"
}

# ============================================
# الاسترداد التفاعلي
# ============================================
interactive_restore() {
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  وضع الاسترداد التفاعلي${NC}"
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}\n"

    list_backups

    echo -e "${YELLOW}ماذا تريد استرداده؟${NC}"
    echo "  1) قاعدة البيانات فقط (PostgreSQL)"
    echo "  2) الملفات المرفوعة فقط (Uploads)"
    echo "  3) Redis فقط"
    echo "  4) كل شيء"
    echo "  5) اختيار نسخة محددة"
    echo ""
    echo -n "اختر رقم (1-5): "
    read -r choice

    case "$choice" in
        1)
            local pg_file=$(find_latest_pg_backup)
            if [[ -n "$pg_file" ]]; then
                log_info "سيتم استرداد: $pg_file"
                restore_postgresql "$pg_file"
            else
                log_error "لا توجد نسخة PostgreSQL متاحة!"
            fi
            ;;
        2)
            local uploads_dir=$(find_latest_uploads_backup)
            if [[ -n "$uploads_dir" ]]; then
                log_info "سيتم استرداد: $uploads_dir"
                restore_uploads "$uploads_dir"
            else
                log_error "لا توجد نسخة ملفات متاحة!"
            fi
            ;;
        3)
            local redis_file=$(find_latest_redis_backup)
            if [[ -n "$redis_file" ]]; then
                log_info "سيتم استرداد: $redis_file"
                restore_redis "$redis_file"
            else
                log_error "لا توجد نسخة Redis متاحة!"
            fi
            ;;
        4)
            # استرداد كل شيء
            local pg_file=$(find_latest_pg_backup)
            local uploads_dir=$(find_latest_uploads_backup)
            local redis_file=$(find_latest_redis_backup)

            confirm_action "سيتم استرداد كل شيء! هذا سيستبدل جميع البيانات الحالية."

            [[ -n "$pg_file" ]] && restore_postgresql "$pg_file" || log_warning "لا نسخة PostgreSQL"
            [[ -n "$uploads_dir" ]] && restore_uploads "$uploads_dir" || log_warning "لا نسخة ملفات"
            [[ -n "$redis_file" ]] && restore_redis "$redis_file" || log_warning "لا نسخة Redis"
            ;;
        5)
            echo -e "${YELLOW}أدخل مسار ملف النسخة الكامل:${NC}"
            read -r custom_file
            if [[ -f "$custom_file" ]]; then
                if [[ "$custom_file" == *.sql.gz || "$custom_file" == *.dump ]]; then
                    restore_postgresql "$custom_file"
                elif [[ "$custom_file" == *.rdb ]]; then
                    restore_redis "$custom_file"
                else
                    log_error "نوع ملف غير معروف!"
                fi
            else
                log_error "الملف غير موجود: $custom_file"
            fi
            ;;
        *)
            log_error "اختيار غير صالح"
            ;;
    esac
}

# ============================================
# إنشاء نقطة استرداد (Snapshot)
# ============================================
create_restore_point() {
    local point_name="restore_point_$(date +%Y%m%d_%H%M%S)"
    local point_dir="$BACKUP_ROOT/restore-points/$point_name"

    log_info "إنشاء نقطة استرداد: $point_name"
    mkdir -p "$point_dir"

    # حفظ معلومات النظام الحالي
    local pg_status="unknown"
    local redis_status="unknown"
    local minio_status="unknown"

    if [[ "$ENV_MODE" == "docker" ]]; then
        pg_status=$(docker inspect --format='{{.State.Status}}' "$POSTGRES_CONTAINER" 2>/dev/null || echo "stopped")
        redis_status=$(docker inspect --format='{{.State.Status}}' "$REDIS_CONTAINER" 2>/dev/null || echo "stopped")
        minio_status=$(docker inspect --format='{{.State.Status}}' "$MINIO_CONTAINER" 2>/dev/null || echo "stopped")
    fi

    local pg_size="N/A"
    local redis_size="N/A"
    local uploads_size="N/A"
    [[ -d /mnt/postgresql ]] && pg_size=$(du -sh /mnt/postgresql 2>/dev/null | cut -f1 || echo "N/A")
    [[ -d /mnt/redis ]] && redis_size=$(du -sh /mnt/redis 2>/dev/null | cut -f1 || echo "N/A")
    [[ -d /mnt/hdd/minio-data ]] && uploads_size=$(du -sh /mnt/hdd/minio-data 2>/dev/null | cut -f1 || echo "N/A")

    cat > "$point_dir/metadata.json" << META
{
    "name": "$point_name",
    "timestamp": "$(date -Iseconds)",
    "created_by": "restore.sh",
    "environment": "$ENV_MODE",
    "containers": {
        "postgres": "$pg_status",
        "redis": "$redis_status",
        "minio": "$minio_status"
    },
    "disk_usage": {
        "postgresql": "$pg_size",
        "redis": "$redis_size",
        "uploads": "$uploads_size"
    }
}
META

    # إنشاء روابط للنسخ الحالية
    local latest_pg=$(find_latest_pg_backup)
    if [[ -n "$latest_pg" ]]; then
        ln -sf "$latest_pg" "$point_dir/postgresql.sql.gz"
    fi

    local latest_redis=$(find_latest_redis_backup)
    if [[ -n "$latest_redis" ]]; then
        ln -sf "$latest_redis" "$point_dir/redis.rdb"
    fi

    log_success "تم إنشاء نقطة الاسترداد: $point_dir"
}

# ============================================
# التشغيل الرئيسي
# ============================================
main() {
    print_banner
    check_permissions
    mkdir -p "$LOG_DIR" "$BACKUP_ROOT/pre_restore" 2>/dev/null || true

    # تحليل المعاملات
    local mode="interactive"
    local db_file=""
    local restore_all=false
    local use_latest=false

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --list)
                list_backups
                exit 0
                ;;
            --latest)
                use_latest=true
                mode="auto"
                ;;
            --db)
                mode="db"
                ;;
            --uploads)
                mode="uploads"
                ;;
            --redis)
                mode="redis"
                ;;
            --all)
                mode="all"
                restore_all=true
                ;;
            --file)
                shift
                db_file="$1"
                ;;
            --from-s3)
                mode="cloud"
                ;;
            --restore-point)
                create_restore_point
                exit 0
                ;;
            *)
                log_warning "معامل غير معروف: $1"
                ;;
        esac
        shift
    done

    case "$mode" in
        interactive)
            interactive_restore
            ;;
        auto)
            confirm_action "سيتم استرداد آخر نسخة متاحة من كل شيء!"
            local pg=$(find_latest_pg_backup)
            local up=$(find_latest_uploads_backup)
            local rd=$(find_latest_redis_backup)

            [[ -n "$pg" ]] && restore_postgresql "$pg" || log_warning "لا نسخة PostgreSQL"
            [[ -n "$up" ]] && restore_uploads "$up" || log_warning "لا نسخة ملفات"
            [[ -n "$rd" ]] && restore_redis "$rd" || log_warning "لا نسخة Redis"
            ;;
        db)
            if [[ -n "$db_file" ]]; then
                restore_postgresql "$db_file"
            else
                local pg=$(find_latest_pg_backup)
                [[ -n "$pg" ]] && restore_postgresql "$pg" || log_error "لا نسخة PostgreSQL متاحة!"
            fi
            ;;
        uploads)
            local up=$(find_latest_uploads_backup)
            [[ -n "$up" ]] && restore_uploads "$up" || log_error "لا نسخة ملفات متاحة!"
            ;;
        redis)
            local rd=$(find_latest_redis_backup)
            [[ -n "$rd" ]] && restore_redis "$rd" || log_error "لا نسخة Redis متاحة!"
            ;;
        all)
            confirm_action "سيتم استرداد كل شيء!"
            local pg=$(find_latest_pg_backup)
            local up=$(find_latest_uploads_backup)
            local rd=$(find_latest_redis_backup)

            [[ -n "$pg" ]] && restore_postgresql "$pg" || log_warning "لا نسخة PostgreSQL"
            [[ -n "$up" ]] && restore_uploads "$up" || log_warning "لا نسخة ملفات"
            [[ -n "$rd" ]] && restore_redis "$rd" || log_warning "لا نسخة Redis"
            ;;
        cloud)
            restore_from_cloud
            ;;
    esac

    # إنشاء تقرير
    local end_time=$(date +%s)
    local duration=$(( end_time - START_TIME ))
    local minutes=$(( duration / 60 ))
    local seconds=$(( duration % 60 ))

    echo -e "\n${GREEN}══════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  اكتمل الاسترداد - المدة: ${minutes} دقيقة ${seconds} ثانية${NC}"
    echo -e "${GREEN}  سجل العملية: $LOG_FILE${NC}"
    echo -e "${GREEN}══════════════════════════════════════════════════${NC}\n"

    if [[ "$ENV_MODE" == "docker" ]]; then
        log_info "ينصح بإعادة تشغيل جميع الخدمات: docker compose restart"
    else
        log_info "ينصح بإعادة تشغيل التطبيق: bash scripts/start-pg.sh && npm run dev"
    fi
}

main "$@"
