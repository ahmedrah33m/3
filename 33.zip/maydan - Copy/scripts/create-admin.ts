/**
 * سكريبت إنشاء المستخدم الإداري
 * Create admin users script
 *
 * Usage:
 *   npx tsx scripts/create-admin.ts
 *
 * ⚠️  اضبط كلمات المرور عبر متغيرات البيئة قبل التشغيل:
 *   export OWNER_PASSWORD="your_strong_password"
 *   export ADMIN_PASSWORD="your_strong_password"
 *   export MODERATOR_PASSWORD="your_strong_password"
 */

import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/auth'

const prisma = new PrismaClient()

const ADMIN_USERS = [
  {
    email: process.env.OWNER_EMAIL || 'owner@maydan.iq',
    password: process.env.OWNER_PASSWORD || 'CHANGE_ME_OWNER_PASS',
    name: 'مالك المنصة',
    role: 'OWNER' as const,
    jobTitle: 'مؤسس المنصة',
    organization: 'ميدان الاقتصاد',
    location: 'بغداد، العراق',
    isVerified: true,
    emailVerified: true,
  },
  {
    email: process.env.ADMIN_EMAIL || 'admin@maydan.iq',
    password: process.env.ADMIN_PASSWORD || 'CHANGE_ME_ADMIN_PASS',
    name: 'عبدالرحمن المنصوري',
    role: 'ADMIN' as const,
    jobTitle: 'مسؤول النظام',
    organization: 'ميدان الاقتصاد',
    location: 'بغداد، العراق',
    isVerified: true,
    emailVerified: true,
  },
  {
    email: process.env.MODERATOR_EMAIL || 'moderator@maydan.iq',
    password: process.env.MODERATOR_PASSWORD || 'CHANGE_ME_MOD_PASS',
    name: 'حسين الكرملي',
    role: 'MODERATOR' as const,
    jobTitle: 'مشرف المحتوى',
    organization: 'ميدان الاقتصاد',
    location: 'بغداد، العراق',
    isVerified: true,
    emailVerified: true,
  },
]

async function main() {
  // Warn if default passwords are still in use
  const hasDefaultPasswords = ADMIN_USERS.some(u => u.password.includes('CHANGE_ME'))
  if (hasDefaultPasswords) {
    console.warn('\n⚠️  تحذير: بعض كلمات المرور لا تزال افتراضية!')
    console.warn('   WARNING: Some passwords are still default!')
    console.warn('   Set OWNER_PASSWORD, ADMIN_PASSWORD, MODERATOR_PASSWORD env vars.\n')
  }

  console.log('🔧 إنشاء المستخدمين الإداريين...')
  console.log('   Creating admin users...\n')

  for (const userData of ADMIN_USERS) {
    try {
      // ✅ استخدم upsert بدل findUnique + create/update
      // upsert يبحث بالـ email، إن وُجد يحدّثه، إن لم يوجد ينشئه بـ id تلقائي (cuid)
      const hashedPassword = hashPassword(userData.password)

      const user = await prisma.user.upsert({
        where: { email: userData.email },
        update: {
          password: hashedPassword,
          role: userData.role,
          emailVerified: true,
          isVerified: true,
          name: userData.name,
          jobTitle: userData.jobTitle,
          organization: userData.organization,
          location: userData.location,
        },
        create: {
          // ✅ لا تُصلّب id — اترك Prisma يولّد cuid() تلقائياً
          email: userData.email,
          password: hashedPassword,
          name: userData.name,
          role: userData.role,
          jobTitle: userData.jobTitle,
          organization: userData.organization,
          location: userData.location,
          isVerified: userData.isVerified,
          emailVerified: userData.emailVerified,
        },
      })

      console.log(`✅ ${userData.email} → ${user.role} (id: ${user.id})`)
    } catch (err: any) {
      console.error(`❌ خطأ مع ${userData.email}:`, err.message)
      // محاولة بديلة: حدّث فقط بدون محاولة الإنشاء
      if (err.code === 'P2002') {
        console.log(`   → محاولة التحديث فقط...`)
        try {
          const hashedPassword = hashPassword(userData.password)
          await prisma.user.update({
            where: { email: userData.email },
            data: {
              password: hashedPassword,
              role: userData.role,
              emailVerified: true,
              isVerified: true,
            },
          })
          console.log(`   ✅ تم التحديث بنجاح`)
        } catch (updateErr: any) {
          console.error(`   ❌ فشل التحديث أيضاً:`, updateErr.message)
        }
      }
    }
  }

  // Print summary
  const totalUsers = await prisma.user.count()
  console.log(`\n📊 إجمالي المستخدمين في قاعدة البيانات: ${totalUsers}`)

  // Verify login works
  console.log('\n🔍 التحقق من بيانات الدخول...')
  for (const userData of ADMIN_USERS) {
    const user = await prisma.user.findUnique({ where: { email: userData.email } })
    if (user) {
      console.log(`   ✅ ${userData.email} — الدور: ${user.role} — كلمة المرور: ***`)
    } else {
      console.log(`   ❌ ${userData.email} — غير موجود!`)
    }
  }

  await prisma.$disconnect()
  console.log('\n✅ تم الانتهاء!')
}

main().catch((err) => {
  console.error('❌ خطأ:', err)
  process.exit(1)
})
