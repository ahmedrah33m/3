#!/bin/bash
# ============================================
# سكريبت مراقبة النسخ الاحتياطي والتنبيهات
# Backup Monitoring & Alerting Script
# ============================================
# يفحص صحة النسخ الاحتياطي ويرسل تنبيهات عند:
#   - فشل النسخ الاحتياطي
#   - عدم وجود نسخة حديثة
#   - نفاد مساحة التخزين
#   - فشل الرفع السحابي
# ============================================
# الاستخدام:
#   bash scripts/backup-monitor.sh              # فحص فوري
#   bash scripts/backup-monitor.sh --install    # تثبيت ك cron job
#   bash scripts/backup-monitor.sh --status     # عرض الحالة
# ============================================

set -uo pipefail

# ============================================
# كشف البيئة
# ============================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

ENV_MODE="local"
if command -v docker &>/dev/null && docker ps &>/dev/null 2>&1; then
    if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "maydan-postgres"; then
        ENV_MODE="docker"
    fi
fi

# ============================================
# إعدادات - تتكيف مع البيئة
# ============================================
if [[ "$ENV_MODE" == "docker" && -d "/mnt/hdd/backups" && -r "/mnt/hdd/backups" ]]; then
    BACKUP_ROOT="/mnt/hdd/backups"
else
    BACKUP_ROOT="$PROJECT_DIR/backups"
fi

if [[ "$ENV_MODE" == "docker" && -d "/mnt/hdd/logs" && -w "/mnt/hdd/logs" ]]; then
    LOG_DIR="/mnt/hdd/logs"
else
    LOG_DIR="$PROJECT_DIR/backups/logs"
fi

PG_BACKUP_DIR="$BACKUP_ROOT/postgresql"
REDIS_BACKUP_DIR="$BACKUP_ROOT/redis"
UPLOADS_BACKUP_DIR="$BACKUP_ROOT/uploads"
HEALTH_LOG="$LOG_DIR/backup_health.log"

# إنشاء مجلد السجلات
mkdir -p "$LOG_DIR" 2>/dev/null || {
    LOG_DIR="/tmp/maydan-monitor-logs"
    HEALTH_LOG="$LOG_DIR/backup_health.log"
    mkdir -p "$LOG_DIR"
}

# حدود التنبيه
MAX_HOURS_SINCE_LAST_PG_BACKUP=2      # ساعة
MAX_HOURS_SINCE_LAST_REDIS_BACKUP=2   # ساعة
MAX_DAYS_SINCE_LAST_UPLOADS_BACKUP=2  # يوم
MIN_DISK_SPACE_GB=10                  # جيجابايت
MIN_PG_BACKUP_SIZE_KB=100             # كيلوبايت

# إعدادات التنبيهات
ALERT_WEBHOOK_URL="${ALERT_WEBHOOK_URL:-}"     # Slack/Discord webhook
ALERT_EMAIL="${ALERT_EMAIL:-}"                  # بريد التنبيه
ALERT_TELEGRAM_BOT_TOKEN="${ALERT_TELEGRAM_BOT_TOKEN:-}"
ALERT_TELEGRAM_CHAT_ID="${ALERT_TELEGRAM_CHAT_ID:-}"

# ============================================
# ألوان
# ============================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ============================================
# دوال مساعدة
# ============================================
log_health() {
    local status="$1"
    shift
    local msg="$*"
    local ts=$(date '+%Y-%m-%d %H:%M:%S')
    local line="[$ts] [$status] $msg"
    echo "$line"
    echo "$line" >> "$HEALTH_LOG" 2>/dev/null || true
}

# ============================================
# فحص نسخ PostgreSQL
# ============================================
check_postgresql() {
    log_health "INFO" "فحص نسخ PostgreSQL..."

    local latest_file=""
    local latest_time=0

    # البحث في جميع مستويات RPO
    for level in hourly daily weekly monthly; do
        local dir="$PG_BACKUP_DIR/$level"
        if [[ -d "$dir" ]]; then
            local f=$(ls -t "$dir"/maydan_db_*.sql.gz 2>/dev/null | head -1)
            if [[ -n "$f" ]]; then
                local f_time=$(stat -c %Y "$f" 2>/dev/null || echo 0)
                if [[ $f_time -gt $latest_time ]]; then
                    latest_time=$f_time
                    latest_file="$f"
                fi
            fi
        fi
    done

    if [[ -z "$latest_file" ]]; then
        log_health "CRITICAL" "لا توجد أي نسخة PostgreSQL!"
        return 1
    fi

    local now=$(date +%s)
    local age_hours=$(( (now - latest_time) / 3600 ))
    local size=$(du -k "$latest_file" | cut -f1)

    if [[ $age_hours -gt $MAX_HOURS_SINCE_LAST_PG_BACKUP ]]; then
        log_health "WARNING" "آخر نسخة PostgreSQL قديمة: ${age_hours} ساعة (الحد: $MAX_HOURS_SINCE_LAST_PG_BACKUP)"
        return 1
    fi

    if [[ $size -lt $MIN_PG_BACKUP_SIZE_KB ]]; then
        log_health "WARNING" "حجم نسخة PostgreSQL صغير جداً: ${size}KB (الحد: $MIN_PG_BACKUP_SIZE_KB)"
        return 1
    fi

    log_health "OK" "PostgreSQL - آخر نسخة: $(basename "$latest_file") (${age_hours} ساعة مضت, ${size}KB)"
    return 0
}

# ============================================
# فحص نسخ Redis
# ============================================
check_redis() {
    log_health "INFO" "فحص نسخ Redis..."

    local latest_file=""
    local latest_time=0

    for level in hourly daily; do
        local dir="$REDIS_BACKUP_DIR/$level"
        if [[ -d "$dir" ]]; then
            local f=$(ls -t "$dir"/dump_*.rdb 2>/dev/null | head -1)
            if [[ -n "$f" ]]; then
                local f_time=$(stat -c %Y "$f" 2>/dev/null || echo 0)
                if [[ $f_time -gt $latest_time ]]; then
                    latest_time=$f_time
                    latest_file="$f"
                fi
            fi
        fi
    done

    if [[ -z "$latest_file" ]]; then
        log_health "WARNING" "لا توجد أي نسخة Redis!"
        return 1
    fi

    local now=$(date +%s)
    local age_hours=$(( (now - latest_time) / 3600 ))

    if [[ $age_hours -gt $MAX_HOURS_SINCE_LAST_REDIS_BACKUP ]]; then
        log_health "WARNING" "آخر نسخة Redis قديمة: ${age_hours} ساعة"
        return 1
    fi

    log_health "OK" "Redis - آخر نسخة: $(basename "$latest_file") (${age_hours} ساعة مضت)"
    return 0
}

# ============================================
# فحص نسخ الملفات المرفوعة
# ============================================
check_uploads() {
    log_health "INFO" "فحص نسخ الملفات المرفوعة..."

    local latest_dir=""
    local latest_time=0

    for level in daily weekly monthly; do
        local dir="$UPLOADS_BACKUP_DIR/$level/uploads_latest"
        if [[ -d "$dir" ]]; then
            local d_time=$(stat -c %Y "$dir" 2>/dev/null || echo 0)
            if [[ $d_time -gt $latest_time ]]; then
                latest_time=$d_time
                latest_dir="$dir"
            fi
        fi
    done

    if [[ -z "$latest_dir" ]]; then
        log_health "WARNING" "لا توجد أي نسخة ملفات مرفوعة!"
        return 1
    fi

    local now=$(date +%s)
    local age_days=$(( (now - latest_time) / 86400 ))

    if [[ $age_days -gt $MAX_DAYS_SINCE_LAST_UPLOADS_BACKUP ]]; then
        log_health "WARNING" "آخر نسخة ملفات قديمة: ${age_days} يوم"
        return 1
    fi

    local size=$(du -sh "$latest_dir" | cut -f1)
    log_health "OK" "Uploads - آخر نسخة: ${age_days} يوم مضت ($size)"
    return 0
}

# ============================================
# فحص مساحة التخزين
# ============================================
check_disk_space() {
    log_health "INFO" "فحص مساحة التخزين..."

    local check_path="/"
    if [[ -d "/mnt/hdd" ]]; then
        check_path="/mnt/hdd"
    elif [[ -d "$BACKUP_ROOT" ]]; then
        check_path="$BACKUP_ROOT"
    fi

    local available_gb=$(df -BG "$check_path" 2>/dev/null | tail -1 | awk '{print $4}' | tr -d 'G' || echo "999")

    if [[ -n "$available_gb" && "$available_gb" -lt $MIN_DISK_SPACE_GB 2>/dev/null ]]; then
        log_health "CRITICAL" "مساحة التخزين منخفضة: ${available_gb}GB متبقية (الحد: $MIN_DISK_SPACE_GB)"
        return 1
    fi

    log_health "OK" "مساحة التخزين: ${available_gb}GB متبقية"
    return 0
}

# ============================================
# فحص حالة Docker
# ============================================
check_docker() {
    if [[ "$ENV_MODE" != "docker" ]]; then
        log_health "OK" "بيئة محلية - لا حاويات Docker للفحص"
        return 0
    fi

    log_health "INFO" "فحص حالة الحاويات..."

    local containers=("maydan-postgres" "maydan-redis" "maydan-minio" "maydan-app")
    local all_ok=true

    for container in "${containers[@]}"; do
        local status=$(docker inspect --format='{{.State.Status}}' "$container" 2>/dev/null || echo "not_found")
        if [[ "$status" != "running" ]]; then
            log_health "WARNING" "الحاوية $container: $status"
            all_ok=false
        else
            log_health "OK" "الحاوية $container: تعمل"
        fi
    done

    if [[ "$all_ok" == "true" ]]; then
        return 0
    else
        return 1
    fi
}

# ============================================
# إرسال تنبيه
# ============================================
send_alert() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')

    local full_message="[$level] ميدان الاقتصاد - تنبيه النسخ الاحتياطي
الوقت: $timestamp
الرسالة: $message"

    # Telegram
    if [[ -n "$ALERT_TELEGRAM_BOT_TOKEN" && -n "$ALERT_TELEGRAM_CHAT_ID" ]]; then
        curl -s -X POST "https://api.telegram.org/bot$ALERT_TELEGRAM_BOT_TOKEN/sendMessage" \
            -d chat_id="$ALERT_TELEGRAM_CHAT_ID" \
            -d text="$full_message" \
            > /dev/null 2>&1 || true
    fi

    # Slack/Discord webhook
    if [[ -n "$ALERT_WEBHOOK_URL" ]]; then
        curl -s -X POST "$ALERT_WEBHOOK_URL" \
            -H 'Content-type: application/json' \
            -d "{\"text\": \"$full_message\"}" \
            > /dev/null 2>&1 || true
    fi

    # تسجيل التنبيه
    log_health "ALERT" "[$level] $message"
}

# ============================================
# عرض الحالة
# ============================================
show_status() {
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  حالة النسخ الاحتياطي - ميدان الاقتصاد${NC}"
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}\n"

    echo -e "${BLUE}البيئة: $ENV_MODE${NC}"
    echo -e "${BLUE}مسار النسخ: $BACKUP_ROOT${NC}\n"

    local errors=0

    check_postgresql || errors=$((errors + 1))
    check_redis || errors=$((errors + 1))
    check_uploads || errors=$((errors + 1))
    check_disk_space || errors=$((errors + 1))
    check_docker || errors=$((errors + 1))

    echo ""
    if [[ $errors -eq 0 ]]; then
        echo -e "${GREEN}✓ جميع الفحوصات ناجحة${NC}"
    else
        echo -e "${RED}✖ $errors فحوصات فاشلة${NC}"
    fi

    # عرض ملخص النسخ
    echo -e "\n${YELLOW}ملخص النسخ المتاحة:${NC}"
    echo "  PostgreSQL:"
    for level in hourly daily weekly monthly; do
        local count=$(find "$PG_BACKUP_DIR/$level" -name "maydan_db_*.sql.gz" 2>/dev/null | wc -l)
        [[ $count -gt 0 ]] && echo "    [$level]: $count نسخة"
    done

    echo "  Redis:"
    for level in hourly daily; do
        local count=$(find "$REDIS_BACKUP_DIR/$level" -name "dump_*.rdb" 2>/dev/null | wc -l)
        [[ $count -gt 0 ]] && echo "    [$level]: $count نسخة"
    done

    echo "  Uploads:"
    for level in daily weekly monthly; do
        [[ -d "$UPLOADS_BACKUP_DIR/$level/uploads_latest" ]] && echo "    [$level]: متوفر"
    done
}

# ============================================
# تثبيت ك cron job
# ============================================
install_monitor() {
    echo -e "${BLUE}تثبيت مراقب النسخ الاحتياطي...${NC}"

    local script_path="$(readlink -f "$0")"

    # إضافة فحص كل 6 ساعات
    (crontab -l 2>/dev/null | grep -v "backup-monitor"; echo "0 */6 * * * $script_path >> $LOG_DIR/backup_monitor.log 2>&1") | crontab -

    echo -e "${GREEN}تم التثبيت - سيتم الفحص كل 6 ساعات${NC}"
}

# ============================================
# التشغيل الرئيسي
# ============================================
main() {
    case "${1:-}" in
        --install)
            install_monitor
            ;;
        --status)
            show_status
            ;;
        *)
            # فحص صامت - إرسال تنبيهات فقط عند وجود مشاكل
            local errors=0
            check_postgresql || errors=$((errors + 1))
            check_redis || errors=$((errors + 1))
            check_uploads || errors=$((errors + 1))
            check_disk_space || errors=$((errors + 1))

            if [[ $errors -gt 0 ]]; then
                send_alert "CRITICAL" "فشل $errors فحوصات من أصل 4 في النسخ الاحتياطي - تحقق فوراً!"
            fi
            ;;
    esac
}

main "$@"
