#!/bin/bash
# ============================================================
# 🔧 إصلاح سريع لمشاكل بدء التشغيل
# Quick Fix for Startup Issues
# ============================================================
#
# يحل:
#   1. P3005 (database not empty) — استخدم db push بدل migrate
#   2. bunx not found — استخدم npx
#   3. create-admin unique constraint — استخدم upsert
#   4. prisma config deprecated — نقل إلى prisma.config.ts
#
# الاستخدام:
#   bash scripts/quick-fix.sh
# ============================================================

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_ok()   { echo -e "${GREEN}✅ $1${NC}"; }
print_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_info() { echo -e "ℹ️  $1"; }
print_err()  { echo -e "${RED}❌ $1${NC}"; }

echo "═══════════════════════════════════════════"
echo "  🔧 إصلاح سريع لمشاكل بدء التشغيل"
echo "═══════════════════════════════════════════"
echo ""

# ─── 1. تحميل متغيرات البيئة ──────────────────────────────
print_info "1️⃣  تحميل متغيرات البيئة..."
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
  print_ok ".env محمّل"
else
  print_err ".env غير موجود! انسخ .env.example أولاً: cp .env.example .env"
  exit 1
fi
echo ""

# ─── 2. توليد Prisma client ───────────────────────────────
print_info "2️⃣  توليد Prisma client..."
npx prisma generate
print_ok "Prisma client جاهز"
echo ""

# ─── 3. تطبيق Schema (db push بدل migrate) ────────────────
print_info "3️⃣  تطبيق Schema على قاعدة البيانات..."
print_warn "استخدام db push (بدل migrate deploy) لتجنب P3005"

# محاولة db push عادية أولاً
if npx prisma db push 2>&1; then
  print_ok "Schema مُطبّق بنجاح"
else
  print_warn "db push فشل — قد يكون بسبب FK violations"
  print_info "تشغيل سكريبت إصلاح FK violations..."
  bash scripts/fix-fk-violations.sh
fi
echo ""

# ─── 4. بذر البيانات ──────────────────────────────────────
print_info "4️⃣  بذر البيانات الأولية (اختياري)..."
read -p "هل تريد بذر البيانات الأولية؟ (y/N): " SEED_CONFIRM
if [ "$SEED_CONFIRM" = "y" ] || [ "$SEED_CONFIRM" = "Y" ]; then
  print_info "بذر البيانات..."
  npx tsx prisma/seed.ts 2>&1 | tail -20 || print_warn "فشل البذر (قد تكون البيانات موجودة)"
  print_ok "البذر مكتمل"
else
  print_warn "تم تخطي البذر"
fi
echo ""

# ─── 5. إنشاء حسابات admin ────────────────────────────────
print_info "5️⃣  إنشاء حسابات admin..."

# تعيين كلمات مرور افتراضية إن لم تُعيّن
export OWNER_PASSWORD="${OWNER_PASSWORD:-Maydan@2026}"
export ADMIN_PASSWORD="${ADMIN_PASSWORD:-Maydan@2026}"
export MODERATOR_PASSWORD="${MODERATOR_PASSWORD:-Maydan@2026}"

print_warn "كلمات المرور الافتراضية:"
print_warn "  OWNER: $OWNER_PASSWORD"
print_warn "  ADMIN: $ADMIN_PASSWORD"
print_warn "  MODERATOR: $MODERATOR_PASSWORD"
print_warn "لتغييرها: export OWNER_PASSWORD='new_pass' قبل التشغيل"
echo ""

npx tsx scripts/create-admin.ts
print_ok "حسابات admin جاهزة"
echo ""

# ─── 6. التحقق ────────────────────────────────────────────
print_info "6️⃣  التحقق من الحسابات..."
npx tsx -e "
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
(async () => {
  const users = await prisma.user.findMany({
    where: { role: { in: ['OWNER', 'ADMIN', 'MODERATOR'] } },
    select: { email: true, role: true, name: true }
  });
  console.log('الحسابات الإدارية:');
  users.forEach(u => console.log('  ' + u.email + ' → ' + u.role + ' (' + u.name + ')'));
  await prisma.\$disconnect();
})();
" 2>&1 || print_warn "تعذر التحقق"
echo ""

# ─── 7. ملخص ──────────────────────────────────────────────
echo "═══════════════════════════════════════════"
print_ok "🎉 الإصلاح مكتمل!"
echo "═══════════════════════════════════════════"
echo ""
echo "📋 الخطوات التالية:"
echo "  1. شغّل المنصة: npm run dev"
echo "  2. افتح المتصفح: http://localhost:3300"
echo "  3. سجّل دخول بـ:"
echo "     - owner@maydan.iq / $OWNER_PASSWORD"
echo "     - admin@maydan.iq / $ADMIN_PASSWORD"
echo "     - moderator@maydan.iq / $MODERATOR_PASSWORD"
echo ""
echo "⚠️  غيّر كلمات المرور بعد أول تسجيل دخول!"
