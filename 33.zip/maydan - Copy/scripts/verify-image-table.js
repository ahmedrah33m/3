const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

async function main() {
  const rows = await db.$queryRawUnsafe(
    `SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'Image'`
  )
  console.log('table:', JSON.stringify(rows))
  const cols = await db.$queryRawUnsafe(
    `SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'Image' ORDER BY ordinal_position`
  )
  console.log('columns:', JSON.stringify(cols.map((c) => c.column_name)))
  await db.$disconnect()
}

main().catch((e) => {
  console.log('err:', e.message.slice(0, 300))
  process.exit(1)
})
