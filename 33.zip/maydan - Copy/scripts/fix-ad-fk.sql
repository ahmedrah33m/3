-- ============================================================
-- 🔧 إصلاح تعارض Foreign Key في جدول Ad
-- Run: psql -U maydan -d maydan_db -f scripts/fix-ad-fk.sql
-- ============================================================

-- المشكلة: Ad.advertiserId يشير إلى User.id بدلاً من AdvertiserAccount.id
-- الحل: مسح القيم المعطوبة (set to NULL) — آمن لأن advertiserId optional

BEGIN;

-- 1. مسح advertiserId المعطوبة في Ad
UPDATE "Ad" SET "advertiserId" = NULL
WHERE "advertiserId" IS NOT NULL
  AND "advertiserId" NOT IN (SELECT id FROM "AdvertiserAccount");

-- 2. مسح authorId المعطوبة في Post
UPDATE "Post" SET "authorId" = NULL
WHERE "authorId" IS NOT NULL
  AND "authorId" NOT IN (SELECT id FROM "User");

-- 3. حذف SavedCandidate المعطوبة
DELETE FROM "SavedCandidate"
WHERE "companyId" NOT IN (SELECT id FROM "User")
   OR "candidateId" NOT IN (SELECT id FROM "User");

-- 4. حذف JobMessage المعطوبة
DELETE FROM "JobMessage"
WHERE "senderId" IS NOT NULL
  AND "senderId" NOT IN (SELECT id FROM "User");

-- 5. حذف ApplicationStageChange المعطوبة
DELETE FROM "ApplicationStageChange"
WHERE "changedById" NOT IN (SELECT id FROM "User");

-- 6. حذف CommunityMember المعطوبة
DELETE FROM "CommunityMember"
WHERE "userId" NOT IN (SELECT id FROM "User")
   OR "communityId" NOT IN (SELECT id FROM "Community");

-- 7. حذف StoryView المعطوبة
DELETE FROM "StoryView"
WHERE "viewerId" NOT IN (SELECT id FROM "User")
   OR "storyId" NOT IN (SELECT id FROM "Story");

-- 8. حذف ReadingListItem المعطوبة
DELETE FROM "ReadingListItem"
WHERE "readingListId" NOT IN (SELECT id FROM "ReadingList");

COMMIT;

-- التحقق
SELECT 'Ad with valid advertiserId' as check_name, count(*) as count
FROM "Ad" WHERE "advertiserId" IS NOT NULL
  AND "advertiserId" IN (SELECT id FROM "AdvertiserAccount");

SELECT 'Total Ads' as check_name, count(*) as count FROM "Ad";
