#!/bin/bash
# ============================================
# سكريبت النسخ الاحتياطي الشامل
# Comprehensive Backup Script for Maydan Al-Iqtisad
# ============================================
# يدعم:
#   - بيئة التطوير المحلية (PostgreSQL مباشر + ملفات محلية)
#   - بيئة الإنتاج (Docker containers)
#   - نسخ قاعدة بيانات PostgreSQL
#   - نسخ ملفات مرفوعة (صور + مستندات)
#   - نسخ بيانات Redis (إن توفرت)
#   - رفع النسخ للسحابة (S3/FTP)
#   - نظام نقاط استرداد (RPO)
# ============================================
# الاستخدام:
#   bash scripts/backup.sh                  # نسخة كاملة
#   bash scripts/backup.sh --db-only        # قاعدة البيانات فقط
#   bash scripts/backup.sh --uploads        # الملفات المرفوعة فقط
#   bash scripts/backup.sh --redis          # Redis فقط
#   bash scripts/backup.sh --all            # كل شيء + رفع سحابي
#   bash scripts/backup.sh --no-cloud       # كل شيء بدون رفع سحابي
# ============================================

set -uo pipefail

# ============================================
# كشف البيئة تلقائياً
# ============================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# كشف نوع البيئة
ENV_MODE="local"
if command -v docker &>/dev/null && docker ps &>/dev/null 2>&1; then
    if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "maydan-postgres"; then
        ENV_MODE="docker"
    fi
fi

# ============================================
# إعدادات قابلة للتعديل - تتكيف مع البيئة والصلاحيات
# ============================================
# محاولة استخدام مسارات Docker أولاً، ثم الرجوع للمسارات المحلية
# إذا لم تكن المسارات قابلة للكتابة
determine_writable_path() {
    local docker_path="$1"
    local local_path="$2"

    if [[ "$ENV_MODE" == "docker" && -d "$(dirname "$docker_path")" && -w "$(dirname "$docker_path")" ]]; then
        echo "$docker_path"
    elif [[ "$ENV_MODE" == "docker" && -d "$docker_path" && -w "$docker_path" ]]; then
        echo "$docker_path"
    else
        echo "$local_path"
    fi
}

BACKUP_ROOT=$(determine_writable_path "/mnt/hdd/backups" "$PROJECT_DIR/backups")
LOG_DIR=$(determine_writable_path "/mnt/hdd/logs" "$PROJECT_DIR/backups/logs")

# مسارات مصادر الملفات المرفوعة
if [[ "$ENV_MODE" == "docker" ]]; then
    UPLOADS_SOURCES=("/mnt/hdd/minio-data/uploads" "/mnt/hdd/minio-data/maydan-uploads" "$PROJECT_DIR/public/uploads")
else
    UPLOADS_SOURCES=("$PROJECT_DIR/public/uploads")
fi

PG_BACKUP_DIR="$BACKUP_ROOT/postgresql"
UPLOADS_BACKUP_DIR="$BACKUP_ROOT/uploads"
REDIS_BACKUP_DIR="$BACKUP_ROOT/redis"

# إنشاء مجلد السجلات مبكراً
mkdir -p "$LOG_DIR" 2>/dev/null || {
    LOG_DIR="/tmp/maydan-backup-logs"
    mkdir -p "$LOG_DIR"
}

# إعدادات PostgreSQL - قراءة مباشرة من .env (تجنب المتغيرات البيئية القديمة)
DB_HOST="localhost"
DB_PORT="5432"
DB_USER="maydan"
DB_NAME="maydan_db"
DB_PASSWORD=""

# قراءة DATABASE_URL من ملف .env مباشرة (تجاهل المتغيرات البيئية)
if [[ -f "$PROJECT_DIR/.env" ]]; then
    _DB_URL=$(grep "^DATABASE_URL=" "$PROJECT_DIR/.env" | head -1 | cut -d'=' -f2-)
    if [[ -n "$_DB_URL" && "$_DB_URL" == postgresql://* ]]; then
        DB_USER=$(echo "$_DB_URL" | sed -n 's|.*://\([^:]*\):.*|\1|p')
        DB_PASSWORD=$(echo "$_DB_URL" | sed -n 's|.*://[^:]*:\([^@]*\)@.*|\1|p')
        DB_HOST=$(echo "$_DB_URL" | sed -n 's|.*@\([^:]*\):.*|\1|p')
        DB_PORT=$(echo "$_DB_URL" | sed -n 's|.*:\([0-9]*\)/.*|\1|p')
        DB_NAME=$(echo "$_DB_URL" | sed -n 's|.*/\([^?]*\).*|\1|p')
    fi
    # تحميل إعدادات أخرى من .env (الرفع السحابي، FTP، إلخ)
    CLOUD_UPLOAD_ENABLED=$(grep "^CLOUD_UPLOAD_ENABLED=" "$PROJECT_DIR/.env" 2>/dev/null | cut -d'=' -f2- || echo "false")
    S3_BUCKET=$(grep "^S3_BUCKET=" "$PROJECT_DIR/.env" 2>/dev/null | cut -d'=' -f2- || echo "")
    S3_REGION=$(grep "^S3_REGION=" "$PROJECT_DIR/.env" 2>/dev/null | cut -d'=' -f2- || echo "us-east-1")
fi

# إعدادات Docker
POSTGRES_CONTAINER="maydan-postgres"
REDIS_CONTAINER="maydan-redis"
MINIO_CONTAINER="maydan-minio"

# مسار pg_dump في البيئة المحلية
PG_LOCAL_BIN_DIR="/home/z/my-project/db/pg/install/usr/lib/postgresql/17/bin"
PG_DUMP_LOCAL="$PG_LOCAL_BIN_DIR/pg_dump"
PSQL_LOCAL="$PG_LOCAL_BIN_DIR/psql"
PG_ISREADY_LOCAL="$PG_LOCAL_BIN_DIR/pg_isready"

# إعدادات الاحتفاظ بالنسخ (RPO)
HOURLY_KEEP=24
DAILY_KEEP=7
WEEKLY_KEEP=4
MONTHLY_KEEP=12

# إعدادات الرفع السحابي
CLOUD_UPLOAD_ENABLED="${CLOUD_UPLOAD_ENABLED:-false}"
S3_BUCKET="${S3_BUCKET:-}"
S3_REGION="${S3_REGION:-us-east-1}"
AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-}"
AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-}"
S3_ENDPOINT="${S3_ENDPOINT:-}"

# إعدادات FTP
FTP_UPLOAD_ENABLED="${FTP_UPLOAD_ENABLED:-false}"
FTP_HOST="${FTP_HOST:-}"
FTP_USER="${FTP_USER:-}"
FTP_PASS="${FTP_PASS:-}"
FTP_REMOTE_DIR="${FTP_REMOTE_DIR:-/backups}"

# ============================================
# ألوان الطباعة
# ============================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# ============================================
# متغيرات
# ============================================
DATE=$(date +%Y%m%d_%H%M%S)
DATE_DAY=$(date +%Y%m%d)
LOG_FILE="$LOG_DIR/backup_${DATE}.log"
BACKUP_TYPE="full"
START_TIME=$(date +%s)
ERRORS=0

# ============================================
# دوال مساعدة
# ============================================
log() {
    local level="$1"; shift
    local msg="$*"
    local ts=$(date '+%Y-%m-%d %H:%M:%S')
    local line="[$ts] [$level] $msg"
    echo "$line"
    # محاولة الكتابة في ملف السجل (لن تفشل العملية إذا لم يتمكن)
    echo "$line" >> "$LOG_FILE" 2>/dev/null || true
}
log_info()    { log "INFO"    "$@"; }
log_success() { log "SUCCESS" "$@"; }
log_warning() { log "WARNING" "$@"; }
log_error()   { log "ERROR"   "$@"; }

print_banner() {
    echo -e "\n${CYAN}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║     نسخ احتياطي شامل - ميدان الاقتصاد          ║${NC}"
    echo -e "${CYAN}║     Comprehensive Backup - Maydan Al-Iqtisad    ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}\n"
    echo -e "${BLUE}البيئة: $ENV_MODE${NC}"
    echo -e "${BLUE}قاعدة البيانات: $DB_HOST:$DB_PORT/$DB_NAME${NC}"
    echo -e "${BLUE}مسار النسخ: $BACKUP_ROOT${NC}"
    echo -e "${BLUE}مسار السجلات: $LOG_DIR${NC}\n"
}

create_dirs() {
    mkdir -p "$PG_BACKUP_DIR"/{hourly,daily,weekly,monthly} 2>/dev/null || true
    mkdir -p "$UPLOADS_BACKUP_DIR"/{hourly,daily,weekly,monthly} 2>/dev/null || true
    mkdir -p "$REDIS_BACKUP_DIR"/{hourly,daily,weekly,monthly} 2>/dev/null || true
    mkdir -p "$LOG_DIR" 2>/dev/null || true

    # التحقق من إمكانية الكتابة
    if ! touch "$BACKUP_ROOT/.write_test" 2>/dev/null; then
        log_error "لا يمكن الكتابة في $BACKUP_ROOT"
        log_info "حاول: sudo chown -R \$(whoami) $BACKUP_ROOT"
        log_info "أو شغّل مع صلاحيات root: sudo bash scripts/backup.sh"
        # محاولة استخدام مسار بديل
        BACKUP_ROOT="$PROJECT_DIR/backups"
        PG_BACKUP_DIR="$BACKUP_ROOT/postgresql"
        UPLOADS_BACKUP_DIR="$BACKUP_ROOT/uploads"
        REDIS_BACKUP_DIR="$BACKUP_ROOT/redis"
        mkdir -p "$PG_BACKUP_DIR"/{hourly,daily,weekly,monthly}
        mkdir -p "$UPLOADS_BACKUP_DIR"/{hourly,daily,weekly,monthly}
        mkdir -p "$REDIS_BACKUP_DIR"/{hourly,daily,weekly,monthly}
        log_warning "تم التحويل إلى مسار بديل: $BACKUP_ROOT"
    else
        rm -f "$BACKUP_ROOT/.write_test"
    fi

    log_info "تم إنشاء مجلدات النسخ الاحتياطي: $BACKUP_ROOT"
}

get_rpo_level() {
    local hour=$(date +%H)
    local day_of_week=$(date +%u)
    local day_of_month=$(date +%d)

    if [[ "$day_of_month" == "01" && "$hour" == "03" ]]; then
        echo "monthly"
    elif [[ "$day_of_week" == "7" && "$hour" == "03" ]]; then
        echo "weekly"
    elif [[ "$hour" == "03" ]]; then
        echo "daily"
    else
        echo "hourly"
    fi
}

# ============================================
# فحص اتصال PostgreSQL
# ============================================
check_pg_connection() {
    if [[ "$ENV_MODE" == "docker" ]]; then
        docker exec "$POSTGRES_CONTAINER" pg_isready -U "$DB_USER" -d "$DB_NAME" &>/dev/null
    else
        # بيئة محلية - تحقق من pg_isready
        if [[ -x "$PG_ISREADY_LOCAL" ]]; then
            PGPASSWORD="$DB_PASSWORD" "$PG_ISREADY_LOCAL" -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" &>/dev/null
        elif command -v pg_isready &>/dev/null; then
            PGPASSWORD="$DB_PASSWORD" pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" &>/dev/null
        else
            # محاولة اتصال مباشرة عبر psql
            PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1" &>/dev/null 2>&1
        fi
    fi
}

# ============================================
# 1. نسخ قاعدة بيانات PostgreSQL
# ============================================
backup_postgresql() {
    local rpo_level="$1"
    local backup_dir="$PG_BACKUP_DIR/$rpo_level"
    local backup_file="$backup_dir/maydan_db_${DATE}.sql.gz"

    log_info "بدء نسخ PostgreSQL (مستوى: $rpo_level، بيئة: $ENV_MODE)..."

    # فحص الاتصال
    if ! check_pg_connection; then
        log_error "لا يمكن الاتصال بـ PostgreSQL!"
        log_info "  البيئة: $ENV_MODE"
        log_info "  المضيف: $DB_HOST:$DB_PORT"
        log_info "  قاعدة البيانات: $DB_NAME"
        log_info "  المستخدم: $DB_USER"
        if [[ "$ENV_MODE" == "local" ]]; then
            log_info "  حاول تشغيل: bash scripts/start-pg.sh"
        elif [[ "$ENV_MODE" == "docker" ]]; then
            log_info "  حاول: docker start $POSTGRES_CONTAINER"
        fi
        return 1
    fi

    # تنفيذ pg_dump حسب البيئة
    if [[ "$ENV_MODE" == "docker" ]]; then
        # بيئة Docker
        if docker exec "$POSTGRES_CONTAINER" pg_dump -U "$DB_USER" -d "$DB_NAME" \
            --format=plain --no-owner --no-privileges \
            --verbose 2>>"$LOG_FILE" | gzip > "$backup_file"; then
            local size=$(du -sh "$backup_file" | cut -f1)
            log_success "تم نسخ PostgreSQL بنجاح: $backup_file ($size)"
        else
            log_error "فشل نسخ PostgreSQL!"
            rm -f "$backup_file" 2>/dev/null || true
            return 1
        fi

        # نسخة custom
        local custom_file="$backup_dir/maydan_db_${DATE}.dump"
        docker exec "$POSTGRES_CONTAINER" pg_dump -U "$DB_USER" -d "$DB_NAME" \
            --format=custom --verbose 2>>"$LOG_FILE" > "$custom_file" || { rm -f "$custom_file" 2>/dev/null; true; }

    else
        # بيئة محلية
        local pg_dump_cmd=""

        # البحث عن pg_dump المتاح
        if [[ -x "$PG_DUMP_LOCAL" ]]; then
            pg_dump_cmd="$PG_DUMP_LOCAL"
            log_info "استخدام pg_dump المحلي: $PG_DUMP_LOCAL"
        elif command -v pg_dump &>/dev/null; then
            pg_dump_cmd="pg_dump"
            log_info "استخدام pg_dump النظامي"
        else
            log_error "pg_dump غير موجود! تأكد من تثبيت PostgreSQL"
            return 1
        fi

        # تنفيذ النسخ
        log_info "تنفيذ: $pg_dump_cmd -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME"

        if PGPASSWORD="$DB_PASSWORD" "$pg_dump_cmd" \
            -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            --format=plain --no-owner --no-privileges \
            --verbose 2>>"$LOG_FILE" | gzip > "$backup_file"; then

            local size=$(du -sh "$backup_file" | cut -f1)
            log_success "تم نسخ PostgreSQL بنجاح: $backup_file ($size)"
        else
            log_error "فشل نسخ PostgreSQL!"
            rm -f "$backup_file" 2>/dev/null || true
            return 1
        fi

        # نسخة custom (أسرع في الاسترداد)
        local custom_file="$backup_dir/maydan_db_${DATE}.dump"
        if PGPASSWORD="$DB_PASSWORD" "$pg_dump_cmd" \
            -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            --format=custom 2>>"$LOG_FILE" > "$custom_file"; then
            local custom_size=$(du -sh "$custom_file" | cut -f1)
            log_success "تم إنشاء نسخة custom: $custom_file ($custom_size)"
        else
            log_warning "فشل إنشاء نسخة custom (غير حرج)"
            rm -f "$custom_file" 2>/dev/null || true
        fi
    fi

    return 0
}

# ============================================
# 2. نسخ الملفات المرفوعة (صور + مستندات)
# ============================================
backup_uploads() {
    local rpo_level="$1"
    local backup_dir="$UPLOADS_BACKUP_DIR/$rpo_level"

    log_info "بدء نسخ الملفات المرفوعة (مستوى: $rpo_level)..."

    # تحديد مصدر الملفات المرفوعة تلقائياً
    local uploads_source=""
    for src in "${UPLOADS_SOURCES[@]}"; do
        if [[ -d "$src" ]]; then
            uploads_source="$src"
            break
        fi
    done

    if [[ -z "$uploads_source" ]]; then
        log_warning "لم يتم العثور على مجلد الملفات المرفوعة في أي من المسارات:"
        for src in "${UPLOADS_SOURCES[@]}"; do
            log_warning "  - $src"
        done
        log_info "سيتم إنشاء نسخة فارغة كعلامة مرجعية"
        mkdir -p "$backup_dir/uploads_latest"
        return 0
    fi

    log_info "مصدر الملفات: $uploads_source"

    # نسخ تدريجي باستخدام rsync
    local rsync_target="$backup_dir/uploads_latest"

    if rsync -avz --delete \
        --stats \
        --log-file="$LOG_FILE" \
        "$uploads_source/" "$rsync_target/"; then

        local size=$(du -sh "$rsync_target" | cut -f1)
        local file_count=$(find "$rsync_target" -type f | wc -l)
        log_success "تم نسخ الملفات المرفوعة: $rsync_target ($size, $file_count ملف)"
    else
        log_error "فشل نسخ الملفات المرفوعة!"
        return 1
    fi

    # إنشاء أرشيف مضغوط (للرفع السحابي أو النسخ غير كل ساعة)
    if [[ "$rpo_level" != "hourly" ]]; then
        local archive_file="$backup_dir/uploads_${DATE}.tar.gz"
        if tar -czf "$archive_file" -C "$backup_dir" uploads_latest/ 2>>"$LOG_FILE"; then
            local archive_size=$(du -sh "$archive_file" | cut -f1)
            log_success "تم إنشاء أرشيف الملفات: $archive_file ($archive_size)"
        else
            log_warning "فشل إنشاء أرشيف الملفات (غير حرج)"
            rm -f "$archive_file" 2>/dev/null || true
        fi
    fi

    # نسخ المجلدات الفرعية بشكل منفصل
    for subdir in avatars covers posts article research; do
        local sub_src="$uploads_source/$subdir"
        if [[ -d "$sub_src" ]]; then
            local sub_target="$backup_dir/${subdir}_latest"
            rsync -avz "$sub_src/" "$sub_target/" 2>>"$LOG_FILE" || true
            local sub_count=$(find "$sub_target" -type f 2>/dev/null | wc -l)
            log_info "  تم نسخ $subdir: $sub_count ملف"
        fi
    done

    return 0
}

# ============================================
# 3. نسخ بيانات Redis
# ============================================
backup_redis() {
    local rpo_level="$1"
    local backup_dir="$REDIS_BACKUP_DIR/$rpo_level"

    log_info "بدء نسخ Redis (مستوى: $rpo_level)..."

    if [[ "$ENV_MODE" == "docker" ]]; then
        # بيئة Docker
        if ! docker ps --format '{{.Names}}' 2>/dev/null | grep -q "^${REDIS_CONTAINER}$"; then
            log_warning "حاوية Redis ($REDIS_CONTAINER) غير تعمل - تخطي"
            return 0  # ليس خطأ حرج - Redis هو كاش فقط
        fi

        # إجبار Redis على حفظ البيانات
        docker exec "$REDIS_CONTAINER" redis-cli BGSAVE 2>>"$LOG_FILE" || true
        sleep 3

        # نسخ ملف RDB
        local rdb_file="$backup_dir/dump_${DATE}.rdb"
        docker cp "$REDIS_CONTAINER:/data/dump.rdb" "$rdb_file" 2>>"$LOG_FILE" || true

        if [[ -f "$rdb_file" ]]; then
            local size=$(du -sh "$rdb_file" | cut -f1)
            log_success "تم نسخ Redis RDB: $rdb_file ($size)"
        fi

        # نسخ AOF
        local aof_file="$backup_dir/appendonly_${DATE}.aof"
        docker cp "$REDIS_CONTAINER:/data/appendonly.aof" "$aof_file" 2>/dev/null || true
        [[ -f "$aof_file" ]] && log_success "تم نسخ Redis AOF: $aof_file"

    else
        # بيئة محلية
        if command -v redis-cli &>/dev/null; then
            if redis-cli ping &>/dev/null; then
                log_info "Redis يعمل محلياً - بدء النسخ..."

                # إجبار الحفظ
                redis-cli BGSAVE &>/dev/null || true
                sleep 3

                # نسخ ملف RDB
                local rdb_file="$backup_dir/dump_${DATE}.rdb"
                local redis_rdb_path=$(redis-cli CONFIG GET dir 2>/dev/null | tail -1 || echo "/var/lib/redis")
                local redis_rdb_file=$(redis-cli CONFIG GET dbfilename 2>/dev/null | tail -1 || echo "dump.rdb")

                if [[ -f "$redis_rdb_path/$redis_rdb_file" ]]; then
                    cp "$redis_rdb_path/$redis_rdb_file" "$rdb_file" 2>>"$LOG_FILE" || true
                    [[ -f "$rdb_file" ]] && log_success "تم نسخ Redis RDB: $rdb_file"
                else
                    log_warning "لم يتم العثور على ملف RDB في: $redis_rdb_path/$redis_rdb_file"
                fi

                # تصدير المفاتيح
                local keys_file="$backup_dir/redis_keys_${DATE}.txt"
                redis-cli --scan 2>/dev/null | head -10000 > "$keys_file" || true
                local keys_count=$(wc -l < "$keys_file" 2>/dev/null || echo "0")
                log_info "تم تصدير $keys_count مفتاح Redis"
            else
                log_warning "Redis غير يعمل محلياً - تخطي (غير حرج - الكاش فقط)"
                return 0
            fi
        else
            log_warning "redis-cli غير مثبت - تخطي نسخ Redis (غير حرج - الكاش فقط)"
            return 0  # ليس خطأ - Redis كاش فقط
        fi
    fi

    return 0
}

# ============================================
# 4. تنظيف النسخ القديمة حسب RPO
# ============================================
cleanup_old_backups() {
    log_info "بدء تنظيف النسخ القديمة..."

    find "$PG_BACKUP_DIR/hourly" -name "maydan_db_*.sql.gz" -mtime +1 -delete 2>/dev/null || true
    find "$PG_BACKUP_DIR/hourly" -name "maydan_db_*.dump" -mtime +1 -delete 2>/dev/null || true
    find "$REDIS_BACKUP_DIR/hourly" -name "dump_*.rdb" -mtime +1 -delete 2>/dev/null || true
    find "$PG_BACKUP_DIR/daily" -name "maydan_db_*.sql.gz" -mtime +7 -delete 2>/dev/null || true
    find "$PG_BACKUP_DIR/daily" -name "maydan_db_*.dump" -mtime +7 -delete 2>/dev/null || true
    find "$UPLOADS_BACKUP_DIR/daily" -name "uploads_*.tar.gz" -mtime +7 -delete 2>/dev/null || true
    find "$REDIS_BACKUP_DIR/daily" -name "dump_*.rdb" -mtime +7 -delete 2>/dev/null || true
    find "$PG_BACKUP_DIR/weekly" -name "maydan_db_*.sql.gz" -mtime +28 -delete 2>/dev/null || true
    find "$UPLOADS_BACKUP_DIR/weekly" -name "uploads_*.tar.gz" -mtime +28 -delete 2>/dev/null || true
    find "$PG_BACKUP_DIR/monthly" -name "maydan_db_*.sql.gz" -mtime +365 -delete 2>/dev/null || true
    find "$UPLOADS_BACKUP_DIR/monthly" -name "uploads_*.tar.gz" -mtime +365 -delete 2>/dev/null || true
    find "$LOG_DIR" -name "backup_*.log" -mtime +30 -delete 2>/dev/null || true

    log_success "تم تنظيف النسخ القديمة"
}

# ============================================
# 5. رفع النسخ للسحابة (S3)
# ============================================
upload_to_s3() {
    if [[ "$CLOUD_UPLOAD_ENABLED" != "true" ]]; then
        log_info "الرفع السحابي غير مفعّل"
        return 0
    fi

    if [[ -z "$S3_BUCKET" ]]; then
        log_warning "S3_BUCKET غير محدد - تخطي"
        return 0
    fi

    if ! command -v aws &>/dev/null; then
        log_warning "AWS CLI غير مثبت - تخطي الرفع السحابي"
        return 0
    fi

    log_info "بدء رفع النسخ للسحابة (S3)..."
    local rpo_level="$1"
    local s3_base="s3://$S3_BUCKET/maydan-backups/$DATE_DAY"
    local s3_cmd="aws s3 cp"
    [[ -n "$S3_ENDPOINT" ]] && s3_cmd="aws s3 cp --endpoint-url $S3_ENDPOINT"

    local pg_file="$PG_BACKUP_DIR/$rpo_level/maydan_db_${DATE}.sql.gz"
    [[ -f "$pg_file" ]] && $s3_cmd "$pg_file" "$s3_base/postgresql/" 2>>"$LOG_FILE" && log_success "تم رفع PostgreSQL إلى S3"

    local redis_file="$REDIS_BACKUP_DIR/$rpo_level/dump_${DATE}.rdb"
    [[ -f "$redis_file" ]] && $s3_cmd "$redis_file" "$s3_base/redis/" 2>>"$LOG_FILE" && log_success "تم رفع Redis إلى S3"

    local uploads_archive="$UPLOADS_BACKUP_DIR/$rpo_level/uploads_${DATE}.tar.gz"
    [[ -f "$uploads_archive" ]] && $s3_cmd "$uploads_archive" "$s3_base/uploads/" 2>>"$LOG_FILE" && log_success "تم رفع الملفات إلى S3"

    log_success "اكتمل الرفع السحابي"
}

# ============================================
# 6. رفع النسخ عبر FTP
# ============================================
upload_to_ftp() {
    if [[ "$FTP_UPLOAD_ENABLED" != "true" ]]; then return 0; fi
    [[ -z "$FTP_HOST" || -z "$FTP_USER" || -z "$FTP_PASS" ]] && return 0

    log_info "بدء رفع النسخ عبر FTP..."
    local rpo_level="$1"

    if command -v lftp &>/dev/null; then
        lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" <<EOF 2>>"$LOG_FILE"
set ssl:verify-certificate no
mirror -R --only-newer "$PG_BACKUP_DIR/$rpo_level" "$FTP_REMOTE_DIR/postgresql/$rpo_level" || exit 1
mirror -R --only-newer "$REDIS_BACKUP_DIR/$rpo_level" "$FTP_REMOTE_DIR/redis/$rpo_level" || exit 1
quit
EOF
        log_success "تم رفع النسخ عبر FTP"
    elif command -v curl &>/dev/null; then
        local pg_file="$PG_BACKUP_DIR/$rpo_level/maydan_db_${DATE}.sql.gz"
        [[ -f "$pg_file" ]] && curl -T "$pg_file" "ftp://$FTP_USER:$FTP_PASS@$FTP_HOST$FTP_REMOTE_DIR/postgresql/" --silent 2>>"$LOG_FILE" || true
        log_success "تم رفع النسخ عبر FTP (curl)"
    fi
}

# ============================================
# 7. حساب مساحة التخزين
# ============================================
calculate_disk_usage() {
    log_info "حساب مساحة التخزين المستخدمة..."

    if [[ -d "$BACKUP_ROOT" ]]; then
        local pg_size=$(du -sh "$PG_BACKUP_DIR" 2>/dev/null | cut -f1 || echo "0")
        local uploads_size=$(du -sh "$UPLOADS_BACKUP_DIR" 2>/dev/null | cut -f1 || echo "0")
        local redis_size=$(du -sh "$REDIS_BACKUP_DIR" 2>/dev/null | cut -f1 || echo "0")
        local total=$(du -sh "$BACKUP_ROOT" 2>/dev/null | cut -f1 || echo "0")

        log_info "  PostgreSQL:  $pg_size"
        log_info "  Uploads:     $uploads_size"
        log_info "  Redis:       $redis_size"
        log_info "  الإجمالي:    $total"
    fi

    local disk_info=$(df -h "$BACKUP_ROOT" 2>/dev/null | tail -1 || df -h / | tail -1)
    log_info "  مساحة القرص: $disk_info"
}

# ============================================
# 8. إنشاء تقرير النسخ الاحتياطي
# ============================================
generate_report() {
    local end_time=$(date +%s)
    local duration=$(( end_time - START_TIME ))
    local minutes=$(( duration / 60 ))
    local seconds=$(( duration % 60 ))
    local rpo_level=$(get_rpo_level)

    local report_file="$BACKUP_ROOT/backup_report_${DATE}.txt"

    cat > "$report_file" << REPORT
============================================
تقرير النسخ الاحتياطي - ميدان الاقتصاد
============================================
التاريخ:           $(date '+%Y-%m-%d %H:%M:%S')
البيئة:            $ENV_MODE
النوع:             $BACKUP_TYPE
مستوى RPO:         $rpo_level
المدة:             ${minutes} دقيقة ${seconds} ثانية
قاعدة البيانات:    $DB_HOST:$DB_PORT/$DB_NAME
============================================
الحالة:
  PostgreSQL:      $([ -f "$PG_BACKUP_DIR/$rpo_level/maydan_db_${DATE}.sql.gz" ] && echo "نجاح" || echo "فشل")
  Uploads:         $([ -d "$UPLOADS_BACKUP_DIR/$rpo_level/uploads_latest" ] && echo "نجاح" || echo "فشل")
  Redis:           $([ -f "$REDIS_BACKUP_DIR/$rpo_level/dump_${DATE}.rdb" ] && echo "نجاح" || echo "غير متوفر")
  رفع سحابي:       $([ "$CLOUD_UPLOAD_ENABLED" == "true" ] && echo "مفعّل" || echo "معطّل")
============================================
REPORT

    log_info "تم إنشاء تقرير النسخ: $report_file"
    cat "$report_file"
}

# ============================================
# التشغيل الرئيسي
# ============================================
main() {
    print_banner
    create_dirs

    # تحليل المعاملات
    local do_db=true
    local do_uploads=true
    local do_redis=true
    local do_cloud=false

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --db-only)
                do_db=true; do_uploads=false; do_redis=false
                BACKUP_TYPE="database-only"
                ;;
            --uploads)
                do_db=false; do_uploads=true; do_redis=false
                BACKUP_TYPE="uploads-only"
                ;;
            --redis)
                do_db=false; do_uploads=false; do_redis=true
                BACKUP_TYPE="redis-only"
                ;;
            --all)
                do_cloud=true
                BACKUP_TYPE="full-with-cloud"
                ;;
            --no-cloud)
                do_cloud=false
                BACKUP_TYPE="full-local"
                ;;
            *)
                log_warning "معامل غير معروف: $1"
                ;;
        esac
        shift
    done

    # تحديد مستوى RPO
    local rpo_level=$(get_rpo_level)
    log_info "مستوى نقطة الاسترداد (RPO): $rpo_level"
    log_info "نوع النسخ: $BACKUP_TYPE"
    log_info "التاريخ: $DATE"

    # تنفيذ النسخ
    local errors=0

    if [[ "$do_db" == "true" ]]; then
        backup_postgresql "$rpo_level" || errors=$((errors + 1))
    fi

    if [[ "$do_uploads" == "true" ]]; then
        backup_uploads "$rpo_level" || errors=$((errors + 1))
    fi

    if [[ "$do_redis" == "true" ]]; then
        backup_redis "$rpo_level" || errors=$((errors + 1))
    fi

    # تنظيف النسخ القديمة
    cleanup_old_backups

    # رفع للسحابة
    if [[ "$do_cloud" == "true" ]]; then
        upload_to_s3 "$rpo_level"
        upload_to_ftp "$rpo_level"
    fi

    # حساب المساحة
    calculate_disk_usage

    # إنشاء تقرير
    generate_report

    # النتيجة النهائية
    if [[ $errors -eq 0 ]]; then
        log_success "تمت عملية النسخ الاحتياطي بنجاح!"
    else
        log_error "تمت عملية النسخ الاحتياطي مع $errors أخطاء"
        exit 1
    fi
}

main "$@"
