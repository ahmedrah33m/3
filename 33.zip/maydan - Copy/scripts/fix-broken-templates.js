#!/usr/bin/env node
// Find and fix broken template literals in feature files
// Pattern: 'something${var}`  →  `something${var}`
// (single quote at start, backtick at end — bug from generate-features.js)

const fs = require('fs')
const path = require('path')

const ROOT = path.resolve(__dirname, '..', 'src', 'lib', 'features')

function walk(dir) {
  const results = []
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) results.push(...walk(full))
    else if (entry.name.endsWith('.ts')) results.push(full)
  }
  return results
}

// Regex: single-quote string starting with text, containing ${...} interpolation, ending with backtick
// This is broken because the opening quote doesn't match the closing backtick.
// Pattern: 'someText${...}`  OR  'someText${...}`someMoreText'  etc.
// We want to match: ' [^\n]*? \${ [^\n]*? } [^\n]*? `
// And replace the opening ' with `.
const BROKEN_TEMPLATE = /'([^'\n]*?\$\{[^}\n]*?\}[^`\n]*?)`/g

let totalFixed = 0
const filesFixed = []

for (const file of walk(ROOT)) {
  const src = fs.readFileSync(file, 'utf8')
  if (!BROKEN_TEMPLATE.test(src)) continue
  BROKEN_TEMPLATE.lastIndex = 0
  const fixed = src.replace(BROKEN_TEMPLATE, '`$1`')
  if (fixed !== src) {
    const count = (src.match(BROKEN_TEMPLATE) || []).length
    fs.writeFileSync(file, fixed)
    filesFixed.push({ file: path.relative(process.cwd(), file), count })
    totalFixed += count
  }
}

console.log(`\n✅ Fixed ${totalFixed} broken template literals in ${filesFixed.length} files:`)
for (const { file, count } of filesFixed) {
  console.log(`  ${file}: ${count} fix(es)`)
}
