#!/usr/bin/env python3
"""
RTL Fix Script — Fixes all hardcoded dir="rtl" and physical positioning issues.
Makes components dynamically RTL/LTR aware using the I18n system.
"""

import re
import os
import glob

BASE = "/home/z/my-project/midan6/src"

# ════════════════════════════════════════════════════════════════
# 1. Fix globals.css — Remove the standalone (always-on) .rtl-flip
# ════════════════════════════════════════════════════════════════
def fix_globals_css():
    path = os.path.join(BASE, "app", "globals.css")
    with open(path, "r") as f:
        content = f.read()

    # Remove the duplicate standalone .rtl-flip block (lines 1363-1370)
    # Keep only the one inside [dir="rtl"] which is at line 495
    old_block = """/* ─── RTL flip utility (standalone) ─── */
.rtl-flip {
  transform: scaleX(-1);
}

[dir="rtl"] .rtl-flip {
  transform: scaleX(-1);
}"""

    # Replace with empty (the [dir="rtl"] .rtl-flip at line 495 already handles it)
    if old_block in content:
        content = content.replace(old_block, "/* RTL flip handled by [dir=\"rtl\"] .rtl-flip above */")
        print("  ✓ globals.css: Removed duplicate standalone .rtl-flip")
    else:
        print("  ⚠ globals.css: Could not find duplicate .rtl-flip block exactly")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 2. Fix command.tsx — Replace hardcoded dir="rtl" with dynamic
# ════════════════════════════════════════════════════════════════
def fix_command_tsx():
    path = os.path.join(BASE, "components", "ui", "command.tsx")
    with open(path, "r") as f:
        content = f.read()

    # Add dir to the useI18n destructuring for components that already use it
    # CommandInput and CommandEmpty already use useI18n

    # Replace all standalone dir="rtl" with dir={dir}
    # For components that already have useI18n, just change dir="rtl" to dir={dir}
    # For the Command root and others that don't, we need to add useI18n

    # The Command root doesn't use useI18n — but it's a client component, so we can add it
    # Actually, looking at the code, the Command root has no hook calls.
    # Let's make the whole component dir-aware by using a wrapper approach.
    # Simpler: since the root <html> already sets dir, we can just remove dir="rtl" 
    # from Command components and let them inherit. But cmdk might need explicit dir.
    # Best approach: use dynamic dir.

    # For the root Command component, we can't easily add hooks without restructuring.
    # Instead, let's create a small wrapper that reads from the document.
    
    # Actually, the simplest approach: add useI18n to each sub-component that needs it.
    # The Command root - let's just remove dir="rtl" and let it inherit from html.
    # CommandInput, CommandEmpty, CommandGroup, CommandItem, CommandSeparator - same.

    # Replace all dir="rtl" with nothing (inherit from html) since <html> already has correct dir
    # This is actually the cleanest approach for Radix/cmdk components inside a dir-aware document.

    content = content.replace('dir="rtl"\n', '')
    content = content.replace('      dir="rtl"\n', '')
    content = content.replace('        dir="rtl"\n', '')

    # Remove the // @ts-nocheck since we're cleaning up
    content = content.replace('// @ts-nocheck\n', '')

    with open(path, "w") as f:
        f.write(content)
    print("  ✓ command.tsx: Removed hardcoded dir=\"rtl\" (inherits from <html>)")


# ════════════════════════════════════════════════════════════════
# 3. Fix chart.tsx — Remove hardcoded dir="rtl"
# ════════════════════════════════════════════════════════════════
def fix_chart_tsx():
    path = os.path.join(BASE, "components", "ui", "chart.tsx")
    with open(path, "r") as f:
        content = f.read()

    # Replace dir="rtl" — inherit from html
    lines = content.split('\n')
    new_lines = []
    for line in lines:
        if 'dir="rtl"' in line and 'ChartContainer' not in line:
            # For ChartContainer, we want to make it dynamic
            new_lines.append(line.replace('dir="rtl"', ''))
        elif 'dir="rtl"' in line:
            new_lines.append(line.replace('dir="rtl"', ''))
        else:
            new_lines.append(line)

    content = '\n'.join(new_lines)

    with open(path, "w") as f:
        f.write(content)
    print("  ✓ chart.tsx: Removed hardcoded dir=\"rtl\"")


# ════════════════════════════════════════════════════════════════
# 4. Fix calendar.tsx — Remove hardcoded dir="rtl"
# ════════════════════════════════════════════════════════════════
def fix_calendar_tsx():
    path = os.path.join(BASE, "components", "ui", "calendar.tsx")
    with open(path, "r") as f:
        content = f.read()

    content = content.replace('      dir="rtl"\n', '')

    with open(path, "w") as f:
        f.write(content)
    print("  ✓ calendar.tsx: Removed hardcoded dir=\"rtl\"")


# ════════════════════════════════════════════════════════════════
# 5. Fix sonner.tsx — Make dir dynamic
# ════════════════════════════════════════════════════════════════
def fix_sonner_tsx():
    path = os.path.join(BASE, "components", "ui", "sonner.tsx")
    with open(path, "r") as f:
        content = f.read()

    # Check if useI18n is already imported
    has_i18n = "useI18n" in content

    if not has_i18n:
        # Add useI18n import
        content = content.replace(
            'import { cn } from "@/lib/utils"',
            'import { cn } from "@/lib/utils"\nimport { useI18n } from "@/lib/i18n"'
        )
        # Add useI18n call in ThemeToaster
        content = content.replace(
            'const { resolvedTheme = "light" } = useTheme()',
            'const { resolvedTheme = "light" } = useTheme()\n  const { dir } = useI18n()'
        )
        # Replace dir="rtl" with dir={dir}
        content = content.replace('dir="rtl"', 'dir={dir}')
        print("  ✓ sonner.tsx: Made dir dynamic using useI18n")
    else:
        content = content.replace('dir="rtl"', 'dir={dir}')
        print("  ✓ sonner.tsx: Replaced dir=\"rtl\" with dir={dir}")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 6. Fix MobileNavDrawer — Dynamic side based on RTL
# ════════════════════════════════════════════════════════════════
def fix_mobile_nav_drawer():
    path = os.path.join(BASE, "components", "MobileNavDrawer.tsx")
    with open(path, "r") as f:
        content = f.read()

    # Replace: side="left" with dynamic side based on dir
    # The component already uses useI18n and has `dir` available
    old = '<SheetContent side="left" className="w-72 p-0 overflow-y-auto drawer-glass">'
    new = '<SheetContent side={isRTL ? "right" : "left"} className="w-72 p-0 overflow-y-auto drawer-glass">'
    
    if old in content:
        content = content.replace(old, new)
        print("  ✓ MobileNavDrawer.tsx: Made side dynamic (right for RTL, left for LTR)")
    else:
        print("  ⚠ MobileNavDrawer.tsx: Could not find SheetContent side=\"left\"")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 7. Fix ScrollToTop — Use logical property start-6 instead of left-6
# ════════════════════════════════════════════════════════════════
def fix_scroll_to_top():
    path = os.path.join(BASE, "components", "ScrollToTop.tsx")
    with open(path, "r") as f:
        content = f.read()

    content = content.replace('left-6 z-40', 'start-6 z-40')
    print("  ✓ ScrollToTop.tsx: left-6 → start-6")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 8. Fix PWAInstallPrompt — Use logical properties
# ════════════════════════════════════════════════════════════════
def fix_pwa_install_prompt():
    path = os.path.join(BASE, "components", "PWAInstallPrompt.tsx")
    with open(path, "r") as f:
        content = f.read()

    # Replace: fixed bottom-20 left-3 right-3 ... sm:left-auto sm:right-4
    old = 'className="fixed bottom-20 left-3 right-3 z-50 sm:left-auto sm:right-4 sm:w-96 lg:bottom-4"'
    new = 'className="fixed bottom-20 inset-x-3 z-50 sm:start-auto sm:end-4 sm:w-96 lg:bottom-4"'

    if old in content:
        content = content.replace(old, new)
        print("  ✓ PWAInstallPrompt.tsx: Used logical properties for positioning")
    else:
        print("  ⚠ PWAInstallPrompt.tsx: Could not find exact positioning class")

    # Also fix ml-2 in download button
    content = content.replace('ml-2', 'ms-2')
    print("  ✓ PWAInstallPrompt.tsx: ml-2 → ms-2")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 9. Fix MobileBottomNav — Use inset-x-0
# ════════════════════════════════════════════════════════════════
def fix_mobile_bottom_nav():
    path = os.path.join(BASE, "components", "MobileBottomNav.tsx")
    with open(path, "r") as f:
        content = f.read()

    content = content.replace('left-0 right-0 z-50', 'inset-x-0 z-50')
    print("  ✓ MobileBottomNav.tsx: left-0 right-0 → inset-x-0")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 10. Fix (main)/layout.tsx — ThemeToggle positioning
# ════════════════════════════════════════════════════════════════
def fix_main_layout():
    path = os.path.join(BASE, "app", "(main)", "layout.tsx")
    with open(path, "r") as f:
        content = f.read()

    content = content.replace('fixed bottom-4 left-4 z-40', 'fixed bottom-4 start-4 z-40')
    print("  ✓ (main)/layout.tsx: left-4 → start-4 for ThemeToggle")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 11. Fix landing-widgets.tsx — Use logical properties for fixed elements
# ════════════════════════════════════════════════════════════════
def fix_landing_widgets():
    path = os.path.join(BASE, "components", "landing", "landing-widgets.tsx")
    with open(path, "r") as f:
        content = f.read()

    # FloatingNotifications: fixed bottom-24 left-4
    content = content.replace('fixed bottom-24 left-4 z-[60]', 'fixed bottom-24 start-4 z-[60]')
    # Close button: left-2
    content = content.replace('absolute top-2 left-2 w-5', 'absolute top-2 start-2 w-5')
    # Text: pr-4
    content = content.replace('text-xs leading-5 pr-4', 'text-xs leading-5 pe-4')

    # AIChatWidget button: fixed bottom-6 right-6
    content = content.replace('fixed bottom-6 right-6 z-[70]', 'fixed bottom-6 end-6 z-[70]')
    # AIChat popup: fixed bottom-24 right-4
    content = content.replace('fixed bottom-24 right-4 z-[70]', 'fixed bottom-24 end-4 z-[70]')
    # mr-auto in chat header
    content = content.replace('mr-auto flex items-center', 'ms-auto flex items-center')

    print("  ✓ landing-widgets.tsx: Fixed physical left/right → logical start/end")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 12. Fix AdminPanel.tsx — Dynamic Tailwind class
# ════════════════════════════════════════════════════════════════
def fix_admin_panel():
    path = os.path.join(BASE, "components", "AdminPanel.tsx")
    with open(path, "r") as f:
        content = f.read()

    # Fix dynamic Tailwind class: border-${dir === 'rtl' ? 'l' : 'r'} → border-s
    old_pattern = 'border-${dir === \'rtl\' ? \'l\' : \'r\'}'
    if old_pattern in content:
        content = content.replace(old_pattern, 'border-s')
        print("  ✓ AdminPanel.tsx: Fixed dynamic Tailwind class border-s")
    else:
        # Try alternate quoting
        old2 = 'border-${dir === "rtl" ? "l" : "r"}'
        if old2 in content:
            content = content.replace(old2, 'border-s')
            print("  ✓ AdminPanel.tsx: Fixed dynamic Tailwind class border-s")
        else:
            print("  ⚠ AdminPanel.tsx: Dynamic class pattern not found, searching...")
            # Search for the pattern
            if "border-${" in content:
                print("    Found border-${ pattern, attempting fix")
                content = re.sub(
                    r'border-\$\{dir\s*===\s*[\'"]rtl[\'"]\s*\?\s*[\'"]l[\'"]\s*:\s*[\'"]r[\'"]\}',
                    'border-s',
                    content
                )
                print("    ✓ Fixed with regex")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 13. Bulk fix: Replace hardcoded dir="rtl" on Dialog/DialogContent 
#     and div components with dynamic dir using useI18n
# ════════════════════════════════════════════════════════════════

# Files that already use useI18n — just need dir="rtl" → dir={dir}
FILES_WITH_I18N = [
    os.path.join(BASE, "components", "AdminPanel.tsx"),
    os.path.join(BASE, "components", "PromoteButton.tsx"),
    os.path.join(BASE, "components", "EventsView.tsx"),
    os.path.join(BASE, "components", "DiscussionsPage.tsx"),
    os.path.join(BASE, "components", "PollsView.tsx"),
    os.path.join(BASE, "components", "QuestionsView.tsx"),
    os.path.join(BASE, "components", "QuestionDetail.tsx"),
    os.path.join(BASE, "components", "RepostButton.tsx"),
    os.path.join(BASE, "components", "OnboardingFlow.tsx"),
    os.path.join(BASE, "components", "ResearchView.tsx"),
    os.path.join(BASE, "components", "NativeShareButton.tsx"),
    os.path.join(BASE, "components", "ExpertVerificationForm.tsx"),
    os.path.join(BASE, "components", "ImageLightbox.tsx"),
    os.path.join(BASE, "components", "ProfessionalProfileView.tsx"),
    os.path.join(BASE, "components", "CVBuilder.tsx"),
    os.path.join(BASE, "components", "Recommendations.tsx"),
    os.path.join(BASE, "components", "WorldEconomicMap.tsx"),
    os.path.join(BASE, "components", "ExpertMarketView.tsx"),
]

# Files that need useI18n added and dir="rtl" → dir={dir}
FILES_NEED_I18N = [
    os.path.join(BASE, "components", "admin", "BulkNotifications.tsx"),
    os.path.join(BASE, "components", "admin", "ExpertVerifications.tsx"),
    os.path.join(BASE, "components", "admin", "ReportedContent.tsx"),
    os.path.join(BASE, "components", "admin", "FlaggedContentManager.tsx"),
    os.path.join(BASE, "components", "admin", "BroadcastNotification.tsx"),
    os.path.join(BASE, "components", "admin", "AdminCharts.tsx"),
    os.path.join(BASE, "components", "admin", "PaymentsSection.tsx"),
    os.path.join(BASE, "components", "admin", "DataExport.tsx"),
    os.path.join(BASE, "components", "admin", "AuditLog.tsx"),
    os.path.join(BASE, "components", "social", "MentorshipView.tsx"),
    os.path.join(BASE, "components", "security", "SessionManager.tsx"),
    os.path.join(BASE, "components", "security", "SecurityDashboard.tsx"),
    os.path.join(BASE, "components", "security", "TrustedDevices.tsx"),
    os.path.join(BASE, "components", "security", "ApiKeyManager.tsx"),
    os.path.join(BASE, "components", "economic", "InflationCalculator.tsx"),
    os.path.join(BASE, "components", "economic", "EconomicDashboardWidget.tsx"),
    os.path.join(BASE, "components", "economic", "ISXTicker.tsx"),
    os.path.join(BASE, "components", "profile", "Recommendations.tsx"),
    os.path.join(BASE, "components", "profile", "ProfileDialogs.tsx"),
    os.path.join(BASE, "components", "profile", "ProfileTabs.tsx"),
]

# Page files
PAGE_FILES = [
    os.path.join(BASE, "app", "(main)", "wallet", "page.tsx"),
    os.path.join(BASE, "app", "(main)", "premium", "page.tsx"),
    os.path.join(BASE, "app", "(main)", "learn", "page.tsx"),
    os.path.join(BASE, "app", "(main)", "jobs", "[id]", "page.tsx"),
]


def add_use_i18n_import(content: str) -> str:
    """Add useI18n import if not present."""
    if "useI18n" in content:
        return content

    # Add import after the last import line
    import_match = re.search(r'(import\s+.*?)(?:\n\n|\nconst|\nfunction|\nexport|\n\'use client\')', content, re.DOTALL)
    if import_match:
        last_import = import_match.group(1)
        # Check if there's already an import from @/lib/i18n
        if '@/lib/i18n' in content:
            # Find the i18n import and add useI18n
            content = re.sub(
                r'import\s+\{([^}]+)\}\s+from\s+["\']@/lib/i18n["\']',
                lambda m: f'import {{ {m.group(1).strip()}, useI18n }} from "@/lib/i18n"' if 'useI18n' not in m.group(1) else m.group(0),
                content
            )
        else:
            # Add new import
            content = re.sub(
                r'(import\s+.*?from\s+["\'][^"\']+["\'];?\n)',
                lambda m: m.group(0) + 'import { useI18n } from "@/lib/i18n"\n',
                content,
                count=1
            )
    return content


def add_dir_destructuring(content: str) -> str:
    """Add dir to useI18n destructuring if not present."""
    if 'const { dir' in content or 'const { t, dir' in content or 'const { locale, dir' in content:
        return content

    # Find existing useI18n destructuring and add dir
    patterns = [
        (r'const \{ t \} = useI18n\(\)', 'const { t, dir } = useI18n()'),
        (r'const \{ t, locale \} = useI18n\(\)', 'const { t, locale, dir } = useI18n()'),
        (r'const \{ locale \} = useI18n\(\)', 'const { locale, dir } = useI18n()'),
        (r'const \{ (\w+(?:, \w+)*) \} = useI18n\(\)', lambda m: f'const {{ {m.group(1)}, dir }} = useI18n()'),
    ]
    for pattern, replacement in patterns:
        new_content = re.sub(pattern, replacement, content)
        if new_content != content:
            return new_content

    return content


def fix_files_with_i18n():
    """Fix files that already have useI18n."""
    count = 0
    for path in FILES_WITH_I18N:
        if not os.path.exists(path):
            continue
        with open(path, "r") as f:
            content = f.read()

        if 'dir="rtl"' not in content:
            continue

        # Check if dir is destructured from useI18n
        if 'const { dir' not in content and 'const { t, dir' not in content:
            content = add_dir_destructuring(content)

        # Replace dir="rtl" with dir={dir}
        original = content
        content = content.replace('dir="rtl"', 'dir={dir}')

        if content != original:
            with open(path, "w") as f:
                f.write(content)
            count += 1
            fname = os.path.basename(path)
            print(f"  ✓ {fname}: dir=\"rtl\" → dir={{dir}} (useI18n already present)")

    return count


def fix_files_need_i18n():
    """Fix files that need useI18n added."""
    count = 0
    for path in FILES_NEED_I18N:
        if not os.path.exists(path):
            continue
        with open(path, "r") as f:
            content = f.read()

        if 'dir="rtl"' not in content:
            continue

        original = content

        # Check if it's a client component
        is_client = "'use client'" in content or '"use client"' in content

        if is_client:
            # Add useI18n import
            content = add_use_i18n_import(content)

            # Add dir destructuring — find the function component
            # Look for common patterns where we can inject the hook call
            # We'll add it at the start of the function body

            # Strategy: find the first line after function definition to add hook
            # Pattern: function ComponentName(...) { or const ComponentName = (...) => {
            func_match = re.search(
                r'((?:function\s+\w+|const\s+\w+\s*=\s*(?:\([^)]*\)|[^=])\s*=>)\s*\{)',
                content
            )
            if func_match:
                insert_pos = func_match.end()
                # Check if useI18n is already called after the function opening
                after_func = content[insert_pos:insert_pos+200]
                if 'useI18n()' not in after_func:
                    hook_line = '\n  const { dir } = useI18n()\n'
                    content = content[:insert_pos] + hook_line + content[insert_pos:]

        # Replace dir="rtl" with dir={dir}
        if 'dir="rtl"' in content:
            content = content.replace('dir="rtl"', 'dir={dir}')

        if content != original:
            with open(path, "w") as f:
                f.write(content)
            count += 1
            fname = os.path.basename(path)
            print(f"  ✓ {fname}: Added useI18n and dir=\"rtl\" → dir={{dir}}")

    return count


def fix_page_files():
    """Fix page files with hardcoded dir="rtl"."""
    count = 0
    for path in PAGE_FILES:
        if not os.path.exists(path):
            continue
        with open(path, "r") as f:
            content = f.read()

        if 'dir="rtl"' not in content:
            continue

        original = content

        # Check if it's a client component
        is_client = "'use client'" in content or '"use client"' in content

        if is_client:
            content = add_use_i18n_import(content)

            # Find function body to add hook
            func_match = re.search(
                r'((?:function\s+\w+|const\s+\w+\s*=\s*(?:\([^)]*\)|[^=])\s*=>)\s*\{)',
                content
            )
            if func_match:
                insert_pos = func_match.end()
                after_func = content[insert_pos:insert_pos+500]
                if 'useI18n()' not in after_func:
                    hook_line = '\n  const { dir } = useI18n()\n'
                    content = content[:insert_pos] + hook_line + content[insert_pos:]
        else:
            # Server component — just remove dir="rtl" to let it inherit from <html>
            content = content.replace('dir="rtl"', '')

        if content != original:
            with open(path, "w") as f:
                f.write(content)
            count += 1
            fname = os.path.relpath(path, BASE)
            print(f"  ✓ {fname}: Fixed dir=\"rtl\"")

    return count


# ════════════════════════════════════════════════════════════════
# 14. Fix RepostButton.tsx — Uses left-0 for popover position
# ════════════════════════════════════════════════════════════════
def fix_repost_button():
    path = os.path.join(BASE, "components", "RepostButton.tsx")
    if not os.path.exists(path):
        return
    with open(path, "r") as f:
        content = f.read()

    content = content.replace('left-0 mb-2', 'start-0 mb-2')
    print("  ✓ RepostButton.tsx: left-0 → start-0")

    with open(path, "w") as f:
        f.write(content)


# ════════════════════════════════════════════════════════════════
# 15. Fix global-error.tsx — Make dir dynamic
# ════════════════════════════════════════════════════════════════
def fix_global_error():
    path = os.path.join(BASE, "app", "global-error.tsx")
    if not os.path.exists(path):
        return
    with open(path, "r") as f:
        content = f.read()

    # global-error is a special Next.js file - it's a client component
    # but can't use context easily. Since it's an error boundary,
    # keeping dir="rtl" is acceptable as a safe default (the app 
    # is primarily Arabic). We'll leave this one as-is.
    print("  ℹ global-error.tsx: Keeping dir=\"rtl\" (error boundary — safe default)")


# ════════════════════════════════════════════════════════════════
# 16. Fix DataExport.tsx — The HTML export template uses hardcoded RTL
# ════════════════════════════════════════════════════════════════
def fix_data_export():
    path = os.path.join(BASE, "components", "admin", "DataExport.tsx")
    if not os.path.exists(path):
        return
    with open(path, "r") as f:
        content = f.read()

    # The HTML template string uses dir="rtl" — this is for exported files
    # which should respect the current locale. But since this is a generated
    # HTML string, we can't use React hooks. We'll make it use a variable.
    # For now, since the export is primarily for Arabic users, keep as-is.
    print("  ℹ DataExport.tsx: HTML export template keeps dir=\"rtl\" (exported file)")


# ════════════════════════════════════════════════════════════════
# 17. Fix email.ts and email-change-flow.ts — Email templates
# ════════════════════════════════════════════════════════════════
def fix_email_templates():
    # Email templates are server-side rendered strings, not React components
    # They use dir="rtl" in HTML strings which is correct for Arabic emails
    # Leave as-is since these are email templates, not interactive UI
    print("  ℹ email.ts / email-change-flow.ts: Email templates keep dir=\"rtl\" (email HTML)")


# ════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("RTL Fix Script — Midan6 Project")
    print("=" * 60)

    print("\n📦 Phase 1: Core UI Components")
    fix_command_tsx()
    fix_chart_tsx()
    fix_calendar_tsx()
    fix_sonner_tsx()

    print("\n📦 Phase 2: Navigation & Fixed Elements")
    fix_mobile_nav_drawer()
    fix_scroll_to_top()
    fix_pwa_install_prompt()
    fix_mobile_bottom_nav()
    fix_main_layout()

    print("\n📦 Phase 3: CSS Fixes")
    fix_globals_css()

    print("\n📦 Phase 4: Landing Page Components")
    fix_landing_widgets()

    print("\n📦 Phase 5: Component-Specific Fixes")
    fix_admin_panel()
    fix_repost_button()

    print("\n📦 Phase 6: Bulk Fix — Files with existing useI18n")
    c1 = fix_files_with_i18n()

    print("\n📦 Phase 7: Bulk Fix — Files needing useI18n added")
    c2 = fix_files_need_i18n()

    print("\n📦 Phase 8: Page Files")
    c3 = fix_page_files()

    print("\n📦 Phase 9: Known Exceptions (kept as-is)")
    fix_global_error()
    fix_data_export()
    fix_email_templates()

    print("\n" + "=" * 60)
    total = c1 + c2 + c3
    print(f"Done! Fixed {total} component files + core UI + CSS.")
    print("=" * 60)