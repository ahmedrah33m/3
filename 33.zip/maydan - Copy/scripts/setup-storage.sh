#!/bin/bash
# ============================================
# سكريبت إعداد التخزين لمشروع ميدان الاقتصاد
# Storage Setup Script for Maydan Al-Iqtisad
# ============================================
# الأقراص المطلوبة:
#   - NVMe SSD 500GB → PostgreSQL + Redis (سريع)
#   - HDD 2TB        → MinIO + النسخ الاحتياطي (كبير)
# ============================================

set -e

# ---- ألوان الطباعة ----
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}============================================${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}============================================${NC}\n"
}

print_step() {
    echo -e "${GREEN}▶ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✖ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# ---- التحقق من المستخدم الجذر ----
if [[ $EUID -ne 0 ]]; then
    print_error "هذا السكريبت يحتاج صلاحيات root"
    echo "شغّل: sudo bash scripts/setup-storage.sh"
    exit 1
fi

print_header "إعداد التخزين لمشروع ميدان الاقتصاد"

# ============================================
# الخطوة 1: كشف الأقراص
# ============================================
print_header "الخطوة 1: كشف الأقراص المتاحة"

lsblk -d -o NAME,SIZE,TYPE,MODEL,ROTA

echo ""
echo -e "${YELLOW}أدخل اسم قرص NVMe SSD (مثال: nvme0n1):${NC}"
read -r NVME_DISK

echo -e "${YELLOW}أدخل اسم قرص HDD (مثال: sda):${NC}"
read -r HDD_DISK

# التحقق من وجود الأقراص
if [[ ! -b /dev/$NVME_DISK ]]; then
    print_error "القرص /dev/$NVME_DISK غير موجود!"
    exit 1
fi

if [[ ! -b /dev/$HDD_DISK ]]; then
    print_error "القرص /dev/$HDD_DISK غير موجود!"
    exit 1
fi

print_success "تم العثور على الأقراص"

# ============================================
# الخطوة 2: تحذير - مسح البيانات
# ============================================
print_header "الخطوة 2: تحذير مهم"

print_warning "⚠ هذا السكريبت سيمسح جميع البيانات على الأقراص المحددة!"
print_warning "⚠ تأكد من عمل نسخة احتياطية قبل المتابعة"
echo ""
echo -e "${RED}هل أنت متأكد؟ اكتب 'MAYDAN' للمتابعة:${NC}"
read -r CONFIRM

if [[ "$CONFIRM" != "MAYDAN" ]]; then
    print_error "تم الإلغاء"
    exit 1
fi

# ============================================
# الخطوة 3: تقسيم NVMe SSD
# ============================================
print_header "الخطوة 3: تقسيم NVMe SSD"

print_step "إنشاء جدول أقسام GPT على /dev/$NVME_DISK ..."
sgdisk -Z /dev/$NVME_DISK  # مسح أي جدول موجود
sgdisk -o /dev/$NVME_DISK  # إنشاء جدول GPT جديد

print_step "إنشاء الأقسام ..."
# القسم 1: النظام + التطبيقات (30GB)
sgdisk -n 1:0:+30G -t 1:8300 -c 1:"system" /dev/$NVME_DISK
# القسم 2: PostgreSQL (100GB)
sgdisk -n 2:0:+100G -t 2:8300 -c 2:"postgresql" /dev/$NVME_DISK
# القسم 3: Redis (20GB)
sgdisk -n 3:0:+20G -t 3:8300 -c 3:"redis" /dev/$NVME_DISK
# القسم 4: Docker (50GB)
sgdisk -n 4:0:+50G -t 4:8300 -c 4:"docker" /dev/$NVME_DISK
# القسم 5: Swap (16GB)
sgdisk -n 5:0:+16G -t 5:8200 -c 5:"swap" /dev/$NVME_DISK
# القسم 6: المساحة المتبقية
sgdisk -n 6:0:0 -t 6:8300 -c 6:"nvme-free" /dev/$NVME_DISK

print_success "تم تقسيم NVMe SSD"

# ============================================
# الخطوة 4: تهيئة أقسام NVMe
# ============================================
print_header "الخطوة 4: تهيئة أقسام NVMe SSD"

print_step "تهيئة القسم 2 (PostgreSQL) ..."
mkfs.ext4 -L postgresql -E lazy_itable_init=1 /dev/${NVME_DISK}p2

print_step "تهيئة القسم 3 (Redis) ..."
mkfs.ext4 -L redis -E lazy_itable_init=1 /dev/${NVME_DISK}p3

print_step "تهيئة القسم 4 (Docker) ..."
mkfs.ext4 -L docker-data -E lazy_itable_init=1 /dev/${NVME_DISK}p4

print_step "تهيئة القسم 5 (Swap) ..."
mkswap -L swap /dev/${NVME_DISK}p5

print_step "تهيئة القسم 6 (مساحة حرة) ..."
mkfs.ext4 -L nvme-free -E lazy_itable_init=1 /dev/${NVME_DISK}p6

print_success "تم تهيئة أقسام NVMe SSD"

# ============================================
# الخطوة 5: تقسيم وتهيئة HDD
# ============================================
print_header "الخطوة 5: تقسيم وتهيئة HDD 2TB"

print_step "إنشاء جدول أقسام GPT على /dev/$HDD_DISK ..."
sgdisk -Z /dev/$HDD_DISK
sgdisk -o /dev/$HDD_DISK

print_step "إنشاء قسم HDD واحد (2TB) ..."
sgdisk -n 1:0:0 -t 1:8300 -c 1:"hdd-data" /dev/$HDD_DISK

print_step "تهيئة HDD ..."
mkfs.ext4 -L hdd-data -E lazy_itable_init=1 /dev/${HDD_DISK}1

print_success "تم تهيئة HDD"

# ============================================
# الخطوة 6: إنشاء نقاط التحميل
# ============================================
print_header "الخطوة 6: إنشاء نقاط التحميل"

print_step "إنشاء المجلدات ..."
mkdir -p /mnt/postgresql
mkdir -p /mnt/redis
mkdir -p /mnt/docker
mkdir -p /mnt/hdd
mkdir -p /mnt/hdd/minio-data
mkdir -p /mnt/hdd/minio-data/uploads
mkdir -p /mnt/hdd/uploads-backup
mkdir -p /mnt/hdd/logs
mkdir -p /mnt/hdd/postgres-backup

print_success "تم إنشاء المجلدات"

# ============================================
# الخطوة 7: تحميل الأقسام
# ============================================
print_header "الخطوة 7: تحميل الأقسام"

print_step "تحميل أقسام NVMe ..."
mount -o noatime,discard /dev/${NVME_DISK}p2 /mnt/postgresql
mount -o noatime,discard /dev/${NVME_DISK}p3 /mnt/redis
mount -o noatime,discard /dev/${NVME_DISK}p4 /mnt/docker
mount -o noatime        /dev/${HDD_DISK}1     /mnt/hdd

print_step "تفعيل Swap ..."
swapon /dev/${NVME_DISK}p5

print_success "تم تحميل الأقسام"

# ============================================
# الخطوة 8: إضافة إلى fstab (تحميل دائم)
# ============================================
print_header "الخطوة 8: إعداد التحميل الدائم (fstab)"

# نسخ احتياطي
cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)

# الحصول على UUIDs
PG_UUID=$(blkid -s UUID -o value /dev/${NVME_DISK}p2)
REDIS_UUID=$(blkid -s UUID -o value /dev/${NVME_DISK}p3)
DOCKER_UUID=$(blkid -s UUID -o value /dev/${NVME_DISK}p4)
SWAP_UUID=$(blkid -s UUID -o value /dev/${NVME_DISK}p5)
HDD_UUID=$(blkid -s UUID -o value /dev/${HDD_DISK}1)

# إضافة إلى fstab
cat >> /etc/fstab << EOF

# ===========================================
# ميدان الاقتصاد - تخزين محسّن لـ 100K+ مستخدم
# ===========================================

# NVMe SSD - PostgreSQL (سريع لقاعدة البيانات)
UUID=$PG_UUID    /mnt/postgresql  ext4  defaults,noatime,discard  0  2

# NVMe SSD - Redis (سريع للكاش)
UUID=$REDIS_UUID /mnt/redis       ext4  defaults,noatime,discard  0  2

# NVMe SSD - Docker (حاويات التطبيق)
UUID=$DOCKER_UUID /mnt/docker     ext4  defaults,noatime,discard  0  2

# NVMe SSD - Swap
UUID=$SWAP_UUID  none             swap  sw                        0  0

# HDD 2TB - MinIO + بيانات كبيرة
UUID=$HDD_UUID   /mnt/hdd         ext4  defaults,noatime          0  2
EOF

print_success "تم تحديث fstab"

# ============================================
# الخطوة 9: ضبط الصلاحيات
# ============================================
print_header "الخطوة 9: ضبط صلاحيات المجلدات"

# PostgreSQL يحتاج مالك 999 (postgres داخل Docker)
chown -R 999:999 /mnt/postgresql
chmod 700 /mnt/postgresql

# Redis يحتاج مالك 999 (redis داخل Docker)
chown -R 999:999 /mnt/redis
chmod 700 /mnt/redis

# MinIO يحتاج مالك 1000:1000
chown -R 1000:1000 /mnt/hdd/minio-data
chmod 755 /mnt/hdd/minio-data

# Docker
chmod 755 /mnt/docker

# النسخ الاحتياطي والسجلات
chmod 755 /mnt/hdd/uploads-backup
chmod 755 /mnt/hdd/logs
chmod 755 /mnt/hdd/postgres-backup

print_success "تم ضبط الصلاحيات"

# ============================================
# الخطوة 10: إعداد Docker لاستخدام SSD
# ============================================
print_header "الخطوة 10: إعداد Docker على SSD"

if command -v docker &> /dev/null; then
    # إيقاف Docker
    systemctl stop docker
    systemctl stop docker.socket
    
    # تحديث إعدادات Docker
    cat > /etc/docker/daemon.json << 'EOF'
{
    "data-root": "/mnt/docker",
    "storage-driver": "overlay2",
    "log-driver": "json-file",
    "log-opts": {
        "max-size": "50m",
        "max-file": "3"
    },
    "default-ulimits": {
        "nofile": {
            "Name": "nofile",
            "Hard": 65536,
            "Soft": 65536
        }
    }
}
EOF
    
    # نسخ بيانات Docker القديمة إن وجدت
    if [[ -d /var/lib/docker ]]; then
        print_step "نقل بيانات Docker الحالية إلى SSD ..."
        rsync -a /var/lib/docker/ /mnt/docker/
    fi
    
    # إعادة تشغيل Docker
    systemctl start docker.socket
    systemctl start docker
    
    print_success "تم إعداد Docker على SSD"
else
    print_warning "Docker غير مثبت - تخطي هذه الخطوة"
fi

# ============================================
# الخطوة 11: تحسين إعدادات النظام
# ============================================
print_header "الخطوة 11: تحسين إعدادات النظام لـ 100K مستخدم"

# تحسين kernel parameters
cat > /etc/sysctl.d/99-maydan.conf << 'EOF'
# ===========================================
# تحسينات النواة لمشروع ميدان الاقتصاد
# Kernel optimizations for 100K+ users
# ===========================================

# شبكة - زيادة الحد الأقصى للاتصالات
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_backlog = 65535

# شبكة - إعادة استخدام المقابس بسرعة
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 15

# شبكة - حجم المخازن المؤقتة
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216

# ملفات - حد الملفات المفتوحة
fs.file-max = 2097152

# ذاكرة - عدم التبديل إلا عند الضرورة القصوى
vm.swappiness = 1

# ذاكرة - تحسين الكاش
vm.dirty_ratio = 15
vm.dirty_background_ratio = 5

# PostgreSQL - الذاكرة المشتركة
kernel.shmmax = 8589934592
kernel.shmall = 2097152

# اتصالات - نطاق المنافذ المحلية
net.ipv4.ip_local_port_range = 1024 65535
EOF

# تطبيق الإعدادات
sysctl -p /etc/sysctl.d/99-maydan.conf

# تحسين حد الملفات المفتوحة
cat > /etc/security/limits.d/99-maydan.conf << 'EOF'
# حدود ميدان الاقتصاد
* soft nofile 655360
* hard nofile 655360
* soft nproc 655360
* hard nproc 655360
root soft nofile 655360
root hard nofile 655360
EOF

print_success "تم تحسين إعدادات النظام"

# ============================================
# الخطوة 12: إنشاء سكريبت النسخ الاحتياطي
# ============================================
print_header "الخطوة 12: إنشاء سكريبت النسخ الاحتياطي"

cat > /mnt/hdd/postgres-backup/backup.sh << 'BACKUP_SCRIPT'
#!/bin/bash
# نسخ احتياطي يومي لقاعدة بيانات PostgreSQL
# يحفظ على HDD مع ضغط gzip

BACKUP_DIR="/mnt/hdd/postgres-backup"
DATE=$(date +%Y%m%d_%H%M%S)
KEEP_DAYS=7

# نسخة احتياطية
docker exec maydan-postgres pg_dump -U maydan maydan_db | gzip > "$BACKUP_DIR/maydan_db_$DATE.sql.gz"

# حذف النسخ القديمة (أكثر من 7 أيام)
find "$BACKUP_DIR" -name "maydan_db_*.sql.gz" -mtime +$KEEP_DAYS -delete

echo "[$DATE] Backup completed: maydan_db_$DATE.sql.gz"
BACKUP_SCRIPT

chmod +x /mnt/hdd/postgres-backup/backup.sh

# إضافة cron job للنسخ الاحتياطي اليومي
(crontab -l 2>/dev/null; echo "0 3 * * * /mnt/hdd/postgres-backup/backup.sh >> /mnt/hdd/logs/backup.log 2>&1") | crontab -

print_success "تم إعداد النسخ الاحتياطي اليومي (3:00 صباحاً)"

# ============================================
# النتيجة النهائية
# ============================================
print_header "✓ اكتمل إعداد التخزين!"

echo ""
echo -e "${GREEN}ملخص التقسيم:${NC}"
echo ""
echo "┌─────────────────────────────────────────────────────┐"
echo "│  🔹 NVMe SSD 500GB (/dev/$NVME_DISK)              │"
echo "│     ├── p1: النظام         30GB                    │"
echo "│     ├── p2: PostgreSQL    100GB  ← /mnt/postgresql │"
echo "│     ├── p3: Redis          20GB  ← /mnt/redis      │"
echo "│     ├── p4: Docker         50GB  ← /mnt/docker     │"
echo "│     ├── p5: Swap           16GB                     │"
echo "│     └── p6: مساحة حرة    ~284GB                     │"
echo "│                                                     │"
echo "│  🔹 HDD 2TB (/dev/$HDD_DISK)                      │"
echo "│     └── p1: البيانات       2TB  ← /mnt/hdd         │"
echo "│         ├── minio-data/    (صور + ملفات)            │"
echo "│         ├── postgres-backup/ (نسخ احتياطي)         │"
echo "│         ├── uploads-backup/  (نسخ احتياطي)         │"
echo "│         └── logs/           (سجلات)                 │"
echo "└─────────────────────────────────────────────────────┘"
echo ""
echo -e "${YELLOW}الخطوات التالية:${NC}"
echo "  1. تأكد من التحميل: mount | grep mnt"
echo "  2. تأكد من Swap: free -h"
echo "  3. شغّل Docker Compose: docker compose up -d"
echo "  4. تحقق من الأداء: docker stats"
echo ""
echo -e "${BLUE}ملف fstab محفوظ في: /etc/fstab${NC}"
echo -e "${BLUE}النسخ الاحتياطي لـ fstab: /etc/fstab.backup.*${NC}"
