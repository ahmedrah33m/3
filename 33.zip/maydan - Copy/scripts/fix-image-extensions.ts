/**
 * Fix Image Extensions — Migration Script
 * 
 * This script:
 * 1. Scans public/uploads/ for files with mismatched extensions
 * 2. Renames them to match their actual content type
 * 3. Updates database records to reflect the new filenames
 * 
 * Run with: npx tsx scripts/fix-image-extensions.ts
 */

import { readFile, writeFile, rename, access } from 'fs/promises'
import { PrismaClient } from '@prisma/client'
import path from 'path'

const prisma = new PrismaClient()
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), 'public', 'uploads')

interface FormatInfo {
  format: string
  ext: string
  mime: string
}

function detectFormatFromBuffer(buffer: Buffer): FormatInfo | null {
  if (buffer.length < 12) return null

  // WebP: RIFF....WEBP
  if (
    buffer[0] === 0x52 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x46 &&
    buffer[8] === 0x57 && buffer[9] === 0x45 && buffer[10] === 0x42 && buffer[11] === 0x50
  ) {
    return { format: 'webp', ext: 'webp', mime: 'image/webp' }
  }

  // PNG: \x89PNG\r\n\x1a\n
  if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4E && buffer[3] === 0x47) {
    return { format: 'png', ext: 'png', mime: 'image/png' }
  }

  // JPEG: FF D8 FF
  if (buffer[0] === 0xFF && buffer[1] === 0xD8 && buffer[2] === 0xFF) {
    return { format: 'jpeg', ext: 'jpg', mime: 'image/jpeg' }
  }

  // GIF: GIF87a or GIF89a
  if (buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46) {
    return { format: 'gif', ext: 'gif', mime: 'image/gif' }
  }

  return null
}

async function fixImageExtensions() {
  console.log('=== Fix Image Extensions ===\n')
  
  const { readdir } = await import('fs/promises')
  
  async function scanDir(dir: string): Promise<string[]> {
    const entries = await readdir(dir, { withFileTypes: true })
    const files: string[] = []
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name)
      if (entry.isDirectory()) {
        files.push(...await scanDir(fullPath))
      } else if (entry.isFile()) {
        files.push(fullPath)
      }
    }
    return files
  }

  const files = await scanDir(UPLOAD_DIR)
  console.log(`Found ${files.length} files in uploads directory\n`)

  const renames: { oldUrl: string; newUrl: string }[] = []

  for (const filePath of files) {
    const ext = path.extname(filePath).toLowerCase().replace('.', '')
    if (!['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext)) continue

    const buffer = await readFile(filePath)
    const detected = detectFormatFromBuffer(buffer)
    if (!detected) continue

    if (ext !== detected.ext) {
      const newPath = filePath.replace(new RegExp(`\\.${ext}$`), `.${detected.ext}`)
      const oldRelPath = filePath.replace(UPLOAD_DIR, '/uploads')
      const newRelPath = newPath.replace(UPLOAD_DIR, '/uploads')

      try {
        await access(newPath)
        console.log(`SKIP (target exists): ${oldRelPath} -> ${newRelPath}`)
        continue
      } catch {
        // Target doesn't exist, proceed
      }

      await rename(filePath, newPath)
      renames.push({ oldUrl: oldRelPath, newUrl: newRelPath })
      console.log(`RENAMED: ${oldRelPath} -> ${newRelPath}`)
    }
  }

  if (renames.length === 0) {
    console.log('\nNo files needed renaming.')
    return
  }

  // Update database
  console.log(`\nUpdating ${renames.length} URLs in database...`)

  for (const { oldUrl, newUrl } of renames) {
    // Update User.avatar
    await prisma.user.updateMany({
      where: { avatar: oldUrl },
      data: { avatar: newUrl },
    })

    // Update User.coverImage
    await prisma.user.updateMany({
      where: { coverImage: oldUrl },
      data: { coverImage: newUrl },
    })

    // Update Article.coverImage
    await prisma.article.updateMany({
      where: { coverImage: oldUrl },
      data: { coverImage: newUrl },
    })

    // Update ArticleMedia.url
    await prisma.articleMedia.updateMany({
      where: { url: oldUrl },
      data: { url: newUrl },
    })

    // Update DiscussionMedia.url
    await prisma.discussionMedia.updateMany({
      where: { url: oldUrl },
      data: { url: newUrl },
    })
  }

  console.log('\nDatabase updated successfully!')
  console.log(`Total: ${renames.length} files renamed and ${renames.length * 5} DB fields checked.`)
}

fixImageExtensions()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
