#!/bin/bash
# ============================================================
# سكريبت إصلاح مشكلة مصادقة PostgreSQL — ميدان
# PostgreSQL Authentication Fix Script for Midan Platform
# ============================================================
#
# المشكلة: Invalid prisma.user.findUnique() — Authentication failed
# السبب: كلمة مرور مستخدم maydan في PostgreSQL غير مطابقة لـ DATABASE_URL
#
# هذا السكريبت يقوم بـ:
# 1. التحقق من أن PostgreSQL يعمل
# 2. إنشاء مستخدم maydan (إذا لم يوجد) بكلمة مرور جديدة
# 3. إنشاء قاعدة بيانات maydan_db (إذا لم توجد)
# 4. منح كل الصلاحيات
# 5. تحديث ملف .env.local بكلمة المرور الجديدة
# 6. اختبار الاتصال
# 7. تشغيل prisma db push
#
# الاستخدام:
#   chmod +x scripts/fix-postgres-auth.sh
#   ./scripts/fix-postgres-auth.sh
#
# أو مع كلمة مرور مخصصة:
#   NEW_DB_PASSWORD="MyStrongPass123" ./scripts/fix-postgres-auth.sh
# ============================================================

set -e

# ── ألوان للطباعة ──────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_info()  { echo -e "${BLUE}ℹ️  $1${NC}"; }
print_ok()    { echo -e "${GREEN}✅ $1${NC}"; }
print_warn()  { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }

# ── متغيرات ────────────────────────────────────────────────
DB_USER="maydan"
DB_NAME="maydan_db"
NEW_PASSWORD="${NEW_DB_PASSWORD:-$(openssl rand -hex 16)}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
ENV_LOCAL="$PROJECT_DIR/.env.local"
ENV_FILE="$PROJECT_DIR/.env"

echo "============================================================"
echo "  إصلاح مصادقة PostgreSQL — ميدان"
echo "  PostgreSQL Auth Fix — Midan Platform"
echo "============================================================"
echo ""
print_info "Database user: $DB_USER"
print_info "Database name: $DB_NAME"
print_info "New password:  $NEW_PASSWORD"
print_info "Project dir:   $PROJECT_DIR"
echo ""

# ── 1. التحقق من PostgreSQL ────────────────────────────────
print_info "1️⃣  Checking PostgreSQL installation..."

if ! command -v psql &> /dev/null; then
    print_error "PostgreSQL not installed. Installing..."
    sudo apt-get update
    sudo apt-get install -y postgresql postgresql-contrib
fi

if ! command -v pg_isready &> /dev/null; then
    print_error "pg_isready not found. PostgreSQL may not be installed correctly."
    exit 1
fi

print_ok "PostgreSQL installed"

# ── 2. تشغيل PostgreSQL إذا لم يكن يعمل ───────────────────
print_info "2️⃣  Checking PostgreSQL service..."

if ! pg_isready -q 2>/dev/null; then
    print_warn "PostgreSQL not running. Starting..."
    sudo systemctl start postgresql 2>/dev/null || \
    sudo service postgresql start 2>/dev/null || \
    {
        # Fallback: try starting via pg_ctlcluster
        local cluster=$(pg_lsclusters 2>/dev/null | tail -1 | awk '{print $1, $2}')
        if [ -n "$cluster" ]; then
            sudo pg_ctlcluster $cluster start 2>/dev/null
        fi
    }
    sleep 3
    if ! pg_isready -q 2>/dev/null; then
        print_error "Could not start PostgreSQL. Please start it manually:"
        echo "    sudo systemctl start postgresql"
        exit 1
    fi
fi

print_ok "PostgreSQL is running"

# ── 3. إنشاء/تحديث مستخدم maydan ───────────────────────────
print_info "3️⃣  Creating/updating user '$DB_USER'..."

# Check if user exists
if sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1; then
    print_warn "User '$DB_USER' exists. Updating password..."
    sudo -u postgres psql -c "ALTER USER $DB_USER WITH PASSWORD '$NEW_PASSWORD';"
    print_ok "Password updated for user '$DB_USER'"
else
    print_info "Creating user '$DB_USER'..."
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$NEW_PASSWORD' CREATEDB;"
    print_ok "User '$DB_USER' created"
fi

# ── 4. إنشاء قاعدة البيانات maydan_db ─────────────────────
print_info "4️⃣  Creating database '$DB_NAME'..."

if sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1; then
    print_warn "Database '$DB_NAME' already exists. Keeping data."
else
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
    print_ok "Database '$DB_NAME' created"
fi

# ── 5. منح الصلاحيات ───────────────────────────────────────
print_info "5️⃣  Granting privileges..."

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO $DB_USER;" 2>/dev/null || true
# For PostgreSQL 15+, need to grant schema create
sudo -u postgres psql -d "$DB_NAME" -c "ALTER SCHEMA public OWNER TO $DB_USER;" 2>/dev/null || true

print_ok "Privileges granted"

# ── 6. اختبار الاتصال ──────────────────────────────────────
print_info "6️⃣  Testing connection with new credentials..."

if PGPASSWORD="$NEW_PASSWORD" psql -U "$DB_USER" -h localhost -p 5432 -d "$DB_NAME" -c "SELECT current_user, current_database();" 2>&1; then
    print_ok "Connection successful!"
else
    print_error "Connection failed. Trying with peer auth..."
    # If localhost fails, try 127.0.0.1
    if PGPASSWORD="$NEW_PASSWORD" psql -U "$DB_USER" -h 127.0.0.1 -p 5432 -d "$DB_NAME" -c "SELECT 1;" 2>&1; then
        print_ok "Connection successful via 127.0.0.1"
        DB_HOST="127.0.0.1"
    else
        print_error "Could not connect. Check pg_hba.conf:"
        echo "    sudo nano /etc/postgresql/*/main/pg_hba.conf"
        echo "  Make sure 'host all all 127.0.0.1/32 md5' is present."
        exit 1
    fi
fi

DB_HOST="${DB_HOST:-localhost}"

# ── 7. تحديث ملف .env.local ────────────────────────────────
print_info "7️⃣  Updating .env.local with new password..."

NEW_DATABASE_URL="postgresql://$DB_USER:$NEW_PASSWORD@$DB_HOST:5432/$DB_NAME?schema=public&connection_limit=5"
NEW_DIRECT_URL="postgresql://$DB_USER:$NEW_PASSWORD@$DB_HOST:5432/$DB_NAME?schema=public&connect_timeout=30"

if [ -f "$ENV_LOCAL" ]; then
    # Backup existing .env.local
    cp "$ENV_LOCAL" "$ENV_LOCAL.bak.$(date +%Y%m%d_%H%M%S)"
    print_ok "Backed up .env.local"

    # Update DATABASE_URL and DIRECT_DATABASE_URL
    # Use | as delimiter since password may contain /
    sed -i.bak "s|^DATABASE_URL=.*|DATABASE_URL=\"$NEW_DATABASE_URL\"|" "$ENV_LOCAL"
    sed -i.bak "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=\"$NEW_DIRECT_URL\"|" "$ENV_LOCAL"
    rm -f "$ENV_LOCAL.bak"
    print_ok "Updated .env.local"
elif [ -f "$ENV_FILE" ]; then
    # If only .env exists (no .env.local), update .env
    cp "$ENV_FILE" "$ENV_FILE.bak.$(date +%Y%m%d_%H%M%S)"
    sed -i.bak "s|^DATABASE_URL=.*|DATABASE_URL=\"$NEW_DATABASE_URL\"|" "$ENV_FILE"
    sed -i.bak "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=\"$NEW_DIRECT_URL\"|" "$ENV_FILE"
    rm -f "$ENV_FILE.bak"
    print_ok "Updated .env (consider creating .env.local for secrets)"
else
    # Create .env.local from .env.example
    print_warn "No .env or .env.local found. Creating .env.local..."
    cp "$PROJECT_DIR/.env.example" "$ENV_LOCAL"
    sed -i.bak "s|^DATABASE_URL=.*|DATABASE_URL=\"$NEW_DATABASE_URL\"|" "$ENV_LOCAL"
    sed -i.bak "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=\"$NEW_DIRECT_URL\"|" "$ENV_LOCAL"
    rm -f "$ENV_LOCAL.bak"
    print_ok "Created .env.local"
fi

# ── 8. تشغيل Prisma ────────────────────────────────────────
print_info "8️⃣  Running prisma generate and db push..."

cd "$PROJECT_DIR"

print_info "Generating Prisma client..."
if npx prisma generate 2>&1; then
    print_ok "Prisma client generated"
else
    print_error "prisma generate failed"
    exit 1
fi

print_info "Pushing schema to database..."
if npx prisma db push 2>&1; then
    print_ok "Schema pushed to database"
else
    print_error "prisma db push failed. Check the error above."
    exit 1
fi

# ── 9. ملخص نهائي ──────────────────────────────────────────
echo ""
echo "============================================================"
echo "  ✅ تم إصلاح مشكلة مصادقة PostgreSQL بنجاح!"
echo "  PostgreSQL authentication fixed successfully!"
echo "============================================================"
echo ""
print_info "Summary:"
echo "  Database user: $DB_USER"
echo "  Database name: $DB_NAME"
echo "  Password:      $NEW_PASSWORD (saved in .env.local)"
echo "  Connection:    $DB_HOST:5432"
echo ""
print_info "Next steps:"
echo "  1. Restart your dev server:  npm run dev"
echo "  2. Try logging in again"
echo "  3. If you need an admin user: npm run create-admin"
echo ""
print_warn "⚠️  SECURITY NOTE:"
echo "  The password is stored in .env.local (gitignored)."
echo "  Do NOT commit .env.local to git."
echo ""
print_info "If you want to seed the database with sample data:"
echo "  npm run db:seed"
echo ""
