#!/bin/bash
# ============================================================
# 🔧 سكريبت DB موحد — يحل محل 5 سكريبتات مكررة
# Unified Database Setup & Fix Script
# ============================================================
#
# يحل محل:
#   - fix-database.sh (247 سطر)
#   - fix-postgres-auth.sh (235 سطر)
#   - fix-everything.sh (97 سطر)
#   - setup-db.sh (212 سطر)
#   - apply-correct-password.sh (222 سطر)
#
# الاستخدام:
#   bash scripts/db.sh <command>
#
# الأوامر المتاحة:
#   setup      — إعداد قاعدة بيانات جديدة (إنشاء user + db + تطبيق schema)
#   fix-auth   — إصلاح مشاكل مصادقة PostgreSQL
#   fix-pass   — تغيير كلمة مرور مستخدم maydan
#   migrate    — تطبيق migrations
#   seed       — بذر البيانات الأولية
#   reset      — إعادة تعيين قاعدة البيانات (تحذير: يحذف كل البيانات)
#   status     — فحص صحة الاتصال بقاعدة البيانات
#   all        — تشغيل setup + migrate + seed (للتثبيت الأولي)
#
# ============================================================

set -e

# ألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info()  { echo -e "${BLUE}ℹ️  $1${NC}"; }
print_ok()    { echo -e "${GREEN}✅ $1${NC}"; }
print_warn()  { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }

# متغيرات من البيئة (بدون قيم مُصلّبة)
DB_USER="${DB_USER:-maydan}"
DB_NAME="${DB_NAME:-maydan_db}"
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_PASSWORD="${DB_PASSWORD:?يجب تعيين DB_PASSWORD في .env أو كمتغير بيئة}"

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$PROJECT_DIR/.env"

# ============================================================
# 1. SETUP — إعداد قاعدة بيانات جديدة
# ============================================================
setup_db() {
    print_info "إعداد قاعدة بيانات جديدة..."
    print_info "User: $DB_USER"
    print_info "Database: $DB_NAME"
    print_info "Host: $DB_HOST:$DB_PORT"
    print_info "Password: [HIDDEN]"
    echo ""

    # 1. إنشاء المستخدم (إن لم يوجد)
    print_info "1️⃣  إنشاء مستخدم PostgreSQL..."
    sudo -u postgres psql -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_user WHERE usename = '$DB_USER') THEN CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD'; END IF; END \$\$;" || {
        print_warn "فشل إنشاء المستخدم. تأكد أن PostgreSQL يعمل وأن لديك صلاحية sudo."
    }
    print_ok "المستخدم جاهز"

    # 2. إنشاء قاعدة البيانات (إن لم توجد)
    print_info "2️⃣  إنشاء قاعدة البيانات..."
    sudo -u postgres psql -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT FROM pg_database WHERE datname = '$DB_NAME') THEN CREATE DATABASE $DB_NAME OWNER $DB_USER; END IF; END \$\$;" || {
        print_warn "فشل إنشاء قاعدة البيانات."
    }
    print_ok "قاعدة البيانات جاهزة"

    # 3. منح الصلاحيات
    print_info "3️⃣  منح الصلاحيات..."
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;" || true
    sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO $DB_USER;" || true
    print_ok "الصلاحيات ممنوحة"

    # 4. تحديث .env
    print_info "4️⃣  تحديث .env..."
    update_env_file
    print_ok ".env مُحدّث"

    # 5. توليد Prisma client
    print_info "5️⃣  توليد Prisma client..."
    cd "$PROJECT_DIR"
    npx prisma generate
    print_ok "Prisma client جاهز"

    print_ok "🎉 إعداد قاعدة البيانات مكتمل!"
}

# ============================================================
# 2. FIX-AUTH — إصلاح مشاكل مصادقة PostgreSQL
# ============================================================
fix_auth() {
    print_info "إصلاح مشاكل مصادقة PostgreSQL..."
    echo ""

    # 1. فحص pg_hba.conf
    print_info "1️⃣  فحص pg_hba.conf..."
    PG_HBA=$(sudo -u postgres psql -c "SHOW hba_file;" -t | xargs)

    if [ -f "$PG_HBA" ]; then
        print_info "ملف pg_hba.conf: $PG_HBA"

        # فحص إذا كان host all all 127.0.0.1/32 md5 موجود
        if grep -q "host.*all.*all.*127.0.0.1/32.*md5" "$PG_HBA" || \
           grep -q "host.*all.*all.*127.0.0.1/32.*scram-sha-256" "$PG_HBA"; then
            print_ok "pg_hba.conf يحتوي على قواعد md5/scram-sha-256"
        else
            print_warn "pg_hba.conf قد يحتاج تحديث. أضف السطر التالي:"
            echo "  host    all    all    127.0.0.1/32    md5"
            echo ""
            echo "  ثم أعد تحميل PostgreSQL: sudo systemctl reload postgresql"
        fi
    fi

    # 2. فحص اتصال المستخدم
    print_info "2️⃣  فحص اتصال المستخدم..."
    if PGPASSWORD="$DB_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "SELECT current_user, current_database();" 2>&1; then
        print_ok "الاتصال يعمل بشكل صحيح"
    else
        print_error "فشل الاتصال. جرّب fix-pass لتغيير كلمة المرور."
        return 1
    fi
}

# ============================================================
# 3. FIX-PASS — تغيير كلمة مرور مستخدم maydan
# ============================================================
fix_password() {
    print_info "تغيير كلمة مرور مستخدم $DB_USER..."
    echo ""

    if [ -z "$DB_PASSWORD" ]; then
        print_error "DB_PASSWORD غير محدد"
        echo "  استخدم: export DB_PASSWORD='new_strong_password'"
        return 1
    fi

    # 1. تغيير كلمة المرور في PostgreSQL
    print_info "1️⃣  تحديث كلمة المرور في PostgreSQL..."
    sudo -u postgres psql -c "ALTER USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
    print_ok "كلمة المرور مُحدّثة في PostgreSQL"

    # 2. تحديث .env
    print_info "2️⃣  تحديث .env..."
    update_env_file
    print_ok ".env مُحدّث"

    # 3. اختبار الاتصال
    print_info "3️⃣  اختبار الاتصال..."
    if PGPASSWORD="$DB_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "SELECT current_user, current_database();" 2>&1; then
        print_ok "🎉 الاتصال يعمل!"
    else
        print_error "فشل الاتصال. تحقق من pg_hba.conf"
        return 1
    fi
}

# ============================================================
# 4. MIGRATE — تطبيق migrations
# ============================================================
run_migrate() {
    print_info "تطبيق migrations..."
    cd "$PROJECT_DIR"

    # تجربة migrate deploy أولاً (للإنتاج)
    if npx prisma migrate deploy 2>&1; then
        print_ok "migrations مُطبّقة"
    else
        print_warn "migrate deploy فشل. تجربة db push..."
        npx prisma db push
        print_ok "schema مُطبّق عبر db push"
    fi

    npx prisma generate
    print_ok "Prisma client مُولّد"
}

# ============================================================
# 5. SEED — بذر البيانات الأولية
# ============================================================
run_seed() {
    print_info "بذر البيانات الأولية..."
    cd "$PROJECT_DIR"

    # بذر القاموس الاقتصادي أولاً
    if [ -f "prisma/seed-dictionary.ts" ]; then
        print_info "بذر القاموس الاقتصادي..."
        npx tsx prisma/seed-dictionary.ts || print_warn "فشل بذر القاموس"
    fi

    # بذر البيانات الشاملة
    if [ -f "prisma/seed.ts" ]; then
        print_info "بذر البيانات الشاملة..."
        npx tsx prisma/seed.ts || print_warn "فشل البذر الشامل"
    fi

    print_ok "البذر مكتمل"
}

# ============================================================
# 6. RESET — إعادة تعيين قاعدة البيانات
# ============================================================
reset_db() {
    print_warn "⚠️  هذا ستحذف كل البيانات في $DB_NAME!"
    read -p "هل أنت متأكد؟ اكتب RESET للتأكيد: " CONFIRM

    if [ "$CONFIRM" != "RESET" ]; then
        print_warn "تم الإلغاء."
        return 0
    fi

    print_info "إعادة تعيين قاعدة البيانات..."
    cd "$PROJECT_DIR"

    # إسقاط وإعادة إنشاء
    sudo -u postgres psql -c "DROP DATABASE IF EXISTS $DB_NAME;"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"

    # تطبيق schema
    npx prisma db push
    npx prisma generate

    print_ok "تمت إعادة التعيين"
}

# ============================================================
# 7. STATUS — فحص صحة الاتصال
# ============================================================
check_status() {
    print_info "فحص صحة الاتصال بقاعدة البيانات..."
    echo ""

    print_info "DB_USER: $DB_USER"
    print_info "DB_NAME: $DB_NAME"
    print_info "DB_HOST: $DB_HOST:$DB_PORT"
    print_info "DB_PASSWORD: [HIDDEN]"
    echo ""

    # اختبار الاتصال
    if PGPASSWORD="$DB_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "SELECT version();" 2>&1; then
        print_ok "✅ الاتصال يعمل"
    else
        print_error "❌ فشل الاتصال"
        echo ""
        echo "خطوات التشخيص:"
        echo "  1. تأكد أن PostgreSQL يعمل: sudo systemctl status postgresql"
        echo "  2. تأكد أن .env يحتوي DATABASE_URL صحيح"
        echo "  3. جرّب: bash scripts/db.sh fix-auth"
        echo "  4. جرّب: bash scripts/db.sh fix-pass"
        return 1
    fi

    # إحصائيات سريعة
    echo ""
    print_info "إحصائيات قاعدة البيانات:"
    PGPASSWORD="$DB_PASSWORD" psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "
        SELECT
            (SELECT count(*) FROM \"User\") as users,
            (SELECT count(*) FROM \"Article\") as articles,
            (SELECT count(*) FROM \"Job\") as jobs,
            (SELECT count(*) FROM \"Wallet\") as wallets;
    " 2>/dev/null || print_warn "تعذر جلب الإحصائيات (قد تكون قاعدة البيانات فارغة)"
}

# ============================================================
# 8. ALL — تشغيل setup + migrate + seed
# ============================================================
run_all() {
    print_info "تشغيل الإعداد الكامل (setup + migrate + seed)..."
    echo ""
    setup_db
    echo ""
    run_migrate
    echo ""
    run_seed
    echo ""
    print_ok "🎉 الإعداد الكامل مكتمل!"
    echo ""
    check_status
}

# ============================================================
# Helper: تحديث .env
# ============================================================
update_env_file() {
    if [ ! -f "$ENV_FILE" ]; then
        print_warn ".env غير موجود. استخدم: cp .env.example .env"
        return 1
    fi

    DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME?schema=public&connection_limit=5"
    DIRECT_DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@$DB_HOST:$DB_PORT/$DB_NAME?schema=public&connect_timeout=30"

    # Backup
    cp "$ENV_FILE" "$ENV_FILE.bak.$(date +%Y%m%d_%H%M%S)"

    # تحديث DATABASE_URL و DIRECT_DATABASE_URL و POSTGRES_PASSWORD
    if grep -q "^DATABASE_URL=" "$ENV_FILE"; then
        sed -i "s|^DATABASE_URL=.*|DATABASE_URL=\"$DATABASE_URL\"|" "$ENV_FILE"
    else
        echo "DATABASE_URL=\"$DATABASE_URL\"" >> "$ENV_FILE"
    fi

    if grep -q "^DIRECT_DATABASE_URL=" "$ENV_FILE"; then
        sed -i "s|^DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=\"$DIRECT_DATABASE_URL\"|" "$ENV_FILE"
    else
        echo "DIRECT_DATABASE_URL=\"$DIRECT_DATABASE_URL\"" >> "$ENV_FILE"
    fi

    if grep -q "^POSTGRES_PASSWORD=" "$ENV_FILE"; then
        sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$DB_PASSWORD|" "$ENV_FILE"
    else
        echo "POSTGRES_PASSWORD=$DB_PASSWORD" >> "$ENV_FILE"
    fi

    print_ok ".env مُحدّث بـ DATABASE_URL الجديد"
}

# ============================================================
# Main
# ============================================================
COMMAND="${1:-status}"

echo "============================================================"
echo "🔧 DB Script — موحد"
echo "============================================================"
echo ""

case "$COMMAND" in
    setup)    setup_db ;;
    fix-auth) fix_auth ;;
    fix-pass) fix_password ;;
    migrate)  run_migrate ;;
    seed)     run_seed ;;
    reset)    reset_db ;;
    status)   check_status ;;
    all)      run_all ;;
    *)
        echo "استخدام: bash scripts/db.sh <command>"
        echo ""
        echo "الأوامر المتاحة:"
        echo "  setup      — إعداد قاعدة بيانات جديدة"
        echo "  fix-auth   — إصلاح مشاكل مصادقة PostgreSQL"
        echo "  fix-pass   — تغيير كلمة مرور مستخدم maydan"
        echo "  migrate    — تطبيق migrations"
        echo "  seed       — بذر البيانات الأولية"
        echo "  reset      — إعادة تعيين (يحذف كل البيانات)"
        echo "  status     — فحص صحة الاتصال (افتراضي)"
        echo "  all        — setup + migrate + seed"
        exit 1
        ;;
esac
