-- ============================================================
-- Migration: Fix article visibility & articlesCount drift
-- ============================================================
--
-- Problem:
--   1. User.articlesCount is a denormalized counter that drifts when:
--      - Articles are created as DRAFT (counter incremented, but article not visible)
--      - Articles are soft-deleted via different code paths (some don't decrement)
--      - Article status changes between PUBLISHED ↔ DRAFT (no sync logic existed)
--   2. Profile UI shows "N مقالات" while Articles tab shows "لا توجد مقالات"
--
-- This migration is idempotent and safe to run on PostgreSQL.
-- Run with:  psql "$DATABASE_URL" -f scripts/migrate-articles.sql
-- Or via Prisma:  npx prisma db execute --file scripts/migrate-articles.sql
-- ============================================================

BEGIN;

-- Step 1: Ensure publishedAt column exists (no-op if already present)
-- This is needed because some dev DBs were created before the column was added.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Article' AND column_name = 'publishedAt'
  ) THEN
    ALTER TABLE "Article" ADD COLUMN "publishedAt" TIMESTAMP(3);
    RAISE NOTICE 'Added publishedAt column to Article table';
  ELSE
    RAISE NOTICE 'publishedAt column already exists — skipping';
  END IF;
END $$;

-- Step 2: Backfill publishedAt from createdAt for PUBLISHED articles with NULL publishedAt
UPDATE "Article"
SET "publishedAt" = "createdAt"
WHERE "status" = 'PUBLISHED' AND "publishedAt" IS NULL;

-- Step 3: Recompute User.articlesCount based on actual PUBLISHED, non-deleted articles
-- This is the main fix — resets the counter to ground truth.
UPDATE "User" u
SET "articlesCount" = COALESCE(
  (SELECT COUNT(*) FROM "Article" a
   WHERE a."authorId" = u."id"
     AND a."status" = 'PUBLISHED'
     AND a."deletedAt" IS NULL),
  0
);

-- Step 4: Create an index on publishedAt for faster ordering (if not exists)
CREATE INDEX IF NOT EXISTS "Article_publishedAt_idx" ON "Article"("publishedAt");

-- Step 5: Show summary
DO $$
DECLARE
  total_articles INTEGER;
  published_articles INTEGER;
  users_with_articles INTEGER;
BEGIN
  SELECT COUNT(*) INTO total_articles FROM "Article";
  SELECT COUNT(*) INTO published_articles FROM "Article"
    WHERE "status" = 'PUBLISHED' AND "deletedAt" IS NULL;
  SELECT COUNT(*) INTO users_with_articles FROM "User" WHERE "articlesCount" > 0;

  RAISE NOTICE 'Total articles: %', total_articles;
  RAISE NOTICE 'Published & visible: %', published_articles;
  RAISE NOTICE 'Users with at least 1 article: %', users_with_articles;
END $$;

COMMIT;

-- ============================================================
-- Post-migration verification (run manually if needed):
--
--   SELECT u.name, u."articlesCount",
--     (SELECT COUNT(*) FROM "Article" a
--      WHERE a."authorId" = u."id"
--        AND a."status" = 'PUBLISHED'
--        AND a."deletedAt" IS NULL) AS actual_published
--   FROM "User" u
--   WHERE u."articlesCount" > 0
--   ORDER BY u."articlesCount" DESC;
-- ============================================================
