#!/bin/bash
# === سكربت إصلاح سريع لمنصة ميدان ===
# يُستخدم بعد تشغيل install-fix.sh لإصلاح كلمة المرور والمستخدم
# الاستخدام: bash scripts/fix-everything.sh
# ============================================

set -e

# كشف مجلد المشروع تلقائياً
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "=========================================="
echo "  سكربت إصلاح سريع - منصة ميدان"
echo "=========================================="
echo ""

# === قراءة كلمة مرور قاعدة البيانات من .env ===
echo -e "${YELLOW}[1/2] قراءة كلمة مرور قاعدة البيانات من .env...${NC}"

ENV_FILE="$PROJECT_DIR/.env"
if [ ! -f "$ENV_FILE" ]; then
  ENV_FILE="$PROJECT_DIR/.env.local"
fi

if [ ! -f "$ENV_FILE" ]; then
  echo -e "${RED}❌ لم يتم العثور على ملف .env أو .env.local${NC}"
  exit 1
fi

DB_URL=$(grep '^DATABASE_URL=' "$ENV_FILE" | head -1 | cut -d'=' -f2-)
if [ -z "$DB_URL" ]; then
  echo -e "${RED}❌ لم يتم العثور على DATABASE_URL في $ENV_FILE${NC}"
  exit 1
fi

DB_PASS=$(echo "$DB_URL" | sed -n 's|postgresql://[^:]*:\([^@]*\)@.*|\1|p')

if [ -z "$DB_PASS" ]; then
  echo -e "${RED}❌ لم يتم استخراج كلمة مرور صالحة من DATABASE_URL${NC}"
  exit 1
fi

echo -e "${GREEN}  ✅ تم استخراج كلمة المرور${NC}"

# استخراج اسم قاعدة البيانات
DB_NAME=$(echo "$DB_URL" | sed -n 's|.*@\([^/]*\)/\([^?]*\).*|\2|p')
DB_USER=$(echo "$DB_URL" | sed -n 's|postgresql://\([^:]*\):.*|\1|p')

echo ""

# === تحديث كلمة مرور PostgreSQL ===
echo -e "${YELLOW}[2/2] تحديث كلمة المرور وإنشاء المستخدم التجريبي...${NC}"

sudo -u postgres psql -d "$DB_NAME" -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" 2>/dev/null || \
sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" 2>/dev/null
echo -e "${GREEN}  ✅ تم تحديث كلمة مرور PostgreSQL${NC}"

# إنشاء hash بكلمة المرور SeedPass1!
HASH=$(node -e "
const crypto = require('crypto');
const salt = crypto.randomBytes(16).toString('hex');
const hash = crypto.scryptSync('SeedPass1!', salt, 64).toString('hex');
console.log(salt + ':' + hash);
")

sudo -u postgres psql -d "$DB_NAME" << SQL
INSERT INTO "User" (id, email, password, name, role, "userType", "emailVerified", "isVerified", "createdAt", "updatedAt")
VALUES (
    gen_random_uuid(),
    'owner@midaniq.com',
    '${HASH}',
    'مدير ميدان',
    'OWNER',
    'economist',
    NOW(),
    true,
    NOW(),
    NOW()
)
ON CONFLICT (email) DO UPDATE SET password = '${HASH}', role = 'OWNER';
SQL

echo ""
echo "=========================================="
echo -e "${GREEN}  ✅ تم الإصلاح بنجاح!${NC}"
echo "=========================================="
echo ""
echo "  بيانات تسجيل الدخول:"
echo "  البريد:     owner@midaniq.com"
echo "  كلمة المرور: SeedPass1!"
echo ""