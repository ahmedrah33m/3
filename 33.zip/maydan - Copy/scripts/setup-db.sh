#!/usr/bin/env bash
# ============================================================
#  Midan Platform — Database Setup Script
#  سكريبت تجهيز قاعدة البيانات تلقائياً
# ============================================================
#  What it does:
#   1. Reads DB credentials from .env (or .env.example as template)
#   2. Creates the PostgreSQL role if missing
#   3. Creates the database if missing
#   4. Grants privileges
#   5. Tests connection
#   6. Runs prisma db push + generate + seed
#
#  Usage:
#    bash scripts/setup-db.sh           # full setup
#    bash scripts/setup-db.sh --quick   # skip prisma steps
#    bash scripts/setup-db.sh --reset   # drop & recreate (DESTRUCTIVE)
# ============================================================

set -e

# ─── Colors ─────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

print_step()    { echo -e "${BLUE}【$1】${NC} $2"; }
print_ok()      { echo -e "  ${GREEN}✓ $1${NC}"; }
print_warn()    { echo -e "  ${YELLOW}⚠ $1${NC}"; }
print_err()     { echo -e "  ${RED}✗ $1${NC}"; }
print_info()    { echo -e "  ${CYAN}ℹ $1${NC}"; }

# ─── Parse DATABASE_URL from .env ───────────────────────────────────
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

print_step "1/7" "قراءة إعدادات قاعدة البيانات..."

if [[ ! -f .env ]]; then
  print_warn "ملف .env غير موجود"
  if [[ -f .env.example ]]; then
    print_info "نسخ .env.example إلى .env..."
    cp .env.example .env
    print_ok "تم إنشاء .env — يرجى تعديل كلمة المرور ثم إعادة تشغيل السكريبت"
    echo ""
    echo -e "${BOLD}افتح .env الآن وعدّل:{{NC}"
    echo -e "  DATABASE_URL=postgresql://maydan:كلمة_المرور_الخاصة_بك@localhost:5432/maydan_db?schema=public"
    echo ""
    echo -e "${BOLD}ثم أعد التشغيل:${NC}"
    echo -e "  bash scripts/setup-db.sh"
    exit 1
  else
    print_err "ملف .env.example غير موجود أيضاً — لا يمكن المتابعة"
    exit 1
  fi
fi

# Extract DATABASE_URL from .env (handle quotes & comments)
DATABASE_URL=$(grep -E "^DATABASE_URL=" .env | head -1 | sed -E 's/^DATABASE_URL=//; s/^"//; s/"$//; s/^'\''//; s/'\''$//')

if [[ -z "$DATABASE_URL" ]]; then
  print_err "DATABASE_URL غير موجودة في .env"
  exit 1
fi

if [[ "$DATABASE_URL" == *"CHANGE_ME"* ]]; then
  print_err "DATABASE_URL تحتوي على CHANGE_ME — يرجى تعديلها بقيم حقيقية"
  print_info "افتح .env وعدّل السطر DATABASE_URL=..."
  exit 1
fi

# Parse the URL: postgresql://USER:PASSWORD@HOST:PORT/DB_NAME?params
if [[ ! "$DATABASE_URL" =~ ^postgres(?:ql)?://([^:@/]+)(?::([^@/]+))?@([^:/]+)(?::([0-9]+))?/([^?]+) ]]; then
  print_err "صيغة DATABASE_URL غير صالحة"
  print_info "الصيغة المتوقعة: postgresql://USER:PASSWORD@HOST:PORT/DB_NAME?schema=public"
  exit 1
fi

DB_USER="${BASH_REMATCH[1]}"
DB_PASS="${BASH_REMATCH[2]}"
DB_HOST="${BASH_REMATCH[3]}"
DB_PORT="${BASH_REMATCH[4]:-5432}"
DB_NAME="${BASH_REMATCH[5]}"

# URL-decode the password (in case it contains %40 for @, etc.)
DB_PASS=$(printf '%b' "${DB_PASS//%/\\x}")

print_ok "تم تحليل DATABASE_URL بنجاح"
print_info "المستخدم: $DB_USER"
print_info "المضيف:   $DB_HOST:$DB_PORT"
print_info "القاعدة:  $DB_NAME"
echo ""

# ─── Check if PostgreSQL is running ─────────────────────────────────
print_step "2/7" "التحقق من تشغيل PostgreSQL..."

if ! command -v psql >/dev/null 2>&1; then
  print_err "psql غير مُثبّت — ثبّت PostgreSQL client"
  print_info "Ubuntu/Debian: sudo apt install postgresql-client"
  print_info "CentOS/RHEL:   sudo dnf install postgresql"
  exit 1
fi

if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" >/dev/null 2>&1; then
  print_err "PostgreSQL لا يعمل على $DB_HOST:$DB_PORT"
  print_info "ابدأ الخدمة: sudo systemctl start postgresql"
  print_info "أو:           sudo service postgresql start"
  print_info "أو على macOS: brew services start postgresql"
  exit 1
fi

print_ok "PostgreSQL يعمل على $DB_HOST:$DB_PORT"
echo ""

# ─── Create PostgreSQL role if missing ──────────────────────────────
print_step "3/7" "إنشاء مستخدم PostgreSQL: $DB_USER..."

# We need to connect as the postgres superuser to create a role
# Try common methods:
PSQL_ADMIN=""
PSQL_ADMIN_ARGS=""

if sudo -n true 2>/dev/null; then
  # Has passwordless sudo
  PSQL_ADMIN="sudo -u postgres psql"
elif [[ "$(id -un)" == "postgres" ]]; then
  PSQL_ADMIN="psql"
elif psql -U postgres -c "SELECT 1" >/dev/null 2>&1; then
  PSQL_ADMIN="psql -U postgres"
else
  print_warn "لا يمكن الوصول لمستخدم postgres تلقائياً"
  echo ""
  echo -e "${BOLD}أدخل كلمة مرور postgres (أو اضغط Ctrl+C للإلغاء):${NC}"
  if PGPASSWORD_PROMPT=$(read -s -p "Password: " PGPASSWORD_POSTGRES; echo "$PGPASSWORD_POSTGRES"); then
    export PGPASSWORD="$PGPASSWORD_PROMPT"
    if psql -U postgres -h "$DB_HOST" -p "$DB_PORT" -c "SELECT 1" >/dev/null 2>&1; then
      PSQL_ADMIN="psql -U postgres -h $DB_HOST -p $DB_PORT"
    else
      print_err "فشل الاتصال بمستخدم postgres"
      print_info "حاول يدوياً:"
      echo "  sudo -u postgres psql -c \"CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';\""
      echo "  sudo -u postgres psql -c \"CREATE DATABASE $DB_NAME OWNER $DB_USER;\""
      echo "  sudo -u postgres psql -c \"GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;\""
      exit 1
    fi
  fi
fi

# Check if role already exists
ROLE_EXISTS=$($PSQL_ADMIN -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" 2>/dev/null || echo "")
if [[ "$ROLE_EXISTS" == "1" ]]; then
  print_ok "المستخدم $DB_USER موجود مسبقاً"
  # Reset password to match .env
  print_info "تحديث كلمة المرور لتتطابق مع .env..."
  $PSQL_ADMIN -c "ALTER USER \"$DB_USER\" WITH PASSWORD '$DB_PASS';" >/dev/null 2>&1 && \
    print_ok "تم تحديث كلمة المرور" || \
    print_warn "تعذّر تحديث كلمة المرور (ربما لا تملك الصلاحيات)"
else
  $PSQL_ADMIN -c "CREATE USER \"$DB_USER\" WITH PASSWORD '$DB_PASS' CREATEDB;" >/dev/null 2>&1 && \
    print_ok "تم إنشاء المستخدم $DB_USER" || \
    print_warn "تعذّر إنشاء المستخدم تلقائياً — أنشئه يدوياً: CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
fi
echo ""

# ─── Create database if missing ─────────────────────────────────────
print_step "4/7" "إنشاء قاعدة البيانات: $DB_NAME..."

DB_EXISTS=$($PSQL_ADMIN -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" 2>/dev/null || echo "")
if [[ "$DB_EXISTS" == "1" ]]; then
  print_ok "قاعدة البيانات $DB_NAME موجودة مسبقاً"
else
  $PSQL_ADMIN -c "CREATE DATABASE \"$DB_NAME\" OWNER \"$DB_USER\";" >/dev/null 2>&1 && \
    print_ok "تم إنشاء قاعدة البيانات $DB_NAME" || \
    print_warn "تعذّر إنشاء قاعدة البيانات تلقائياً"
fi

# Grant privileges
$PSQL_ADMIN -c "GRANT ALL PRIVILEGES ON DATABASE \"$DB_NAME\" TO \"$DB_USER\";" >/dev/null 2>&1 && \
  print_ok "تم منح الصلاحيات" || \
  print_warn "تعذّر منح الصلاحيات"
echo ""

# ─── Test connection ────────────────────────────────────────────────
print_step "5/7" "اختبار الاتصال بقاعدة البيانات..."

export PGPASSWORD="$DB_PASS"
if psql -U "$DB_USER" -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -c "SELECT current_user, current_database();" >/dev/null 2>&1; then
  print_ok "الاتصال ناجح بـ $DB_USER@$DB_HOST:$DB_PORT/$DB_NAME"
else
  print_err "فشل الاتصال حتى بعد الإعداد"
  print_info "تحقق من ملف pg_hba.conf — قد يحتاج تعديل للسماح بالاتصالات المحلية"
  print_info "أو أعد تشغيل PostgreSQL: sudo systemctl restart postgresql"
  exit 1
fi
echo ""

# ─── Quick mode? ────────────────────────────────────────────────────
if [[ "$1" == "--quick" ]]; then
  print_step "6/7" "(تخطّي Prisma بسبب --quick)"
  print_step "7/7" "(تخطّي Prisma بسبب --quick)"
  echo ""
  print_ok "اكتمل الإعداد الأساسي! شغّل يدوياً:"
  echo "  npx prisma db push"
  echo "  npx prisma generate"
  echo "  npm run db:seed"
  exit 0
fi

# ─── Prisma db push ─────────────────────────────────────────────────
print_step "6/7" "تطبيق Prisma schema على قاعدة البيانات..."

if npx prisma db push --accept-data-loss 2>&1 | tail -5; then
  print_ok "تم تطبيق الـ schema"
else
  print_err "فشل prisma db push"
  print_info "تحقق من رسالة الخطأ أعلاه — قد يكون هناك تعارض في الـ schema"
  exit 1
fi
echo ""

# ─── Prisma generate ────────────────────────────────────────────────
print_step "7/7" "توليد Prisma client..."

if npx prisma generate 2>&1 | tail -3; then
  print_ok "تم توليد Prisma client"
else
  print_err "فشل prisma generate"
  exit 1
fi
echo ""

# ─── Done ───────────────────────────────────────────────────────────
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✓ اكتمل إعداد قاعدة البيانات بنجاح${NC}"
echo -e "${GREEN}${BOLD}  ✓ Database setup completed successfully${NC}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BOLD}الخطوات التالية / Next steps:${NC}"
echo "  1. (اختياري) تشغيل seed:    npm run db:seed"
echo "  2. تشغيل التطبيق:           npm run dev"
echo ""
echo -e "${BOLD}لإنشاء حساب مدير:${NC}"
echo "  npm run create-admin"
echo ""
