#!/bin/bash
# ============================================
# Seed Dictionary Terms - ميدان الاقتصاد
# سكريبت إدراج مصطلحات القاموس الاقتصادي
# ============================================
# 
# التشغيل على خادم الإنتاج:
#   cd ~/maydan && bash scripts/seed-dictionary.sh
#
# أو عبر Docker:
#   docker exec -it maydan-app bash scripts/seed-dictionary.sh

set -e

echo "📖 Maydan Economic Dictionary Seeder"
echo "====================================="
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
  echo "❌ Error: Run this script from the project root directory"
  echo "   cd ~/maydan && bash scripts/seed-dictionary.sh"
  exit 1
fi

# Run the seed script
echo "🚀 Running dictionary seed..."
npx tsx prisma/seed-dictionary.ts

echo ""
echo "✅ Dictionary seeding complete!"
echo "🌐 Visit https://midaniq.com/dictionary to see the results"
