/**
 * Migration script: Backfill publishedAt for existing articles.
 *
 * For articles with status='PUBLISHED' and publishedAt IS NULL,
 * set publishedAt = createdAt (best approximation for legacy data).
 *
 * Usage:
 *   npx tsx scripts/backfill-published-at.ts
 *
 * Or via raw SQL:
 *   UPDATE "Article" SET "publishedAt" = "createdAt"
 *   WHERE status = 'PUBLISHED' AND "publishedAt" IS NULL;
 */

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('Backfilling publishedAt for existing articles...')

  // Use raw SQL for accuracy — sets publishedAt = createdAt per row
  const result = await prisma.$executeRaw`
    UPDATE "Article"
    SET "publishedAt" = "createdAt"
    WHERE status = 'PUBLISHED' AND "publishedAt" IS NULL
  `

  console.log(`Updated ${result} articles: publishedAt = createdAt`)

  // Verify: count any remaining PUBLISHED articles without publishedAt
  const remaining = await prisma.article.count({
    where: { status: 'PUBLISHED', publishedAt: null },
  })

  if (remaining > 0) {
    console.warn(`Warning: ${remaining} PUBLISHED articles still have publishedAt = NULL`)
  } else {
    console.log('All PUBLISHED articles now have publishedAt set.')
  }

  await prisma.$disconnect()
}

main().catch((e) => {
  console.error('Migration failed:', e)
  process.exit(1)
})
