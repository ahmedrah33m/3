#!/bin/bash
# ============================================
# ميدان - سكربت إصلاح مشاكل HMR/Turbopack
# Maydan - HMR/Turbopack Fix Script
# ============================================
# يحل مشكلة: "Module factory is not available. It might have been deleted in an HMR update."
# Next.js 16.1.3 + Turbopack
#
# الاستخدام:
#   chmod +x scripts/fix-hmr.sh
#   ./scripts/fix-hmr.sh
# ============================================

set -e

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PARENT_DIR="$(dirname "$PROJECT_DIR")"

echo "═══════════════════════════════════════════"
echo "  ميدان - إصلاح مشاكل HMR/Turbopack"
echo "═══════════════════════════════════════════"
echo ""
echo "المسار: $PROJECT_DIR"

# 1. حذف كاش .next (السبب الأكثر شيوعاً لخطأ HMR)
echo ""
echo "【1/4】 تنظيف كاش .next ..."
if [ -d "$PROJECT_DIR/.next" ]; then
  rm -rf "$PROJECT_DIR/.next"
  echo "  ✓ تم حذف .next"
else
  echo "  - لا يوجد كاش .next"
fi

# 2. حذف ملفات package.json و package-lock.json من المجلد الأب
# هذا يمنع Turbopack من حل الوحدات من مسارين مختلفين
echo ""
echo "【2/4】 تنظيف تعارضات node_modules الأب ..."
PARENT_CONFLICT=0
if [ -f "$PARENT_DIR/package.json" ]; then
  rm -f "$PARENT_DIR/package.json"
  echo "  ✓ تم حذف $PARENT_DIR/package.json"
  PARENT_CONFLICT=1
fi
if [ -f "$PARENT_DIR/package-lock.json" ]; then
  rm -f "$PARENT_DIR/package-lock.json"
  echo "  ✓ تم حذف $PARENT_DIR/package-lock.json"
  PARENT_CONFLICT=1
fi
if [ -d "$PARENT_DIR/node_modules" ]; then
  # فقط نحذف node_modules إذا كان يحتوي على next (لتجنب حذف node_modules مهمة)
  if [ -d "$PARENT_DIR/node_modules/next" ]; then
    rm -rf "$PARENT_DIR/node_modules/next"
    echo "  ✓ تم حذف next من node_modules الأب (سبب تعارض HMR)"
    PARENT_CONFLICT=1
  fi
fi

if [ $PARENT_CONFLICT -eq 0 ]; then
  echo "  - لا توجد تعارضات"
fi

# 3. تنظيف كاش Turbopack المؤقت
echo ""
echo "【3/4】 تنظيف ملفات Turbopack المؤقتة ..."
rm -f "$PROJECT_DIR/.next-dev-cleanup" 2>/dev/null || true
# حذف ملفات TypeScript المؤقتة
rm -rf "$PROJECT_DIR/.tsbuildinfo" 2>/dev/null || true
echo "  ✓ تم التنظيف"

# 4. التحقق من DATABASE_URL
echo ""
echo "【4/4】 التحقق من DATABASE_URL ..."
if [ -f "$PROJECT_DIR/.env" ]; then
  DB_URL=$(grep "^DATABASE_URL=" "$PROJECT_DIR/.env" | head -1 | cut -d'=' -f2-)
  if echo "$DB_URL" | grep -q "^file:"; then
    echo "  ⚠ تحذير: DATABASE_URL يستخدم SQLite (file:...) بدلاً من PostgreSQL!"
    echo "  ⚠ يجب تغييره إلى: postgresql://maydan:PASSWORD@localhost:5432/maydan_db"
  elif echo "$DB_URL" | grep -q "^postgresql"; then
    echo "  ✓ DATABASE_URL يستخدم PostgreSQL (صحيح)"
  else
    echo "  ⚠ تحذير: DATABASE_URL غير متوقع: $DB_URL"
  fi
else
  echo "  ⚠ لا يوجد ملف .env"
fi

echo ""
echo "═══════════════════════════════════════════"
echo "  تم الانتهاء! شغّل الخادم الآن:"
echo ""
echo "  npm run dev:clean"
echo ""
echo "  أو يدوياً:"
echo "  cd $PROJECT_DIR && rm -rf .next && npm run dev"
echo "═══════════════════════════════════════════"
