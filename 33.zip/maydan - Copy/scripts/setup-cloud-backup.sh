#!/bin/bash
# ============================================
# سكريبت إعداد النسخ السحابي (S3 + FTP)
# Cloud Backup Setup Script
# ============================================
# يدعم:
#   - AWS S3
#   - MinIO خارجي (S3 متوافق)
#   - Wasabi (S3 متوافق - أرخص)
#   - Backblaze B2 (S3 متوافق)
#   - أي خدمة S3 متوافقة
#   - FTP/SFTP
# ============================================
# الاستخدام:
#   sudo bash scripts/setup-cloud-backup.sh
#   sudo bash scripts/setup-cloud-backup.sh --test
#   sudo bash scripts/setup-cloud-backup.sh --check
# ============================================

set -euo pipefail

# ============================================
# ألوان
# ============================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BACKUP_SCRIPT="$SCRIPT_DIR/backup.sh"
ENV_FILE="$PROJECT_DIR/.env.backup-cloud"

# ============================================
# دوال مساعدة
# ============================================
print_banner() {
    echo -e "\n${CYAN}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║   إعداد النسخ السحابي - ميدان الاقتصاد        ║${NC}"
    echo -e "${CYAN}║   Cloud Backup Setup                            ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}\n"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}هذا السكريبت يحتاج صلاحيات root${NC}"
        exit 1
    fi
}

# ============================================
# اختيار مزود السحابة
# ============================================
select_provider() {
    echo -e "${CYAN}اختر مزود التخزين السحابي:${NC}\n"
    echo "  1) AWS S3 (الأكثر شيوعاً)"
    echo "  2) Wasabi (أرخص - S3 متوافق)"
    echo "  3) MinIO خارجي (خادم خاص S3 متوافق)"
    echo "  4) Backblaze B2 (أرخص للنسخ الاحتياطي)"
    echo "  5) FTP/SFTP (خادم ملفات تقليدي)"
    echo "  6) تخطي (استخدام النسخ المحلي فقط)"
    echo ""
    echo -n "اختر رقم (1-6): "
    read -r provider_choice

    case "$provider_choice" in
        1) setup_aws_s3 ;;
        2) setup_wasabi ;;
        3) setup_minio_external ;;
        4) setup_backblaze ;;
        5) setup_ftp ;;
        6) echo -e "${YELLOW}تم التخطي - سيتم استخدام النسخ المحلي فقط${NC}" ;;
        *) echo -e "${RED}اختيار غير صالح${NC}"; exit 1 ;;
    esac
}

# ============================================
# إعداد AWS S3
# ============================================
setup_aws_s3() {
    echo -e "\n${GREEN}إعداد AWS S3...${NC}\n"

    echo -e "${YELLOW}أدخل AWS Access Key ID:${NC}"
    read -r aws_key
    echo -e "${YELLOW}أدخل AWS Secret Access Key:${NC}"
    read -rs aws_secret
    echo ""
    echo -e "${YELLOW}أدخل اسم الـ Bucket (مثال: maydan-backups):${NC}"
    read -r s3_bucket
    echo -e "${YELLOW}أدخل المنطقة (مثال: us-east-1, eu-west-1):${NC}"
    read -r s3_region

    # تثبيت AWS CLI إن لم يكن مثبتاً
    if ! command -v aws &> /dev/null; then
        echo -e "${BLUE}تثبيت AWS CLI...${NC}"
        apt-get update -qq && apt-get install -y -qq awscli 2>/dev/null || \
        pip3 install awscli 2>/dev/null || {
            echo -e "${RED}فشل تثبيت AWS CLI!${NC}"
            return 1
        }
    fi

    # تكوين AWS CLI
    aws configure set aws_access_key_id "$aws_key"
    aws configure set aws_secret_access_key "$aws_secret"
    aws configure set default.region "$s3_region"

    # إنشاء bucket إن لم يكن موجوداً
    if ! aws s3 ls "s3://$s3_bucket" 2>/dev/null; then
        echo -e "${BLUE}إنشاء bucket: $s3_bucket${NC}"
        if [[ "$s3_region" == "us-east-1" ]]; then
            aws s3 mb "s3://$s3_bucket" 2>/dev/null || true
        else
            aws s3 mb "s3://$s3_bucket" --region "$s3_region" 2>/dev/null || true
        fi
    fi

    # تفعيل التشفير على Bucket
    aws s3api put-bucket-encryption \
        --bucket "$s3_bucket" \
        --server-side-encryption-configuration '{
            "Rules": [{
                "ApplyServerSideEncryptionByDefault": {
                    "SSEAlgorithm": "AES256"
                }
            }]
        }' 2>/dev/null || true

    # تفعيل إصدارات الكائنات (Versioning)
    aws s3api put-bucket-versioning \
        --bucket "$s3_bucket" \
        --versioning-configuration Status=Enabled 2>/dev/null || true

    # حفظ الإعدادات
    save_config "S3" "$s3_bucket" "$s3_region" "$aws_key" "$aws_secret" ""

    # اختبار الاتصال
    test_s3_connection "$s3_bucket" "" "$s3_region"
}

# ============================================
# إعداد Wasabi
# ============================================
setup_wasabi() {
    echo -e "\n${GREEN}إعداد Wasabi (S3 متوافق - أرخص)...${NC}\n"

    echo -e "${YELLOW}أدخل Wasabi Access Key:${NC}"
    read -r wasabi_key
    echo -e "${YELLOW}أدخل Wasabi Secret Key:${NC}"
    read -rs wasabi_secret
    echo ""
    echo -e "${YELLOW}أدخل اسم الـ Bucket:${NC}"
    read -r s3_bucket
    echo -e "${YELLOW}أدخل منطقة Wasabi (مثال: us-east-1, eu-central-1):${NC}"
    read -r s3_region

    local endpoint="https://s3.${s3_region}.wasabisys.com"

    # تثبيت AWS CLI
    if ! command -v aws &> /dev/null; then
        apt-get update -qq && apt-get install -y -qq awscli 2>/dev/null || \
        pip3 install awscli 2>/dev/null || true
    fi

    aws configure set aws_access_key_id "$wasabi_key"
    aws configure set aws_secret_access_key "$wasabi_secret"
    aws configure set default.region "$s3_region"

    save_config "S3" "$s3_bucket" "$s3_region" "$wasabi_key" "$wasabi_secret" "$endpoint"
    test_s3_connection "$s3_bucket" "$endpoint" "$s3_region"
}

# ============================================
# إعداد MinIO خارجي
# ============================================
setup_minio_external() {
    echo -e "\n${GREEN}إعداد MinIO خارجي...${NC}\n"

    echo -e "${YELLOW}أدخل عنوان خادم MinIO (مثال: https://minio.example.com):${NC}"
    read -r minio_url
    echo -e "${YELLOW}أدخل Access Key:${NC}"
    read -r minio_key
    echo -e "${YELLOW}أدخل Secret Key:${NC}"
    read -rs minio_secret
    echo ""
    echo -e "${YELLOW}أدخل اسم الـ Bucket:${NC}"
    read -r s3_bucket

    local endpoint="$minio_url"

    # تثبيت AWS CLI
    if ! command -v aws &> /dev/null; then
        apt-get update -qq && apt-get install -y -qq awscli 2>/dev/null || \
        pip3 install awscli 2>/dev/null || true
    fi

    aws configure set aws_access_key_id "$minio_key"
    aws configure set aws_secret_access_key "$minio_secret"
    aws configure set default.region "us-east-1"

    save_config "S3" "$s3_bucket" "us-east-1" "$minio_key" "$minio_secret" "$endpoint"
    test_s3_connection "$s3_bucket" "$endpoint" "us-east-1"
}

# ============================================
# إعداد Backblaze B2
# ============================================
setup_backblaze() {
    echo -e "\n${GREEN}إعداد Backblaze B2...${NC}\n"

    echo -e "${YELLOW}أدخل B2 Key ID:${NC}"
    read -r b2_key
    echo -e "${YELLOW}أدخل B2 Application Key:${NC}"
    read -rs b2_secret
    echo ""
    echo -e "${YELLOW}أدخل اسم الـ Bucket:${NC}"
    read -r s3_bucket

    local endpoint="https://s3.us-west-002.backblazeb2.com"

    if ! command -v aws &> /dev/null; then
        apt-get update -qq && apt-get install -y -qq awscli 2>/dev/null || \
        pip3 install awscli 2>/dev/null || true
    fi

    aws configure set aws_access_key_id "$b2_key"
    aws configure set aws_secret_access_key "$b2_secret"
    aws configure set default.region "us-west-002"

    save_config "S3" "$s3_bucket" "us-west-002" "$b2_key" "$b2_secret" "$endpoint"
    test_s3_connection "$s3_bucket" "$endpoint" "us-west-002"
}

# ============================================
# إعداد FTP
# ============================================
setup_ftp() {
    echo -e "\n${GREEN}إعداد FTP/SFTP...${NC}\n"

    echo -e "${YELLOW}أدخل عنوان خادم FTP:${NC}"
    read -r ftp_host
    echo -e "${YELLOW}أدخل اسم المستخدم:${NC}"
    read -r ftp_user
    echo -e "${YELLOW}أدخل كلمة المرور:${NC}"
    read -rs ftp_pass
    echo ""
    echo -e "${YELLOW}أدخل المسار البعيد (مثال: /backups):${NC}"
    read -r ftp_dir

    # تثبيت lftp
    if ! command -v lftp &> /dev/null; then
        echo -e "${BLUE}تثبيت lftp...${NC}"
        apt-get update -qq && apt-get install -y -qq lftp 2>/dev/null || true
    fi

    # حفظ الإعدادات
    cat > "$ENV_FILE" << FTPENV
# ============================================
# إعدادات النسخ السحابي عبر FTP
# Cloud Backup Configuration - FTP
# ============================================
FTP_UPLOAD_ENABLED=true
FTP_HOST=$ftp_host
FTP_USER=$ftp_user
FTP_PASS=$ftp_pass
FTP_REMOTE_DIR=$ftp_dir
CLOUD_UPLOAD_ENABLED=true
FTPENV

    # اختبار الاتصال
    test_ftp_connection "$ftp_host" "$ftp_user" "$ftp_pass" "$ftp_dir"

    echo -e "${GREEN}تم حفظ إعدادات FTP في: $ENV_FILE${NC}"
}

# ============================================
# حفظ الإعدادات
# ============================================
save_config() {
    local type="$1"
    local bucket="$2"
    local region="$3"
    local key="$4"
    local secret="$5"
    local endpoint="$6"

    cat > "$ENV_FILE" << S3ENV
# ============================================
# إعدادات النسخ السحابي - ميدان الاقتصاد
# Cloud Backup Configuration
# ============================================
# تم إنشاؤه تلقائياً بواسطة setup-cloud-backup.sh
# التاريخ: $(date '+%Y-%m-%d %H:%M:%S')
# ============================================

# تفعيل الرفع السحابي
CLOUD_UPLOAD_ENABLED=true

# إعدادات S3
S3_BUCKET=$bucket
S3_REGION=$region
AWS_ACCESS_KEY_ID=$key
AWS_SECRET_ACCESS_KEY=$secret
S3_ENDPOINT=$endpoint

# إعدادات FTP (معطلة - استخدم setup-cloud-backup.sh لتفعيلها)
FTP_UPLOAD_ENABLED=false
FTP_HOST=
FTP_USER=
FTP_PASS=
FTP_REMOTE_DIR=
S3ENV

    chmod 600 "$ENV_FILE"
    echo -e "${GREEN}تم حفظ الإعدادات في: $ENV_FILE${NC}"
    echo -e "${YELLOW}تنبيه: الملف محمي بصلاحيات 600 (الجذر فقط يمكنه القراءة)${NC}"
}

# ============================================
# اختبار اتصال S3
# ============================================
test_s3_connection() {
    local bucket="$1"
    local endpoint="$2"
    local region="$3"

    echo -e "\n${BLUE}اختبار الاتصال بـ S3...${NC}"

    local s3_cmd="aws s3 ls"
    if [[ -n "$endpoint" ]]; then
        s3_cmd="aws s3 ls --endpoint-url $endpoint"
    fi

    if $s3_cmd "s3://$bucket" 2>/dev/null; then
        echo -e "${GREEN}تم الاتصال بنجاح!${NC}"

        # رفع ملف اختبار
        local test_file="/tmp/maydan_cloud_test_$(date +%s).txt"
        echo "Maydan Cloud Backup Test - $(date)" > "$test_file"

        local cp_cmd="aws s3 cp"
        if [[ -n "$endpoint" ]]; then
            cp_cmd="aws s3 cp --endpoint-url $endpoint"
        fi

        if $cp_cmd "$test_file" "s3://$bucket/maydan-backups/test/" 2>/dev/null; then
            echo -e "${GREEN}تم رفع ملف اختبار بنجاح!${NC}"
            # حذف ملف الاختبار
            $cp_cmd "s3://$bucket/maydan-backups/test/" --recursive --exclude "*" --include "maydan_cloud_test_*" 2>/dev/null || true
        else
            echo -e "${YELLOW}تحذير: فشل رفع ملف الاختبار - تحقق من الصلاحيات${NC}"
        fi
        rm -f "$test_file"
    else
        echo -e "${RED}فشل الاتصال! تحقق من:${NC}"
        echo "  1. صحة Access Key و Secret Key"
        echo "  2. وجود الـ Bucket"
        echo "  3. صلاحيات الكتابة على الـ Bucket"
    fi
}

# ============================================
# اختبار اتصال FTP
# ============================================
test_ftp_connection() {
    local host="$1"
    local user="$2"
    local pass="$3"
    local dir="$4"

    echo -e "\n${BLUE}اختبار الاتصال بـ FTP...${NC}"

    if command -v lftp &> /dev/null; then
        if lftp -u "$user","$pass" "$host" -e "ls $dir; quit" 2>/dev/null; then
            echo -e "${GREEN}تم الاتصال بـ FTP بنجاح!${NC}"
        else
            echo -e "${YELLOW}تحذير: فشل الاتصال - تحقق من البيانات${NC}"
        fi
    else
        echo -e "${YELLOW}lftp غير مثبت - لا يمكن اختبار FTP${NC}"
    fi
}

# ============================================
# تحديث سكريبت النسخ بالإعدادات
# ============================================
update_backup_script() {
    if [[ -f "$ENV_FILE" ]]; then
        echo -e "${BLUE}تحديث سكريبت النسخ بالإعدادات السحابية...${NC}"

        # إضافة source للإعدادات في بداية backup.sh
        if ! grep -q "backup-cloud" "$BACKUP_SCRIPT" 2>/dev/null; then
            sed -i '1a\
# تحميل إعدادات النسخ السحابي\
if [[ -f "$(dirname "$0")/.env.backup-cloud" ]]; then\
    source "$(dirname "$0")/.env.backup-cloud"\
fi' "$BACKUP_SCRIPT"
        fi

        echo -e "${GREEN}تم التحديث${NC}"
    fi
}

# ============================================
# فحص حالة النسخ السحابي
# ============================================
check_cloud_status() {
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  حالة النسخ السحابي${NC}"
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}\n"

    if [[ -f "$ENV_FILE" ]]; then
        source "$ENV_FILE"
        echo -e "  الرفع السحابي: $([ "$CLOUD_UPLOAD_ENABLED" == "true" ] && echo "${GREEN}مفعّل${NC}" || echo "${RED}معطّل${NC}")"
        echo -e "  S3 Bucket: ${S3_BUCKET:-غير محدد}"
        echo -e "  S3 Region: ${S3_REGION:-غير محدد}"
        echo -e "  S3 Endpoint: ${S3_ENDPOINT:-افتراضي (AWS)}"
        echo -e "  FTP: $([ "$FTP_UPLOAD_ENABLED" == "true" ] && echo "${GREEN}مفعّل${NC}" || echo "معطّل")"
    else
        echo -e "  ${RED}لم يتم إعداد النسخ السحابي بعد${NC}"
        echo -e "  شغّل: sudo bash $0"
    fi

    # فحص آخر رفع سحابي
    local latest_cloud_log=$(ls -t /mnt/hdd/logs/backup_*.log 2>/dev/null | head -1)
    if [[ -n "$latest_cloud_log" ]]; then
        if grep -q "رفع السحابي" "$latest_cloud_log" 2>/dev/null; then
            echo -e "\n  آخر رفع سحابي:"
            grep -i "سحاب\|cloud\|s3\|ftp" "$latest_cloud_log" | tail -5
        fi
    fi
}

# ============================================
# التشغيل الرئيسي
# ============================================
main() {
    print_banner
    check_root

    case "${1:-}" in
        --test)
            echo -e "${YELLOW}اختبار النسخ السحابي...${NC}"
            CLOUD_UPLOAD_ENABLED=true "$BACKUP_SCRIPT" --all
            ;;
        --check)
            check_cloud_status
            ;;
        --reset)
            rm -f "$ENV_FILE"
            echo -e "${GREEN}تم إعادة تعيين إعدادات النسخ السحابي${NC}"
            ;;
        *)
            select_provider
            update_backup_script
            echo -e "\n${GREEN}تم إعداد النسخ السحابي بنجاح!${NC}"
            echo -e "${YELLOW}للاختبار: sudo bash $0 --test${NC}"
            echo -e "${YELLOW}للفحص: sudo bash $0 --check${NC}"
            ;;
    esac
}

main "$@"
