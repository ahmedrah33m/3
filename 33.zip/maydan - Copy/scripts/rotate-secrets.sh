#!/bin/bash
# ============================================================
# تدوير الأسرار وتنظيف git history
# Secrets Rotation & Git History Cleanup Guide
# ============================================================
#
# ⚠️  تنبيه حرج: هذا السكريبت يجب أن يُشغّل بحذر شديد.
#    اقرأ كل خطوة قبل التنفيذ. اعمل backup كامل قبل البدء.
#
# ============================================================

set -e  # توقف عند أي خطأ

echo "============================================================"
echo "🔒 تدوير الأسرار وتنظيف git history"
echo "============================================================"
echo ""

# ─── 1. النسخ الاحتياطي قبل البدء ────────────────────────────
echo "📦 [1/7] إنشاء نسخة احتياطية كاملة..."
echo "   إجراء backup قبل أي تعديل..."
# git bundle create ../midan9-backup-$(date +%Y%m%d).bundle --all
echo "   ✓ تم (علّق السطر أعلاه بعد المراجعة)"
echo ""

# ─── 2. توليد JWT_SECRET جديد ────────────────────────────────
echo "🔐 [2/7] توليد JWT_SECRET جديد..."
NEW_JWT_SECRET=$(openssl rand -base64 48)
echo "   JWT_SECRET الجديد: $NEW_JWT_SECRET"
echo "   ⚠️  احفظه في مكان آمن (password manager) ثم ضعه في .env"
echo ""

# ─── 3. توليد أسرار أخرى ─────────────────────────────────────
echo "🔑 [3/7] توليد أسرار أخرى..."
echo "   Redis password: $(openssl rand -base64 24)"
echo "   MinIO root password: $(openssl rand -base64 16)"
echo "   MinIO access key: midan$(openssl rand -hex 4)"
echo "   VAPID public key: (generate via web-push CLI)"
echo "   VAPID private key: (generate via web-push CLI)"
echo "   ⚠️  ضع كل واحد في .env المقابل"
echo ""

# ─── 4. قائمة الأسرار التي يجب تغييرها ───────────────────────
echo "🔄 [4/7] قائمة الأسرار التي يجب تغييرها يدوياً:"
echo ""
echo "   في .env:"
echo "   ├── JWT_SECRET              ← استخدم القيمة المولّدة أعلاه"
echo "   ├── DATABASE_URL            ← غيّر كلمة مرور PostgreSQL"
echo "   ├── REDIS_URL               ← غيّر كلمة مرور Redis"
echo "   ├── S3_ACCESS_KEY           ← غيّر مفتاح MinIO"
echo "   ├── S3_SECRET_KEY           ← غيّر سر MinIO"
echo "   ├── SMTP_PASSWORD           ← غيّر كلمة مرور SMTP"
echo "   ├── GOOGLE_CLIENT_SECRET    ← أعد إنشاء OAuth credentials في Google Cloud Console"
echo "   ├── CLOUDFLARE_TUNNEL_TOKEN ← أعد إنشاء tunnel في Cloudflare Zero Trust"
echo "   ├── MASTERCARD_API_KEY      ← أعد إنشاء في Mastercard Developer Portal"
echo "   ├── ZAINCASH_SECRET_KEY     ← تواصل مع ZainCash support"
echo "   ├── ALERT_TELEGRAM_BOT_TOKEN ← أنشئ bot جديد عبر @BotFather"
echo "   └── AWS_ACCESS_KEY_ID/SECRET ← أعد إنشاء IAM credentials في AWS Console"
echo ""
echo "   في Cloudflare Dashboard:"
echo "   ├── Tunnel token (في Zero Trust > Tunnels)"
echo "   └── API tokens (في My Profile > API Tokens)"
echo ""
echo "   في Google Cloud Console:"
echo "   ├── OAuth 2.0 Client ID + Secret"
echo "   └── Service Account keys (إن وجدت)"
echo ""

# ─── 5. تنظيف git history ────────────────────────────────────
echo "🧹 [5/7] تنظيف git history (يجب تثبيت BFG Repo-Cleaner)"
echo ""
echo "   # تثبيت BFG (إذا لم يكن مثبتاً):"
echo "   brew install bfg  # macOS"
echo "   # أو: скачать bfg.jar من https://rtyley.github.io/bfg-repo-cleaner/"
echo ""
echo "   # 1. استنساخ نسخة bare من المستودع:"
echo "   git clone --mirror https://github.com/ahmedrah33m/midan9.git midan9.git"
echo ""
echo "   # 2. إنشاء ملف secrets.txt يحتوي كل الأسرار المسروقة (كل سر في سطر):"
echo "   # ارجع لـ SECURITY-ALERT.md لقائمة كاملة بالأسرار المسروقة"
echo "   cat > secrets.txt << 'EOF'"
echo "   # ضع هنا كل سر مسروق (كلمات مرور، tokens، API keys)"
echo "   # مثال (استبدل بالقيم الفعلية من SECURITY-ALERT.md):"
echo "   # OLD_DB_PASSWORD_HERE"
echo "   # OLD_SMTP_PASSWORD_HERE"
echo "   # OLD_GOOGLE_OAUTH_SECRET_HERE"
echo "   # OLD_CLOUDFLARE_TUNNEL_TOKEN_HERE"
echo "   EOF"
echo ""
echo "   # 3. تشغيل BFG لحذف .env من history:"
echo "   java -jar bfg.jar --delete-files .env midan9.git"
echo "   java -jar bfg.jar --delete-files '*.env' midan9.git"
echo "   java -jar bfg.jar --replace-text passwords.txt midan9.git"
echo ""
echo "   # 4. تنظيف reflog و garbage collection:"
echo "   cd midan9.git"
echo "   git reflog expire --expire=now --all"
echo "   git gc --prune=now --aggressive"
echo ""
echo "   # 5. رفع النسخة المنظفة (force push):"
echo "   git push --force"
echo ""
echo "   ⚠️  تنبيه: هذا سيعيد كتابة history كامل. كل المساهمين يجب أن:"
echo "       1. يعيدوا استنساخ المستودع"
echo "       2. يعيدوا إعداد git remotes"
echo ""

# ─── 6. التحقق من عدم وجود أسرار متبقية ──────────────────────
echo "🔍 [6/7] فحص الأسرار المتبقية في الكود..."
echo ""
echo "   # استخدم git-secrets أو trufflehog:"
echo "   pip install trufflehog"
echo "   trufflehog https://github.com/ahmedrah33m/midan9.git"
echo ""
echo "   # أو استخدم grep للأنماط الشائعة:"
echo "   grep -rnE '(password|secret|api_key|token).{0,5}[=:].{0,5}[\"'\'']' src/ --include='*.ts' --include='*.tsx'"
echo "   # استخدم trufflehog للفحص الشامل:"
echo "   trufflehog https://github.com/ahmedrah33m/midan9.git"
echo ""

# ─── 7. خطوات ما بعد التنظيف ─────────────────────────────────
echo "✅ [7/7] خطوات ما بعد التنظيف:"
echo ""
echo "   1. حدّث كل .env في كل البيئات (dev, staging, production)"
echo "   2. أعد تشغيل كل الخدمات: docker-compose down && docker-compose up -d"
echo "   3. أعد إنشاء جلسات كل المستخدمين (سيُسجَّلون خروج تلقائياً):"
echo "      redis-cli FLUSHDB  # يمسح كل JWT blacklist + sessions"
echo "   4. راقب logs لأي محاولة استخدام أسرار قديمة"
echo "   5. أبلغ المستخدمين بأنه قد يُطلب منهم تسجيل دخول جديد"
echo ""

echo "============================================================"
echo "✅ اكتمل دليل تدوير الأسرار"
echo "============================================================"
echo ""
echo "📋 ملخص ما يجب عمله:"
echo "   1. اعمل backup كامل ✓"
echo "   2. ولّد JWT_SECRET جديد ✓"
echo "   3. غيّر كل الأسرار في .env والخدمات الخارجية"
echo "   4. نظّف git history بـ BFG"
echo "   5. افحص الأسرار المتبقية بـ trufflehog"
echo "   6. أعد تشغيل الخدمات"
echo "   7. أبلغ المستخدمين بإعادة تسجيل الدخول"
echo ""
echo "⚠️  بعد إكمال هذه الخطوات، اعتبر كل الأسرار القديمة منتهية الصلاحية."
