#!/usr/bin/env node
// Fix all broken string literals in feature files
// Handles multiple broken patterns from generate-features.js
const fs = require('fs')
const path = require('path')

const ROOT = path.resolve(__dirname, '..', 'src', 'lib', 'features')

function walk(dir) {
  const results = []
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) results.push(...walk(full))
    else if (entry.name.endsWith('.ts')) results.push(full)
  }
  return results
}

let totalFixed = 0
const filesFixed = []

// Patterns to fix:
// 1. `'text${...}` ` → `` `text${...}` `` (open ', close `) — already fixed in previous run
// 2. `` `text${...}' `` → `` `text${...}` `` (open `, close ')
// 3. `'text', ... ` → `'text', ...` (object property with mismatched end)
// 4. `status: `open'` → `status: 'open'`
// 5. `=== 'RESTRICTED` ` → `=== 'RESTRICTED'`

for (const file of walk(ROOT)) {
  const src = fs.readFileSync(file, 'utf8')
  let fixed = src
  let count = 0

  // Pattern A: `text...${...}' → `text...${...}` (backtick opening, single-quote closing)
  // Match: ` [non-quote non-newline]* ${...} [non-quote non-newline]* '
  // Replace final ' with `
  fixed = fixed.replace(/(`[^'`\n]*?\$\{[^}\n]*?\}[^'`\n]*?)'/g, (m, p1) => {
    count++
    return p1 + '`'
  })

  // Pattern B: `text' (without ${...}, plain backtick→single quote mismatch)
  // Match: `text' where text has no quotes — be careful
  // Only match if the backtick is preceded by specific patterns to avoid false positives
  // e.g., sensitivity === 'RESTRICTED` → sensitivity === 'RESTRICTED'
  fixed = fixed.replace(/===\s*'([^'`\n]+?)`/g, (m, p1) => {
    count++
    return `=== '${p1}'`
  })

  // Pattern C: status: `open' → status: 'open' (backtick open, single close, in object property)
  // Match: : `word' (word = alphanumeric)
  fixed = fixed.replace(/:\s*`([a-zA-Z_][a-zA-Z0-9_]*)'/g, (m, p1) => {
    count++
    return `: '${p1}'`
  })

  // Pattern D: hset('apikeys`, ... → hset(`apikeys`, ...
  // Single quote opening, backtick closing (no $) — but inside function call
  // Match: ('text` → (`text`
  fixed = fixed.replace(/\('([a-zA-Z_:][a-zA-Z0-9_:\-]*)`/g, (m, p1) => {
    count++
    return `(\`${p1}\``
  })

  // Pattern E: 'something` (end of line or before ,) → `something`
  // Single quote opening, backtick closing on its own (no $)
  // Match: 'word` , or 'word`)
  fixed = fixed.replace(/'([a-zA-Z_][a-zA-Z0-9_\-:]*?)`(\s*[,)])/g, (m, p1, p2) => {
    count++
    return `\`${p1}\`${p2}`
  })

  // Pattern F: `something' (end of line, plain) → `something`
  // Backtick opening, single quote closing (no $)
  // Match: `word' , or `word')
  fixed = fixed.replace(/`([a-zA-Z_][a-zA-Z0-9_\-:]*?)'(\s*[,)])/g, (m, p1, p2) => {
    count++
    return `\`${p1}\`${p2}`
  })

  // Pattern G: '/api/auth/sso/callback`) → `/api/auth/sso/callback`)
  // Single quote open, backtick close, in concatenation
  // Match: '/path` → `/path`
  fixed = fixed.replace(/'((?:\/|api\/|http)[a-zA-Z0-9_\-/:.]*)`/g, (m, p1) => {
    count++
    return `\`${p1}\``
  })

  // Pattern H: 'text\n' where text ends with backtick (multi-line broken)
  // Match: 'word\n` + ... → `word\n` + ...
  fixed = fixed.replace(/'([^'`\n]*?\\n)`/g, (m, p1) => {
    count++
    return `\`${p1}\``
  })

  if (count > 0) {
    fs.writeFileSync(file, fixed)
    filesFixed.push({ file: path.relative(process.cwd(), file), count })
    totalFixed += count
  }
}

console.log(`\n✅ Fixed ${totalFixed} additional broken string literals in ${filesFixed.length} files:`)
for (const { file, count } of filesFixed) {
  console.log(`  ${file}: ${count} fix(es)`)
}
