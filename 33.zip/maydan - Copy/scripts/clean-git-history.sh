#!/bin/bash
# ============================================================
# 🧹 تنظيف git history من الأسرار المسروقة
# Clean Git History from Leaked Secrets using BFG Repo-Cleaner
# ============================================================
#
# ⚠️  تنبيه حرج: هذا السكريبت يعيد كتابة git history!
#
#    قبل التشغيل:
#    1. اعمل backup كامل: git bundle create backup.bundle --all
#    2. أبلغ كل المساهمين — ستحتاج إعادة استنساخ المستودع
#    3. تأكد أنك تملك صلاحية force-push على GitHub
#
#    بعد التشغيل:
#    1. كل المساهمين يجب أن يعيدوا استنساخ المستودع
#    2. راقب GitHub Secret Scanning alerts
#    3. تأكد أن الأسرار القديمة تم تدويرها
#
# ============================================================

set -e  # توقف عند أي خطأ

# ألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info()  { echo -e "${BLUE}ℹ️  $1${NC}"; }
print_ok()    { echo -e "${GREEN}✅ $1${NC}"; }
print_warn()  { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }

# متغيرات
REPO_URL="${1:-https://github.com/ahmedrah33m/midan9.git}"
REPO_NAME="midan9"
MIRROR_DIR="${REPO_NAME}.git"
BFG_JAR="${BFG_JAR:-bfg.jar}"

echo "============================================================"
echo "🧹 تنظيف git history من الأسرار المسروقة"
echo "============================================================"
echo ""
print_info "المستودع: $REPO_URL"
print_info "مجلد الـ mirror: $MIRROR_DIR"
echo ""

# ─── 1. التحقق من المتطلبات ──────────────────────────────────
print_info "1️⃣  التحقق من المتطلبات..."

# فحص Java
if ! command -v java &> /dev/null; then
    print_error "Java غير مثبت. ثبته أولاً:"
    echo "  Ubuntu/Debian: sudo apt install default-jre"
    echo "  macOS: brew install openjdk"
    exit 1
fi
print_ok "Java مثبت: $(java -version 2>&1 | head -1)"

# فحص BFG
if [ ! -f "$BFG_JAR" ]; then
    print_warn "BFG غير موجود. جاري التحميل..."
    curl -L -o "$BFG_JAR" "https://repo1.maven.org/maven2/com/madgag/bfg/1.14.0/bfg-1.14.0.jar"
    if [ ! -f "$BFG_JAR" ]; then
        print_error "فشل تحميل BFG. نزّله يدوياً من:"
        echo "  https://rtyley.github.io/bfg-repo-cleaner/"
        exit 1
    fi
    print_ok "BFG تم تحميله: $BFG_JAR"
else
    print_ok "BFG موجود: $BFG_JAR"
fi

# فحص git
if ! command -v git &> /dev/null; then
    print_error "git غير مثبت!"
    exit 1
fi
print_ok "git مثبت: $(git --version)"

echo ""

# ─── 2. التحذير والطلب تأكيد ─────────────────────────────────
echo "============================================================"
print_warn "⚠️  تحذير حرج!"
echo "============================================================"
echo ""
echo "هذا السكريبت سوف:"
echo "  1. يستنسخ نسخة bare من المستودع"
echo "  2. يحذف ملفات .env و RAR من git history بالكامل"
echo "  3. يستبدل كل الأسرار المسروقة بـ ***REMOVED***"
echo "  4. ينظف reflog و garbage collection"
echo "  5. يعمل force push إلى GitHub"
echo ""
echo "النتائج:"
echo "  • كل git history سيتغير (commit hashes جديدة)"
echo "  • كل المساهمين يجب إعادة استنساخ المستودع"
echo "  • لن يمكن استرجاع الـ history القديم"
echo ""
echo "قبل المتابعة، تأكد من:"
echo "  ✓ عمل backup: git bundle create backup.bundle --all"
echo "  ✓ تدوير كل الأسرار المسروقة (راجع SECURITY-ALERT.md)"
echo "  ✓ إعلام كل المساهمين"
echo "  ✓ صلاحية force-push على GitHub"
echo ""
read -p "هل تريد المتابعة؟ اكتب YES للمتابعة: " CONFIRM

if [ "$CONFIRM" != "YES" ]; then
    print_warn "تم الإلغاء."
    exit 0
fi

echo ""
print_ok "تم التأكيد. بدء التنظيف..."
echo ""

# ─── 3. إنشاء ملف الأسرار للاستبدال ──────────────────────────
print_info "2️⃣  إنشاء ملف الأسرار للاستبدال..."

SECRETS_FILE="secrets-to-replace.txt"
cat > "$SECRETS_FILE" << 'EOF'
# ضع هنا كل سر مسروق كامل (كل سر في سطر)
# القيم المنزوعة في SECURITY-ALERT.md للتوضيح فقط
# استخرج القيم الكاملة من git history القديم إن لزم

# كلمة مرور DB المسروقة (كاملة — استبدل بالقيمة الفعلية)
# OLD_DB_PASSWORD_FULL

# كلمة مرور SMTP Zoho المسروقة (كاملة)
# OLD_SMTP_PASSWORD_FULL

# Google OAuth Client ID المسروق (كامل)
# OLD_GOOGLE_OAUTH_CLIENT_ID_FULL

# Google OAuth Client Secret المسروق (كامل)
# OLD_GOOGLE_OAUTH_CLIENT_SECRET_FULL

# Cloudflare Tunnel Token المسروق (كامل)
# OLD_CLOUDFLARE_TUNNEL_TOKEN_FULL
EOF

print_ok "ملف الأسرار جاهز: $SECRETS_FILE"
echo "   (عدّله لإضافة أي أسرار أخرى قبل المتابعة)"
echo ""
read -p "هل ملف الأسرار جاهز؟ اكتب YES للمتابعة: " CONFIRM2
if [ "$CONFIRM2" != "YES" ]; then
    print_warn "تم الإلغاء. عدّل $SECRETS_FILE ثم أعد التشغيل."
    exit 0
fi

# ─── 4. استنساخ bare mirror ──────────────────────────────────
print_info "3️⃣  استنساخ bare mirror من GitHub..."

if [ -d "$MIRROR_DIR" ]; then
    print_warn "المجلد $MIRROR_DIR موجود. سيتم حذفه."
    rm -rf "$MIRROR_DIR"
fi

git clone --mirror "$REPO_URL" "$MIRROR_DIR"
print_ok "تم استنساخ الـ mirror"
echo ""

# ─── 5. تشغيل BFG ────────────────────────────────────────────
print_info "4️⃣  تشغيل BFG Repo-Cleaner..."

cd "$MIRROR_DIR"

# حذف ملفات .env من history
print_info "حذف ملفات .env من history..."
java -jar "../$BFG_JAR" --delete-files ".env" --no-blob-protection

# حذف أرشيف RAR من history
print_info "حذف أرشيف RAR من history..."
java -jar "../$BFG_JAR" --delete-files "*.rar" --no-blob-protection

# استبدال الأسرار بـ ***REMOVED***
print_info "استبدال الأسرار المسروقة..."
java -jar "../$BFG_JAR" --replace-text "../$SECRETS_FILE" --no-blob-protection

print_ok "BFG انتهى"
echo ""

# ─── 6. تنظيف reflog و gc ────────────────────────────────────
print_info "5️⃣  تنظيف reflog و garbage collection..."

git reflog expire --expire=now --all
git gc --prune=now --aggressive

print_ok "تم التنظيف"
echo ""

# ─── 7. عرض تقرير ────────────────────────────────────────────
print_info "6️⃣  تقرير ما تم تنظيفه..."
echo ""
echo "============================================================"
echo "📊 تقرير BFG:"
echo "============================================================"
ls -la .git/bfg-report/ 2>/dev/null || echo "(التقرير في ../bfg-report/)"
echo ""
echo "✅ تم تنظيف:"
echo "  • ملفات .env من كل git history"
echo "  • أرشيفات .rar من كل git history"
echo "  • كل الأسرار في secrets-to-replace.txt استُبدلت بـ ***REMOVED***"
echo ""

# ─── 8. force push ───────────────────────────────────────────
print_info "7️⃣  رفع الـ history المنظف (force push)..."
echo ""
print_warn "⚠️  هذا سيعيد كتابة history على GitHub!"
echo "   كل المساهمين سيحتاجون إعادة استنساخ المستودع."
echo ""
read -p "هل تريد force push؟ اكتب PUSH للمتابعة: " CONFIRM3

if [ "$CONFIRM3" == "PUSH" ]; then
    git push --force
    print_ok "✅ تم رفع الـ history المنظف!"
    echo ""
    echo "============================================================"
    print_ok "🎉 اكتمل تنظيف git history!"
    echo "============================================================"
    echo ""
    echo "الخطوات التالية:"
    echo "  1. أبلغ كل المساهمين بإعادة استنساخ المستودع"
    echo "  2. تحقق من GitHub Secret Scanning alerts"
    echo "  3. تأكد أن كل الأسرار تم تدويرها (راجع NEW-SECRETS.txt)"
    echo "  4. احذف ملفات التنظيف المحلية:"
    echo "     cd .. && rm -rf $MIRROR_DIR $BFG_JAR $SECRETS_FILE"
    echo ""
else
    print_warn "تم الإلغاء. الـ mirror المنظف موجود في $MIRROR_DIR"
    echo "   لرفعه يدوياً: cd $MIRROR_DIR && git push --force"
fi

# ─── 9. تنظيف ────────────────────────────────────────────────
cd ..
echo ""
print_info "تنظيف الملفات المؤقتة..."
rm -f "$SECRETS_FILE"
print_ok "تم حذف $SECRETS_FILE"
echo ""
echo "ملاحظة: الـ mirror موجود في $MIRROR_DIR — احذفه يدوياً بعد التحقق:"
echo "  rm -rf $MIRROR_DIR"
