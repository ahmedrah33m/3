#!/bin/bash
# ============================================
# سكريبت إعداد الجدولة الزمنية للنسخ الاحتياطي (RPO)
# Backup Schedule Setup - Recovery Point Objective
# ============================================
# يقوم بإعداد cron jobs لضمان:
#   - نسخة كل ساعة (فقدان أقصى 1 ساعة من البيانات)
#   - نسخة يومية كاملة (فقدان أقصى 1 يوم من الملفات)
#   - رفع أسبوعي للسحابة (حماية من تلف السيرفر)
# ============================================
# الاستخدام:
#   bash scripts/setup-backup-cron.sh              # إعداد الجدولة
#   bash scripts/setup-backup-cron.sh --status     # عرض الجدول الحالي
#   bash scripts/setup-backup-cron.sh --remove     # إزالة الجدول
#   bash scripts/setup-backup-cron.sh --test       # اختبار نسخة
# ============================================

set -uo pipefail

# ============================================
# ألوان
# ============================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BACKUP_SCRIPT="$SCRIPT_DIR/backup.sh"

# كشف البيئة
ENV_MODE="local"
if command -v docker &>/dev/null && docker ps &>/dev/null 2>&1; then
    if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "maydan-postgres"; then
        ENV_MODE="docker"
    fi
fi

# تحديد مسارات السجلات حسب البيئة والصلاحيات
if [[ "$ENV_MODE" == "docker" && -d "/mnt/hdd/logs" && -w "/mnt/hdd/logs" ]]; then
    LOG_DIR="/mnt/hdd/logs"
else
    LOG_DIR="$PROJECT_DIR/backups/logs"
fi
mkdir -p "$LOG_DIR" 2>/dev/null || LOG_DIR="/tmp/maydan-cron-logs"

# ============================================
# دوال مساعدة
# ============================================
print_banner() {
    echo -e "\n${CYAN}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║   إعداد جدولة النسخ الاحتياطي - RPO            ║${NC}"
    echo -e "${CYAN}║   Backup Schedule - Recovery Point Objective    ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}\n"
}

# ============================================
# عرض الجدول الحالي
# ============================================
show_status() {
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  جدول النسخ الاحتياطي الحالي${NC}"
    echo -e "${CYAN}══════════════════════════════════════════════════${NC}\n"

    local current_cron=$(crontab -l 2>/dev/null || echo "فارغ")
    echo -e "${YELLOW}Cron Jobs:${NC}"
    echo "$current_cron"
    echo ""

    # عرض حالة آخر نسخة
    echo -e "${YELLOW}آخر نسخة احتياطية:${NC}"
    local latest_log=$(ls -t "$LOG_DIR"/backup_*.log 2>/dev/null | head -1)
    if [[ -n "$latest_log" ]]; then
        echo "  السجل: $latest_log"
        tail -5 "$latest_log" 2>/dev/null || true
    else
        echo "  لا توجد سجلات نسخ احتياطي بعد"
    fi

    echo ""
    echo -e "${YELLOW}مساحة النسخ الاحتياطي:${NC}"
    if [[ "$ENV_MODE" == "docker" && -d "/mnt/hdd/backups" ]]; then
        du -sh /mnt/hdd/backups/* 2>/dev/null || echo "  مجلد النسخ فارغ"
    else
        du -sh "$PROJECT_DIR/backups"/* 2>/dev/null || echo "  مجلد النسخ فارغ"
    fi

    echo ""
    echo -e "${YELLOW}جدول RPO المتوقع:${NC}"
    echo "  ┌──────────────┬────────────┬────────────────────────────┐"
    echo "  │ المستوى      │ التكرار    │ أقصى فقدان بيانات         │"
    echo "  ├──────────────┼────────────┼────────────────────────────┤"
    echo "  │ كل ساعة      │ كل 1 ساعة  │ ساعة واحدة من قاعدة البيانات│"
    echo "  │ يومي         │ كل يوم 3AM │ يوم واحد من الملفات       │"
    echo "  │ أسبوعي       │ كل أحد     │ أسبوع (مع رفع سحابي)      │"
    echo "  │ شهري         │ أول الشهر  │ شهر (نسخة كاملة)          │"
    echo "  └──────────────┴────────────┴────────────────────────────┘"
}

# ============================================
# إعداد الجدولة
# ============================================
setup_cron() {
    echo -e "${GREEN}بدء إعداد جدولة النسخ الاحتياطي...${NC}\n"

    # التحقق من وجود سكريبت النسخ
    if [[ ! -f "$BACKUP_SCRIPT" ]]; then
        echo -e "${RED}سكريبت النسخ غير موجود: $BACKUP_SCRIPT${NC}"
        exit 1
    fi
    chmod +x "$BACKUP_SCRIPT"

    # إنشاء مجلد السجلات
    mkdir -p "$LOG_DIR"

    # إزالة أي جدولة سابقة لمشروع ميدان
    echo -e "${BLUE}إزالة الجدولة السابقة...${NC}"
    crontab -l 2>/dev/null | grep -v "maydan\|backup.sh\|restore.sh" | { cat; } > /tmp/maydan_cron_tmp || true

    # إضافة الجدولة الجديدة - استخدام المسار الديناميكي للمشروع
    echo -e "${BLUE}إضافة جدولة جديدة...${NC}\n"

    cat >> /tmp/maydan_cron_tmp << CRON

# ============================================
# ميدان الاقتصاد - جدولة النسخ الاحتياطي (RPO)
# Maydan Al-Iqtisad - Backup Schedule
# ============================================

# ┌───────────── كل ساعة ─────────────┐
# نسخ PostgreSQL + Redis كل ساعة
# أقصى فقدان: 1 ساعة من البيانات
0 * * * * $BACKUP_SCRIPT --db-only --redis >> $LOG_DIR/backup_hourly.log 2>&1

# ┌───────────── يومي ─────────────┐
# نسخة كاملة يومياً الساعة 3:00 صباحاً
# تشمل: قاعدة بيانات + ملفات مرفوعة + Redis
# أقصى فقدان: 1 يوم من الملفات المرفوعة
0 3 * * * $BACKUP_SCRIPT >> $LOG_DIR/backup_daily.log 2>&1

# ┌───────────── أسبوعي ─────────────┐
# نسخة كاملة + رفع سحابي كل أحد الساعة 4:00 صباحاً
# أقصى فقدان: أسبوع (مع نسخة سحابية احتياطية)
0 4 * * 0 $BACKUP_SCRIPT --all >> $LOG_DIR/backup_weekly.log 2>&1

# ┌───────────── شهري ─────────────┐
# نسخة كاملة + رفع سحابي أول كل شهر الساعة 5:00 صباحاً
0 5 1 * * $BACKUP_SCRIPT --all >> $LOG_DIR/backup_monthly.log 2>&1

# ┌───────────── صيانة ─────────────┐
# تنظيف السجلات القديمة أسبوعياً
0 2 * * 1 find $LOG_DIR -name "backup_*.log" -mtime +30 -delete 2>/dev/null

# فحص صحة النسخ الاحتياطي يومياً
0 6 * * * test -f $PROJECT_DIR/backups/postgresql/daily/maydan_db_\$(date +\%Y\%m\%d)*.sql.gz || echo "ALERT: No daily backup found for today!" >> $LOG_DIR/backup_health.log 2>&1
CRON

    # تثبيت الجدولة الجديدة
    crontab /tmp/maydan_cron_tmp
    rm -f /tmp/maydan_cron_tmp

    echo -e "${GREEN}تم إعداد الجدولة بنجاح!${NC}\n"

    # عرض الجدول المثبت
    echo -e "${CYAN}الجدول المثبت:${NC}"
    crontab -l | grep -v "^$" | grep -v "^#"

    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  تم إعداد نظام نقاط الاسترداد (RPO) بنجاح!     ║${NC}"
    echo -e "${GREEN}╠══════════════════════════════════════════════════╣${NC}"
    echo -e "${GREEN}║  كل ساعة:  PostgreSQL + Redis                   ║${NC}"
    echo -e "${GREEN}║  يومياً:   نسخة كاملة (3:00 صباحاً)            ║${NC}"
    echo -e "${GREEN}║  أسبوعياً: نسخة + رفع سحابي (أحد 4:00 صباحاً) ║${NC}"
    echo -e "${GREEN}║  شهرياً:   نسخة + رفع سحابي (1 الشهر 5:00 صباحاً)║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"

    echo ""
    echo -e "${YELLOW}لتفعيل الرفع السحابي، عدّل المتغيرات في .env:${NC}"
    echo "  CLOUD_UPLOAD_ENABLED=true"
    echo "  S3_BUCKET=your-bucket-name"
    echo "  AWS_ACCESS_KEY_ID=your-key"
    echo "  AWS_SECRET_ACCESS_KEY=your-secret"
    echo ""
    echo -e "${YELLOW}لاختبار النسخ الاحتياطي فوراً:${NC}"
    echo "  bash $BACKUP_SCRIPT"
}

# ============================================
# إزالة الجدولة
# ============================================
remove_cron() {
    echo -e "${YELLOW}إزالة جدولة النسخ الاحتياطي...${NC}"
    crontab -l 2>/dev/null | grep -v "maydan\|backup.sh\|restore.sh" | { cat; } > /tmp/maydan_cron_tmp || true
    crontab /tmp/maydan_cron_tmp
    rm -f /tmp/maydan_cron_tmp
    echo -e "${GREEN}تم إزالة الجدولة${NC}"
}

# ============================================
# التشغيل الرئيسي
# ============================================
main() {
    print_banner

    case "${1:-}" in
        --status)
            show_status
            ;;
        --remove)
            remove_cron
            ;;
        --test)
            echo -e "${YELLOW}تشغيل نسخة احتياطية تجريبية...${NC}"
            "$BACKUP_SCRIPT"
            ;;
        *)
            setup_cron
            ;;
    esac
}

main "$@"
