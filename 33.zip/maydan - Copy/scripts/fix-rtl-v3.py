#!/usr/bin/env python3
"""
RTL Fix v3 — For files where dir={dir} is in a function without hook access,
simply remove dir={dir} entirely. The <html> tag already sets the correct dir,
and all components render within that tree (portals inherit from body/html).
"""
import os

BASE = "/home/z/my-project/midan6/src"

FILES = [
    "components/DiscussionsPage.tsx",
    "components/Recommendations.tsx",
    "components/WorldEconomicMap.tsx",
    "components/admin/AdminCharts.tsx",
    "components/admin/DataExport.tsx",
    "components/economic/EconomicDashboardWidget.tsx",
    "components/economic/ISXTicker.tsx",
    "components/economic/InflationCalculator.tsx",
    "components/profile/ProfileDialogs.tsx",
    "components/profile/Recommendations.tsx",
    "components/security/ApiKeyManager.tsx",
    "components/security/SecurityDashboard.tsx",
    "components/security/SessionManager.tsx",
    "components/security/TrustedDevices.tsx",
    "components/social/MentorshipView.tsx",
    "components/MobileNavDrawer.tsx",
]

count = 0
for f in FILES:
    path = os.path.join(BASE, f)
    if not os.path.exists(path):
        continue
    
    with open(path, "r") as fh:
        content = fh.read()
    
    original = content
    
    # Remove dir={dir} — let it inherit from <html>
    # Also remove dir="rtl" if any remain
    content = content.replace(' dir={dir}', '')
    content = content.replace(' dir="rtl"', '')
    
    # For MobileNavDrawer, also fix isRTL — it needs to use useI18n properly
    if "MobileNavDrawer" in f:
        # The side prop uses isRTL which should be from useI18n
        # Check if isRTL is available
        if 'isRTL' in content and 'const {' in content:
            # Find the useI18n destructuring and ensure isRTL is there
            import re
            # Check if there's a destructuring that should have isRTL
            if 'isRTL' not in content.split('useI18n')[1].split(')')[0] if 'useI18n' in content else True:
                # Add isRTL to the destructuring
                def add_isrtl(m):
                    if 'isRTL' in m.group(1):
                        return m.group(0)
                    items = [x.strip() for x in m.group(1).split(',')]
                    if 'dir' not in items:
                        items.append('dir')
                    items.append('isRTL')
                    return f'const {{ {", ".join(items)} }} = useI18n()'
                
                content = re.sub(
                    r'const\s*\{([^}]+)\}\s*=\s*useI18n\(\)',
                    add_isrtl,
                    content
                )
    
    if content != original:
        with open(path, "w") as fh:
            fh.write(content)
        count += 1
        print(f"  ✓ {os.path.basename(f)}: Removed dir attr (inherits from <html>)")

print(f"\nFixed {count} files")