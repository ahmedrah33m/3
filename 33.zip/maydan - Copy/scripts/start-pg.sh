#!/bin/bash
# ============================================
# Start PostgreSQL Server (User-Space)
# تشغيل خادم PostgreSQL (مساحة المستخدم)
# ============================================

PG_BIN=/home/z/my-project/db/pg/install/usr/lib/postgresql/17/bin
PG_DATA=/home/z/my-project/db/pgdata

# Check if PostgreSQL is already running
if $PG_BIN/pg_isready -h $PG_DATA/run -p 5432 &>/dev/null; then
    echo "✅ PostgreSQL يعمل بالفعل"
    exit 0
fi

echo "🚀 تشغيل PostgreSQL..."

# Start PostgreSQL
$PG_BIN/pg_ctl -D $PG_DATA -l $PG_DATA/logfile start

# Wait for it to be ready
for i in {1..10}; do
    if $PG_BIN/pg_isready -h $PG_DATA/run -p 5432 &>/dev/null; then
        echo "✅ PostgreSQL يعمل بنجاح!"
        echo "   الاتصال: postgresql://maydan:maydan_secure_password@127.0.0.1:5432/maydan_db"
        exit 0
    fi
    sleep 1
done

echo "❌ فشل تشغيل PostgreSQL. تحقق من: $PG_DATA/logfile"
exit 1
