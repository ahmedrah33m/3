/* eslint-disable no-console */
// Standalone image migration runner (server-side).
// Scans public/uploads, generates responsive WebP variants for legacy images,
// records metadata in the Image table. Resumable (skips already-processed rows).
//
// Run on the server (after deploy + prisma db push + prisma generate):
//   npx tsx scripts/run-migration.ts [limitPerBatch] [startIndex]
import 'dotenv/config'
import { readdir, readFile, stat } from 'fs/promises'
import path from 'path'
import { PrismaClient } from '@prisma/client'
import {
  getStorage,
  UPLOAD_CONFIGS,
  type UploadType,
} from '../src/lib/storage'

const UPLOAD_BASE = 'public/uploads'
const IMAGE_EXTS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif'])
const SKIP_FOLDERS = new Set(['videos', 'video'])

const FOLDER_TO_TYPE: Record<string, UploadType> = {
  article: 'article',
  articles: 'article',
  avatar: 'avatar',
  avatars: 'avatar',
  cover: 'cover',
  covers: 'cover',
  post: 'post',
  posts: 'post',
  research: 'research',
  job: 'job',
  jobs: 'job',
  general: 'general',
  certificate: 'certificate',
  certificates: 'certificate',
  cv: 'cv',
}

function detectFormatFromBuffer(buffer: Buffer): string | null {
  if (buffer.length < 12) return null
  if (buffer[0] === 0x52 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x46 && buffer[8] === 0x57) return 'webp'
  if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47) return 'png'
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpeg'
  if (buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46) return 'gif'
  if (buffer[4] === 0x66 && buffer[5] === 0x74 && buffer[6] === 0x79 && buffer[7] === 0x70 && buffer[8] === 0x61) return 'avif'
  const header = buffer.subarray(0, 100).toString('utf8').trim()
  if (header.startsWith('<?xml') || header.startsWith('<svg')) return 'svg'
  return null
}

async function walkDir(dir: string): Promise<string[]> {
  const results: string[] = []
  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return results
  }
  for (const entry of entries) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) results.push(...(await walkDir(full)))
    else if (entry.isFile()) results.push(full)
  }
  return results
}

async function collectCandidates(uploadDir: string): Promise<{ relative: string; filePath: string }[]> {
  const all = await walkDir(uploadDir)
  const candidates: { relative: string; filePath: string }[] = []
  for (const filePath of all) {
    const relative = path.relative(uploadDir, filePath).replace(/\\/g, '/')
    const folder = relative.split('/')[0]
    if (SKIP_FOLDERS.has(folder)) continue
    const ext = path.extname(filePath).toLowerCase()
    if (!IMAGE_EXTS.has(ext)) continue
    candidates.push({ relative, filePath })
  }
  return candidates.sort((a, b) => a.relative.localeCompare(b.relative))
}

async function main() {
  const limit = Math.max(1, parseInt(process.argv[2] || '50', 10) || 50)
  const startIndex = Math.max(0, parseInt(process.argv[3] || '0', 10) || 0)

  const db = new PrismaClient()
  const uploadDir = process.env.UPLOAD_DIR || path.join(process.cwd(), UPLOAD_BASE)
  const candidates = await collectCandidates(uploadDir)

  console.log(`[Migrate] ${candidates.length} image files in ${uploadDir}`)
  if (candidates.length === 0) {
    console.log('[Migrate] Nothing to do.')
    await db.$disconnect()
    process.exit(0)
  }

  const storage = getStorage()
  const imageProcessor = storage.getImageProcessor()

  let processed = 0
  let skipped = 0
  let errors = 0
  let savedBytesTotal = 0
  let nextOffset = startIndex

  for (let i = startIndex; i < candidates.length; i++) {
    if (processed >= limit) break
    const { relative, filePath } = candidates[i]
    nextOffset = i + 1
    const url = `/uploads/${relative}`

    const existing = await db.image.findUnique({ where: { url }, select: { processed: true } })
    if (existing?.processed) {
      skipped++
      continue
    }

    try {
      const buffer = await readFile(filePath)
      const detected = detectFormatFromBuffer(buffer)
      const folder = relative.split('/')[0]
      const type = FOLDER_TO_TYPE[folder] || 'general'
      const fileSize = buffer.length

      if (detected === 'gif' || detected === 'svg' || detected === 'avif' || detected === 'webp') {
        await db.image.upsert({
          where: { url },
          create: { url, storagePath: relative, type, format: detected, fileSize, originalSize: fileSize, processed: false },
          update: { storagePath: relative, type, format: detected, fileSize, originalSize: fileSize, processed: false },
        })
        skipped++
        continue
      }

      const config = UPLOAD_CONFIGS[type]
      const result = await imageProcessor.processVariants(buffer, config.image)

      const saveable = result.variants.map((v) => ({
        suffix: v.suffix,
        data: v.data,
        contentType: v.contentType,
      }))
      const variantUrls = await storage.saveVariants(relative, saveable)

      const variants: Record<string, string> = {}
      for (const v of result.variants) {
        if (variantUrls[v.suffix]) variants[v.suffix] = variantUrls[v.suffix]
      }

      const primarySize = result.variants[0].data.length
      const savedPercent = result.metadata.size > 0
        ? Math.round(((result.metadata.size - primarySize) / result.metadata.size) * 1000) / 10
        : 0
      savedBytesTotal += Math.max(0, result.metadata.size - primarySize)

      await db.image.upsert({
        where: { url },
        create: {
          url, storagePath: relative, type,
          format: result.metadata.format,
          width: result.metadata.width,
          height: result.metadata.height,
          fileSize: primarySize,
          originalSize: result.metadata.size,
          savedBytes: Math.max(0, result.metadata.size - primarySize),
          savedPercent,
          variants: variants as any,
          processed: true,
        },
        update: {
          type,
          format: result.metadata.format,
          width: result.metadata.width,
          height: result.metadata.height,
          fileSize: primarySize,
          originalSize: result.metadata.size,
          savedBytes: Math.max(0, result.metadata.size - primarySize),
          savedPercent,
          variants: variants as any,
          processed: true,
        },
      })

      processed++
      console.log(`  ✓ ${relative} → ${result.variants.length} variants, -${savedPercent}% (${primarySize}B/${result.metadata.size}B)`)
    } catch (err: any) {
      errors++
      console.error(`  ✗ ${relative}:`, err?.message?.slice(0, 200))
      await db.image.upsert({
        where: { url },
        create: { url, storagePath: relative, type: FOLDER_TO_TYPE[relative.split('/')[0]] || 'general', processed: true, fileSize: 0 },
        update: { processed: true },
      }).catch(() => {})
    }
  }

  const done = nextOffset >= candidates.length
  console.log(JSON.stringify({
    processed,
    skipped,
    errors,
    savedBytes: savedBytesTotal,
    nextOffset,
    done,
    total: candidates.length,
  }, null, 2))
  if (!done) {
    console.log(`[Migrate] Run again with: npx tsx scripts/run-migration.ts ${limit} ${nextOffset}`)
  }
  await db.$disconnect()
}

main().catch(async (e) => {
  console.error('[Migrate] Fatal:', e)
  process.exit(1)
})
