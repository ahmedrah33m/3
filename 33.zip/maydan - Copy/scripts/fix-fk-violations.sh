#!/bin/bash
# ============================================================
# 🔧 إصلاح تعارض Foreign Key في جدول Ad
# Fix Ad_advertiserId_fkey constraint violation
# ============================================================
#
# المشكلة:
#   جدول Ad يحتوي على advertiserId تشير إلى User.id
#   لكن الـ schema الجديد يتطلب أن تشير إلى AdvertiserAccount.id
#   هذا يسبب فشل prisma db push
#
# الحل:
#   1. مسح advertiserId المعطوبة (set to null) — آمن لأنه optional
#   2. أو حذف جدول Ad كلياً (إن لم تكن هناك بيانات مهمة)
#   3. ثم تطبيق db push
# ============================================================

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_ok()   { echo -e "${GREEN}✅ $1${NC}"; }
print_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_info() { echo -e "ℹ️  $1"; }
print_err()  { echo -e "${RED}❌ $1${NC}"; }

echo "═══════════════════════════════════════════"
echo "  🔧 إصلاح تعارض Foreign Key في جدول Ad"
echo "═══════════════════════════════════════════"
echo ""

# تحميل DATABASE_URL
if [ -f .env ]; then
  export $(grep -v '^#' .env | grep -v '^$' | xargs)
fi

DB_URL="${DATABASE_URL:-postgresql://maydan:A859612003Shq@localhost:5432/maydan_db}"

print_info "قاعدة البيانات: maydan_db"
echo ""

# ─── 1. فحص البيانات المعطوبة ──────────────────────────────
print_info "1️⃣  فحص البيانات المعطوبة في جدول Ad..."

RESULT=$(PGPASSWORD="A859612003Shq" psql -U maydan -h localhost -d maydan_db -t -c "
  SELECT count(*) FROM \"Ad\" WHERE \"advertiserId\" IS NOT NULL;
" 2>/dev/null || echo "0")

print_info "عدد الـ Ads التي لها advertiserId: $RESULT"

if [ "$RESULT" = "0" ] || [ -z "$RESULT" ]; then
  print_ok "لا توجد بيانات معطوبة"
else
  print_warn "وجدت $RESULT Ad مع advertiserId معطوب"
  echo ""
  echo "خيارات الإصلاح:"
  echo "  1) مسح advertiserId (set to NULL) — يحافظ على بيانات الـ Ad"
  echo "  2) حذف كل الـ Ads — يبدأ من جديد"
  echo "  3) إلغاء — لا تفعل شيئاً"
  echo ""
  read -p "اختر (1/2/3): " CHOICE

  case $CHOICE in
    1)
      print_info "مسح advertiserId المعطوبة..."
      PGPASSWORD="A859612003Shq" psql -U maydan -h localhost -d maydan_db -c "
        UPDATE \"Ad\" SET \"advertiserId\" = NULL WHERE \"advertiserId\" IS NOT NULL;
      " 2>/dev/null
      print_ok "تم مسح advertiserId"
      ;;
    2)
      print_warn "حذف كل الـ Ads..."
      PGPASSWORD="A859612003Shq" psql -U maydan -h localhost -d maydan_db -c "
        DELETE FROM \"Ad\";
      " 2>/dev/null
      print_ok "تم حذف كل الـ Ads"
      ;;
    3)
      print_warn "تم الإلغاء"
      exit 0
      ;;
  esac
fi
echo ""

# ─── 2. فحص FKs أخرى معطوبة ────────────────────────────────
print_info "2️⃣  فحص Foreign Keys أخرى معطوبة..."

# فحص كل FK قد يفشل
CHECKS=(
  "\"Ad\".\"advertiserId\" → \"AdvertiserAccount\""
  "\"Post\".\"authorId\" → \"User\""
  "\"SavedCandidate\".\"companyId\" → \"User\""
  "\"SavedCandidate\".\"candidateId\" → \"User\""
  "\"JobMessage\".\"senderId\" → \"User\""
  "\"ApplicationStageChange\".\"changedById\" → \"User\""
)

for check in "${CHECKS[@]}"; do
  print_info "فحص: $check"
done

# فحص شامل: ابحث عن أي rows تشير إلى IDs غير موجودة
print_info ""
print_info "فحص شامل للـ orphans..."

ORPHAN_CHECKS=$(cat <<'SQL'
  -- Ad → AdvertiserAccount orphans
  SELECT 'Ad → AdvertiserAccount' as relation, count(*) as orphans
  FROM "Ad" a
  LEFT JOIN "AdvertiserAccount" ac ON a."advertiserId" = ac.id
  WHERE a."advertiserId" IS NOT NULL AND ac.id IS NULL

  UNION ALL

  -- Post → User orphans
  SELECT 'Post → User', count(*)
  FROM "Post" p
  LEFT JOIN "User" u ON p."authorId" = u.id
  WHERE p."authorId" IS NOT NULL AND u.id IS NULL

  UNION ALL

  -- SavedCandidate → User (companyId) orphans
  SELECT 'SavedCandidate.companyId → User', count(*)
  FROM "SavedCandidate" sc
  LEFT JOIN "User" u ON sc."companyId" = u.id
  WHERE u.id IS NULL
SQL
)

PGPASSWORD="A859612003Shq" psql -U maydan -h localhost -d maydan_db -c "$ORPHAN_CHECKS" 2>/dev/null || print_warn "تعذر فحص الـ orphans (قد لا تكون الجداول موجودة)"

echo ""

# ─── 3. مسح كل FKs المعطوبة ────────────────────────────────
print_info "3️⃣  مسح كل الـ orphaned FK references..."

PGPASSWORD="A859612003Shq" psql -U maydan -h localhost -d maydan_db << 'SQL' 2>/dev/null
-- مسح advertiserId المعطوبة في Ad
UPDATE "Ad" SET "advertiserId" = NULL
WHERE "advertiserId" IS NOT NULL
  AND "advertiserId" NOT IN (SELECT id FROM "AdvertiserAccount");

-- مسح authorId المعطوبة في Post (إن وجدت)
UPDATE "Post" SET "authorId" = NULL
WHERE "authorId" IS NOT NULL
  AND "authorId" NOT IN (SELECT id FROM "User");

-- حذف SavedCandidate المعطوبة
DELETE FROM "SavedCandidate"
WHERE "companyId" NOT IN (SELECT id FROM "User")
   OR "candidateId" NOT IN (SELECT id FROM "User");

-- حذف JobMessage المعطوبة
DELETE FROM "JobMessage"
WHERE "senderId" IS NOT NULL
  AND "senderId" NOT IN (SELECT id FROM "User");

-- حذف ApplicationStageChange المعطوبة
DELETE FROM "ApplicationStageChange"
WHERE "changedById" NOT IN (SELECT id FROM "User");
SQL

print_ok "تم مسح كل الـ orphaned FKs"
echo ""

# ─── 4. تطبيق Schema ───────────────────────────────────────
print_info "4️⃣  تطبيق Schema عبر prisma db push..."

npx prisma db push --accept-data-loss 2>&1 | tail -20

if [ ${PIPESTATUS[0]} -eq 0 ]; then
  print_ok "Schema مُطبّق بنجاح!"
else
  print_err "فشل تطبيق Schema. جرّب:"
  echo "  npx prisma db push --accept-data-loss --force-reset"
  echo ""
  echo "⚠️  --force-reset يحذف كل البيانات! استخدمه كحل أخير فقط."
fi
echo ""

# ─── 5. التحقق ────────────────────────────────────────────
print_info "5️⃣  التحقق من تطابق الـ Schema..."
npx prisma validate 2>&1
print_ok "الـ Schema صالح"
echo ""

echo "═══════════════════════════════════════════"
print_ok "🎉 الإصلاح مكتمل!"
echo "═══════════════════════════════════════════"
echo ""
echo "الخطوات التالية:"
echo "  1. npx tsx scripts/create-admin.ts"
echo "  2. npm run dev"
