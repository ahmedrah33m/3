# سجل إصلاحات المشاكل الحرجة والمتوسطة — ميدان الاقتصاد

## الملخص

| المرحلة | عدد المشاكل | الحالة |
|---------|------------|--------|
| حرجة (Critical) | 6/6 | ✅ مكتمل |
| متوسطة (Medium) | 7/7 | ✅ مكتمل |
| الاختبارات | 115 اختبار | ✅ ناجح |

---

## المشاكل الحرجة (تم حلها في المرحلة السابقة)

1. ✅ **Redis Integration** — استبدال Map في الذاكرة بـ Redis عبر ioredis
2. ✅ **Test Framework** — Vitest + Testing Library مع 115 اختبار
3. ✅ **React Strict Mode** — تفعيل reactStrictMode في next.config.ts
4. ✅ **Password Hashing** — scrypt + random salt في prisma/seed.ts
5. ✅ **Google OAuth** — إعداد auth/google/route.ts
6. ✅ **AI APIs** — ربط z-ai-web-dev-sdk في مسارات AI

---

## المشاكل المتوسطة (تم حلها الآن)

### 1. ✅ JSON Strings بدل جداول قاعدة البيانات

**المشكلة**: عدة حقول في قاعدة البيانات كانت تخزن بيانات مهيكلة كنصوص JSON بدلاً من جداول علاقات.

**الحل**: إضافة 8 جداول علاقات جديدة في Prisma schema:

| الجدول الجديد | يستبدل | الوظيفة |
|-------------|--------|---------|
| `UserSkill` | `User.expertise` (نص مفصول بفاصلات) | مهارات المستخدم |
| `UserSpecialization` | `User.specializations` (نص) | تخصصات المستخدم |
| `UserSocialLink` | `User.socialLinks` (JSON) | روابط التواصل الاجتماعي |
| `NotificationPreference` | `User.notificationPrefs` (JSON) | تفضيلات الإشعارات |
| `ArticleTag` | `Article.tags` (JSON) + ربط بـ `Hashtag` | وسوم المقالات |
| `ArticleMedia` | `Article.mediaUrls` (JSON) | ملفات وسائط المقالات |
| `DiscussionMedia` | `Discussion.mediaUrls` (JSON) | ملفات وسائط النقاشات |
| `QuizOptionRecord` | `QuizQuestion.options` (JSON) | خيارات الأسئلة |
| `QuizAnswer` | `QuizAttempt.answers` (JSON) | إجابات المحاولات |

الحقول القديمة محفوظة ومعلّمة كـ `@deprecated` لضمان التوافق العكسي أثناء الهجرة.

**الملفات**: `prisma/schema.prisma`

---

### 2. ✅ لا يوجد WebSocket حقيقي

**المشكلة**: غرف الدردشة كانت تعتمد على HTTP polling كل ثانيتين. ملف WebSocket في `examples/` غير متصل بالتطبيق.

**الحل**: نظام SSE (Server-Sent Events) للاتصال الحقيقي:

- **SSE API Route** (`src/app/api/chat-rooms/[id]/events/route.ts`):
  - بث أحداث `message` عند وصول رسائل جديدة
  - `heartbeat` كل 15 ثانية للحفاظ على الاتصال
  - استعلام فعال بقاعدة البيانات كل 1.5 ثانية
  - دعم `?lastId=xxx` لاستئناف الاتصال
  - تنظيف تلقائي عند إغلاق الاتصال

- **useChatSSE Hook** (`src/hooks/useChatSSE.ts`):
  - اتصال تلقائي عبر EventSource
  - إعادة اتصال تراجعية أسّية (1s → 2s → 4s → 30s)
  - حالة اتصال مرئية (متصل/يعاد الاتصال/استطلاع/غير متصل)
  - إزالة تكرار الرسائل بالمعرف
  - fallback تلقائي للاستطلاع بعد 3 محاولات فاشلة

- **مؤشر حالة الاتصال**: نقطة ملونة في رأس الدردشة
  - 🟢 أخضر = SSE متصل
  - 🟡 أصفر = يعيد الاتصال
  - 🔵 أزرق = fallback استطلاع
  - 🔴 أحمر = غير متصل

**الملفات**: `events/route.ts`, `useChatSSE.ts`, `ChatRooms.tsx` (مُحدّث)

---

### 3. ✅ نظام الدفع غير مكتمل

**المشكلة**: جميع المدفوعات محاكاة — الحالة تُعطى مباشرة `completed` بدون بوابة دفع حقيقية.

**الحل**: طبقة تجريد بوابة الدفع:

- **PaymentGateway Interface** (`src/lib/payment-gateway.ts`):
  - `initialize()`, `createPayment()`, `verifyPayment()`, `refund()`
  - `PaymentGatewayError` class مع أنواع الأخطاء
  - `SimulatedGateway` — محاكاة كاملة للتطوير
  - `MastercardGateway` — هيكل جاهز لربط Mastercard API
  - `ZainCashGateway` — هيكل جاهز لربط Zain Cash API
  - `createPaymentGateway(method)` — مصنع لإنشاء البوابة المناسبة

- **PaymentService** (`src/lib/payment-service.ts`):
  - `createPaymentOrder()` — تحقق من الأسعار، خصم الكوبونات، إنشاء طلب
  - `confirmPayment()` — تأكيد من البوابة، تحديث قاعدة البيانات
  - `handleWebhook()` — معالجة ردود البوابات
  - `refundPayment()` — استرجاع الأموال
  - التكامل مع المحفظة (`Wallet` و `WalletTransaction`)

- **Webhook Endpoint** (`src/app/api/payments/webhook/route.ts`):
  - POST: استقبال تأكيدات البوابات
  - GET: فحص صحة البوابات المدعومة

- **تحديث payments API**: الحالة الآن `pending` (لا `completed` مباشرة)

**الملفات**: `payment-gateway.ts`, `payment-service.ts`, `webhook/route.ts`, `payments/route.ts` (مُحدّث)

---

### 4. ✅ الرقابة على المحتوى بالكلمات فقط

**المشكلة**: نظام الرقابة يعتمد فقط على قائمة كلمات ممنوعة مع عيوب عديدة:
- `\b` لا يعمل مع النص العربي
- خطأ: `' Wahabi '` بمسافة بادئة لا يمسك الاستخدام العادي
- لا يلتقط التلاعب بالنص (حروف مفصولة بنقاط، أرقام بدل حروف)
- `moderateImageUrl` و `moderateVideoUrl` no-ops دائماً
- رسائل الدردشة والرسائل المباشرة غير مراقبة

**الحل**: تعزيز نظام الرقابة بـ 6 مراحل:

1. **Unicode Normalization** (`normalizeArabic()`):
   - تجريد التشكيل (فتحة، ضمة، كسرة، شدة، سكون)
   - توحيد ألف (أ، إ، آ → ا)
   - تحويل تاء مربوطة (ة → ه)
   - إزالة الأحرف عرض الصفر
   - إزالة التطويل

2. **Anti-Evasion Detection** (`detectEvasion()`):
   - إدخال نقاط بين الحروف: ك.ل.ب
   - تكرار الحروف: ككككللللببب
   - استبدال الأرقام بالحروف العربية (7→ح، 5→خ، 3→ع، 9→ص)
   - حروف خاصة متداخلة

3. **Arabic-Aware Boundary Matching**: استبدال `\b` بفاحص حدود يدوي يدعم العربية واللاتينية

4. **رقابة الرسائل**: تطبيق `moderateContent()` على:
   - رسائل غرف الدردشة (`chat-rooms/[id]/messages`)
   - الرسائل المباشرة (`messages`)

**الملفات**: `moderation.ts` (مُحدّث), `messages/route.ts` (مُحدّث), `chat-rooms/[id]/messages/route.ts` (مُحدّث)

---

### 5. ✅ لا يوجد Error Boundary مركزي

**المشكلة**: إذا تعطل أي مكون فردي (مثلاً بطاقة مقال)، يتعطل الصفحة بالكامل.

**الحل**: مكون ErrorBoundary قابل لإعادة الاستخدام:

- **`ErrorBoundary.tsx`**: مكون React class component يدعم:
  - `fallback` مخصص أو واجهة افتراضية عربية
  - `componentName` لتسجيل الأخطاء
  - `showReset` / `showHome` أزرار
  - `onError` callback للخدمات الخارجية
  - `onReset` callback لإعادة تحميل البيانات

- **`withErrorBoundary.tsx`**: HOC لتغليف المكونات بسهولة:
  ```tsx
  const SafeArticleCard = withErrorBoundary(ArticleCard, { componentName: 'ArticleCard' })
  ```

**الملفات**: `ErrorBoundary.tsx`, `withErrorBoundary.tsx`

---

### 6. ✅ store.ts require() → ES imports (حُلّ سابقاً)

### 7. ✅ ملفات Python عشوائية (حُلّت سابقاً) + ✅ .env.example (حُلّ سابقاً)

---

## الاختبارات

| ملف الاختبار | عدد الاختبارات | المحتوى |
|-------------|-------------|---------|
| `moderation.test.ts` | 10 | فلترة الكلمات الممنوعة |
| `moderation-enhanced.test.ts` | 22 | Unicode normalization، anti-evasion، تشكيل |
| `auth.test.ts` | 8 | تجزئة كلمات المرور، التحقق |
| `cache.test.ts` | 7 | التخزين المؤقت (Redis/ذاكرة) |
| `cache-helpers.test.ts` | 16 | مفاتيح التخزين، cachedFetch |
| `rate-limit.test.ts` | 6 | تحديد المعدل |
| `navigation.test.ts` | 21 | بناء الروابط، تعيين المسارات |
| `tags.test.ts` | 22 | تحليل/تحويل الوسوم |
| `error-boundary.test.ts` | 3 | ErrorBoundary exports |
| **المجموع** | **115** | |

---

## المتغيرات البيئية الجديدة

```env
# Payment Gateways
MASTERCARD_API_KEY=
MASTERCARD_MERCHANT_ID=
MASTERCARD_TEST_MODE=true
ZAINCASH_MERCHANT_ID=
ZAINCASH_SECRET_KEY=
ZAINCASH_TEST_MODE=true
PAYMENT_GATEWAY_ENV=development
```
