# 08 — تدقيق نظام المقابلات | Interview Workflow

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 🔴 الحالة الحالية: مكسور تمامًا

### المشاكل
1. ❌ لا يوجد `/api/interviews` (لا CRUD)
2. ❌ لا يوجد `Interview` model في DB
3. ❌ صفحة `/jobs/employer/interviews` تستخدم mock data
4. ❌ `handleComplete/handleCancel/handleSaveReschedule/handleSaveNotes` كلها `setTimeout` بدون API
5. ❌ يُحقن بيانات تجريبية ("demo-1", "demo-2") عند عدم وجود بيانات

---

## 🎯 الـ Interview Model المطلوب

```text
Interview
├── scheduling
│   ├── scheduledAt (DateTime)
│   ├── durationMinutes (Int)
│   ├── location (String?)
│   ├── isOnline (Boolean)
│   ├── meetingUrl (String?)  // Zoom/Teams/Meet
│   └── meetingPassword (String?)
├── interviewers
│   └── interviewerIds (String[])
├── type
│   └── round (1st, 2nd, final, technical)
│   └── type (general | technical | hr | final | phone_screen)
├── status
│   └── SCHEDULED | COMPLETED | CANCELLED | NO_SHOW | RESCHEDULED
├── evaluation
│   ├── technicalSkills (1-5)
│   ├── communication (1-5)
│   ├── experience (1-5)
│   ├── problemSolving (1-5)
│   ├── cultureFit (1-5)
│   ├── overallScore (0-100)
│   └── recommendation (RECOMMEND | NEUTRAL | DO_NOT_RECOMMEND)
└── notes
    ├── strengths
    ├── weaknesses
    └── notes
```

---

## 🛠️ خطة التنفيذ

### P0
1. إنشاء `Interview` + `InterviewEvaluation` models
2. إنشاء `/api/interviews` (CRUD)
3. إصلاح صفحة `/jobs/employer/interviews` (إزالة mock data)
4. ربط المقابلة بـ JobApplication + Job + Candidate + Company

### P1
5. إضافة تذكيرات (email + WhatsApp قبل المقابلة بـ 24 ساعة)
6. إضافة Online meeting integration (Zoom/Google Meet)
7. إضافة Evaluation form للمقابِلين
8. تجميع نتائج المقابلات المتعددة

</div>
