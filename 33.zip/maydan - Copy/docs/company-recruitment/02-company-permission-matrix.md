# 02 — مصفوفة صلاحيات الشركات | Company Permission Matrix

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 🎯 الهدف

تعريف نظام صلاحيات هرمي للشركات يدعم:

```text
OWNER (مالك الشركة)
   ↓
GENERAL_MANAGER (مدير عام)
   ↓
HR_MANAGER (مدير موارد بشرية)
   ↓
RECRUITER (مسؤول توظيف)
   ↓
HIRING_MANAGER (مدير توظيف)
   ↓
BRANCH_MANAGER (مدير فرع)
   ↓
DEPARTMENT_MANAGER (مدير قسم)
   ↓
EMPLOYEE (موظف)
```

---

## 📋 مصفوفة الصلاحيات التفصيلية

### 1. Company Management

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| تعديل بيانات الشركة | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| حذف الشركة | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| رفع مستندات التوثيق | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| إدارة الفروع | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| إدارة الأقسام | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ (فرعه) | ❌ |
| دعوة مستخدمين للشركة | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| تعيين أدوار للموظفين | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |

### 2. Job Management

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| إنشاء وظيفة | ✅ | ✅ | ✅ | ✅ | ✅ (قسمه) | ✅ (فرعه) | ❌ |
| نشر وظيفة | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ (فرعه) | ❌ |
| تعديل وظيفة (خاصة) | ✅ | ✅ | ✅ | ✅ (إنشائه) | ✅ (قسمه) | ✅ (فرعه) | ❌ |
| حذف وظيفة | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| جدولة نشر | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| إغلاق تلقائي | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| إعادة فتح وظيفة | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

### 3. Candidate & CV Bank

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| الوصول لـ CV Bank | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| بحث في السير الذاتية | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| عرض ملف مرشح كامل | ✅ | ✅ | ✅ | ✅ | ✅ (مرشحيه) | ❌ | ❌ |
| حفظ مرشح | ✅ | ✅ | ✅ | ✅ | ✅ (مرشحيه) | ❌ | ❌ |
| تقييم مرشح | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| دعوة مرشح للتقديم | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| مقارنة مرشحين | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| Talent Pools إدارة | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Saved Searches | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Talent Alerts | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |

### 4. ATS Pipeline

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| عرض المتقدمين (كل الوظائف) | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ (فرعه) | ❌ |
| عرض المتقدمين (وظيفة محددة) | ✅ | ✅ | ✅ | ✅ | ✅ (وظائفه) | ✅ (فرعه) | ❌ |
| تغيير مرحلة pipeline | ✅ | ✅ | ✅ | ✅ | ✅ (مرشحيه) | ❌ | ❌ |
| إضافة ملاحظة داخلية | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| رفض مرشح | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |

### 5. Interview & Offer

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| جدولة مقابلة | ✅ | ✅ | ✅ | ✅ | ✅ (وظائفه) | ❌ | ❌ |
| تقييم مقابلة | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| إنشاء عرض وظيفي | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| تعديل عرض | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| سحب عرض | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

### 6. Hiring & Employee

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| توظيف مرشح (تحويل لـ Employee) | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| عرض سجل الموظفين | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ (فرعه) | ❌ |
| إدارة Onboarding | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

### 7. Analytics & Reports

| الإجراء | OWNER | GM | HR_MGR | RECRUITER | HIRING_MGR | BRANCH_MGR | EMPLOYEE |
|---------|-------|-----|--------|-----------|------------|------------|----------|
| عرض تقارير الشركة الكاملة | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ (فرعه) | ❌ |
| عرض Recruitment Funnel | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| عرض Time-to-Hire | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| تصدير بيانات المرشحين | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

---

## 🗄️ نماذج Prisma المطلوبة

### `UserCompanyRole` (علاقة المستخدم بالشركة)

```prisma
model UserCompanyRole {
  id          String   @id @default(cuid())
  userId      String
  companyId   String
  role        CompanyRole  // owner | general_manager | hr_manager | recruiter | hiring_manager | branch_manager | department_manager | employee
  branchId    String?   // للـ branch_manager
  departmentId String?  // للـ department_manager
  assignedById String?  // من عيّن هذا الدور
  assignedAt  DateTime  @default(now())
  status      String   @default("active")  // active | suspended | revoked
  permissions Json?    // صلاحيات إضافية محددة
  
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  company     Company  @relation(fields: [companyId], references: [id], onDelete: Cascade)
  
  @@unique([userId, companyId])
  @@index([companyId, role])
}

enum CompanyRole {
  OWNER
  GENERAL_MANAGER
  HR_MANAGER
  RECRUITER
  HIRING_MANAGER
  BRANCH_MANAGER
  DEPARTMENT_MANAGER
  EMPLOYEE
}
```

---

## 🔧 خطة التنفيذ

### P0 (فوري)
1. إضافة `CompanyRole` enum إلى schema
2. إضافة `UserCompanyRole` model
3. عند إنشاء شركة، يتم إنشاء `UserCompanyRole` بدور `OWNER` للمالك
4. تحديث `permission-engine-enhanced.ts` ليدعم هذه الأدوار

### P1 (قصير المدى)
5. إضافة UI لإدارة أعضاء الشركة (`/company-dashboard/team`)
6. إضافة دعوات بالبريد لانضمام موظفين للشركة
7. ربط الـ permission engine بكل routes التوظيف

### P2 (متوسط المدى)
8. إضافة `branchId` و `departmentId` للوظائف
9. تطبيق scope filtering (branch manager يرى فرعه فقط)
10. إضافة audit log لكل تغيير دور

</div>
