# 14 — سجل التغييرات | Implementation Changelog

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## ✅ ما تم إنجازه (P0 — Fixes)

### 1. إصلاح bug ترتيب الوسائط في `/api/jobs/[id]/applications`
**الملف:** `src/app/api/jobs/[id]/applications/route.ts`
**المشكلة:** `getJobApplications(user.id, id, ...)` كان يمرر `user.id` (userId) كـ jobId، و `id` (من URL) كـ companyId. النتيجة: 404 دائمًا.
**الإصلاح:** بدّل الترتيب إلى `getJobApplications(id, user.id, ...)` (jobId=id, companyId=user.id)

### 2. إصلاح ثغرة `/api/jobs/[id]/messages` — انتحال هوية
**الملف:** `src/app/api/jobs/[id]/messages/route.ts`
**المشكلة:** 
- GET: لا auth — أي شخص يقرأ كل رسائل المتقدمين
- POST: يقبل `senderId` من body — انتحال هوية كامل
**الإصلاح:**
- أضف `requireAuth()` للـ GET و POST
- استخدم `user.id` من session بدل `senderId` من body
- أضف ownership check (الشركة تملك الوظيفة)

### 3. إصلاح ثغرة `/api/jobs/[id]/share` — لا auth
**الملف:** `src/app/api/jobs/[id]/share/route.ts`
**المشكلة:** 
- POST: أي شخص يحقن سجلات مشاركة مزيفة
- GET: أي شخص يقرأ إحصاءات المشاركة
**الإصلاح:**
- أضف `requireAuth()` للـ GET و POST
- استخدم `user.id` من session بدل `userId` من body
- أضف ownership check للـ GET

### 4. إصلاح ثغرة `/api/candidates/[id]/profile` — لا tier check
**الملف:** `src/app/api/candidates/[id]/profile/route.ts`
**المشكلة:** `getCandidateProfile(id)` يُرجع البريد، الهاتف، ملف السيرة الذاتية لأي مستخدم مسجّل — تسريب بيانات شخصية.
**الإصلاح:**
- استخدم tier-aware flow:
  1. إذا المستخدم OWNER → وصول كامل
  2. إذا المستخدم recruiter يملك وظيفة تقدم لها هذا المرشح → وصول كامل
  3. إذا ADMIN/MODERATOR → وصول كامل
  4. خلاف ذلك → استخدم `getCandidateDetail` من cv-bank.service (مع tier check)

### 5. إصلاح `/api/companies` POST — لا يُحدّث userType
**الملف:** `src/app/api/companies/route.ts` + `src/services/company.service.ts`
**المشكلة:** 
- الـ route يستخدم `db.company.create` مباشرة دون تحديث `user.userType`
- خدمة `createCompany` في company.service.ts (التي تُحدّث userType) كانت DEAD CODE
- النتيجة: شركة مسجّلة لكن owner لا يستطيع نشر وظائف
**الإصلاح:**
- استدعاء `createCompany` من company.service.ts في الـ route
- تحديث `CreateCompanyInput` interface ليدعم كل الحقول (size, headquarterLocation, specialization, linkedinUrl)
- ✅ الآن `user.userType` يُحدّث إلى `'company'` تلقائيًا بعد إنشاء الشركة

### 6. إضافة DELETE method لسحب الطلب (withdraw application)
**الملف:** `src/app/api/jobs/[id]/apply/route.ts` + `src/services/job-application.service.ts`
**المشكلة:** 
- صفحة `/jobs/candidate/applied` تحاول `DELETE /api/jobs/${appId}/apply`
- الـ route لا يدعم DELETE → 405 Method Not Allowed
- حتى لو وُجد DELETE، يتمرر `appId` في مكان `jobId` (bug مزدوج)
**الإصلاح:**
- أضف DELETE method لـ `/api/jobs/[id]/apply`
- اقبل `applicationId` كـ query param (`?applicationId=xxx`)
- أضف دالة `withdrawApplication(userId, applicationId)` في job-application.service.ts
  - تتحقق من ownership (المستخدم يملك الطلب)
  - تُحدّث `pipelineStage = 'WITHDRAWN'` و `withdrawnAt = new Date()`
  - تسجل stage change في `ApplicationStageChange` (audit log)

---

## 📦 الوثائق المُنتجة

### 14 وثيقة في `docs/company-recruitment/`

1. ✅ `01-company-registration-audit.md` — تدقيق تسجيل الشركة
2. ✅ `02-company-permission-matrix.md` — مصفوفة الصلاحيات
3. ✅ `03-company-workflow.md` — الـ workflow الكامل
4. ✅ `04-job-workflow.md` — تدقيق الـ Job Workflow
5. ✅ `05-cv-bank-audit.md` — تدقيق بنك السير الذاتية
6. ✅ `06-candidate-workflow.md` — تدقيق الـ Candidate Workflow
7. ✅ `07-ats-workflow.md` — تدقيق ATS Pipeline
8. ✅ `08-interview-workflow.md` — تدقيق نظام المقابلات
9. ✅ `09-offer-workflow.md` — تدقيق نظام العروض
10. ✅ `10-recruitment-security-audit.md` — تدقيق الأمان
11. ✅ `11-recruitment-competitor-analysis.md` — تحليل المنافسين
12. ✅ `12-feature-gap-analysis.md` — تحليل الفجوات
13. ✅ `13-recruitment-roadmap.md` — خارطة الطريق
14. ✅ `14-implementation-changelog.md` — سجل التغييرات (هذا الملف)

### ملف Prisma إضافي
- ✅ `prisma/schema-additions-recruitment.prisma` — 11 نموذج جديد (Interview, Offer, Employee, TalentPool, SavedSearch, CandidateInvitation, UserCompanyRole, JobScreeningQuestion, ScreeningAnswer, إلخ)

---

## 🎯 ما يحتاج إكمالًا (P1 — التالي)

### نماذج Prisma (Migration آمن)
- دمج محتوى `schema-additions-recruitment.prisma` في `schema.prisma`
- تشغيل `npx prisma migrate dev --name recruitment_system_models`
- تشغيل `npx prisma generate`

### APIs جديدة
- `/api/interviews` (CRUD + scheduling + evaluation)
- `/api/offers` (CRUD + accept/decline/withdraw)
- `/api/talent-pools` (CRUD + members)
- `/api/saved-searches` (CRUD + alerts)
- `/api/candidate-invitations` (CRUD)
- `/api/candidates/compare` (مقارنة جنبًا إلى جنب)

### UI جديدة
- `CompanyRegistrationWizard.tsx` (7 steps)
- `InterviewScheduler.tsx` (with calendar + online meeting)
- `OfferManager.tsx` (create/send/track offers)
- `CandidateComparison.tsx` (side-by-side table)
- `TalentPoolManager.tsx` (CRUD + members)
- `SavedSearchManager.tsx` (with alerts)

### إصلاحات UI
- إصلاح `/jobs/employer/interviews` (إزالة mock data)
- إصلاح `/jobs/employer/settings` (استخدام `/api/companies/[id]` بدلاً من `/api/auth/me`)
- إصلاح `/jobs/candidate/offers` (استخدام `/api/offers` بدلاً من stage manipulation)

---

## ⚠️ ما يجب اختباره بعد الإصلاحات

### اختبارات P0 (يجب أن تنجح)
1. ✅ إنشاء شركة جديدة → owner يمكنه نشر وظائف
2. ✅ عرض متقدمي وظيفة (لا 404)
3. ✅ سحب طلب (DELETE يعمل)
4. ✅ رسائل الوظائف تتطلب auth
5. ✅ عرض ملف مرشح يتطلب tier (لغير recruiters)
6. ✅ مشاركة الوظائف تتطلب auth

### اختبارات IDOR (P1)
7. User A لا يستطيع تعديل وظائف User B
8. User A لا يستطيع عرض متقدمي وظائف User B
9. Recruiter من Company X لا يرى مرشحي Company Y
10. Candidate A لا يستطيع سحب طلبات Candidate B

</div>
