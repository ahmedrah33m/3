# 01 — تدقيق تسجيل الشركة | Company Registration Audit

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ التدقيق:** 2026-08-23
**النطاق:** نظام تسجيل الشركات + Organization + Permissions

---

## 📊 الحالة الحالية

### الـ flow الحالي (مكسور)

```text
User Registration
   ↓ (auth/register مع userType='company' أو 'member')
Email Verification
   ↓
Profile Creation
   ↓
اختيار "إنشاء شركة"
   ↓
POST /api/companies
   ↓
⚠️ BUG: لا يتم تحديث user.userType إلى 'company'
   ↓
النتيجة: شركة مسجّلة لكن صاحبها لا يستطيع نشر وظائف
```

### المشاكل المكتشفة

| # | المشكلة | الخطورة | الموقع |
|---|---------|--------|--------|
| 1 | لا يوجد wizard متعدد الخطوات | 🔴 حرج | `/api/companies` POST مباشر |
| 2 | `company.service.ts` (createCompany) **DEAD CODE** — لا route يستدعيه | 🔴 حرج | `src/services/company.service.ts` |
| 3 | `/api/companies` POST لا يُحدّث `user.userType='company'` | 🔴 حرج | `src/app/api/companies/route.ts` |
| 4 | النتيجة: شركة مسجّلة لكن owner ممنوع من `createJob` | 🔴 حرج | `job.service.ts` يتحقق `userType === 'company'` |
| 5 | `Company.ownerId @unique` — مالك واحد فقط، لا recruiters | ⚠️ قيد | `prisma/schema.prisma` |
| 6 | لا يوجد Company Verification workflow | ⚠️ ناقص | لا model verification |
| 7 | لا يوجد رفع مستندات قانونية | ⚠️ ناقص | لا file upload للشركات |
| 8 | لا يوجد Branch/Department في DB | ⚠️ ناقص | لا نماذج |
| 9 | `UserRole` enum لا يحتوي `COMPANY` (لكن permission-engine يُشير إليه!) | 🔴 تعارض | `prisma/schema.prisma` L15 |

---

## 🎯 المتطلبات (حسب البرومبت)

### Wizard من 7 خطوات

```text
Step 1: إنشاء حساب شخصي (User Registration)
Step 2: اختيار "إنشاء شركة / منظمة"
Step 3: Company Identity
   - الاسم التجاري
   - الاسم القانوني
   - نوع الكيان
   - رقم التسجيل
   - القطاع
   - النشاط
   - تاريخ التأسيس
   - الدولة / المحافظة / المدينة / المنطقة
   - العنوان
   - البريد الرسمي
   - الهاتف
   - الموقع الإلكتروني
Step 4: Brand Identity
   - Logo
   - Cover
   - Brand description
   - Company slogan
Step 5: Company Structure
   - Headquarters
   - Branches
   - Departments
Step 6: Verification
   - رفع المستندات (سجل تجاري، هوية المالك، إلخ)
Step 7: Company Created → Owner Dashboard
```

### النموذج المعماري المطلوب

```text
USER (شخص)
   ↓
PERSONAL PROFILE

USER
   ↓
ORGANIZATION MEMBERSHIP  ← هذه علاقة Many-to-Many
   ↓                          (مع دور: owner/HR/recruiter)
COMPANY (كيان مستقل)
```

**القاعدة:** الشركة ليست مستخدمًا. الشركة كيان مستقل، والمستخدم يملك صلاحية داخلها.

---

## 🛠️ خطة الإصلاح (P0)

### 1. إصلاح `/api/companies` POST
- استدعاء `createCompany` من `company.service.ts` بدل `db.company.create` مباشرة
- هذا سيُحدّث `user.userType='company'` تلقائيًا

### 2. إنشاء Wizard Component
- `src/components/company/CompanyRegistrationWizard.tsx`
- 7 خطوات مع validation في كل خطوة
- يحفظ الحالة في localStorage (draft) + يستعيدها عند العودة

### 3. إضافة نماذج Prisma الناقصة (migration آمن)
- `CompanyVerification` — حالة التوثيق + المستندات
- `CompanyDocument` — ملفات مرفوعة (سجل تجاري، إلخ)
- `UserCompanyRole` — علاقة المستخدم بالشركة مع الدور

### 4. إضافة `COMPANY` إلى `UserRole` enum
- مع الحفاظ على التوافق مع الكود القديم

---

## ✅ معايير القبول

- [ ] `POST /api/companies` يُحدّث `user.userType='company'`
- [ ] wizard من 7 خطوات يعمل
- [ ] يمكن للمستخدم اختيار "إنشاء شركة" بعد التسجيل
- [ ] يتم رفع المستندات وتخزينها بأمان
- [ ] تظهر حالة التوثيق في Company Dashboard
- [ ] يمكن للمالك الوصول للـ Owner Dashboard بعد الإنشاء

</div>
