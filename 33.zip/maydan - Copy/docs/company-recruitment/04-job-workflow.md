# 04 — تدقيق الـ Job Workflow | Job Creation, Publishing, Management

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 📋 الحالة الحالية

### ✅ يعمل
- JobCreationForm (6 تبويبات، 1980 سطر)
- createJob service مع validation ودفع
- CompanyFreePeriod + couponCode
- auto-publish على تيليجرام
- إشعارات للمستخدمين المهتمين

### ❌ ناقص
- لا screeningQuestions في DB
- لا companyId FK (String فقط)
- لا branchId / departmentId
- لا positionsCount (عدد الشواغر)
- لا Job Visibility (Public/Private/Internal)
- لا "Who can apply?" filter (All/Verified/Selected regions)
- لا Scheduled Publish
- لا Auto Close عند انتهاء الموعد
- لا Reopen Job
- لا Duplicate Job Detection

---

## 🎯 الحقول المطلوبة (حسب البرومبت)

```text
Job Title
Department
Employment Type
Work Mode (onsite/remote/hybrid)
Location (governorate/city/area)
Branch
Description
Responsibilities
Requirements
Skills
Education
Experience
Salary (min/max + currency)
Benefits
Deadline
Vacancies (positionsCount)
Contact (email/phone/method)
Screening Questions
```

### ميزات متقدمة
```text
Job Visibility: Public | Private | Internal
Who can apply: All | Verified | Selected regions | Selected skill levels
Scheduled Publish
Auto Close
Extend Deadline
Reopen Job
Duplicate Detection
```

---

## 🛠️ خطة الإصلاح

### P0
1. ✅ إصلاح /api/companies POST (يحدّث userType)
2. إضافة screeningQuestions إلى JobCreationForm
3. إضافة positionsCount و workMode و responsibilities

### P1
4. إضافة Job Visibility options
5. إضافة "Who can apply" filters
6. إضافة Duplicate Detection قبل النشر
7. إضافة Scheduled Publish

### P2
8. إضافة Auto Close + Reopen
9. ربط Job بـ companyId FK حقيقي
10. ربط Job بـ branchId / departmentId

</div>
