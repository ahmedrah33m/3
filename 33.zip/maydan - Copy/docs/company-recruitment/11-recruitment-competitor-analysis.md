# 11 — تحليل المنافسين | Recruitment Competitor Analysis

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 📊 تحليل المنافسين

| الميزة | LinkedIn | Indeed | Bayt | GulfTalent | ميدان (حالي) |
|--------|----------|--------|------|------------|--------------|
| Job Matching | ✅ AI | ❌ | ✅ Basic | ❌ | ⚠️ Basic |
| Candidate Search | ✅ | ✅ | ✅ | ✅ | ✅ |
| Recruiter Workflows | ✅ Advanced | ✅ | ✅ Basic | ⚠️ | ❌ |
| CV Database | ✅ | ✅ | ✅ | ✅ | ✅ |
| Candidate Invitations | ✅ | ❌ | ⚠️ | ❌ | ❌ |
| Interview Management | ✅ | ❌ | ❌ | ❌ | ❌ |
| Employer Branding | ✅ | ✅ | ✅ | ⚠️ | ❌ |
| Recruitment Analytics | ✅ Advanced | ✅ | ⚠️ | ⚠️ | ⚠️ Basic |
| Talent Pools | ✅ | ❌ | ✅ | ❌ | ❌ |
| Application Tracking | ✅ ATS | ✅ | ✅ | ⚠️ | ✅ Kanban |
| Saved Searches | ✅ + Alerts | ⚠️ | ⚠️ | ❌ | ❌ |
| Verified Experience | ✅ | ❌ | ❌ | ❌ | ❌ |
| Skill Gap Analysis | ❌ | ❌ | ❌ | ❌ | ❌ |
| Iraq-specific Features | ❌ | ❌ | ❌ | ⚠️ | ✅ Map + Governorates |

---

## 🎯 فرص تميّز ميدان

### 1. Iraq Talent Map
- خريطة تعرض الكفاءات حسب المحافظة
- Demand vs Supply per skill per governorate
- لا يقدمها أي منافس

### 2. Economic Talent Index
- مؤشر مهني مبني على النشاط الاقتصادي للمستخدم
- يربط ميدان الاقتصاد بميدان التوظيف
- ميزة فريدة لميدان

### 3. Verified Experience (محلي)
- تأكيد فترة العمل من قبل الشركة
- يبني ثقة في سوق العمل العراقي
- مهم خصوصًا في العراق حيث التحقق صعب

### 4. Skill Demand Map
- عرض الطلب على المهارات حسب المحافظة
- يساعد المرشحين على اختيار التخصص المناسب
- يساعد الجامعات على توجيه الطلاب

### 5. Graduate Mode + Internship Marketplace
- استهداف الخريجين الجدد
- تكامل مع الأكاديمية (Courses → Internship → Job)
- مناسب لطبيعة السوق العراقي الشاب

</div>
