# 09 — تدقيق نظام العروض | Offer Workflow

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 🔴 الحالة الحالية: مكسور تمامًا

### المشاكل
1. ❌ لا يوجد `/api/offers` (لا CRUD)
2. ❌ لا يوجد `Offer` model في DB
3. ❌ "العرض" = نقل المرشح لمرحلة OFFERED فقط
4. ❌ لا offer letter (PDF)
5. ❌ لا deadline للاستجابة
6. ❌ لا تفاصيل راتب منفصلة (salary min/max, currency, benefits)
7. ❌ لا توقيع/قبول رسمي
8. ❌ لا سجل تعديلات
9. ❌ صفحة `/jobs/candidate/offers` تبني عرضًا من مرحلة OFFERED فقط

---

## 🎯 الـ Offer Model المطلوب

```text
Offer
├── details
│   ├── jobTitle (String)
│   ├── jobDescription (String?)
│   ├── contractType (FULL_TIME | PART_TIME | CONTRACT | INTERNSHIP)
│   ├── startDate (DateTime)
│   ├── endDate (DateTime?)  // for contracts
│   └── probationPeriod (Int? months)
├── compensation
│   ├── salaryMin (Decimal)
│   ├── salaryMax (Decimal)
│   ├── salaryCurrency (IQD | USD)
│   ├── benefits (JSON array)
│   └── bonuses (String?)
├── deadline
│   └── offerDeadline (DateTime)
├── status
│   └── PENDING | ACCEPTED | REJECTED | WITHDRAWN | EXPIRED | COUNTERED
├── response
│   ├── candidateResponse (String?)
│   ├── respondedAt (DateTime?)
│   ├── acceptedAt (DateTime?)
│   └── rejectedAt (DateTime?)
├── letter
│   └── offerLetter (String? — URL to PDF)
└── audit
    ├── createdById (String)
    ├── createdAt (DateTime)
    └── updatedAt (DateTime)
```

---

## 🛠️ خطة التنفيذ

### P0
1. إنشاء `Offer` model
2. إنشاء `/api/offers` (CRUD + accept/decline/withdraw)
3. إنشاء `/api/offers/[id]/accept` و `/api/offers/[id]/decline`
4. ربط العرض بـ JobApplication + Job + Candidate + Company
5. إصلاح صفحة `/jobs/candidate/offers` لاستخدام الـ API الجديد

### P1
6. توليد PDF offer letter
7. إشعارات (email + WhatsApp) عند إنشاء/قبول/رفض عرض
8. توقيع إلكتروني (future)
9. Counter-offer workflow

</div>
