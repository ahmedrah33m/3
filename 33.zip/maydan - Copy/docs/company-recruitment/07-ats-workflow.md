# 07 — تدقيق ATS Pipeline

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 📋 الـ Pipeline Stages الموحّدة

```text
RECEIVED          → تم الاستلام
UNDER_REVIEW      → قيد المراجعة
CV_ACCEPTED       → قبول السيرة
INTERVIEW_INVITED → دعوة للمقابلة
FIRST_INTERVIEW   → المقابلة الأولى
SECOND_INTERVIEW  → المقابلة الثانية
OFFERED           → عرض وظيفي
HIRED             → تم التوظيف
REJECTED          → مرفوض
WITHDRAWN         → مسحوب
```

---

## 🎯 الـ Pipeline المطلوب (8 مراحل)

```text
New
  ↓
Screening
  ↓
Shortlisted
  ↓
Interview
  ↓
Technical Test
  ↓
Final Interview
  ↓
Offer
  ↓
Hired

(Rejected can happen at any stage)
(Withdrawn can happen at any stage)
```

---

## 📋 Kanban Features

### ✅ موجود
- Drag & Drop (10 أعمدة)
- عرض matchScore, skills, experience, education, location
- أزرار نقل يمين/يسار
- إضافة ملاحظة
- تقييم سريع (4 معايير)
- عرض الملف الكامل

### ❌ ناقص
- لا bulk actions (bulk shortlist, bulk reject, bulk message)
- لا stage-specific actions (e.g., "Schedule Interview" only in INTERVIEW_INVITED)
- لا stage transition validation (لا يمكن القفز من RECEIVED إلى HIRED مباشرة)
- لا audit log لكل تغيير مرحلة (ApplicationStageChange موجود لكن غير مُعمر دائمًا)

---

## 🔒 صلاحيات تغيير المراحل

| المرحلة المستهدفة | OWNER | HR_MGR | RECRUITER | HIRING_MGR |
|------------------|-------|--------|-----------|------------|
| → UNDER_REVIEW | ✅ | ✅ | ✅ | ❌ |
| → CV_ACCEPTED | ✅ | ✅ | ✅ | ❌ |
| → INTERVIEW_INVITED | ✅ | ✅ | ✅ | ❌ |
| → FIRST_INTERVIEW | ✅ | ✅ | ✅ | ✅ (وظائفه) |
| → SECOND_INTERVIEW | ✅ | ✅ | ❌ | ✅ (وظائفه) |
| → OFFERED | ✅ | ✅ | ❌ | ❌ |
| → HIRED | ✅ | ✅ | ❌ | ❌ |
| → REJECTED | ✅ | ✅ | ✅ | ❌ |

</div>
