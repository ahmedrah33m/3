# 12 — تحليل الفجوات | Feature Gap Analysis

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 📊 جدول الفجوات

| # | الميزة | الحالة الحالية | Frontend | Backend | DB | الأولوية |
|---|--------|---------------|----------|---------|-----|---------|
| 1 | Company Registration Wizard | ❌ | ❌ | ⚠️ (مكسور) | ✅ | P0 |
| 2 | Company Verification | ❌ | ❌ | ❌ | ❌ | P0 |
| 3 | User Type Update (POST /companies) | ❌ | ✅ | ❌ (مكسور) | ✅ | P0 |
| 4 | Job Creation (مع screening) | ⚠️ | ✅ (جزئي) | ⚠️ | ❌ | P0 |
| 5 | Job Publishing | ✅ | ✅ | ✅ | ✅ | ✅ |
| 6 | CV Bank Search | ✅ | ✅ | ✅ | ✅ | ✅ |
| 7 | CV Bank Tier Check | ✅ | ✅ | ✅ | ✅ | ✅ |
| 8 | Candidate Profile (tier-gated) | ❌ | ✅ | ❌ (مكسور) | ✅ | P0 |
| 9 | Applications (apply) | ✅ | ✅ | ✅ | ✅ | ✅ |
| 10 | Applications (withdraw) | ❌ | ⚠️ (مكسور) | ❌ | ✅ | P0 |
| 11 | ATS Pipeline (Kanban) | ⚠️ | ✅ | ⚠️ (bug) | ✅ | P0 |
| 12 | Interview Scheduling | ❌ | ❌ (mock) | ❌ | ❌ | P1 |
| 13 | Interview Evaluation | ❌ | ❌ | ❌ | ❌ | P1 |
| 14 | Offer Management | ❌ | ⚠️ (mock) | ❌ | ❌ | P1 |
| 15 | Hiring + Employee Record | ❌ | ❌ | ❌ | ❌ | P1 |
| 16 | Talent Pools | ❌ | ❌ | ❌ | ❌ | P1 |
| 17 | Saved Searches + Alerts | ❌ | ❌ | ❌ | ❌ | P1 |
| 18 | Candidate Invitations | ❌ | ❌ | ❌ | ❌ | P1 |
| 19 | Candidate Comparison | ❌ | ❌ | ❌ | ❌ | P2 |
| 20 | Open to Work | ❌ | ❌ | ❌ | ✅ (user.openToWork) | P2 |
| 21 | Skill Gap Analysis | ❌ | ❌ | ❌ | ❌ | P2 |
| 22 | Verified Experience | ❌ | ❌ | ❌ | ❌ | P2 |
| 23 | Professional Passport | ❌ | ❌ | ❌ | ❌ | P2 |
| 24 | Recruitment Funnel Analytics | ⚠️ | ⚠️ | ⚠️ | ✅ | P2 |
| 25 | Iraq Talent Map | ❌ | ❌ | ❌ | ❌ | P3 |
| 26 | Skill Demand Map | ❌ | ❌ | ❌ | ❌ | P3 |
| 27 | University Integration | ❌ | ❌ | ❌ | ❌ | P3 |

---

## 🎯 ملخص الأولويات

### P0 (حرج — فوري) — 7 إصلاحات
1. ✅ Company Registration: إصلاح POST /api/companies
2. ✅ Bugfix: /api/jobs/[id]/applications ترتيب الوسائط
3. ✅ Security: /api/jobs/[id]/messages auth
4. ✅ Security: /api/jobs/[id]/share auth
5. ✅ Security: /api/candidates/[id]/profile tier check
6. ✅ Withdraw application (DELETE /api/jobs/[id]/apply)
7. ⏳ Company Registration Wizard (7 steps)

### P1 (هام — قصير المدى) — 7 إضافات
1. Interview model + API + صفحة محدّثة
2. Offer model + API + صفحة محدّثة
3. Employee model + onboarding
4. Talent Pools
5. Saved Searches + Talent Alerts
6. Candidate Invitations
7. Screening Questions في JobCreationForm

### P2 (مهم — متوسط المدى)
1. Verified Experience
2. Professional Passport
3. Open to Work
4. Skill Gap Analysis
5. Recruitment Funnel Analytics
6. Candidate Comparison

### P3 (مستقبلي — طويل المدى)
1. Iraq Talent Map
2. Skill Demand Map
3. University Integration
4. Economic Talent Index

</div>
