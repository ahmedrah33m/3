# 06 — تدقيق الـ Candidate Workflow

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 📋 الـ Candidate Profile المطلوب

```text
Personal Info (name, avatar, contact — privacy-controlled)
Professional Summary
Experience (work history)
Education
Skills (with verification status)
Languages (with proficiency)
Certificates
Projects
Portfolio (URLs)
Expected Salary
Availability (immediate / 2 weeks / 1 month)
Preferred Locations
Work Mode (onsite / remote / hybrid)
CV (PDF — with versioning)
```

---

## 🔒 Candidate Privacy Center (مطلوب)

```text
Who can see my CV?
  - Public
  - Companies only
  - Private (invitations only)
  - Hidden

Who viewed my CV?
  - List of companies/recruiters who viewed
  - Timestamp
  - How many times

Which companies saved me?
Which companies contacted me?
Which companies invited me?
```

---

## 🎯 ميزات إضافية مطلوبة

### 1. Open to Work
```text
Open to Work toggle
  - Job Types (full-time, part-time, contract, remote)
  - Locations (preferred governorates)
  - Salary Range
  - Availability date
```

### 2. Professional Passport
```text
Experience + Education + Skills + Certificates + Research + Projects
+ Articles + Recommendations + Employment History
= "Midan Professional Passport"
```

### 3. Verified Experience
```text
بعد انتهاء العمل:
  Company confirms employment period
  → تصبح "Verified Experience"
  → تظهر بشارة ✅ في الملف
```

### 4. Skill Gap Analysis
```text
إذا كان المرشح مناسبًا بنسبة 78%:
  "أنت تفي بـ 78% من متطلبات الوظيفة.
   لزيادة فرصتك:
   - Excel
   - Financial Modeling"
```

### 5. Job Recommendations
```text
للمستخدم: "Best Jobs for You"
مع تفسير: "Because your skills match, location matches, experience matches"
```

</div>
