# 03 — تدقيق الـ Workflow الكامل | Company & Recruitment Workflow

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 🔄 الـ Workflow المستهدف (End-to-End)

```text
┌─────────────────────────────────────────────────────────────────────┐
│                    MIDAN RECRUITMENT INTELLIGENCE                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Company                                                            │
│     ↓                                                                │
│  Job Creation                                                       │
│     ↓                                                                │
│  Requirements (skills, experience, education, location)             │
│     ↓                                                                │
│  Candidate Discovery (CV Bank + Matching Engine)                    │
│     ↓                                                                │
│  Matching (Match Score + Skill Gap analysis)                        │
│     ↓                                                                │
│  Shortlist (Talent Pool)                                             │
│     ↓                                                                │
│  Interview (scheduling + evaluation)                                 │
│     ↓                                                                │
│  Offer (creation + acceptance)                                       │
│     ↓                                                                │
│  Hire (employee onboarding)                                          │
│     ↓                                                                │
│  Employee (record + department + branch)                             │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📋 الـ Workflow الحالي والمشاكل

### 1. Company Registration Flow (مكسور ❌)

```text
User → /api/auth/register (userType='member')
   ↓
POST /api/companies (لا يُحدّث userType!)
   ↓
النتيجة: شركة مسجّلة لكن owner ممنوع من createJob
```

**الإصلاح:** ✅ تم — استدعاء `createCompany` من company.service.ts

### 2. Job Creation Flow (جزئي ⚠️)

```text
Company → /jobs/new (JobCreationForm)
   ↓
POST /api/jobs (createJob)
   ↓
✅ يدفع من المحفظة
✅ يدعم CompanyFreePeriod
✅ يدعم couponCode
✅ auto-publish على تيليجرام
   ↓
❌ لا screening questions
❌ لا companyId FK (String فقط)
❌ لا branchId / departmentId
❌ لا positionsCount
```

### 3. Job Publishing Flow (يعمل ✅)

```text
createJob
   ↓
✅ Job Validation (Zod schema)
✅ Payment processing
✅ Notification إرسال للمستخدمين المهتمين
✅ Telegram auto-publish
```

### 4. Candidate Discovery Flow (جزئي ⚠️)

```text
Job Published
   ↓
❌ لا يظهر "Recommended Candidates" تلقائيًا للشركة
   ↓
الشركة تبحث يدويًا في CV Bank
   ↓
✅ POST /api/cv-bank/search (مع tier check)
✅ فلاتر متقدمة (skills, experience, education, location, salary, availability)
   ↓
❌ لا saved searches
❌ لا talent alerts
❌ لا candidate invitations
❌ لا candidate comparison
```

### 5. Application Flow (يعمل ✅)

```text
Candidate → /jobs/[id] (JobDetail)
   ↓
POST /api/jobs/[id]/apply
   ↓
✅ applyToJob (verify duplicates, calculate matchScore, create applicantSnapshot)
✅ Email + WhatsApp notifications
   ↓
✅ Pipeline: RECEIVED → UNDER_REVIEW → CV_ACCEPTED → INTERVIEW_INVITED →
   FIRST_INTERVIEW → SECOND_INTERVIEW → OFFERED → HIRED
   ↓
❌ DELETE method لسحب الطلب — تم إصلاحه ✅
```

### 6. ATS Pipeline (جزئي ⚠️)

```text
✅ Kanban view يعمل (/jobs/employer/applicants/[jobId]/kanban)
✅ Drag & drop (تغيير مرحلة عبر PATCH /api/jobs/[id]/pipeline)
✅ ملاحظات داخلية (POST /api/jobs/[id]/notes)
✅ تقييم سريع (4 معايير)
   ↓
❌ 10 stages لكن لا توجد INTERVIEW model مستقلة
❌ لا توجد OFFER model مستقلة
❌ لا employee onboarding بعد HIRED
```

### 7. Interview Flow (مكسور 🔴)

```text
❌ لا يوجد /api/interviews
❌ لا يوجد Interview model في DB
   ↓
صفحة /jobs/employer/interviews:
   - 🔴 تجلب المتقدمين في مراحل INTERVIEW_*
   - 🔴 تُحقن بيانات تجريبية (demo-1, demo-2)
   - 🔴 handleComplete/handleCancel/handleSaveReschedule كلها setTimeout
   - 🔴 لا API حقيقي
```

### 8. Offer Flow (مكسور 🔴)

```text
❌ لا يوجد /api/offers
❌ لا يوجد Offer model في DB
   ↓
"العرض" = نقل المرشح لمرحلة OFFERED فقط (PATCH /api/jobs/[id]/pipeline)
   - 🔴 لا offer letter
   - 🔴 لا deadline
   - 🔴 لا تفاصيل راتب منفصلة
   - 🔴 لا توقيع/قبول رسمي
   - 🔴 لا سجل تعديلات
```

### 9. Hiring Flow (مكسور 🔴)

```text
عند النقل لـ HIRED:
   ↓
✅ يُحدّث hiredAt = new Date()
   ↓
❌ لا يوجد Employee model
❌ لا تدفق onboarding
❌ لا تعيين department/branch
❌ لا توقيع عقد
❌ لا payroll integration
```

---

## 🎯 الـ Workflow المستهدف (After Fix)

### Company → Job → Hire (End-to-End)

```text
1. Company Registration (Wizard 7 steps)
   ↓
2. Company Verification (document upload)
   ↓
3. Company Dashboard
   ↓
4. Job Creation (with screening questions)
   ↓
5. Job Publishing (with validation)
   ↓
6. Candidate Discovery
   ├── Auto: Recommended Candidates (Matching Engine)
   └── Manual: CV Bank Search
   ↓
7. Candidate Invitation (optional)
   ↓
8. Application Received
   ↓
9. ATS Pipeline
   ├── Screening (CV review)
   ├── Shortlist (Talent Pool)
   ├── Interview (scheduling + evaluation)
   ├── Technical Test
   ├── Final Interview
   └── Offer
   ↓
10. Offer Management
   ├── Create Offer (salary, benefits, deadline)
   ├── Send to Candidate
   ├── Accept / Reject / Negotiate
   └── Sign
   ↓
11. Hiring
   ├── Employee Record
   ├── Department Assignment
   ├── Branch Assignment
   ├── Manager Assignment
   └── Start Date
   ↓
12. Onboarding
   ├── Welcome Email
   ├── Document Collection
   ├── Training Plan
   └── First-day Checklist
```

---

## 📊 الـ Pipeline Stages (الموحّدة)

```text
RECEIVED         → تم الاستلام
UNDER_REVIEW     → قيد المراجعة
CV_ACCEPTED      → قبول السيرة
INTERVIEW_INVITED → دعوة للمقابلة
FIRST_INTERVIEW  → المقابلة الأولى
SECOND_INTERVIEW → المقابلة الثانية
OFFERED          → عرض وظيفي
HIRED            → تم التوظيف
REJECTED         → مرفوض
WITHDRAWN        → مسحوب
```

> **ملاحظة:** يجب توحيد هذه الترجمات في namespace i18n واحد (`pipeline.stages.*`) بدلاً من تكرارها في 4 أماكن مختلفة.

</div>
