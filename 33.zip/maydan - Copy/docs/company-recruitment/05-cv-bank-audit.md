# 05 — تدقيق بنك السير الذاتية | CV Bank Audit

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 📋 الحالة الحالية

### ✅ يعمل
- CV Bank search بفلاتر متقدمة (skills, experience, education, location, salary, availability)
- tier check (FREE/BASIC/PROFESSIONAL/ENTERPRISE)
- حفظ المرشحين + تقييم (4 معايير)
- ملاحظات داخلية على المرشحين
- سجل عمليات البحث (CvBankSearchLog)

### ❌ ناقص
- لا "Recommended Candidates" تلقائيًا عند نشر وظيفة
- لا Saved Searches
- لا Talent Alerts
- لا Candidate Invitations
- لا Candidate Comparison
- لا Talent Pools
- لا CV Versioning
- لا Smart CV Profile (استخراج بيانات من PDF)
- لا "Who viewed my CV?" للمرشح

---

## 🔒 الخصوصية (Critical)

### حالات الظهور المطلوبة
```text
PUBLIC      → ظاهر للجميع (حتى غير المسجلين)
SEARCHABLE  → ظاهر في CV Bank للشركات المشتركة
PRIVATE     → ظاهر فقط لمن ترسل لهم دعوة
HIDDEN      → غير ظاهر إطلاقًا
OPEN_TO_WORK → شارة "أبحث عن عمل"
```

### سجل المشاهدات (مطلوب)
```text
Who viewed my CV?
  - من (company/recruiter name)
  - متى (timestamp)
  - أي شركة
  - أي recruiter
```

---

## 🎯 Matching Engine المطلوب

### عوامل المطابقة
```text
Skills           (35%)
Experience       (30%)
Education        (25%)
Job Title        (10%)
Industry         (5%)
Location         (5%)
Language         (5%)
Availability     (5%)
Salary Match     (5%)
Employment Type  (5%)
Certifications   (5%)
Projects         (5%)
```

### Match Score Display
```text
✅ Matched Skills: 5/6
❌ Missing Skills: Excel, Financial Modeling
✅ Experience Match: Strong (8y required, 10y actual)
✅ Location Match: Baghdad
✅ Education Match: MSc required, MSc actual
```

### Explainability
- لا تُظهر "92% Match" فقط
- اعرض التفصيل: skills 5/6, experience strong, location match, education match

### منع التحيز
- ❌ ممنوع: Gender, Religion, Race, Ethnicity, Political views, Health data
- ✅ Audit matching algorithm للتأكد من عدم إدخال متغيرات حساسة

</div>
