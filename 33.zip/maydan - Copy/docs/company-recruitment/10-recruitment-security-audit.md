# 10 — تدقيق أمان نظام التوظيف | Recruitment Security Audit

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 🔴 الثغرات الأمنية المكتشفة (P0)

### 1. `/api/jobs/[id]/messages` POST — انتحال هوية
**المشكلة:** يقبل `senderId` من body بدون تحقق من session
**الإصلاح:** ✅ تم — استخدم `requireAuth()` و `user.id` من session

### 2. `/api/jobs/[id]/messages` GET — لا auth
**المشكلة:** أي شخص يقرأ كل رسائل المتقدمين
**الإصلاح:** ✅ تم — أضف `requireAuth()` + ownership check

### 3. `/api/jobs/[id]/share` POST/GET — لا auth
**المشكلة:** يمكن حقن سجلات مشاركة مزيفة
**الإصلاح:** ✅ تم — أضف `requireAuth()` + ownership check

### 4. `/api/candidates/[id]/profile` GET — لا tier check
**المشكلة:** أي مستخدم مسجّل يرى بيانات أي مرشح (email, phone, resume)
**الإصلاح:** ✅ تم — أضف tier check (CV Bank subscription) أو recruiter context

### 5. `/api/jobs/[id]/applications` GET — bug ترتيب الوسائط
**المشكلة:** `getJobApplications(user.id, id, ...)` يمرر userId كـ jobId → 404 دائمًا
**الإصلاح:** ✅ تم — بدّل الترتيب إلى `getJobApplications(id, user.id, ...)`

### 6. `/api/companies` POST — لا يُحدّث userType
**المشكلة:** شركة مسجّلة لكن owner لا يستطيع نشر وظائف (createJob يرفضه)
**الإصلاح:** ✅ تم — استدعاء `createCompany` من company.service.ts

### 7. `/api/jobs/[id]/apply` DELETE — غير مدعوم
**المشكلة:** صفحة candidate/applied تحاول DELETE لكن الـ route لا يدعمه → 405
**الإصلاح:** ✅ تم — أضف DELETE method + `withdrawApplication` service

---

## ⚠️ ثغرات إضافية (P1)

### 8. `/api/candidates/saved` POST — لا تحقق من userType
- أي مستخدم عادي يمكنه حفظ أي مستخدم كـ "مرشح"
- **الإصلاح المطلوب:** تحقق أن الـ saver شركة أو recruiter

### 9. Job model لا يحتوي FK إلى Company
- `Job.company` هو String فقط (اسم الشركة كنص)
- لو حُذفت Company، تبقى وظائفها بدون أصل
- **الإصلاح المطلوب:** إضافة `companyOrgId String?` كـ FK

### 10. `Company.ownerId @unique` — مالك واحد فقط
- لا يمكن للشركة أن تملك عدة recruiters
- **الإصلاح المطلوب:** إنشاء `UserCompanyRole` (Many-to-Many)

### 11. SessionUser لا يحتوي userType
- لا يمكن فحص النوع من خلال جلسة الـ route وحدها
- **الإصلاح المطلوب:** إضافة `userType` و `accountType` إلى SessionUser interface

---

## 🛡️ اختبارات IDOR المطلوبة (P1)

```text
✅ IDOR Test 1: User A يحاول تعديل وظيفة نشرها User B
   → يجب أن يُرجع 403 Forbidden

✅ IDOR Test 2: User A يحاول عرض متقدمي وظيفة نشرها User B
   → يجب أن يُرجع 403 Forbidden

✅ IDOR Test 3: User A يحاول عرض ملف مرشح لم يُقدّم على وظائفه
   → يجب أن يطلب CV Bank subscription

✅ IDOR Test 4: Recruiter من Company X يحاول عرض مرشحي Company Y
   → يجب أن يُرجع 403 Forbidden

✅ IDOR Test 5: Branch Manager يحاول عرض وظائف فرع آخر
   → يجب أن يُرجع 403 Forbidden

✅ IDOR Test 6: Candidate A يحاول سحب طلب Candidate B
   → يجب أن يُرجع 403 Forbidden
```

---

## 📋 Audit Log المطلوب

كل عملية حساسة يجب أن تُسجّل:

```text
Who: user ID + role
What: action (viewed, created, updated, deleted, status_changed)
When: timestamp
From where: IP address + user agent
Target: entity ID + type
Before: previous state (for updates)
After: new state (for updates)
```

### العمليات التي تحتاج audit log
- عرض ملف مرشح (CV view)
- تغيير مرحلة pipeline
- إنشاء/تعديل/حذف مقابلة
- إنشاء/تعديل/سحب عرض
- توظيف مرشح
- تغيير صلاحيات مستخدم في الشركة

</div>
