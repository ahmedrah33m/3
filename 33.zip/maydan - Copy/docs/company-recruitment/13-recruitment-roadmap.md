# 13 — خارطة طريق نظام التوظيف | Recruitment Roadmap

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-23

---

## 🗓️ الخطة الزمنية

### Phase 1: P0 Fixes (1-2 أسابيع)
- ✅ إصلاح 6 bugs أمنية ووظيفية (تم)
- ⏳ Company Registration Wizard (7 steps)
- ⏳ إضافة screeningQuestions لـ JobCreationForm
- ⏳ توحيد مراحل pipeline في i18n

### Phase 2: P1 Features (2-4 أسابيع)
- ⏳ Interview model + API + UI
- ⏳ Offer model + API + UI
- ⏳ Employee model + onboarding
- ⏳ Talent Pools
- ⏳ Saved Searches + Talent Alerts
- ⏳ Candidate Invitations
- ⏳ UserCompanyRole (علاقة Many-to-Many)
- ⏳ ربط permission-engine بـ routes التوظيف

### Phase 3: P2 Enhancements (4-8 أسابيع)
- ⏳ Verified Experience
- ⏳ Professional Passport
- ⏳ Open to Work
- ⏳ Skill Gap Analysis
- ⏳ Candidate Comparison
- ⏳ Recruitment Funnel Analytics
- ⏳ Bulk Actions في Kanban

### Phase 4: P3 Future (8+ أسابيع)
- ⏳ Iraq Talent Map
- ⏳ Skill Demand Map
- ⏳ University Integration
- ⏳ Economic Talent Index
- ⏳ Internship Marketplace
- ⏳ Graduate Mode

---

## 🎯 معايير القبول النهائية

```text
✓ Company registration works (wizard 7 steps)
✓ Company owner works (userType updated)
✓ Organization membership works (UserCompanyRole)
✓ Roles work (Owner/GM/HR/Recruiter/Hiring Mgr)
✓ Branch scope works
✓ Job publishing works (with screening questions)
✓ CV bank works (with tier check)
✓ Candidate matching works (with explainability)
✓ Candidate privacy works (visibility settings)
✓ Applications work (apply + withdraw)
✓ ATS works (Kanban + drag & drop)
✓ Interviews work (scheduling + evaluation)
✓ Offers work (create + accept + decline)
✓ Hiring works (employee record + onboarding)
✓ Notifications work (email + in-app + WhatsApp)
✓ Audit logs work (every sensitive action)
✓ Analytics work (funnel + time-to-hire)
✓ Mobile works (responsive)
✓ APIs are protected (IDOR-safe)
✓ No cross-company data leakage
✓ No broken links
✓ No fake buttons
```

</div>
