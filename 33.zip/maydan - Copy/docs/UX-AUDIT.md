# ميدان — تقرير تدقيق UX/UI (المرحلة 1)

- **التاريخ:** 11 آب 2026
- **النطاق:** جميع واجهات منصة ميدان — 45+ مساراً رئيسياً، ~90 صفحة، أكثر من 40 مكوّناً رئيسياً
- **المنهجية:** فحص الكود المصدري (لا اختبار حي على المتصفح) + 5 جولات تدقيق موزعة + قراءة نظام التصميم والبنية العامة
- **التصنيف:** 🔴 حرجة (تنفيذ فوري) · 🟠 عالية (قريبة) · 🟡 متوسطة · 🟢 تحسينات
- **الملاحظة:** هذا تدقيق — لم تُعدّل أي ملفات. صيغة كل مشكلة: PROBLEM / USER IMPACT / ROOT CAUSE / RECOMMENDATION / DESIGN CHANGE / FRONTEND REQUIREMENT / BACKEND REQUIREMENT / PRIORITY

---

## ملخص تنفيذي

المنصة تتمتع بنظام تصميم طموح (glass morphism + نظام ألوان قرمزي/ذهبي + دعم RTL/ثلاث لغات) وكمية ضخمة من الميزات. لكن التدقيق كشف أن المشكلة الجوهرية ليست "نقص تصميم" بل **مصداقية واتساق**:

1. **بيانات وهمية ومزيفة تُعرض كمحتوى حقيقي** في أقسام حرجة (اقتصاد، استشارات، استثمار، Landing) — أخطر مشكلة في المنصة كلها.
2. **نماذج ومدفوعات وهمية تُضيّع بيانات المستخدم** (حجز مدفوع بلا API، موعد لا يُرسل، نموذج انضمام لا يُحفظ).
3. **ازدواجية بنيوية**: نظامان بصريان (glass/shadcn)، 3 لوحات شركة، لوحات يتيمة غير مرتبطة، 49 رابطاً في القائمة.
4. **كسر في التجارب الأساسية**: روابط 404، أزرار ميتة بلا onClick، قوائم بلا حالات خطأ.
5. **RTL مكسور جزئياً** في الإدارة والترقيم، و**i18n غائب تماماً عن Landing**.

---

# 🔴 المشاكل الحرجة (P0)

## 1. بيانات وهمية تُعرض كحقيقة — اقتصاد
- **PROBLEM:** أسعار السوق والمؤشرات وتقويم الأحداث مولّدة client-side بـ `Math.random()`، و"تحليل الذكاء الاصطناعي" نص ثابت وليس تحليلاً.
- **USER IMPACT:** المستخدم يتخذ قرارات مالية/اقتصادية (شراء/بيع/استثمار) بناءً على أرقام مزيفة. تدمير كامل للثقة في المنصة الاقتصادية.
- **ROOT CAUSE:** لا توجد API خلفية للبيانات الحية، فتم "تمثيل" البيانات في الواجهة.
- **RECOMMENDATION:** إزالة كل البيانات المولّدة فوراً واستبدالها بحالات "البيانات غير متوفرة" الصادقة + بناء مصادر بيانات حقيقية (أو متأخرة/مدفوعة) تدريجياً.
- **DESIGN CHANGE:** إضافة حالة صريحة "بيانات تجريبية/غير متاحة" وتمييز أي بيانات ليست من مصدر موثوق.
- **FRONTEND REQUIREMENT:** إزالة `Math.random()`/`generateAllEvents`/`generateHistory`/`AI_ANALYSIS` الثابت وربط كل شاشة بحالة خطأ/فارغة صادقة مع CTA.
- **BACKEND REQUIREMENT:** توفير API حقيقية للأسعار/المؤشرات/التقويم (من جهات خارجية موثقة) أو إرجاع `available: false` + `lastUpdated`.
- **PRIORITY:** 🔴 P0

**الملفات:** `MarketPricesView.tsx` · `EconomicCalendarView.tsx:514` · `EconomicIndicatorsView.tsx` · `InvestmentBankView.tsx:522-523` (IRR/NPV مفبركة) · `ConsultantDashboard.tsx:44-61` (MOCK_STATS/MOCK_APPOINTMENTS)

---

## 2. بيانات وهمية ومضللة على Landing (غير المسجلة)
- **PROBLEM:** إحصائيات ثابتة تتعارض مع API الحقيقي، شهادات ومنشورات وأسعار سوق ملفّقة، عدّاد مؤتمر زائف (+15 يوماً في كل زيارة)، "مساعد ذكي" زائف يرد برسائل جاهزة ويدفع للتسجيل، وتيكر أسعار بلا مصدر.
- **USER IMPACT:** أول انطباع عن المنصة غير صادق؛ الزائر يكتشف التناقضات فيضرّ بثقة العلامة قبل التسجيل.
- **ROOT CAUSE:** Landing بُنيت كمكوّنة تسويقية ثابتة منفصلة عن بيانات المنتج.
- **RECOMMENDATION:** ربط كل رقم في Landing بـ API (LandingStats موجود أصلاً) أو إخفاؤه؛ إزالة العدّاد الزائف والـ AI الوهمي.
- **DESIGN CHANGE:** ترويسة شفافة تعرض الأرقام الحقيقية فقط.
- **FRONTEND REQUIREMENT:** استبدال الأرقام الثابتة في `landing-data.ts` والعدّاد في `landing-effects.tsx:255` ومساعد `landing-widgets.tsx:102-205` بحالة صادقة.
- **BACKEND REQUIREMENT:** توسيع `/api/landing-stats` لتشمل كل الأرقام المعروضة.
- **PRIORITY:** 🔴 P0

---

## 3. مدفوعات ونماذج وهمية تُضيّع بيانات المستخدم — الاستشارات
- **PROBLEM:** `BookingForm` (ConsultationsMarketplace:1119-1381): الدفع المدفوع `setTimeout(1500)` بلا أي API؛ `bookingDate` الذي يختاره المستخدم لا يُرسل في POST؛ نموذج "انضم كمستشار" (699-811) كل حقوله بلا `value/onChange` والزر يغلق النافذة فقط.
- **USER IMPACT:** المستخدم يدفع/يحدد موعداً/يملأ نموذجاً كاملاً ثم يضيع كل شيء بصمت — تجربة خادعة وخطيرة قانونياً (دفع وهمي).
- **ROOT CAUSE:** بناء واجهات قبل اكتمال الـ API خلفها.
- **RECOMMENDATION:** إما إكمال الـ API أو تعطيل هذه الإجراءات مع رسالة "قريباً".
- **DESIGN CHANGE:** نموذج الحجز خطوتان واضحتان (بيانات الموعد → تأكيد الدفع) مع شريط تقدم حقيقي.
- **FRONTEND REQUIREMENT:** إزالة `setTimeout` الوهمي؛ إرسال `bookingDate` فعلياً؛ تحويل "انضم كمستشار" إلى زر يستدعي API أو إزالته.
- **BACKEND REQUIREMENT:** إنشاء/استكمال endpoints للحجز المدفوع والانضمام كاستشاري؛ إرجاع `paymentUrl` أو `status: pending` حقيقي.
- **PRIORITY:** 🔴 P0

---

## 4. كسر في التجارب الأساسية — الوظائف
- **PROBLEM:** رابط `/company/${publisher.id}` في `JobDetail.tsx:702-708` (المسار الصحيح `/companies/` بصيغة الجمع) → **كل نقرة على اسم الشركة = 404**. قائمة الوظائف (`JobsPage.tsx:339`) تُسكت الأخطاء وتعرض "لا توجد وظائف" عند فشل الشبكة. الإحصائيات (:390-391) تُحسب من المحمّل حالياً فقط فتتغير كذباً مع التمرير. زر الحفظ (:245-250) مخفي حتى hover → **غير مرئي على الموبايل**.
- **USER IMPACT:** كسر مسار أساسي في أكبر قسم توظيف + معلومات مضللة + إجراء غير قابل للوصول على أكبر شريحة مستخدمين.
- **ROOT CAUSE:** مسار خاطئ + لا معالجة أخطاء + إحصائيات محلية بدل إجمالي السيرفر.
- **RECOMMENDATION:** إصلاح الرابط فوراً، إضافة ErrorState، ربط الإحصائيات بالسيرفر، جعل زر الحفظ ظاهراً دائماً.
- **FRONTEND REQUIREMENT:** تغيير `company` → `companies`؛ إضافة `isError/refetch` لـ `JobsPage`؛ جعل زر الحفظ `opacity-100` دائماً مع aria-label.
- **PRIORITY:** 🔴 P0

---

## 5. أخطاء مالية مرئية في لوحة الإدارة
- **PROBLEM:** `admin/FinanceSection.tsx:308` — الشرط يعرض أي حالة `COMPLETED` أو `PENDING_TRANSFER` (حالات نجاح) على أنها **"مرفوض"**. `admin/PaymentsSection.tsx:99-103` — زر "الاسترداد" ينادي endpoint الحظر `/api/admin/users/{userId}/ban` لتنفيذ عملية مالية.
- **USER IMPACT:** المالك يرى سحوبات ناجحة كمرفوضة، وقد يُسترد مبلغ عبر آلية حظر — خطأ مالي وأمني خطير.
- **ROOT CAUSE:** منطق حالة ناقص + إعادة استخدام endpoint غير مناسب.
- **RECOMMENDATION:** خريطة حالات كاملة؛ إنشاء endpoint استرداد مستقل.
- **FRONTEND REQUIREMENT:** تحديث دالة عرض الحالة لتشمل كل الحالات؛ إزالة استدعاء ban للاسترداد.
- **BACKEND REQUIREMENT:** إنشاء `POST /api/payments/{id}/refund` مع صلاحيات مناسبة.
- **PRIORITY:** 🔴 P0

---

## 6. Landing بلا i18n إطلاقاً + HTML/SEO ثابت
- **PROBLEM:** كل أقسام `src/components/landing/**` عربية مكتوبة حرفياً (لا `useI18n`)، والـ root layout `<html lang="ar" dir="rtl">` ثابت SSR + Metadata عربية فقط بلا `alternates`.
- **USER IMPACT:** تبديل اللغة للإنجليزية يترك Landing عربياً كاملاً؛ محركات البحث ترى اللغة العربية فقط رغم ادعاء 3 لغات.
- **ROOT CAUSE:** Landing مبنية خارج نظام i18n.
- **RECOMMENDATION:** دمج Landing في `useI18n` + إنتاج Metadata ديناميكية.
- **DESIGN CHANGE:** توفير نظام نصوص ثنائي/ثلاثي بنفس جودة بقية التطبيق.
- **FRONTEND REQUIREMENT:** استبدال النصوص الصلبة بمفاتيح `t.landing.*` (توسيع `i18n`).
- **PRIORITY:** 🔴 P0

---

## 7. Azرار ميتة بلا أي onClick
- **PROBLEM:** زر "حفظ الملف" `InvestmentBankView.tsx:1066` بلا `onClick` إطلاقاً؛ أزرار Share/Quiz `EconomicDictionaryView.tsx:326-328,588-591`؛ Export/Share/Notification `EconomicCalendarView.tsx:1336-1347`؛ "شحن"/"سحب" في المحفظة بالملف الشخصي `profile/ProfileTabs.tsx:346-351`؛ "اشترك الآن" `:331`.
- **USER IMPACT:** أزرار وهمية تخلق شعوراً بمنتج معطل وتهز الثقة.
- **RECOMMENDATION:** لكل زر: إما تنفيذ الفعل أو حذفه أو تعطيله مع تلميح.
- **FRONTEND REQUIREMENT:** ربط أو إزالة كل الأزرار الميتة المذكورة.
- **PRIORITY:** 🔴 P0

---

# 🟠 المشاكل العالية (P1)

## 8. تضخم التنقل (Information Architecture)
- **PROBLEM:** Sidebar فيها **49 رابطاً** (مع 8 روابط مكررة داخلياً: cv-builder، wallet×3، premium، learn، bookmarks، discussions)؛ `MobileNavDrawer` يعيد بناء ~40 رابطاً بمصدر قائمة منفصل تماماً (يتفلتان بسهولة)؛ `MobileBottomNav` 5 عناصر فقط لا تغطي الخبراء/النقاشات/الوظائف؛ قسمان مفتوحان افتراضياً يظهران 24 رابطاً دفعة واحدة.
- **USER IMPACT:** شلل اختيار؛ صعوبة إيجاد ركائز المنصة؛ صيانة مزدوجة تكسر الاتساق.
- **ROOT CAUSE:** نمو لا يُدار — كل ميزة تضيف رابطاً.
- **RECOMMENDATION:** إعادة هيكلة: تجميع روابط الأعمال (وظائف/سوق/استشارات/استثمار) في فئة واحدة "خدمات" قابلة للتوسع + إعادة ترتيب الأولويات + مصادر قائمة موحّدة (مصفوفة nav واحدة يستهلكها Sidebar و Drawer و BottomNav).
- **DESIGN CHANGE:** بنية تنقل: 6 فئات قصوى، كل فئة ≤ 7 روابط، جميعها مطوية افتراضياً.
- **FRONTEND REQUIREMENT:** إنشاء `src/lib/navigation.ts` كمصدر وحيد للقوائم وربط المكونات الثلاثة به؛ إزالة التكرارات.
- **PRIORITY:** 🟠 P1

## 9. لوحات شركة متوازية + بوابات يتيمة
- **PROBLEM:** 3 تطبيقات لنفس اللوحة: `/company-dashboard` (مرتبط)، `/jobs/dashboard` (يتيم)، `/jobs/employer/**` (6 صفحات بلا أي رابط إليها). بوابات المرشح `/jobs/candidate/**` (6 صفحات) **غير مرتبطة من أي مكان**. `CompanyDashboard` مكررة بهويتين بصريتين كاملتين (`src/components/CompanyDashboard.tsx` vs `src/components/jobs/CompanyDashboard.tsx`، مع `confirm()` أصلي و`dir="rtl"` صلب وtypo "المختكورون").
- **USER IMPACT:** المستخدم لا يصل لبوابات جاهزة؛ كل تباين بين النسخ يصيب المستخدم؛ حذف وظيفة عبر confirm أصلي بلا حماية.
- **ROOT CAUSE:** نمو متوازٍ بدون توحيد.
- **RECOMMENDATION:** اختيار بوابة واحدة (يفضّل `/jobs/employer/**` الحديثة) وربطها بالقائمة، ونقل القديمة للأرشفة.
- **FRONTEND REQUIREMENT:** توحيد المسارات + حذف النسخ المتعارضة + استبدال confirm بـ DeleteDialog.
- **PRIORITY:** 🟠 P1

## 10. تسميات ووجهات متضاربة
- **PROBLEM:** "الرسائل" في BottomNav → `/chat-rooms` بينما أيقونة الرسائل في Navbar → `/messages` (وجهتان لنفس الاسم وشارة unread ملتصقة بالخاطئ). تسميات بحث: "البحث المتقدم"/"فلاتر متقدمة" (Sidebar/Drawer) مقابل "بحث" (BottomNav). ترجمات تعرض نص الحالة بدل فعل الإجراء (`DashboardView.tsx:448-463`)، و`cards.tsx:223` تستخدم `mp.nearYou` كشارة isUrgent.
- **USER IMPACT:** ارتباك ثقة في وجهة الأيقونة والتسمية.
- **RECOMMENDATION:** مواءمة التسميات/الوجهات في مصفوفة navigation الموحدة.
- **FRONTEND REQUIREMENT:** تصحيح الروابط والتسميات والمفاتيح الخاطئة.
- **PRIORITY:** 🟠 P1

## 11. نوافذ منبثقة يدوية بلا إتاحة
- **PROBLEM:** `ExpertMarketplaceView.tsx:1439-1758` و`EconomicIndicatorsView.tsx:286` تستخدم `fixed inset-0` يدوي بدل `Dialog` — بلا `role="dialog"`/`aria-modal`/Escape/قفل تركيز.
- **USER IMPACT:** مستخدمو لوحة المفاتيح وقارئات الشاشة لا يمكنهم إغلاق/التنقل؛ تجربة متعثرة.
- **RECOMMENDATION:** استبدالها بـ `Dialog` الموحد.
- **FRONTEND REQUIREMENT:** استبدال الـ overlays اليدوية في الملفين.
- **PRIORITY:** 🟠 P1

## 12. حالات الخطأ المفقودة (ثغرات محددة)
- **PROBLEM:** `MidanAcademyView` (4 استعلامات: courses/stats/quizzes/certificates) بلا أي `isError`/`ErrorState` إطلاقاً (أكده الفحص المباشر)؛ `CurrencyConverter` بلا تحميل/خطأ؛ `MapView:177` خطأ بلا retry + عربي صلب؛ `PaidServicesCard:116` فشل الجلب يظهر كـ "لا توجد خدمات".
- **USER IMPACT:** فشل الشبكة يظهر كمنتج فارغ أو شاشة ميتة.
- **RECOMMENDATION:** إكمال حالة `isError/refetch` لكل query.
- **FRONTEND REQUIREMENT:** تطبيق نفس نمط ErrorState الموزّع في بقية المشروع.
- **PRIORITY:** 🟠 P1

## 13. RTL مكسور في الإدارة
- **PROBLEM:** أسهم طيّ السايدبار متعاكسة بين `AdminPanel:595-597` (collapsed?ChevronRight:ChevronLeft) و`OwnerPanel:289-291` (isRTL?ChevronLeft:ChevronRight) — أحدها معكوس دائماً؛ ترقيم صفحات admin بأسهم LTR بلا قلب (`admin/UsersSection.tsx:254,266`، `ReportedContent:619-623`، `FlaggedContentManager:623-629`) بينما `owner/*` تقلب صحيحاً؛ `jobs/CompanyDashboard.tsx:1685` `dir="rtl"` صلب.
- **USER IMPACT:** أسهم "السابق/التالي" تشير للاتجاه الخاطئ حسب الشاشة.
- **RECOMMENDATION:** قاعدة واحدة: "السابق = `isRTL ? ChevronRight : ChevronLeft`" و"التالي = معكوسه".
- **FRONTEND REQUIREMENT:** توحيد الاتجاه في الملفات الخمسة + إزالة dir الصلب.
- **PRIORITY:** 🟠 P1

## 14. دلالة ألوان اتجاه السعر معكوسة
- **PROBLEM:** الارتفاع أحمر في `CurrencyConverter:104,112,230` و`MarketPricesView` و`EconomicCalendarView`، لكنه أخضر في KPI ملخص `EconomicIndicatorsView:162` — نفس المفهوم بلونين.
- **USER IMPACT:** قراءة خاطئة لاتجاه الأسعار عند التنقل بين الشاشات.
- **RECOMMENDATION:** قاعدة واحدة (in Iraqi context، الرقم السالب أخضر/الموجب أحمر؟) تُعتمد عالمياً.
- **FRONTEND REQUIREMENT:** تثبيت خريطة ألوان موحدة في `globals.css` واستخدامها في كل الشاشات.
- **PRIORITY:** 🟠 P1

## 15. dark mode معطوب في قوالب كاملة
- **PROBLEM:** `ExpertMarketplaceView.tsx:902,905` (`bg-white` + gray-*) و`EconomicDictionaryView.tsx` (`slate-50/blue-50/gray-100`) و`candidate/offers/page.tsx:98-100` (Hex `#D4A853`) — ألوان صلبة تتجاوز الوضع الداكن.
- **USER IMPACT:** ومضات ساطعة/أجزاء مكسورة في dark mode.
- **RECOMMENDATION:** استبدال الألوان الصلبة بـ tokens.
- **FRONTEND REQUIREMENT:** توحيدها على `bg-card`/`bg-muted`/tokens.
- **PRIORITY:** 🟠 P1

## 16. جلسة استشارة وهمية (مصداقية الخدمة المدفوعة)
- **PROBLEM:** `ConsultationSession.tsx`: فيديو placeholder (360-364)، رفع ملف يضيف `document_N.pdf` وهمياً (189)، تقييم بلا معالج (243-249)، والدخول مسموح عند فشل `/session-status` (85-88) — لجلسة مدفوعة هذا تساهل.
- **USER IMPACT:** المستخدم يدفع لجلسة ثم يكتشف أنها محاكاة.
- **RECOMMENDATION:** إما WebRTC فعلي أو إخفاء ميزات الجلسة حتى تكتمل.
- **FRONTEND REQUIREMENT:** إزالة المحاكاة أو تعطيل الميزات غير الجاهزة مع رسالة صادقة.
- **PRIORITY:** 🟠 P1

---

# 🟡 المشاكل المتوسطة (P2)

## 17. أزرار بلا حالات تحميل/تعطيل
- **PROBLEM:** نماذج الحجز/الاستشارة في `ExpertMarketplaceView` بلا loading أثناء الإرسال؛ أزرار +/- في `DetailViews.tsx:252-254` بلا aria-label وبلا حد أقصى مقابل المخزون؛ إجراءات في `DashboardView:647,748,394` تُبتلع أخطاؤها.
- **USER IMPACT:** نقر مزدوج، وصفّ غير محدود، فشل صامت.
- **FRONTEND REQUIREMENT:** إضافة `isLoading/disabled` لكل أزرار الإرسال + تعامل مع الأخطاء.
- **PRIORITY:** 🟡 P2

## 18. الفلترة بعد الترقيم
- **PROBLEM:** `ConsultationsMarketplace.tsx:296-300` فلاتر `verified/free` تطبَّق client-side بعد pagination سيرفرية → نتائج غير متسقة عبر الصفحات؛ `InvestmentBankView` لا واجهة ترقيم رغم `limit=20` — أول 20 فقط يظهرون دائماً؛ تبويب "مشاريع معوقة/الشراكات" (1244-1248) يعرض نفس بيانات ACTIVE.
- **USER IMPACT:** المستخدم لا يرى كل النتائج أو يراها مكررة.
- **BACKEND REQUIREMENT:** نقل الفلترة للـ API + ترقيم حقيقي + فلاتر حالة لكل تبويب.
- **PRIORITY:** 🟡 P2

## 19. إمكانية الوصول (Accessibility)
- **PROBLEM:** خطوط `text-2xs`/`text-[8px]`/`text-[9px]` منتشرة في ~10 ملفات (Investments:1017-1349، cards.tsx، DetailViews)؛ أفعال hover-only (`opacity-0 group-hover:opacity-100` في DashboardView:365)؛ أزرار أيقونات بلا aria-label (مصغرات المعرض DetailViews:38-45، أزرار الجرس)؛ `window.confirm` أصلي (DashboardView:931، CompanyDashboard×2)؛ `toLocaleString('en-US')` بلا locale.
- **USER IMPACT:** مستخدمو قارئات الشاشة واللمس والتباين المنخفض معزولون.
- **FRONTEND REQUIREMENT:** تقنين أحجام الخطوط (min 12px)، إزالة الـ hover-only، aria-label شامل، استبدال confirm بـ Dialog، locale-aware formatting.
- **PRIORITY:** 🟡 P2

## 20. تقارير الصفحات الضخمة أحادية الملف
- **PROBLEM:** `ExpertMarketplaceView.tsx` (1758 سطراً)، `CompanyDashboard.tsx` (1752)، `InvestmentBankView.tsx` (1368)، `DashboardView.tsx` (1211)، `wallet/page.tsx` (1144)، `CVBuilder.tsx` — إدارة الحالة والتنقل بالتبويب في ملف واحد.
- **USER IMPACT:** صعوبة صيانة تؤدي لبطء التطوير وتراكم الأخطاء.
- **FRONTEND REQUIREMENT:** تقسيم تدريجي لمكوّنات فرعية (خطة في `docs/refactor.md`).
- **PRIORITY:** 🟡 P2

## 21. ازدواج مكوّنات بنفس الوظيفة
- **PROBLEM:** `PollComponent.tsx` مقابل نسخة في `PollsView.tsx`؛ `MidanAcademyView` مقابل `education/LearningPaths.tsx`/`Quizzes.tsx`/`EconomicDictionary.tsx`؛ `EmptyState` في `components/EmptyState.tsx` مقابل `ui/feedback-state.tsx`؛ `DiscussionDetail.tsx` يستورد Share2/Bookmark/ThumbUp/Flag ولا يعرضها.
- **USER IMPACT:** هويات بصرية مختلفة لنفس العنصر + ميزات ميتة.
- **FRONTEND REQUIREMENT:** توحيد المكوّنات أو توثيق legacy-vs-new + تفعيل/حذف الأيقونات الميتة.
- **PRIORITY:** 🟡 P2

## 22. أرقام/عربات وأخطاء إملائية في البيانات
- **PROBLEM:** "رmelissa southern"، "كرموك وكركوك"، "يئة الاحصاء العراقية"، "قطاع ال خدمات مالية"، أحرف صينية، "التميثل"، "المختكورون"، "ارتفاع Temperatures".
- **USER IMPACT:** ظهور نصوص مكسورة في واجهة عامة يهز الثقة.
- **RECOMMENDATION:** فحص البيانات المزروعة وتنظيفها.
- **PRIORITY:** 🟡 P2

## 23. ترويسات أقسام بتدرجات متعددة
- **PROBLEM:** كل صفحة تختار لون hero مختلفاً (برتقالي للأحداث، نيلي للبحث، بنفسجي للإنجازات، زمردي للقاموس) + badges/accordions بلوحة من 8 ألوان مختلفة.
- **USER IMPACT:** فقدان الهوية الموحدة؛ فوضى لونية.
- **RECOMMENDATION:** خريطة ألوان ثانوية معتمدة (قرمزي رئيسي + ذهبي + 3-4 ألوان وظيفية فقط).
- **FRONTEND REQUIREMENT:** تقييد استخدام badge-economy/education/community... بلوحة موحدة.
- **PRIORITY:** 🟡 P2

## 24. أكورديون Landing المعاد إنشاؤه لا يستخدم نظام الـ tabs
- **PROBLEM:** `ConsultationsMarketplace` نموذج "انضم كمستشار" ونوافذ بدون Dialog؛ `TabsTrigger` في InvestmentBank يستدعي `setView` بلا TabsContent.
- **FRONTEND REQUIREMENT:** استخدام أنظمة ui/ الموحدة.
- **PRIORITY:** 🟡 P2

---

# 🟢 التحسينات (P3)

## 25. أداء Landing
- **PROBLEM:** 80 جسيماً بحلقات O(n²) لكل فريم + 4 كتل blur-3xl بحجم 50vw + 3 marquees + عدّاد كل ثانية + مستمعا تمرير + TiltCard 3D.
- **FRONTEND REQUIREMENT:** تعطيل canvas المتحرك خارج viewport، خفض عدد الجسيمات، استبدال blur كبيرة بـ tokens أرخص، إزالة marquees المتعددة.
- **PRIORITY:** 🟢 P3

## 26. CSS غير صالح
- **PROBLEM:** `linear-gradient(to inline-end, ...)` في **9 أسطر** بـ `globals.css` (819, 881, 890, 899, 908, 917, 926, 935, 944) — صيغة غير صحيحة تُتجاهل صامتاً؛ `bg-gradient-to-e` غير صالحة في CvBankPage.
- **FRONTEND REQUIREMENT:** تصحيح إلى `to left`/`to right` أو logical عبر `@apply` مع `dir`.
- **PRIORITY:** 🟢 P3

## 27. ازدواج الـ ThemeToggle في الصفحة الرئيسية
- **PROBLEM:** `src/app/page.tsx:79,145` يستخدم `fixed bottom-4 left-4` بينما `(main)/layout.tsx:75` يستخدم `start-4` — يتعاكسان في RTL.
- **FRONTEND REQUIREMENT:** توحيد على `start-4`.
- **PRIORITY:** 🟢 P3

## 28. صور بدون fallback
- **PROBLEM:** `ImageWithFallback.tsx` بلا `onError`؛ `alt` متعارضة (Receipt بالعربي).
- **FRONTEND REQUIREMENT:** إضافة fallback موحّد + alt عربية صحيحة.
- **PRIORITY:** 🟢 P3

---

# أمثلة إيجابية تُحتذى (ما يجب الحفاظ عليه)

- **`wallet/page.tsx`**: أنظف صفحة في المشروع — GlassCard + Skeleton + Dialog صحيح + تعطيل أزرار أثناء الإرسال + ترقيم RTL-aware.
- **مسارات marketplace `[id]`**: server components مع `generateMetadata` + JSON-LD + notFound — أفضل نمط SEO.
- **`DashboardView`/`DetailViews`/`RequestsViews`**: استخدام موحد لـ ErrorState + SkeletonGrid + EmptyBlock مع useQuery/staleTime.
- **`admin/AuditLog.tsx`**: بحث سيرفر + Ctrl+K + فلاتر + تصدير CSV — معيار لوحات الإدارة.
- **أنظمة RTL في `ExpertMarketplaceView:907`، `InvestmentBankView:459`، `CVBuilder:551`**: نماذج صحيحة للقلب.
- **`AIAssistantView`**: i18n موحد + حالات فارغة واضحة + معالجة أخطاء.

---

# خارطة الطريق المقترحة

| المرحلة | المحتوى | الحجم |
|---|---|---|
| **1. النزاهة (مصداقية)** | إزالة كل البيانات الوهمية + الأزرار الميتة + إصلاح الروابط 404 + المدفوعات الوهمية | 5 أيام |
| **2. اتساق الهوية** | توحيد glass/shadcn، إصلاح dark mode، خريطة الألوان، الخطوط | 4 أيام |
| **3. التنقل** | مصفوفة navigation موحدة، تقليص 49→~30 رابطاً، ربط البوابات، إصلاح RTL الإداري | 3 أيام |
| **4. حالات النظام** | استكمال ErrorState/EmptyState، توحيد الصفحات القديمة | 3 أيام |
| **5. i18n Landing** | نقل Landing لنظام الترجمة + Metadata ديناميكية | 2 أيام |
| **6. توحيد البنية** | تقسيم الملفات الضخمة، إزالة الازدواجيات | مستمر |

---

*ملاحظة منهجية: التدقيق بالكود المصدري فقط. بعض الملفات الضخمة قُرئت جزئياً — أي شاشة غير مغطاة بالكامل ستُدرج عند اللمس. يُنصح بجولة تحقق بصرية على المتصفح (Desktop 1440 + Mobile 390) لتأكيد النتائج.*
