# 06 — معمارية API | API Architecture

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §26 (قواعد API) و §31 (الأداء)

---

## 🎯 الهدف

توحيد بنية API في منصة ميدان لتحقيق:
- **Consistency**: شكل استجابة موحّد
- **Security**: Authentication + Authorization + Validation في كل route
- **Performance**: caching, pagination, rate-limiting
- **Observability**: logging + metrics لكل طلب
- **Versioning**: استراتيجية ترقيم واضحة

---

## 📊 الحالة الحالية

| المؤشر | القيمة | التقييم |
|--------|--------|---------|
| مسارات API (`route.ts`) | 411 | ضخم |
| مجموعات API | 89 | عالي |
| متوسط routes/مجموعة | 4.6 | جيد |
| Endpoints تستخدم Zod | ~70% | يحتاج تحسين |
| Endpoints بـ rate-limiting | ~30% | يحتاج تحسين |
| Endpoints بـ caching | ~20% | منخفض |
| Endpoints بـ structured logging | ~40% | متوسط |
| API versioning | ❌ غير موجود | مطلوب |
| Unified response shape | ❌ غير موجود | مطلوب |
| OpenAPI/Swagger | جزئي (`/api-docs.html`) | يحتاج تجديد |

---

## 🏗️ المجموعات الحالية (89 مجموعة)

```text
src/app/api/
├── academy/                 # 8 routes
├── achievements/            # 3
├── activity-log/             # 2
├── admin/                    # 40+ routes (تتداخل مع owner)
├── ads/                      # 5
├── advertiser/               # 3
├── ai/                       # 8 (موزّعة على /ai و /economy/ai و /ai-assistant)
├── analytics/                # 4
├── articles/                 # 15+ (CRUD, promote, like, comment, etc.)
├── assessment/               # 3
├── auth/                     # 12 (login, register, 2FA, OAuth, reset, verify)
├── bookmarks/                # 3
├── cache/                    # 2
├── candidates/               # 4
├── chat-rooms/               # 6 (تتداخل مع messages)
├── comments/                 # 4
├── commissions/              # 3
├── communities/              # 5
├── companies/                # 6
├── company/                  # 4
├── company-reviews/          # 3
├── connections/              # 4
├── consultations/            # 8
├── coupons/                  # 3
├── cv-bank/                  # 3
├── cv-builder/               # 3
├── cv-service/               # 3
├── dashboard/                # 4
├── debug/                    # 2 (dev only)
├── dictionary/               # 3
├── discussions/              # 8
├── download/                 # 2
├── economic/                 # 4
├── economy/                  # 10+
├── education/                # 5 (يتداخل مع academy)
├── errors/                   # 2
├── events/                   # 3
├── expert-market/            # 5
├── expert-verification/      # 3
├── feed/                     # 3
├── finance/                  # 4
├── follows/                  # 3
├── hashtags/                 # 3
├── health/                   # 1
├── images/                   # 3
├── investment-bank/          # 4
├── iraq-map/                 # 3
├── jobs/                     # 10+
├── landing-stats/            # 2
├── leaderboard/              # 2
├── likes/                    # 3
├── map/                      # 2
├── marketplace/              # 15+
├── mentorship/               # 4
├── messages/                 # 6
├── moderation/               # 5
├── notifications/            # 5 (SSE)
├── owner/                    # 20+ (يتداخل مع admin)
├── payment/                  # 3
├── payment-destination/      # 2
├── payment-gateways/         # 3
├── payment-info/             # 2
├── payments/                 # 5
├── polls/                    # 4
├── posts/                    # 8
├── pricing/                  # 2
├── professional-profile/     # 3
├── promote/                  # 2
├── push/                     # 3
├── questions/                # 8
├── recommendations/          # 3
├── referrals/                # 3
├── reports/                  # 3
├── reposts/                  # 2
├── reputation/               # 3
├── research/                 # 4
├── route.ts                  # 1 (root)
├── search/                   # 4
├── security/                 # 4
├── seed/                     # 2 (dev only)
├── settings/                 # 3
├── subscription/             # 2
├── subscriptions/            # 4
├── translate/                # 2
├── tts/                      # 2
├── u/                        # 3 (users short)
├── uploads/                  # 4
├── users/                    # 20+
├── wallet/                   # 6
└── ... (89 مجموعات)
```

---

## 🎯 المعايير الموحّدة المطلوبة

### 1. Response Shape (Unified)

**المطلوب:**
```typescript
// نجاح
{
  "success": true,
  "data": T,
  "meta"?: {
    "page": number,
    "limit": number,
    "total": number,
    "hasMore": boolean
  }
}

// فشل
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR" | "UNAUTHORIZED" | "FORBIDDEN" | "NOT_FOUND" | "CONFLICT" | "RATE_LIMITED" | "INTERNAL_ERROR",
    "message": string,
    "details"?: Record<string, any>
  },
  "requestId": string
}
```

**الحالة الحالية:** ❌ غير موحّد. بعض الـ routes تُرجع البيانات مباشرة، بعضها `{ data }`، بعضها `{ success, data }`.

**الإصلاح:** إنشاء `src/lib/api-response.ts` موحّد.

### 2. Validation (Zod Schemas)

**المطلوب:**
```typescript
// src/lib/validation/article.ts
export const createArticleSchema = z.object({
  title: z.string().min(5).max(200),
  summary: z.string().max(500).optional(),
  content: z.string().min(50),
  category: z.enum(['ANALYSIS', 'REPORT', 'STUDY', 'OPINION', 'NEWS', 'RESEARCH']),
  tags: z.array(z.string()).max(10).optional(),
})

export type CreateArticleInput = z.infer<typeof createArticleSchema>
```

**الاستخدام:**
```typescript
export async function POST(request: Request) {
  const user = await requireAuth()
  
  const body = await request.json().catch(() => null)
  const parsed = createArticleSchema.safeParse(body)
  if (!parsed.success) {
    return apiValidationError(parsed.error.flatten())
  }
  
  // ... المتابعة
}
```

### 3. Authentication & Authorization

**Pattern موحّد:**
```typescript
import { requireAuth } from '@/lib/session'
import { checkPermission } from '@/lib/permission-engine'
import { apiSuccess, apiError } from '@/lib/api-response'
import { z } from 'zod'

export async function POST(request: Request) {
  // 1. Authentication
  const user = await requireAuth()
  
  // 2. Authorization (RBAC + Scope)
  const { allowed, reason } = await checkPermission(
    { userId: user.id, globalRole: user.role, contextualRoles: user.contextualRoles },
    'article', 'create'
  )
  if (!allowed) {
    return apiError('FORBIDDEN', 'لا تملك صلاحية إنشاء مقال', { reason })
  }
  
  // 3. Validation
  const body = await request.json().catch(() => null)
  const parsed = createArticleSchema.safeParse(body)
  if (!parsed.success) {
    return apiValidationError(parsed.error.flatten())
  }
  
  // 4. Rate limiting (handled in middleware, but can be specific)
  // 5. Business logic
  const article = await articleService.create(user.id, parsed.data)
  
  // 6. Logging
  logger.info('article.created', { userId: user.id, articleId: article.id })
  
  // 7. Response
  return apiSuccess(article, 201)
}
```

### 4. Pagination

**موحّد:**
```typescript
// Query params: ?page=1&limit=20&sort=-createdAt&search=keyword

// Response meta:
{
  "data": [...],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 153,
    "totalPages": 8,
    "hasMore": true,
    "nextPage": 2
  }
}
```

**Cursor pagination (للـ feeds):**
```typescript
// ?cursor=eyJpZCI6ImFiYzEyMyJ9&limit=20
// Response:
{
  "data": [...],
  "meta": {
    "limit": 20,
    "hasMore": true,
    "nextCursor": "eyJpZCI6Inh5ejQ1NiJ9"
  }
}
```

### 5. Rate Limiting (Multi-tier)

| Tier | Endpoint Type | Limit |
|------|--------------|-------|
| Public | `/api/auth/*`, `/api/articles` (GET) | 100 req/min |
| Authenticated | GET endpoints | 60 req/min per user |
| Authenticated | POST/PUT/DELETE | 20 req/min per user |
| Sensitive | `/api/wallet/withdraw`, `/api/payments` | 5 req/min per user |
| Heavy | `/api/ai/*`, `/api/search` | 10 req/min per user |
| Upload | `/api/uploads` | 20 req/hour per user |

### 6. Caching Strategy

```typescript
// GET endpoints caching
// 1. Public data (articles, jobs, indicators): cache 60s
// 2. User-specific (dashboard): cache 5s
// 3. Authenticated lists: no cache

// Example:
export async function GET(request: Request) {
  const cacheKey = `articles:page:${page}:limit:${limit}`
  const cached = await cache.get(cacheKey)
  if (cached) return apiSuccess(cached)
  
  const articles = await articleService.list({ page, limit })
  await cache.set(cacheKey, articles, 60) // 60s TTL
  
  return apiSuccess(articles)
}
```

### 7. Error Codes (Standardized)

```typescript
// src/lib/api-response.ts
export const API_ERRORS = {
  VALIDATION_ERROR:     { status: 400, code: 'VALIDATION_ERROR' },
  UNAUTHORIZED:         { status: 401, code: 'UNAUTHORIZED' },
  FORBIDDEN:            { status: 403, code: 'FORBIDDEN' },
  NOT_FOUND:            { status: 404, code: 'NOT_FOUND' },
  METHOD_NOT_ALLOWED:   { status: 405, code: 'METHOD_NOT_ALLOWED' },
  CONFLICT:             { status: 409, code: 'CONFLICT' },
  RATE_LIMITED:         { status: 429, code: 'RATE_LIMITED' },
  INTERNAL_ERROR:       { status: 500, code: 'INTERNAL_ERROR' },
  SERVICE_UNAVAILABLE:  { status: 503, code: 'SERVICE_UNAVAILABLE' },
  BAD_GATEWAY:          { status: 502, code: 'BAD_GATEWAY' },
} as const
```

---

## 🔧 Helper Library الموحّدة

### `src/lib/api-response.ts`

```typescript
import { NextResponse } from 'next/server'

// Types
export interface ApiSuccessResponse<T> {
  success: true
  data: T
  meta?: PaginationMeta
}

export interface ApiErrorResponse {
  success: false
  error: {
    code: string
    message: string
    details?: Record<string, any>
  }
  requestId: string
}

export interface PaginationMeta {
  page: number
  limit: number
  total: number
  totalPages: number
  hasMore: boolean
  nextPage?: number
}

// Helpers
export function apiSuccess<T>(data: T, status: number = 200, meta?: PaginationMeta): NextResponse {
  return NextResponse.json(
    { success: true, data, ...(meta ? { meta } : {}) },
    { status }
  )
}

export function apiError(
  code: keyof typeof API_ERRORS,
  message: string,
  details?: Record<string, any>,
  requestId?: string
): NextResponse {
  const errorConfig = API_ERRORS[code]
  return NextResponse.json(
    {
      success: false,
      error: { code: errorConfig.code, message, details },
      requestId: requestId || crypto.randomUUID(),
    },
    { status: errorConfig.status }
  )
}

export function apiValidationError(issues: any[]): NextResponse {
  return NextResponse.json(
    {
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: 'البيانات غير صحيحة',
        details: { issues },
      },
      requestId: crypto.randomUUID(),
    },
    { status: 400 }
  )
}

export function paginate<T>(items: T[], total: number, page: number, limit: number): PaginationMeta {
  const totalPages = Math.ceil(total / limit)
  return {
    page,
    limit,
    total,
    totalPages,
    hasMore: page < totalPages,
    nextPage: page < totalPages ? page + 1 : undefined,
  }
}
```

### `src/lib/api-handler.ts` — Wrapper لتبسيط

```typescript
type ApiHandler = (request: Request, context?: any) => Promise<NextResponse>

export function withAuth(handler: ApiHandler): ApiHandler {
  return async (request, context) => {
    try {
      const user = await requireAuth()
      // Attach user to request for handler
      ;(request as any).user = user
      return handler(request, context)
    } catch (error) {
      if (error instanceof AuthError) {
        return apiError('UNAUTHORIZED', error.message)
      }
      return apiError('INTERNAL_ERROR', 'خطأ غير متوقع')
    }
  }
}

export function withPermission(resource: string, action: string) {
  return function(handler: ApiHandler): ApiHandler {
    return withAuth(async (request, context) => {
      const user = (request as any).user
      const { allowed, reason } = await checkPermission(
        { userId: user.id, globalRole: user.role, contextualRoles: user.contextualRoles },
        resource, action
      )
      if (!allowed) {
        return apiError('FORBIDDEN', 'لا تملك صلاحية', { reason })
      }
      return handler(request, context)
    })
  }
}

// Usage:
export const POST = withPermission('article', 'create')(async (request) => {
  const user = (request as any).user
  // ... business logic
})
```

---

## 🗂️ API Versioning Strategy

**النهج المختار:** Prefix-based versioning

```text
/api/v1/articles     ← الحالي (افتراضي)
/api/v2/articles     ← مستقبلاً عند breaking changes
/api/articles        ← backward-compatible alias لـ v1
```

**التطبيق:**
- لا حاجة لإعادة كتابة كل الـ routes فورًا
- إضافة `version` header اختياري
- عند الحاجة لـ v2، يتم إنشاء `/api/v2/*` مع نفس الـ handlers المعدّلة
- v1 تُحفظ لمدة 6 أشهر على الأقل بعد إطلاق v2

---

## 📋 Documenting APIs (OpenAPI)

**المطلوب:** توليد `openapi.json` تلقائيًا من Zod schemas.

```typescript
// scripts/generate-openapi.ts
import { writeFileSync } from 'fs'
import { zodToJsonSchema } from 'zod-to-json-schema'

const schemas = {
  createArticle: createArticleSchema,
  // ... كل الـ schemas
}

const openapi = {
  openapi: '3.0.3',
  info: { title: 'Maydan API', version: '1.0.0' },
  paths: { /* extracted from routes */ },
  components: { schemas: /* from zod */ },
}

writeFileSync('docs/openapi.json', JSON.stringify(openapi, null, 2))
```

**الناتج:** صفحة `/api-docs` محدّثة تلقائيًا.

---

## 🔄 Unified Search API (مقترح)

```typescript
// GET /api/search?q=keyword&type=article|job|user|service|product&page=1&limit=20

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const q = searchParams.get('q') || ''
  const type = searchParams.get('type') || 'all'
  const page = parseInt(searchParams.get('page') || '1')
  const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 50)
  
  if (q.length < 2) {
    return apiError('VALIDATION_ERROR', 'الاستعلام قصير جدًا')
  }
  
  const results = await searchService.unified(q, { type, page, limit })
  return apiSuccess(results.data, 200, paginate(results.data, results.total, page, limit))
}
```

---

## 🔒 Sensitive Endpoints (Financial & Auth)

هذه الـ endpoints تحتاج إجراءات إضافية:

```typescript
const SENSITIVE_ENDPOINTS = [
  '/api/wallet/transfer',
  '/api/wallet/withdraw',
  '/api/payments/process',
  '/api/subscriptions/purchase',
  '/api/auth/login',
  '/api/auth/register',
  '/api/auth/change-password',
  '/api/auth/2fa/disable',
  '/api/users/delete',
]

// لكل endpoint حساس:
// 1. Idempotency-Key header (للـ financial)
// 2. CAPTCHA (للـ auth)
// 3. Re-authentication (للـ 2FA disable, account delete)
// 4. IP logging
// 5. Suspicious activity detection
// 6. Email notification after action
```

---

## 📡 Webhooks & Real-time

### SSE (Server-Sent Events) — موجود ✅

```typescript
// /api/notifications/stream — إشعارات لحظية
// /api/chat-rooms/[id]/stream — رسائل الدردشة
```

### WebSocket (socket.io) — موجود ✅

```typescript
// examples/websocket/server.ts — separate service
// Dockerfile.notification — منفصل
```

### Webhooks (Outgoing) — مقترح

```typescript
// /api/webhooks/* — استقبال webhooks من بوابات الدفع
// /api/integrations/webhooks/register — تسجيل webhook خاص بالمستخدم
```

---

## 📊 Monitoring & Metrics

### Required Metrics

```typescript
// كل endpoint يجب أن يُسجّل:
{
  endpoint: '/api/articles',
  method: 'GET',
  status: 200,
  duration_ms: 145,
  user_id: 'cuid_xxx',  // null for public
  request_id: 'uuid',
  timestamp: '2026-08-22T...',
  ip: '...',
  user_agent: '...',
  cache_hit: false,
  db_queries: 3,
  db_duration_ms: 89
}
```

### Health Check Endpoint

```typescript
// GET /api/health
export async function GET() {
  const checks = await Promise.allSettled([
    db.$queryRaw`SELECT 1`,
    redis.ping(),
    // ... other services
  ])
  
  const healthy = checks.every(c => c.status === 'fulfilled')
  
  return NextResponse.json({
    status: healthy ? 'healthy' : 'degraded',
    timestamp: new Date().toISOString(),
    services: {
      database: checks[0].status === 'fulfilled',
      redis: checks[1].status === 'fulfilled',
    },
    version: process.env.npm_package_version,
  }, { status: healthy ? 200 : 503 })
}
```

---

## ✅ معايير قبول API الجديدة

| المعيار | الحالة |
|---------|------|
| كل route يستخدم `apiSuccess/apiError` | يجب |
| كل route يستخدم Zod schema | يجب |
| كل route محمي بـ `requireAuth` (إذا مطلوب) | يجب |
| كل route محمي بـ `checkPermission` (إذا مطلوب) | يجب |
| كل route له rate-limit مناسب | يجب |
| كل route يُسجّل structured log | يجب |
| كل route له OpenAPI doc | يجب |
| لا توجد endpoints مكررة | يجب |
| Pagination موحّدة | يجب |
| Error codes موحّدة | يجب |

---

## 🔗 روابط ذات صلة

- `02_INFORMATION_ARCHITECTURE.md` — بنية الصفحات
- `04_PERMISSION_MATRIX.md` — الصلاحيات في API
- `09_SECURITY_AUDIT.md` — أمان API
- `10_MIGRATION_PLAN.md` — خطة ترحيل الـ APIs المكررة

</div>
