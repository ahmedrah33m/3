# 10 — خطة الترحيل | Migration Plan

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §25 (لا تكسر الوظائف / لا تحذف بيانات) و §34 (المطلوب عدم فعله)

---

## 🎯 الهدف

خطة تفصيلية لترحيل منصة ميدان من حالتها الحالية إلى البنية المستهدفة، مع ضمان:
- **Zero data loss** — لا فقدان أي بيانات
- **Zero downtime** — لا توقف للخدمة
- **Backward compatibility** — كل الروابط القديمة تعمل
- **Reversible** — كل تغيير قابل للتراجع
- **Auditable** — كل خطوة موثّقة

---

## 📐 المبادئ الذهبية

### 1. Safe Migration Pattern

```text
┌─────────────────────────────────────────────────┐
│ Step 1: Create new (empty)         — لا يكسر شيئًا │
│ Step 2: Seed reference data        — لا يكسر شيئًا │
│ Step 3: Add new columns (nullable) — لا يكسر شيئًا │
│ Step 4: Backfill from old data     — تدريجي       │
│ Step 5: Add new routes (parallel)  — بجانب القديم │
│ Step 6: Move traffic to new        — feature flag │
│ Step 7: Deprecate old              — مع تحذير     │
│ Step 8: Remove old (after 6 months)— بعد التأكيد   │
└─────────────────────────────────────────────────┘
```

### 2. Backup Before Every Migration

```bash
# قبل أي migration:
pg_dump $DATABASE_URL > backups/pre-migration-$(date +%Y%m%d-%H%M%S).sql.gz

# Prisma migration:
npx prisma migrate deploy --name <descriptive-name>

# بعد التطبيق:
npm run test  # اختبارات
npx tsc --noEmit  # فحص الأنواع
```

### 3. Feature Flag Pattern

```typescript
// src/lib/platform/feature-flags.ts (موجود ✅)
export const FEATURE_FLAGS = {
  PERMISSION_ENGINE_V2: false,  // enable تدريجيًا
  UNIFIED_LEARNING: false,
  CONTROL_CENTER: false,
  AI_HUB: false,
}
```

---

## 🗄️ Database Migrations

### PHASE 1 — Foundation Migrations

#### Migration 1: إضافة نماذج Location الجغرافية

**الاسم:** `20260822_add_location_models`

```sql
-- Step 1: إنشاء الجداول الجديدة (empty)
CREATE TABLE "Country" (
  "id" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "nameAr" TEXT,
  "flag" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Country_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Country_code_key" ON "Country"("code");

CREATE TABLE "Governorate" (
  "id" TEXT NOT NULL,
  "countryId" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "nameAr" TEXT,
  "population" INTEGER,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Governorate_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Governorate_code_key" ON "Governorate"("code");
CREATE INDEX "Governorate_countryId_idx" ON "Governorate"("countryId");

-- نفس الشيء لـ City, Area

-- Step 2: FK constraints
ALTER TABLE "Governorate" 
  ADD CONSTRAINT "Governorate_countryId_fkey" 
  FOREIGN KEY ("countryId") REFERENCES "Country"("id") 
  ON DELETE RESTRICT;

-- Step 3: Seed بيانات العراق
INSERT INTO "Country" ("id", "code", "name", "nameAr", "flag") VALUES
  ('cl_country_iq', 'IQ', 'Iraq', 'العراق', '🇮🇶');

INSERT INTO "Governorate" ("id", "countryId", "code", "name", "nameAr") VALUES
  ('cl_gov_bgd', 'cl_country_iq', 'IQ-BGD', 'Baghdad', 'بغداد'),
  ('cl_gov_bsr', 'cl_country_iq', 'IQ-BSR', 'Basra', 'البصرة'),
  ('cl_gov_nin', 'cl_country_iq', 'IQ-NIN', 'Nineveh', 'نينوى'),
  ('cl_gov_ebl', 'cl_country_iq', 'IQ-EBL', 'Erbil', 'أربيل'),
  ('cl_gov_anb', 'cl_country_iq', 'IQ-ANB', 'Anbar', 'الأنبار'),
  -- ... 18 محافظة
  ;
```

**Reversibility:**
```sql
-- Rollback:
DROP TABLE IF EXISTS "Area";
DROP TABLE IF EXISTS "City";
DROP TABLE IF EXISTS "Governorate";
DROP TABLE IF EXISTS "Country";
```

#### Migration 2: إضافة Organization/Branch/Department

**الاسم:** `20260822_add_organization_models`

```sql
CREATE TABLE "Organization" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "nameAr" TEXT,
  "description" TEXT,
  "logo" TEXT,
  "type" TEXT NOT NULL DEFAULT 'company',
  "status" TEXT NOT NULL DEFAULT 'active',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Organization_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Organization_status_idx" ON "Organization"("status");

CREATE TABLE "Branch" (
  "id" TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "nameAr" TEXT,
  "countryId" TEXT,
  "governorateId" TEXT,
  "cityId" TEXT,
  "areaId" TEXT,
  "address" TEXT,
  "phone" TEXT,
  "email" TEXT,
  "managerId" TEXT,
  "status" TEXT NOT NULL DEFAULT 'active',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Branch_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Branch_organizationId_status_idx" ON "Branch"("organizationId", "status");
CREATE INDEX "Branch_cityId_idx" ON "Branch"("cityId");

-- FKs
ALTER TABLE "Branch" 
  ADD CONSTRAINT "Branch_organizationId_fkey" 
  FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") 
  ON DELETE RESTRICT;

ALTER TABLE "Branch" 
  ADD CONSTRAINT "Branch_countryId_fkey" 
  FOREIGN KEY ("countryId") REFERENCES "Country"("id") 
  ON DELETE SET NULL;

-- نفس الشيء لـ Department
```

#### Migration 3: إضافة Permission Models

**الاسم:** `20260822_add_permission_models`

```sql
CREATE TABLE "Permission" (
  "id" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "description" TEXT,
  "resource" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "scope" TEXT NOT NULL DEFAULT 'self',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Permission_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Permission_key_key" UNIQUE ("key")
);
CREATE INDEX "Permission_resource_action_idx" ON "Permission"("resource", "action");

CREATE TABLE "RolePermission" (
  "id" TEXT NOT NULL,
  "roleName" TEXT NOT NULL,
  "permissionKey" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "RolePermission_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "RolePermission_roleName_permissionKey_key" UNIQUE ("roleName", "permissionKey")
);
CREATE INDEX "RolePermission_roleName_idx" ON "RolePermission"("roleName");

ALTER TABLE "RolePermission" 
  ADD CONSTRAINT "RolePermission_permissionKey_fkey" 
  FOREIGN KEY ("permissionKey") REFERENCES "Permission"("key") 
  ON DELETE CASCADE;

CREATE TABLE "UserOrganizationRole" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "organizationId" TEXT NOT NULL,
  "branchId" TEXT,
  "departmentId" TEXT,
  "contextualRole" TEXT NOT NULL,
  "permissions" JSONB,
  "status" TEXT NOT NULL DEFAULT 'active',
  "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "UserOrganizationRole_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "UserOrganizationRole_userId_organizationId_branchId_key" UNIQUE ("userId", "organizationId", "branchId")
);
CREATE INDEX "UserOrganizationRole_userId_idx" ON "UserOrganizationRole"("userId");
CREATE INDEX "UserOrganizationRole_organizationId_idx" ON "UserOrganizationRole"("organizationId");
CREATE INDEX "UserOrganizationRole_branchId_idx" ON "UserOrganizationRole"("branchId");

-- FKs (User موجود، Organization/Branch موجود من migration سابق)
ALTER TABLE "UserOrganizationRole" 
  ADD CONSTRAINT "UserOrganizationRole_userId_fkey" 
  FOREIGN KEY ("userId") REFERENCES "User"("id") 
  ON DELETE CASCADE;

-- Seed Permissions (50+ default permissions)
INSERT INTO "Permission" ("id", "key", "resource", "action", "scope", "description") VALUES
  ('cl_perm_art_read', 'article.read', 'article', 'read', 'self', 'Read own articles'),
  ('cl_perm_art_create', 'article.create', 'article', 'create', 'self', 'Create articles'),
  ('cl_perm_art_update_any', 'article.update.any', 'article', 'update', 'global', 'Update any article'),
  ('cl_perm_art_delete_any', 'article.delete.any', 'article', 'delete', 'global', 'Delete any article'),
  ('cl_perm_art_publish', 'article.publish', 'article', 'publish', 'self', 'Publish article'),
  ('cl_perm_art_feature', 'article.feature', 'article', 'feature', 'global', 'Feature article'),
  ('cl_perm_job_read', 'job.read', 'job', 'read', 'global', 'Read jobs'),
  ('cl_perm_job_create', 'job.create', 'job', 'create', 'self', 'Create job'),
  ('cl_perm_job_apply', 'job.apply', 'job', 'apply', 'self', 'Apply for job'),
  ('cl_perm_wallet_read_self', 'wallet.read.self', 'wallet', 'read', 'self', 'Read own wallet'),
  ('cl_perm_wallet_credit_self', 'wallet.credit.self', 'wallet', 'credit', 'self', 'Credit own wallet'),
  ('cl_perm_wallet_debit_self', 'wallet.debit.self', 'wallet', 'debit', 'self', 'Debit own wallet'),
  ('cl_perm_wallet_read_all', 'wallet.read.all', 'wallet', 'read', 'global', 'Read all wallets'),
  ('cl_perm_wallet_credit_all', 'wallet.credit.all', 'wallet', 'credit', 'global', 'Credit any wallet'),
  ('cl_perm_user_read_all', 'user.read.all', 'user', 'read', 'global', 'Read all users'),
  ('cl_perm_user_ban', 'user.ban', 'user', 'ban', 'global', 'Ban user'),
  ('cl_perm_user_change_role', 'user.change_role', 'user', 'change_role', 'global', 'Change user role'),
  ('cl_perm_perm_assign', 'permission.assign', 'permission', 'assign', 'global', 'Assign permissions'),
  ('cl_perm_org_create', 'organization.create', 'organization', 'create', 'global', 'Create organization'),
  ('cl_perm_branch_create', 'branch.create', 'branch', 'create', 'org', 'Create branch in org'),
  -- ... 30+ more
  ;

-- Seed Role-Permission mappings
INSERT INTO "RolePermission" ("id", "roleName", "permissionKey") VALUES
  -- USER role
  ('cl_rp_user_1', 'user', 'article.read'),
  ('cl_rp_user_2', 'user', 'article.create'),
  ('cl_rp_user_3', 'user', 'article.publish'),
  ('cl_rp_user_4', 'user', 'job.read'),
  ('cl_rp_user_5', 'user', 'job.apply'),
  ('cl_rp_user_6', 'user', 'wallet.read.self'),
  ('cl_rp_user_7', 'user', 'wallet.credit.self'),
  ('cl_rp_user_8', 'user', 'wallet.debit.self'),
  
  -- EXPERT role (USER + expert-specific)
  ('cl_rp_expert_1', 'expert', 'article.read'),
  ('cl_rp_expert_2', 'expert', 'article.create'),
  ('cl_rp_expert_3', 'expert', 'article.publish'),
  ('cl_rp_expert_4', 'expert', 'job.read'),
  ('cl_rp_expert_5', 'expert', 'job.create'),
  ('cl_rp_expert_6', 'expert', 'wallet.read.self'),
  
  -- ADMIN role (all permissions with scope 'global')
  ('cl_rp_admin_1', 'admin', 'article.read'),
  ('cl_rp_admin_2', 'admin', 'article.update.any'),
  ('cl_rp_admin_3', 'admin', 'article.delete.any'),
  ('cl_rp_admin_4', 'admin', 'article.feature'),
  ('cl_rp_admin_5', 'admin', 'user.read.all'),
  ('cl_rp_admin_6', 'admin', 'user.ban'),
  ('cl_rp_admin_7', 'admin', 'wallet.read.all'),
  
  -- OWNER role (all permissions)
  ('cl_rp_owner_1', 'owner', 'article.read'),
  ('cl_rp_owner_2', 'owner', 'article.update.any'),
  ('cl_rp_owner_3', 'owner', 'article.delete.any'),
  ('cl_rp_owner_4', 'owner', 'article.feature'),
  ('cl_rp_owner_5', 'owner', 'user.read.all'),
  ('cl_rp_owner_6', 'owner', 'user.ban'),
  ('cl_rp_owner_7', 'owner', 'user.change_role'),
  ('cl_rp_owner_8', 'owner', 'permission.assign'),
  ('cl_rp_owner_9', 'owner', 'organization.create'),
  ('cl_rp_owner_10', 'owner', 'branch.create'),
  ('cl_rp_owner_11', 'owner', 'wallet.read.all'),
  ('cl_rp_owner_12', 'owner', 'wallet.credit.all'),
  ;
```

#### Migration 4: إضافة FK columns على الجداول الموجودة

**الاسم:** `20260822_add_location_fk_columns`

```sql
-- Step 1: إضافة columns nullable (لا كسر)
ALTER TABLE "User" ADD COLUMN "governorateId" TEXT;
ALTER TABLE "User" ADD COLUMN "cityId" TEXT;
ALTER TABLE "User" ADD COLUMN "organizationId" TEXT;

ALTER TABLE "Job" ADD COLUMN "governorateId" TEXT;
ALTER TABLE "Job" ADD COLUMN "cityId" TEXT;

ALTER TABLE "Company" ADD COLUMN "governorateId" TEXT;
ALTER TABLE "Company" ADD COLUMN "cityId" TEXT;
ALTER TABLE "Company" ADD COLUMN "organizationId" TEXT;

-- Step 2: FK constraints (ON DELETE SET NULL للأمان)
ALTER TABLE "User" 
  ADD CONSTRAINT "User_governorateId_fkey" 
  FOREIGN KEY ("governorateId") REFERENCES "Governorate"("id") 
  ON DELETE SET NULL;

ALTER TABLE "User" 
  ADD CONSTRAINT "User_cityId_fkey" 
  FOREIGN KEY ("cityId") REFERENCES "City"("id") 
  ON DELETE SET NULL;

ALTER TABLE "User" 
  ADD CONSTRAINT "User_organizationId_fkey" 
  FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") 
  ON DELETE SET NULL;

-- نفس الشيء لـ Job, Company

-- Step 3: Backfill script (يدوي أو cron)
-- UPDATE "User" SET "governorateId" = 'cl_gov_bgd' WHERE "location" ILIKE '%baghdad%';
-- UPDATE "User" SET "governorateId" = 'cl_gov_bsr' WHERE "location" ILIKE '%basra%';
-- ... تدريجيًا

-- ✅ لا حذف للـ string القديم. سيُحذف في migration لاحقة بعد التأكد.
```

#### Migration 5: إضافة TransactionAudit و IdempotencyKey

**الاسم:** `20260822_add_financial_audit_models`

```sql
CREATE TABLE "TransactionAudit" (
  "id" TEXT NOT NULL,
  "transactionId" TEXT NOT NULL,
  "actorId" TEXT,
  "action" TEXT NOT NULL,
  "previousState" JSONB,
  "newState" JSONB,
  "reason" TEXT,
  "ipAddress" TEXT,
  "userAgent" TEXT,
  "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "TransactionAudit_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "TransactionAudit_transactionId_idx" ON "TransactionAudit"("transactionId");
CREATE INDEX "TransactionAudit_actorId_timestamp_idx" ON "TransactionAudit"("actorId", "timestamp");

CREATE TABLE "IdempotencyKey" (
  "id" TEXT NOT NULL,
  "key" TEXT NOT NULL,
  "endpoint" TEXT NOT NULL,
  "requestBodyHash" TEXT NOT NULL,
  "responseStatus" INTEGER,
  "responseBody" TEXT,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "IdempotencyKey_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "IdempotencyKey_key_key" UNIQUE ("key")
);
CREATE INDEX "IdempotencyKey_key_expiresAt_idx" ON "IdempotencyKey"("key", "expiresAt");
```

### PHASE 2 — Refactor Migrations

#### Migration 6: إضافة SearchIndex و ConversationContext

**الاسم:** `20260822_add_unified_search_messaging`

```sql
CREATE TABLE "SearchIndex" (
  "id" TEXT NOT NULL,
  "entityType" TEXT NOT NULL,
  "entityId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "content" TEXT NOT NULL,
  "keywords" TEXT[],
  "language" TEXT NOT NULL DEFAULT 'ar',
  "isPublished" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "SearchIndex_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "SearchIndex_entityType_entityId_key" UNIQUE ("entityType", "entityId")
);
CREATE INDEX "SearchIndex_entityType_isPublished_idx" ON "SearchIndex"("entityType", "isPublished");

-- GIN index للـ full-text search (PostgreSQL)
CREATE INDEX "SearchIndex_title_content_idx" ON "SearchIndex" 
  USING GIN (to_tsvector('arabic', "title" || ' ' || "content"));

CREATE TABLE "ConversationContext" (
  "id" TEXT NOT NULL,
  "conversationId" TEXT NOT NULL,
  "contextType" TEXT NOT NULL,
  "contextId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ConversationContext_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ConversationContext_conversationId_contextType_contextId_key" 
    UNIQUE ("conversationId", "contextType", "contextId")
);
CREATE INDEX "ConversationContext_contextType_contextId_idx" 
  ON "ConversationContext"("contextType", "contextId");
```

#### Migration 7: إضافة Certificate Models

**الاسم:** `20260822_add_certificate_models`

```sql
CREATE TABLE "Certificate" (
  "id" TEXT NOT NULL,
  "certificateNumber" TEXT NOT NULL,
  "holderId" TEXT NOT NULL,
  "courseId" TEXT,
  "learningPathId" TEXT,
  "issuedById" TEXT,
  "issueDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "expiryDate" TIMESTAMP(3),
  "score" DOUBLE PRECISION,
  "metadata" JSONB,
  CONSTRAINT "Certificate_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Certificate_certificateNumber_key" UNIQUE ("certificateNumber")
);
CREATE INDEX "Certificate_holderId_idx" ON "Certificate"("holderId");

CREATE TABLE "CertificateVerification" (
  "id" TEXT NOT NULL,
  "certificateId" TEXT NOT NULL,
  "verifiedBy" TEXT,
  "verifiedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "CertificateVerification_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "CertificateVerification_certificateId_idx" 
  ON "CertificateVerification"("certificateId");
```

---

## 🔄 Code Migrations (Route Refactoring)

### استراتيجية: Parallel Routes + Feature Flags

**النمط:** لا نحذف المسار القديم. نُنشئ المسار الجديد بجانبه، نوجّه الترافيك تدريجيًا عبر feature flag.

#### Migration 1: توحيد Learning

```text
الحالة الحالية:
  /learn             ← page.tsx
  /learning          ← page.tsx
  /learning/[id]     ← page.tsx
  /academy           ← page.tsx
  /quizzes           ← page.tsx
  /quizzes/[id]      ← page.tsx
  /dictionary        ← page.tsx

الحالة المستهدفة (PHASE 2):
  /learning          ← unified page (يحوي تبويبات: Courses, Paths, Quizzes, Dictionary)
  /learning/courses/[id]
  /learning/paths/[id]
  /learning/quizzes/[id]
  /learning/dictionary

الـ redirects:
  /learn             → 301 → /learning
  /academy           → 301 → /learning
  /quizzes           → 301 → /learning/quizzes
  /quizzes/[id]      → 301 → /learning/quizzes/[id]
  /dictionary        → 301 → /learning/dictionary

التنفيذ:
  1. إنشاء src/app/(main)/learning/courses/ و paths/ و quizzes/ و dictionary/
  2. نقل المحتوى من الصفحات القديمة
  3. تحديث page.tsx في /learn, /academy, /quizzes, /dictionary لتصبح redirects
  4. اختبار كل redirect
  5. تحديث sitemap.ts
  6. مراقبة 404s لمدة أسبوع
```

#### Migration 2: توحيد AI

```text
الحالة الحالية:
  /ai-assistant
  /economy/ai-assistant

الحالة المستهدفة:
  /ai
  /ai/general
  /ai/economic
  /ai/research
  /ai/career
  /ai/investment
  /ai/content

الـ redirects:
  /ai-assistant          → 301 → /ai/general
  /economy/ai-assistant  → 301 → /ai/economic

التنفيذ: نفس نمط Learning.
```

#### Migration 3: توحيد Control Center

```text
الحالة الحالية:
  /admin
  /admin/auto-publish
  /admin/scrape
  /owner
  /owner-panel

الحالة المستهدفة:
  /control-center
  /control-center/dashboard
  /control-center/users
  /control-center/organizations
  /control-center/companies
  /control-center/jobs
  /control-center/experts
  /control-center/marketplace
  /control-center/finance
  /control-center/research
  /control-center/academy
  /control-center/moderation
  /control-center/ads
  /control-center/ai
  /control-center/analytics
  /control-center/security
  /control-center/audit-logs
  /control-center/settings
  /control-center/branches
  /control-center/employees

الـ redirects:
  /admin/*      → 302 → /control-center/*
  /owner/*      → 302 → /control-center/*
  /owner-panel  → 301 → /control-center

ملاحظة: نستخدم 302 (مؤقت) لـ admin/owner لأنها محمية، نريد الحفاظ على backward compat.
```

#### Migration 4: توحيد Career

```text
الحالة الحالية:
  /jobs
  /jobs/[id]
  /jobs/new
  /jobs/candidate/*
  /jobs/employer/*
  /jobs/cv-bank
  /jobs/dashboard

الحالة المستهدفة:
  /career
  /career/jobs
  /career/jobs/[id]
  /career/jobs/new
  /career/my-applications
  /career/cv
  /career/cv-bank
  /career/interviews
  /career/offers
  /career/employer
  /career/employer/jobs
  /career/employer/applicants
  /career/employer/interviews
  /career/employer/reports

الـ redirects:
  /jobs                → 301 → /career/jobs
  /jobs/[id]           → 301 → /career/jobs/[id]
  /jobs/new            → 301 → /career/jobs/new
  /jobs/candidate/applied    → 301 → /career/my-applications
  /jobs/candidate/interviews → 301 → /career/interviews
  /jobs/candidate/offers     → 301 → /career/offers
  /jobs/employer/*      → 301 → /career/employer/*
  /jobs/cv-bank        → 301 → /career/cv-bank
  /jobs/dashboard      → 301 → /career
```

---

## 🚦 Feature Flag Strategy

```typescript
// src/lib/platform/feature-flags.ts
export const FEATURE_FLAGS = {
  // PHASE 1
  PERMISSION_ENGINE_V2: process.env.FF_PERMISSION_ENGINE_V2 === 'true',
  LOCATION_SERVICE_V2: process.env.FF_LOCATION_SERVICE_V2 === 'true',
  UNIFIED_NAVIGATION: process.env.FF_UNIFIED_NAV === 'true',
  
  // PHASE 2
  UNIFIED_LEARNING: process.env.FF_UNIFIED_LEARNING === 'true',
  UNIFIED_AI: process.env.FF_UNIFIED_AI === 'true',
  CONTROL_CENTER: process.env.FF_CONTROL_CENTER === 'true',
  UNIFIED_CAREER: process.env.FF_UNIFIED_CAREER === 'true',
  UNIFIED_MESSAGING: process.env.FF_UNIFIED_MESSAGING === 'true',
  UNIFIED_SEARCH: process.env.FF_UNIFIED_SEARCH === 'true',
  
  // PHASE 9
  IDEMPOTENT_TRANSACTIONS: process.env.FF_IDEMPOTENT_TX === 'true',
  
  // PHASE 10
  AI_HUB: process.env.FF_AI_HUB === 'true',
} as const

export function isEnabled(flag: keyof typeof FEATURE_FLAGS): boolean {
  return FEATURE_FLAGS[flag] === true
}
```

**الاستخدام:**
```typescript
// في API route
import { isEnabled } from '@/lib/platform/feature-flags'

export async function GET() {
  if (isEnabled('PERMISSION_ENGINE_V2')) {
    return await newPermissionCheck()
  } else {
    return await legacyRoleCheck()  // الـ pattern الحالي
  }
}
```

---

## 📊 Rollout Strategy

### Phase 1 Rollout (Foundation)

```text
Week 1: Development + Staging tests
  ↓
Week 2: 1% traffic (feature flags)
  ↓
Week 3: 10% traffic
  ↓
Week 4: 50% traffic
  ↓
Week 5: 100% traffic
  ↓
Week 6: Remove legacy code paths
```

### المراقبة أثناء الـ Rollout

- **Error rate** يجب أن يبقى < 1%
- **Response time** يجب ألا يزيد بنسبة > 20%
- **User complaints** يتم تتبّعها يوميًا
- **Feature flag toggle** جاهز للتراجع فوريًا

---

## 🔄 Rollback Strategy

لكل migration:

```bash
# 1. Database rollback
npx prisma migrate resolve --rolled-back <migration-name>
psql $DATABASE_URL < backups/pre-migration-XXX.sql

# 2. Code rollback
git revert <commit-hash>
git push origin main

# 3. Feature flag disable
FF_PERMISSION_ENGINE_V2=false
# إعادة تشغيل الخادم

# 4. Communication
# - إشعار المستخدمين بالعودة للنسخة السابقة
# - توثيق السبب في worklog.md
```

---

## ✅ Pre-Migration Checklist

قبل كل migration:

- [ ] Backup قاعدة البيانات (pg_dump)
- [ ] اختبار الـ migration على staging
- [ ] اختبار rollback على staging
- [ ] مراجعة الكود (peer review)
- [ ] تحديث الـ tests للـ pattern الجديد
- [ ] توثيق الـ migration في `worklog.md`
- [ ] إعداد feature flag للتراجع
- [ ] مراقبة معدل الأخطاء بعد التطبيق

---

## 📅 Timeline الترحيل المقترح

```text
Week 1-2:  PHASE 1 migrations 1-2 (Location, Organization)
Week 3:    PHASE 1 migration 3 (Permission models)
Week 4:    PHASE 1 migration 4 (FK columns on User/Job/Company)
Week 5:    PHASE 1 migration 5 (Financial audit models)
Week 6-7:  PHASE 2 migration 6 (Search, Messaging context)
Week 8:    PHASE 2 migration 7 (Certificates)
Week 9+:   Code migrations (Learning, AI, Control Center, Career) — تدريجي
```

---

## ⚠️ مخاطر الترحيل

| الخطر | الاحتمالية | التأثير | التخفيف |
|------|----------|--------|---------|
| فقدان بيانات أثناء backfill | منخفضة | كارثي | backup قبل + اختبار على staging |
| كسر روابط مُفهرسة في Google | متوسطة | عالي | 301 redirects لكل مسار قديم |
| Performance degradation | متوسطة | متوسط | مراقبة + rollback سريع |
| تعارض Prisma migrations | منخفضة | عالي | prisma migrate resolve |
| User confusion | متوسطة | منخفض | announcements + onboarding tour |
| API breaking changes | منخفضة | عالي | API versioning + deprecation period |

---

## 📦 Post-Migration Validation

بعد كل migration:

1. **Smoke tests** على كل الصفحات الحرجة
2. **API tests** على كل endpoints المتأثرة
3. **Database integrity checks** (foreign keys, indexes)
4. **Performance benchmarks** (مقارنة قبل/بعد)
5. **User feedback monitoring** (complaints, support tickets)
6. **SEO monitoring** (Google Search Console للـ redirects)

---

## 🔗 روابط ذات صلة

- `01_PROJECT_AUDIT.md` — وضع البداية
- `08_ROADMAP.md` — خطة التنفيذ الكاملة
- `09_SECURITY_AUDIT.md` — اعتبارات الأمان أثناء الترحيل

</div>
