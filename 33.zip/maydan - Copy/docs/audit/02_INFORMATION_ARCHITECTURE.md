# 02 — بنية المعلومات | Information Architecture

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §5 (البنية المستقبلية الأساسية)

---

## 🎯 الهدف

تعريف البنية المعلوماتية المستهدفة لمنصة ميدان، بحيث تصبح جميع الأقسام جزءًا من منتج واحد متناسق. هذه البنية هي **المرجع** لكل التطويرات القادمة، ولن يتم قبول أي صفحة أو API خارجها إلا بقرار معماري صريح.

---

## 📐 المبادئ المعمارية

### 1. Single Source of Truth
كل وظيفة لها مسار واحد فقط. لا تكرار، لا تفرّع. إذا وُجدت `learn` و `learning` و `academy`، يجب توحيدها.

### 2. Domain-Driven Bounded Contexts
كل قسم له نطاق واضح (Bounded Context). لا يخلط `Economy` مع `Marketplace` في نفس الـ namespace.

### 3. Backward Compatibility
المسارات القديمة (`/learn`, `/academy`, `/owner`) تُحفظ كـ redirects دائمة 301 إلى المسارات الجديدة، لضمان عدم فقدان SEO أو روابط خارجية.

### 4. RTL-First Design
المنصة عربية أولًا. الترتيب الافتراضي RTL، مع دعم LTR للغات الأخرى.

### 5. Permission-Aware Navigation
عناصر التنقّل تُعرض/تُخفى بناءً على `Role + Scope + Organization Context`، لكن الإخفاء ليس حماية فعلية (يجب التحقق دائمًا في API).

---

## 🗺️ البنية المستهدفة (Top-Level)

```text
                          MIDAN
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
   DISCOVER              COMMUNITY              ECONOMY
   (استكشاف)              (مجتمع)               (اقتصاد)
       │                    │                    │
   People              Posts              Dashboard
   Experts             Discussions        Indicators
   Companies           Questions          Markets
   Jobs                Polls              Charts
   Services            Communities        Calendar
   Products            Rooms              Iraq Map
   Research                                AI
       │                    │                    │
       └────────────────────┼────────────────────┘
                            │
                      ┌─────┴─────┐
                      │           │
                  CAREER      EXPERTS
                  (وظائف)     (خبراء)
                      │           │
                  Jobs         Experts
                  CV           Consultations
                  Applications Expert Market
                  Interviews
                  Offers
                  Employer
                  CV Bank
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
   MARKETPLACE         INVESTMENT             RESEARCH
   (سوق)              (استثمار)              (أبحاث)
       │                    │                    │
   Services            Opportunities        Papers
   Products            Investors             Researchers
   Stores              Partnerships          Projects
   Providers           Matching              Funding
   Requests                                  Citations
       │                    │                    │
       └────────────────────┼────────────────────┘
                            │
                       EDUCATION
                       (تعليم)
                            │
                       Academy
                       Courses
                       Learning Paths
                       My Learning
                       Quizzes
                       Certificates
                            │
                            ▼
                        FINANCE
                        (مالية)
                            │
                       Wallet
                       Transactions
                       Invoices
                       Withdrawals
                       Payments
                            │
                            ▼
                          AI
                       (ذكاء)
                            │
                  Midan Intelligence
                            │
                            ▼
                    CONTROL CENTER
                    (مركز التحكم)
                            │
                  Owner / Management
                  Finance / Security
                  Moderation / Analytics
```

---

## 📂 بنية المسارات (URL Structure)

### المسارات العامة (Public — لا تتطلب تسجيل دخول)

| المسار | الصفحة | الملاحظات |
|--------|--------|---------|
| `/` | الصفحة الرئيسية (Personalized Feed) | تعرض Hero + Economic Snapshot + Trending |
| `/login` | تسجيل الدخول | يحفظ `returnUrl` |
| `/register` | إنشاء حساب | يدعم USER / EXPERT / COMPANY |
| `/explore` | استكشاف المنصة | لغير المسجلين |
| `/about` | عن ميدان | محتوى ثابت |
| `/pricing` | خطط الأسعار | subscriptions |
| `/verify-certificate` | التحقق من شهادة | صفحة عامة |
| `/sitemap.xml` | خريطة الموقع | ديناميكية |
| `/robots.txt` | robots | ديناميكية |

### DISCOVER — `/discover/*`

| المسار | الوصف | الصلاحية |
|--------|------|---------|
| `/discover` | لوحة الاستكشاف الشاملة | USER+ |
| `/discover/people` | أشخاص | USER+ |
| `/discover/experts` | خبراء | USER+ |
| `/discover/companies` | شركات | USER+ |
| `/discover/jobs` | وظائف (preview) | USER+ |
| `/discover/services` | خدمات | USER+ |
| `/discover/products` | منتجات | USER+ |
| `/discover/research` | أبحاث | USER+ |

> **ملاحظة:** الصفحات الموجودة حاليًا (`/experts`, `/companies`, `/jobs` الخ) **تبقى كما هي** كمسارات مباشرة، و `/discover` يعرضها بشكل مجمع (aggregation view) ولا يستبدلها.

### ECONOMY — `/economy/*` (موجود بالفعل ✅)

| المسار | الوصف |
|--------|------|
| `/economy` | لوحة الاقتصاد الرئيسية (Dashboard) |
| `/economy/indicators` | المؤشرات الاقتصادية |
| `/economy/markets` | الأسواق |
| `/economy/charts` | الرسوم البيانية |
| `/economy/calendar` | التقويم الاقتصادي |
| `/economy/map` | خريطة العراق الاقتصادية |
| `/economy/converter` | محول العملات |
| `/economy/ai` | مساعد AI اقتصادي (→ redirect من `/economy/ai-assistant`) |
| `/economy/oil` | لوحة النفط (مقترح) |
| `/economy/inflation` | حاسبة التضخم (مقترح) |
| `/economy/budget` | الموازنة (مقترح) |

### COMMUNITY — `/community/*`

| المسار | الوصف |
|--------|------|
| `/community` | لوحة المجتمع الرئيسية |
| `/community/posts` | المنشورات (→ `/posts` الحالي) |
| `/community/discussions` | النقاشات (→ `/discussions`) |
| `/community/questions` | الأسئلة (→ `/questions`) |
| `/community/polls` | الاستطلاعات (→ `/polls`) |
| `/community/communities` | المجتمعات (→ `/communities`) |
| `/community/rooms` | غرف الدردشة (→ `/chat-rooms`) |

> **ملاحظة:** المسارات الحالية (`/posts`, `/discussions`, `/questions`, `/polls`, `/chat-rooms`, `/communities`) **تبقى كما هي** لأنها مُفهرسة في محركات البحث وتمتلك روابط خلفية. `/community/*` فقط يوفر واجهة موحدة للوصول إليها.

### CAREER — `/career/*` (توسيع لـ `/jobs` الحالي)

| المسار | الوصف |
|--------|------|
| `/career` | لوحة الوظائف الرئيسية |
| `/career/jobs` | تصفّح الوظائف |
| `/career/jobs/[id]` | تفاصيل وظيفة |
| `/career/jobs/new` | نشر وظيفة (EMPLOYER) |
| `/career/my-applications` | تطبيقاتي (CANDIDATE) |
| `/career/cv` | بناء/تعديل السيرة الذاتية |
| `/career/cv-bank` | بنك السير (لأصحاب العمل) |
| `/career/interviews` | مقابلاتي |
| `/career/offers` | عروضي |
| `/career/employer` | لوحة صاحب العمل |
| `/career/employer/jobs` | وظائفي المنشورة |
| `/career/employer/applicants` | المتقدمون |
| `/career/employer/applicants/[jobId]/kanban` | ATS Kanban |
| `/career/employer/interviews` | المقابلات |
| `/career/employer/reports` | تقارير التوظيف |

> **Redirects:** `/jobs/*` → `/career/jobs/*` و `/jobs/candidate/*` → `/career/my-*` و `/jobs/employer/*` → `/career/employer/*`

### EXPERTS — `/experts/*`

| المسار | الوصف |
|--------|------|
| `/experts` | دليل الخبراء |
| `/experts/[id]` | ملف خبير |
| `/consultations` | الاستشارات |
| `/consultations/[id]` | تفاصيل استشارة |
| `/expert-market` | سوق الخبراء (للبيع/الحجز) |
| `/consultant-dashboard` | لوحة المستشار |

### LEARNING — `/learning/*` (موحّد ✅)

| المسار | الوصف |
|--------|------|
| `/learning` | الأكاديمية (unified) |
| `/learning/courses` | كل الكورسات |
| `/learning/courses/[id]` | تفاصيل كورس |
| `/learning/courses/[id]/lesson/[lessonId]` | مشغّل الدرس |
| `/learning/paths` | مسارات التعلم |
| `/learning/paths/[id]` | تفاصيل مسار |
| `/learning/my-learning` | تعلّمي (CANDIDATE) |
| `/learning/quizzes` | الاختبارات |
| `/learning/quizzes/[id]` | تفاصيل اختبار |
| `/learning/certificates` | شهاداتي |
| `/learning/dictionary` | القاموس الاقتصادي |

> **Redirects:** `/learn` → `/learning`, `/academy` → `/learning`, `/quizzes` → `/learning/quizzes`, `/dictionary` → `/learning/dictionary`

### RESEARCH — `/research/*`

| المسار | الوصف |
|--------|------|
| `/research` | الأبحاث |
| `/research/papers` | الأوراق البحثية |
| `/research/papers/[id]` | تفاصيل ورقة |
| `/research/researchers` | الباحثون |
| `/research/projects` | المشاريع البحثية |
| `/research/funding` | التمويل البحثي |

### INVESTMENT — `/investment/*` (جديد — توسيع لـ `/investment-bank` الحالي)

| المسار | الوصف |
|--------|------|
| `/investment` | لوحة الاستثمار |
| `/investment/opportunities` | الفرص الاستثمارية |
| `/investment/investors` | المستثمرون |
| `/investment/partnerships` | الشراكات |
| `/investment/matching` | المطابقة |
| `/investment-bank` | البنك الاستثماري (يبقى كما هو) |

### MARKETPLACE — `/marketplace/*` (موجود ✅)

| المسار | الوصف |
|--------|------|
| `/marketplace` | السوق الرئيسي |
| `/marketplace/services` | خدمات |
| `/marketplace/services/[id]` | تفاصيل خدمة |
| `/marketplace/products` | منتجات |
| `/marketplace/products/[id]` | تفاصيل منتج |
| `/marketplace/stores` | متاجر |
| `/marketplace/stores/[id]` | تفاصيل متجر |
| `/marketplace/providers` | مزوّدون |
| `/marketplace/providers/[id]` | تفاصيل مزوّد |
| `/marketplace/requests` | طلبات |
| `/marketplace/requests/new` | إنشاء طلب |
| `/marketplace/requests/[id]` | تفاصيل طلب |
| `/marketplace/dashboard` | لوحة البائع |

### FINANCE — `/finance/*` (موحّد)

| المسار | الوصف |
|--------|------|
| `/finance` | لوحة مالية شاملة |
| `/finance/wallet` | المحفظة (→ `/wallet` الحالي) |
| `/finance/transactions` | المعاملات |
| `/finance/invoices` | الفواتير |
| `/finance/withdrawals` | السحوبات |
| `/finance/payments` | المدفوعات |
| `/finance/reports` | التقارير المالية |

> **Redirects:** `/wallet` → `/finance/wallet` (لكن `/wallet` يبقى للتوافق)

### AI — `/ai/*` (موحّد ✅)

| المسار | الوصف |
|--------|------|
| `/ai` | لوحة AI الرئيسية |
| `/ai/general` | مساعد عام |
| `/ai/economic` | محلل اقتصادي |
| `/ai/research` | مساعد أبحاث |
| `/ai/career` | مساعد وظيفي |
| `/ai/investment` | مساعد استثمار |
| `/ai/content` | مساعد محتوى |

> **Redirects:** `/ai-assistant` → `/ai/general`, `/economy/ai-assistant` → `/ai/economic`

### CONTROL CENTER — `/control-center/*` (موحّد Owner/Admin)

| المسار | الوصف | الصلاحية |
|--------|------|---------|
| `/control-center` | لوحة التحكم الشاملة | OWNER, ADMIN, GENERAL_MANAGER |
| `/control-center/dashboard` | الإحصائيات | OWNER, ADMIN |
| `/control-center/users` | المستخدمون | OWNER, ADMIN |
| `/control-center/organizations` | المؤسسات | OWNER |
| `/control-center/companies` | الشركات | OWNER, ADMIN |
| `/control-center/jobs` | إدارة الوظائف | OWNER, ADMIN |
| `/control-center/experts` | التحقق من الخبراء | OWNER, ADMIN, MODERATOR |
| `/control-center/marketplace` | إدارة السوق | OWNER, ADMIN |
| `/control-center/finance` | المالية | OWNER |
| `/control-center/research` | الأبحاث | OWNER, ADMIN |
| `/control-center/academy` | الأكاديمية | OWNER, ADMIN |
| `/control-center/moderation` | الإشراف | OWNER, ADMIN, MODERATOR |
| `/control-center/ads` | الإعلانات | OWNER, ADMIN |
| `/control-center/ai` | إعدادات AI | OWNER |
| `/control-center/analytics` | التحليلات | OWNER, ADMIN |
| `/control-center/security` | الأمان | OWNER |
| `/control-center/audit-logs` | سجلات التدقيق | OWNER |
| `/control-center/settings` | إعدادات النظام | OWNER |
| `/control-center/branches` | الفروع | OWNER, GENERAL_MANAGER |
| `/control-center/employees` | الموظفون | OWNER, GENERAL_MANAGER, BRANCH_MANAGER |

> **Redirects:** `/admin` → `/control-center`, `/owner-panel` → `/control-center`, `/owner` → `/control-center` (مع الحفاظ على routing داخلي للأقسام)

### ملف شخصي وتفاعلات

| المسار | الوصف |
|--------|------|
| `/profile/[id]` | ملف شخصي (موجود ✅) |
| `/dashboard` | لوحة التحكم الشخصية (موجود ✅) |
| `/notifications` | الإشعارات (موجود ✅) |
| `/messages` | الرسائل (موجود ✅) |
| `/bookmarks` | المحفوظات (موجود ✅) |
| `/connections` | الاتصالات (موجود ✅) |
| `/search` | البحث (موجود ✅) |
| `/tags/[tag]` | تصفّح وسم (موجود ✅) |
| `/create-post` | إنشاء منشور (موجود ✅) |
| `/write` | محرر مقالات (موجود ✅) |
| `/write/[id]` | تعديل مقال (موجود ✅) |
| `/cv-builder` | بناء سيرة ذاتية (موجود ✅) |
| `/premium` | الاشتراك المميز (موجود ✅) |
| `/achievements` | الإنجازات (موجود ✅) |
| `/leaderboard` | لوحة المتصدرين (موجود ✅) |
| `/events` | الأحداث (موجود ✅) |
| `/analytics` | التحليلات الشخصية (موجود ✅) |

---

## 🔄 خريطة إعادة التوجيه (Redirect Map)

التغييرات التالية تتطلب **301 redirects** دائمة للحفاظ على SEO:

| المسار القديم | المسار الجديد | النوع |
|---------------|--------------|------|
| `/learn` | `/learning` | 301 |
| `/academy` | `/learning` | 301 |
| `/quizzes` | `/learning/quizzes` | 301 |
| `/dictionary` | `/learning/dictionary` | 301 |
| `/ai-assistant` | `/ai/general` | 301 |
| `/economy/ai-assistant` | `/ai/economic` | 301 |
| `/admin` | `/control-center` | 301 |
| `/owner-panel` | `/control-center` | 301 |
| `/owner` | `/control-center` | 301 |
| `/jobs/candidate/applied` | `/career/my-applications` | 301 |
| `/jobs/candidate/interviews` | `/career/interviews` | 301 |
| `/jobs/candidate/offers` | `/career/offers` | 301 |
| `/jobs/employer/jobs` | `/career/employer/jobs` | 301 |
| `/jobs/employer/applicants` | `/career/employer/applicants` | 301 |

> **ملاحظة مهمة:** المسارات القديمة **لا تُحذف** في PHASE 1. تُضاف redirects فقط. الحذف يكون في PHASE 12 بعد التأكد من استقرار الجديد.

---

## 🧭 قواعد التنقّل (Navigation Rules)

### Navbar العلوي (Desktop)

```text
[Logo] [Search]                                    [Notifications] [Messages] [Profile]
```

عناوين رئيسية في Navbar:
1. الرئيسية
2. استكشاف (Dropdown: People, Experts, Companies, Jobs, Services, Products, Research)
3. اقتصاد (Dropdown: Dashboard, Indicators, Markets, Charts, Calendar, Iraq Map)
4. مجتمع (Dropdown: Posts, Discussions, Questions, Polls, Communities, Rooms)
5. وظائف
6. تعلّم
7. AI (مع شارة "جديد")
8. [+] إنشاء (زر بارز)

### Sidebar الأيمن (RTL)

```text
[Avatar]
[Dashboard]
[My Articles]
[Saved]
[Wallet]
[Messages]
[Notifications]
─────────────
My Network
[Connections]
[Following]
─────────────
Tools
[CV Builder]
[AI Assistant]
[Economic AI]
─────────────
[Settings]
```

### MobileBottomNav (موجود ✅)

5 تبويبات: Home, Search, Create, Chat, Profile — مع شارة إشعارات على Chat.

---

## 🎯 أولوية العرض للأقسام

عند بناء القوائم والـ Home، نتبع الأولوية:

```text
1. CONTENT (مقالات، منشورات) — قلب المنصة
2. PEOPLE (خبراء، أعضاء) — القيمة الاجتماعية
3. ECONOMY (مؤشرات، أسعار) — القيمة الاقتصادية
4. CAREER (وظائف، CV) — القيمة المهنية
5. LEARNING (أكاديمية، كورسات) — النمو
6. MARKETPLACE (خدمات، منتجات) — التجارة
7. AI — التميّز التقني
8. CONTROL CENTER — للإدارة فقط
```

---

## 📊 قياس نجاح البنية

المعايير التالية ستُقاس بعد PHASE 1:

| المعيار | الهدف |
|---------|------|
| عدد المسارات المكررة | 0 |
| عدد redirects العاملة | 15+ |
| الصفحات بـ consistent UI | 100% |
| الصفحات بـ loading/empty/error states | 100% |
| زمن تنقل بين الأقسام (mobile) | < 200ms |
| Bounce rate من قائمة الـ Discover | < 30% |

---

## 🔗 الوثائق المرتبطة

- `03_SITEMAP.md` — خريطة المسارات الكاملة
- `07_DESIGN_SYSTEM.md` — نظام التصميم
- `08_ROADMAP.md` — ترتيب التنفيذ
- `10_MIGRATION_PLAN.md` — خطة الترحيل الآمن

</div>
