# 08 — خارطة الطريق | Roadmap

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §24 (ترتيب التطوير الإلزامي) و §37 (الأولوية المطلقة)

---

## 🎯 الهدف

خطة تنفيذية مفصّلة لتحويل ميدان من المنصة الحالية إلى المنصة المستهدفة، موزّعة على 13 مرحلة (PHASE 0 → PHASE 12). كل مرحلة لها:
- مدة زمنية تقديرية
- مخرجات قابلة للقياس
- معايير قبول واضحة
- مخاطر معروفة

---

## 📅 الخط الزمني الإجمالي

```text
PHASE 0 — Discovery & Audit        ← ✅ مكتمل (هذا التقرير)
PHASE 1 — Foundation                ← 2-3 أسابيع (الأهم)
PHASE 2 — Architecture Refactor     ← 2-3 أسابيع
PHASE 3 — Core UX                   ← 2 أسابيع
PHASE 4 — Career                    ← 2 أسابيع
PHASE 5 — Experts & Consulting      ← 1-2 أسبوع
PHASE 6 — Economy                   ← 2 أسابيع
PHASE 7 — Academy & Research        ← 2 أسابيع
PHASE 8 — Marketplace               ← 2-3 أسابيع
PHASE 9 — Finance                   ← 2 أسابيع (حرج)
PHASE 10 — AI                       ← 2 أسابيع
PHASE 11 — Business & Growth        ← 1-2 أسبوع
PHASE 12 — Optimization             ← مستمر

الإجمالي: ~5-6 أشهر عمل متواصل
```

---

## 📋 PHASE 0 — Discovery & Audit ✅

**الحالة:** مكتمل
**المدة:** تم
**المخرجات:**
- ✅ 10 وثائق تخطيط (`docs/audit/01-10`)
- ✅ تحليل شامل للمشروع الحالي
- ✅ تحديد الازدواجيات والفجوات
- ✅ تعريف البنية المستهدفة

---

## 🏗️ PHASE 1 — Foundation

**المدة:** 2-3 أسابيع
**الأولوية:** 🔴 حرج — كل المراحل الأخرى تعتمد عليه

### المخرجات

1. **Design Tokens** (`src/lib/design-system/tokens.ts`)
   - توثيق كامل للهوية البصرية الحالية
   - إضافة Semantic Colors (success, warning, info, danger)
   - Spacing scale موحّد
   - Type scale موحّد

2. **Navigation Config** (`src/lib/navigation-config.ts`)
   - تعريف كل عناصر التنقّل في مكان واحد
   - دعم Role-based filtering
   - دعم RTL/LTR

3. **Permission Engine** (`src/lib/permission-engine.ts`)
   - `checkPermission(ctx, resource, action, options)`
   - دعم Global Role + Contextual Role
   - دعم Geographic Scope
   - دعم Organization Scope

4. **Location Service** (`src/lib/location-service.ts`)
   - `getGovernorates()`, `getCities(govId)`, `getAreas(cityId)`
   - backfill من string إلى FK

5. **Prisma Additions** (بدون كسر الموجود):
   - `Country`, `Governorate`, `City`, `Area`, `Branch`
   - `Organization`, `Department`
   - `UserOrganizationRole`
   - `Permission`, `RolePermission`

6. **API Response Helpers** (`src/lib/api-response.ts`)
   - `apiSuccess`, `apiError`, `apiValidationError`
   - Unified response shape
   - Pagination helpers

7. **Audit Log Enhancement** (`src/lib/audit.ts`)
   - تسجيل كل قرار صلاحية
   - structured logging

8. **Unified Error Handling**
   - `ErrorBoundary` محسّن
   - Error reporting للـ Sentry (مع تفعيل DSN)

### معايير القبول

- [ ] `npx tsc --noEmit` يمر بدون أخطاء
- [ ] `npm test` يجتاز 233+ اختبار (مع إضافة اختبارات جديدة للـ Permission Engine)
- [ ] `npm run build` ينجح في < 90 ثانية
- [ ] جميع الصفحات الموجودة تعمل كما هي
- [ ] الـ redirects الجديدة تعمل (301)
- [ ] الـ Design Tokens تُستخدم في 100% من المكوّنات الجديدة

### المخاطر

| الخطر | الاحتمالية | التأثير | التخفيف |
|------|----------|--------|---------|
| كسر backward compatibility | عالية | عالي | اختبارات regression شاملة |
| تأثير على الـ SEO | متوسطة | متوسط | redirects 301 دائمة |
| أداء أبطأ بسبب permission checks | متوسطة | منخفض | caching للصلاحيات في Redis |
| تعارض Prisma migrations | منخفضة | عالي | اختبار على staging أولاً |

---

## 🔄 PHASE 2 — Architecture Refactor

**المدة:** 2-3 أسابيع
**الأولوية:** 🔴 عالي

### المخرجات

1. **توحيد Learning**
   - دمج `/learn`, `/learning`, `/academy` تحت `/learning`
   - إضافة redirects 301
   - توحيد المكونات في `src/components/learning/`

2. **توحيد Control Center**
   - دمج `/owner`, `/owner-panel`, `/admin` تحت `/control-center`
   - الصلاحيات: OWNER vs ADMIN vs GENERAL_MANAGER
   - إضافة redirects 302 (مؤقت، للحفاظ على backward compat)

3. **توحيد AI**
   - دمج `/ai-assistant`, `/economy/ai-assistant` تحت `/ai/*`
   - تبويبات للأنواع: General, Economic, Research, Career, Investment, Content
   - إضافة redirects 301

4. **توحيد Messaging**
   - `Unified Messaging Layer`
   - `ConversationContext` for job/consultation/marketplace
   - صفحة `/messages` واحدة تعرض كل الأنواع

5. **توحيد Search**
   - `Central Search Engine` (`src/lib/search-engine.ts` محسّن)
   - `SearchIndex` model
   - GIN indexes على PostgreSQL
   - `/search` صفحة واحدة متقدمة

6. **توحيد Marketplace Core**
   - `MarketplaceService` موحّد
   - Workflow: Request → Offers → Selection → Payment → Execution → Delivery → Review

7. **توحيد Economy Data Layer**
   - `EconomicDataService` مركزي
   - كل الصفحات تأخذ البيانات منه بدل الاستدعاءات المنفصلة

### معايير القبول

- [ ] عدد المسارات المكررة = 0
- [ ] جميع redirects تعمل (HTTP 301/302)
- [ ] لا يوجد API مكرر لنفس الوظيفة
- [ ] كل قسم له service layer واضح

---

## 🎨 PHASE 3 — Core User Experience

**المدة:** 2 أسابيع
**الأولوية:** 🟡 متوسط

### المخرجات

1. **Personalized Home Feed**
   - Hero + Economic Snapshot + Trending + Recommended
   - خوارزمية توصية مبنية على:
     - اهتمامات المستخدم
     - تخصصه
     - موقعه
     - نشاطه
     - بحثه السابق

2. **Profile Page Redesign**
   - تبويبات: نظرة عامة، مقالات، نقاشات، وظائف، خدمات، شهادات
   - شارات: Verified, Premium, Top Contributor
   - إحصائيات مرئية

3. **Discover Page**
   - `/discover` يجمع: People, Experts, Companies, Jobs, Services, Products, Research
   - فلاتر متقدمة + search

4. **Notifications Hub**
   - تبويبات: Social, Jobs, Marketplace, Finance, System, Security
   - إعدادات تفضيلات لكل نوع

5. **Search Experience**
   - بحث موحّد عبر كل الأنواع
   - autocomplete + suggestions
   - filters + sort + save searches

### معايير القبول

- [ ] Home Feed يعرض محتوى مخصصًا خلال < 1s
- [ ] Profile Page تعرض كل بيانات المستخدم بشكل منظّم
- [ ] Search يدعم كل الأنواع مع نتائج خلال < 500ms

---

## 💼 PHASE 4 — Career Platform

**المدة:** 2 أسابيع
**الأولوية:** 🟡 متوسط

### المخرجات

1. **Midan Career Platform** (`/career/*`)
   - توحيد `/jobs`, `/jobs/candidate/*`, `/jobs/employer/*`
   - إضافة redirects

2. **ATS Pipeline**
   - Applied → Review → Shortlisted → Interview → Offer → Hired
   - Kanban view للـ employers

3. **Candidate Profile Enhanced**
   - مهارات، تعليم، خبرة، روابط
   - CV Builder محسّن
   - Self-assessment

4. **AI Job Matching**
   - مطابقة Skills + Experience + Education + Location + Salary + Job Type
   - احترام صلاحيات الوصول للبيانات

5. **CV Bank Enhanced**
   - للـ employers: بحث، فلترة، حفظ المرشحين
   - للـ candidates: خصوصية + تحكم في الرؤية

### معايير القبول

- [ ] ATS Pipeline يدعم كل المراحل
- [ ] AI Matching يحترم الـ privacy
- [ ] CV Bank آمن (permissions محكمة)

---

## 👨‍🏫 PHASE 5 — Experts & Consulting

**المدة:** 1-2 أسبوع
**الأولوية:** 🟢 منخفض

### المخرجات

1. **Expert Directory** (`/experts`)
   - تصفّح، فلترة، بحث
   - Profiles مع شارات

2. **Expert Market** (`/expert-market`)
   - بيع/حجز الاستشارات
   - تقويم + توافر

3. **Consultation Workflow**
   - Booking → Payment → Session → Review
   - دعم video call integration (مستقبلاً)

4. **Consultant Dashboard** محسّن

### معايير القبول

- [ ] الفصل الواضح بين Directory و Market
- [ ] Booking workflow كامل
- [ ] Reviews موثوقة

---

## 📊 PHASE 6 — Economy Intelligence

**المدة:** 2 أسابيع
**الأولوية:** 🟡 متوسط

### المخرجات

1. **Economic Dashboard** موحّد
2. **Indicators Layer** محسّن
3. **Iraq Economic Map** تفاعلي
4. **Economic Calendar**
5. **Central Economic Data Layer** (`src/lib/economic/index.ts`)
6. **AI Economic Analyst** (تحت `/ai/economic`)

### معايير القبول

- [ ] كل البيانات من مصدر واحد
- [ ] الخريطة تعرض 18 محافظة
- [ ] التحديثات في الوقت الفعلي (SSE)

---

## 🎓 PHASE 7 — Academy & Research

**المدة:** 2 أسابيع
**الأولوية:** 🟡 متوسط

### المخرجات

1. **Unified Learning** (`/learning/*`)
2. **Academy** (الأكاديمية الرسمية)
3. **Courses** مع video player
4. **Learning Paths** متعددة
5. **Quizzes** تفاعلية
6. **Certificates** قابلة للتحقق
7. **Research Platform** (`/research/*`)

### معايير القبول

- [ ] شهادات مع UUID قابل للتحقق
- [ ] Course progress tracking
- [ ] Research collaboration tools

---

## 🛒 PHASE 8 — Marketplace

**المدة:** 2-3 أسابيع
**الأولوية:** 🟡 متوسط

### المخرجات

1. **Unified Marketplace Core**
2. **Services + Products + Stores + Providers + Requests**
3. **Order Workflow** كامل
4. **Reviews** موثوقة
5. **Payments** integration
6. **Seller/Provider Dashboards**

### معايير القبول

- [ ] كل workflow ينجز بدون أخطاء
- [ ] Reviews لا يمكن تزييفها
- [ ] Payments آمنة (atomic transactions)

---

## 💰 PHASE 9 — Finance

**المدة:** 2 أسابيع
**الأولوية:** 🔴 حرج

### المخرجات

1. **Wallet** محسّن (atomic transactions)
2. **Transactions** مع idempotency
3. **Invoices** PDF
4. **Withdrawals** workflow
5. **Payouts** للـ experts/sellers
6. **Financial Reports** للإدارة
7. **TransactionAudit** log

### معايير القبول

- [ ] لا double-spending ممكن
- [ ] لا race conditions
- [ ] كل معاملة لها audit trail
- [ ] اختبارات financial security

---

## 🤖 PHASE 10 — Midan AI

**المدة:** 2 أسابيع
**الأولوية:** 🟡 متوسط

### المخرجات

1. **Unified AI Hub** (`/ai/*`)
2. **General Assistant**
3. **Economic Analyst** AI
4. **Research Assistant** AI
5. **Career Assistant** AI
6. **Investment Assistant** AI
7. **Content Assistant** AI
8. **Recommendation Engine**
9. **Moderation AI**

### معايير القبول

- [ ] كل AI يحترم صلاحيات الوصول للبيانات
- [ ] Rate limiting للـ AI calls
- [ ] Caching للنتائج المتكررة
- [ ] Fallback عند فشل الـ AI

---

## 📈 PHASE 11 — Business & Growth

**المدة:** 1-2 أسبوع
**الأولوية:** 🟢 منخفض

### المخرجات

1. **Subscriptions** (BASIC, PREMIUM, EXPERT)
2. **Advertising** platform
3. **Promotions** (paid article visibility)
4. **Analytics** for owners
5. **Company Plans**
6. **Expert Plans**
7. **Marketplace Commissions**

### معايير القبول

- [ ] كل مصدر إيراد موثّق
- [ ] التسعير مركزي (ServicePrice table)

---

## ⚡ PHASE 12 — Optimization (مستمر)

**المدة:** مستمر
**الأولوية:** 🟢 مستمر

### المخرجات

1. **Security Testing** (OWASP ZAP, pen-testing)
2. **Performance Testing** (k6, Lighthouse)
3. **Load Testing** (10K concurrent users)
4. **Database Optimization** (indexes, query tuning)
5. **API Optimization** (caching, N+1 fixes)
6. **Accessibility Testing** (axe-core)
7. **SEO Audit**
8. **Mobile Optimization**
9. **Observability** (Prometheus + Grafana)
10. **Monitoring** (Sentry, Uptime)

### معايير القبول

- [ ] Lighthouse score > 90 لكل صفحة
- [ ] لا ثغرات OWASP Top 10
- [ ] WCAG 2.1 AA compliance
- [ ] Uptime > 99.5%

---

## 📊 KPIs لقياس النجاح

### بعد PHASE 1 (الأسبوع 3)
| KPI | الهدف |
|-----|------|
| TypeScript errors | 0 |
| Test coverage | > 30% |
| Build time | < 90s |
| Bundle size | < 500KB initial |
| Page load (LCP) | < 2.5s |

### بعد PHASE 3 (الأسبوع 7)
| KPI | الهدف |
|-----|------|
| Bounce rate | < 40% |
| Pages per session | > 3 |
| Time on site | > 4 min |
| Mobile responsive | 100% |

### بعد PHASE 9 (الأسبوع 18)
| KPI | الهدف |
|-----|------|
| Financial accuracy | 100% |
| Transaction success rate | > 99.5% |
| Withdrawal processing | < 24h |

### بعد PHASE 12 (الأسبوع 26)
| KPI | الهدف |
|-----|------|
| Lighthouse score | > 90 |
| Uptime | > 99.5% |
| User satisfaction (CSAT) | > 4.5/5 |
| Page load (LCP) | < 2s |
| API response time (p95) | < 200ms |

---

## 🎯 الأولويات المطلقة (حسب البرومبت §37)

```text
1. Architecture          ← PHASE 1 (يجب أن يكتمل أولًا)
2. Security              ← PHASE 1 + 9 + 12
3. Authorization         ← PHASE 1 (RBAC + Scope)
4. Design System         ← PHASE 1 (Tokens)
5. Navigation            ← PHASE 1 (Unified config)
6. Core UX               ← PHASE 3
7. Data Layer            ← PHASE 2 (Locations + Search + Messaging)
8. Career                ← PHASE 4
9. Economy               ← PHASE 6
10. Marketplace          ← PHASE 8
11. Finance              ← PHASE 9 (حرج)
12. AI                   ← PHASE 10
13. Growth               ← PHASE 11
```

---

## ⚠️ المخاطر العامة

| الخطر | الاحتمالية | التأثير | التخفيف |
|------|----------|--------|---------|
| فقدان بيانات أثناء migrations | منخفضة | كارثي | backup قبل كل migration + اختبار على staging |
| كسر روابط قديمة (SEO) | متوسطة | عالي | 301 redirects لكل مسار قديم |
| Performance degradation | متوسطة | متوسط | caching + indexing + monitoring |
| Security regression | منخفضة | كارثي | security testing بعد كل phase |
| User confusion من التغييرات | متوسطة | متوسط | announcement + onboarding tour |

---

## 📦 المخرجات النهائية المتوقعة

بعد إكمال جميع المراحل:

1. **منصة موحّدة** بهوية واحدة وتجربة واحدة
2. **بنية قابلة للتوسع** تدعم عشرات الوحدات المستقبلية
3. **نظام صلاحيات دقيق** (RBAC + Scope + Organization)
4. **معاملات مالية آمنة** (atomic + auditable)
5. **اختبارات شاملة** (> 70% coverage)
6. **أداء عالي** (Lighthouse > 90)
7. **أمان قوي** (لا ثغرات OWASP Top 10)
8. **توثيق كامل** (10 وثائق تخطيط + OpenAPI)
9. **مراقبة 24/7** (Sentry + metrics + uptime)
10. **تجربة مستخدم احترافية** متّسقة عبر كل الأقسام

---

## 🔗 روابط ذات صلة

- `01_PROJECT_AUDIT.md` — وضع البداية
- `10_MIGRATION_PLAN.md` — تفاصيل الترحيل
- جميع الوثائق `02-09` للمحاور المحددة

</div>
