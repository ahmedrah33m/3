# ميدان | دليل التصميم المرجعي (Design Reference Guide V2)

<div dir="rtl">

**المنصة:** ميدان (Midan) — منصة اقتصادية ومهنية عراقية
**تاريخ الإصدار:** 2026-08-23
**المرجع:** Screenshot 2026-08-15 — Design System المرئي

---

## 🎯 الفلسفة التصميمية الجديدة

المنصة تتبنى **Modern Clean UI** بأسلوب احترافي يجمع بين:
- **طاقة متوسطة (Medium Energy)** — ليست صارمة جدًا ولا مرحًا، بل متوازنة
- **احترافية محلية** — مصممة خصيصًا للمحترفين العراقيين
- **مينيمالية مع دفء** — نظيفة، مساحات بيضاء، مع ألوان دافئة

### الجملة الإرشادية:
> *"A professional brand with medium energy for Iraqi professionals."*

---

## 🎨 نظام الألوان الجديد

### الألوان الأساسية

| Token | HEX | الاستخدام |
|-------|-----|---------|
| `--color-primary` | `#A9000C` | الأحمر الكريمزي — للأزرار الأساسية، الروابط، التأكيد |
| `--color-secondary` | `#DCA4B1` | الوردي البيج — للعناصر الثانوية، البطاقات المميزة |
| `--color-accent` | `#A9000C` | نفس Primary — للتأكيد |
| `--color-background` | `#F2F6F8` | رمادي فاتح مزرق — الخلفية العامة |
| `--color-surface` | `#FFFFFF` | أبيض — خلفية البطاقات |

### ألوان النصوص

| Token | HEX | الاستخدام |
|-------|-----|---------|
| `--color-text-primary` | `#5E646C` | النص الأساسي — رمادي داكن، سهل القراءة |
| `--color-text-secondary` | `#8A929B` | النص الثانوي |
| `--color-text-muted` | `#B5BAC0` | النص الخافت |
| `--color-link` | `#C6536A` | الروابط — وردي محمر |

### الألوان الدلالية (Semantic)

| Token | HEX | الاستخدام |
|-------|-----|---------|
| `--color-success` | `#2D8659` | أخضر — للنجاح والتأكيد |
| `--color-warning` | `#D17B0F` | برتقالي — للتنبيه |
| `--color-danger` | `#A9000C` | أحمر — للأخطاء والإجراءات الحذّارة |
| `--color-info` | `#2B6CB0` | أزرق — للمعلومات |

### ألوان إضافية

| Token | HEX | الاستخدام |
|-------|-----|---------|
| `--color-divider` | `#E5E9ED` | الفواصل |
| `--color-hover` | `#EDF2F7` | خلفية التحويم |
| `--color-overlay` | `rgba(0,0,0,0.4)` | الطبقات الشفافة |

---

## 🔤 نظام الخطوط

```css
/* الخط الأساسي */
--font-family-sans: "Noto Sans Arabic", "Segoe UI", system-ui, -apple-system, sans-serif;

/* خط المونوسبيس (للأرقام والكود) */
--font-family-mono: "Cascadia Code", "Fira Code", ui-monospace, monospace;
```

### السلم الطباعي (Type Scale)

| المستوى | الحجم | ارتفاع السطر | الوزن | الاستخدام |
|---------|------|--------------|------|---------|
| Display | 48px | 1.1 | 700 | Hero عناوين |
| H1 | 36px | 1.2 | 700 | عناوين الصفحات |
| H2 | 28px | 1.3 | 600 | عناوين الأقسام |
| H3 | 22px | 1.4 | 600 | عناوين البطاقات |
| H4 | 18px | 1.4 | 600 | عناوين فرعية |
| Body Large | 18px | 1.6 | 400 | النصوص الرئيسية |
| Body | 16px | 1.6 | 400 | النص الافتراضي |
| Body Small | 14px | 1.5 | 400 | النصوص الثانوية |
| Caption | 13px | 1.4 | 500 | التسميات التوضيحية |
| Overline | 11px | 1.2 | 600 (UPPERCASE) | تسميات صغيرة |

---

## 📐 نظام المسافات (Spacing Scale)

أساس 4px:

```css
--space-0: 0;
--space-1: 4px;   /* xs */
--space-2: 8px;    /* sm */
--space-3: 12px;   /* md */
--space-4: 16px;   /* base */
--space-5: 20px;   /* lg */
--space-6: 24px;   /* xl */
--space-8: 32px;   /* 2xl */
--space-10: 40px;  /* 3xl */
--space-12: 48px;  /* 4xl */
--space-16: 64px;  /* 5xl */
--space-20: 80px;  /* 6xl */
--space-24: 96px;  /* section gap */
```

### مسافات دلالية

```css
--space-card-padding: 24px;
--space-page-padding: 32px;
--space-section-gap: 64px;
--space-nav-item: 12px;
--space-form-field: 16px;
```

---

## 📦 نظام نصف القطر (Border Radius)

```css
--radius-sm: 6px;     /* بطاقات صغيرة، شارات */
--radius-md: 8px;     /* بطاقات، حقول */
--radius-lg: 12px;    /* بطاقات كبيرة، modals */
--radius-xl: 16px;    /* الأقسام الرئيسية */
--radius-full: 9999px; /* أزرار دائرية، avatars */
```

**القاعدة:** نصف قطر واحد متّسق في كل المنصة (افتراضي: `--radius-md` = 8px).

---

## 🌫️ نظام الظلال (Shadows)

```css
/* ظلال خفيفة — للبطاقات */
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);

/* ظلال متوسطة — للعناصر الطافية */
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);

/* ظلال كبيرة — للـ dropdowns, popovers */
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);

/* ظلال ضخمة — للـ modals */
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
```

**القاعدة:** الظلال فقط للعناصر الطافية فعلاً (dropdowns, modals, popovers). البطاقات والـ buttons الثابتة بلا ظل.

---

## 🎭 نظام الأيقونات

- **المجموعة:** Lucide React (موجودة بالفعل ✅)
- **الوزن:** 1.5 (stroke-width)
- **الحجم:** متناسق مع النص بجانبها
  - inline: 16px (w-4 h-4)
  - standalone: 20px (w-5 h-5)
  - بطاقات: 24px (w-6 h-6)

**ممنوع:** وضع أيقونة داخل صندوق ملوّن (tinted square). الأيقونة تجلس مباشرة على الخلفية بحجم النص.

---

## 📦 المكوّنات الأساسية (Components)

### 1. البطاقة (Card)

```tsx
<div className="bg-white rounded-lg border border-[#E5E9ED] p-6">
  {/* المحتوى */}
</div>
```

- خلفية بيضاء نقية
- حدود رفيعة (`#E5E9ED`)
- لا ظل (unless floating)
- نصف قطر 12px

### 2. الزر الأساسي (Primary Button)

```tsx
<button className="bg-[#A9000C] hover:bg-[#8B000A] text-white rounded-md px-5 py-2.5 text-sm font-medium transition-colors duration-150">
  ابدأ الآن
</button>
```

- لون أساسي: `#A9000C`
- ارتفاع: 40px
- نصف قطر: 8px
- مسافة أفقية: 20px

### 3. الزر الثانوي (Secondary Button)

```tsx
<button className="bg-[#F2F6F8] hover:bg-[#EDF2F7] text-[#5E646C] rounded-md px-5 py-2.5 text-sm font-medium border border-[#E5E9ED] transition-colors duration-150">
  إلغاء
</button>
```

### 4. حقل الإدخال (Input)

```tsx
<input
  type="text"
  className="bg-white border border-[#E5E9ED] rounded-md px-4 py-2.5 text-sm text-[#5E646C] focus:outline-none focus:border-[#A9000C] focus:ring-2 focus:ring-[#A9000C]/20 transition-all"
/>
```

### 5. الشارة (Badge)

```tsx
<span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-[#A9000C]/10 text-[#A9000C]">
  مميز
</span>
```

### 6. الأفاتار (Avatar)

```tsx
<div className="w-10 h-10 rounded-full bg-[#DCA4B1] flex items-center justify-center text-white font-medium">
  أح
</div>
```

---

## 🧭 قواعد التخطيط (Layout Rules)

### 1. الحد الأقصى للعرض
```css
--container-max-width: 1280px;
--content-max-width: 720px;  /* للمقالات */
--card-grid-max-width: 1100px;
```

### 2. هيكل الصفحة

```tsx
<div className="min-h-screen bg-[#F2F6F8]">
  <Navbar />
  <main className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8">
    {/* محتوى الصفحة */}
  </main>
  <Footer />
</div>
```

### 3. الشبكة (Grid)

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {/* بطاقات */}
</div>
```

---

## ✨ قواعد التفاعل (Interaction Rules)

### Hover States
- تغيير لون الخلفية أو الحدود فقط
- المدة: 120-150ms ease-out
- ❌ ممنوع: scale, glow, lift, translate

### Focus States
```css
:focus-visible {
  outline: 2px solid #A9000C;
  outline-offset: 2px;
}
```

### Loading States
- Skeleton loaders بـ shimmer effect
- لا spinners للصفحات (فقط للأزرار)

### Empty States
- أيقونة + عنوان + وصف + زر إجراء

### Error States
- أيقونة + رسالة + زر إعادة المحاولة

---

## 🌐 دعم RTL

```css
[dir="rtl"] {
  text-align: right;
}

/* استخدام Logical Properties */
margin-inline-start: 8px;  /* بدل margin-right */
padding-inline-end: 16px;  /* بدل padding-left */
inset-inline-start: 0;     /* بدل left */
border-start-start-radius: 8px;
```

---

## 📱 Responsive Breakpoints

```css
sm:  640px;   /* mobile landscape */
md:  768px;   /* tablet portrait */
lg:  1024px;  /* desktop */
xl:  1280px;  /* large desktop */
2xl: 1536px;  /* extra large */
```

### استراتيجية التخطيط
- **Mobile (<768):** صفحة واحدة عمودية + bottom nav
- **Tablet (768-1024):** شبكة بعمودين
- **Desktop (>1024):** Sidebar + محتوى رئيسي

---

## 🎨 قواعد عامة مهمة

### ✅ يجب
1. استخدام الألوان من الـ tokens فقط
2. مسافات بمضاعفات 4px
3. ألوان نصوص بتباين ≥ 4.5:1
4. HTML دلالي (`header`, `nav`, `main`, `section`, `article`, `aside`, `footer`)
5. `aria-label` للأيقونات
6. فصل المحتوى بـ whitespace أو حدود 1px
7. كل صفحة لها loading/empty/error states

### ❌ ممنوع
1. التدرجات اللونية blue→purple
2. النصوص المتدرجة (gradient text)
3. الظلال على البطاقات الثابتة
4. أيقونات الـ sparkle ✨ كـ "AI"
5. الـ emoji كواجهة (فقط كمحتوى مستخدم)
6. الأيقونات داخل صناديق ملوّنة
7. Em dash (—) في النصوص
8. hover: scale, glow, lift
9. Full-viewport sections لمجرد التأثير
10. كلمات مثل "seamless", "supercharge", "cutting-edge"

---

## 📋 قائمة فحص كل صفحة

قبل اعتماد أي صفحة:

- [ ] تستخدم ألوان من الـ tokens
- [ ] مسافات بمضاعفات 4px
- [ ] لها loading state
- [ ] لها empty state
- [ ] لها error state
- [ ] تستجيب لـ breakpoints (sm/md/lg)
- [ ] تدعم RTL
- [ ] تباين النص ≥ 4.5:1
- [ ] لها focus states
- [ ] لا تحتوي على عناصر ممنوعة (تدرجات، sparkle، إلخ)
- [ ] HTML دلالي
- [ ] لا تحتوي على أحجام عشوائية

</div>
