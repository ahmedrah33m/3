# 09 — تدقيق الأمان | Security Audit

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §27 (قواعد الأمان) و §34 (المطلوب عدم فعله)

---

## 🎯 الهدف

تدقيق شامل للأمان في منصة ميدان، وتحديد الثغرات المحتملة، ووضع خطة معالجة. الأمان في منصة بها محفظة مالية وبيانات مستخدمين حساسة (سير ذاتية، شركات) **ليس اختياريًا**.

---

## ✅ نقاط القوة الأمنية الحالية

### 1. Authentication & Session Management (قوي جدًا)

| المكوّن | الملف | التقييم |
|---------|------|---------|
| JWT (jose) | `src/lib/edge-auth.ts` | ✅ قوي، ES256 |
| Password hashing | `src/lib/auth.ts` (bcryptjs) | ✅ salt rounds = 10 |
| Token blacklist | `src/lib/token-blacklist-edge.ts` | ✅ للـ logout فوري |
| Session cookies | httpOnly + secure + sameSite | ✅ |
| 2FA (TOTP) | `src/lib/two-factor.ts` | ✅ مع backup codes |
| WebAuthn | `src/lib/security/webauthn.ts` | ✅ للأجهزة الحديثة |
| OAuth Google | `src/app/api/auth/google/` | ✅ state parameter |
| Email verification | 6-digit code | ✅ |
| Password reset | token-based, expires | ✅ |
| Magic links | `src/lib/security/magic-links.ts` | ✅ للـ passwordless |
| Brute force guard | `src/lib/security/brute-force-guard.ts` | ✅ 5 محاولات/ساعة |
| Account lockout | `src/lib/security/account-lockout.ts` | ✅ بعد 10 محاولات |
| Login anomaly | `src/lib/security/login-anomaly.ts` | ✅ new device/location |

### 2. CSRF & XSS Protection (قوي)

| المكوّن | الحالة |
|---------|------|
| CSRF (double-submit cookie) | ✅ في كل POST/PUT/DELETE |
| HTML sanitizer | `src/lib/html-sanitizer.ts` ✅ |
| Content injection guard | `src/lib/security/content-injection-guard.ts` ✅ |
| CSP headers | مُعدّة في `next.config.ts` ✅ |
| X-Frame-Options: DENY | ✅ |
| X-Content-Type-Options: nosniff | ✅ |
| Referrer-Policy | ✅ |

### 3. Rate Limiting & Bot Detection (قوي)

| المكوّن | الحالة |
|---------|------|
| Rate limiting (in-memory + Redis) | ✅ multi-tier |
| Bot detection | `src/lib/security/bot-detection.ts` ✅ |
| Anti-scraping | `src/lib/security/anti-scraping.ts` ✅ |
| IP reputation | `src/lib/security/ip-reputation.ts` ✅ |
| Geographic access control | `src/lib/security/geo-access-control.ts` ✅ |
| DoS protection | `src/lib/security/dos-protection.ts` ✅ |
| Tiered rate limit | `src/lib/security/tiered-rate-limit.ts` ✅ |

### 4. Encryption (قوي)

| المكوّن | الحالة |
|---------|------|
| Encryption at rest | `src/lib/security/encryption-at-rest.ts` ✅ (AES-256-GCM) |
| Encrypted fields | `src/lib/encrypted-fields.ts` ✅ |
| TLS/HTTPS | إجباري عبر Caddyfile ✅ |
| HSTS | max-age=31536000 + preload ✅ |
| Passwords in DB | bcrypt hash (لا تشفير عكسي) ✅ |

### 5. Authorization (متوسط — يحتاج تحسين)

| المكوّن | الحالة |
|---------|------|
| Role-based access | ✅ USER/EXPERT/ADMIN/MODERATOR/OWNER |
| `requireAuth()` | ✅ متّسق |
| `requireAdmin()` | ✅ |
| `requireOwner()` | ✅ |
| Permission Engine (RBAC + Scope) | ❌ **مفقود — مطلوب في PHASE 1** |
| Resource ownership checks | ⚠️ جزئي |

### 6. Input Validation (قوي)

| المكوّن | الحالة |
|---------|------|
| Zod schemas | ✅ في معظم الـ routes |
| Input validation | `src/lib/security/input-validation.ts` ✅ |
| SQL injection protection | ✅ Prisma ORM (parameterized) |
| File upload validation | `src/lib/security/file-scanner.ts` ✅ |
| Data classification | `src/lib/security/data-classification.ts` ✅ |
| Data leak prevention | `src/lib/security/data-leak-prevention.ts` ✅ |
| Data masking | `src/lib/security/data-masking.ts` ✅ |

### 7. Audit & Logging (قوي)

| المكوّن | الحالة |
|---------|------|
| Audit log | `src/lib/audit.ts` ✅ |
| Enhanced audit | `src/lib/security/audit-enhanced.ts` ✅ |
| Audit trail | `src/lib/security/audit-trail.ts` ✅ |
| Activity logger | `src/lib/activity-logger.ts` ✅ |
| App logger | `src/lib/app-logger.ts` ✅ |

### 8. Advanced Security Features (قوي)

| المكوّن | الحالة |
|---------|------|
| Zero trust architecture | `src/lib/security/zero-trust.ts` ✅ |
| API firewall | `src/lib/security/api-firewall.ts` ✅ |
| API key manager | `src/lib/security/api-key-manager.ts` ✅ |
| API scanner | `src/lib/security/api-scanner.ts` ✅ |
| Request integrity | `src/lib/security/request-integrity.ts` ✅ |
| CSP builder | `src/lib/security/csp-builder.ts` ✅ |
| CORS config | `src/lib/security/cors-config.ts` ✅ |
| Security headers | `src/lib/security/security-headers.ts` ✅ |
| Session hardening | `src/lib/security/session-hardening.ts` ✅ |
| Session manager | `src/lib/security/session-manager.ts` ✅ |
| Account deletion | `src/lib/security/account-deletion.ts` ✅ |
| Account lockout | `src/lib/security/account-lockout.ts` ✅ |
| Email change flow | `src/lib/security/email-change-flow.ts` ✅ |
| Magic links | `src/lib/security/magic-links.ts` ✅ |
| Permission engine | `src/lib/security/permission-engine.ts` ⚠️ موجود لكن يحتاج ربط |
| Password policy | `src/lib/security/password-policy.ts` ✅ |
| Admin MFA | `src/lib/security/admin-mfa.ts` ✅ |

### 9. DevOps Security

| المكوّن | الحالة |
|---------|------|
| Docker images | ✅ non-root user |
| Environment secrets | ✅ في `.env` (gitignored) |
| Secrets rotation | `src/lib/security/env-secrets.ts` ✅ |
| Database connection | ✅ SSL في الإنتاج |
| Redis password | مطلوب في الإنتاج |

---

## ⚠️ الثغرات والفجوات الأمنية

### حرج (Critical) 🔴

#### 1. Permission Engine غير مُفعّل بالكامل

**المشكلة:** رغم وجود `src/lib/security/permission-engine.ts`، إلا أنه:
- لا يُستخدم في كل الـ API routes
- لا يدعم Geographic/Organization Scope
- الصلاحيات ما زالت role-based فقط

**التأثير:** 
- ADMIN يرى كل شيء بلا حدود جغرافية
- GENERAL_MANAGER و BRANCH_MANAGER غير مدعومين

**الحل:** PHASE 1 — تنفيذ Permission Engine كامل + استخدامه في كل route.

#### 2. отсутствует Idempotency للمعاملات المالية

**المشكلة:** لا يوجد `IdempotencyKey` في `/api/wallet/transfer`, `/api/payments/process`. لو ضغط المستخدم زر "ادفع" مرتين بسرعة، قد تحدث معاملتان.

**التأثير:** خسارة مالية مزدوجة.

**الحل:** PHASE 9 — إضافة `IdempotencyKey` model + header check.

#### 3. لا يوجد TransactionAudit مستقل

**المشكلة:** `AuditLog` عام، لا يوجد سجل تفصيلي للمعاملات المالية بحالة قبل/بعد.

**التأثير:** صعوبة في الـ forensics عند حدوث خطأ مالي.

**الحل:** PHASE 9 — إضافة `TransactionAudit` model.

### عالي (High) 🟠

#### 4. Sentry معطّل

**المشكلة:** `SENTRY_DSN` غير مُعدّ في `.env`، فالـ error reporting لا يعمل.

**التأثير:** الأخطاء في الإنتاج لا تُرصد.

**الحل:** تفعيل Sentry في الإنتاج + إضافة `SENTRY_DSN`.

#### 5. بعض الـ API Routes بدون Rate Limiting

**المشكلة:** middleware يطبّق rate-limit على مستوى IP، لكن الـ sensitive endpoints تحتاج rate-limiting إضافي.

**التأثير:** brute force محتمل على بعض endpoints.

**الحل:** إضافة endpoint-specific rate limits (مثل `/api/wallet/withdraw` 5/دقيقة).

#### 6. لا يوجد CAPTCHA

**المشكلة:** لا يوجد CAPTCHA على login/register/forgot-password.

**التأثير:** bot attacks محتملة.

**الحل:** دمج hCaptcha أو Cloudflare Turnstile.

#### 7. Session Fixation غير مُعالج

**المشكلة:** بعد login، session ID لا يتغيّر.

**التأثير:** session fixation attacks.

**الحل:** تجديد session ID بعد login + 2FA verification.

### متوسط (Medium) 🟡

#### 8. بعض الأسرار في `.env` غير مُشفّرة

**المشكلة:** `DATABASE_URL` يحوي password كـ plain text في `.env`.

**التأثير:** لو تسريب `.env`، فالـ DB مكشوفة.

**الحل:** استخدام secrets manager (Vault, AWS Secrets Manager) في الإنتاج.

#### 9. لا يوجد CSP nonce

**المشكلة:** CSP يسمح `'unsafe-inline'` للـ scripts بسبب Next.js requirements.

**التأثير:** XSS أسهل إذا حدث.

**الحل:** استخدام nonce-based CSP (Next.js 16 يدعمه).

#### 10. Redis بدون TLS

**المشكلة:** اتصال Redis بدون TLS في الإنتاج.

**التأثير:** sniffing محتمل على الـ Redis traffic.

**الحل:** تفعيل `rediss://` (TLS) في الإنتاج.

#### 11. لا يوجد Security Headers للـ Subresources

**المشكلة:** `frame-ancestors 'none'` موجود، لكن لا يوجد `child-src` أو `worker-src`.

**التأثير:** possible clickjacking عبر workers.

**الحل:** إضافة `child-src 'self'; worker-src 'self'`.

### منخفض (Low) 🟢

#### 12. لا يعم Device Fingerprinting قوي

**المشكلة:** `src/lib/security/device-fingerprint.ts` موجود لكنه بسيط.

**التأثير:** صعوبة في كشف account sharing.

**الحل:** تحسين خوارزمية fingerprint.

#### 13. بعض الـ APIs تُرجع stack traces

**المشكلة:** في وضع التطوير، الأخطاء تُرجع stack trace كامل.

**التأثير:** information disclosure.

**الحل:** تعطيل في الإنتاج (تم بالفعل، يحتاج تأكيد).

---

## 🛡️ OWASP Top 10 Coverage

| # | الضعف | الحالة في ميدان |
|---|------|---------------|
| A01 | Broken Access Control | ⚠️ يحتاج Permission Engine |
| A02 | Cryptographic Failures | ✅ قوي (AES-256, bcrypt) |
| A03 | Injection | ✅ Prisma parameterized |
| A04 | Insecure Design | ⚠️ يحتاج unified patterns |
| A05 | Security Misconfiguration | ✅ جيد، يحتاج tuning |
| A06 | Vulnerable Components | ⚠️ يحتاج dependency audit |
| A07 | Auth Failures | ✅ قوي (2FA, brute force) |
| A08 | Software & Data Integrity | ⚠️ يحتاج SRI checks |
| A09 | Logging & Monitoring | ⚠️ Sentry معطّل |
| A10 | SSRF | ✅ URL validation موجود |

---

## 🔐 فحص المكونات الحساسة

### 1. Wallet (المحفظة) — حرج

**الحالة الحالية:**
- ✅ `wallet-service.ts` موجود
- ✅ `payFromWallet()` function
- ❌ لا يوجد idempotency
- ❌ لا يوجد locking ضد race conditions

**اختبار سيناريو (Race Condition):**
```typescript
// لو المستخدم ضغط "ادفع" مرتين في نفس الوقت:
// Request 1: balance = 100, amount = 50, new balance = 50 ✅
// Request 2: balance = 100 (لأن الـ transaction الأولى لم تكتمل), new balance = 50 ❌
// النتيجة: المستخدم دفع 50 لكن رصيده نقص 50 فقط!
```

**الحل:**
```typescript
// استخدام database transaction + row locking
await db.$transaction(async (tx) => {
  const wallet = await tx.wallet.findUnique({ where: { userId } })
  // SELECT ... FOR UPDATE (locking)
  if (wallet.balance < amount) throw new Error('INSUFFICIENT_FUNDS')
  await tx.wallet.update({
    where: { userId },
    data: { balance: { decrement: amount } }
  })
  await tx.walletTransaction.create({ ... })
})
```

### 2. CV Bank — حساس

**الحالة الحالية:**
- ✅ الصلاحيات: COMPANY فقط
- ❌ لا يوجد audit log لكل مرة يرى فيها company سيرة ذاتية

**الحل:** تسجيل كل وصول في `AuditLog`.

### 3. Admin Panel — حساس

**الحالة الحالية:**
- ✅ `requireAdmin()` موجود
- ✅ Admin MFA موجود
- ⚠️ لا يوجد IP whitelist (مطلوب للإنتاج)

**الحل:** تفعيل IP whitelist + VPN-only للـ OWNER.

### 4. File Uploads — حساس

**الحالة الحالية:**
- ✅ `file-scanner.ts` موجود
- ✅ Validation على extension + MIME type
- ⚠️ لا يوجد antivirus scanning

**الحل:** دمج ClamAV في الإنتاج.

### 5. AI APIs — حساس

**الحالة الحالية:**
- ✅ Rate limiting
- ❌ لا يوجد data leakage prevention قبل الإرسال للـ AI

**التأثير:** لو مستخدم طلب من AI "أرني بيانات جميع المستخدمين"، الـ AI قد يُرجعها لو كانت في context.

**الحل:** التحقق من صلاحيات الوصول قبل إرسال أي بيانات للـ AI model.

---

## 📋 خطة المعالجة (Remediation Plan)

### فوري (خلال أسبوع — PHASE 1)

1. ✅ تفعيل `SENTRY_DSN` في الإنتاج
2. ✅ تنفيذ Permission Engine كامل
3. ✅ إضافة endpoint-specific rate limits للـ sensitive endpoints
4. ✅ إضافة CAPTCHA على auth endpoints
5. ✅ تجديد session ID بعد login

### قصير المدى (PHASE 9 — Finance)

6. ✅ إضافة `IdempotencyKey` للمعاملات المالية
7. ✅ إضافة `TransactionAudit` model
8. ✅ Database transactions + row locking
9. ✅ اختبارات financial security

### متوسط المدى (PHASE 12 — Optimization)

10. ✅ Dependency audit (`npm audit`)
11. ✅ SRI checks للـ external scripts
12. ✅ CSP nonce-based
13. ✅ Redis TLS
14. ✅ Antivirus scanning للملفات المرفوعة

### طويل المدى (مستمر)

15. ✅ Pen-testing دوري (كل 6 أشهر)
16. ✅ Bug bounty program
17. ✅ Security training للفريق
18. ✅ Compliance certifications (ISO 27001 مستقبلاً)

---

## ✅ معايير قبول الأمان

| المعيار | الحالة |
|---------|------|
| Permission Engine مُفعّل في كل routes | يجب (PHASE 1) |
| كل معاملة مالية atomic | يجب (PHASE 9) |
| كل_sensitive_ endpoint له rate-limit خاص | يجب (PHASE 1) |
| CAPTCHA على auth endpoints | يجب (PHASE 1) |
| Sentry يلتقط كل الأخطاء | يجب (PHASE 1) |
| لا stack traces في الإنتاج | يجب |
| كل secrets في secrets manager | يجب (الإنتاج) |
| اختبارات أمان دورية | يجب (PHASE 12) |
| لا ثغرات OWASP Top 10 | يجب |
| WCAG 2.1 AA للـ accessibility | يجب |

---

## 🔗 روابط ذات صلة

- `04_PERMISSION_MATRIX.md` — نظام الصلاحيات
- `05_DATABASE_ARCHITECTURE.md` — أمان قاعدة البيانات
- `10_MIGRATION_PLAN.md` — خطة الترحيل الآمن

</div>
