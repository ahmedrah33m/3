# 05 — معمارية قاعدة البيانات | Database Architecture

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §8 (المواقع الجغرافية) و §16 (المالية) و §25 (لا تحذف بيانات)

---

## 🎯 الهدف

توثيق البنية الحالية لقاعدة بيانات ميدان، وتحديد الفجوات، واقتراح إضافات آمنة لا تكسر الموجود. القاعدة الذهبية: **Backward Compatible, Reversible, Safe, Auditable**.

---

## 📊 الحالة الحالية

### إحصائيات

| المؤشر | القيمة |
|--------|--------|
| إجمالي النماذج (Prisma models) | 249 |
| إجمالي الـ Enums | 21 |
| حجم `schema.prisma` | 196KB |
| Migrations | 12+ ملف |
| Seed files | 6 |
| نوع قاعدة البيانات | PostgreSQL 16 |
| ORM | Prisma 6.19.2 |
| Connection limit | 5 (dev) / 50 (prod via PgBouncer) |

### النماذج الرئيسية الموجودة (249)

تم تصنيفها حسب الـ Bounded Context:

#### Core / Identity (15 نموذج)
- `User`, `UserActivity`, `UserActivityLog`, `UserReputation`
- `Account`, `Session` (لـ NextAuth إذا استُخدم)
- `Notification`, `NotificationPreference`
- `AuditLog`, `Achievement`, `UserAchievement`
- `Connection`, `Follow`
- `Report`, `ModerationLog`

#### Content (20 نموذج)
- `Article`, `ArticleAnalytics`, `ArticleMedia`, `ArticleTag`
- `Comment`, `Like`, `Hashtag`, `Tag`
- `Discussion`, `DiscussionReply`, `DiscussionInvite`, `DiscussionFollower`, `DiscussionReference`
- `Question`, `Answer`, `QuestionVote`, `QuestionTag`, `QuestionComment`, `QuestionBounty`, `QuestionBookmark`, `QuestionCommunity`
- `StandalonePoll`, `StandalonePollOption`, `StandalonePollVote`

#### Career / Recruitment (15 نموذج)
- `Job`, `JobApplication`, `JobCategory`, `JobTag`, `JobSkill`
- `CandidateProfile`, `CvBankEntry`
- `Interview`, `Offer`, `PipelineStage`
- `EmployerProfile`
- `Skill`, `Education`, `WorkExperience`

#### Marketplace (25 نموذج)
- `MarketplaceProfile`, `MarketplaceService`, `MarketplaceProduct`
- `MarketplaceOrder`, `MarketplaceOrderItem`
- `MarketplaceRequest`, `MarketplaceOffer`
- `MarketplaceReview`, `MarketplaceReviewReaction`
- `MarketplaceFavorite`, `MarketplaceStore`
- `MarketplacePayment`, `MarketplaceEscrow`

#### Finance / Wallet (15 نموذج)
- `Wallet`, `WalletTransaction`
- `Invoice`, `InvoiceItem`
- `Subscription`, `SubscriptionPlan`, `SubscriptionPayment`
- `Payment`, `PaymentMethod`, `PayoutRequest`
- `ServicePrice`, `PricingConfig` (legacy)
- `Coupon`, `GiftCard`

#### Experts & Consultations (10 نماذج)
- `ExpertVerification`, `ExpertSkill`
- `Consultation`, `ConsultationBooking`, `ConsultationReview`
- `ConsultationSchedule`, `ConsultationReminder`
- `MentorshipRequest`, `MentorshipSession`

#### Learning / Education (20 نموذج)
- `Course`, `CourseLesson`, `CourseModule`, `CourseEnrollment`
- `LearningPath`, `LearningPathItem`, `LearningPathEnrollment`
- `Quiz`, `QuizQuestion`, `QuizAttempt`, `QuizAnswer`
- `Certificate`, `CertificateVerification`
- `EconomicTerm`, `EconomicCategory`

#### Research (10 نماذج)
- `ResearchPaper`, `Researcher`, `ResearchProject`
- `ResearchFunding`, `ResearchCitation`
- `ResearchCollaborator`

#### Economy (15 نموذج)
- `EconomicIndicator`, `EconomicCalendarEvent`
- `MarketPrice`, `CurrencyRate`, `OilPrice`
- `InflationRate`, `GdpData`, `TradeBalance`
- `IraqProvince`, `IraqCity` (موجودة لكن غير مرتبطة FK)
- `BudgetItem`, `GovernmentSpending`

#### Communication (15 نموذج)
- `Message`, `Conversation`, `ConversationParticipant`
- `ChatRoom`, `ChatRoomMember`, `ChatMessage`
- `DirectMessage`, `MessageReaction`, `MessageReadReceipt`
- `EmailLog`, `SmsLog`, `PushNotification`

#### Organization / Admin (10 نماذج)
- `Company`, `CompanyProfile`, `CompanyReview`
- `Ad`, `AdCampaign`, `AdClick`
- `Setting`, `SiteConfig`
- `Announcement`, `Briefing`

#### Security (10 نماذج)
- `CsrfToken`, `RateLimitBucket`
- `LoginAttempt`, `IpBlock`
- `WebauthnCredential`
- `TwoFactorSecret`
- `ApiKey`, `ApiCallLog`
- `SecurityEvent`, `AuditTrail`

#### Social Features (مؤرشفة في `src/lib/social/` — ليست في schema)
- `VoiceRoom`, `RoomParticipant`
- `Debate`, `DebateArgument`, `DebateParticipant`, `DebateVote`
- `CollabDocument`, `DocumentVersion`
- `ArticleSeries`, `SeriesArticle`

#### إجمالي تقريبي: 200+ نموذج موزّعة على الـ contexts أعلاه

---

## ❌ الفجوات الحرجة (Critical Gaps)

### 1. نظام جغرافي موحّد (Critical — PHASE 1)

**المشكلة:**
```typescript
// User.location هو String? — لا يمكن join
// Job.location هو String — لا يمكن filter
// Company.address هو String — لا يمكن aggregate
// ServiceArea.serviceLocations هو JSON — لا يمكن index
```

**الحل:** إضافة نماذج Location جديدة + إضافة FK columns (تبقى String القديمة لـ backward compat):

```prisma
model Country { ... }        // IQ, SA, AE
model Governorate { ... }    // Baghdad, Basra, Nineveh
model City { ... }           // Baghdad City, Basra City
model Area { ... }           // Karrada, Jadriya
model Branch { ... }         // ربط بالـ Organization
```

**Migration آمنة:**
1. إنشاء النماذج الجديدة (empty)
2. Seed ببيانات العراق (18 محافظة)
3. إضافة columns جديدة `governorateId`, `cityId` كـ nullable FK
4. تدريجيًا: backfill من `User.location` (string) إلى `User.governorateId` (FK)
5. لا حذف للـ string القديم

### 2. نظام الصلاحيات الدقيق (Critical — PHASE 1)

**المشكلة:**
- `UserRole` فقط (5 قيم)
- لا يوجد جدول `Permission`
- لا يوجد `RolePermission`
- لا يوجد `UserOrganizationRole`

**الحل:** إضافة النماذج كما هو موثّق في `04_PERMISSION_MATRIX.md`.

### 3. التدقيق المالي (Critical — PHASE 9)

**المشكلة:**
- `WalletTransaction` موجود لكن:
  - لا يوجد `idempotencyKey` (خطر double-spending)
  - لا يوجد `reference` فريد عبر الأنظمة
  - لا يوجد `auditTrail` منفصل لكل تعديل

**الحل:** إضافة:
```prisma
model TransactionAudit {
  id              String   @id @default(cuid())
  transactionId   String
  actorId         String   // من قام بالتعديل
  action          String   // CREATE | UPDATE | DELETE | REVERSE
  previousState   Json?
  newState        Json?
  reason          String?
  ipAddress       String?
  userAgent       String?
  timestamp       DateTime @default(now())
  
  @@index([transactionId])
  @@index([actorId, timestamp])
}

model IdempotencyKey {
  id              String   @id @default(cuid())
  key             String   @unique  // client-generated
  endpoint        String   // e.g., "POST /api/wallet/transfer"
  requestBodyHash String
  responseStatus  Int?
  responseBody    String?
  expiresAt        DateTime
  createdAt       DateTime @default(now())
  
  @@index([key, expiresAt])
}
```

### 4. نظام بحث مركزي (Medium — PHASE 2)

**المشكلة:**
- Full-text search عبر `Article`, `Job`, `User`, `Service`, `Product` متكرر
- لا يوجد unified search index
- PostgreSQL trigram indexes موجودة لكن غير موحّدة

**الحل:** إضافة:
```prisma
model SearchIndex {
  id          String   @id @default(cuid())
  entityType  String   // article | job | user | service | product | ...
  entityId    String
  title       String
  content     String   // markdown stripped
  keywords    String[] // extracted
  language    String   @default("ar")
  isPublished Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  @@unique([entityType, entityId])
  @@index([entityType, isPublished])
}
// مع GIN index على (title, content) باستخدام tsvector
```

### 5. الشهادات (Certificate) — موجود جزئيًا

**الحل:** إضافة:
```prisma
model Certificate {
  id              String   @id @default(cuid())
  certificateNumber String @unique  // MDN-2026-XXXXXX
  holderId        String   // User ID
  courseId        String?
  learningPathId String?
  issuedById      String   // Instructor/Org ID
  issueDate       DateTime @default(now())
  expiryDate      DateTime?
  score           Float?
  metadata        Json?
  
  holder          User     @relation(fields: [holderId], references: [id])
  
  @@index([holderId])
  @@index([certificateNumber])
}

model CertificateVerification {
  id            String   @id @default(cuid())
  certificateId String
  verifiedBy    String   // IP or User ID
  verifiedAt    DateTime @default(now())
  
  certificate   Certificate @relation(fields: [certificateId], references: [id])
  
  @@index([certificateId])
}
```

### 6. Messaging موحّد (Medium — PHASE 2)

**المشكلة:**
- 3 أنواع messaging (DM, Chat Rooms, Consultation Messenger)
- لا يوجد `MessageType` discriminator موحّد
- لا يوجد `ConversationContext` (job_id, consultation_id, order_id)

**الحل:** إضافة:
```prisma
// إضافة حقول على Conversation الموجود
// contextType  String?  // direct | job | consultation | marketplace | company
// contextId    String?  // ID of the related entity

// إذا لم يكن Conversation موجودًا، نضيف:
model ConversationContext {
  id              String   @id @default(cuid())
  conversationId  String
  contextType     String   // job | consultation | order | service | product | company
  contextId       String
  createdAt       DateTime @default(now())
  
  @@unique([conversationId, contextType, contextId])
  @@index([contextType, contextId])
}
```

### 7. الإشعارات المُصنّفة (Low — PHASE 3)

**المشكلة:**
- `NotificationType` enum موجود (21 قيمة)
- لكن لا يوجد `category` (Social, Jobs, Marketplace, Finance, System, Security)

**الحل:** إضافة:
```prisma
// إضافة على Notification
// category String  // social | jobs | consultation | marketplace | finance | system | security
// priority String @default("normal")  // low | normal | high | critical
```

---

## 🏗️ المعايير البنيوية

### 1. Type Conventions

```prisma
// ✅ متّبع:
id           String   @id @default(cuid())
createdAt    DateTime @default(now())
updatedAt    DateTime @updatedAt
deletedAt    DateTime?  // soft delete

// 🔴 يحتاج توحيد:
// - بعض النماذج تستخدم @uuid بدل cuid
// - بعضها بدون deletedAt
// - بعضها بدون updatedAt
```

### 2. Indexing Strategy

```prisma
// ✅ Indexes على:
// - FK columns
// - Lookup columns (email, slug, status)
// - Date ranges (createdAt, updatedAt)

// 🔴 يحتاج إضافة:
// - Composite indexes على (status, createdAt) للـ pagination
// - GIN indexes على JSONB fields (tags, metadata)
// - Trigram indexes على text fields للـ search
// - Partial indexes على (WHERE deletedAt IS NULL)
```

### 3. JSON Fields Convention

```prisma
// ✅ استخدام Json? للحقول المرنة
// - User.socialLinks, Article.metadata, WalletTransaction.details

// 🔴 المشاكل:
// - لا يوجد schema validation على Json fields
// - لا يوجد typed access helper
```

### 4. Money/Decimal Handling

```prisma
// 🔴 مشكلة سابقة (محلولة):
// كان يستخدم Float للمال — تم تحويله إلى Decimal في migration 20260812

// ✅ الحالي:
amount      Decimal  @db.Decimal(18, 3)  // 3 digits للـ fils
currency    String   @default("IQD")
```

### 5. Soft Delete Pattern

```prisma
// ✅ Pattern موحّد:
deletedAt   DateTime?
deletedById String?

// في queries:
db.article.findMany({
  where: { deletedAt: null, ... }
})

// ملاحظة: يجب استخدام Prisma middleware لإضافة `deletedAt: null` تلقائيًا
```

---

## 📦 مثال: Migration آمنة

```sql
-- مثال: إضافة Country, Governorate, City, Area, Branch
-- بدون كسر أي جدول موجود

-- Step 1: إنشاء الجداول الجديدة (empty)
CREATE TABLE "Country" (
  "id" TEXT NOT NULL,
  "code" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "nameAr" TEXT,
  "flag" TEXT,
  CONSTRAINT "Country_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "Country_code_key" ON "Country"("code");

-- (نفس الشيء لـ Governorate, City, Area, Branch)
-- ...

-- Step 2: Seed ببيانات العراق
INSERT INTO "Country" ("id", "code", "name", "nameAr", "flag") VALUES
  ('cuid_1', 'IQ', 'Iraq', 'العراق', '🇮🇶');

INSERT INTO "Governorate" ("id", "countryId", "code", "name", "nameAr") VALUES
  ('cuid_bgd', 'cuid_1', 'IQ-BGD', 'Baghdad', 'بغداد'),
  ('cuid_bsr', 'cuid_1', 'IQ-BSR', 'Basra', 'البصرة'),
  -- ... 18 محافظة
  ;

-- Step 3: إضافة FK columns nullable على الجداول الموجودة
ALTER TABLE "User" ADD COLUMN "governorateId" TEXT;
ALTER TABLE "Job" ADD COLUMN "governorateId" TEXT;
ALTER TABLE "Company" ADD COLUMN "governorateId" TEXT;

-- Step 4: FK constraints (لاحظ ON DELETE SET NULL للأمان)
ALTER TABLE "User" 
  ADD CONSTRAINT "User_governorateId_fkey" 
  FOREIGN KEY ("governorateId") REFERENCES "Governorate"("id") 
  ON DELETE SET NULL;

-- Step 5: Backfill script (يدوي أو cron)
-- UPDATE "User" SET "governorateId" = 'cuid_bgd' WHERE "location" ILIKE '%baghdad%';
-- ... تدريجيًا

-- ✅ لا حذف، لا كسر، لا فقدان بيانات
```

---

## 🔄 Connection Pooling Strategy

### Production Setup

```env
# Direct connection (للـ migrations)
DIRECT_DATABASE_URL=postgresql://user:pass@host:5432/db?schema=public&connect_timeout=30

# PgBouncer pooled (للـ app)
DATABASE_URL=postgresql://user:pass@host:6432/db?pgbouncer=true&connection_limit=50

# Read replica (للـ heavy reads)
DATABASE_REPLICA_URL=postgresql://user:pass@host:5433/db?schema=public
```

### Prisma Configuration

```typescript
// prisma/schema.prisma
generator client {
  provider        = "prisma-client-js"
  previewFeatures = ["driverAdapters"]
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
  directUrl = env("DIRECT_DATABASE_URL")
}
```

---

## 📊 Backup Strategy

```text
Daily:    full pg_dump → S3 / MinIO
Hourly:  WAL archiving → continuous replication
Weekly:  full base backup → cold storage
Monthly: snapshot + integrity check

Retention:
- Daily backups: 30 days
- Weekly backups: 12 weeks
- Monthly backups: 12 months
- Yearly backups: 3 years (للـ compliance)
```

النسخ الاحتياطية موجودة في `backups/postgresql/hourly/` ✅

---

## 🧪 الاختبارات المطلوبة

| النوع | التغطية المطلوبة |
|------|------------------|
| Schema validation | كل النماذج |
| Migration safety | كل migration قبل الإنتاج |
| Seed data | كل ملف seed |
| Performance | Queries على أكبر 10 جداول |
| Indexes | EXPLAIN ANALYZE على الـ hot queries |
| Backup restore | شهرية |

---

## 🔗 روابط ذات صلة

- `04_PERMISSION_MATRIX.md` — نماذج الصلاحيات
- `09_SECURITY_AUDIT.md` — أمان قاعدة البيانات
- `10_MIGRATION_PLAN.md` — خطوات الترحيل التفصيلية

</div>
