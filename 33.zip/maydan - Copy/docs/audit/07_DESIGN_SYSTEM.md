# 07 — نظام التصميم | Design System

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §3 (الحفاظ على الهوية البصرية) و §4 (Design System موحد) و §29 (Responsive)

---

## 🎯 الهدف

توحيد نظام تصميم ميدان الحالي (**Visual Refinement وليس Visual Replacement**) عبر:
1. توثيق الهوية البصرية الحالية كـ tokens مركزية
2. توحيد المكوّنات المكررة (Button/GlassButton، Card/GlassCard، إلخ)
3. ضمان اتساق بصري عبر كل الأقسام
4. تحسين قابلية الوصول (Accessibility) والتباين (Contrast)

---

## 🎨 الهوية البصرية الحالية (توثيق)

### الألوان الأساسية

```css
/* Light Mode (افتراضي) */
--background:    oklch(0.97 0.005 240);  /* خلفية كريمية فاتحة */
--foreground:    oklch(0.15 0.02 260);   /* نص أسود مزرق */
--primary:       oklch(0.45 0.20 25);    /* أحمر-برتقالي عميق */
--primary-foreground: oklch(0.99 0.005 0); /* أبيض */
--destructive:   oklch(0.577 0.245 27.325); /* أحمر تحذيري */
--gold:          #D4A853;                /* ذهبي مميّز لميدان */
--gold-light:    #E8C97A;
--gold-dark:     #B8923F;
--radius:        1rem;                   /* 16px — نصف قطر الحواف */

/* Dark Mode */
--background:    oklch(0.10 0.01 260);
--foreground:    oklch(0.95 0.005 260);
--primary:       oklch(0.62 0.22 25);
--destructive:   oklch(0.704 0.191 22.216);
```

### لوحة الألوان الكاملة (المقترحة للتوحيد)

```css
/* ✅ Brand Colors — هوية ميدان */
--color-brand-primary:    oklch(0.45 0.20 25);   /* الأحمر-البرتقالي */
--color-brand-primary-hover: oklch(0.40 0.20 25);
--color-brand-gold:       #D4A853;               /* الذهبي */
--color-brand-gold-hover: #B8923F;

/* 🆕 Semantic Colors — توحيد (مفقودة حاليًا) */
--color-success:    oklch(0.60 0.15 145);        /* أخضر */
--color-success-foreground: oklch(0.99 0.005 0);
--color-warning:    oklch(0.75 0.18 70);         /* أصفر */
--color-warning-foreground: oklch(0.20 0.02 70);
--color-info:       oklch(0.60 0.15 240);        /* أزرق */
--color-info-foreground: oklch(0.99 0.005 0);
--color-danger:      oklch(0.577 0.245 27.325);   /* أحمر */
--color-danger-foreground: oklch(0.99 0.005 0);

/* ✅ Surface Colors — طبقات */
--color-surface-1:   var(--background);
--color-surface-2:   oklch(0.99 0.005 240);       /* بطاقات */
--color-surface-3:   oklch(1 0 0);               /* modals */
--color-surface-glass: rgba(255, 255, 255, 0.6);  /* glass effect */

/* ✅ Text Colors — هرم */
--color-text-primary:    var(--foreground);
--color-text-secondary:  oklch(0.45 0.02 260);
--color-text-muted:      oklch(0.55 0.02 260);
--color-text-disabled:   oklch(0.70 0.02 260);

/* ✅ Border Colors */
--color-border-default: oklch(0.90 0.005 240);
--color-border-strong:  oklch(0.80 0.005 240);
--color-border-focus:   var(--primary);
```

### الخطوط (Typography)

```css
/* ✅ الخط الأساسي */
--font-noto-arabic: 'NotoSansArabic-Variable', 'Noto Sans Arabic', sans-serif;
--font-sans: var(--font-noto-arabic), sans-serif;

/* ✅ خط المونوسبيس */
--font-mono: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, monospace;

/* 🆕 Type Scale موحّد (مقترح) */
--text-2xs:   10px / 14px;   /* badges, captions */
--text-xs:    12px / 16px;   /* small text */
--text-sm:    14px / 20px;   /* body small */
--text-base:  16px / 24px;   /* body default */
--text-lg:    18px / 28px;   /* lead */
--text-xl:    20px / 28px;   /* h4 */
--text-2xl:   24px / 32px;   /* h3 */
--text-3xl:   30px / 36px;   /* h2 */
--text-4xl:   36px / 40px;   /* h1 */
--text-5xl:   48px / 1;      /* hero */
--text-6xl:   60px / 1;      /* display */

/* 🆕 Font Weights */
--font-weight-regular:  400;
--font-weight-medium:   500;
--font-weight-semibold: 600;
--font-weight-bold:     700;
--font-weight-extrabold: 800;
```

### Spacing (المساحات)

```css
/* 🆕 Spacing Scale موحّد (مقترح، مبني على Tailwind default) */
--space-0:   0;
--space-px:  1px;
--space-0.5: 2px;
--space-1:   4px;
--space-2:   8px;
--space-3:   12px;
--space-4:   16px;
--space-5:   20px;
--space-6:   24px;
--space-8:   32px;
--space-10:  40px;
--space-12:  48px;
--space-16:  64px;
--space-20:  80px;
--space-24:  96px;

/* 🆕 Semantic Spacing */
--space-card-padding: 24px;      /* مساحة داخل البطاقة */
--space-section: 64px;           /* مساحة بين الأقسام */
--space-page: 32px;              /* مساحة حواف الصفحة */
--space-nav-item: 12px;          /* مساحة بين عناصر التنقل */
```

### Border Radius

```css
/* ✅ موجود */
--radius: 1rem;          /* 16px — القاعدة */
--radius-sm: calc(var(--radius) - 4px);  /* 12px */
--radius-md: calc(var(--radius) - 2px);  /* 14px */
--radius-lg: var(--radius);              /* 16px */
--radius-xl: calc(var(--radius) + 4px);  /* 20px */
--radius-2xl: calc(var(--radius) + 8px); /* 24px */
--radius-3xl: calc(var(--radius) + 16px);/* 32px */
--radius-full: 9999px;                  /* دائري */
```

### Shadows (الظلال — Glass Style)

```css
/* ✅ موجود في tailwind.config.ts */
--shadow-glass:         0 8px 32px 0 rgba(31, 38, 135, 0.08);
--shadow-glass-sm:      0 4px 16px 0 rgba(31, 38, 135, 0.06);
--shadow-glass-lg:      0 20px 60px rgba(0, 0, 0, 0.15);
--shadow-glass-xl:      0 30px 80px rgba(0, 0, 0, 0.18);
--shadow-glass-inner:   inset 0 1px 0 0 rgba(255, 255, 255, 0.4);
--shadow-glow:          0 0 40px oklch(0.45 0.20 25 / 0.18);
--shadow-glow-sm:       0 0 12px oklch(0.45 0.20 25 / 0.4);
```

### Backdrop Blur

```css
/* ✅ موجود */
--blur-glass: 16px;
--blur-glass-lg: 20px;
--blur-glass-xl: 24px;
--blur-glass-2xl: 40px;
--blur-xs: 4px;
```

### Motion (الحركات)

```css
/* 🆕 Motion Tokens موحّد */
--duration-instant: 0ms;
--duration-fast: 150ms;
--duration-normal: 250ms;
--duration-slow: 400ms;
--duration-slower: 600ms;

--easing-default: cubic-bezier(0.4, 0, 0.2, 1);
--easing-in: cubic-bezier(0.4, 0, 1, 1);
--easing-out: cubic-bezier(0, 0, 0.2, 1);
--easing-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);

/* ✅ Keyframes موجودة في tailwind.config.ts */
shimmer, pulseGlow, float, fadeInUp, scaleIn, slideInRight, ...
```

---

## 🧩 المكوّنات الموحّدة (Components)

### القاعدة الأساسية للتوحيد

| النوع | المكوّن الموصى به | الاستخدام |
|------|-------------------|---------|
| زر عادي | `Button` | UI الافتراضي |
| زر بتأثير زجاجي | `GlassButton` | العناصر البارزة (Hero, CTAs) |
| بطاقة عادية | `Card` | محتوى عادي |
| بطاقة بتأثير زجاجي | `GlassCard` | لوحات، إحصائيات، Hero |
| حقل إدخال عادي | `Input` | نماذج بسيطة |
| حقل إدخال بتأثير زجاجي | `GlassInput` | نماذج بارزة، Auth |
| شارة عادية | `Badge` | حالة، عداد |
| شارة بتأثير زجاجي | `GlassBadge` | شارات مميّزة (Premium, Verified) |
| صورة مستخدم عادية | `Avatar` | في القوائم |
| صورة مستخدم بتأثير زجاجي | `GlassAvatar` | في الـ navbar، البطاقات البارزة |

> **القاعدة:** لا تخلط بين Glass وغير Glass في نفس القسم. اختر أسلوبًا واحدًا لكل صفحة.

### 1. Button (الموحد)

```tsx
// الملف: src/components/ui/button.tsx (موجود ✅)
// ✅ يدعم:
// - variants: default | destructive | outline | secondary | ghost | link
// - sizes: xs | sm | md | lg | xl | icon | icon-sm | icon-lg | icon-xl
// - isLoading + spinner
// - asChild (Slot pattern)
// - RTL support
// - focus-visible ring

// مثال:
<Button variant="default" size="md" isLoading={isSubmitting}>
  حفظ
</Button>

<Button asChild variant="outline">
  <Link href="/articles">المقالات</Link>
</Button>
```

### 2. GlassButton (المميّز)

```tsx
// الملف: src/components/ui/glass-button.tsx (موجود ✅)
// مثال:
<GlassButton variant="gradient" size="lg" className="...">
  ابدأ مجانًا
</GlassButton>
```

### 3. Card / GlassCard

```tsx
// src/components/ui/card.tsx ✅
// src/components/ui/glass-card.tsx ✅
// يدعم: variant (flat | elevated | gradient), size (sm | md | lg), hoverable
```

### 4. Input / GlassInput

```tsx
// src/components/ui/input.tsx ✅
// src/components/ui/glass-input.tsx ✅
// يدعم: startIcon, endIcon, error state, RTL
```

### 5. Dialog (Modal)

```tsx
// src/components/ui/dialog.tsx ✅
// يدعم: RTL, max-width variants, close button, overlay
```

### 6. Loading States

```tsx
// src/components/ui/spinner.tsx ✅
// src/components/ui/skeleton.tsx ✅
// src/components/LoadingStates.tsx ✅ (صفحة كاملة)
```

### 7. Empty States

```tsx
// src/components/EmptyState.tsx ✅
// يدعم: icon, title, description, action button
```

### 8. Error States

```tsx
// src/components/ErrorBoundary.tsx ✅
// src/components/ErrorReporter.tsx ✅
```

---

## 📐 RTL Support

```css
/* ✅ ميدان عربي أولًا */
[dir="rtl"] {
  text-align: right;
}

/* ✅ استخدام Logical Properties (لا物理ية) */
margin-inline-start: 8px;   /* بدل margin-right في RTL */
padding-inline-end: 12px;
inset-inline-start: 0;
border-start-start-radius: 8px;
```

**القاعدة:** لا تستخدم `left`/`right` في CSS. استخدم `inline-start`/`inline-end`.

---

## 📱 Responsive Breakpoints

```css
/* ✅ Tailwind defaults */
sm:  640px;   /* mobile landscape */
md:  768px;   /* tablet portrait */
lg:  1024px;  /* tablet landscape / small desktop */
xl:  1280px;  /* desktop */
2xl: 1536px;  /* large desktop */
```

### Layout Strategy

```text
Mobile (<768px):    BottomNav + صفحة واحدة عمودية
Tablet (768-1024): Sidebar قابل للطي + محتوى مزدوج العمود أحيانًا
Desktop (>1024):   Navbar علوي + Sidebar أيمن + محتوى + Sidebar أيسر اختياري
```

---

## ♿ Accessibility (WCAG 2.1 AA)

### Contrast Targets

| النص | الخلفية | النسبة المطلوبة |
|------|--------|----------------|
| Body text | Background | 4.5:1 |
| Large text (18px+) | Background | 3:1 |
| UI components | Background | 3:1 |
| Disabled text | Background | غير محدد |

### Focus States

```css
/* ✅ موجود */
:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}
```

### Keyboard Navigation

- Tab order منطقي (يسار-يمين في LTR، أعلى-أسفل في RTL)
- Skip-to-content link في بداية كل صفحة
- Escape closes modals/dropdowns
- Enter activates buttons/links
- Arrow keys in dropdowns/menus

### Screen Reader Support

```tsx
// aria-label لكل زر icon-only
<button aria-label="إغلاق">
  <X />
</button>

// role="status" للـ loading
<div role="status" aria-live="polite">جارٍ التحميل...</div>

// role="alert" للأخطاء
<div role="alert">حدث خطأ</div>
```

---

## 🎯 قواعد الاستخدام

### 1. لكل صفحة:

```tsx
<>
  {/* Loading */}
  {isLoading && <LoadingState />}
  
  {/* Empty */}
  {!isLoading && data.length === 0 && <EmptyState ... />}
  
  {/* Error */}
  {error && <ErrorState ... />}
  
  {/* Success */}
  {!isLoading && !error && data.length > 0 && <ContentList data={data} />}
  
  {/* Permission denied */}
  {!can && <PermissionDeniedState />}
</>
```

### 2. لكل نموذج:

```tsx
<form>
  <Label htmlFor="email">البريد الإلكتروني</Label>
  <Input id="email" type="email" required />
  {errors.email && <p className="text-destructive">{errors.email}</p>}
  
  <Button type="submit" isLoading={isSubmitting}>
    إرسال
  </Button>
</form>
```

### 3. لكل بطاقة:

```tsx
<Card>
  <CardHeader>
    <CardTitle>عنوان</CardTitle>
    <CardDescription>وصف</CardDescription>
  </CardHeader>
  <CardContent>...</CardContent>
  <CardFooter>
    <Button>إجراء</Button>
  </CardFooter>
</Card>
```

### 4. لكل قائمة:

```tsx
<div>
  {items.map(item => <Item key={item.id} {...item} />)}
  
  {/* Pagination */}
  <Pagination page={page} totalPages={totalPages} onChange={setPage} />
  
  {/* أو Infinite scroll */}
  <InfiniteScroll onLoadMore={loadMore} hasMore={hasMore} />
</div>
```

---

## 📦 Design Tokens File (المقترح)

يتم إنشاء `src/lib/design-system/tokens.ts`:

```typescript
export const designTokens = {
  colors: {
    brand: {
      primary: 'oklch(0.45 0.20 25)',
      primaryHover: 'oklch(0.40 0.20 25)',
      gold: '#D4A853',
      goldHover: '#B8923F',
    },
    semantic: {
      success: 'oklch(0.60 0.15 145)',
      warning: 'oklch(0.75 0.18 70)',
      info: 'oklch(0.60 0.15 240)',
      danger: 'oklch(0.577 0.245 27.325)',
    },
    surface: {
      1: 'var(--background)',
      2: 'oklch(0.99 0.005 240)',
      3: 'oklch(1 0 0)',
      glass: 'rgba(255, 255, 255, 0.6)',
    },
    text: {
      primary: 'var(--foreground)',
      secondary: 'oklch(0.45 0.02 260)',
      muted: 'oklch(0.55 0.02 260)',
      disabled: 'oklch(0.70 0.02 260)',
    },
  },
  typography: {
    fontFamily: {
      sans: 'var(--font-noto-arabic), "Noto Sans Arabic", sans-serif',
      mono: 'ui-monospace, SFMono-Regular, monospace',
    },
    scale: {
      '2xs': { size: '10px', lineHeight: '14px' },
      xs: { size: '12px', lineHeight: '16px' },
      sm: { size: '14px', lineHeight: '20px' },
      base: { size: '16px', lineHeight: '24px' },
      lg: { size: '18px', lineHeight: '28px' },
      xl: { size: '20px', lineHeight: '28px' },
      '2xl': { size: '24px', lineHeight: '32px' },
      '3xl': { size: '30px', lineHeight: '36px' },
      '4xl': { size: '36px', lineHeight: '40px' },
      '5xl': { size: '48px', lineHeight: '1' },
    },
    weight: {
      regular: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800,
    },
  },
  spacing: {
    0: '0', px: '1px', 0.5: '2px', 1: '4px', 2: '8px',
    3: '12px', 4: '16px', 5: '20px', 6: '24px', 8: '32px',
    10: '40px', 12: '48px', 16: '64px', 20: '80px', 24: '96px',
    // Semantic
    cardPadding: '24px',
    section: '64px',
    page: '32px',
    navItem: '12px',
  },
  radius: {
    sm: '12px',
    md: '14px',
    lg: '16px',
    xl: '20px',
    '2xl': '24px',
    '3xl': '32px',
    full: '9999px',
  },
  shadow: {
    glass: '0 8px 32px 0 rgba(31, 38, 135, 0.08)',
    glassSm: '0 4px 16px 0 rgba(31, 38, 135, 0.06)',
    glassLg: '0 20px 60px rgba(0, 0, 0, 0.15)',
    glassXl: '0 30px 80px rgba(0, 0, 0, 0.18)',
    glow: '0 0 40px oklch(0.45 0.20 25 / 0.18)',
  },
  motion: {
    duration: { fast: '150ms', normal: '250ms', slow: '400ms' },
    easing: {
      default: 'cubic-bezier(0.4, 0, 0.2, 1)',
      in: 'cubic-bezier(0.4, 0, 1, 1)',
      out: 'cubic-bezier(0, 0, 0.2, 1)',
      bounce: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    },
  },
  breakpoints: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px',
  },
} as const

export type DesignTokens = typeof designTokens
```

---

## 🚫 ممنوع في التصميم

1. ❌ **إعادة تصميم الهوية** — لا تغيير الألوان الأساسية أو الشعار
2. ❌ **Hardcoded colors** — استخدم `tokens` دائمًا
3. ❌ **Hardcoded spacing** — استخدم Tailwind classes أو tokens
4. ❌ **Inline styles** للألوان/الأحجام — استخدم classes
5. ❌ **مكوّنات مكررة** — لا تنشئ `Button2`, `CustomButton`, إلخ
6. ❌ **Mixing Glass و non-Glass** في نفس القسم
7. ❌ **Breakpoints مخصصة** — استخدم Tailwind defaults
8. ❌ **Line height غير محدد** للنصوص الكبيرة

---

## ✅ Checklist لكل صفحة جديدة

- [ ] تستخدم `Button` أو `GlassButton` (لا inline buttons)
- [ ] تستخدم `Card` أو `GlassCard` (لا divs مع classes مخصصة)
- [ ] تستخدم `Input` أو `GlassInput` للنماذج
- [ ] لديها loading state (`Skeleton` أو `Spinner`)
- [ ] لديها empty state (`EmptyState` component)
- [ ] لديها error state (`ErrorBoundary` أو error UI)
- [ ] تستخدم `Dialog` للـ modals
- [ ] تستخدم `DropdownMenu` للقوائم
- [ ] تدعم RTL (`dir="rtl"` على الجذر)
- [ ] تستخدم logical properties (`ms-`, `me-`, `ps-`, `pe-`)
- [ ] تستجيب لـ breakpoints (sm, md, lg)
- [ ] تتبع contrast ratios للنصوص
- [ ] لديها focus states واضحة
- [ ] تستخدم `aria-label` للأيقونات
- [ ] لا تحتوي على hardcoded colors أو spacing

---

## 🔗 روابط ذات صلة

- `02_INFORMATION_ARCHITECTURE.md` — بنية الصفحات
- `08_ROADMAP.md` — خطة التنفيذ
- `10_MIGRATION_PLAN.md` — كيفية ترحيل المكوّنات المكررة

</div>
