# 04 — مصفوفة الصلاحيات | Permission Matrix

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22
**المرجعية:** البرومبت الشامل §7 (تطوير نظام الصلاحيات) و §27 (قواعد الأمان)

---

## 🎯 الهدف

تعريف نظام صلاحيات متعدد الأبعاد يحلّ محل "Role-only authorization" الحالي. النظام الجديد يدعم:

```text
Role (Global) + Scope (Geographic) + Organization + Department + Resource Permission
```

مع الحفاظ الكامل على `UserRole` الحالي (USER, EXPERT, ADMIN, MODERATOR, OWNER) لإمكانية التراجع (backward compatibility).

---

## 📐 المبادئ

### 1. Defense in Depth
التحقق من الصلاحية يتم في **3 طبقات**:
1. **Edge Middleware** — تحقق سريع (role-based)
2. **API Route Handler** — تحقق تفصيلي (role + scope + ownership)
3. **Database Query** — فلترة بالـ WHERE clause (scope-based filtering)

إخفاء زر في الواجهة **ليس** حماية. الحماية الفعلية في طبقات 2 و 3.

### 2. Principle of Least Privilege
المستخدم يحصل على الصلاحيات اللازمة فقط. الـ ADMIN لا يرى OWNER data. الـ BRANCH_MANAGER يرى فرعه فقط.

### 3. Explicit Allow > Implicit Deny
الصلاحيات تُمنح صراحةً. عدم وجود صلاحية = منع. لا يوجد "default allow".

### 4. Auditability
كل قرار صلاحية (سماح/منع) يُسجّل في `AuditLog` مع السبب والمستخدم والمصدر.

---

## 👤 الأدوار (Roles)

### Global Roles (موجودة — تُحفظ)

| Role | الوصف | الصلاحية الجغرافية |
|------|------|------------------|
| `USER` | مستخدم عادي | يرى بياناته فقط |
| `EXPERT` | خبير معتمد | يرى بياناته + استشاراته |
| `COMPANY` | شركة (نوع مستخدم) | يرى بيانات شركته + وظائفها |
| `MODERATOR` | مشرف محتوى | يرى المحتوى المُبلّغ عنه |
| `ADMIN` | مدير نظام | يرى كل ما تحت OWNER |
| `OWNER` | المالك | يرى كل شيء |

### Contextual Roles (جديدة — تُضاف)

```text
OWNER
│
├── GENERAL_MANAGER (مدير عام)
│   │
│   ├── BRANCH_MANAGER (مدير فرع)
│   │   └── EMPLOYEE (موظف)
│   │
│   └── BRANCH_MANAGER
│
└── GENERAL_MANAGER
```

| Contextual Role | نطاق الرؤية |
|----------------|-------------|
| `GENERAL_MANAGER` | كل الفروع التابعة له |
| `BRANCH_MANAGER` | فرع واحد |
| `EMPLOYEE` | مهام مخصصة فقط |

> **ملاحظة:** `UserRole` الحالي يبقى كما هو (USER, EXPERT, ADMIN, MODERATOR, OWNER). نضيف `ContextualRole` كطبقة إضافية عبر جدول `UserOrganizationRole`.

---

## 🌍 أنواع النطاقات (Scopes)

### 1. Geographic Scope

```text
Country        (دولة)
  └── Governorate  (محافظة)
       └── City     (مدينة)
            └── Area  (منطقة/حي)
                 └── Branch (فرع)
```

**أمثلة:**
- `Iraq → Baghdad → Baghdad City → Karrada → Branch #1`
- `Iraq → Basra → Basra City → Al-Asmai → Branch #2`

### 2. Organization Scope

```text
Organization   (مؤسسة)
  └── Branch        (فرع)
       └── Department (قسم)
            └── Employee (موظف)
```

**أمثلة:**
- `Maydan Org → Baghdad Branch → Sales Department → Ahmed`
- `Maydan Org → Basra Branch → HR Department → Sara`

### 3. Resource Scope

```text
Resource (مورد) ← Action (إجراء)
  ├── Article: read | write | delete | publish
  ├── Job: read | create | apply | moderate
  ├── Wallet: read_self | credit_self | debit_self | read_all
  ├── User: read | update | delete | ban
  └── ... (50+ مورد)
```

---

## 📋 مصفوفة الصلاحيات التفصيلية

### القسم 1: المحتوى (Content)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Article | read (published) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Article | create | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| Article | update (own) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| Article | update (any) | — | — | — | ✅ | ✅ | ✅ | — | — | — |
| Article | delete (own) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| Article | delete (any) | — | — | — | — | ✅ | ✅ | — | — | — |
| Article | publish | — | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| Article | feature | — | — | — | — | ✅ | ✅ | — | — | — |
| Article | promote (paid) | ✅ | ✅ | ✅ | — | — | ✅ | — | — | — |
| Article | flag | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| Comment | create | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Comment | update (own) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Comment | delete (any) | — | — | — | ✅ | ✅ | ✅ | — | — | — |

### القسم 2: المستخدمون (Users)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| User (self) | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| User (others) | read (public profile) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| User (others) | read (full) | — | — | — | ✅ | ✅ | ✅ | ✅ (org) | ✅ (branch) | — |
| User (self) | update | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| User (self) | delete | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| User | update (any) | — | — | — | — | ✅ | ✅ | ✅ (org) | ✅ (branch) | — |
| User | ban | — | — | — | ✅ | ✅ | ✅ | ✅ (org) | ✅ (branch) | — |
| User | unban | — | — | — | ✅ | ✅ | ✅ | ✅ (org) | ✅ (branch) | — |
| User | change role | — | — | — | — | ✅ | ✅ | — | — | — |
| User | verify expert | — | — | — | — | ✅ | ✅ | — | — | — |

### القسم 3: الوظائف (Jobs)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Job | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Job | create | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Job | update (own) | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Job | delete (own) | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Job | apply | ✅ | ✅ | — | — | — | — | — | — | — |
| Job | see applicants (own) | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Job | see applicants (all) | — | — | — | — | ✅ | ✅ | — | — | — |
| Job | feature | — | — | — | — | ✅ | ✅ | — | — | — |
| Application | withdraw (own) | ✅ | ✅ | — | — | — | — | — | — | — |
| Application | update status | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| CV Bank | read | — | — | ✅ | — | ✅ | ✅ | — | — | — |

### القسم 4: المحفظة والمالية (Wallet & Finance)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Wallet (self) | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Wallet (self) | credit (top-up) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Wallet (self) | debit (pay) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Wallet (others) | read | — | — | — | — | ✅ | ✅ | — | — | — |
| Wallet (others) | credit | — | — | — | — | ✅ | ✅ | — | — | — |
| Transaction (self) | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Transaction (all) | read | — | — | — | — | ✅ | ✅ | — | — | — |
| Invoice (self) | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Invoice (all) | read | — | — | — | — | ✅ | ✅ | — | — | — |
| Withdrawal | request | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| Withdrawal | approve | — | — | — | — | — | ✅ | — | — | — |
| Withdrawal | reject | — | — | — | — | — | ✅ | — | — | — |
| Pricing | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Pricing | update | — | — | — | — | — | ✅ | — | — | — |

### القسم 5: الاقتصاد (Economy)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Indicators | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Markets | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Calendar | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Map | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Converter | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Indicator | update | — | — | — | — | ✅ | ✅ | — | — | — |
| Indicator | publish | — | — | — | — | ✅ | ✅ | — | — | — |

### القسم 6: السوق (Marketplace)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Service | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Service | create | ✅ | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Service | update (own) | ✅ | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Service | delete (own) | ✅ | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Product | create | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Store | create | — | — | ✅ | — | ✅ | ✅ | — | — | — |
| Order (buy) | create | ✅ | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Order (own) | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Order (seller) | read | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Order (all) | read | — | — | — | — | ✅ | ✅ | — | — | — |
| Review | create | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Review | delete | — | — | — | ✅ | ✅ | ✅ | — | — | — |

### القسم 7: الخبراء والاستشارات (Experts & Consultations)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Expert profile | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Expert profile | apply to be expert | ✅ | — | — | — | — | — | — | — | — |
| Expert profile | verify | — | — | — | — | ✅ | ✅ | — | — | — |
| Consultation | book | ✅ | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Consultation (expert) | read own | — | ✅ | — | — | ✅ | ✅ | — | — | — |
| Consultation (all) | read | — | — | — | — | ✅ | ✅ | — | — | — |
| Consultation | cancel own | ✅ | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Consultation | approve (expert) | — | ✅ | — | — | ✅ | ✅ | — | — | — |

### القسم 8: التعلم (Learning)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Course | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Course | enroll | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Course | create | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Course | update (own) | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Course | delete (own) | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Quiz | take | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Certificate | issue | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |
| Certificate | verify | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Learning Path | create | — | ✅ | ✅ | — | ✅ | ✅ | — | — | — |

### القسم 9: الإدارة والنظام (Admin & System)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| AuditLog | read | — | — | — | — | ✅ | ✅ | — | — | — |
| Settings | read | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Settings | update | — | — | — | — | — | ✅ | — | — | — |
| AI settings | update | — | — | — | — | — | ✅ | — | — | — |
| Organization | create | — | — | — | — | — | ✅ | — | — | — |
| Branch | create | — | — | — | — | — | ✅ | — | — | — |
| Department | create | — | — | — | — | — | ✅ | ✅ (org) | — | — |
| Employee | assign role | — | — | — | — | — | ✅ | ✅ (org) | ✅ (branch) | — |

### القسم 10: الإشراف (Moderation)

| المورد | الإجراء | USER | EXPERT | COMPANY | MODERATOR | ADMIN | OWNER | GENERAL_MGR | BRANCH_MGR | EMPLOYEE |
|--------|--------|------|--------|---------|-----------|-------|-------|-------------|-----------|----------|
| Reported content | read | — | — | — | ✅ | ✅ | ✅ | — | — | — |
| Reported content | action | — | — | — | ✅ | ✅ | ✅ | — | — | — |
| User | warn | — | — | — | ✅ | ✅ | ✅ | — | — | — |
| User | suspend | — | — | — | — | ✅ | ✅ | — | — | — |
| AI moderation | configure | — | — | — | — | ✅ | ✅ | — | — | — |

---

## 🏢 مثال عملي: السلسلة الإدارية

### سيناريو 1: شركة بشركتين وثلاثة فروع

```text
Maydan Org (المؤسسة)
│
├── Ahmed (GENERAL_MANAGER, Baghdad region)
│   ├── Branch 1 (Baghdad - Karrada)
│   │   └── Sara (BRANCH_MANAGER)
│   │       ├── Ali (EMPLOYEE - Sales)
│   │       └── Noor (EMPLOYEE - HR)
│   │
│   └── Branch 2 (Baghdad - Jadriya)
│       └── Hassan (BRANCH_MANAGER)
│           └── Fatima (EMPLOYEE - Sales)
│
└── Khalid (GENERAL_MANAGER, Basra region)
    └── Branch 3 (Basra - Al-Asmai)
        └── Omar (BRANCH_MANAGER)
            └── Layla (EMPLOYEE - IT)
```

**الصلاحيات:**
- `Ahmed` يرى Branch 1 + Branch 2 (فقط في Baghdad)
- `Khalid` يرى Branch 3 (فقط في Basra)
- `Ahmed` لا يرى Branch 3، `Khalid` لا يرى Branch 1/2
- `Sara` (BRANCH_MANAGER) ترى Branch 1 فقط
- `Ali` و `Noor` يريان مهامهما في Branch 1 فقط
- `OWNER` يرى كل شيء

### سيناريو 2: مستخدم عادي يطلب خدمة

```text
1. USER يزور /marketplace/services
2. Middleware: يتحقق من session → USER مسجّل ✅
3. API: requireAuth() → user = { id, role: 'USER' }
4. DB Query: SELECT services WHERE isApproved=true
5. USER يضغط "اطلب الخدمة"
6. API: requireAuth() + checkPermission('order', 'create', { scope: 'self' })
7. ✅ مسموح، يتم إنشاء الطلب
```

### سيناريو 3: BRANCH_MANAGER يحاول رؤية موظفي فرع آخر

```text
1. Sara (BRANCH_MANAGER, Branch 1) تزور /control-center/employees?branchId=3
2. API: requireAuth() → user = { id, contextualRole: 'BRANCH_MANAGER', branchId: 1 }
3. checkPermission('user', 'read', { scope: 'branch', branchId: 3 })
4. ❌ ممنوع: Sara's branchId = 1 ≠ 3
5. Response: 403 Forbidden
6. AuditLog: { userId, action: 'unauthorized_access', resource: 'user', target: 'branch:3' }
```

---

## 🗄️ النماذج المطلوبة (Prisma additions)

```prisma
// إضافات على schema.prisma (بدون كسر الموجود)

model Organization {
  id          String   @id @default(cuid())
  name        String
  nameAr      String?
  description String?
  logo        String?
  type        String   @default("company") // company | government | ngo | educational
  status      String   @default("active")  // active | suspended | deleted
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  branches    Branch[]
  users       UserOrganizationRole[]
  
  @@index([status])
}

model Branch {
  id             String   @id @default(cuid())
  organizationId String
  name           String
  nameAr         String?
  
  // Geographic scope
  countryId      String?
  governorateId  String?
  cityId         String?
  areaId         String?
  
  address        String?
  phone          String?
  email          String?
  managerId      String?  // User ID of BRANCH_MANAGER
  status         String   @default("active")
  createdAt      DateTime @default(now())
  updatedAt      DateTime @updatedAt
  
  organization   Organization @relation(fields: [organizationId], references: [id])
  users          UserOrganizationRole[]
  
  @@index([organizationId, status])
  @@index([cityId])
}

model Department {
  id          String   @id @default(cuid())
  branchId    String
  name        String
  nameAr      String?
  headId      String?  // User ID of department head
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  branch      Branch   @relation(fields: [branchId], references: [id])
  users       UserOrganizationRole[]
  
  @@index([branchId])
}

model UserOrganizationRole {
  id             String   @id @default(cuid())
  userId         String
  organizationId String
  branchId       String?
  departmentId   String?
  
  // Contextual role (General Manager, Branch Manager, Employee)
  contextualRole String   // general_manager | branch_manager | employee
  
  // Specific permissions granted to this user (JSON array of permission keys)
  permissions    Json?
  
  status         String   @default("active")  // active | suspended
  assignedAt     DateTime @default(now())
  updatedAt      DateTime @updatedAt
  
  user           User         @relation(fields: [userId], references: [id])
  organization   Organization @relation(fields: [organizationId], references: [id])
  branch         Branch?      @relation(fields: [branchId], references: [id])
  department     Department?  @relation(fields: [departmentId], references: [id])
  
  @@unique([userId, organizationId, branchId])
  @@index([userId])
  @@index([organizationId])
  @@index([branchId])
}

model Permission {
  id          String   @id @default(cuid())
  key         String   @unique  // e.g., "article.create", "wallet.credit.others"
  description String?
  resource    String   // article | user | job | wallet | ...
  action      String   // create | read | update | delete | approve | ...
  scope       String   @default("self") // self | org | branch | global
  createdAt   DateTime @default(now())
  
  @@index([resource, action])
}

model RolePermission {
  id           String @id @default(cuid())
  roleName    String  // user | expert | company | moderator | admin | owner | general_manager | branch_manager | employee
  permissionKey String
  createdAt    DateTime @default(now())
  
  permission   Permission @relation(fields: [permissionKey], references: [key])
  
  @@unique([roleName, permissionKey])
  @@index([roleName])
}

// نماذج Location (جغرافية موحّدة)
model Country {
  id           String  @id @default(cuid())
  code         String  @unique  // IQ, SA, AE, ...
  name         String
  nameAr       String?
  flag         String?
  
  governorates Governorate[]
  
  @@index([code])
}

model Governorate {
  id          String  @id @default(cuid())
  countryId   String
  code        String  @unique  // IQ-BGD, IQ-BSR, ...
  name        String
  nameAr      String?
  population  Int?
  
  country     Country @relation(fields: [countryId], references: [id])
  cities      City[]
  
  @@index([countryId])
}

model City {
  id             String @id @default(cuid())
  governorateId  String
  name           String
  nameAr         String?
  latitude       Float?
  longitude      Float?
  
  governorate    Governorate @relation(fields: [governorateId], references: [id])
  areas          Area[]
  
  @@index([governorateId])
}

model Area {
  id          String @id @default(cuid())
  cityId      String
  name        String
  nameAr      String?
  
  city        City @relation(fields: [cityId], references: [id])
  branches    Branch[]
  
  @@index([cityId])
}
```

---

## 🔧 تنفيذ طبقة الصلاحيات

### 1. Permission Engine (`src/lib/permission-engine.ts`)

```typescript
// pseudocode — يتم تنفيذه فعليًا في PHASE 1

export interface PermissionContext {
  userId: string
  globalRole: UserRole  // USER | EXPERT | ADMIN | MODERATOR | OWNER
  contextualRoles?: {
    organizationId: string
    branchId?: string
    departmentId?: string
    role: 'general_manager' | 'branch_manager' | 'employee'
    permissions?: string[]
  }[]
}

export async function checkPermission(
  ctx: PermissionContext,
  resource: string,
  action: string,
  options?: {
    ownerId?: string  // for "self" scope checks
    organizationId?: string
    branchId?: string
    departmentId?: string
  }
): Promise<{ allowed: boolean; reason?: string }> {
  // 1. OWNER always allowed
  if (ctx.globalRole === 'OWNER') return { allowed: true }
  
  // 2. Check global role permissions (cached)
  const globalAllowed = await checkGlobalRolePermission(ctx.globalRole, resource, action)
  if (globalAllowed) {
    // For "self" scope resources, ensure ownership
    if (options?.ownerId && options.ownerId !== ctx.userId) {
      return { allowed: false, reason: 'NOT_OWNER' }
    }
    return { allowed: true }
  }
  
  // 3. Check contextual roles (organization-scoped)
  if (options?.organizationId && ctx.contextualRoles) {
    for (const ctxRole of ctx.contextualRoles) {
      if (ctxRole.organizationId === options.organizationId) {
        // Check if role matches the scope needed
        const scopeMatch = checkScope(ctxRole, options)
        if (scopeMatch) {
          const permMatch = checkPermissionList(ctxRole.permissions || [], resource, action)
          if (permMatch) return { allowed: true }
        }
      }
    }
  }
  
  return { allowed: false, reason: 'NO_PERMISSION' }
}
```

### 2. API Usage Pattern

```typescript
// في أي API route
import { requireAuth } from '@/lib/session'
import { checkPermission } from '@/lib/permission-engine'

export async function POST(request: Request) {
  const user = await requireAuth()
  
  const body = await request.json()
  
  const { allowed, reason } = await checkPermission(
    { userId: user.id, globalRole: user.role, contextualRoles: user.contextualRoles },
    'article', 'create'
  )
  
  if (!allowed) {
    return Response.json({ error: 'Forbidden', reason }, { status: 403 })
  }
  
  // ... المتابعة
}
```

### 3. Database Query Pattern

```typescript
// في service layer
export async function getJobsForUser(user: SessionUser) {
  // Public jobs - للجميع
  if (user.role === 'USER' || user.role === 'EXPERT') {
    return db.job.findMany({ where: { isExpired: false, deletedAt: null, status: 'PUBLISHED' } })
  }
  
  // COMPANY - يرى وظائفه + المتقدمين عليها
  if (user.role === 'COMPANY') {
    return db.job.findMany({
      where: {
        OR: [
          { isExpired: false, deletedAt: null, status: 'PUBLISHED' },  // public
          { postedById: user.id }  // own
        ]
      }
    })
  }
  
  // ADMIN/OWNER - يرى كل شيء (مع فلترة scope)
  if (user.role === 'ADMIN' || user.role === 'OWNER') {
    const scopeFilter = user.role === 'OWNER' ? {} : await getAdminScopeFilter(user.id)
    return db.job.findMany({ where: { deletedAt: null, ...scopeFilter } })
  }
  
  // GENERAL_MANAGER / BRANCH_MANAGER - يرى فروعه فقط
  const branchIds = await getUserBranchIds(user.id)
  if (branchIds.length > 0) {
    return db.job.findMany({
      where: {
        deletedAt: null,
        OR: [
          { status: 'PUBLISHED', isExpired: false },  // public
          { branchId: { in: branchIds } }  // scoped
        ]
      }
    })
  }
  
  return []
}
```

### 4. Frontend Pattern

```tsx
// في أي مكون React
import { useCan } from '@/hooks/useCan'

function DeleteArticleButton({ article }: { article: Article }) {
  const can = useCan('article', 'delete', { ownerId: article.authorId })
  
  if (!can) return null
  
  return <Button onClick={() => deleteArticle(article.id)}>حذف</Button>
}
```

---

## ✅ معايير قبول نظام الصلاحيات

| المعيار | الحالة |
|---------|------|
| كل API route يستخدم `checkPermission()` | يجب |
| كل زر حساس محمي بـ `useCan()` | يجب |
| سجل `AuditLog` لكل رفض صلاحية | يجب |
| اختبار role-based access لكل role | يجب |
| اختبار scope-based filtering | يجب |
| توثيق كل صلاحية جديدة | يجب |
| لا يوجد hardcoded role checks | يجب (إلا في permission-engine) |

---

## 🔗 روابط ذات صلة

- `05_DATABASE_ARCHITECTURE.md` — تفاصيل نماذج Prisma
- `09_SECURITY_AUDIT.md` — الأمان والثغرات
- `10_MIGRATION_PLAN.md` — كيفية الترحيل بأمان

</div>
