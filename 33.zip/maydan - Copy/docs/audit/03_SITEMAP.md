# 03 — خريطة الموقع | Sitemap

<div dir="rtl">

**المنصة:** ميدان (Midan)
**تاريخ الإصدار:** 2026-08-22

---

## 🎯 الهدف

توفير خريطة كاملة لجميع المسارات (URLs) في منصة ميدان، موزّعة حسب:
1. الحالة الحالية (موجودة / مقترحة / موحّدة)
2. الصلاحية المطلوبة
3. أولوية الـ SEO
4. الصلاحية (Public / Authenticated / Role-restricted)

---

## 📊 إحصائيات المسارات

| النوع | العدد |
|------|------|
| صفحات Next.js (`page.tsx`) موجودة | 94 |
| صفحات مقترحة جديدة | 28 |
| إجمالي صفحات مستهدفة | 122 |
| صفحات ثابتة (Static) | 373 |
| صفحات ديناميكية (Server-rendered) | 67 |
| صفحات عامة (Public SEO) | 18 |
| صفحات تتطلب تسجيل دخول | 76 |
| صفحات تتطلب صلاحية خاصة | 28 |

---

## 🌐 الصفحات العامة (Public SEO-Optimized)

هذه الصفحات يجب أن تكون **مُفهرسة** في محركات البحث وتحوي metadata كاملة.

| # | المسار | الصلاحية | SEO | الأولوية | Sitemap Priority |
|---|--------|---------|-----|---------|------------------|
| 1 | `/` | Public | ✅ OpenGraph + JSON-LD | عالية | 1.0 |
| 2 | `/login` | Public | noindex | منخفضة | 0.1 |
| 3 | `/register` | Public | noindex | منخفضة | 0.1 |
| 4 | `/articles` | Public | ✅ OpenGraph | عالية | 0.9 |
| 5 | `/articles/[id]` | Public | ✅ OpenGraph + Article JSON-LD | عالية | 0.9 |
| 6 | `/experts` | Public | ✅ OpenGraph | عالية | 0.8 |
| 7 | `/companies` | Public | ✅ OpenGraph | عالية | 0.8 |
| 8 | `/companies/[id]` | Public | ✅ Organization JSON-LD | عالية | 0.8 |
| 9 | `/profile/[id]` | Public | ✅ Person JSON-LD | متوسطة | 0.6 |
| 10 | `/tags/[tag]` | Public | ✅ OpenGraph | متوسطة | 0.6 |
| 11 | `/jobs` | Public | ✅ OpenGraph | عالية | 0.9 |
| 12 | `/jobs/[id]` | Public | ✅ JobPosting JSON-LD | عالية | 0.9 |
| 13 | `/marketplace/services` | Public | ✅ OpenGraph | متوسطة | 0.7 |
| 14 | `/marketplace/services/[id]` | Public | ✅ Service JSON-LD | متوسطة | 0.7 |
| 15 | `/marketplace/products` | Public | ✅ OpenGraph | متوسطة | 0.7 |
| 16 | `/marketplace/products/[id]` | Public | ✅ Product JSON-LD | متوسطة | 0.7 |
| 17 | `/marketplace/stores/[id]` | Public | ✅ Store JSON-LD | متوسطة | 0.7 |
| 18 | `/verify-certificate` | Public | noindex | منخفضة | 0.3 |
| 19 | `/economy/indicators` | Public | ✅ OpenGraph | عالية | 0.8 |
| 20 | `/economy/map` | Public | ✅ OpenGraph | متوسطة | 0.7 |
| 21 | `/research/papers/[id]` | Public | ✅ ScholarlyArticle JSON-LD | متوسطة | 0.6 |
| 22 | `/learning/courses/[id]` | Public | ✅ Course JSON-LD | متوسطة | 0.7 |
| 23 | `/learning/certificates/[id]` | Public | ✅ EducationalOccupationalCredential | متوسطة | 0.6 |

---

## 🔐 الصفحات المتطلب تسجيل دخول (Authenticated)

### لوحة المستخدم الشخصية

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 1 | `/dashboard` | لوحة التحكم الشخصية | USER+ |
| 2 | `/notifications` | الإشعارات | USER+ |
| 3 | `/messages` | الرسائل | USER+ |
| 4 | `/bookmarks` | المحفوظات | USER+ |
| 5 | `/connections` | الاتصالات | USER+ |
| 6 | `/search` | البحث المتقدم | USER+ |
| 7 | `/create-post` | إنشاء منشور | USER+ |
| 8 | `/write` | محرر المقالات | USER+ |
| 9 | `/write/[id]` | تعديل مقال | USER+ (author) |
| 10 | `/cv-builder` | بناء سيرة ذاتية | USER+ |
| 11 | `/premium` | الاشتراك المميز | USER+ |
| 12 | `/achievements` | الإنجازات | USER+ |
| 13 | `/leaderboard` | لوحة المتصدرين | USER+ |
| 14 | `/events` | الأحداث | USER+ |
| 15 | `/analytics` | تحليلاتي | USER+ |
| 16 | `/wallet` | المحفظة | USER+ |
| 17 | `/finance` | اللوحة المالية الشاملة | USER+ |
| 18 | `/ai-assistant` | مساعد AI | USER+ |
| 19 | `/profile/[id]` | ملف شخصي | USER+ (or self) |
| 20 | `/ai` | لوحة AI الموحدة (مقترح) | USER+ |
| 21 | `/ai/general` | مساعد عام | USER+ |
| 22 | `/ai/economic` | محلل اقتصادي | USER+ |
| 23 | `/ai/research` | مساعد أبحاث | USER+ |
| 24 | `/ai/career` | مساعد وظيفي | USER+ |
| 25 | `/ai/investment` | مساعد استثمار | USER+ |
| 26 | `/ai/content` | مساعد محتوى | USER+ |
| 27 | `/discover` | استكشاف شامل | USER+ |

### المجتمع (Community)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 28 | `/discussions` | النقاشات | USER+ |
| 29 | `/discussions/[id]` | تفاصيل نقاش | USER+ |
| 30 | `/questions` | الأسئلة | USER+ |
| 31 | `/questions/[id]` | تفاصيل سؤال | USER+ |
| 32 | `/polls` | الاستطلاعات | USER+ |
| 33 | `/chat-rooms` | غرف الدردشة | USER+ |
| 34 | `/communities` | المجتمعات | USER+ |
| 35 | `/communities/[id]` | تفاصيل مجتمع | USER+ |
| 36 | `/community` | لوحة المجتمع الموحدة (مقترح) | USER+ |

### الوظائف (Career)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 37 | `/jobs` | تصفّح الوظائف | USER+ |
| 38 | `/jobs/[id]` | تفاصيل وظيفة | USER+ |
| 39 | `/jobs/new` | نشر وظيفة | COMPANY / EXPERT |
| 40 | `/jobs/candidate/applied` | تطبيقاتي | USER+ |
| 41 | `/jobs/candidate/interviews` | مقابلاتي | USER+ |
| 42 | `/jobs/candidate/offers` | عروضي | USER+ |
| 43 | `/jobs/candidate/profile` | ملفي كمرشح | USER+ |
| 44 | `/jobs/candidate/resume` | سيرتي الذاتية | USER+ |
| 45 | `/jobs/candidate/saved` | الوظائف المحفوظة | USER+ |
| 46 | `/jobs/cv-bank` | بنك السير الذاتية | COMPANY |
| 47 | `/jobs/dashboard` | لوحة الوظائف | USER+ |
| 48 | `/jobs/employer` | لوحة صاحب العمل | COMPANY |
| 49 | `/jobs/employer/jobs` | وظائفي المنشورة | COMPANY |
| 50 | `/jobs/employer/applicants` | المتقدمون | COMPANY |
| 51 | `/jobs/employer/applicants/[jobId]/kanban` | ATS Kanban | COMPANY |
| 52 | `/jobs/employer/interviews` | مقابلاتي كصاحب عمل | COMPANY |
| 53 | `/jobs/employer/reports` | تقارير التوظيف | COMPANY |
| 54 | `/jobs/employer/settings` | إعدادات صاحب العمل | COMPANY |
| 55 | `/career` | لوحة Career موحدة (مقترح) | USER+ |

### الاقتصاد (Economy)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 56 | `/economy/indicators` | المؤشرات | Public |
| 57 | `/economy/calendar` | التقويم الاقتصادي | USER+ |
| 58 | `/economy/charts` | الرسوم البيانية | USER+ |
| 59 | `/economy/map` | خريطة العراق الاقتصادية | Public |
| 60 | `/economy/converter` | محول العملات | Public |
| 61 | `/economy/market` | أسعار الأسواق | Public |
| 62 | `/economy/ai-assistant` | AI اقتصادي (→ `/ai/economic`) | USER+ |

### الخبراء والاستشارات (Experts)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 63 | `/experts` | دليل الخبراء | Public |
| 64 | `/expert-market` | سوق الخبراء | USER+ |
| 65 | `/consultations` | الاستشارات | USER+ |
| 66 | `/consultant-dashboard` | لوحة المستشار | EXPERT |
| 67 | `/company-dashboard` | لوحة الشركة | COMPANY |

### التعلم (Learning)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 68 | `/learning` | الأكاديمية الموحدة | USER+ |
| 69 | `/learning/[id]` | تفاصيل مسار تعلم | USER+ |
| 70 | `/learn` | ← redirect إلى `/learning` | — |
| 71 | `/academy` | ← redirect إلى `/learning` | — |
| 72 | `/quizzes` | ← redirect إلى `/learning/quizzes` | — |
| 73 | `/quizzes/[id]` | تفاصيل اختبار | USER+ |
| 74 | `/dictionary` | ← redirect إلى `/learning/dictionary` | — |

### البحث والأبحاث (Research)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 75 | `/research` | الأبحاث | USER+ |

### الاستثمار (Investment)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 76 | `/investment-bank` | البنك الاستثماري | USER+ |
| 77 | `/investment` | لوحة الاستثمار (مقترح) | USER+ |
| 78 | `/investment/opportunities` | الفرص الاستثمارية | USER+ |

### السوق (Marketplace)

| # | المسار | الوصف | الصلاحية |
|---|--------|------|---------|
| 79 | `/marketplace` | السوق الرئيسي | USER+ |
| 80 | `/marketplace/services` | خدمات | USER+ |
| 81 | `/marketplace/services/[id]` | تفاصيل خدمة | USER+ |
| 82 | `/marketplace/products` | منتجات | USER+ |
| 83 | `/marketplace/products/[id]` | تفاصيل منتج | USER+ |
| 84 | `/marketplace/stores` | متاجر | USER+ |
| 85 | `/marketplace/stores/[id]` | تفاصيل متجر | USER+ |
| 86 | `/marketplace/providers` | مزوّدون | USER+ |
| 87 | `/marketplace/providers/[id]` | تفاصيل مزوّد | USER+ |
| 88 | `/marketplace/requests` | طلبات | USER+ |
| 89 | `/marketplace/requests/new` | إنشاء طلب | USER+ |
| 90 | `/marketplace/requests/[id]` | تفاصيل طلب | USER+ |
| 91 | `/marketplace/dashboard` | لوحة البائع | COMPANY / EXPERT |
| 92 | `/marketplace/admin` | إدارة السوق | ADMIN+ |

---

## 🛡️ صفحات لوحة التحكم (Control Center)

| # | المسار | الوصف | الصلاحية | Scope |
|---|--------|------|---------|-------|
| 93 | `/admin` | لوحة الإدارة (موجودة) | ADMIN+ | Global |
| 94 | `/admin/auto-publish` | النشر التلقائي | ADMIN+ | Global |
| 95 | `/admin/scrape` | السكريبر | ADMIN+ | Global |
| 96 | `/owner` | لوحة المالك (موجودة) | OWNER | Global |
| 97 | `/owner-panel` | ← redirect إلى `/control-center` | OWNER | Global |
| 98 | `/control-center` | لوحة التحكم الموحدة (مقترح) | OWNER, ADMIN | Org/Geo scope |
| 99 | `/control-center/users` | المستخدمون | OWNER, ADMIN | Scoped |
| 100 | `/control-center/organizations` | المؤسسات | OWNER | Global |
| 101 | `/control-center/companies` | الشركات | OWNER, ADMIN | Scoped |
| 102 | `/control-center/branches` | الفروع | OWNER, GENERAL_MANAGER | Scoped |
| 103 | `/control-center/employees` | الموظفون | OWNER, GENERAL_MANAGER, BRANCH_MANAGER | Scoped |
| 104 | `/control-center/jobs` | إدارة الوظائف | OWNER, ADMIN | Scoped |
| 105 | `/control-center/experts` | التحقق من الخبراء | OWNER, ADMIN, MODERATOR | Global |
| 106 | `/control-center/marketplace` | إدارة السوق | OWNER, ADMIN | Scoped |
| 107 | `/control-center/finance` | المالية | OWNER | Global |
| 108 | `/control-center/research` | الأبحاث | OWNER, ADMIN | Global |
| 109 | `/control-center/academy` | الأكاديمية | OWNER, ADMIN | Global |
| 110 | `/control-center/moderation` | الإشراف | OWNER, ADMIN, MODERATOR | Scoped |
| 111 | `/control-center/ads` | الإعلانات | OWNER, ADMIN | Global |
| 112 | `/control-center/ai` | إعدادات AI | OWNER | Global |
| 113 | `/control-center/analytics` | التحليلات | OWNER, ADMIN | Scoped |
| 114 | `/control-center/security` | الأمان | OWNER | Global |
| 115 | `/control-center/audit-logs` | سجلات التدقيق | OWNER | Global |
| 116 | `/control-center/settings` | إعدادات النظام | OWNER | Global |

---

## 🔄 صفحات الحالة الخاصة

| # | المسار | الوصف |
|---|--------|------|
| 117 | `/error` | صفحة خطأ عامة |
| 118 | `/404` (not-found) | صفحة غير موجودة |
| 119 | `/500` (error) | خطأ في الخادم |
| 120 | `/global-error` | خطأ جذري |
| 121 | `/offline` | صفحة PWA بدون اتصال |
| 122 | `/api-docs` | توثيق API (Public) |

---

## 📋 قائمة الـ Redirects النهائية

| المسار القديم | المسار الجديد | HTTP Status |
|---------------|--------------|-------------|
| `/learn` | `/learning` | 301 |
| `/academy` | `/learning` | 301 |
| `/quizzes` | `/learning/quizzes` | 301 |
| `/dictionary` | `/learning/dictionary` | 301 |
| `/ai-assistant` | `/ai/general` | 301 |
| `/economy/ai-assistant` | `/ai/economic` | 301 |
| `/owner-panel` | `/control-center` | 301 |
| `/owner` | `/control-center` | 301 |
| `/admin` | `/control-center` | 302 (مؤقت — للحفاظ على backward compat) |

---

## 🌐 Sitemap.xml الناتج

يتم توليد `/sitemap.xml` ديناميكيًا من `src/app/sitemap.ts`. يجب أن يحوي:

```typescript
// src/app/sitemap.ts (محسّن)
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
  
  // صفحات ثابتة
  const staticPages = [
    { url: '/', changeFrequency: 'hourly', priority: 1.0 },
    { url: '/articles', changeFrequency: 'hourly', priority: 0.9 },
    { url: '/experts', changeFrequency: 'daily', priority: 0.8 },
    { url: '/companies', changeFrequency: 'daily', priority: 0.8 },
    { url: '/jobs', changeFrequency: 'hourly', priority: 0.9 },
    { url: '/economy/indicators', changeFrequency: 'hourly', priority: 0.8 },
    { url: '/economy/map', changeFrequency: 'weekly', priority: 0.7 },
    // ... باقي الصفحات العامة
  ]
  
  // صفحات ديناميكية من DB
  const articles = await db.article.findMany({ where: { status: 'PUBLISHED' }, select: { id: true, updatedAt: true } })
  const jobs = await db.job.findMany({ where: { isExpired: false, deletedAt: null }, select: { id: true, updatedAt: true } })
  const experts = await db.user.findMany({ where: { role: 'EXPERT', isVerified: true }, select: { id: true, updatedAt: true } })
  
  // ... دمج وإرجاع
}
```

---

## 🎯 أولويات الـ SEO

### High Priority (Google Indexing مهم)

1. الصفحة الرئيسية `/`
2. صفحات المقالات `/articles/[id]` (مع Article JSON-LD)
3. صفحات الوظائف `/jobs/[id]` (مع JobPosting JSON-LD)
4. صفحات الشركات `/companies/[id]` (مع Organization JSON-LD)
5. صفحات الخبراء `/profile/[id]` للخبراء (مع Person JSON-LD)
6. المؤشرات الاقتصادية `/economy/indicators`
7. خريطة العراق `/economy/map`

### Medium Priority

8. المنتجات `/marketplace/products/[id]` (Product JSON-LD)
9. الخدمات `/marketplace/services/[id]` (Service JSON-LD)
10. المتاجر `/marketplace/stores/[id]` (Store JSON-LD)
11. الكورسات `/learning/courses/[id]` (Course JSON-LD)
12. الأبحاث `/research/papers/[id]` (ScholarlyArticle JSON-LD)

### Low Priority (noindex)

13. `/login`, `/register`
14. لوحات التحكم الشخصية والإدارية
15. `/search`, `/notifications`, `/messages`

---

## 📱 Sitemap للأجهزة المحمولة

نفس المسارات، لكن مع:
- AMP غير مطلوب (الموقع responsive بشكل كافٍ)
- Mobile-friendly test لكل صفحة public
- Service Worker (`/sw.js`) لـ offline support

---

## 🔗 روابط ذات صلة

- `02_INFORMATION_ARCHITECTURE.md` — البنية المعمارية الشاملة
- `08_ROADMAP.md` — خطة التنفيذ
- `10_MIGRATION_PLAN.md` — خطة الترحيل الآمن

</div>
