# ============================================
# دليل النسخ الاحتياطي والاسترداد
# Backup & Restore Guide - Maydan Al-Iqtisad
# ============================================

## الملفات المُنشأة

### 1. سكريبت النسخ الاحتياطي الشامل
**الملف:** `scripts/backup.sh`

يدعم:
- نسخ قاعدة بيانات PostgreSQL (SQL + Custom format)
- نسخ الملفات المرفوعة (صور + مستندات) باستخدام rsync
- نسخ بيانات Redis (RDB + AOF)
- رفع النسخ للسحابة (S3/FTP)
- نظام تنظيف تلقائي حسب RPO
- إنشاء تقرير تفصيلي
- **يعمل بدون صلاحيات root** (يكتشف البيئة تلقائياً)

```bash
# نسخة كاملة
bash scripts/backup.sh

# قاعدة البيانات فقط
bash scripts/backup.sh --db-only

# الملفات المرفوعة فقط
bash scripts/backup.sh --uploads

# Redis فقط
bash scripts/backup.sh --redis

# كل شيء + رفع سحابي
bash scripts/backup.sh --all

# كل شيء بدون رفع سحابي
bash scripts/backup.sh --no-cloud
```

> **ملاحظة:** السكريبت يكتشف البيئة تلقائياً (Docker أو محلي).
> في بيئة Docker، إذا لم تكن لديك صلاحيات الكتابة في `/mnt/hdd/`، سيستخدم مجلد `backups/` داخل المشروع تلقائياً.

---

### 2. سكريبت الاسترداد التلقائي
**الملف:** `scripts/restore.sh`

يدعم:
- استرداد تفاعلي (قوائم اختيار)
- استرداد آخر نسخة بضغطة واحدة
- استرداد من ملف محدد
- استرداد من السحابة (S3)
- إنشاء نسخة احتياطية قبل الاسترداد (pre-restore backup)
- نقاط استرداد (restore points)
- **يعمل بدون صلاحيات root** (مع تحذير إذا كانت بعض العمليات تحتاج sudo)

```bash
# استرداد تفاعلي
bash scripts/restore.sh

# عرض النسخ المتاحة
bash scripts/restore.sh --list

# استرداد آخر نسخة
bash scripts/restore.sh --latest

# استرداد قاعدة البيانات فقط
bash scripts/restore.sh --db

# استرداد من ملف محدد
bash scripts/restore.sh --db --file /path/to/backup.sql.gz

# استرداد الملفات المرفوعة
bash scripts/restore.sh --uploads

# استرداد Redis
bash scripts/restore.sh --redis

# استرداد كل شيء
bash scripts/restore.sh --all

# استرداد من السحابة
bash scripts/restore.sh --from-s3

# إنشاء نقطة استرداد
bash scripts/restore.sh --restore-point
```

> **ملاحظة:** بعض عمليات الاسترداد في بيئة Docker (مثل إعادة تشغيل الحاويات أو تغيير صلاحيات الملفات) قد تحتاج `sudo`. السكريبت سيحذرك إذا احتاج صلاحيات إضافية.

---

### 3. سكريبت إعداد الجدولة الزمنية (RPO)
**الملف:** `scripts/setup-backup-cron.sh`

يُعد جدولة تلقائية:
- كل ساعة: نسخ PostgreSQL + Redis
- يومياً (3 صباحاً): نسخة كاملة
- أسبوعياً (أحد 4 صباحاً): نسخة + رفع سحابي
- شهرياً (1 الشهر 5 صباحاً): نسخة + رفع سحابي

```bash
# إعداد الجدولة
bash scripts/setup-backup-cron.sh

# عرض الحالة
bash scripts/setup-backup-cron.sh --status

# إزالة الجدولة
bash scripts/setup-backup-cron.sh --remove

# تشغيل نسخة تجريبية
bash scripts/setup-backup-cron.sh --test
```

---

### 4. سكريبت إعداد النسخ السحابي
**الملف:** `scripts/setup-cloud-backup.sh`

يدعم:
- AWS S3
- Wasabi (أرخص - S3 متوافق)
- MinIO خارجي (خادم خاص)
- Backblaze B2 (أرخص للنسخ الاحتياطي)
- FTP/SFTP

```bash
# إعداد تفاعلي
sudo bash scripts/setup-cloud-backup.sh

# اختبار الاتصال
sudo bash scripts/setup-cloud-backup.sh --test

# فحص الحالة
sudo bash scripts/setup-cloud-backup.sh --check

# إعادة تعيين
sudo bash scripts/setup-cloud-backup.sh --reset
```

---

### 5. سكريبت مراقبة النسخ الاحتياطي
**الملف:** `scripts/backup-monitor.sh`

يفحص:
- وجود نسخ PostgreSQL حديثة
- وجود نسخ Redis حديثة
- وجود نسخ ملفات مرفوعة حديثة
- مساحة التخزين المتاحة
- حالة حاويات Docker
- إرسال تنبيهات (Telegram/Slack/Email)
- **يعمل بدون صلاحيات root**

```bash
# فحص فوري مع عرض الحالة
bash scripts/backup-monitor.sh --status

# تثبيت ك cron job (كل 6 ساعات)
bash scripts/backup-monitor.sh --install

# فحص صامت (يرسل تنبيهات فقط عند وجود مشاكل)
bash scripts/backup-monitor.sh
```

---

## نظام نقاط الاسترداد (RPO)

| المستوى | التكرار | أقصى فقدان بيانات | الاحتفاظ |
|---------|---------|-------------------|----------|
| كل ساعة | كل 1 ساعة | 1 ساعة (PostgreSQL + Redis) | 24 نسخة (1 يوم) |
| يومي | كل يوم 3AM | 1 يوم (ملفات مرفوعة) | 7 نسخ (1 أسبوع) |
| أسبوعي | كل أحد | أسبوع (مع نسخة سحابية) | 4 نسخ (1 شهر) |
| شهري | أول كل شهر | شهر | 12 نسخة (1 سنة) |

---

## هيكل مجلدات النسخ الاحتياطي

### بيئة الإنتاج (Docker):
```
/mnt/hdd/backups/
├── postgresql/
│   ├── hourly/          # نسخ كل ساعة
│   │   ├── maydan_db_20260610_010000.sql.gz
│   │   └── maydan_db_20260610_010000.dump
│   ├── daily/           # نسخ يومية
│   ├── weekly/          # نسخ أسبوعية
│   └── monthly/         # نسخ شهرية
├── uploads/
│   ├── daily/
│   │   ├── uploads_latest/   # نسخة rsync تدريجية
│   │   ├── avatars_latest/
│   │   ├── covers_latest/
│   │   └── uploads_20260610_030000.tar.gz
│   ├── weekly/
│   └── monthly/
├── redis/
│   ├── hourly/
│   │   ├── dump_20260610_010000.rdb
│   │   ├── appendonly_20260610_010000.aof
│   │   └── redis_keys_20260610_010000.txt
│   └── daily/
├── restore-points/       # نقاط استرداد يدوية
└── pre_restore/          # نسخ ما قبل الاسترداد
```

### بيئة التطوير (محلي):
```
~/maydan/backups/
├── postgresql/
│   ├── hourly/
│   ├── daily/
│   ├── weekly/
│   └── monthly/
├── uploads/
│   └── ...
├── redis/
│   └── ...
└── logs/
    ├── backup_20260610_010000.log
    └── backup_health.log
```

---

## كشف البيئة التلقائي

السكريبتات تكتشف نوع البيئة تلقائياً:

| الشرط | البيئة المكتشفة | مسار النسخ |
|-------|----------------|-----------|
| حاوية `maydan-postgres` تعمل AND يمكن الكتابة في `/mnt/hdd/` | Docker | `/mnt/hdd/backups/` |
| حاوية `maydan-postgres` تعمل AND لا يمكن الكتابة في `/mnt/hdd/` | Docker (fallback) | `~/maydan/backups/` |
| حاوية `maydan-postgres` لا تعمل | محلي | `~/maydan/backups/` |

> إذا واجهت مشاكل في الصلاحيات، يمكنك تشغيل السكريبتات مع `sudo` أو إعطاء صلاحيات الكتابة:
> ```bash
> sudo chown -R $(whoami) /mnt/hdd/backups /mnt/hdd/logs
> ```

---

## حالات الطوارئ

### حالة 1: اختراق الموقع
```bash
# 1. إيقاف الموقع فوراً
cd ~/maydan
docker compose down

# 2. استرداد آخر نسخة
bash scripts/restore.sh --latest

# 3. إعادة التشغيل
docker compose up -d
```

### حالة 2: حذف بيانات بالخطأ
```bash
# 1. استرداد قاعدة البيانات فقط
bash scripts/restore.sh --db

# 2. اختيار نسخة سابقة من القائمة
```

### حالة 3: تلف السيرفر بالكامل
```bash
# على سيرفر جديد:
# 1. تثبيت Docker + إعداد التخزين
sudo bash scripts/setup-storage.sh

# 2. نسخ المشروع
git clone <repo-url> ~/maydan

# 3. إعداد النسخ السحابي
sudo bash scripts/setup-cloud-backup.sh

# 4. استرداد من السحابة
bash scripts/restore.sh --from-s3

# 5. إعادة التشغيل
docker compose up -d
```

### حالة 4: فشل Redis فقط
```bash
bash scripts/restore.sh --redis
docker compose restart redis
```

---

## تنبيهات المراقبة

لتفعيل التنبيهات عبر Telegram:
1. أنشئ بوت عبر @BotFather
2. احصل على Chat ID
3. أضف المتغيرات في `.env`:
```bash
ALERT_TELEGRAM_BOT_TOKEN="your-bot-token"
ALERT_TELEGRAM_CHAT_ID="your-chat-id"
```

أو عبر Slack/Discord:
```bash
ALERT_WEBHOOK_URL="https://hooks.slack.com/services/..."
```

---

## استكشاف الأخطاء

### خطأ: "لا يمكن الكتابة في /mnt/hdd/backups"
```bash
# الحل 1: إعطاء صلاحيات الكتابة
sudo chown -R $(whoami) /mnt/hdd/backups /mnt/hdd/logs

# الحل 2: استخدام sudo
sudo bash scripts/backup.sh

# الحل 3: السكريبت سيستخدم تلقائياً مسار بديل (~/maydan/backups/)
```

### خطأ: "حاوية maydan-postgres غير تعمل"
```bash
# فحص حالة الحاويات
docker ps -a

# تشغيل الحاويات
cd ~/maydan && docker compose up -d

# فحص سجلات الحاوية
docker logs maydan-postgres
```

### خطأ: "لم يتم العثور على مجلد الملفات المرفوعة"
```bash
# فحص وجود مجلد الرفع
ls -la public/uploads/

# في بيئة Docker
ls -la /mnt/hdd/minio-data/uploads/

# إنشاء المجلد إذا لم يكن موجوداً
mkdir -p public/uploads/{avatars,covers,posts,article,research}
```
