# Migration Guide — Applying the Patched Delivery

This guide walks you through applying the patched Midan Platform delivery to your existing deployment. The patch fixes 17 critical bugs and adds 5 new wallet operations, 6 new API endpoints, and a new financial dashboard.

---

## Prerequisites

- PostgreSQL 14+ running and accessible
- Node.js 18+ and npm
- Existing Midan deployment (v0.2.0 or later)
- Database backup from the last 24 hours

---

## Step 1: Backup Your Database

**CRITICAL — do not skip this step.**

```bash
# Create a timestamped backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql

# Verify the backup is non-empty
ls -lh backup_*.sql

# For extra safety, copy the backup to a different machine
scp backup_*.sql user@backup-server:/backups/
```

---

## Step 2: Stop the Running Application

```bash
# Free the application port (default 3300)
npm run kill

# Verify no process is listening
lsof -i :3300 || echo "Port is free"
```

---

## Step 3: Extract the Patch Over Your Project

```bash
# From your project root
unzip -o midan11-patched.zip

# This will overwrite the following files:
# - src/lib/wallet-service.ts (major rewrite)
# - src/lib/payment-service.ts
# - src/lib/async-queue.ts
# - src/services/job.service.ts
# - src/services/cv-bank.service.ts
# - src/app/api/owner/topup/route.ts
# - src/app/api/owner/withdrawals/route.ts
# - src/app/api/payments/confirm/route.ts
# - src/app/api/finance/withdrawals/[id]/route.ts
# - src/app/api/expert-market/orders/route.ts
# - src/app/(main)/wallet/page.tsx
# - src/app/(main)/articles/page.tsx
# - src/app/(main)/learn/page.tsx
# - src/app/(main)/connections/page.tsx
# - src/app/(main)/bookmarks/page.tsx
# - src/app/(main)/premium/page.tsx
# - src/app/(main)/economy/indicators/page.tsx
# - src/app/(main)/economy/converter/page.tsx
# - src/app/(main)/economy/market/page.tsx
# - src/app/(main)/economy/map/page.tsx
# - src/app/(main)/economy/calendar/page.tsx
# - src/app/(main)/economy/ai-assistant/page.tsx
# - src/app/(main)/investment-bank/page.tsx
# - src/app/(main)/expert-market/page.tsx
# - src/components/OwnerPanel.tsx
# - src/components/EconomicIndicatorsView.tsx
#
# And create the following new files:
# - src/components/owner/FinancialOverviewDashboard.tsx
# - src/app/api/wallet/refund/route.ts
# - src/app/api/wallet/transfer/route.ts
# - src/app/api/owner/financial-overview/route.ts
# - src/app/api/owner/wallets/route.ts
# - src/app/api/owner/wallets/adjust/route.ts
# - src/app/api/owner/invoices/route.ts
# - src/app/api/owner/transactions/route.ts
# - src/app/api/expert-market/orders/[id]/release-escrow/route.ts
```

---

## Step 4: Install Dependencies

No new dependencies were added. Just verify your `node_modules` is up to date:

```bash
npm install
```

---

## Step 5: Regenerate Prisma Client

```bash
npm run db:generate
```

This ensures the Prisma client includes any schema changes (in this delivery, no schema changes are required for the fixes to work — they use `SELECT ... FOR UPDATE` raw queries which work with the existing schema).

---

## Step 6: Apply Database Fixes (Optional but Recommended)

The fixes work with the existing schema. However, the following optional migration adds a `version` field to the `Wallet` table for additional safety:

```sql
-- prisma/migrations/20260719000000_wallet_hardening/migration.sql
ALTER TABLE "Wallet" ADD COLUMN IF NOT EXISTS "version" INTEGER NOT NULL DEFAULT 0;
```

Apply with:

```bash
npx prisma db push --accept-data-loss
```

**Note:** This migration is optional. The `SELECT ... FOR UPDATE` row-level locks added in `wallet-service.ts` work without it. The `version` field provides an additional layer of optimistic concurrency that can be enabled later.

---

## Step 7: Repair Existing Data (Recommended)

If your existing deployment has been running with the buggy code, you may have inconsistent data. Run these repair queries:

```sql
-- 1. Find wallets where pendingBalance is inflated (top-ups approved but pendingBalance never decremented)
SELECT w.userId, w.balance, w.pendingBalance,
  (SELECT COUNT(*) FROM "TopUpRequest" WHERE "userId" = w.userId AND status = 'APPROVED') AS approved_topups,
  (SELECT COALESCE(SUM(amount), 0) FROM "TopUpRequest" WHERE "userId" = w.userId AND status IN ('PENDING_REVIEW')) AS pending_topups_amount
FROM "Wallet" w
WHERE w."pendingBalance" > 0
ORDER BY w."pendingBalance" DESC;

-- 2. Find withdrawals marked COMPLETED but balance never deducted
SELECT wr.userId, wr.amount, wr.status, wr."completedAt", w.balance
FROM "WithdrawalRequest" wr
JOIN "Wallet" w ON w."userId" = wr."userId"
WHERE wr.status = 'COMPLETED'
  AND NOT EXISTS (
    SELECT 1 FROM "WalletTransaction" wt
    WHERE wt."walletId" = w.id
      AND wt.type = 'WITHDRAW'
      AND wt."serviceId" = wr.id
  );

-- 3. For each such withdrawal, deduct the amount from balance
-- (Run this only after verifying the withdrawals above are legitimate)
-- UPDATE "Wallet" SET balance = balance - (
--   SELECT COALESCE(SUM(amount), 0) FROM "WithdrawalRequest"
--   WHERE "userId" = "Wallet"."userId" AND status = 'COMPLETED'
--   AND NOT EXISTS (
--     SELECT 1 FROM "WalletTransaction" wt
--     WHERE wt."walletId" = "Wallet".id AND wt.type = 'WITHDRAW'
--     AND wt."serviceId" = "WithdrawalRequest".id
--   )
-- )
-- WHERE EXISTS (...);

-- 4. Find WalletTransactions with invalid type 'PURCHASE_JOB' (created by old payments/confirm route)
SELECT COUNT(*) FROM "WalletTransaction" WHERE type = 'PURCHASE_JOB';
-- Update them to 'DEPOSIT' for consistency:
-- UPDATE "WalletTransaction" SET type = 'DEPOSIT' WHERE type = 'PURCHASE_JOB';
```

---

## Step 8: Build and Start

```bash
# Production build
npm run build

# Start the production server
npm run start
# OR for development:
npm run dev:direct
```

---

## Step 9: Verify the Fixes

### 9.1 Test Top-Up Flow

1. Log in as a regular user.
2. Navigate to `/wallet`.
3. Click "شحن المحفظة" and submit a top-up request for 10,000 IQD.
4. Log in as OWNER (`/owner`).
5. Navigate to "طلبات الشحن" tab.
6. Approve the top-up request.
7. **Verify:** User's `Wallet.balance` increased by 10,000 IQD AND `Wallet.pendingBalance` decreased by 10,000 IQD (was buggy before — pendingBalance was not decremented).

### 9.2 Test Withdrawal Flow

1. As a regular user with sufficient balance, request a withdrawal of 5,000 IQD.
2. As OWNER, navigate to "طلبات السحب".
3. Click "قبول" (Approve) — status moves to PROCESSING.
4. Click "إكمال" (Complete) — set a transactionRef.
5. **Verify:** User's `Wallet.balance` decreased by 5,000 IQD AND `pendingBalance` decreased by 5,000 IQD (was buggy before — balance was never deducted).

### 9.3 Test Job Post Payment

1. Log in as a company user.
2. Navigate to `/jobs/new`.
3. Fill the form and submit.
4. **Verify:** Job is created (no P2003 FK error), wallet is debited, WalletTransaction is created with `serviceId = job.id`.

### 9.4 Test Expert Service Order

1. As a buyer, navigate to `/expert-market`.
2. Click "طلب خدمة" on any service.
3. Submit the order.
4. **Verify:** Order is created (no "Unknown argument" error), buyer's wallet is debited, expert's `frozenBalance` is incremented (funds are in escrow, NOT in expert's balance yet).
5. As the buyer, call `POST /api/expert-market/orders/{orderId}/release-escrow` to release funds.
6. **Verify:** Expert's `frozenBalance` decreased, `balance` and `totalEarnings` increased.

### 9.5 Test New Financial Dashboard

1. Log in as OWNER.
2. Navigate to `/owner`.
3. Click the new "لوحة التحكم المالية الشاملة" tab (PieChart icon, second in the sidebar).
4. **Verify:** The dashboard loads with 4 tabs (Overview, Wallets, Transactions, Invoices).
5. Click "Wallets" tab — verify you see all wallets with balances.
6. Click "Adjust" on any wallet — verify the adjust dialog works and updates the balance.

### 9.6 Test i18n Switching

1. From any page, switch language to English.
2. Navigate to `/articles` — verify the title is "Articles" (not "المقالات").
3. Navigate to `/economy/indicators` — verify the title is "Iraqi Economic Indicators".
4. Navigate to `/learn` — verify the tab labels are in English.
5. Switch back to Arabic — verify all titles revert to Arabic.

### 9.7 Test RTL Layout

1. Switch to English (LTR mode).
2. Navigate to `/premium` — verify the toggle thumb is on the LEFT when monthly, and gradients flow left-to-right.
3. Navigate to `/articles` — verify the search icon is on the LEFT side of the input.
4. Switch to Arabic (RTL mode).
5. Verify the same elements flip correctly to the right side.

---

## Step 10: Monitor for Issues

After deployment, monitor the following for the first 48 hours:

- **Application logs:** `tail -f dev.log | grep -i error`
- **Prisma errors:** Watch for any `P2003` (FK violation) or `P2025` (record not found) errors — should be zero now
- **Wallet balance drift:** Compare `SUM(balance)` across all wallets against `SUM(totalDeposited - totalSpent)` — should match within rounding
- **Notification queue:** Check that `pending` count in `notificationQueue.getStats()` doesn't grow unboundedly

---

## Rollback Plan

If critical issues appear after deployment:

```bash
# 1. Stop the application
npm run kill

# 2. Restore the database from backup
psql $DATABASE_URL < backup_YYYYMMDD_HHMMSS.sql

# 3. Revert the code (assuming git)
git reset --hard HEAD~1  # or however many commits you made

# 4. Restart
npm run dev:direct
```

---

## Support

If you encounter issues with this delivery, refer to:

1. `docs/AUDIT-REPORT.pdf` — Full audit findings and fix details
2. `docs/CHANGES.md` — Detailed list of all modifications
3. The inline code comments — every fix is documented with `// FIX:` or `// NEW:` comments explaining what changed and why

For each issue, include:
- The exact error message (from server logs or browser console)
- The API endpoint or page URL where the issue occurs
- The request payload (if applicable)
- The expected vs. actual behavior
