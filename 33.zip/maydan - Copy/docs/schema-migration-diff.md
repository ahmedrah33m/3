# Schema ↔ Migration Diff Report

## Summary
- Schema Models: 297
- Migration Tables: 297
- Models in both: 297
- Only in Schema: 0
- Only in Migration: 0
- Schema Enums: 22
- Migration Enums: 22
- Enums in both: 22
- Only in Schema Enums: 0
- Only in Migration Enums: 0

## Models only in Schema (0)


## Models only in Migration (0)


## Enums only in Schema (0)


## Enums only in Migration (0)


## Field Differences (Models in both)

### AIOperationLog
- Only in Schema: createdAt    DateTime @default(now()), durationMs   Int?, id           String   @id @default(cuid()), inputTokens  Int?, metadata     Json? // JSON string
- Only in Migration: "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "durationMs" INTEGER,, "id" TEXT NOT NULL,, "inputTokens" INTEGER,, "metadata" JSONB,

### AccountDeletionRequest
- Only in Schema: createdAt   DateTime  @default(now()), expiresAt   DateTime, id          String    @id @default(cuid()), processedAt DateTime?, reason      String?
- Only in Migration: "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "expiresAt" TIMESTAMP(3) NOT NULL,, "id" TEXT NOT NULL,, "processedAt" TIMESTAMP(3),, "reason" TEXT,

### Achievement
- Only in Schema: category      String // PROFILE, LEARNING, WRITING, RESEARCH, QA, COMMUNITY, EXPERT, EVENTS, DICTIONARY, INVESTMENT, VOLUNTEER, SEASONAL, chainChildren    Achievement[]     @relation("AchievementChain"), chainOrder    Int? // order within chain, chainParent      Achievement?      @relation("AchievementChain", fields: [chainParentId], references: [id]), chainParentId String? // for achievement chains
- Only in Migration: "category" TEXT NOT NULL,, "chainOrder" INTEGER,, "chainParentId" TEXT,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "description" TEXT NOT NULL,

### AchievementChain
- Only in Schema: category      String, completedAt   DateTime?, createdAt     DateTime  @default(now()), currentStep   Int       @default(0), description   String?
- Only in Migration: "category" TEXT NOT NULL,, "completedAt" TIMESTAMP(3),, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "currentStep" INTEGER NOT NULL DEFAULT 0,, "description" TEXT,

### Ad
- Only in Schema: advertiser AdvertiserAccount? @relation(fields: [advertiserId], references: [id]), advertiserId   String?, clicks         Int       @default(0), createdAt      DateTime  @default(now()), description    String?
- Only in Migration: "advertiserId" TEXT,, "clicks" INTEGER NOT NULL DEFAULT 0,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "description" TEXT,, "endDate" TIMESTAMP(3),

### Adjustment
- Only in Schema: adjustmentType    String, amount            Decimal  @db.Decimal(18, 3), approvedAt        DateTime?, approvedById      String?, company           Company         @relation("AdjustmentCompany", fields: [companyId], references: [id], onDelete: Cascade)
- Only in Migration: "adjustmentType" TEXT NOT NULL,, "amount" DECIMAL(18,3) NOT NULL,, "approvedAt" TIMESTAMP(3),, "approvedById" TEXT,, "companyId" TEXT NOT NULL,

### AdvertiserAccount
- Only in Schema: ads           Ad[], balance      Decimal    @default(0), businessType String   @default("INDIVIDUAL"), campaigns     PromotionCampaign[], companyName  String?
- Only in Migration: "balance" DECIMAL(65,30) NOT NULL DEFAULT 0,, "businessType" TEXT NOT NULL DEFAULT 'INDIVIDUAL',, "companyName" TEXT,, "contactEmail" TEXT,, "contactPhone" TEXT,

### AiLog
- Only in Schema: action       String // summarize, translate, analyze, moderate, write, createdAt    DateTime @default(now()), durationMs   Int?, error        String?, id           String   @id @default(cuid())
- Only in Migration: "action" TEXT NOT NULL,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "durationMs" INTEGER,, "error" TEXT,, "id" TEXT NOT NULL,

### Allowance
- Only in Schema: allowanceType     String, amount            Decimal  @db.Decimal(18, 3), company           Company         @relation("AllowanceCompany", fields: [companyId], references: [id], onDelete: Cascade), companyId         String, createdAt         DateTime @default(now())
- Only in Migration: "allowanceType" TEXT NOT NULL,, "amount" DECIMAL(18,3) NOT NULL,, "companyId" TEXT NOT NULL,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "createdById" TEXT NOT NULL,

### AnalyticsEvent
- Only in Schema: category  String?, createdAt DateTime @default(now()), eventType String, id        String   @id @default(cuid()), ipAddress String?
- Only in Migration: "category" TEXT,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "eventType" TEXT NOT NULL,, "id" TEXT NOT NULL,, "ipAddress" TEXT,

### Answer
- Only in Schema: author   User              @relation("UserAnswers", fields: [authorId], references: [id]), authorId     String, authorOrg    String? // cached author org at time of answer, authorTitle  String? // cached author title at time of answer, commentCount Int      @default(0)
- Only in Migration: "authorId" TEXT NOT NULL,, "authorOrg" TEXT,, "authorTitle" TEXT,, "commentCount" INTEGER NOT NULL DEFAULT 0,, "content" TEXT NOT NULL,

### ApiKeyRecord
- Only in Schema: createdAt  DateTime  @default(now()), expiresAt  DateTime?, id         String    @id @default(cuid()), keyHash    String, keyPrefix  String // First 12 chars for display
- Only in Migration: "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "expiresAt" TIMESTAMP(3),, "id" TEXT NOT NULL,, "keyHash" TEXT NOT NULL,, "keyPrefix" TEXT NOT NULL,

### ApplicationStageChange
- Only in Schema: application   JobApplication @relation(fields: [applicationId], references: [id], onDelete: Cascade), applicationId String, changedBy     String // userId of HR who changed, changedByUser User           @relation("StageChangedBy", fields: [changedBy], references: [id]), createdAt     DateTime @default(now())
- Only in Migration: "applicationId" TEXT NOT NULL,, "changedBy" TEXT NOT NULL,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "fromStage" TEXT NOT NULL,, "id" TEXT NOT NULL,

### Article
- Only in Schema: aiScore       Float?, aiSummary     String?, analytics        ArticleAnalytics[], author           User               @relation(fields: [authorId], references: [id], onDelete: Cascade), authorId      String
- Only in Migration: "aiScore" DOUBLE PRECISION,, "aiSummary" TEXT,, "authorId" TEXT NOT NULL,, "category" "ArticleCategory" NOT NULL,, "commentCount" INTEGER NOT NULL DEFAULT 0,

### ArticleAnalytics
- Only in Schema: article Article @relation(fields: [articleId], references: [id], onDelete: Cascade), articleId      String, avgReadTime    Float    @default(0) // in seconds, bounceRate     Float    @default(0) // 0-100 percentage, createdAt      DateTime @default(now())
- Only in Migration: "articleId" TEXT NOT NULL,, "avgReadTime" DOUBLE PRECISION NOT NULL DEFAULT 0,, "bounceRate" DOUBLE PRECISION NOT NULL DEFAULT 0,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "date" TEXT NOT NULL,

### ArticleMedia
- Only in Schema: article Article @relation(fields: [articleId], references: [id], onDelete: Cascade), articleId String, id        String @id @default(cuid()), order     Int    @default(0), type      String @default("image") // image, video
- Only in Migration: "articleId" TEXT NOT NULL,, "id" TEXT NOT NULL,, "order" INTEGER NOT NULL DEFAULT 0,, "type" TEXT NOT NULL DEFAULT 'image',, "url" TEXT NOT NULL,

### ArticleSeries
- Only in Schema: articleCount    Int      @default(0), author User @relation("ArticleSeriesAuthor", fields: [authorId], references: [id], onDelete: Cascade), authorId        String, coverImage      String?, createdAt       DateTime @default(now())
- Only in Migration: "articleCount" INTEGER NOT NULL DEFAULT 0,, "authorId" TEXT NOT NULL,, "coverImage" TEXT,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "description" TEXT,

### ArticleTag
- Only in Schema: article Article @relation(fields: [articleId], references: [id], onDelete: Cascade), articleId String, hashtag Hashtag @relation(fields: [hashtagId], references: [id], onDelete: Cascade), hashtagId String, id        String @id @default(cuid())
- Only in Migration: "articleId" TEXT NOT NULL,, "hashtagId" TEXT NOT NULL,, "id" TEXT NOT NULL,

### ArticleView
- Only in Schema: articleId String, createdAt DateTime @default(now()), id        String   @id @default(cuid()), ipAddress String?, userId    String?
- Only in Migration: "articleId" TEXT NOT NULL,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "id" TEXT NOT NULL,, "ipAddress" TEXT,, "userId" TEXT,

### Assessment
- Only in Schema: attemptCount     Int      @default(0), averageScore     Float    @default(0), createdAt        DateTime @default(now()), description      String?, descriptionAr    String?
- Only in Migration: "attemptCount" INTEGER NOT NULL DEFAULT 0,, "averageScore" DOUBLE PRECISION NOT NULL DEFAULT 0,, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,, "description" TEXT,, "descriptionAr" TEXT,
