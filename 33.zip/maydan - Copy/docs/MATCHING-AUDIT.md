# تدقيق شامل — الوظيفة رقم 3: مطابقة الوظائف بالمهارات (Job & Skill Matching Engine)

> **الحالة:** Phase 1 — تدقيق فقط. **لم يُنشأ أي Model جديد ولم تُعدَّل أي API بعد.**
> **التاريخ:** 2026-09-28
> **المرجع:** `برومبت تطوير مطابقة الوظائف بالمهارات في منصة ميدان.md` (البند 190)
> **قاعدة حاكمة:** كل سطر في هذا التقرير إمّا **مقروء ومتحقق منه**، أو معلَّم صراحةً بـ «لم يُتحقق».
> **البيئة المرجعية:** working tree على الخادم `/home/ahmed/maydan` (الفرع `main`). النسخة المحلية `maydan - Copy` **متأخرة** وتنقصها ملفات (فويل: اعتمد الخادم).

---

## 0. خلاصة تنفيذية

نظام المطابقة **لا يوجد بعد كنظام**، لكن **المخطط (Schema) والبنية الأدنى جاهزة بنسبة كبيرة** مع فجوات جوهرية. الأدلة من قاعدة البيانات الفعلية:

| الجدول | الصفوف | الحقيقة |
|---|---|---|
| `Skill` / `SkillAlias` / `JobCategory` / `Role` | **0** / 0 / 0 / 0 | التصنيف موجود في المخطط لكن **لم يُزرع أبدًا** |
| `UserSkill` / `SkillGraph` / `Certification` | **0** / 0 / 0 | لا توجد مهارات مرشحين مقروءة من أي مصدر |
| `Job` جوّلت `skillsRequired` | **0 من 15,498** | لا وظيفة تحمل متطلبات مهارية مهيكلة حتى الآن |
| `CvJobMatch` / `JobCandidateMatch` | 0 / 0 | لا توجد سجل مطابقة مخزّن واحد |
| `SavedSearch` | 0 | لا توجد بحث محفوظ أو تنبيه وظائف |
| `User` | 52 (4 فقط عندهم `resumeData`) | قاعدة صغيرة — لا backfill مطلوب |

### ترجمة ذلك عمليًا

1. **يوجد محرَّكان حساب نصّيان جزئيان وغير متناسقين:**
   - `calculateMatchScore(applicant, job)` في `src/services/job-application.service.ts:341` — أوزان ثابتة `خبرة 30 / تعليم 25 / مهارات 35 / موقع 5 / نوع عمل 5`، ينتج `MatchDetail[]` بـ `match|partial|miss`. يُستدعى عند التقديم (يكتب `JobApplication.matchScore` + `matchDetails`) **ويعاد استخدامه** في `matchCandidatesForJob`.
   - `calculateJobMatch` في `src/app/api/cv-builder/match/route.ts` — صيغة مختلفة `مهارات 50 / خبرة 30 / تعليم 20`، **لا يكتب أي جدول**، ويقارن آخر 20 وظيفة فقط بلا Pagination.
   > الترتيب = **محرَّكان متنافسان** لنفس الناتج → يجب توحيدهما في وحدة `matching-engine.ts` واحدة (البند 76-77 من البرومبت).

2. **بوابة الخصوصية غائبة عن مطابقة الشركات:** `matchCandidatesForJob` (في `talent-marketplace.service.ts:38+`) يختار المرشحين بشرط `isBanned: false` ووجود CV فقط — **لا يفحص `cvVisibility` ولو HIDDEN_FROM_RECRUITERS**. هذا يتعارض مباشرةً مع نموذج الرضا الذي بنيناه للـ CV Bank (الوظيفة 2) وهو **ثغرة S1 يجب إصلاحها قبل أي مرحلة**. (`docs/CV-BANK-AUDIT.md` و `cvVisibility` في `User`).

3. **لا Required/Preferred، لا UNKNOWN، لا تحقق (verified/self-reported)، لا أوزان قابلة للتكوين، لا إصدار.** حساب المهارات يعتمد `includes` نصّي خام (زائف positives، لا مرادفات، لا عربي/إنجليزي)، والملف الناقص يُحتسب `miss` (نفي خاطئ) بدل `unknown`. اللغات/الشهادات/التوفر/الموقع المطبَّع **لا تدخل الحساب إطلاقًا** رغم وجود حقولها.

4. **البنية القابلة لإعادة الاستخدام قائمة وقوية:** التصنيف `Skill/SkillAlias/Role/JobCategory` في المخطط، وحقول الوظيفة المهيكلة (`skillsRequired`, `skillsNormalized [{skillId,level}]`, `experienceYearsMin/Max`, `workMode`, `languages`, `requiredCertifications`, `province/city`, `sector`, `jobLevel`), وحاوية الملف المهني `resumeData["professional"]` (`src/lib/jobs/professional-profile.ts`), و `src/lib/jobs/taxonomy.ts` (مفردات موحّدة), و Feature Flags (`FEATURE_AI_MATCHING`)، ونظام صلاحيات الشركات (`resolveCompanyContext`, `cv-bank-access`), و ATS كامل، و Queue خلفية.

**الخلاصة:** التوصية موافقة للبرومبت — المرحلة التالية هي **Phase 2 (متطلبات وظيفية مهيكلة Required/Preferred) ثم Phase 3 (Engine V1 موحّد مطّبع)**, لكن مع **قرار يسبق الجميع: إغلاق S1 (بوابة `cvVisibility` في أي مخرج مطابقة للشركات)**.

---

## 1. نطاق التدقيق والمنهجية

### مقروء بالكامل (FULL)
| الملف | الأسطر | الملاحظة |
|---|---|---|
| `prisma/schema.prisma` | 9280 | فهرس شامل — النماذج/التعدادات كلها + قراءة نماذج المطابقة/التصنيف/الوظائف كاملة |
| `src/services/job-application.service.ts` | 330-500 | `calculateMatchScore` + `MatchDetail` + الاستخدام |
| `src/services/talent-marketplace.service.ts` | كامل | `matchCandidatesForJob` / `getJobMatches` / `inviteCandidates` |
| `src/app/api/jobs/[id]/marketplace/route.ts` | كامل | GET/POST مطابقة جهة الشركة + `canManageJob` |
| `src/app/api/cv-builder/match/route.ts` | كامل | مطابقة مسار المرشح (jobs العشرون الأحدث) |
| `src/lib/jobs/professional-profile.ts` | كامل | حاوية الملف المهني + `normalizeProfessional` |
| `src/lib/jobs/feature-flags.ts` | كامل | أعلام الميزات (AI_MATCHING, ATS, JOB_ALERTS…) |
| `src/lib/jobs/taxonomy.ts` | 80 سطرًا أولى | الفئات/القطاعات/المحافظات/المستويات |
| `src/app/api/jobs/route.ts` | 70 سطرًا أولى | إنشاء/عرض الوظائف |
| `src/app/api/professional-profile/route.ts` | كامل | **Stub (501)** — لا يُستخدم |
| نماذج: `User`, `Job`, `Skill`, `SkillAlias`, `JobCategory`, `Role`, `JobApplication`, `SavedJob`, `UserSkill`, `UserSpecialization`, `Certificate`, `Certification`, `SkillEndorsement`, `SkillPassport(+Entry)`, `ProfessionalPassport(+Section)`, `CvVersion`, `CvJobMatch`, `SkillGraph`, `CvRecommendation`, `TalentPool(+Member)`, `TalentCrmEntry(+Interaction)`, `JobCandidateMatch`, `SavedSearch`, `CandidateInvitation`, `UserCompanyRole`, `Interview`, `Offer`, `JobScreeningQuestion`, `ScreeningAnswer`, `Notification`, `NotificationType` | — | من `schema.prisma` |

### فحص قاعدة البيانات (فعلي — `psql` عبر `maydan-postgres`)
- عدّادات الجداول أعلاه (القسم 0) + مُجمل `jobs_total=15498`, `users_total=52`.
- نموذج المطابقة الكامل: **لم يُتحقق على UI** (لا توجد صفحة مطابقة بعد).

---

## 2. الموجود القابل لإعادة الاستخدام (REUSABLE)

| البند | المكان | الاستخدام المقترح |
|---|---|---|
| Taxonomy كاملة | `Skill`(شجرة+aliases), `SkillAlias`, `JobCategory`, `Role` | الأساس لـ §13-16, §19 من البرومبت — تحتاج زراعة (seed) |
| متطلبات الوظيفة الحالية | `Job.skillsRequired[]`, `requiredLanguages[]`, `requiredCertifications[]`, `experienceRequired`(`1-3|3-5|5-10|10+`), `educationRequired`, `experienceYearsMin/Max`, `workMode(ONSITE|HYBRID|REMOTE…)`, `languages[{lang,level}]`, `province/city`, `sector`, `jobLevel`, `skillsNormalized[{skillId,level}]` | تُرتكّب عليها Phase 2 (توسيع لا استبدال) |
| حاوية الملف المهني | `resumeData["professional"]` via `src/lib/jobs/professional-profile.ts` | مصدر بيانات المرشح الأساسي §4, §26 |
| مفردات موحّدة | `src/lib/jobs/taxonomy.ts` (فئات/قطاعات/محافظات 19/أنواع/مستويات/أوضاع عمل/لغات) | وضع الحقول في واجهات الإنشاء §56-64 |
| Feature Flags | `src/lib/jobs/feature-flags.ts` (`FEATURE_AI_MATCHING`, `FEATURE_ATS`, `FEATURE_JOB_ALERTS`…) | تحكم roll-out للواجهات §184 |
| حساب جزئي معتمد | `calculateMatchScore` + `MatchDetail[]` (match/partial/miss) | بذرة Engine V1 — تُوحَّد وتُعمَّم |
| Recruiter-side discrete | `JobCandidateMatch` + `matchCandidatesForJob` + `/api/jobs/[id]/marketplace` | أساس Phase 5 (filters/sort/compare) |
| Candidate-side storage | `CvJobMatch` (جدول **غير مكتوب** حاليًا — dormant) | المستودع المناسب لنتيجة المرشح §128 |
| ATS | `JobApplication` (pipeline, matchScore, matchDetails, applicantSnapshot, screening) + `JobScreeningQuestion` + `Interview` + `Offer` | لا إنشاء نظام تقديم جديد §104 |
| صلاحيات/خصوصية | `resolveCompanyContext`, `cv-bank-access.ts`, `canManageJob` pattern, `UserCompanyRole`, `cvVisibility` | أساس كل بوابات الوصول §89-93 |
| البحث/التخزين | `cv-bank.service.ts` (search, consent `contactAvailable`, quota) + `SavedCandidate` + `TalentPool` | لا إنشاء CV Bank ثانٍ §189 |
| Queue | `src/lib/jobs` worker (BullMQ + fallback single-process) | عمليات البث §83-84 |
| إشعارات | `NotificationType` (يوجد `CV_BANK_CANDIDATE_FOUND`, `JOB_*`) + `notification.service.ts` | §106 (ربما نضيف نوع MATCH) |
| توطين | `src/lib/locales/ar.ts`, `en.ts` | §124 («كردي» **لم يُتحقق**) |

---

## 3. الناقص (MISSING) — ما يتطلبه البرومبت ولا يوجد

| # | البند | التفاصيل |
|---|---|---|
| 1 | **المتطلبات المهيكلة** (المواصفة §11, §56-64) | لا توجد `JobSkillRequirement` ولا تمييز **Required/Preferred/Optional** ولا `weight`/`years`/`verificationRequired` لكل مطلوب. `skillsRequired` مصفوفة مسطّحة بلا أهمية. |
| 2 | **Engine V1 موحّد** (§32-36, §76-77, §160) | محرَّكان متنافسان؛ لا وحدة pure موحّدة؛ لا أوزان قابلة للتكوين (§96) ولا حدود منطقية |
| 3 | **شرح النتيجة** (§78-80, §130) | لا `MatchBreakdown` ولا `Evidence` (المصدر/الدليل لكل مطلوب) |
| 4 | **UNKNOWN + التحقق** (§50, §131, §25, §134, §158) | الغير محدد = `miss` حاليًا؛ الـ `Certification.isVerified`/`SkillGraph.verified`/`ProfessionalPassportSection.status` **لا تدخل الحساب** |
| 5 | **اللغات/الشهادات/التوفر/الموقع المطبع** (§23-24, §17-21) | لم تُقيَّم إطلاقًا (رغم الحقول) |
| 6 | **الإصدار والصحة** (§95, §136-138, §82) | لا `algorithmVersion`/`profileVersion`/`jobVersion`، لا إبطال عند تعديل الملف أو الوظيفة |
| 7 | **Feedback** (§99-100) | لا جدول ولا API |
| 8 | **صفحات/واجهات** | لا `/jobs/recommended` (§67)، لا بطاقة توافق على صفحة الوظيفة (§7-9, §39)، لا `/company/jobs/[jobId]/matching` (§41-47)، استبدال route موجود بـ JSON فقط |
| 9 | **ضوابط الخصوصية** (§53-55, §145) | لا opt-out من matching/التوصيات، لا «حجب شركة»، لا `allowed/blockedMatchFields` firewall (§30-31) |
| 10 | **Rate limiting + bulk** (§115-116) | لا حماية على `POST /matching/run` ولا على المواب الخام |

---

## 4. المكرر/غير المتناسق (DUPLICATE)

1. **محرَّكان للحساب** — `calculateMatchScore` (30/25/35/5/5) مقابل `calculateJobMatch` (50/30/20). → توحيد إلزامي.
2. **`MatchDetail.status`** = `match|partial|miss` vs مواصفة `matched|partiallyMatched|notMatched|unknown` (§130).
3. **`CvJobMatch` (مكرر/ميت)** — لا يكتبه أي كود رغم أنه مستودع المرشح الأمثل.
4. **`JobCandidateMatch` (نشط)** — مستودع الشركة والمصدر لتحسين UX بدل تخزين جديد.
5. **`/api/professional-profile` (Stub 501)** — مكرر مع `resumeData["professional"]` و `/api/jobs/candidate/profile` — يُهجر أو يوجِّه.

---

## 5. المكسور (BROKEN) / مخاطر الأمان والبيانات

### الأمان:
- **S1 (عليا):** `matchCandidatesForJob` لا يفحص `cvVisibility` ولا حظر شركة — يكشف مرشحين HIDDEN لشركات. يجب أن يمر عبر بوابة `cv-bank-access` نفسها.
- **S2:** `POST /api/jobs/[id]/marketplace` بلا rate-limit؛ التعداد الضخم (fetch limit) متزامن في الطلب — مناسب للاستغلال (>§115).
- **S3:** لا اختبارات IDOR بعد للـ `jobId/candidateId` في مسار المطابقة (الكتب الحالية للـ marketplace تفحص `canManageJob` ✓ لكن عموم pivots غير مختبَرة).

### البيانات:
- كل جداول التصنيف/المهارات فارغة → **لا backfill، إصلاح آمن** (مثل CV Bank سابقًا).
- `jobs_with_skills=0` → حتى مع Engine؛ لا نتائج بدون **متطلبات وظيفية مهيكلة** (Phase 2 قبل كل UI).
- لا `UNKNOWN`: ملف ناقص = `miss` → نتائج مضللة.
- المطابقة النصّية `includes()` تُحدث negative/positive خاطئة بين العربي والإنجليزي والمرادفات (§14-15).

### الأداء:
- `matchCandidatesForJob` يصف كل المرشحين في طلب HTTP — لا يُصغّر عند النمو (100k) (§83, §139).
- `cv-builder/match` يعدّ 20 وظيفة بلا Pagination/كاش.

### UX:
- لا بطاقة توافق مفسَّرة، لا اقتراحات تحسين، لا `/jobs/recommended`، لا filters/sort/compare للشركة — السطور الحالية (route JSON) بلا محتوى الواجهة.

---

## 6. خطة المراحل المقترحة (Phase التصحيح)

1. **Gate S1 (قبل كل شيء):** إلزام أي قراءة/كتابة مطابقة للشركات بفحص `cvVisibility` + رفض Company + `isBanned`. إضافة opt-out «سماح باكتشاف المطابقة» للمرشح (§53-55).
2. **Phase 2 — المتطلبات المهيكلة:** `JobSkillRequirement` (skillId→Taxonomy, importance Required/Preferred/Optional, weight, years, verificationRequired) + تجهيز وظيفة منشئ المتطلبات UI (§56-64). قابل للإضافة عبر `Job.skillsNormalized` الموسّع أو جدول جديد (قرار — القسم 7).
3. **Phase 3 — Engine V1:** `src/lib/jobs/matching-engine.ts` — pure/deterministic: توحيد الصيغتين، أوزان قابلة للتكوين بحدود (§96)، منحنى خبرة (Partial) (§17), تعليم مع Equivalent Fields (§18-19), موقع مطبَّع (§20-21), لغة (§23), شهادات + تحقق (§24-25), توفر (§22), Language/AR aliases عبر `SkillAlias`, Basics بيانات غير موجودة → `UNKNOWN`. مخرجات `{score, breakdown, matchedSkills, missingSkills, matchedRequirements, warnings, confidence}` (§78) + حفظ `algorithmVersion` (§95).
4. **Phase 4 — تجربة المرشح:** بطاقة تطابق على صفحة الوظيفة (§7-9, §39, §187) + شرح «كيف تم الحساب؟» (§47) + المهارات الناقصة + اقتراحات (§29) + `/jobs/recommended` (§67-68) + زر «إضافة لملفي» (§48-49 بدون auto-add) + الإبطال عند تعديل الملف (§82).
5. **Phase 5 — تجربة الشركة:** `/company/jobs/[jobId]/matching` (§41-47, §188) فوق `JobCandidateMatch` الحالي: filters/sort/compare/بحث محفوظ + feedback (§99-100) + rate-limit (§115).
6. **Phase 6 — أداء:** pagination⁄cursor (§88), caching مع مفتاح `jobId+candidateId+versions` (§81-82), batch عبر queue (§83-84).
7. **Phase 7 — AI (اختياري، لاحق):** `FEATURE_AI_MATCHING` من flags؛ Semantic Matching مساعِد قابل للتفسير (§71-75, §184) بلا قرار شخصي.

---

## 7. قرارات مطلوبة قبل بدء Phase 2

1. **نموذج المتطلبات:** جدول جديد `JobSkillRequirement` (أنظف، قابل للفلترة والـ weight — **موصى به**) أم توسيع `Job.skillsNormalized` JSON (أقل تغيير Migration)؟
2. **مستودع المرشح:** تفعيل `CvJobMatch` الميت كمخزن نتيجة المرشح اللحظي (موصى به، يكفي `algorithmVersion`).
3. **نطاق Phase 2-3 في هذه الجلسة:** هل ننفذ الآن (Phase 2 + Engine + اختبارات + واجهة المرشح) قبل واجهة الشركة، وفق تسلسل البرومبت؟

---

## 8. تعريف الإنجاز (DoD — مستخلص البنود 177)

- متطلبات وظيفية مهيكلة ✓ — مصدر بيانات المرشح = `resumeData["professional"]` + `SkillGraph` ✓ — حساب match للخبرة/التعليم/الموقع/اللغة/الشهادة/التوفر ✓ — Required/Preferred ✓ — UNKNOWN ✓ — شرح وتفسير ✓ — ناقصات+اقتراحات ✓ — توصيات المرشح ✓ — مطابقة الشركة فوق `cv-bank-access` ✓ — خصوصية Opt-out ✓ — صلاحيات الشركة ✓ — IDOR/Rate-limit ✓ — عربي/إنجليزي/RTL ✓ — TypeScript/Lint/Testes/Build ✓