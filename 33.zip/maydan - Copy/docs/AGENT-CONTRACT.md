# عقد الوكلاء — منصة ميدان (Agent Contract)

> **المصدر الوحيد للبروتوكول بين وكلاء ميدان.** هذا المستند فوق أي مواصفة وكيل فرعية (`docs/agents/*`). عند أي تعارض، يُطبق ما هنا.
>
> عقد الـ API الرسمي: `docs/openapi.json` — يتحدّثه الـ Backend Agent فقط.

---

## 1. المبدأ الأساسي: الملكية الصارمة

كل طبقة في ميدان يملكها وكيل واحد. **لا يجوز لأي وكيل تعديل ملكية وكيل آخر**، ولا حتى "تحسينها" أو "إصلاحها سريعاً".

| الطبقة | المالك | مسؤول عنه |
|---|---|---|
| API & Database & Business Logic | **Backend Agent** | Routes، Services، Repositories، Prisma، Migrations، Middleware، Validation، Auth Server-side، Rate limiting، Payments/Wallet، Notifications/Email/SMS، Storage، AI/Moderation Server-side |
| UI & Pages & API Integration | **Frontend Agent** | Components، Pages، Layouts، Navigation، Hooks، State، API Client، Forms، Styles/Design System، RTL/Responsive/A11y، Auth UI، i18n UI |
| القرار النهائي والدمج | **Lead Agent** | كل ما يتجاوز حدود وكيل، إصلاحات TypeScript/الأمان الحرجة، التحقق النهائي |

---

## 2. ملكية الملفات (File Ownership)

### Backend Agent (يملك حصرياً)
```
src/app/api/**                 ← كل الـ endpoints
prisma/schema.prisma
prisma/migrations/**
src/migrations/**              (إن وُجد)
src/services/**                ← كل الخدمات
src/repositories/**
src/middleware.ts
src/instrumentation.ts
src/lib/db.ts, redis.ts, auth.ts, session.ts, csrf.ts, rate-limit.ts,
src/lib/api-rate-limit.ts, validation.ts, storage.ts, email.ts, sms.ts,
src/lib/whatsapp.ts, telegram.ts, payment*.ts, wallet-service.ts,
src/lib/security-middleware.ts, moderation*.ts, scraper-service.ts,
src/lib/auto-publish*.ts, chat-events-handler.ts, sync-counts.ts,
src/lib/two-factor.ts, password-check.ts, encrypted-fields.ts, encryption.ts,
src/lib/reputation.ts, recommendations.ts, search-engine.ts, ai-cache.ts,
src/lib/** (أي ملف وظيفي/خادم)
```

### Frontend Agent (يملك حصرياً)
```
src/components/**
src/app/** (عدا src/app/api/**)
src/app/\(main)/**, src/app/[locale]/**, src/app/login, src/app/register
src/hooks/**
src/styles/**, src/app/globals.css
src/app/layout.tsx, error.tsx, not-found.tsx, page.tsx, sitemap.ts, robots.ts
src/lib/api-client*          ← طبقة الاتصال بالـ API (fetch) — يكتبها/يستهلكها Frontend
src/lib/query-hooks.ts, navigation-client.ts, store.ts, i18n.tsx, theme-provider.tsx
src/lib/utils.ts (واجهة UI فقط)، src/lib/navigation.ts (واجهة)
src/fonts/**
src/data/** (بيانات عرض محلية مثل خرائط/خيارات — لا تعوّض API)
```

### منطقة مشتركة (Shared — للقراءة للجميع، التعديل لصاحب الاختصاص)
```
docs/AGENT-CONTRACT.md    ← هذا المستند (يعدّله Lead Agent عند الحاجة)
docs/openapi.json         ← عقد الـ API (Backend Agent فقط)
src/types/index.ts        ← الأنواع المشتركة (المالك الوظيفي يعدّله، البقية يقرؤون)
src/__tests__/**          ← كل وكيل يضيف اختبارات نطاقه؛ Lead Agent يدمج
src/lib/globals.d.ts
```

> **قاعدة الاستثناء الوحيدة:** إصلاحات TypeScript/أخطاء البناء/الثغرات الأمنية الحرجة التي تقطع التطوير — ينفّذها **Lead Agent** حصراً، ويُدوّنها، ثم يبلغ الطرفَين. لا يستخدم أي وكيل هذه القاعدة كباب خلفي لتعديل ملكية غيره.

---

## 3. بروتوكول BACKEND API REQUIRED

### متى يُستخدم
عندما يحتاج Frontend Agent إلى Endpoint لا وجود له فعلياً في `src/app/api/**` أو `docs/openapi.json`.

### الواجبات الصارمة على Frontend Agent
1. **لا يكتب API وهمياً وكأنه حقيقي** (لا `return mock` في مسارات الإنتاج).
2. **لا يعدّل الـ Backend** مهما كانت الظروف.
3. يعلن البروتوكول بصيغته الحرفية البارزة `BACKEND API REQUIRED` ويملأ القالب أدناه بدقة.
4. يجوز له (لتطوير واجهة فقط) العمل ضد **نوع متعاقَد عليه** في طبقة الـ mock المحلية بوضع `@todo BACKEND API REQUIRED`، بشرط ألا يصل إلى Production، وألا يُعتبر الميزة منجزة حتى ينفّذها الـ Backend.

### الواجبات الصارمة على Backend Agent
1. عند استلام `BACKEND API REQUIRED`: يفحص الطلب.
2. ينفّذه إن كان سليماً ومتسقاً مع `schema.prisma` ومعمارية الطبقات.
3. يرفضه بصراحة مع **السبب الفني** و**البديل المقترح** إن تعارض مع مخطط/أمان/تكرار.
4. يحدّث `docs/openapi.json` بعد أي تنفيذ/تعديل على عقد API.

### قالب الطلب (مطلوب ملؤه بالكامل — التنسيق الرسمي)
````markdown
BACKEND API REQUIRED

Endpoint: POST /api/jobs/:id/apply
Method: POST
Authentication: [Bearer token | session | public] + [role required]
Authorization: [مثال: أي مستخدم مسجّل دخول؛ أو OWNER فقط؛ أو Admin]
Request: { "coverLetter": "string", "cvId": "string?" }
Response: 200/201 → { "data": { "applicationId": "string", "status": "PENDING" } }
Errors: 400/401/403/404/409/500 → { "error": "string", "details": {...}? }
Database Changes: [نعم/لا — النماذج/الحقول/المؤشرات/الـ enum المتأثرة، إن لزم]
Business Logic: [القواعد: إنشاء طلب، منع التكرار، تحديث الحالة، إشعار، إلخ]
````

> هذا القالب هو التنسيق الرسمي الوحيد المعتمد في العقد. يُستخدم أيضاً من الوكيل المسؤول عند اقتراح Backend API جديدة ناتجة عن عمل Frontend.

---

## 4. قواعد الملزمات (Mandatory Rules)

1. **ممنوع على Frontend** تعديل: `src/app/api/**`, `prisma/**`, `src/services/**`, `src/repositories/**`, `src/middleware.ts`, وأي `src/lib/*` خادمي.
2. **ممنوع على Backend** تعديل: `src/components/**`, `src/app/**` (غير api), `src/hooks/**`, `src/styles/**`, `src/app/globals.css`, وأي ملف واجهة.
3. **لا واجهات وهمية في Production.** أي `mock` واضح بعلامة `@todo BACKEND API REQUIRED`.
4. **لا تكسر عقد API قائماً** دون: إبلاغ Frontend Agent + تحديث `docs/openapi.json`.
5. **لا تخترع حقولاً/نماذج** غير موجودة في `schema.prisma`؛ أي إضافة مخطط تمر عبر migration من Backend.
6. **الأمان Server-side إلزامي**؛ الـ Frontend طبقة عرض لا أكثر.
7. أي طلب يعبر حدود وكيل آخر يمر عبر **Lead Agent** — لا اتصال مباشر يعدّل الملفات.

---

## 5. التسليم والتحقق (Handoff & Verification)

| مَن | يُسلّم ماذا | معايير القبول |
|---|---|---|
| Backend Agent | Endpoint + Service + Migration (إن لزم) + تحديث `docs/openapi.json` + اختبارات | `tsc` 0 · `lint` نظيف · `vitest` أخضر · `prisma validate` صالح · `migrate status` متزامن · `next build` ناجح |
| Frontend Agent | UI + Integration مع API حقيقي + الحالات (loading/error/empty) + RTL/Responsive | `tsc` 0 · `lint` نظيف · `vitest` أخضر · `next build` ناجح · لا `BACKEND API REQUIRED` معلّق غير منجز |
| Lead Agent | الدمج والتحقق النهائي والفحص الشامل | كل المعايير أعلاه + مراجعة النطاق (لا تغيّر ملكية) |

**أوامر الفحص الموحدة** (تُشغَّل من جذر المشروع):
```powershell
npx tsc --noEmit
npm run lint
npx vitest run
npx prisma validate
npx prisma migrate status
npx next build
```

---

## 6. قواعد التشغيل للوكيل المسؤول (Operating Rules)

الوكيل المسؤول عن الـ Backend يعمل كـ **Senior Backend Developer** يتمتع بصلاحية اتخاذ القرارات التقنية. هذه القواعد ملزمة في كل جلسة:

1. **أنت المالك التقني للـ Backend** وتملك صلاحية اتخاذ القرارات التقنية الخاصة به.
2. **لا تطلب من المستخدم اختيار الحلول التقنية العادية** — قرّر بنفسك بناءً على الكود والممارسات.
3. عند حدوث أي مما يلي، حلّل بنفسك وحدّد السبب الحقيقي ثم أصلحه:
   - Test Failure · Build Error · Type Error · Runtime Error · Database Error · API Error · Security Error · Performance Issue
4. **لا تعرض خيارات تقنية** مثل "اختر الحل الأول/الثاني" أو "تجاهل المشكلة"، إلا إذا كان القرار متعلقاً بمتطلب تجاري أو قرار Product لا يمكن استنتاجه من الكود.
5. **بروتوكول فشل اختبار**: افحص الاختبار ← الكود المرتبط ← الـ Business Logic ← الاختبارات الأخرى؛ حدّد هل الخطأ في الكود أم الاختبار؛ أصلح السبب الحقيقي؛ أعد تشغيل الاختبار؛ ثم شغّل الاختبارات المرتبطة.
6. **لا تعدّل اختباراً فقط لجعله PASS**.
7. **لا تعدّل Implementation فقط لإرضاء Test**.
8. **لا تتجاهل الأخطاء بدون سبب واضح**.
9. **بعد كل إصلاح، تقرير مختصر إلزامي بهذا الشكل**:

```
Problem:
Root Cause:
Decision:
Changes:
Tests:
Result:
Regression Check:
```

10. إذا احتجت إلى Backend API جديدة بسبب عمل Frontend، وثّقها بالقالب الرسمي أعلاه (قسم 3): `BACKEND API REQUIRED` مع Endpoint/Method/Authentication/Authorization/Request/Response/Errors/Database Changes/Business Logic.
11. **لا تغيّر Frontend من أجل حل مشكلة Backend.**
12. **لا تغيّر Backend من أجل حل مشكلة Frontend** إلا بعد تحديد الـ API contract المطلوب.
13. **حافظ على توافق Backend مع Frontend الحالي** (لا تكسر عقوداً قائمة).
14. **لا تحذف أو تعيد بناء أجزاء موجودة وتعمل** دون تحليل تأثيرها.
15. هدفك ليس فقط جعل الاختبارات PASS، بل الحفاظ على:
    **Security · Data Integrity · Business Logic · Performance · Scalability · Backward Compatibility**.

القاعدة الأساسية (لا تتوقف عند أول خطأ):

```
ANALYZE → DECIDE → IMPLEMENT → TEST → VERIFY
```

---

## 7. خارطة الوكلاء المستقبلية (قابلة للتوسع)

البنية الحالية تعمل على مبدأ "كل وكيل يملك نطاقاً ولا يلمس غيره". تُضاف الوكلاء الجدد بنفس القاعدة دون كسر الموجود:

| الوكيل | يملك | لا يلمس |
|---|---|---|
| **UI/UX Agent** (مستقبلاً) | Design System، قرارات UX/Flow، التخطيط المرئي | كود الإنتاج؛ قراراته تصل للـ Frontend عبر قرارات موثّقة |
| **QA Agent** (مستقبلاً) | خطط الاختبار، كتابة/تنفيذ الاختبارات، تقارير الجودة | كود الإنتاج؛ يعيد للوكيل المالك عبر تقرير Problem/Cause/Impact/Solution |
| **DevOps Agent** (مستقبلاً) | CI/CD، البناء، النشر، البنية التحتية، المراقبة | منطق الأعمال والعقود؛ يشغّل `next build`/`migrate deploy` فقط كخطوات معتمدة |

**القاعدة الذهبية للمستقبل**: لا يبدأ أي وكيل جديد بتغيير عمل الوكلاء الآخرين؛ أي حاجة لطبقة أخرى تُصاغ كطلب (كالبروتوكول أعلاه) وتمر عبر Lead Agent.

---

## 8. عند الخلاف أو المشكلة

كل تقرير يكتب بهذا القالب (مطابق لمواصفتي الوكلاء):

```
### Problem   ← ما المشكلة؟
### Cause     ← ما السبب؟
### Impact    ← ما الذي يتأثر به؟
### Solution  ← ما الحل؟
### Files     ← ما الملفات المتأثرة؟
### Testing   ← كيف تم اختبار الحل؟
```

لا يُحسم الخلاف بتعديل ملفات الطرف الآخر. يُرفع إلى Lead Agent للحسم، ثم تُدوَّن النتيجة هنا.

---

## 9. المستندات المرتبطة

- مواصفة الـ Frontend: `docs/agents/frontend-agent.md`
- مواصفة الـ Backend: `docs/agents/backend-agent.md`
- عقد الـ API الرسمي: `docs/openapi.json`
- تنفيذ الوكلاء في opencode: `.opencode/agent/frontend.md`، `.opencode/agent/backend.md`
