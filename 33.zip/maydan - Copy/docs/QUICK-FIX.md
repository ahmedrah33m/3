# Quick Fix — حل مشاكل قاعدة البيانات و Schema

## المشاكل التي تم إصلاحها في هذه النسخة

### 1. خطأ Prisma Schema: `Field "activityLogs" is already defined on model "User"`

**السبب:** كان هناك تعريفين مكررين:
- `User.activityLogs` معرّف مرتين (مرة في السطر 246 بمُسماة علاقة "ActivityLogs"، ومرة في السطر 333 بدون اسم علاقة)
- `model UserActivityLog` معرّف مرتين (مرة في السطر 686 للسجل الأمني، ومرة في السطر 4411 لنقاط التعلم)

**الحل المُطبّق:**
- حذف التكرار في `User.activityLogs` (السطر 333)
- حذف `model UserActivityLog` الثاني (السطر 4411) — كان غير مستخدم في الكود
- جميع الاستخدامات الفعلية تستخدم الحقول الأمنية (action, ipAddress, userAgent, details)

### 2. خطأ `P1000: Authentication failed for user 'user'`

**السبب:** ملف `.env` **غير موجود** في الـ zip (لأن `.gitignore` يتجاهله). عندما يحاول Prisma الاتصال بدون `.env`، يستخدم افتراضياً المستخدم `user` (الاسم الافتراضي في PostgreSQL) الذي إما غير موجود أو بدون كلمة مرور.

**الحل المُطبّق:**

#### أ) سكريبت `setup-db.sh` جديد ذكي
يُجهز قاعدة البيانات تلقائياً في 7 خطوات:
1. يقرأ `DATABASE_URL` من `.env`
2. يتحقق من تشغيل PostgreSQL
3. ينشئ المستخدم إذا لم يكن موجوداً
4. ينشئ القاعدة إذا لم تكن موجودة
5. يمنح الصلاحيات
6. يختبر الاتصال
7. يشغّل `prisma db push` و `prisma generate`

#### ب) ملف `.env.dev-template` جديد
قيم آمنة جاهزة للتطوير المحلي:
```bash
cp .env.dev-template .env
bash scripts/setup-db.sh
```

#### ج) تحسين `db.ts`
الآن يُظهر رسالة واضحة بالعربية والإنجليزية عند غياب `DATABASE_URL` بدلاً من الخطأ الغامض السابق.

#### د) تحسين `dev.sh`
الآن يفحص وجود `.env` قبل البدء، ويُنشئه تلقائياً من `.env.dev-template` إذا لم يكن موجوداً.

---

## كيفية التشغيل الآن (3 طرق)

### الطريقة 1: التشغيل السريع (مُوصى به)

```bash
cd ~/maydan

# 1. إنشاء .env من القالب الجاهز
cp .env.dev-template .env

# 2. تجهيز قاعدة البيانات تلقائياً
bash scripts/setup-db.sh

# 3. (اختياري) تشغيل seed
npm run db:seed

# 4. تشغيل التطبيق
npm run dev
```

### الطريقة 2: استخدام أمر `npm run setup` (الأكثر شمولاً)

```bash
cd ~/maydan
npm run setup
```

هذا الأمر يقوم بكل شيء: إيقاف العمليات القديمة → تشغيل `setup-db.sh` → إنشاء حساب admin → تشغيل التطبيق.

### الطريقة 3: التشغيل اليدوي (للمستخدمين المتقدمين)

```bash
# 1. تثبيت الحزم
npm install

# 2. إنشاء .env بقيمك الخاصة
cp .env.example .env
# عدّل .env وضع قيمك الحقيقية

# 3. تجهيز قاعدة البيانات في PostgreSQL يدوياً
sudo -u postgres psql
# داخل psql:
CREATE USER maydan WITH PASSWORD 'maydan_secure_password' CREATEDB;
CREATE DATABASE maydan_db OWNER maydan;
GRANT ALL PRIVILEGES ON DATABASE maydan_db TO maydan;
\q

# 4. تطبيق schema
npx prisma db push
npx prisma generate

# 5. (اختياري) تشغيل seed
npm run db:seed

# 6. تشغيل التطبيق
npm run dev
```

---

## استكشاف الأخطاء

### `P1000: Authentication failed`

**الأسباب والحلول:**

1. **ملف `.env` غير موجود**
   ```bash
   cp .env.dev-template .env
   bash scripts/setup-db.sh
   ```

2. **كلمة مرور PostgreSQL لا تطابق**
   ```bash
   # حدّث كلمة المرور في PostgreSQL:
   sudo -u postgres psql -c "ALTER USER maydan WITH PASSWORD 'maydan_secure_password';"
   ```

3. **PostgreSQL غير مُشغّل**
   ```bash
   sudo systemctl start postgresql
   # أو
   sudo service postgresql start
   ```

4. **ملف pg_hba.conf يرفض الاتصالات المحلية**
   ```bash
   # عدّل /etc/postgresql/16/main/pg_hba.conf (أو الإصدار المناسب)
   # أضف أو عدّل السطر:
   # host    all    all    127.0.0.1/32    md5
   # ثم:
   sudo systemctl restart postgresql
   ```

### `P1012: Prisma schema validation - Field already defined`

تم إصلاحه في هذه النسخة. إذا ظهر مرة أخرى، شغّل:
```bash
grep -c "^model UserActivityLog" prisma/schema.prisma
# يجب أن يُرجع: 1
```

### `Midan schema is not up to date`

```bash
npx prisma db push --accept-data-loss
npx prisma generate
```

### `JWT_SECRET not set — using development-only fallback`

تحذير غير حرج، لكن يجب تعديله في الإنتاج:
```bash
# توليد سر آمن:
openssl rand -hex 32
# ضعه في .env:
JWT_SECRET=<القيمة_المولّدة>
```

### `tailwind.config.ts MODULE_TYPELESS_PACKAGE_JSON warning`

تحذير غير حرج من Node.js. لتجنّبه، أضف `"type": "module"` إلى `package.json` — لكن قد يكسر سكريبتات bash أخرى. الأفضل تجاهله.

---

## التحقق من نجاح الإعداد

بعد تشغيل `npm run dev`، افتح المتصفح على http://localhost:3300. يجب أن ترى:
- صفحة الهبوط بدون أخطاء
- عند فتح Console المتصفح: لا توجد أخطاء 500
- عند الضغط على زر "تسجيل الدخول": تظهر صفحة الدخول بدون أخطاء

للتحقق من قاعدة البيانات:
```bash
psql -U maydan -h localhost -d maydan_db -c "SELECT COUNT(*) FROM \"User\";"
# يجب أن يُرجع عدداً (ربما 0 إذا لم تشغّل seed)
```

---

## هل ما زالت هناك مشاكل؟

إذا استمرت المشاكل بعد اتباع الخطوات أعلاه، أرسل:

1. مخرجات `bash scripts/setup-db.sh` كاملة
2. محتوى ملف `.env` (بدون كلمات المرور الحقيقية)
3. ناتج `psql -U postgres -c "\du"` (قائمة المستخدمين)
4. ناتج `psql -U postgres -c "\l"` (قاعدة البيانات)

سجل الأخطاء:
```bash
# تشغيل مع تسجيل كامل:
npm run dev 2>&1 | tee dev.log

# إرسال آخر 100 سطر:
tail -100 dev.log
```
