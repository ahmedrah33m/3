# FINAL_SYSTEM_ARCHITECTURE.md

## Frontend
Next.js App Router — `124` صفحة (Server/Client مختلط)، i18n عربي/إنكليزي/كردي، Radix+Tailwind، نظام ui-v2 موحد.

## Backend
428 مسار API (`645` دالة HTTP). كل مسار يتبع: Auth (requireAuth/getCurrentUser) → صلاحيات (FINANCE_ROLES/OwnerOrAdmin/…) → Zod validation حيث يلزم → Service → Prisma.

## Services Layer
22 خدمة داخل `src/services` تغطي Jobs/Employment pipeline/Offer/Company/CV-Bank/Consultation-Marketplace/Messaging/Moderation-AI/Analytics/Notification-readside/Report/Search/Talent-Pool...

## Database
PostgreSQL + Prisma 6 (260 نموذجاً، 22 enum). الفهارس والقيود مرصودة في DATABASE_RELATION_MAP.md.

## Events & Engines
- **Notifications**: طابور sendNotification (Redis أو in-process batched flush) ← Notification rows + SSE signal + بريد اختياري. خريطة كاملة NOTIFICATION_EVENT_MAP.md
- **Audit**: lib/audit.logAudit (43 موقع استدعاء في admin APIs) + security/audit-trail بسلسلة hash قابلة للتحقق verifyAuditChain() + **(جديد)** logMoneyAudit لكل حركة مالية
- **Analytics**: trackEvent للعميل عبر POST /api/analytics/events + **(جديد)** trackServerEvent مدمج في 8 نقاط تجارية حرجة

## Payments/Wallet
محفظة IQD موحدة (wallet-service): Idempotency، Ledger WalletTransaction، فواتير، عمولة منصة + حصة مزود، تجميد أموال السحب، خصم ذري شرطي، REST finance review بواجهة Owner/Admin/Modérator.

## AI
moderation-ai (إشراف آلي)، مطابقة وظائف-سيرة matchScore، مساعدات محتوى. كل نداءات AI خلف session auth — لا AI يتجاوز الصلاحيات.

## Security
JWT HttpOnly + blacklist عند تقليل صلاحية + 2FA + rate limits + IDOR tests + no secrets in logs (مفحوص).

## Integrations
S3 presigned uploads, SMTP email templates عربية, WhatsApp business notifications, WebSocket خدمة إشعارات منفصلة examples/websocket.
