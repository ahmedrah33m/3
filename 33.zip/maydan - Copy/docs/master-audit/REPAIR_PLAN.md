# REPAIR_PLAN.md — خطة الإصلاحات بترتيب الأولوية

> MASTER PROMPT المرحلة 36 — صيغة ISSUE مع Root Cause والحالة

## P0 — الأمن / سلامة البيانات / المال / Core Flow مكسور

| ID | العنوان | الجذر | الإصلاح | الحالة |
|---|---|---|---|---|
| WALLET-001 | حركات المحفظة بلا AuditLog (مخالفة المرحلة 24) | wallet-service لا يستدعي أي audit | logMoneyAudit داخل wallet-service لكل عملية دفع/سحب/شحن/رفض | **مُصلح ✓** |
| JOB-002 | ApplicationStageChange بدون jobId عند سحب المتقدم للحقل الإلزامي | withdrawApplication ينشئ السجل حرفياً دون الحقل | تمرير application.jobId من الاستعلام | **مُصلح ✓** |
| OFFER-001 | offer.companyId = undefined عند إنشاء Employee بعد القبول | select في acceptOffer نسي companyId | أضيف companyId إلى select | **مُصلح ✓** |

## P1 — تكامل حرج

| ID | العنوان | الحالة |
|---|---|---|
| NOTIF-001 | إشعار دعوة المرشح بنوع غير موجود في enum (JOB_INVITATION) فلا يُحفظ | **مُصلح ✓** (استبدال بـ JOB_OPPORTUNITY + data JSON) |
| ANALYTICS-001 | لا أحداث تحليلات server-side نهائياً (PAYMENT/JOB_APPLIED/CV_SEARCHED...) | **مُصلح ✓** عبر src/lib/analytics-server.ts trackServerEvent |
| REGISTER-001 | التسجيل لا يولد إشعار ترحيب ولا USER_REGISTERED | **مُصلح ✓** |

## P2 — تناقض UX/Backend

| ID | العنوان | الحالة |
|---|---|---|
| TS-083 | 83 خطأ TypeScript تحجب `tsc --noEmit` (ui-v2 مزدوج التصدير، JobCreationForm نموذج بلا حقول، typos...) | **مُصلح ✓ → 0 خطأ** |
| SKILL-001 | typo `skilles` يجعل مهارات الطلب صفراً دائماً في skill-demand + نموذج خاطئ db.skill | **مُصلح ✓** |
| TALENT-001 | talent-map يستعلم عن User.province غير الموجود (العمود location) | **مُصلح ✓** |
| ACADEMY-001 | صفحتا learning/paths,certificates تمرران initialTab لكن AcademyView لا يقبل Props | **مُصلح ✓** |
| INV-001 | زر مشاركة فرصة استثمار يستخدم opp.summary غير الموجودة | **مُصلح ✓** (description) |
| BTN-DEAD-001 | شاريت الشظara InvestmentBank Share بلا onClick سابقاً | سبق إصلاحه، تحقق المرحلة 46 ✓ |

## P3 — تنظيف وتحسين
- توحيد مفاتيح الفهارس البعيدة لمسارات 428 API (موصى به لاحقاً)
- بعض مسارات admin تعمل مباشرة على prisma دون service layer (قاعدة المرحلة 47) — مراجعة تدريجية
- `form`} dummy refs لم تعد موجودة؛ mockData المرصودة داخل __tests__ فقط (مشروعية)

## P4 — Nice to have
- إضافة AnalyticsEvent retention/cron للتجميع الزمني
- توسيع CHANGE_LOG أوتوماتيكياً من ApplicationStageChange
