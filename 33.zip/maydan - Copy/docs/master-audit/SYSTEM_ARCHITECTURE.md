# SYSTEM_ARCHITECTURE.md

> المرحلة 40/المرحلة 8 — خريطة الدومينات.

## طبقات التنفيذ

```
UI (124 صفحة + 250 مكوّن)
 ↓ fetch/api-client
API Routes (428 مساراً / 645 دالة)
 ↓ requireAuth + صلاحيات
Services (22 خدمة في src/services)
 ↓ Prisma 6
PostgreSQL (260 نموذجاً) + Redis (كاش/طوابير)
 ↓
محركات عرضية: sendNotification (async-queue) • trackEvent (AnalyticsEvent) • logAudit (AuditLog مُسلسل)
```

## Domains → المصادر

| الدومين | أمثلة API | خدمات |
|---|---|---|
| Identity/Auth | /api/auth, /api/users | User Session Profile |
| Social | /api/follows, /api/connections | /api/posts /api/comments /api/likes |
| Content | /api/articles, /api/discussions | /api/questions /api/polls /api/tags |
| Jobs | /api/jobs, /api/candidate | job.service, job-application.service, offer.service, interview.service |
| Companies | /api/companies, /api/company- | company.service |
| Experts | /api/expert, /api/consultations | consultation-marketplace.service |
| Marketplace | /api/marketplace | lib/marketplace |
| Learning | /api/academy, /api/learn | courses quizzes certificates |
| Wallet/Payments | /api/wallet, /api/finance | wallet-service, payment.service |
| Subscriptions | /api/subscriptions, /api/premium | premium.service config |
| Notifications | /api/notifications | async-queue notification |
| Moderation | /api/admin/moderation | moderation-ai, report.service |
| Administration | /api/admin, /api/owner | owner-panel |
