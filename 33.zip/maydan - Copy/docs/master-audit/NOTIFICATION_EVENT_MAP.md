# NOTIFICATION_EVENT_MAP.md

> المرحلة 22 — مصدر واحد: sendNotification() في src/lib/async-queue.ts (طابور Redis أو داخل العملية ثم db.notification.createMany) + SSE signal.

| الحدث (type) | المنبعث من | الطرف المستلم | القناة |
|---|---|---|---|
| `JOB_APPLICATION_RECEIVED` | job-application.service.applyToJob | المتقدم + ناشر الوظيفة | In-App+Email |
| `JOB_APPLICATION_REVIEWED/SHORTLISTED/INTERVIEW/OFFERED/HIRED/REJECTED` | changePipelineStage | المتقدم | In-App (+Email/WhatsApp للحالات) |
| `FOLLOW` | POST /api/follows | المتابَع | In-App+Email |
| `CONNECTION*` | connections/route.ts | الطرف الثاني | In-App |
| `LIKE / COMMENT / DISCUSSION_REPLY / MENTION` | likes, comments, discussion.service mentions-system | صاحب المحتوى | In-App(+Email تعليق) |
| `CV_BANK_CANDIDATE_FOUND` | cv-bank.service.searchCandidates | الباحث (شركة) | In-App |
| `MARKETPLACE_ORDER*، MARKETPLACE_OFFER*` | lib/marketplace.notifyMarketplace + orders APIs | مشترٍ/بائع | In-App |
| `WALLET_TOPUP_APPROVED/REJECTED` | finance/topup-requests/:id | صاحب المحفظة | In-App+SSE+WhatsApp |
| `WALLET_WITHDRAWAL_APPROVED/REJECTED` | finance/withdrawals/:id | صاحب الطلب | In-App+SSE |
| `CONSULTATION_REQUEST/REMINDER/SESSION_OPEN` | consultations/book + reminder-service | خبير ومستخدم | In-App+Email |
| `USER_REGISTERED (ترحيب)` | auth/register (جديد) | المستخدم الجديد | In-App |
| `ARTICLE_PUBLISHED / EVENT_REMINDER / REPUTATION_CHANGE / SYSTEM` | broadcast admin + أنظمة ذات صلة | متعدد | In-App+Bulk |

> مزلاجات الانتقال (Enum): NotificationType فيه 41 قيمة؛ تنبيه: JOB_INVITATION لم تكن ضمن enum وتسببت في إخفاق حفظ إشعار الدعوات — أُستبدل بـ JOB_OPPORTUNITY مع تخزين الرابط داخل data.