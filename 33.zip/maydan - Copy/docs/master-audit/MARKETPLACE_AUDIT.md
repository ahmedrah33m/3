# MARKETPLACE_AUDIT — تدقيق دومين

> MASTER PROMPT — التسليم رقم 10+

## نتائج الفحص

- Flow كامل: Store/Product/Service → Order POST (تحقق ملكية، كميات، كوبون بقواعد زمنية وحد استخدام) → دفع محفظة فوري أو COD → إشعار بائع → عدادات مبيعات.
- إلغاء تلقائي للطلب إذا فشل الخصم (status CANCELLED) — لا طلبات مدفوعة جزئياً.
- الدفع مضبوط بمفتاح idempotency مركب marketplace-order:{orderId}.
- أحداث ORDER_CREATED الآن server-side (جديد) وتحويل الطلب إلى COMPLETED يصدر MARKETPLACE_ORDER_COMPLETED عند اكتمال الطلب في put/sold flows.