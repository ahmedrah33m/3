# PROJECT_INVENTORY.md — جرد شامل لمنصة ميدان

> مولّد آلياً من سكربتات التدقيق (2026-08-26) — MASTER PROMPT المرحلة 1

---

# 1) تقنيات النظام

| المكوّن | القيمة |
|---|---|
| Framework | Next.js (App Router) + React 19 |
| TypeScript | نعم (tsconfig strict paths @/) |
| ORM | Prisma 6.19.2 (PostgreSQL adapter pg) |
| Database | PostgreSQL (+Redis اختياري للكاش والطوابير) |
| Authentication | JWT مخصص (lib/auth.ts) + كوكيز HttpOnly + blacklist توكنز |
| Authorization | أدوار USER/EXPERT/MODERATOR/ADMIN/OWNER + permission-engine-enhanced |
| Storage | AWS S3 SDK (presigned URLs) |
| Payments | محفظة موحدة IQD + قنوات QI/ZainCash/FastPay/Bank (تحقق يدوي مالي) |
| Notifications | طابور داخل العملية + Redis queue + SSE signals + Email + WhatsApp |
| Realtime | WebSocket منفصل (examples/websocket) + publishNotificationSignal |
| Caching | cache-service + cache-helpers + Redis idempotency |
| AI | lib/ai + moderation-ai.service (توليد، إشراف، مطابقة) |
| Analytics | AnalyticsEvent (DB) + trackEvent API + dashboards |
| Cron/Jobs | jobs-worker.ts + async-queue timers |
| Testing | Vitest — 19 ملف اختبار، 254 اختبار ✓ |

---

# 2) إحصاءات الكود

| العنصر | العدد |
|---|---|
| الصفحات (page.tsx) | 124 |
| ملفات مسارات API (route.ts) | 428 |
| مجموع دوال HTTP المعروضة | 645 |
| مكوّنات React (tsx) | ~250 |
| ملفات lib | 181 |
| خدمات الخدمات (services/) | 22 خدمة |
| نماذج Prisma | 260 |
| Enum بـ Prisma | 22 |
| أسطر الأزرار/onClick المكتشفة | 2119 |
| النماذج <form> التقليدية | 17 |

---

# 3) بنية المجلدات

- `src/app (الصفحات وAPI)`
- `src/components`
- `src/lib`
- `src/services`
- `src/repositories`
- `src/hooks`
- `src/types`
- `prisma (schema + migrations + seeds)`
- `docs`
- `scripts`

---

# 4) ENV المتغيرات الحرجة

`DATABASE_URL`, `REDIS_URL` (اختياري), `JWT_SECRET`, S3 credentials, SMTP, WebSocket port — التفاصيل الكاملة في `.env.example`
