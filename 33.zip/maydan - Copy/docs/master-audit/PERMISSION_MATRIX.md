# PERMISSION_MATRIX.md

> المرحلة 10 — الأدوار: USER, EXPERT, MODERATOR, ADMIN, OWNER (+ أدوار شركة تطبيقية عبر Company Users).

| المنطقة | USER | EXPERT | MODERATOR | ADMIN | OWNER | آلية الحماية |
|---|---|---|---|---|---|---|
| تسجيل/دخول/تحقق هاتف/بريد | ✓ | ✓ | ✓ | ✓ | ✓ | rate-limit + codes |
| تقديم وظيفة | ✓ | ✓ | ✓ | ✓ | ✓ | ownership للسحب |
| نشر وظيفة مدفوعة | اشتراك/رصيد | — | — | — | ✓ | ServicePrice + محفظة |
| مراجعة الح Valance المالية (سحب/شحن) | ✗ | ✗ | FINANCE_ROLES | ✓ | ✓ | requireFinanceRole()
| تغيير الأدوار | ✗ | ✗ | ✗ | ADMIN فقط (لا OWNER→) | ✓ | requireOwnerOrAdmin + blacklist sessions |
| إشراف المحتوى (حظر/حذف/flag) | ✗ | ✗ | ✓ | ✓ | ✓ | logAudit لكل إجراء (43 موقعاً) |
| OwnerPanel (أسعار/عمولة/مالية) | ✗ | ✗ | ✗ | محدود | ✓ | session role check |
| إنشاء شركة | مرة واحدة | مرة واحدة | ✗ | ✗ | ✗ | unique ownerId |

- فحوص الصلاحيات مركزية في lib/session + permission-engine-enhanced; AuditLog مُسلسَل hash-chain في lib/security/audit-trail (verifyAuditChain).
