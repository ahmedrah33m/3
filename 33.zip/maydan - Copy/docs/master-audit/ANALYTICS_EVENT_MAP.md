# ANALYTICS_EVENT_MAP.md

> المرحلة 25 — التخزين AnalyticsEvent (eventType, userId, category, payload Json) والاستعلام عبر GET /api/analytics/events ولوحات الداشبورد.

## Client-side ingestion
`POST /api/analytics/events` (Zod: AnalyticsEventSchema) — يلتقط أحداث الواجهة (مشاهدات صفحات، تفاعلات) بأمان مع IP+UA.

## Server-side emission (trackServerEvent — جديد هذه الجلسة)

| الحدث | الموضع | المعنى التجاري |
|---|---|---|
| PAYMENT_COMPLETED / PAYMENT_FAILED | wallet-service.payFromWallet | كل عملية دفع/رسوم على المنصة (عمولة، مزود، فاتورة) |
| WITHDRAWAL_REQUESTED / _APPROVED / _REJECTED | createWithdrawalRequest / approve/rejectWithdrawal | سلوك السيولة والموافقات المالية |
| WALLET_TOPUP_APPROVED | approveTopUp | نمو الإيداعات المعتمدة |
| JOB_APPLIED | applyToJob | حجم الطلب على الوظائف وجودة المطابقة |
| CV_SEARCHED | cv-bank.searchCandidates | استهلاك الاشتراكات المدفوعة |
| MARKETPLACE_ORDER_CREATED | orders POST | حجم سوق ميدان |
| USER_REGISTERED | auth/register | النمو العضوي ونوع الحساب |

```
AnalyticsEvent ── Aggregation (analytics.service.getDashboardStats/getChartData) ── Dashboards (Owner/Admin/Analytics pages)
```
