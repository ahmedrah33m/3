# JOB_SYSTEM_AUDIT — تدقيق دومين

> MASTER PROMPT — التسليم رقم 10+

## نتائج الفحص

- دورة الطلب: RECEIVED → SCREENING → SHORTLISTED → INTERVIEW → OFFERED → HIRED (+ WITHDRAWN/REJECTED) مدعومة بـ PIPELINE_STAGES.
- كل انتقال يمرّ changePipelineStage: ApplicationStageChange + إشعار للمتقدم + بريد/واتساب اختياري.
- applyToJob: matchScore يحسب ويخزن + Snapshot للسيرة + إشعار مزدوج + JOB_APPLIED analytics (جديد).
- **إصلاح P0 (هذه الجلسة):** withdrawApplication كان ينشئ ApplicationStageChange بدون jobId الحقل الإلزامي ← كان يسقط بصمت؛ أضيف application.jobId.
- Offers: acceptOffer يستدعي changePipelineStage(HIRED) بدل الكتابة المباشرة (JOB-001 FIX).
- **إصلاح P1 (هذه الجلسة):** acceptOffer select لم يتضمن companyId رغم استخدامه في إنشاء Employee.