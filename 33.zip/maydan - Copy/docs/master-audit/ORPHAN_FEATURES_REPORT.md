# ORPHAN_FEATURES_REPORT.md

> المرحلة 28/44 — الشذرات والأزرار الميتة (آلي ثم تحقق يدوي)

## ملاحظات منهجية
مستخدم الواجهة يكتشف عبر البحث عن أي `/api/...` في الكود غير الخاص بـ app/api. المسارات المستخدمة كسيرفر-تو-سيرفر أو cron قد تظهر "غير مستخدمة" ظاهرياً — راجع عمود FRONTEND_CONSUMERS في API_DEPENDENCY_MATRIX.csv قبل أي حذف (قاعدة SEARCH→TRACE→CONFIRM→DOCUMENT→DELETE).

### A. TODO/FIXME (1)
- src/app/api/push/send/route.ts:36 — `// TODO: For production with encrypted payloads, install `web-push` npm package`

### B. Coming Soon (4)
- src/components/CoursePlayer.tsx:268 — `{locale === 'ar' ? 'النقاش قريباً' : 'Discussion coming soon'}`
- src/components/ExpertMarketplaceView.tsx:1158 — `{em.noServices || 'Portfolio coming soon'}`
- src/components/ExpertMarketplaceView.tsx:1165 — `{em.noServices || 'Articles coming soon'}`
- src/lib/locales/en.ts:107 — `comingSoon: 'Coming soon',`

### C. Mock/Dummy المراجع (70) — أغلبها أكواد اختبار أو تعليقات؛ أهم 15:
- src/__tests__/api-client.test.ts:9
- src/__tests__/api-client.test.ts:108
- src/__tests__/api-client.test.ts:118
- src/__tests__/api-routes.test.ts:10
- src/__tests__/api-routes.test.ts:50
- src/__tests__/api-routes.test.ts:51
- src/__tests__/api-routes.test.ts:69
- src/__tests__/api-routes.test.ts:70
- src/__tests__/api-routes.test.ts:84
- src/__tests__/api-routes.test.ts:85
- src/__tests__/api-routes.test.ts:89
- src/__tests__/api-routes.test.ts:93
- src/__tests__/api-routes.test.ts:100
- src/__tests__/api-routes.test.ts:107
- src/__tests__/api-routes.test.ts:112

### D. Endpoints بدون مستهلك واجهة مكتشف (184/428)

الأبرز:

| Endpoint | طرق | Auth | صناعة المحتوى داخلياً؟ |
|---|---|---|---|
| /api/academy/certificates/verify | GET | لا | ? |
| /api/academy/courses/create | POST | لا | ? |
| /api/academy/courses | GET | لا | ? |
| /api/academy/seed | POST | لا | ? |
| /api/achievements/:id | GET | لا | ? |
| /api/achievements/seed | POST | نعم | ? |
| /api/admin/ai-logs | GET | لا | ? |
| /api/admin/analytics | GET | لا | ? |
| /api/admin/audit-log | GET | لا | ? |
| /api/admin/auto-publish/retry | GET,POST | لا | ? |
| /api/admin/capacity | GET | لا | ? |
| /api/admin/comments/:id | DELETE | لا | ? |
| /api/admin/encryption-status | GET | لا | ? |
| /api/admin/errors | GET,POST,PATCH | لا | ? |
| /api/admin/export | GET | لا | ? |
| /api/admin/reports | GET,PATCH | لا | ? |
| /api/admin/scrape/history | GET | لا | ? |
| /api/admin/scrape/telegram/channels/:id | PATCH,DELETE | لا | ? |
| /api/admin/smtp | GET,POST | لا | ? |
| /api/admin/system-health | GET | لا | ? |
| /api/advertiser | GET,POST | نعم | ? |
| /api/ai/analyze | POST | نعم | ? |
| /api/ai/bulk-analyze | POST | نعم | ? |
| /api/ai/moderate | POST | نعم | ? |
| /api/ai/sentiment | POST | نعم | ? |
| /api/ai/summary | POST | نعم | ? |
| /api/analytics/dashboard | GET | لا | ? |
| /api/analytics/events | GET,POST | لا | ? |
| /api/analytics/stats | GET | لا | ? |
| /api/analytics/track | POST | لا | ? |
| /api/articles/:id/rate | GET,POST | لا | ? |
| /api/articles/promote | POST | لا | ? |
| /api/auth/change-email | POST | نعم | ? |
| /api/auth/change-password | POST | نعم | ? |
| /api/auth/check-blacklist | GET | لا | ? |
| /api/auth/confirm-email-change | GET,POST | لا | ? |
| /api/auth/confirm-phone | POST | نعم | ? |
| /api/auth/google/callback | GET | لا | ? |
| /api/auth/send-phone-code | POST | نعم | ? |
| /api/auth/send-verification | POST | لا | ? |

... والقائمة الكاملة في CSV.
