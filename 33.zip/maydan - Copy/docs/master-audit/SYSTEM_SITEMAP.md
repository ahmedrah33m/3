# SYSTEM_SITEMAP.md — خريطة صفحات ميدان

> الآلي — المرحلة 2. التصنيف المستنتج من المسار والصلاحيات.

## /academy (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/academy` | Client | - | AUTHENTICATED |

## /achievements (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/achievements` | Server | - | AUTHENTICATED |

## /admin (17 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/admin` | Client | - | ADMIN |
| `/admin/ads` | Server | - | ADMIN |
| `/admin/analytics` | Server | - | ADMIN |
| `/admin/audit-logs` | Server | - | ADMIN |
| `/admin/auto-publish` | Server | - | ADMIN |
| `/admin/companies` | Server | - | ADMIN |
| `/admin/consultations` | Server | - | ADMIN |
| `/admin/content` | Server | - | ADMIN |
| `/admin/experts` | Server | - | ADMIN |
| `/admin/finance` | Server | - | ADMIN |
| `/admin/jobs` | Server | - | ADMIN |
| `/admin/marketplace` | Server | - | ADMIN |
| `/admin/moderation` | Server | - | ADMIN |
| `/admin/scrape` | Server | - | ADMIN |
| `/admin/security` | Server | - | ADMIN |
| `/admin/settings` | Server | - | ADMIN |
| `/admin/users` | Server | - | ADMIN |

## /ai-assistant (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/ai-assistant` | Client | - | AUTHENTICATED |

## /analytics (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/analytics` | Client | - | AUTHENTICATED |

## /articles (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/articles` | Client | - | AUTHENTICATED |
| `/articles/:id` | Client | - | AUTHENTICATED |

## /bookmarks (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/bookmarks` | Client | - | AUTHENTICATED |

## /chat-rooms (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/chat-rooms` | Client | - | AUTHENTICATED |

## /communities (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/communities` | Client | - | AUTHENTICATED |
| `/communities/:id` | Client | - | owner, admin, moderator |

## /companies (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/companies` | Client | - | AUTHENTICATED |
| `/companies/:id` | Client | - | AUTHENTICATED |

## /company (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/company/register` | Client | - | COMPANY |

## /company-dashboard (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/company-dashboard` | Client | - | COMPANY |

## /connections (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/connections` | Client | - | AUTHENTICATED |

## /consultant-dashboard (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/consultant-dashboard` | Client | - | EXPERT |

## /consultations (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/consultations` | Server | - | AUTHENTICATED |

## /control-center (5 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/control-center` | Server | - | OWNER, ADMIN |
| `/control-center/branches` | Server | - | OWNER, ADMIN |
| `/control-center/employees` | Server | - | OWNER, ADMIN |
| `/control-center/organization` | Server | - | OWNER, ADMIN |
| `/control-center/system` | Server | - | OWNER, ADMIN |

## /create-post (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/create-post` | Client | - | AUTHENTICATED |

## /cv-builder (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/cv-builder` | Client | - | AUTHENTICATED |

## /dashboard (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/dashboard` | Client | - | AUTHENTICATED |

## /dictionary (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/dictionary` | Client | - | AUTHENTICATED |

## /discussions (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/discussions` | Client | - | AUTHENTICATED |
| `/discussions/:id` | Client | - | AUTHENTICATED |

## /economy (7 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/economy/ai-assistant` | Client | - | AUTHENTICATED |
| `/economy/calendar` | Client | - | AUTHENTICATED |
| `/economy/charts` | Client | - | AUTHENTICATED |
| `/economy/converter` | Client | - | AUTHENTICATED |
| `/economy/indicators` | Client | - | AUTHENTICATED |
| `/economy/map` | Client | - | AUTHENTICATED |
| `/economy/market` | Client | - | AUTHENTICATED |

## /events (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/events` | Server | - | AUTHENTICATED |

## /expert-market (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/expert-market` | Client | - | AUTHENTICATED |

## /experts (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/experts` | Client | - | AUTHENTICATED |

## /finance (3 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/finance` | Client | - | OWNER, ADMIN |
| `/finance/invoices` | Client | - | OWNER, ADMIN |
| `/finance/transactions` | Client | - | OWNER, ADMIN |

## /investment (3 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/investment/investors` | Client | - | AUTHENTICATED |
| `/investment/opportunities` | Client | - | AUTHENTICATED |
| `/investment/partnerships` | Client | - | AUTHENTICATED |

## /investment-bank (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/investment-bank` | Client | - | AUTHENTICATED |

## /jobs (18 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/jobs` | Client | - | AUTHENTICATED |
| `/jobs/:id` | Client | - | AUTHENTICATED |
| `/jobs/candidate/applied` | Client | - | AUTHENTICATED |
| `/jobs/candidate/interviews` | Client | - | AUTHENTICATED |
| `/jobs/candidate/offers` | Client | - | AUTHENTICATED |
| `/jobs/candidate/profile` | Client | - | AUTHENTICATED |
| `/jobs/candidate/resume` | Client | - | AUTHENTICATED |
| `/jobs/candidate/saved` | Client | - | AUTHENTICATED |
| `/jobs/cv-bank` | Client | - | AUTHENTICATED |
| `/jobs/dashboard` | Client | - | AUTHENTICATED |
| `/jobs/employer` | Client | - | AUTHENTICATED |
| `/jobs/employer/applicants` | Client | - | AUTHENTICATED |
| `/jobs/employer/applicants/:jobId/kanban` | Client | - | AUTHENTICATED |
| `/jobs/employer/interviews` | Client | - | AUTHENTICATED |
| `/jobs/employer/jobs` | Client | - | AUTHENTICATED |
| `/jobs/employer/reports` | Client | - | AUTHENTICATED |
| `/jobs/employer/settings` | Client | - | AUTHENTICATED |
| `/jobs/new` | Client | - | AUTHENTICATED |

## /leaderboard (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/leaderboard` | Client | - | AUTHENTICATED |

## /learn (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/learn` | Client | - | AUTHENTICATED |

## /learning (6 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/learning` | Client | - | AUTHENTICATED |
| `/learning/:id` | Client | - | AUTHENTICATED |
| `/learning/certificates` | Client | - | AUTHENTICATED |
| `/learning/dictionary` | Client | - | AUTHENTICATED |
| `/learning/paths` | Client | - | AUTHENTICATED |
| `/learning/quizzes` | Client | - | AUTHENTICATED |

## /marketplace (14 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/marketplace` | Client | - | AUTHENTICATED |
| `/marketplace/admin` | Client | - | AUTHENTICATED |
| `/marketplace/dashboard` | Client | - | AUTHENTICATED |
| `/marketplace/products` | Client | - | AUTHENTICATED |
| `/marketplace/products/:id` | Server | - | AUTHENTICATED |
| `/marketplace/providers` | Client | - | AUTHENTICATED |
| `/marketplace/providers/:id` | Server | - | AUTHENTICATED |
| `/marketplace/requests` | Client | - | AUTHENTICATED |
| `/marketplace/requests/:id` | Server | - | AUTHENTICATED |
| `/marketplace/requests/new` | Client | - | AUTHENTICATED |
| `/marketplace/services` | Client | - | AUTHENTICATED |
| `/marketplace/services/:id` | Server | - | AUTHENTICATED |
| `/marketplace/stores` | Client | - | AUTHENTICATED |
| `/marketplace/stores/:id` | Server | - | AUTHENTICATED |

## /messages (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/messages` | Client | - | AUTHENTICATED |

## /notifications (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/notifications` | Client | - | AUTHENTICATED |

## /owner (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/owner` | Client | - | OWNER |

## /owner-panel (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/owner-panel` | Client | - | OWNER |

## /polls (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/polls` | Server | - | AUTHENTICATED |

## /premium (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/premium` | Client | - | AUTHENTICATED |

## /profile (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/profile/:id` | Client | - | AUTHENTICATED |
| `/profile/me` | Server | - | AUTHENTICATED |

## /questions (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/questions` | Server | - | AUTHENTICATED |
| `/questions/:id` | Server | - | AUTHENTICATED |

## /quizzes (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/quizzes` | Client | - | AUTHENTICATED |
| `/quizzes/:id` | Client | - | AUTHENTICATED |

## /research (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/research` | Client | - | AUTHENTICATED |

## /search (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/search` | Client | - | AUTHENTICATED |

## /tags (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/tags/:tag` | Server | - | AUTHENTICATED |

## /verify-certificate (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/verify-certificate` | Client | - | PUBLIC |

## /wallet (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/wallet` | Client | - | AUTHENTICATED |

## /write (2 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/write` | Client | - | AUTHENTICATED |
| `/write/:id` | Server | - | AUTHENTICATED |

## /login (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/login` | Client | - | PUBLIC |

## /(root) (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/` | Client | - | PUBLIC |

## /register (1 صفحة)

| Route | نوع التصيير | حماية | أدوار مرصودة |
|---|---|---|---|
| `/register` | Client | - | PUBLIC |
