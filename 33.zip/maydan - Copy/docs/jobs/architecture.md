# Midan Jobs 2.0 — Architecture

> PHASE 3 of the master-prompt sequence (§271). Based on the Phase 1 audit and the approved `MIDAN_JOBS_GAP_ANALYSIS.md`.
> Principle: **Extend Existing, not Replace Everything** (§2).

## 1. Approved architectural decisions

| # | Decision | Rationale |
| -- | -------- | --------- |
| D1 | **Messaging**: unify candidate↔employer messaging on `ChatRoom`/`ChatRoomMessage` (Socket.IO real-time path). Deprecate legacy `Message` for job conversations; resolve orphaned `Conversation`/`ConversationParticipant` addendum models (FK them or remove from addendum schema). | One live real-time channel; avoid triple state; keep legacy Message usable for non-job chat during migration. |
| D2 | **Professional Profile store**: build on the CVBuilder `CVData` JSON struct (`user.resumeData`) + `CvVersion` as the normalized store. Additive searchable tables only where matching/talent-search needs them (skills). No new `professional_profiles` relational rewrite. | Reuse existing CVBuilder (1,648 lines) and CvVersion models; profile fills matching/Talent Directory/ATS. |
| D3 | **Company identity**: migrate jobs to the newer `Company` entity — add nullable `Job.companyId` FK, backfill from `publishedBy`, keep `publishedBy` working for legacy; a single `getJobCompany()` helper reads either path. | Removes the User/Company split; preserves live jobs. |
| D4 | **Search**: Prisma-first (taxonomy + normalized columns + Arabic `normalizeArabic`), no hosted search index in this cycle; revisit (Meilisearch/Typesense) only if data volume demands (§88). | Cost/ops constraints; existing `search-engine.ts` normalization reused. |

## 2. Architecture layers

```
UI (components/(main)/jobs, CompanyDashboard, new /talent, /profile/[username], /company/[slug], NotificationCenter)
  ⇅  client fetch /api/*
API routes (src/app/api/**) — auth via src/lib/session (requireAuth/requireAdmin), zod schemas, api-utils responses
  ⇅
Services (src/services/*.service.ts) — single owner of business rules + Prisma access; new: matching, alert, salary, labor-market, verification, tracker, message-unifier
  ⇅
Repository/data access: Prisma client (src/lib/db.ts), ai-cache.ts, cache-service.ts
  ⇅
Data: PostgreSQL (pgbouncer) + Redis (bullmq queues) + MinIO/S3 files
```

- Business rules live in `src/services/*.service.ts`; route handlers stay thin (try/catch + `handleApiError`).
- New domain services:
  - `src/services/jobs/taxonomy.service.ts` — structured dictionary (roles/skills/categories) resolution
  - `src/services/matching.service.ts` — hybrid match (rule→taxonomy→semantic→weighted) with explanation
  - `src/services/alert.service.ts` — JobAlert scheduling + delivery (email/in-app/push/Telegram)
  - `src/services/salary.service.ts` — SalaryRecord/Aggregate ingestion + percentiles
  - `src/services/labor-market.service.ts` — snapshots + demand aggregates
  - `src/services/verification.service.ts` — job/company verification levels + scam risk flags
  - `src/services/tracker.service.ts` — application tracker + analytics for user
  - `src/services/conversation.service.ts` — ChatRoom-based candidate↔employer DMs (D1)
- Constants/taxonomy in `src/lib/jobs/taxonomy.ts` (single source, no per-component duplication).

## 3. Schema evolution (migrations M1→M5, additive, raw-SQL on server)

| Mig | Models / fields | Purpose |
| --- | --------------- | ------- |
| M1 | `Skill`, `SkillAlias`, `JobCategory`, `Role` + structured `Job` columns (workMode, salaryPeriod, experienceYearsMin/Max, normalizedTitle, roleSlug, subcategory, applicationMethod, allowedCountries/Cities, timezoneRequirements, workAuthorization, verificationStatus, lastVerifiedAt, isSponsored) + indexes | Taxonomy backbone + structured job object (§12) — **this phase** |
| M2 | `JobSkill`, `JobLocation`, `JobBenefit`, `JobLanguage` join tables (+ optional `JobQuestion` ref) seeded from existing Json | Normalized job facts for matching/search (§12, §104) |
| M3 | `Job.companyId` FK + backfill from `publishedBy`; add FKs on `Interview`/`Offer` → `JobApplication` (nullable, backfilled) | Identity unification (D3) |
| M4 | `JobAlert`, `JobView`, `SalaryRecord`, `SalaryAggregate`, `LaborMarketSnapshot`, `JobReport`, `JobVerificationCase`, `OutboundClick`, `CvParsingJob` | Alerts + analytics + intelligence (§80–84, §104) |
| M5 | Talent-facing: profile search indexes, candidate visibility/privacy, invitation/outreach limits | Talent Directory (D2) |

- Every migration: generated via `prisma migrate diff` (datamodel→datamodel, offline), applied locally/verify, then applied as raw SQL on server (no `_prisma_migrations` table). Never `migrate reset`. Existing server DB drift (payroll/live/HR) is out of scope and tracked separately.

## 4. Feature flags (§260, §261)

`src/lib/feature-flags.ts` — all Jobs 2.0 flags default off except core jobs internals:

```
FEATURE_STRUCTURED_JOBS  (M1 live-read of new columns; harmless) = on
FEATURE_JOBS_ADVANCED_FILTERS                                   = off
FEATURE_TALENT_DIRECTORY                                        = off
FEATURE_AI_MATCHING                                             = off
FEATURE_ATS                                                     = off (screening already exists; gates new ATS UI)
FEATURE_SALARY_INSIGHTS                                         = off
FEATURE_AI_INTERVIEW                                            = off
FEATURE_JOB_ALERTS                                              = off
FEATURE_VERIFICATION_ENGINE                                     = off
```
Client availability exposed via `NEXT_PUBLIC_FEATURE_*`.

## 5. API layout (follows existing conventions §165)

- Keep `/api/jobs`, `/api/jobs/[id]`, `/jobs/[id]/apply|pipeline|screen` intact.
- New (phase-appropriate):
  - `/api/jobs/search` (advanced), `/api/jobs/recommendations`, `/api/jobs/[id]/report`
  - `/api/talent` + `/api/talent/search`, `/api/talent/[id]/invite`
  - `/api/profile` (public/[username]), `/api/profile/skills`
  - `/api/alerts`, `/api/salary`, `/api/labor-market`
  - `/api/employer/ats`, `/api/employer/company`
- All new endpoints: `requireAuth`/role guards, zod validation, `api-utils` responses, service calls, IDOR-safe ownership checks.

## 6. Cross-cutting

- **Auth/RBAC**: `src/lib/session.ts` guards + middleware prefixes; new pages registered in `PROTECTED_PAGE_PREFIXES` / `ADMIN_PAGE_PREFIXES` as needed.
- **RTL / i18n**: Arabic-first everywhere; corpus uses Arabic strings + ICU-style bilingual labels in taxonomy lib.
- **Events**: BullMQ queues (exists) for alerts, market snapshots, salary aggregation, freshness; notification engine reused (web-push + Socket.IO).
- **AI**: `src/services/ai.service.ts` + `ai-cache.ts`; AI assist only, never source of truth, never user-facing system prompts; no protected attributes in matching (§110–112).
- **Testing**: vitest suites in `src/__tests__/`; matching A–D test cases (§251), Arabic search tests (§254), fraud tests (§253); keep existing 22 files green.
- **Deploy**: reuse feasibility pipeline (7-Zip tar; prisma diff; raw SQL; image rebuild); per-phase run report per §269.

## 7. Data dictionary (started — §155)

| Entity | Source of truth | Estimated (derived) |
| ------ | --------------- | ------------------- |
| Job title / normalization | `Job.normalizedTitle` + `Role` | synonyms in `Role.aliases` |
| Skills on job | `Job.skillsRequired` (Json) → M2 `JobSkill` | skill id + level |
| Salary | `Job.salaryMin/Max` (+ `salaryPeriod`, currency) | `SalaryAggregate` (percentiles w/ sample) |
| Candidate skills | `user.resumeData.skills` + `SkillGraph` | verification flags |
| Governorates | `src/lib/job-provinces.ts` (canonical 19) | aliases map |
| Job status | `Job.lifecycle` + `isExpired`/`expiresAt` | `verificationStatus`, freshness states |
| Company identity | `Company` (D3), legacy `job.publishedBy` → kept | `getJobCompany()` helper |

## 8. Known constraints / risks

- Jobs domain = live surface; zero delete of existing routes/fields.
- Denormalized `Job` Json fields stay readable as cache (write-through).
- Server DB drift (payroll/live/HR) — untouched by Jobs 2.0 migrations.
- Python/bsdtar deploy quirks handled by existing 7-Zip tooling.