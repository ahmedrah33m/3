# MIDAN FRONTEND AUDIT

> فحص Frontend شامل — قراءة فقط، دون أي تعديل على الكود.
> التاريخ: 2026-08-09 — النطاق: `src/` وملفات الإعداد.
> مصنف حسب الخطورة: 🔴 Critical · 🟠 High · 🟡 Medium · 🟢 Low

---

## الملخص التنفيذي

ميدان مبني على أساس سليم (Next.js 16 + React 19 + Tailwind v4 + shadcn-style + auth قوي خادمياً)، لكن الفحص كشف **3 ثغرات حماية في الواجهة**، و**انفجاراً في حجم المكونات**، و**نظام RTL معطوب جزئياً**، و**طبقة API client غير موحّدة**، و**بنية مزدوجة ([locale] vs (main))** تنتج صفحات ميتة وروتينغ ملتبساً.

| # | البند | الخطورة |
|---|---|---|
| 1 | تجاوز حماية الـ middleware عبر بادئة locale (`/ar/dashboard`, `/ar/admin`...) | 🔴 |
| 2 | صفحات إدارية بلا أي حماية (`/owner`, `/owner/pricing`, `/marketplace/admin`, `/marketplace/dashboard`) | 🔴 |
| 3 | RTL معطوب بصمت (اتجاهيات يدوية تفوق المنطقية + `border-${isRtl}` لا يُبنى في Tailwind) | 🔴 |
| 4 | تكرار ملفات متطابقة + أزواج أسماء مكررة + نسخ `.bak` داخل `src` | 🔴 |
| 5 | 86 مكوّناً فوق 400 سطر (أكبرها 2875) ودليل التقسيم غير مطبّق | 🔴 |
| 6 | لا طبقة API client موحّدة — 291 `fetch` مباشر بلا `handleError` مشترك | 🟠 |
| 7 | react-query كود ميت؛ zustand يخزّن server-state بلا إبطال | 🟠 |
| 8 | نظاما Auth متوازيان؛ نسخ `[locale]/auth/*` ميتة كلياً + `returnUrl` مهمل | 🟠 |
| 9 | 13+ صفحة employer/candidate بلا حماية على مستوى الصفحة (البيانات محمية بالـ API فقط) | 🟠 |
| 10 | الوصولية شبه غائبة (568 placeholder مقابل 57 aria-label) | 🟠 |
| 11 | أسرار إنتاج على القرص (`NEW-SECRETS.txt`, `.env`) + مصادقة PII في localStorage | 🟠 |
| 12 | لا اختبارات UI إطلاقاً؛ `src/__tests__` مستبعد من type-check | 🟠 |

**الإيجابيات** (لا تُهدم): auth خادمي محكم (HttpOnly cookie + JWT jose + 2FA + CSRF مزدوج + rate-limit)، Google OAuth بـ PKCE، كل `<img>` له `alt`، `dangerouslySetInnerHTML` معقّم بالكامل، روابط Sidebar/Navbar سليمة، Design System shadcn مع `cn()` و`@theme`.

---

## 1. Framework 🔴/🟢

- **المنصة**: Next.js `16.2.7` (App Router) + React `19` + TypeScript 5 + Tailwind CSS `4` (postcss) + Vitest 4 + Prisma 6.19.
- **Standalone output** + security headers (CSP صارم production، HSTS، nosniff) + image optimization (avif/webp, remotePatterns منضبطة) — 🟢.
- 🟡 **`tsconfig.json:13` — `noImplicitAny: false`** يُضعف صرامة TS رغم `strict: true`.
- 🟡 **`tsconfig.json:44-54` يستبعد من type-check**: `src/lib/security-middleware.ts` (ملف أمني!)، `src/lib/social/**`، `src/lib/features/**`، `src/__tests__/**`، `prisma/**`، و`COMPONENT_SPLITTING_GUIDE.ts`.

## 2. Architecture 🟠

- طبقات نظيفة على مستوى الخدمات (`services/repositories/lib`) — 🟢.
- لكن **الحد الفاصل UI/Logic مكسور في الواجهة**: 86 مكوّناً فوق 400 سطر تحوي منطق أعمال داخل العرض (أمثلة: `AuthModals.tsx:23-49` منطق تسجيل دخول + استدعاء store؛ `jobs/JobDetail.tsx` fetch + عرض في ملف واحد).
- `src/components/features/` **فارغ تماماً** — مساحة معدة لنقل المنطق من المكونات ولم تُستعمل. 🟡

## 3. Routing 🟠

- **109 صفحات**: 3 جذر + 91 في `(main)` + 15 في `[locale]`.
- **ازدواج بنية**: locale يُقشط في موضعين (`next.config.ts:158-165` rewrite + `src/middleware.ts:269-284` على مستوى Edge)؛ معظم صفحات `[locale]` **ميتة** لأن القشط يبتلعها (انظر §22).
- **ثغرة حرجة في ترتيب الـ middleware**: الـ `return` المبكر (سطر 282) يقشط locale قبل بلوغ فحص الجلسة/الدور (سطر 376)، والفحص يعمل على `pathname` الأصلي المسبوق بـ locale — فكل بادئات الحماية ~19 قابلة للتجاوز عبر `/ar/` أو `/en/`. تفصيل في §8.
- 🟡 `returnUrl` يُبنى في middleware لكن صفحة login تتجاهله وتعيد التوجيه إلى `/`.

## 4. Components 🟠

- **314 ملف `.tsx` + 10 `.ts`** (108,634 سطراً) تحت `src/components`.
- **54 مكوّن UI** في `src/components/ui/` (shadcn-style حول Radix) — 🟢 أساس جيد.
- **تكرارات**: انظر §21.
- **ملفات شبه ميتة**: ~19 مكوّناً لا يستوردها أحد، و`91/100` وحدة في `src/lib/features` بلا استخدام.

## 5. Pages 🟡

- 109 صفحة؛ غالبية صفحات `(main)` هي **Client Components تجلب بياناتها بـ useEffect** بدل Server Components / RSC data — ما يسبب waterfalls وSkeleton متكررة.
- أمثلة waterfall: `jobs/candidate/saved/page.tsx:403→421`، `connections/page.tsx:55→65`.
- `jobs/candidate/applied` يعرض "قريباً" (feature ناقصة). 🟡

## 6. State Management 🟠

- **zustand** (`src/lib/store.ts:233`): store واحد عام يجمع auth + server-state (articles/experts/discussions/notifications/messages) + UI state. تحديث يدوي بـ `setArticles/setExperts` **بلا إبطال/مزامنة** مع السيرفر → 🟠 stale.
- **react-query** (`@tanstack/react-query` + `src/lib/query-hooks.ts`) **معطّل كلياً**: لا `QueryClientProvider` في أي مكان، ولا مستورد واحد من `query-hooks`. كود ميت.
- 🟢 تحسين جيد: `checkAuth` (store.ts:241) يمنع إعادة الفحص خلال 60 ثانية.

## 7. API Integration 🟠

- 🔴 **لا طبقة موحّدة**: **291 استدعاء `fetch('/api/...')` مباشر** موزّعة على كامل src، كل مكوّن يعيد `data.error || t.errors...` يدوياً. `fetcher` الموحّد في `query-hooks.ts:32` غير مستخدم.
- 🟢 **CSRF ممتاز**: حقن تلقائي عبر `CsrfBootstrap` + `useCsrf`/`csrfFetch` في ~20 مكوّناً.
- 🟢 مساعدات السيرفر موحّدة في `src/lib/api-utils.ts` (success/error/validation/auth).
- 🟡 لا يوجد `handleError` عميل مشترك.

## 8. Authentication 🟢 / Authorization UI 🟠

- 🟢 **قوة خادمية**: جلسة HttpOnly cookie `maydan_session` (jose + scrypt)، 2FA بتدفق `tempToken` قصير، Google OAuth بـ PKCE، rate-limit، CSRF مزدوج. لا توكن في localStorage.
- 🟠 **ثغرة 1 — تجاوز middleware بالبادئة** (تفصيل §3):
  - `src/middleware.ts:273-284` (rewrite مبكر + `return`) + فحص على `pathname` الأصلي `:376`.
  - الصفحات المتأثرة (قابلة للتجاوز عبر `/ar/` أو `/en/`): `/dashboard`، `/admin` (+ scrape/auto-publish)، `/create-post`، `/write`, `/wallet`, `/bookmarks`, `/notifications`, `/messages`, `/settings`، `/owner-panel`, `/company-dashboard`, `/profile/*`, `/consultations`, `/chat-rooms`, `/cv-builder`, `/ai-assistant`, `/consultant-dashboard`, `/learning`.
  - **الأسوأ**: `/ar/settings` (صفحة `[locale]` بلا AuthGate إطلاقاً — تُعرض للجميع)، و`/ar/admin` و`/ar/owner-panel` (تجاوز فحص الدور خادمياً).
- 🟠 **ثغرة 2 — صفحات إدارية خارج الحماية كلياً**:
  - `src/app/(main)/owner/page.tsx:1-7` — يرسّم `<OwnerPanel/>` مباشرة؛ `/owner` **ليست** في `PROTECTED_PAGE_PREFIXES` ولا `ADMIN_PAGE_PREFIXES`.
  - `src/app/(main)/marketplace/admin/page.tsx:1-22` — بلا guard ولا middleware.
  - `src/app/(main)/marketplace/dashboard/page.tsx:1-22` — بلا guard.
  - `src/app/[locale]/owner/pricing/page.tsx` — بلا guard (مكشوفة عبر `/ar/owner/pricing`).
  - ملاحظة: **البيانات محمية بالـ API** (`requireAuth/requireAdmin` في session.ts:223-257) — الخطر عرض واجهات/بنية إدارية للزائر، لا تسريب بيانات مباشر.
- 🟠 `AuthGate` (`AuthGate.tsx:13-32`) لا يحجب الـ render (يرسم ثم redirect) ولا يغطي صفحات `[locale]`.
- 🟠 **نظاما auth متوازيان**: الحي عبر `AuthModals` (/login، /register) قوي؛ بينما `[locale]/auth/login/page.tsx` **ميت كلياً** (بلا `onSubmit`، `href="#"` في :71/:85، أزرار Biometric ميتة) و`[locale]/auth/register/page.tsx` **لا يرسل أي API** (فقط ينتقل لخطوة OTP) — الزائر الذي يصل لـ `/ar/auth/login` محاصر في صفحة لا تعمل.
- 🟠 13+ صفحة `jobs/employer/*` و`jobs/candidate/*` و`jobs/cv-bank` خارج `PROTECTED_PAGE_PREFIXES` **وبلا guard على مستوى الصفحة** — تُعرض الواجهة كاملة للزائر (تفشل fetch، يرى رسائل أخطاء).

## 9. Authorization UI 🟠

- لا يوجد منع عرض موحّد للوظائف الإدارية في المكونات نفسها؛ `OwnerPanel`/`AdminPanel` لا تتحققان من الدور داخلياً. الحماية المعتمدة: middleware (ثُغِرت بالبادئة) + guard صفحة admin (client) + API.
- `/admin/scrape/page.tsx:1-9` و`/admin/auto-publish/page.tsx:1-9` Server Components بلا guard (تعتمد على middleware الذي يُتجاوز).

## 10. Design System 🟠

- 🟢 أساس سليم: `cn()` (clsx + tailwind-merge) في `utils.ts:4-6`، shadcn-style عبر Radix، `@theme` في globals.css.
- 🟠 **انفلات التوكين**: `text-[10px]` **869 مرة**، `text-[11px]` 162، `text-[9px]` 156، `text-[8px]` 50 — أعلى التركيزات في `admin/ReportedContent.tsx`، `admin/FlaggedContentManager.tsx`، `admin/BulkNotifications.tsx`.
- 🟠 **259 نمط `style={{...}}` inline** بدل التوكين (أمثلة: `OwnerPanel.tsx:190`, `LandingPage.tsx:123`, `JobsView.tsx:630`).
- 🟡 تعدد أنظمة i18n النصي: `i18n.tsx` + `owner-i18n.ts` + `admin/i18n/new-admin-keys.ts` + ترجمات inline في `ConsultationsPage.tsx:117`.

## 11. RTL 🔴

- 🟢 الإعداد الأساسي سليم: `src/app/layout.tsx:113` — `<html lang="ar" dir="rtl">` + سكربت هيدرات للغة المحفوظة + `i18n.tsx:93-100`.
- 🔴 **اتجاهيات يدوية تفوق المنطقية**: `ml/mr/pl/pr` **281** استخداماً مقابل `ms/me/ps/pe` **241** — هوامش متجهة تُفسد العرض العربي.
- 🔴 **فئة ديناميكية لا تُبنى إطلاقاً**: `AdminPanel.tsx:566` — `` className={`border-${isRtl ? 'l' : 'r'} ...`} ``: قالب حرفي داخل className لا يولّده Tailwind (بلا أي CSS) → حدّ مفقود في RTL.
- 🟠 **كسر RTL في الأيقونات**: `EventsView.tsx:273,279-282,340,358,472` (`mr-1`/`mr-1.5`/`pl-10`).
- 🟠 `rtl:` **22 استخداماً فقط** مقابل **437 شرط `isRtl`** و65 موضع `dir === 'rtl'` — البرمجة الشرطية بدل CSS logical.
- 🟡 positioning يدوي: `AdminPanel.tsx:565-568` (`right-0/left-0` + translate-x).
- 🟡 `[locale]/layout.tsx:1-7` **لا يضبط dir/lang** — زائر `/en/...` بلا localStorage يبقى `dir="rtl"`.

## 12. Responsive Design 🟠

- **120 ملفاً بلا أي breakpoint**: أكبرها `JobsView.tsx` (785 سطراً، `grid-cols-2` ثابت)، `admin/SettingsSection.tsx`, `admin/LiveActivityFeed.tsx`.
- استخدام ضعيف للأحجام: `sm:` 788 / `md:` 240 / `lg:` 284 / `xl:` 37.
- 🟠 شبكات ثابتة على mobile: `AchievementsView.tsx:332` (`grid-cols-4 md:grid-cols-8`), `:573` (`grid-cols-3` بلا بديل).
- 🟡 `h-[90vh]` في 12+ ملفاً (أمثلة `admin/AdManager.tsx`, `ConsultationsPage.tsx`).
- 🟡 `jobs/JobCreationForm.tsx` (1865 سطراً) — `sm:` فقط 13 مرة (نموذج شبه desktop-only).

## 13. Accessibility 🟠

- 🟠 **مدخلات بلا أسماء مسموعة**: `placeholder=` **568** مقابل `aria-label` **57** فقط؛ `aria-labelledby` **0**، `aria-describedby` **3**.
- 🟠 **Dialog بلا اسم مفيد**: `ui/dialog.tsx:68-70` — عنوان `sr-only` حرفي "Dialog" بلا ربط `aria-labelledby` بمحتوى العنوان.
- 🟠 غياب حالات التفاعل: `aria-expanded` **0**، `aria-pressed` **0**، `role=` **0**، `aria-selected` 5 فقط.
- 🟡 لوحة مفاتيح محدودة: `tabIndex` 14، `autoFocus` 10.
- 🟢 **إيجابي**: 45 `<img>` كلها بـ `alt` (الوحيد بدونه داخل تعليق في `OptimizedImage.tsx:118`)؛ `focus-visible` 138 — الموجود جيد.

## 14. Performance 🟠

- 🟠 **مكتبات ثقيلة في الـ layout العام**: socket.io-client + framer-motion تُحمَّل ضمن كل صفحات `(main)` بلا تفكيك (agent-found: layout التفكيك غير كافٍ).
- 🟠 **مكتبات ضخمة بلا dynamic import**: recharts, maplibre-gl, @mdxeditor/editor, html2canvas-pro, pdfjs-dist مستوردة مباشرة في مكونات (تحقق من مواقعها قبل الاقتراح).
- 🟡 `prefetch={true}` صريح في `Sidebar.tsx:144` و`Navbar.tsx:113` (مع أن prefetch الافتراضي نشط أصلاً في App Router).
- 🟠 **N+1**: حلقة استعلامات في `src/app/(main)/jobs/employer/page.tsx`.
- 🟡 image optimization مفعّل (avif/webp، deviceSizes، minimumCacheTTL 3600) — 🟢 لكن راجع أي `<img>` بدل `next/image`.
- 🟡 كل الصفحات Client + waterfalls fetch متسلسلة (البنية §5).

## 15. Forms 🟠

- 🟠 **react-hook-form غير مستخدم إطلاقاً**: `src/components/ui/form.tsx` (غلاف shadcn) موجود لكن **لا يوجد أي `useForm()`** في المشروع.
- 🟠 **zod محصور في السيرفر** (`src/lib/validation.ts`, `services/job.service.ts:18`): التحقق العميل يدوي وغير موحّد.
- أمثلة: جيّد — `jobs/JobCreationForm.tsx:485-502` (دالة validate ترجع أول خطأ). ضعيف — `AuthModals.tsx:317` (`if (!form.name...) return` بلا رسائل حقول)؛ `[locale]/auth/login/page.tsx` **بلا validation إطلاقاً**.
- 🟡 لا يوجد `handleError` عميل مشترك لرسائل مفيدة بدل "Something went wrong".

## 16. Loading States 🟠

- **61** موضع `if (loading|isLoading)` + **232** `animate-spin` + **271** `Loader2` + 101 نمط spinner يدوي.
- `LoadingSpinner` مكرر حرفياً ×2 + نسخة محلية ثالثة (`ui/button.tsx:64-72`, `ui/glass-button.tsx:83-91`, `map/MapContentPanels.tsx:85`).
- 🟢 Skeleton موجود (shadcn) لكن الاستخدام غير موحّد.

## 17. Error States 🟠

- **لا يوجد `ErrorState` موحّد**: `ErrorFallbackUI` داخل `ErrorBoundary.tsx:30` فقط؛ `ErrorBoundary/withErrorBoundary` مستخدمة 35 مرة (نقطة جيدة) لكن المكوّنات لا تستخدم حالة خطأ مشتركة داخل الصفحات.
- كل مكوّن يعيد رسالة الخطأ يدوياً من fetch (انظر §7).

## 18. Empty States 🟠

- **`EmptyState.tsx:153` مستخدم 18 مرة فقط** مقابل **81 ملفاً** يكتب "لا توجد/لا يوجد" يدوياً.
- `admin/` و`jobs/` يكرران النصوص رغم توفر المكوّن (أمثلة `admin/ReportedContent.tsx`, `jobs/JobDetail.tsx`).

## 19. Mobile Experience 🟡

- يعتمد على نتائج §12: صفحات كاملة بلا breakpoints، شبكات ثابتة، نماذج طويلة، `h-[90vh]`.
- Navbar/Sidebar يبدوان قائمين (Sidebar يحتوي نسخة mobile) — يستدعي تحققاً عملياً إضافياً.

## 20. Technical Debt 🟠

- 🟠 **707 استخدام `any`** في components/app (عيّنات: مذكورة في التقرير التفصيلي).
- 🟠 **91/100 وحدة في `src/lib/features` بلا استخدام** + **19 مكوّن ميت** + **2 hooks ميتان** (`usePushNotifications.ts`, `useMessageActions.ts`) + `query-hooks.ts` ميت + `ui/form.tsx` ميت.
- 🟠 **40 route مؤرشفة** في `src/app/api/features/src/app/api/features/*` + 4 endpoints شبحية متداخلة تحت `/api/features/src/...`.
- 🟠 **أسرار إنتاج على القرص**: `NEW-SECRETS.txt` + `.env` يحوي مفاتيح بوابات دفع (MASTERCARD, ZAINCASH, QICARD, FIB) وكلمات مرور. (المشروع ليس git repo حالياً — لكن عند التهيئة يجب إضافة `.env` و`NEW-SECRETS.txt` إلى `.gitignore` قبل أي commit).
- 🟠 **PII يتيمة في localStorage**: `maydan_user` يُكتب من `AuthModals.tsx:373,899`, `ProfileView.tsx:172,353,405,530`, `ProfileImageGallery.tsx:119` — **ولا يوجد أي `getItem('maydan_user')`** (نسخة يتيمة/مصدر تعقّب لا يُقرأ — يُوصى بإزالتها).
- 🟡 8 `@ts-ignore` فقط (قليلة، جيد).
- 🟡 `.bak.*` داخل `src` (`ProfileView.tsx.bak.20260726_003312` وغيرها).
- 🟡 `COMPONENT_SPLITTING_GUIDE.ts` (460 سطراً) داخل `components/jobs` — دليل لم يُطبّق.

## 21. Duplicate Components 🔴

- 🔴 **`ProfileView.tsx` مكرر بايتاً ببايت**: `src/components/ProfileView.tsx` = `src/components/profile/ProfileView.tsx` (نفس SHA256) — أي إصلاح على نسخة يترك الأخرى.
- 🟠 **6 أزواج أسماء مكررة** (محتوى مختلف): `CompanyDashboard` (1407/1643)، `DashboardView`، `Sidebar`، `Pagination`، `Recommendations`.
- 🟠 **أزواج XX/XXView شبه مكررة وظيفياً**: `EconomicCalendar` (665) ↔ `EconomicCalendarView` (1356)؛ `AdvancedSearch` (224) ↔ `AdvancedSearchView` (1210)؛ `ExpertMarketView` (909) ↔ `ExpertMarketplaceView` (1652)؛ `ConsultationsView` (638) ↔ `ConsultationsPage` (2875)؛ `MarketPrices` (455) ↔ `MarketPricesView` (617).
- 🟠 **3 Navbars/Headers**: `Navbar.tsx` + `NavbarServer.tsx` + `Header.tsx` + تنفيذات Preview داخل `PlatformShell.tsx`.

## 22. Broken UI 🔴

- 🔴 **7 dead routes في `[locale]`** (تُبتلع بالقشط): `page`, `articles`, `dashboard`, `research`, `search`, `wallet`, `admin/analytics`. الأخيرة **404 دائم** (لا صفحة في `(main)`)، والأولى 6 تحمل **بيانات وهمية hardcoded** (مثل `mockTransactions` في `[locale]/wallet/page.tsx:25`).
- 🔴 **صفحتا auth في `[locale]` ميتتان** (انظر §8) — رابط `/ar/auth/register` يقود لمأزق.
- 🟠 **مسار ميت**: `src/app/(main)/iraq-map/[province]/` فارغ (بلا page.tsx).
- 🟠 **`/polls/standalone`** في بادئات الحماية لكن لا صفحة تحته → 404 دائم.
- 🟢 مجلدات فارغة غير مؤذية: `consultations-messages/`, `jobs/employer/subscription/`.

## 23. Missing Features 🟡

- لا اختبارات UI/component إطلاقاً (رغم تثبيت testing-library).
- `jobs/candidate/applied` — "قريباً".
- react-query infra جاهزة لكن غير موصّلة (State §6).
- لا `ErrorState` موحّد، ولا `EmptyState` في admin/jobs.

## 24. Recommended Improvements (مرتّب حسب الأولوية)

### المرحلة 1 — أمن (Critical)
1. **إصلاح ترتيب الـ middleware** في `src/middleware.ts`: نقل فحص `locale` (القشط) بعد فحص الحماية، أو إجراء فحص الحماية على المسار **المجرّد من البادئة** في كل الحالات (`stripped`).
2. **تغطية الحماية المفقودة**: إضافة `/owner`, `/owner-panel`, `/marketplace/admin`, `/marketplace/dashboard`, `/jobs/employer`, `/jobs/candidate`, `/jobs/cv-bank`, `/finance` إلى `PROTECTED_PAGE_PREFIXES` (وأدوار مناسبة للإداري منها)، أو guard على مستوى كل صفحة.
3. **حماية صفحات `[locale]` المحمية** (خاصة `/settings`) عبر تمريرها من نفس سياسة الحماية.
4. **إزالة أسرار القرص**: نقل `NEW-SECRETS.txt` خارج المشروع، ووضع `.env*` في `.gitignore` (عند تهيئة git).
5. **إزالة `maydan_user` من localStorage** أو إغلاق مسار الكتابة إن لم يعد مستخدماً.

### المرحلة 2 — صحة/اتساق (High)
6. **توحيد نظام auth**: حذف صفحتَي `[locale]/auth/*` الميتتين أو إصلاحهما لاستخدام نفس تدفق `AuthModals`؛ تفعيل `returnUrl` في `/login`.
7. **حذف الـ 7 dead routes في `[locale]`** + تثبيت `[locale]/layout.tsx` لضبط dir/lang (أو إزالة الـ group إن لم يُعد مطلوباً).
8. **إصلاح RTL**: تحويل الـ 281 `ml/mr/pl/pr` إلى logical (`ms/me/ps/pe`) تدريجياً، وإصلاح `AdminPanel.tsx:566` بفئة ثابتة (`border-s`/`border-e`).
9. **توحيد طبقة الـ API client** (استخدام `fetcher` الموجود + `handleError` مشترك + تحديث الـ 291 fetch تدريجياً).
10. **ربط react-query**: إضافة `QueryClientProvider` وتحويل server-state من zustand إلى react-query (إبطال الكاش + refetch).

### المرحلة 3 — قابلية الصيانة/الأداء (Medium)
11. **تقسيم المكونات العملاقة** (86 مكوّناً >400 سطر) بدءاً من الأكبر، مع استخراج hooks/features إلى `src/components/features/` — تطبيق فعلي لدليل `COMPONENT_SPLITTING_GUIDE`.
12. **إزالة الكود الميت**: 91 وحدة `features`، 19 مكوّناً، hookين، `query-hooks.ts` (إن لم يُفعَّل)، `ui/form.tsx`، المسارات المؤرشفة `api/features/src/...`.
13. **حذف الملفات المكررة** (نسختا `ProfileView`) ودمج أزواج XX/XXView وNavbars الثلاثة.
14. **توحيد حالات UI**: اعتماد `EmptyState`/`Skeleton`/`ErrorState` موحّد بدل الأنماط اليدوية (81 ملفاً).
15. **الوصولية**: إضافة `aria-label`/`aria-labelledby` للمدخلات، ربط Dialog بالعنوان، حالات `aria-expanded/pressed`.
16. **التجاوب**: إضافة breakpoints للـ 120 ملفاً المفقودة (البدء بالحرجة).
17. **تقييد الانفلات**: سياسة قيم التوكين بدل `text-[10px]` و`style={{}}` (lint rule مخصص).
18. **الأداء**: dynamic import لـ recharts/maplibre/mdxeditor/pdfjs؛ حلقة N+1 في `jobs/employer/page.tsx`؛ إعادة فحص تحميل socket.io-client في layout عام.

---

### المرجع (ملفات أساسية)
- `src/middleware.ts` — القشط `:269-284`، البادئات المحمية `:156-182`، فحص الحماية `:376-427`.
- `src/app/layout.tsx:113` — dir/lang.
- `src/components/ui/` — نظام التصميم.
- `src/lib/query-hooks.ts`, `src/lib/store.ts` — الحالة.
- `src/components/AuthModals.tsx`, `src/app/[locale]/auth/*` — auth UI.
- `docs/AGENT-CONTRACT.md` — حدود الملكية (Frontend يملك `src/components/**`, `src/app/**` عدا api).
