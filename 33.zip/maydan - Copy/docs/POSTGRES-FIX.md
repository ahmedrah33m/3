# إصلاح خطأ مصادقة PostgreSQL

<div dir="rtl">

## 🔴 الخطأ

```
Invalid `prisma.user.findUnique()` invocation:
Authentication failed against database server,
the provided database credentials for `maydan` are not valid.
```

## 🎯 السبب

كلمة مرور مستخدم `maydan` في PostgreSQL لا تطابق القيمة في `DATABASE_URL` بملف `.env.local`.

## ⚙️ الحل السريع (سكربت آلي)

```bash
cd midan9
bash scripts/db.sh fix-auth
# أو لتغيير كلمة المرور:
bash scripts/db.sh fix-pass
```

السكربت الموحد `db.sh` يقوم تلقائياً بـ:
1. التحقق من تشغيل PostgreSQL
2. فحص pg_hba.conf وإرشادك لإصلاحه
3. اختبار الاتصال
4. (fix-pass) تغيير كلمة مرور مستخدم `maydan`
5. تحديث `.env` بكلمة المرور الجديدة
6. اختبار الاتصال النهائي
7. تشغيل `prisma generate` و `prisma db push`

---

## 🔧 الحل اليدوي (خطوة بخطوة)

### 1. تأكد من تشغيل PostgreSQL

```bash
# Linux (systemd)
sudo systemctl status postgresql
sudo systemctl start postgresql

# Linux (service)
sudo service postgresql start

# macOS (Homebrew)
brew services start postgresql

# Docker
docker start midanco-postgres
```

### 2. سجّل الدخول كمستخدم postgres

```bash
sudo -u postgres psql
# أو
sudo -u postgres psql -U postgres
```

### 3. أنشئ/حدّث مستخدم maydan بكلمة مرور جديدة

داخل psql:

```sql
-- إنشاء المستخدم إذا لم يوجد
CREATE USER maydan WITH PASSWORD 'ضع_هنا_كلمة_مرور_قوية';

-- أو تحديث كلمة المرور إذا كان موجوداً
ALTER USER maydan WITH PASSWORD 'ضع_هنا_كلمة_مرور_قوية';

-- منح صلاحية إنشاء قواعد بيانات
ALTER USER maydan CREATEDB;

-- إنشاء قاعدة البيانات
CREATE DATABASE maydan_db OWNER maydan;

-- منح كل الصلاحيات
GRANT ALL PRIVILEGES ON DATABASE maydan_db TO maydan;

-- الخروج
\q
```

### 4. اختبر الاتصال

```bash
PGPASSWORD='ضع_هنا_كلمة_مرور_قوية' psql -U maydan -h localhost -p 5432 -d maydan_db -c "SELECT current_user, current_database();"
```

يجب أن ترى:
```
 current_user | current_database
--------------+------------------
 maydan       | maydan_db
```

### 5. حدّث ملف `.env.local`

افتح `midanco/.env.local` وعدّل السطرين:

```bash
DATABASE_URL="postgresql://maydan:ضع_هنا_كلمة_مرور_قوية@localhost:5432/maydan_db?schema=public&connection_limit=5"
DIRECT_DATABASE_URL="postgresql://maydan:ضع_هنا_كلمة_مرور_قوية@localhost:5432/maydan_db?schema=public&connect_timeout=30"
```

> ⚠️ **مهم**: استخدم نفس كلمة المرور التي وضعتها في الخطوة 3.

### 6. طبّق الـ schema على قاعدة البيانات

```bash
cd midanco
npx prisma generate
npx prisma db push
```

### 7. (اختياري) أضف بيانات أولية وأنشئ admin

```bash
npm run db:seed
npm run create-admin
```

### 8. أعد تشغيل الخادم

```bash
npm run dev
```

---

## 🐛 مشاكل شائعة إضافية

### المشكلة: `Connection refused` (بدلاً من Authentication failed)

**السبب**: PostgreSQL لا يعمل، أو يعمل على منفذ مختلف.

**الحل**:
```bash
# تحقق من المنفذ
sudo -u postgres psql -c "SHOW port;"
# عادة 5432، لكن قد يكون 5433 إذا كان هناك نسختان

# عدّل DATABASE_URL بالمنفذ الصحيح
```

### المشكلة: `password authentication failed for user "postgres"`

**السبب**: كلمة مرور مستخدم `postgres` الأساسي غير معروفة.

**الحل**:
```bash
# Linux: بدّل إلى postgres بدون كلمة مرور
sudo -u postgres psql

# ثم بدّل كلمة المرور
ALTER USER postgres WITH PASSWORD 'new_password';
```

### المشكلة: `database "maydan_db" does not exist`

**الحل**:
```sql
sudo -u postgres psql -c "CREATE DATABASE maydan_db OWNER maydan;"
```

### المشكلة: `permission denied for schema public`

**السبب**: PostgreSQL 15+ يغيّر صلاحيات `public` schema.

**الحل**:
```sql
sudo -u postgres psql -d maydan_db -c "GRANT ALL ON SCHEMA public TO maydan;"
sudo -u postgres psql -d maydan_db -c "ALTER SCHEMA public OWNER TO maydan;"
```

### المشكلة: `pg_hba.conf` يرفض الاتصال

**السبب**: إعدادات `pg_hba.conf` لا تسمح بالاتصال بكلمة مرور.

**الحل**:
```bash
# ابحث عن ملف pg_hba.conf
sudo -u postgres psql -c "SHOW hba_file;"

# عادة في:
# /etc/postgresql/15/main/pg_hba.conf
# /etc/postgresql/16/main/pg_hba.conf

# عدّل السطر لـ:
# host    all    all    127.0.0.1/32    md5
# host    all    all    ::1/128         md5

# ثم أعد التحميل
sudo systemctl reload postgresql
```

---

## 📋 قائمة تحقق سريعة

- [ ] PostgreSQL يعمل (`pg_isready` يُرجع "accepting connections")
- [ ] مستخدم `maydan` موجود بكلمة مرور صحيحة
- [ ] قاعدة بيانات `maydan_db` موجودة ومملوكة لـ `maydan`
- [ ] `.env.local` يحتوي على `DATABASE_URL` الصحيح
- [ ] `npx prisma generate` نجح
- [ ] `npx prisma db push` نجح
- [ ] `npm run dev` يعمل بدون أخطاء
- [ ] تسجيل الدخول يعمل

</div>
