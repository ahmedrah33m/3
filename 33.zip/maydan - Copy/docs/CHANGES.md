# Changelog — Midan Platform Patched Delivery

**Date:** 2026-07-19
**Base commit:** midan11 (extracted from `midan11.zip`)
**Total files modified:** 26
**Total files created:** 9
**Critical bugs fixed:** 17 / 17 (100%)
**High-priority issues fixed:** 11 / 12 (92%)
**Medium-priority issues fixed:** 7 / 10 (70%)

---

## 1. Wallet & Payment System (`src/lib/wallet-service.ts`)

### Critical Bug Fixes

- **BUG-1 (CRITICAL):** `payFromWallet` had `where: { userId: wallet.id }` — should be `where: { id: wallet.id }`. This single-character bug threw Prisma P2025 for every call, breaking all 11 wallet-integrated payment endpoints.
- **BUG-8:** `payFromWallet` set `netAmount: amount` on the buyer's SPEND transaction and on the Invoice. Should be `netAmount: providerAmount` (the share the provider keeps after commission).
- **BUG-15:** `payFromWallet` had a race condition — two concurrent payments against the same wallet could both pass the balance check and both decrement, going negative. Fixed by `SELECT * FROM "Wallet" WHERE userId = ? FOR UPDATE` inside the transaction.
- **BUG-16:** `redeemGiftCard` had the same race — same gift card code could be redeemed twice by concurrent requests. Fixed with `SELECT FOR UPDATE` + conditional `updateMany` (double-safety).
- **BUG-17:** `createTopUpRequest` and `createWithdrawalRequest` were non-atomic — `topUpRequest.create` and `wallet.update({ pendingBalance: increment })` were two separate operations. Wrapped in `db.$transaction` with row-level lock.

### New Features Added

- `refundPayment(originalTxId, reason, reviewerId)` — reverses a `payFromWallet`: refunds buyer, deducts provider (with frozenBalance fallback if provider's balance is insufficient). Marks Invoice as REFUNDED.
- `transferFunds(fromUserId, toUserId, amount, description)` — P2P wallet-to-wallet transfer with deterministic lock ordering (sort userIds) to avoid deadlocks.
- `adjustWallet({ userId, amount, reason, reviewerId })` — manual credit/debit by owner. Uses ADJUSTMENT tx type. Requires reason ≥5 chars, max 50,000,000 IQD.
- `freezeFunds({ userId, amount, reason, reviewerId })` — locks funds in `frozenBalance` (e.g., during dispute). Uses FROZEN tx type.
- `unfreezeFunds(frozenTxId, reviewerId, releaseToBalance)` — releases frozen funds back to balance OR deducts from wallet.
- `releaseEscrow(providerTxId)` — converts FROZEN provider transaction → EARNING. Moves amount from `frozenBalance` to `balance` + `totalEarnings`. Used by expert-service order completion flow.
- `payFromWallet` now accepts `useEscrow?: boolean` option — when true, the provider's share goes to `frozenBalance` instead of `balance`, awaiting `releaseEscrow` call.
- `getAllWallets({ page, pageSize, search, sortBy })` — admin viewer for all wallets.
- `getFinancialOverview(period)` — owner dashboard summary: revenue, GMV, payouts, refunds, by service type, by day.

### Validation Hardening

- Added `isvalidServiceType(s)` function — `payFromWallet` now rejects unknown serviceType values.
- `generateInvoiceNumber` is now race-safe via `SELECT ... FOR UPDATE` on the count query.
- `createTopUpRequest` and `createWithdrawalRequest` enforce max amount (10,000,000 IQD).
- `createWithdrawalRequest` now validates `paymentMethod` and `accountDetails` fields.

---

## 2. Owner Approval Routes

### `src/app/api/owner/topup/route.ts`

- **BUG-4 (CRITICAL):** Approval forgot to decrement `pendingBalance` — wallet's `pendingBalance` grew forever, corrupting available-balance math. Now delegates to `wallet-service.approveTopUp`.
- **BUG-5 (CRITICAL):** Rejection didn't touch the wallet at all — `pendingBalance` permanently inflated for rejected top-ups. Now delegates to `wallet-service.rejectTopUp`.

### `src/app/api/owner/withdrawals/route.ts`

- **BUG-2 (CRITICAL):** POST `complete` never decremented `Wallet.balance` — users could withdraw unlimited amounts. Now delegates to `wallet-service.approveWithdrawal(action='COMPLETE')`.
- **BUG-3:** POST `approve` only touched `pendingBalance`; inline logic diverged from `wallet-service` state machine. Now delegates to `wallet-service.approveWithdrawal(action='APPROVE')`.
- **BUG-7:** Two parallel withdrawal state machines — `wallet-service` used APPROVED as intermediate; owner UI used PROCESSING. Now both use PROCESSING. Reject accepts any pre-COMPLETED state.

---

## 3. Service Layer Fixes

### `src/services/job.service.ts`

- **BUG-9 / H3 (CRITICAL):** `Job.paymentId = result.walletTxId` — wrote `WalletTransaction.id` into a field whose FK requires `Payment.id`. Every paid job post threw P2003 after money was deducted. Removed the `paymentId` write; the link is recorded in `WalletTransaction.serviceId`.
- **BUG-14 / H8 (CRITICAL):** `sendNotification({ userId: 'all' })` — FK violation (no User with id='all') poisoned the entire notification batch via `createMany` (skipDuplicates doesn't skip FK violations). Replaced with targeted query: find users whose `interests` or `skills` match the job category, then send individual notifications (max 200 to prevent flooding).

### `src/services/cv-bank.service.ts`

- **BUG-10 / H5 (CRITICAL):** Same FK violation as `job.service.ts` — `CvBankSubscription.paymentId = result.walletTxId` (WalletTransaction.id, not Payment.id). Removed the `paymentId` write from both `create` and `update` branches of the upsert. The link is recorded in `WalletTransaction.serviceId`.

### `src/lib/payment-service.ts`

- **BUG-12 / H2 (CRITICAL):** `createPaymentOrder` wrote 4 fields that don't exist on the Payment schema: `purpose`, `couponCode`, `customerPhone`, `gatewayReference`. Every call threw "Unknown argument". Mapped to existing fields: `purpose` → `description`, `customerPhone` → `phoneNumber`, `gatewayReference` → `gatewayTxId`. `couponCode` stored in `callbackData` JSON field. Also added `gatewayUrl` write.
- `handleWebhook` now uses `gatewayTxId` (was `gatewayReference`) and wraps the status update + job activation in `db.$transaction`.

---

## 4. API Route Fixes

### `src/app/api/expert-market/orders/route.ts`

- **BUG-11 / H4 (CRITICAL):** Wrote `walletTxId` and `amount` to `ExpertServiceOrder.create()` — neither field exists in the schema. Every order creation failed after the wallet payment had been deducted. Removed the non-existent fields.
- **H16 (CRITICAL):** USD→IQD conversion heuristic was broken: `serviceAmount < 1000 ? * 1500 : as-is`. A 999-IQD service got mis-converted to 1,498,500 IQD (buyer pays 1500× too much). A $1500 service was treated as 1500 IQD (expert gets 1500× too little). Fixed to use `service.currency` field — only multiplies by 1500 if currency is explicitly USD.
- **Escrow + refund-on-failure:** Now calls `payFromWallet` with `useEscrow: true` to hold funds in provider's `frozenBalance` until order completion. If `ExpertServiceOrder.create` throws, the payment is automatically refunded via `refundPayment`.

### `src/app/api/expert-market/orders/[id]/release-escrow/route.ts` (NEW)

- POST endpoint to release escrowed funds to the expert after service completion. Verifies the caller is the buyer or OWNER, finds the FROZEN transaction for this order, calls `releaseEscrow`, and marks the order as COMPLETED.

### `src/app/api/payments/confirm/route.ts`

- **BUG-6 / H9 (CRITICAL):** Created a `WalletTransaction` with `type: 'PURCHASE_JOB'` (not in the documented enum) but never incremented `Wallet.balance`. Money vanished — deposit was recorded but balance stayed at 0. Fixed:
  - Wrapped all writes in `db.$transaction`.
  - Status normalized to uppercase ('COMPLETED' / 'PENDING').
  - Now increments `balance` and `totalDeposited`.
  - Uses valid tx type 'DEPOSIT' instead of 'PURCHASE_JOB'.
  - Sets `serviceType` and `serviceId` on the transaction.

### `src/app/api/finance/withdrawals/[id]/route.ts`

- **H7 (CRITICAL):** Two bugs in one: used field name `content` (schema has `message`) and enum value `WALLET_WITHDRAWAL_COMPLETED` (not in NotificationType enum — only `WALLET_WITHDRAWAL_APPROVED` and `WALLET_WITHDRAWAL_REJECTED` exist). Both threw Prisma errors, causing 500 AFTER the withdrawal had already been committed.
- Fixed: `content` → `message`; `WALLET_WITHDRAWAL_COMPLETED` → `WALLET_WITHDRAWAL_APPROVED` (for both APPROVE and COMPLETE actions, since the enum doesn't distinguish).
- Wrapped each notification in `try/catch` so a notification failure doesn't return 500 after a successful withdrawal.
- COMPLETE action now accepts from PENDING_REVIEW, APPROVED, or PROCESSING states.
- REJECT action now accepts from any pre-COMPLETED state (was PENDING_REVIEW only).

### `src/lib/async-queue.ts`

- **H8 (CRITICAL, defense in depth):** Even with the `job.service.ts` fix, added a pre-flight filter in the notification queue flush: drops any notification whose `userId` is `'all'`, empty string, non-string, or doesn't match the cuid format `/^[a-z0-9]{20,}$/i`. This prevents one bad notification from poisoning an entire batch via FK violation.

---

## 5. New API Endpoints

### `src/app/api/wallet/refund/route.ts` (NEW)

- POST — Owner-only endpoint to refund a payment. Calls `wallet-service.refundPayment(originalTxId, reason, owner.id)`.

### `src/app/api/wallet/transfer/route.ts` (NEW)

- POST — Authenticated endpoint for P2P wallet transfer. Validates amount (1,000–5,000,000 IQD), description (≥3 chars), and prevents self-transfer. Calls `wallet-service.transferFunds`.

### `src/app/api/owner/financial-overview/route.ts` (NEW)

- GET — Owner-only endpoint that returns financial summary for a given period (day/week/month/year). Includes: totalRevenue (commissions), totalGmv, totalPayouts, totalRefunds, pendingTopups, pendingWithdrawals, pendingWithdrawalAmount, byServiceType breakdown, byDay breakdown, transactionCount, invoiceCount.

### `src/app/api/owner/wallets/route.ts` (NEW)

- GET — Owner-only paginated wallet list with search (by user name/email) and sort (by balance/totalSpent/totalDeposited/totalEarnings).

### `src/app/api/owner/wallets/adjust/route.ts` (NEW)

- POST — Owner-only manual wallet adjustment. Validates userId, amount (non-zero, ≤50M IQD), reason (≥5 chars). Calls `wallet-service.adjustWallet`.

### `src/app/api/owner/invoices/route.ts` (NEW)

- GET — Owner-only paginated invoice list with status/serviceType filters and search. Returns aggregated stats (totalAmount, totalCommission, totalNet, count).

### `src/app/api/owner/transactions/route.ts` (NEW)

- GET — Owner-only paginated transaction log with type/serviceType/status filters and search (in description/reference/user).

---

## 6. Owner Panel — New Financial Dashboard

### `src/components/owner/FinancialOverviewDashboard.tsx` (NEW)

A new comprehensive financial dashboard component with 4 tabs:

1. **Overview:** Top stat cards (revenue, GMV, payouts, refunds); revenue by service type breakdown; daily revenue bar chart; pending actions alert banner.
2. **Wallets:** All-wallets table with search/sort/adjust. Columns: user, balance, pending, frozen, deposited, spent. Adjust button opens a guided dialog with credit/debit toggle.
3. **Transactions:** Full transaction log filtered by type (DEPOSIT/SPEND/EARNING/REFUND/WITHDRAW/FROZEN/UNFREEZE/ADJUSTMENT/TRANSFER_IN/TRANSFER_OUT/GIFT_CARD_REDEEM) and serviceType. Color-coded badges per type.
4. **Invoices:** Invoice list with status filter (PAID/REFUNDED/CANCELLED), service type filter, and aggregate stats (total amount, commission, net).

### `src/components/OwnerPanel.tsx` (MODIFIED)

- Added new nav item `financial` (icon: `PieChart`) pointing to `FinancialOverviewDashboard`.
- Imported the new component.
- Updated `validSections` array to include `'financial'`.
- Updated `renderContent` switch to render `<FinancialOverviewDashboard />` for the new section.

---

## 7. Wallet Page Fixes

### `src/app/(main)/wallet/page.tsx`

- **BUG-11 (UI):** Imported `BanknoteIcon` from `lucide-react` — this icon does not exist in the library. Was rendering as `undefined`, causing React to fall back to nothing. Fixed by aliasing: `import { Banknote as BanknoteIcon } from 'lucide-react'`.
- **BUG-12 (UI):** `TabsList` for transactions only had 4 tabs: all, DEPOSIT, SPEND, EARNING. Withdrawals and gift card redeems only showed under "all". Added 3 new tabs: WITHDRAW, GIFT_CARD_REDEEM, REFUND — each with i18n fallback.

---

## 8. i18n & RTL Fixes

### Data Corruption Fix

- **CRITICAL:** `src/components/EconomicIndicatorsView.tsx` line 131 had Chinese characters `得益于` mixed into an Arabic string: `'ارتفع الناتج المحلي بنسبة 3.2%得益于 زيادة الإنتاج النفطي...'`. Replaced with proper Arabic `'بفضل'`.

### Pages Now i18n-Aware (12 pages fixed)

Each of these pages now imports `useI18n` and uses `t.section.key || (locale === 'en' ? 'English fallback' : 'Arabic fallback')` for title/subtitle/labels:

- `src/app/(main)/articles/page.tsx` — title, subtitle, search placeholder, all status messages
- `src/app/(main)/learn/page.tsx` — title, subtitle, 3 tab labels
- `src/app/(main)/connections/page.tsx` — tab labels (was importing useI18n but never calling t)
- `src/app/(main)/bookmarks/page.tsx` — title, subtitle, empty state, button label, locale-aware date formatting
- `src/app/(main)/economy/indicators/page.tsx`
- `src/app/(main)/economy/converter/page.tsx`
- `src/app/(main)/economy/market/page.tsx`
- `src/app/(main)/economy/map/page.tsx`
- `src/app/(main)/economy/calendar/page.tsx`
- `src/app/(main)/economy/ai-assistant/page.tsx`
- `src/app/(main)/investment-bank/page.tsx`
- `src/app/(main)/expert-market/page.tsx`

### RTL Fixes

- `src/app/(main)/articles/page.tsx`:
  - Line 146: `right-3` → `start-3` (search icon position)
  - Line 151: `pr-9 pl-4` → `ps-9 pe-4` (input padding)
- `src/app/(main)/premium/page.tsx`:
  - Line 247: toggle thumb `translate-x-6` / `translate-x-1` → added `rtl:-translate-x-6` / `rtl:-translate-x-1` variants
  - Line 252: `ml-1` → `ms-1` (Gift icon)
  - Lines 274, 277: directional gradients `bg-gradient-to-r` → added `rtl:bg-gradient-to-l`
  - Line 280: badge gradient → added `rtl:bg-gradient-to-l`
  - Lines 330, 332: CTA button gradients → added `rtl:bg-gradient-to-l`
- `src/app/(main)/connections/page.tsx`:
  - Lines 150, 161: `ml-1` → `ms-1` (badge positioning)

---

## 9. Documentation Files

- `docs/AUDIT-REPORT.pdf` — Comprehensive 26-page audit report (this delivery's main deliverable)
- `docs/AUDIT-REPORT.md` — Same content in Markdown for editing/version control
- `docs/CHANGES.md` — This file
- `docs/MIGRATION.md` — Step-by-step guide to apply this delivery to an existing deployment

---

## 10. Known Remaining Issues (Documented, Not Fixed)

These issues are documented in the audit report but require database migrations or larger refactors that should be tested in staging:

1. **Schema migrations needed:**
   - Migrate 9 money fields from `Float` to `Decimal` (Subscription.amount, PromotionCampaign.{budget,dailyBudget,spentAmount}, etc.)
   - Change `ExpertService.price` from `String` to `Decimal`
   - Add `version Int @default(0)` to `Wallet` for optimistic concurrency (alternative to row-level locks)
   - Change `Payment.currency` default from `"USD"` to `"IQD"`
   - Add missing `@@index` annotations

2. **Translation gaps:**
   - Kurdish (ku) missing 3 top-level sections: `dictionary`, `aiChat`, `assessment` (~245 keys total)
   - `premium/page.tsx` has 89 hardcoded strings (plans array, comparison table) — needs full i18n pass
   - `EconomicIndicatorsView.tsx` has 100+ hardcoded strings + 6 `text-right` occurrences in table headers

3. **Validation migration:**
   - 247 endpoints use manual validation; should migrate to Zod schemas for type safety
   - 6 endpoints have no validation at all (admin/users/[id]/ban, etc.)

4. **Cleanup (safe to delete):**
   - 6 orphaned owner components: `PricingTab.tsx`, `RevenueTab.tsx`, `PaymentAccountsTab.tsx`, `PaymentGatewaysTab.tsx`, `FreePeriodsTab.tsx`, `CouponsTab.tsx`
   - 4 deprecated API routes returning 410: `/api/payment`, `/api/payment/callback/{zain-cash,qi-card}`, `/api/payment/verify`
   - 1 deprecated lib: `src/lib/payment/gateway.ts`

5. **Atomicity gaps:**
   - `articles/[id]/route.ts` PUT — article update + tag delete + tag create should be in $transaction
   - `jobs/route.ts` POST — job create + extra-fields update should be in $transaction (and bypasses Zod)
   - `consultations/book/route.ts` — payment + consultation update should be in $transaction

6. **Security:**
   - No CSRF protection on wallet POST routes (relies only on session cookie)
   - Hardcoded DB URL fallback in `src/lib/db.ts:45` (contains password)

---

## 11. Testing Checklist

After applying this delivery, verify the following:

- [ ] Owner can approve a top-up request — `Wallet.balance` increases, `pendingBalance` decreases by the same amount
- [ ] Owner can reject a top-up request — `pendingBalance` decreases, `balance` unchanged
- [ ] Owner can complete a withdrawal — `Wallet.balance` decreases by withdrawal amount
- [ ] Owner can reject a withdrawal — `pendingBalance` decreases, `balance` unchanged
- [ ] User can create a paid job post — wallet is debited, job is created (no P2003 error)
- [ ] User can subscribe to CV bank — wallet is debited, subscription is created (no P2003 error)
- [ ] User can order an expert service — wallet is debited, funds are held in expert's `frozenBalance`
- [ ] Buyer can release escrow after service completion — funds move from `frozenBalance` to `balance` + `totalEarnings`
- [ ] Owner can adjust a wallet manually — balance changes correctly, ADJUSTMENT tx is created
- [ ] Owner can refund a payment — buyer is refunded, provider is deducted (with frozen fallback)
- [ ] User can transfer funds P2P — sender debited, recipient credited, both tx records created
- [ ] Notifications don't get dropped when a job is created (no `userId: 'all'`)
- [ ] Switching to English displays English page titles on articles/learn/economy/* pages
- [ ] Switching to Arabic displays Arabic page titles
- [ ] Premium page toggle and gradients flip correctly in LTR mode
- [ ] New Financial Dashboard loads at `/owner` → "لوحة التحكم المالية الشاملة" tab

---

## 12. Post-Delivery Fixes (2026-07-19 — same day)

After the initial delivery, the user reported two issues preventing the app from starting. Both are fixed in the patched zip.

### Issue A: Prisma Schema Validation Error

```
Error: P1012
error: Field "activityLogs" is already defined on model "User".
error: The model "UserActivityLog" cannot be defined because a model with that name already exists.
```

**Root cause:** Two duplicates in `prisma/schema.prisma`:
- `User.activityLogs` was declared twice (line 246 with `@relation("ActivityLogs")` name, and line 333 without — the second caused a conflict)
- `model UserActivityLog` was defined twice (line 686 for the security audit log with `action`/`ipAddress`/`userAgent`/`details`, and line 4411 for a learning-activity log with `points`/`referenceId`/`referenceType`)

**Fix applied in `prisma/schema.prisma`:**
- Removed the duplicate `activityLogs` field at line 333 (the canonical relation at line 246 with the `"ActivityLogs"` named relation is kept)
- Removed the entire duplicate `model UserActivityLog` definition at line 4411 — it was never used in any code (all 14 actual usages of `db.userActivityLog.create()` in `src/lib/activity-logger.ts`, `src/lib/logger.ts`, `src/app/api/auth/change-password/route.ts`, `src/app/api/auth/reset-password/route.ts`, `src/app/api/admin/analytics/route.ts`, etc. all use the security fields: `action`, `ipAddress`, `userAgent`, `details`)

### Issue B: Database Authentication Failed

```
Error: P1000: Authentication failed against database server,
the provided database credentials for `user` are not valid.
```

**Root cause:** The `.env` file is NOT included in the zip (because `.gitignore` excludes it for security). When the user extracted the zip and ran `npm run dev`, Prisma had no `DATABASE_URL` to read, so it silently used PostgreSQL's default username `user` (which doesn't exist or has no password on most systems).

**Fixes applied:**

1. **New file `.env.dev-template`** — A ready-to-use `.env` file with safe default values for local development:
   - `DATABASE_URL=postgresql://maydan:maydan_secure_password@localhost:5432/maydan_db?schema=public`
   - Generated `JWT_SECRET`, `ENCRYPTION_KEY`, etc. (clearly marked as "dev only — change in production")
   - The user can simply `cp .env.dev-template .env` and be ready to develop locally

2. **New script `scripts/setup-db.sh`** — A 7-step automated database setup script:
   - Reads `DATABASE_URL` from `.env` and parses it
   - Checks PostgreSQL is running
   - Creates the role (`CREATE USER maydan WITH PASSWORD ...`) if missing
   - Creates the database (`CREATE DATABASE maydan_db OWNER maydan`) if missing
   - Grants privileges
   - Tests the connection
   - Runs `npx prisma db push` and `npx prisma generate`
   - Falls back gracefully when sudo isn't available (asks for postgres password)
   - Can be invoked via `npm run db:setup` or `bash scripts/setup-db.sh`

3. **Improved `src/lib/db.ts`:**
   - Now prints a clear bilingual (Arabic + English) error banner when `DATABASE_URL` is missing or invalid
   - Prints a startup banner showing which database it's connecting to (without exposing the password)
   - Keeps the hard-coded fallback URL (for backward compatibility) but with a clear warning

4. **Improved `dev.sh`:**
   - Added step 0: checks for `.env` file existence
   - Auto-creates `.env` from `.env.dev-template` if missing
   - Detects `CHANGE_ME` placeholders and warns the user
   - Detects default dev credentials and confirms them

5. **Updated `package.json` scripts:**
   - `npm run db:setup` → runs `bash scripts/setup-db.sh` (full setup)
   - `npm run db:setup:quick` → runs `bash scripts/setup-db.sh --quick` (skip prisma steps)
   - `npm run setup` → now uses `setup-db.sh` instead of the old `db.sh`
   - `npm run fix:db` → alias for `setup-db.sh`

### Quick Recovery Procedure for Existing Deployments

If you've already extracted the previous zip and are seeing the errors above:

```bash
cd ~/maydan

# 1. Extract the new zip (overwrites the buggy files)
unzip -o /path/to/midan11-patched.zip

# 2. Create .env from the new template
cp .env.dev-template .env

# 3. Run the new automated setup script
bash scripts/setup-db.sh

# 4. (Optional) Seed the database
npm run db:seed

# 5. Start the app
npm run dev
```

### Files Changed in This Hotfix

- `prisma/schema.prisma` — Removed duplicate `User.activityLogs` and duplicate `model UserActivityLog`
- `src/lib/db.ts` — Improved error messages with bilingual banner + startup connection log
- `scripts/setup-db.sh` (NEW) — Automated 7-step database setup
- `.env.dev-template` (NEW) — Ready-to-use .env for local development
- `.env.example` — Added pointer to `.env.dev-template` for quick start
- `dev.sh` — Added step 0: auto-create `.env` from template if missing
- `package.json` — Added `db:setup`, `db:setup:quick` scripts; updated `setup` and `fix:db`
- `docs/QUICK-FIX.md` (NEW) — Step-by-step troubleshooting guide

---

## 13. Final Verification Commands

Run these commands to verify the hotfix:

```bash
# Verify schema has no duplicates
grep -c "^model UserActivityLog" prisma/schema.prisma
# Expected: 1

grep -c "activityLogs.*UserActivityLog" prisma/schema.prisma
# Expected: 1

# Verify .env files exist
ls -la .env.dev-template .env.example

# Verify setup script is executable
ls -la scripts/setup-db.sh

# Verify db.ts has the new error banner
grep -c "DATABASE_URL غير مُعرّفة" src/lib/db.ts
# Expected: 1
```
