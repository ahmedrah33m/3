#!/usr/bin/env bash
# ============================================================================
# midan-fix-seed.sh — one-shot patch for the seed.ts FK violation + articles bug
# ============================================================================
# This script:
#   1. Backs up prisma/seed.ts
#   2. Patches the broken deleteMany block with TRUNCATE ... CASCADE
#   3. Creates scripts/diagnose-articles.ts (so `npx tsx scripts/diagnose-articles.ts` works)
#   4. Re-runs `npm run db:seed` (which will now succeed)
#   5. Runs the diagnostic to verify
#
# Usage:   bash midan-fix-seed.sh
# ============================================================================

set -euo pipefail
cd "$(dirname "$0")"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "═══════════════════════════════════════════"
echo -e "  ميدان — إصلاح عطل seed + Articles"
echo -e "═══════════════════════════════════════════\n"

# ─── 1. Locate seed.ts ───────────────────────────────────────────────────────
SEED_FILE="prisma/seed.ts"
if [ ! -f "$SEED_FILE" ]; then
  echo -e "${RED}✗ لم يتم العثور على $SEED_FILE${NC}"
  echo "  نفّذ هذا السكربت من جذر المشروع (حيث يوجد package.json)."
  exit 1
fi

# ─── 2. Check if already patched ─────────────────────────────────────────────
if grep -q "TRUNCATE TABLE" "$SEED_FILE"; then
  echo -e "${YELLOW}⚠️  seed.ts يبدو أنه مُعَدَّل مسبقاً (يحتوي TRUNCATE TABLE) — تخطي التعديل${NC}"
else
  # ─── 3. Backup ────────────────────────────────────────────────────────────
  BACKUP="prisma/seed.ts.bak.$(date +%Y%m%d_%H%M%S)"
  cp "$SEED_FILE" "$BACKUP"
  echo -e "${GREEN}✓ نسخة احتياطية: $BACKUP${NC}"

  # ─── 4. Apply patch using node (robust string replacement) ────────────────
  node -e "
const fs = require('fs');
const path = 'prisma/seed.ts';
let src = fs.readFileSync(path, 'utf8');

// Find the block: 'async function main() {\n  console.log(\'🌱 Seeding database...\')\n\n  // Clear existing data\n  await prisma.quizAnswer.deleteMany()\n  ... up to and including 'await prisma.user.deleteMany()'

const startMarker = \"  // Clear existing data\";
const endMarker = \"  await prisma.user.deleteMany()\";

const startIdx = src.indexOf(startMarker);
if (startIdx === -1) { console.error('✗ Could not find start marker'); process.exit(1); }

const endIdx = src.indexOf(endMarker, startIdx);
if (endIdx === -1) { console.error('✗ Could not find end marker'); process.exit(1); }
const endIdxAfter = endIdx + endMarker.length;

const replacement = \`  // ─────────────────────────────────────────────────────────────
  // Reset database — robust, idempotent, FK-order-independent
  // ─────────────────────────────────────────────────────────────
  // The previous implementation called prisma.user.deleteMany() after a handful
  // of sibling deleteMany() calls, but the schema has ~250 models — many of
  // them (AuditLog, Notification, Message, Connection, Follow, Post,
  // PromotionCampaign, …) reference User WITHOUT onDelete: Cascade. Trying to
  // delete User while those tables still hold rows triggers:
  //   Foreign key constraint violated on the constraint: AuditLog_adminId_fkey
  // and aborts the seed halfway — leaving the DB in a broken state where the
  // User table retains stale rows (with stale articlesCount) while the Article
  // table is already empty. That is exactly the bug pattern users see when
  // the profile sidebar shows 'N مقالات' but the Articles tab is empty.
  //
  // Fix: use PostgreSQL TRUNCATE … CASCADE to wipe ALL public tables in a
  // single statement. This (a) bypasses FK ordering entirely, (b) is much
  // faster than per-table deleteMany on large datasets, (c) is idempotent.
  // For SQLite (dev fallback) we keep the explicit ordered deleteMany list,
  // extended with the previously-missing AuditLog/Notification/Message/etc.
  // ─────────────────────────────────────────────────────────────

  const isPostgres = (process.env.DATABASE_URL || '').startsWith('postgres')

  if (isPostgres) {
    console.log('🧹 PostgreSQL detected — TRUNCATE all tables (CASCADE)...')
    const tables = await prisma.\\\$queryRawUnsafe<{ tablename: string }[]>(\\\`
      SELECT tablename
      FROM pg_tables
      WHERE schemaname = 'public'
        AND tablename <> '_prisma_migrations'
      ORDER BY tablename;
    \\\`)
    await prisma.\\\$executeRawUnsafe('SET session_replication_role = replica;')
    try {
      const tableNames = tables.map((t) => \\\`\\\`\\\`\\\${t.tablename}\\\`\\\`\\\`).join(', ')
      if (tableNames) {
        await prisma.\\\$executeRawUnsafe(\\\`TRUNCATE TABLE \\\${tableNames} CASCADE;\\\`)
      }
      console.log(\\\`  ✓ Truncated \\\${tables.length} tables\\\`)
    } finally {
      await prisma.\\\$executeRawUnsafe('SET session_replication_role = origin;')
    }
  } else {
    console.log('🧹 SQLite detected — ordered deleteMany (FK-safe order)...')
    await prisma.auditLog.deleteMany()
    await prisma.notification.deleteMany()
    await prisma.message.deleteMany()
    await prisma.conversationParticipant.deleteMany()
    await prisma.conversation.deleteMany()
    await prisma.connection.deleteMany()
    await prisma.follow.deleteMany()
    await prisma.userActivityLog.deleteMany()
    await prisma.userActivity.deleteMany()
    await prisma.passwordResetCode.deleteMany()
    await prisma.userSession.deleteMany()
    await prisma.systemError.deleteMany()
    await prisma.errorReport.deleteMany()
    await prisma.securityEvent.deleteMany()
    await prisma.apiKeyRecord.deleteMany()
    await prisma.accountDeletionRequest.deleteMany()
    await prisma.passwordChangeLog.deleteMany()
    await prisma.profileView.deleteMany()
    await prisma.profileViewLog.deleteMany()
    await prisma.readingListItem.deleteMany()
    await prisma.readingList.deleteMany()
    await prisma.post.deleteMany()
    await prisma.repost.deleteMany()
    await prisma.promotionCampaign.deleteMany()
    await prisma.ad.deleteMany()
    await prisma.advertiserAccount.deleteMany()
    await prisma.payment.deleteMany()
    await prisma.invoice.deleteMany()
    await prisma.walletTransaction.deleteMany()
    await prisma.wallet.deleteMany()
    await prisma.subscription.deleteMany()
    await prisma.commission.deleteMany()
    await prisma.referral.deleteMany()
    await prisma.pushSubscription.deleteMany()
    await prisma.quizAnswer.deleteMany()
    await prisma.quizOptionRecord.deleteMany()
    await prisma.quizAttempt.deleteMany()
    await prisma.quizQuestion.deleteMany()
    await prisma.quiz.deleteMany()
    await prisma.userLessonProgress.deleteMany()
    await prisma.lesson.deleteMany()
    await prisma.learningPath.deleteMany()
    await prisma.articleTag.deleteMany()
    await prisma.hashtag.deleteMany()
    await prisma.economicTerm.deleteMany()
    await prisma.like.deleteMany()
    await prisma.discussionReply.deleteMany()
    await prisma.discussionMedia.deleteMany()
    await prisma.discussion.deleteMany()
    await prisma.comment.deleteMany()
    await prisma.articleMedia.deleteMany()
    await prisma.article.deleteMany()
    await prisma.job.deleteMany()
    await prisma.siteSettings.deleteMany()
    await prisma.pricingConfig.deleteMany()
    await prisma.paymentDestination.deleteMany()
    await prisma.user.deleteMany()
    console.log('  ✓ Cleared all tables in FK-safe order')
  }\`;

const newSrc = src.slice(0, startIdx) + replacement + src.slice(endIdxAfter);
fs.writeFileSync(path, newSrc);
console.log('✓ seed.ts patched');
"

  if [ $? -ne 0 ]; then
    echo -e "${RED}✗ فشل تطبيق التعديل تلقائياً${NC}"
    echo "  طبّق التعديل يدوياً (راجع التعليمات في المحادثة)."
    exit 1
  fi
  echo -e "${GREEN}✓ تم تعديل seed.ts${NC}"
fi

# ─── 5. Create scripts/diagnose-articles.ts ──────────────────────────────────
mkdir -p scripts
cat > scripts/diagnose-articles.ts << 'TS_EOF'
/**
 * diagnose-articles.ts
 *
 * Diagnostic — answers: "Why does profile show 'N مقالات' but Articles tab is empty?"
 *
 * Run:  npx tsx scripts/diagnose-articles.ts
 */
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('\n🔬 Midan — articles diagnostic\n')

  const [userCount, articleCount, publishedCount] = await Promise.all([
    prisma.user.count(),
    prisma.article.count(),
    prisma.article.count({ where: { status: 'PUBLISHED', deletedAt: null } }),
  ])
  console.log(`Users:                    ${userCount}`)
  console.log(`Articles (total):         ${articleCount}`)
  console.log(`Articles (PUBLISHED):     ${publishedCount}`)

  if (publishedCount === 0) {
    console.log('\n⚠️  No PUBLISHED articles in the database.')
    console.log('   This is why every profile shows "لا توجد مقالات".')
  }

  console.log('\n─ Per-user articlesCount vs actual PUBLISHED count ─')
  const users = await prisma.user.findMany({
    select: {
      id: true,
      name: true,
      articlesCount: true,
      articles: {
        where: { status: 'PUBLISHED', deletedAt: null },
        select: { id: true, title: true, publishedAt: true, createdAt: true },
      },
    },
    take: 50,
  })

  let driftCount = 0
  for (const u of users) {
    const actual = u.articles.length
    const cached = u.articlesCount || 0
    if (actual !== cached) {
      driftCount++
      console.log(`  ✗ ${u.id.padEnd(20)} | cached=${cached}  actual=${actual}  ← DRIFT`)
    } else if (cached > 0) {
      console.log(`  ✓ ${u.id.padEnd(20)} | cached=${cached}  actual=${actual}`)
      for (const a of u.articles) {
        console.log(`      • ${a.title.slice(0, 60)}  (publishedAt=${a.publishedAt?.toISOString() || 'null'})`)
      }
    }
  }

  if (driftCount > 0) {
    console.log(`\n❌ ${driftCount} user(s) have stale articlesCount.`)
    console.log('   Fix: re-run `npm run db:seed` (now using TRUNCATE CASCADE).')
  } else if (publishedCount > 0) {
    console.log('\n✅ All counters are in sync.')
  } else {
    console.log('\n✓ Counters are in sync (but DB is empty — run the seed).')
  }

  console.log('')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })
TS_EOF
echo -e "${GREEN}✓ تم إنشاء scripts/diagnose-articles.ts${NC}"

# ─── 6. Run the seed ─────────────────────────────────────────────────────────
echo -e "\n${YELLOW}【3/4】 إعادة تشغيل seed (سيتم مسح كل البيانات وإعادة إنشائها)...${NC}"
npm run db:seed

# ─── 7. Run diagnostic ───────────────────────────────────────────────────────
echo -e "\n${YELLOW}【4/4】 تشخيص الحالة بعد seed...${NC}"
npx tsx scripts/diagnose-articles.ts || true

echo -e "\n${GREEN}═══════════════════════════════════════════${NC}"
echo -e "${GREEN}  ✓ اكتمل الإصلاح${NC}"
echo -e "${GREEN}═══════════════════════════════════════════${NC}"
echo ""
echo "الخطوات التالية:"
echo "  1. أعد تشغيل الخادم:  npm run dev"
echo "  2. افتح: http://localhost:3300/profile/user_owner"
echo "  3. يجب أن ترى مقالات فعلية في تبويب 'المقالات'"
echo ""
