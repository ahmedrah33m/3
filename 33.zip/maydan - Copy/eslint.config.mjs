import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";
import { dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const eslintConfig = [{
  ignores: [
    "node_modules/**",
    ".next/**",
    "out/**",
    "build/**",
    ".next",
    "next-env.d.ts",
    "examples/**",
    "skills/**",
    "scripts/**",
    "*.config.*",
    ".opencode/**",
    "src/lib/features/_archived/**",
    "src/components/jobs/COMPONENT_SPLITTING_GUIDE.ts",
    "midan-telegram-fix/**",
  ]
}, ...nextCoreWebVitals, ...nextTypescript, {
  rules: {
    // TypeScript rules — re-enabled for safety
    "@typescript-eslint/no-explicit-any": "warn",
    "@typescript-eslint/no-unused-vars": ["warn", { argsIgnorePattern: "^_", varsIgnorePattern: "^_" }],
    "@typescript-eslint/no-non-null-assertion": "warn",
    "@typescript-eslint/ban-ts-comment": ["warn", { "ts-ignore": "allow-with-description" }],
    "@typescript-eslint/prefer-as-const": "warn",

    // React rules
    "react-hooks/exhaustive-deps": "warn",
    "react-hooks/refs": "off",
    "react-hooks/set-state-in-effect": "off",
    "react-hooks/immutability": "off",
    "react-hooks/create-components": "off",
    "react-hooks/static-components": "off",
    "react-hooks/purity": "off",
    "react/no-unescaped-entities": "off",
    "react/display-name": "off",
    "react/prop-types": "off",

    // Next.js rules
    "@next/next/no-img-element": "warn",
    "@next/next/no-html-link-for-pages": "warn",

    // General JavaScript rules
    "prefer-const": "warn",
    "no-unused-vars": "off", // handled by @typescript-eslint/no-unused-vars
    "no-console": ["warn", { allow: ["warn", "error"] }],
    "no-debugger": "error",
    "no-empty": "warn",
    "no-irregular-whitespace": "warn",
    "no-case-declarations": "warn",
    "no-fallthrough": "warn",
    "no-mixed-spaces-and-tabs": "warn",
    "no-redeclare": "warn",
    "no-unreachable": "warn",
    "no-useless-escape": "warn",
  },
}, {
  // Override: allow all console methods in the app-logger module (it IS the logging layer)
  files: ["src/lib/app-logger.ts"],
  rules: {
    "no-console": "off",
  },
}, {
  // Seed files and diagnostic scripts — utility scripts, not app code
  files: ["prisma/seed*.{ts,js}", "seed.{ts,js}", "diagnose-articles.ts"],
  rules: {
    "no-console": "off",
    "@typescript-eslint/no-explicit-any": "off",
  },
}, {
  // JS scripts (scripts/, *.js) need require()
  files: ["**/*.js", "scripts/**"],
  rules: {
    "@typescript-eslint/no-require-imports": "off",
  },
}];

export default eslintConfig;
