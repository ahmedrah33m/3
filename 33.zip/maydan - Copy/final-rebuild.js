const fs = require('fs');

// Read all addition files
const additionFiles = [
  'prisma/schema-additions-payroll.prisma',
  'prisma/schema-additions-employment-verification.prisma',
  'prisma/schema-additions-onboarding.prisma',
  'prisma/schema-additions-live-rooms.prisma',
];

// Parse models from content
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

// Parse original schema
const originalContent = fs.readFileSync('prisma/schema.prisma', 'utf8');
const originalModels = parseModels(originalContent);
console.log('Original models:', originalModels.size);

// Parse all additions
const allAdditionModels = new Map();
for (const file of additionFiles) {
  const content = fs.readFileSync(file, 'utf8');
  for (const [name, lines] of parseModels(content)) {
    allAdditionModels.set(name, lines);
  }
}
console.log('Addition models:', allAdditionModels.size);

// Find new models that don't exist in original
const originalNames = new Set([...originalModels.keys()]);
const newModels = new Map();
for (const [name, lines] of allAdditionModels) {
  if (!originalNames.has(name)) {
    newModels.set(name, lines);
  }
}
console.log('New models to add:', newModels.size);

// Find what back-relations each existing model needs
const backRelations = new Map();
for (const [name, lines] of newModels) {
  for (const line of lines) {
    // Check for @relation fields
    const match = line.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
    if (match) {
      const fieldName = match[1];
      const referencedModel = match[2];
      if (originalNames.has(referencedModel)) {
        if (!backRelations.has(referencedModel)) {
          backRelations.set(referencedModel, new Set());
        }
        backRelations.get(referencedModel).add(line.trim());
      }
    }
  }
}
console.log('Models needing back-relations:', backRelations.size);

// Rebuild schema
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

// Add all original models with back-relations
for (const [name, lines] of originalModels) {
  const rels = backRelations.get(name);
  if (rels && rels.size > 0) {
    // Find closing brace and insert back-relations before it
    const closingIdx = lines.length - 1;
    const newLines = [...lines];
    newLines.splice(closingIdx, 0, '', '  // Back-relations', ...[...rels].map(r => '  ' + r));
    output.push(...newLines);
  } else {
    output.push(...lines);
  }
  output.push('');
}

// Add new models
output.push('// ============================================');
output.push('// New Models from Additions');
output.push('// ============================================');
output.push('');

for (const [name, lines] of newModels) {
  output.push(...lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
