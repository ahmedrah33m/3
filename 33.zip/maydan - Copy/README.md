# ربط OwnerPanel و Wallet بالخدمات المدفوعة + توحيد الأسعار

## الفكرة العامة

كان نظام التسعير في المنصة مُجزّأ إلى 3 مصادر غير متصلة:

1. **جدول `ServicePrice`** (الموحّد، يُدار من OwnerPanel) — يستخدمه فقط `job.service.ts`
2. **جدول `PricingConfig`** (قديم) — يستخدمه `cv-builder/route.ts` و `users/[id]/resume/route.ts`
3. **أسعار hardcoded** في الكود — في `articles/promote`, `cv-service`, `subscriptions`, `mentorship/request`

النتيجة: المالك يضبط الأسعار في `OwnerPanel → PricingManagement` لكنها **لا تُطبَّق** على معظم الخدمات المدفوعة.

بعد التعديل، أصبح كل شيء موصولاً عبر دالة موحّدة `getServicePrice()`.

---

## مخطط التدفق بعد الربط

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   OwnerPanel (PricingManagement.tsx)                            │
│   ──────────────────────────────────                             │
│   يضبط الأسعار → PUT /api/owner/pricing                         │
│                          ↓                                       │
│   ┌──────────────────────────────────────────────┐              │
│   │  جدول ServicePrice (مصدر الحقيقة الوحيد)     │              │
│   │  - serviceKey, price, currency               │              │
│   │  - isFree, isActive                          │              │
│   └──────────────────────────────────────────────┘              │
│                          ↓                                       │
│   getServicePrice('KEY')  ←── يقرأ منها كل routes المدفوعة      │
│   ┌──────────────────────────────────────────────┐              │
│   │  /api/cv-builder          (CV_BUILDER)       │              │
│   │  /api/users/[id]/resume   (CV_BUILDER)       │              │
│   │  /api/cv-service          (CV_BUILDER)       │              │
│   │  /api/articles/promote    (PROMOTION)        │              │
│   │  /api/mentorship/request  (MENTORSHIP)       │              │
│   │  /api/subscriptions       (SUBSCRIPTION)     │              │
│   │  /api/jobs (via job.service) (JOB_POST)      │              │
│   └──────────────────────────────────────────────┘              │
│                          ↓                                       │
│   payFromWallet({ amount: price.priceIQD, ... })                │
│                          ↓                                       │
│   ┌──────────────────────────────────────────────┐              │
│   │  Wallet (محفظة ميدان)                         │              │
│   │  - تخصم المبلغ من رصيد المستخدم               │              │
│   │  - تنشئ فاتورة                                │              │
│   │  - تدفع حصة الخبير (إن وُجد)                  │              │
│   └──────────────────────────────────────────────┘              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

عرض الأسعار للمستخدم:
  /api/pricing (public GET)
       ↓
  ┌─────────────────────────────────────┐
  │  صفحة /wallet                       │
  │  ─────────────                      │
  │  ┌─────────────────────────────┐    │
  │  │ PaidServicesCard            │    │
  │  │ (مكوّن جديد)                 │    │
  │  │ - يعرض كل خدمة + سعرها       │    │
  │  │ - رابط مباشر لصفحة الخدمة    │    │
  │  └─────────────────────────────┘    │
  └─────────────────────────────────────┘
```

---

## الملفات المعدّلة (11 ملف)

### 1) `src/lib/wallet-service.ts` — أضيف دالتان جديدتان

```ts
getServicePrice(serviceKey): Promise<ServicePriceResult>
getServicePriceIQD(serviceKey): Promise<number>   // shortcut
```

أولوية الحصول على السعر:
1. جدول `ServicePrice` (مصدر أساسي — يتحكم به المالك)
2. جدول `PricingConfig` القديم (للخدمات CV_BUILDER و JOB_POST فقط، للحفاظ على التوافق)
3. hardcoded fallback (آخر احتياط)

كل نتيجة تحتوي على:
- `priceIQD` — جاهز للتمرير إلى `payFromWallet()`
- `isFree` — true عندما يحدد المالك الخدمة كمجانية
- `isActive` — false عندما يوقف المالك الخدمة
- `source` — 'db' | 'fallback' | 'legacy' (للتشخيص)

### 2) API routes التي تم ربطها بـ `ServicePrice`

| الملف | الخدمة | التغيير |
|---|---|---|
| `api/cv-builder/route.ts` | CV_BUILDER | استبدال `db.pricingConfig` بـ `getServicePrice('CV_BUILDER')` |
| `api/users/[id]/resume/route.ts` | CV_BUILDER | استبدال `db.pricingConfig` بـ `getServicePrice('CV_BUILDER')` |
| `api/cv-service/route.ts` | CV_BUILDER | استخدام `getServicePrice('CV_BUILDER')` مع مضاعف حسب النوع (BASIC=1×, PREMIUM=2×, EXPERT_REVIEW=3×) |
| `api/articles/promote/route.ts` | PROMOTION | استخدام `getServicePrice('PROMOTION')` مع تحجيم عدد الأيام |
| `api/mentorship/request/route.ts` | MENTORSHIP | أولوية: سعر من body → ServicePrice → fallback |
| `api/subscriptions/route.ts` | SUBSCRIPTION | استخدام `getServicePrice('SUBSCRIPTION')` (PREMIUM = 3× BASIC) |
| `api/pricing/route.ts` | (public) | أعيدت كتابته ليعرض كل `ServicePrice` للعموم + حقول legacy للتوافق |

### 3) ملفات الواجهة الأمامية

| الملف | التغيير |
|---|---|
| `components/wallet/PaidServicesCard.tsx` | **ملف جديد** — يعرض كل خدمة مدفوعة وسعرها الحالي في صفحة /wallet، مع رابط مباشر لصفحة الخدمة |
| `app/(main)/wallet/page.tsx` | أُضيف `import PaidServicesCard` ووُضع المكوّن بعد قسم "Action Buttons" مباشرة |
| `components/owner/PricingManagement.tsx` | أُضيف زر "معاينة في المحفظة" بجانب زر "حفظ التسعير" — يفتح /wallet ليرى المالك ما سيراه المستخدمون |

---

## كيفية التثبيت

1. فك ضغط الأرشيف في جذر مشروعك:

```bash
cd /path/to/maydan
unzip owner-wallet-link.zip -d .
# سيستبدل الملفات في مساراتها الصحيحة
```

2. أعد بناء المشروع:

```bash
npm run build
```

3. تأكد من أن جدول `ServicePrice` موجود في قاعدة البيانات (الـ schema موجود مسبقاً في `prisma/schema.prisma`):
```bash
npx prisma db push
```

---

## كيفية الاستخدام بعد التثبيت

### للمالك (Owner):

1. ادخل `/owner-panel` → تبويب **"التسعير والدفع"** (Pricing)
2. ستظهر قائمة بكل الخدمات (15+ خدمة مقسّمة على 5 فئات)
3. لكل خدمة:
   - **السعر**: بالدينار العراقي (IQD) أو الدولار (USD)
   - **مجاني/مدفوع**: زر تبديل سريع
   - **تفعيل/تعطيل**: لإيقاف خدمة كلياً
4. اضغط **"حفظ التسعير"**
5. اضغط **"معاينة في المحفظة"** لرؤية كيف ستظهر الأسعار للمستخدمين

### للمستخدم العادي:

1. يدخل `/wallet`
2. يرى بطاقة **"الخدمات المدفوعة"** جديدة تعرض:
   - كل خدمة مع سعرها الحالي (أو "مجاني")
   - وصف موجز لكل خدمة
   - أيقونة واضحة + اسم عربي
   - بالضغط على أي خدمة → ينتقل مباشرة لصفحتها
3. عند استخدام أي خدمة (مثلاً بناء سيرة ذاتية)، يُخصم السعر من رصيد محفظته تلقائياً

### منطق الأسعار (مهم):

- إذا حدد المالك سعراً > 0 → يُستخدم هذا السعر
- إذا حدد `isFree = true` → السعر 0 (مجاني للمستخدم)
- إذا عطّل الخدمة (`isActive = false`) → تُرفض الطلبات برسالة "الخدمة غير متاحة حالياً"
- الأسعار تُخزَّن بـ USD أو IQD، وتُحوَّل تلقائياً لـ IQD (USD × 1500) قبل الخصم من المحفظة

---

## اختبار سريع بعد التثبيت

```bash
# 1. شغّل الخادم
npm run dev

# 2. سجّل دخول كـ OWNER
# 3. اذهب إلى /owner-panel → Pricing
# 4. غيّر سعر "CV_BUILDER" إلى 30000 IQD واحفظ
# 5. اذهب إلى /wallet → يجب أن ترى "بناء سيرة ذاتية — 30,000 د.ع"
# 6. اذهب إلى /cv-builder وادفع → يجب أن يُخصم 30000 من محفظتك
# 7. ارجع لـ OwnerPanel واجعل CV_BUILDER "مجاني" واحفظ
# 8. اذهب لـ /wallet → يجب أن ترى "بناء سيرة ذاتية — مجاني"
# 9. اذهب لـ /cv-builder واحفظ → يجب أن يكتمل بدون خصم
```
