import type { NextConfig } from "next";
import path from "path";

const projectRoot = path.resolve(__dirname);
const isProduction = process.env.NODE_ENV === 'production';

const nextConfig = {
  output: "standalone",
  reactStrictMode: true,
  // TypeScript checking is ENABLED — build-time type-checking runs `tsc` and
  // fails the build on errors. `npx tsc --noEmit` was verified at 0 errors
  // (2026-09-05: 90 pre-existing errors fixed across routes, services, components).
  // The earlier build OOM was solved correctly via NODE_OPTIONS --max-old-space-size
  // in the Dockerfile builder stage (NOT by disabling the check).
  // eslint config has been removed from next.config.ts in Next.js 16.
  // Use `eslint.config.mjs` at the project root instead.

  // Compression — enable gzip compression for API responses (important for 100K users)
  compress: true,

  // Allow cross-origin requests in development
  // Next.js 16 requires hostname format (not full URLs)
  allowedDevOrigins: [
    'midaniq.com',
    'www.midaniq.com',
    '192.168.88.121',
    'localhost',
    '127.0.0.1',
  ],

  // Increase body size limit for file uploads
  // In Next.js 15.3+, this applies to both Server Actions AND Route Handlers
  experimental: {
    serverActions: {
      bodySizeLimit: '100mb',
    },
    // Optimize package imports for faster builds and smaller bundles
    optimizePackageImports: [
      '@radix-ui/react-icons',
      'lucide-react',
      'recharts',
      'date-fns',
      'react-markdown',
      'react-syntax-highlighter',
      'framer-motion',
    ],
    // Fix HMR "module factory is not available" errors in Next.js 16.1.3 Turbopack
    // Stale module references cause factory lookup failures during HMR updates.
    // Setting dynamic=0 forces Turbopack to re-resolve dynamic route modules on each update,
    // preventing the "deleted in HMR update" error for boundary-components.js etc.
    staleTimes: {
      dynamic: 0,
      static: 300,
    },
  },

  // Constrain Turbopack/webpack resolution
  // NOTE: outputFileTracingRoot is only for production standalone builds.
  // It should NOT be combined with turbopack.root in development —
  // doing so causes Turbopack HMR module factory errors (Next.js 16.1.3).
  // outputFileTracingRoot is set only in production below.
  turbopack: {},

  // Only apply outputFileTracingRoot in production (standalone build)
  // In development, this conflicts with Turbopack's module resolution
  ...(isProduction ? { outputFileTracingRoot: projectRoot } : {}),

  // Headers — Security and caching
  async headers() {
    const headersList: Array<{ source: string; headers: Array<{ key: string; value: string }> }> = [
      {
        // Apply security headers to all routes
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
          // Content Security Policy — restricts sources for scripts, styles, images, etc.
          // In production, tighten CSP to only allow self-hosted resources.
          // 'unsafe-inline' is required for Next.js inline styles; 'unsafe-eval' only in dev.
          {
            key: 'Content-Security-Policy',
            value: isProduction
              ? "default-src 'self'; script-src 'self' 'unsafe-inline' https://accounts.google.com https://apis.google.com https://static.cloudflareinsights.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https:; media-src 'self' blob: https:; frame-src https://www.youtube.com https://www.youtube-nocookie.com https://player.vimeo.com https://www.facebook.com https://www.facebook.net; connect-src 'self' https://accounts.google.com https://static.cloudflareinsights.com http://minio:9000 https://a.tile.openstreetmap.org https://b.tile.openstreetmap.org https://c.tile.openstreetmap.org https://www.geoboundaries.org https://github.com ${process.env.S3_PUBLIC_URL || ''}; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
              : "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://static.cloudflareinsights.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https: http:; media-src 'self' blob: https:; frame-src https://www.youtube.com https://www.youtube-nocookie.com https://player.vimeo.com https://www.facebook.com https://www.facebook.net; connect-src 'self' http://localhost:* ws://localhost:* https://static.cloudflareinsights.com https://a.tile.openstreetmap.org https://b.tile.openstreetmap.org https://c.tile.openstreetmap.org https://www.geoboundaries.org https://github.com; frame-ancestors 'none'",
          },
          // Strict-Transport-Security — force HTTPS for 1 year, include subdomains
          { key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains; preload' },
        ],
      },
    ]

    // Only add static caching headers in production
    // (Next.js manages dev caching internally — custom Cache-Control breaks dev HMR)
    if (isProduction) {
      headersList.push({
        source: '/_next/static/(.*)',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      })
    }

    headersList.push({
      // Cache uploaded images — files are UUID-named and never mutated,
      // so they can be cached as immutable (matches the serving route).
      source: '/uploads/(.*)',
      headers: [
        { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
      ],
    })

    // Service Worker must never be cached — always fetch the latest version
    headersList.push({
      source: '/sw.js',
      headers: [
        { key: 'Cache-Control', value: 'no-cache, no-store, must-revalidate' },
      ],
    })

    // Manifest should be revalidated frequently
    headersList.push({
      source: '/manifest.json',
      headers: [
        { key: 'Cache-Control', value: 'public, max-age=0, must-revalidate' },
      ],
    })

    return headersList
  },

  // Image optimization configuration
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'localhost' },
      { protocol: 'http', hostname: 'localhost' },
      { protocol: 'https', hostname: 'midaniq.com' },
      { protocol: 'http', hostname: 'midaniq.com' },
      
      { protocol: 'https', hostname: '**.cloudinary.com' },
      { protocol: 'https', hostname: '**.amazonaws.com' },
      { protocol: 'https', hostname: 'avatars.githubusercontent.com' },
      { protocol: 'https', hostname: 'lh3.googleusercontent.com' },
    ],
    localPatterns: [
      {
        pathname: '/uploads/**',
      },
    ],
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200],
    imageSizes: [16, 32, 48, 64, 96, 128, 256],
    // Increase minimum cache TTL for optimized images
    minimumCacheTTL: 3600,
  },

  // ── Community merge redirects ──────────────────────────────────────
  // questions/polls merged into /discussions tabs, chat-rooms into /messages.
  // Config-level redirects run before the filesystem -> returns real 307
  // (permanent: false) with Location header instead of a prerendered
  // meta-refresh page. Page-level redirect() files remain as a fallback
  // for locale-prefixed paths and client-side navigation.
  async redirects() {
    return [
      { source: '/questions', destination: '/discussions?tab=questions', permanent: false },
      { source: '/polls', destination: '/discussions?tab=polls', permanent: false },
      { source: '/chat-rooms', destination: '/messages?tab=rooms', permanent: false },
      // economy pages merged into /economy (اقتصاد السوق)
      { source: '/economy/market', destination: '/economy', permanent: true },
      { source: '/economy/converter', destination: '/economy', permanent: true },
      { source: '/economy/calendar', destination: '/economy', permanent: true },
      { source: '/economy/map', destination: '/economy', permanent: true },
      // premium merged into /wallet (محفظة ميدان)
      { source: '/premium', destination: '/wallet?tab=premium', permanent: true },
      // career path merged into /jobs (الوظائف والمسار المهني)
      { source: '/cv-builder', destination: '/jobs?tab=cv', permanent: true },
      { source: '/professional-passport', destination: '/jobs?tab=passport', permanent: true },
      { source: '/reputation', destination: '/jobs?tab=reputation', permanent: true },
      { source: '/jobs/candidate/applied', destination: '/jobs?tab=applications', permanent: true },
      { source: '/jobs/candidate/interviews', destination: '/jobs?tab=interviews', permanent: true },
    ]
  },

  // ── Locale prefix rewrites ─────────────────────────────────────────
  // Pages live under (main)/ route-group (no locale segment).
  // Links generate /en/search, /ar/dashboard etc.
  // Strip locale prefix so Next.js resolves to the correct page.
  // Exclude: auth, owner/pricing, community, companies, settings (kept for URL compatibility)
  async rewrites() {
    return [
      {
        source: '/:locale(en|ar|fr|tr|ur)/:path((?!auth/|owner/pricing|community|companies|settings).*)*',
        destination: '/:path*',
      },
    ]
  },
} as NextConfig;

export default nextConfig;
