#!/bin/bash
# ============================================
# Maydan Al-Iqtisad - Permanent Service Manager
# ميدان الاقتصاد - مدير التشغيل الدائم
# ============================================

PROJECT_DIR="$HOME/maydan"
PORT=3300
PID_FILE="$PROJECT_DIR/.next-server.pid"
LOG_FILE="$PROJECT_DIR/server.log"
CF_PID_FILE="$PROJECT_DIR/.cloudflared.pid"
CF_LOG_FILE="$PROJECT_DIR/cloudflared.log"

# Load environment variables from .env (so CLOUDFLARE_TUNNEL_TOKEN etc. work)
if [ -f "$PROJECT_DIR/.env" ]; then
  set -a
  . "$PROJECT_DIR/.env"
  set +a
fi

# JWT Secret (generate once and save)
JWT_FILE="$PROJECT_DIR/.jwt-secret"
if [ ! -f "$JWT_FILE" ]; then
  openssl rand -hex 32 > "$JWT_FILE"
fi
JWT_SECRET=$(cat "$JWT_FILE")

start_server() {
  if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
    echo "⚠️  Next.js server already running (PID: $(cat "$PID_FILE"))"
    return 1
  fi

  echo "🚀 Starting Maydan Next.js server on port $PORT..."
  cd "$PROJECT_DIR"
  
  JWT_SECRET="$JWT_SECRET" nohup node .next/standalone/server.js \
    -p $PORT \
    >> "$LOG_FILE" 2>&1 &
  
  echo $! > "$PID_FILE"
  
  # Wait for server to be ready
  for i in $(seq 1 30); do
    if curl -s "http://localhost:$PORT" > /dev/null 2>&1; then
      echo "✅ Next.js server started successfully (PID: $(cat "$PID_FILE"))"
      echo "   📍 http://localhost:$PORT"
      return 0
    fi
    sleep 1
  done
  
  echo "❌ Server failed to start. Check $LOG_FILE"
  return 1
}

stop_server() {
  if [ ! -f "$PID_FILE" ]; then
    echo "⚠️  No server PID file found"
    return 0
  fi
  
  PID=$(cat "$PID_FILE")
  if kill -0 "$PID" 2>/dev/null; then
    echo "🛑 Stopping Next.js server (PID: $PID)..."
    kill "$PID" 2>/dev/null
    sleep 2
    # Force kill if still running
    if kill -0 "$PID" 2>/dev/null; then
      kill -9 "$PID" 2>/dev/null
    fi
    rm -f "$PID_FILE"
    echo "✅ Server stopped"
  else
    echo "⚠️  Server process not found (stale PID)"
    rm -f "$PID_FILE"
  fi
}

start_tunnel() {
  if [ -f "$CF_PID_FILE" ] && kill -0 $(cat "$CF_PID_FILE") 2>/dev/null; then
    echo "⚠️  Cloudflared tunnel already running (PID: $(cat "$CF_PID_FILE"))"
    return 1
  fi

  # ⚠️  تنبيه أمني: لا تُصلّب الـ token هنا. استخدم متغير البيئة CLOUDFLARE_TUNNEL_TOKEN.
  # أنشئ tunnel جديد في Cloudflare Zero Trust > Tunnels واحفظ الـ token في .env
  CF_TOKEN="${CLOUDFLARE_TUNNEL_TOKEN:?يجب تعيين CLOUDFLARE_TUNNEL_TOKEN في .env أو كمتغير بيئة. أنشئ tunnel جديد من Cloudflare Zero Trust dashboard.}"
  
  echo "🌐 Starting Cloudflare Tunnel..."
  nohup cloudflared tunnel run \
    --token "$CF_TOKEN" \
    >> "$CF_LOG_FILE" 2>&1 &
  
  echo $! > "$CF_PID_FILE"
  sleep 3
  
  if kill -0 $(cat "$CF_PID_FILE") 2>/dev/null; then
    echo "✅ Cloudflare Tunnel started (PID: $(cat "$CF_PID_FILE"))"
    echo "   🌍 Connected via Cloudflare"
    return 0
  else
    echo "❌ Tunnel failed to start. Check $CF_LOG_FILE"
    return 1
  fi
}

stop_tunnel() {
  if [ ! -f "$CF_PID_FILE" ]; then
    echo "⚠️  No tunnel PID file found"
    return 0
  fi
  
  PID=$(cat "$CF_PID_FILE")
  if kill -0 "$PID" 2>/dev/null; then
    echo "🛑 Stopping Cloudflare Tunnel (PID: $PID)..."
    kill "$PID" 2>/dev/null
    sleep 2
    if kill -0 "$PID" 2>/dev/null; then
      kill -9 "$PID" 2>/dev/null
    fi
    rm -f "$CF_PID_FILE"
    echo "✅ Tunnel stopped"
  else
    echo "⚠️  Tunnel process not found (stale PID)"
    rm -f "$CF_PID_FILE"
  fi
}

status() {
  echo "📊 Maydan Service Status"
  echo "========================"
  
  # Server status
  if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
    PID=$(cat "$PID_FILE")
    MEM=$(ps -o rss= -p "$PID" 2>/dev/null | awk '{printf "%.1f MB", $1/1024}')
    CPU=$(ps -o %cpu= -p "$PID" 2>/dev/null | tr -d ' ')
    echo "🟢 Next.js Server: Running (PID: $PID, Memory: $MEM, CPU: ${CPU}%)"
  else
    echo "🔴 Next.js Server: Stopped"
  fi
  
  # Tunnel status
  if [ -f "$CF_PID_FILE" ] && kill -0 $(cat "$CF_PID_FILE") 2>/dev/null; then
    PID=$(cat "$CF_PID_FILE")
    echo "🟢 Cloudflare Tunnel: Running (PID: $PID)"
  else
    echo "🔴 Cloudflare Tunnel: Stopped"
  fi
  
  echo ""
  echo "📁 Project: $PROJECT_DIR"
  echo "📋 Server log: $LOG_FILE"
  echo "📋 Tunnel log: $CF_LOG_FILE"
}

logs() {
  local target="${1:-server}"
  if [ "$target" = "tunnel" ] || [ "$target" = "cf" ]; then
    tail -f "$CF_LOG_FILE"
  else
    tail -f "$LOG_FILE"
  fi
}

case "${1:-}" in
  start)
    start_server
    start_tunnel
    ;;
  stop)
    stop_tunnel
    stop_server
    ;;
  restart)
    stop_tunnel
    stop_server
    sleep 2
    start_server
    start_tunnel
    ;;
  server)
    start_server
    ;;
  tunnel)
    start_tunnel
    ;;
  status)
    status
    ;;
  logs)
    logs "${2:-server}"
    ;;
  seed-dictionary)
    cd "$PROJECT_DIR"
    npx tsx prisma/seed-dictionary.ts
    ;;
  *)
    echo "📋 Maydan Al-Iqtisad - Service Manager"
    echo "======================================="
    echo ""
    echo "Usage: $0 {start|stop|restart|server|tunnel|status|logs|seed-dictionary}"
    echo ""
    echo "Commands:"
    echo "  start             Start server + tunnel"
    echo "  stop              Stop server + tunnel"
    echo "  restart           Restart everything"
    echo "  server            Start Next.js server only"
    echo "  tunnel            Start Cloudflare tunnel only"
    echo "  status            Show service status"
    echo "  logs [server|tunnel]  Show logs (default: server)"
    echo "  seed-dictionary   Seed dictionary terms"
    ;;
esac
