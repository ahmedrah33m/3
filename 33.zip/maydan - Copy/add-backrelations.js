const fs = require('fs');

// Read current schema
const content = fs.readFileSync('prisma/schema.prisma', 'utf8');
const lines = content.split('\n');

// Parse models
function parseModels(content) {
  const lines = content.split('\n');
  const models = new Map();
  let currentModel = null;
  let currentLines = [];
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (currentModel) models.set(currentModel, currentLines);
      currentModel = match[1];
      currentLines = [line];
      braceCount = 1;
    } else if (currentModel) {
      currentLines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        models.set(currentModel, currentLines);
        currentModel = null;
        currentLines = [];
      }
    }
  }
  if (currentModel) models.set(currentModel, currentLines);
  return models;
}

const models = parseModels(content);
console.log('Total models:', models.size);

// Find models that need back-relations
// (models that are referenced by other models with @relation)
const backRelationsNeeded = new Map();

for (const [name, modelLines] of models) {
  for (const line of modelLines) {
    const match = line.match(/^\s+(\w+)\s+(\w+)\??\s*@relation/);
    if (match) {
      const fieldName = match[1];
      const referencedModel = match[2];
      if (models.has(referencedModel)) {
        if (!backRelationsNeeded.has(referencedModel)) {
          backRelationsNeeded.set(referencedModel, new Set());
        }
        backRelationsNeeded.get(referencedModel).add(line.trim());
      }
    }
  }
}

console.log('Models needing back-relations:', backRelationsNeeded.size);

// Rebuild schema with back-relations
const output = [];
let currentModel = null;
let braceCount = 0;
let inModel = false;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const trimmed = line.trim();
  
  const match = trimmed.match(/^model (\w+) \{/);
  if (match) {
    currentModel = match[1];
    inModel = true;
    braceCount = 1;
    output.push(line);
    continue;
  }
  
  if (inModel) {
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    
    if (braceCount === 0 && line.includes('}')) {
      // Add back-relations before closing brace
      const rels = backRelationsNeeded.get(currentModel);
      if (rels && rels.size > 0) {
        // Check if back-relations already exist
        const modelStart = output.findIndex(l => l.includes(`model ${currentModel} {`));
        const modelContent = output.slice(modelStart).join('\n');
        
        for (const rel of rels) {
          const fieldName = rel.split(' ')[0];
          if (!modelContent.includes(fieldName)) {
            output.push('  ' + rel);
          }
        }
      }
      
      output.push(line);
      inModel = false;
      currentModel = null;
      continue;
    }
    
    output.push(line);
    continue;
  }
  
  output.push(line);
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Done!');
