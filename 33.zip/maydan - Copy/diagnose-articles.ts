/**
 * diagnose-articles.ts
 *
 * Diagnostic script — answers the question:
 *   "Why does the profile show '1 مقالات' but the Articles tab is empty?"
 *
 * It checks 3 things:
 *   1. Are there stale users with articlesCount > 0 but no PUBLISHED articles?
 *   2. Are there articles with status='PUBLISHED' whose author doesn't exist?
 *   3. Are there articles with deletedAt set (soft-deleted) that still count?
 *
 * Run with:  npx tsx scripts/diagnose-articles.ts
 */
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('\n🔬 Midan — articles diagnostic\n')

  // 1. Total counts
  const [userCount, articleCount, publishedCount] = await Promise.all([
    prisma.user.count(),
    prisma.article.count(),
    prisma.article.count({ where: { status: 'PUBLISHED', deletedAt: null } }),
  ])
  console.log(`Users:                    ${userCount}`)
  console.log(`Articles (total):         ${articleCount}`)
  console.log(`Articles (PUBLISHED):     ${publishedCount}`)

  if (publishedCount === 0) {
    console.log('\n⚠️  No PUBLISHED articles in the database.')
    console.log('   This is why every profile shows "لا توجد مقالات".')
    console.log('   The seed script needs to create articles, OR you need to publish one.')
  }

  // 2. Per-user discrepancy check
  console.log('\n─ Per-user articlesCount vs actual PUBLISHED count ─')
  const users = await prisma.user.findMany({
    select: {
      id: true,
      name: true,
      articlesCount: true,
      articles: {
        where: { status: 'PUBLISHED', deletedAt: null },
        select: { id: true, title: true, publishedAt: true, createdAt: true },
      },
    },
    take: 50,
  })

  let driftCount = 0
  for (const u of users) {
    const actual = u.articles.length
    const cached = u.articlesCount || 0
    if (actual !== cached) {
      driftCount++
      console.log(`  ✗ ${u.id.padEnd(20)} | cached=${cached}  actual=${actual}  ← DRIFT`)
    } else if (cached > 0) {
      console.log(`  ✓ ${u.id.padEnd(20)} | cached=${cached}  actual=${actual}`)
      for (const a of u.articles) {
        console.log(`      • ${a.title.slice(0, 60)}  (publishedAt=${a.publishedAt?.toISOString() || 'null'})`)
      }
    }
  }

  if (driftCount > 0) {
    console.log(`\n❌ ${driftCount} user(s) have stale articlesCount.`)
    console.log('   This is the EXACT bug pattern: profile sidebar shows a count,')
    console.log('   but the Articles tab is empty because the actual article rows')
    console.log('   were deleted (or never existed).')
    console.log('\n   Fix: re-run `npm run db:seed` — the updated seed script now')
    console.log('   uses TRUNCATE CASCADE, which clears stale counters correctly.')
  } else if (publishedCount > 0) {
    console.log('\n✅ All counters are in sync.')
  } else {
    console.log('\n✓ Counters are in sync (but database is empty — run the seed).')
  }

  // 3. Orphaned articles (author deleted)
  const orphaned = await prisma.article.count({
    where: { author: null } as never,
  })
  if (orphaned > 0) {
    console.log(`\n⚠️  ${orphaned} article(s) have a missing author (orphaned).`)
  }

  console.log('')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })
