# 🚨 تنبيه أمني حرج — Critical Security Alert

> **تاريخ الاكتشاف**: يوليو 2026  
> **الحالة**: تم التعقيم ✅ + تدوير الأسرار مطلوب يدوياً ⚠️

## الوضع الحالي

أثناء فحص المستودع، اكتُشف أن **أرشيف RAR** (`maydan - Copy.rar`) كان مرفوعاً إلى GitHub ويحتوي بداخله على ملف `.env` يحتوي على **أسرار حقيقية مكشوفة**.

كذلك اكتُشف لاحقاً (في هذا التحليل الأمني P0) أن أسراراً إضافية كانت مُصلّبة مباشرة في:

| الملف | السر المكشوف | الحالة |
|------|--------------|--------|
| `scripts/apply-correct-password.sh` | كلمة مرور DB `A8596...Shq!` (منزوع) | ✅ تم التعقيم |
| `maydan.sh` | Cloudflare Tunnel Token (`eyJ...`) | ✅ تم التعقيم |
| `DEPLOY.md` | نفس Cloudflare Tunnel Token | ✅ تم التعقيم |
| `.env` | كلمة مرور DB + SMTP + Google OAuth | ✅ تم التعقيم |

### الأسرار التي سُرّبت (كلها تحتاج تدوير فوري!)

| النوع | القيمة المسروقة | مكان التسريب |
|------|------------------|--------------|
| `JWT_SECRET` | (في .env داخل RAR) | GitHub history |
| `ENCRYPTION_KEY` | (في .env داخل RAR) | GitHub history |
| `INTERNAL_API_SECRET` | (في .env داخل RAR) | GitHub history |
| `SESSION_SECRET` | (في .env داخل RAR) | GitHub history |
| `CSRF_SECRET` | (في .env داخل RAR) | GitHub history |
| كلمة مرور PostgreSQL | `A8596...Shq!` (منزوع) | GitHub history + scripts |
| كلمة مرور SMTP Zoho | `7pVWV...` (منزوع) | GitHub history |
| Google OAuth Client ID | `801223751140-...` (منزوع) | GitHub history |
| Google OAuth Client Secret | `GOCSPX-UX8QZnY_...` | GitHub history |
| Cloudflare Tunnel Token | `eyJhIjoiNjE2MGFk...` | GitHub history + scripts + DEPLOY.md |

> ⚠️ **افترض أن كل هذه الأسرار قد استُخدمت بالفعل من قبل مهاجمين.** يجب تدويرها جميعاً فوراً.

## الإجراءات المطلوبة فوراً (بترتيب الأولوية)

### 1. ✅ تم تنفيذه في هذه الجلسة

- ✅ حُذف أرشيف RAR من النسخة المحلية
- ✅ عُقّم `.env` — كل الأسرار الحقيقية استُبدلت بـ `REPLACE_WITH_*` placeholders
- ✅ عُقّم `scripts/apply-correct-password.sh` — كلمة المرور تُقرأ من `DB_PASSWORD` env var
- ✅ عُقّم `maydan.sh` — Cloudflare token يُقرأ من `CLOUDFLARE_TUNNEL_TOKEN` env var
- ✅ عُقّم `DEPLOY.md` — أُزيل الـ token المسروق، أُضيف دليل آمن
- ✅ تم تحديث `.gitignore` لمنع التسريب مستقبلاً
- ✅ تم تحديث `.env.example` ليوثّق كل 40+ متغير بيئة
- ✅ أُنشئ `scripts/rotate-secrets.sh` كدليل شامل للتدوير

### 2. 🔴 يجب عليك فعلها يدوياً الآن

#### أ) تدوير كل الأسرار (Rotate all secrets)

```bash
# شغّل سكريبت التدوير (يولّد أسراراً جديدة ويعرضها)
bash scripts/rotate-secrets.sh

# أو ولّدها يدوياً:
openssl rand -base64 48  # JWT_SECRET
openssl rand -hex 32     # ENCRYPTION_KEY, SESSION_SECRET, CSRF_SECRET, INTERNAL_API_SECRET
openssl rand -base64 24  # DB_PASSWORD, REDIS_PASSWORD, MINIO passwords
```

ضع كل قيمة جديدة في `.env` (وليس `.env.example`).

#### ب) تغيير كلمات المرور في الخدمات الخارجية

- **PostgreSQL**:
  ```sql
  ALTER USER maydan WITH PASSWORD 'NEW_STRONG_PASSWORD';
  ```
- **Zoho SMTP**: غيّر كلمة مرور `admin@midaniq.com` من لوحة تحكم Zoho (أو أنشئ App Password جديد)
- **PgBouncer**: حدّث `userlist.txt` بكلمة المرور الجديدة

#### ج) إعادة تعيين Google OAuth

1. اذهب إلى https://console.cloud.google.com/apis/credentials
2. احذف OAuth Client الحالي (المسروق)
3. أنشئ OAuth Client جديد
4. حدّث `GOOGLE_CLIENT_ID` و `GOOGLE_CLIENT_SECRET` في `.env`

#### د) إنشاء Cloudflare Tunnel جديد

1. اذهب إلى https://one.dash.cloudflare.com/
2. Networks → Tunnels → حذف الـ tunnel القديم (المسروق)
3. Create a tunnel جديد
4. انسخ الـ token الجديد
5. ضعه في `.env` كـ `CLOUDFLARE_TUNNEL_TOKEN`

#### هـ) حذف الأسرار من تاريخ GitHub

مجرد تعقيم الملفات محلياً **لا يكفي** — الأسرار لا تزال موجودة في تاريخ git العام. للحذف الكامل:

```bash
# الخيار الأسهل: استخدم BFG Repo-Cleaner
# 1. نزّل BFG: https://rtyley.github.io/bfg-repo-cleaner/
# 2. استنساخ bare:
git clone --mirror https://github.com/ahmedrah33m/midan9.git midan9.git

# 3. أنشئ ملف secrets.txt يحتوي كل الأسرار المسروقة (كل سر في سطر):
cat > secrets.txt << 'EOF'
# ضع هنا كل سر مسروق كامل (القيم المنزوعة في SECURITY-ALERT.md للتوضيح فقط)
# استخرج القيم الكاملة من git history القديم إن لزم
# OLD_DB_PASSWORD_FULL
# OLD_SMTP_PASSWORD_FULL
# OLD_GOOGLE_OAUTH_CLIENT_SECRET_FULL
# OLD_CLOUDFLARE_TUNNEL_TOKEN_FULL
EOF

# 4. شغّل BFG:
java -jar bfg.jar --delete-files ".env" midan9.git
java -jar bfg.jar --delete-files "maydan - Copy.rar" midan9.git
java -jar bfg.jar --replace-text secrets.txt midan9.git

# 5. نظّف reflog و garbage collection:
cd midan9.git
git reflog expire --expire=now --all
git gc --prune=now --aggressive

# 6. ارفع (force push):
git push --force

# 7. احذف secrets.txt محلياً:
rm secrets.txt
```

> ⚠️ **تحذير**: `git push --force` سيعيد كتابة history كامل. كل المساهمين يجب أن يعيدوا استنساخ المستودع.

#### و) تفعيل pre-commit hooks لمنع التسريب مستقبلاً

```bash
# تثبيت git-secrets أو trufflehog
pip install trufflehog

# أو استخدم GitHub Secret Scanning (مفعّل افتراضياً للمستودعات العامة)

# أو أضف pre-commit hook:
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
if grep -rnE "(A8596|7pVWV|GOCSPX-|eyJhIjoiNjE2)" . --include="*.sh" --include="*.yml" --include="*.md" --include="*.ts" --include="*.tsx" --include="*.env" 2>/dev/null; then
  echo "❌ كشف سر مسروق! امنع الالتزام."
  exit 1
fi
EOF
chmod +x .git/hooks/pre-commit
```

## التحقق من نجاح الإصلاح

بعد تنفيذ الخطوات أعلاه:

1. ✅ تأكد أن `.env` يحتوي على `REPLACE_WITH_*` placeholders فقط (لا أسرار حقيقية)
2. ✅ تأكد أن `.env.local` (إن استخدمته) غير متعقّب بـ git: `git status .env.local` يجب أن يرجع "nothing to commit"
3. ✅ شغّل فحص الأسرار: `trufflehog https://github.com/ahmedrah33m/midan9.git` — يجب أن يرجع 0 نتائج
4. ✅ تأكد أن الأرشيف RAR لم يعد موجوداً في تاريخ GitHub
5. ✅ اختبر تسجيل الدخول بعد تدوير الأسرار للتأكد من أن كل شيء يعمل
6. ✅ اختبر Google OAuth — يجب أن يعمل بالـ credentials الجديدة
7. ✅ اختبر Cloudflare Tunnel — يجب أن يعمل بالـ token الجديد

## الدروس المستفادة

- ❌ لا ترفع أرشيفات مضغوطة (RAR/ZIP) تحتوي على الكود المصدري إلى git
- ❌ لا تضع ملف `.env` الحقيقي داخل أي أرشيف
- ❌ لا تُصلّب أبداً أسراراً (كلمات مرور، tokens، API keys) في الكود أو الـ scripts أو الـ docs
- ✅ ارفع الكود المصدري مباشرة كملفات
- ✅ استخدم `.env.example` للقيم الوهمية و `.env` للأسرار الحقيقية
- ✅ استخدم أداة مثل `pre-commit` لمنع رفع الأسرار
- ✅ فعّل GitHub Secret Scanning
- ✅ دوّر الأسرار فوراً عند أي اشتباه بتسريب

## مراجع

- [BFG Repo-Cleaner](https://rtyley.github.io/bfg-repo-cleaner/)
- [GitHub Secret Scanning](https://docs.github.com/en/code-security/secret-scanning)
- [git-filter-repo](https://github.com/newren/git-filter-repo)
- [trufflehog](https://github.com/trufflesecurity/trufflehog)
