#!/bin/bash
# ============================================
# سكريبت تثبيت وإصلاح شامل لمنصة ميدان
# Maydan Complete Fix & Install Script
# ============================================
# الاستخدام: bash install-fix.sh
# يمكن تشغيله من أي مسار — يكتشف مجلد المشروع تلقائياً
# ============================================

set -e

# ── ألوان الطرفية ──
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# ── كشف مجلد المشروع ──
SCRIPT_PATH="$(readlink -f "$0" 2>/dev/null || realpath "$0" 2>/dev/null || echo "$0")"
if [ -f "$SCRIPT_PATH" ]; then
    PROJECT_DIR="$(cd "$(dirname "$SCRIPT_PATH")" && pwd)"
else
    PROJECT_DIR="$(pwd)"
fi

# تحقق أننا في مجلد المشروع الصحيح
if [ -f "$PROJECT_DIR/package.json" ] && grep -q "midan-platform\|midaniq\|maydan" "$PROJECT_DIR/package.json" 2>/dev/null; then
    cd "$PROJECT_DIR"
else
    echo -e "${RED}❌ لم يتم العثور على مشروع ميدان${NC}"
    echo "تأكد أن install-fix.sh موجود في مجلد المشروع الرئيسي"
    echo "المسار المتوقع: $PROJECT_DIR"
    exit 1
fi

echo "============================================"
echo "  تثبيت إصلاحات ميدان"
echo "  Maydan Fix Installer"
echo "============================================"
echo ""
echo -e "${BLUE}📂 مجلد المشروع: ${PROJECT_DIR}${NC}"
echo ""

# ── الخطوة 1: إصلاح ملف .env ──────────────────
echo -e "${CYAN}📝 [1/8] فحص وإصلاح ملف .env...${NC}"

if [ ! -f ".env" ]; then
    echo -e "${RED}❌ ملف .env غير موجود!${NC}"
    echo "أنشئ ملف .env بنسخ .env.example واملأ البيانات"
    exit 1
fi

# نسخ احتياطي لـ .env (بمسار كامل لتجنب الخطأ)
BACKUP_ENV=".env.backup.$(date +%Y%m%d%H%M%S)"
cp "$PROJECT_DIR/.env" "$PROJECT_DIR/$BACKUP_ENV"
echo -e "${GREEN}  ✅ تم النسخ الاحتياطي: $BACKUP_ENV${NC}"

# ── إصلاح NODE_ENV للتطوير المحلي ──
if grep -q '^NODE_ENV=production' .env; then
    sed -i 's/^NODE_ENV=production/NODE_ENV=development/' .env
    echo -e "${YELLOW}  ⚠️  تم تغيير NODE_ENV من production إلى development${NC}"
    echo -e "${YELLOW}     (الكوكيز الآمنة لا تعمل على HTTP بدون HTTPS)${NC}"
else
    echo -e "${GREEN}  ✅ NODE_ENV صحيح${NC}"
fi

# ── إصلاح FORCE_SECURE_COOKIE ──
if grep -q '^FORCE_SECURE_COOKIE=true' .env; then
    sed -i 's/^FORCE_SECURE_COOKIE=true/FORCE_SECURE_COOKIE=false/' .env
    echo -e "${YELLOW}  ⚠️  تم تعطيل FORCE_SECURE_COOKIE (مطلوب للتطوير المحلي)${NC}"
else
    echo -e "${GREEN}  ✅ FORCE_SECURE_COOKIE صحيح${NC}"
fi

# ── إصلاح NEXT_PUBLIC_APP_URL ──
if grep -q '^NEXT_PUBLIC_APP_URL=https://midaniq.com' .env; then
    sed -i 's|^NEXT_PUBLIC_APP_URL=https://midaniq.com|NEXT_PUBLIC_APP_URL=http://localhost:3300|' .env
    echo -e "${YELLOW}  ⚠️  تم تغيير APP_URL لـ localhost:3300${NC}"
fi
if grep -q '^NEXT_PUBLIC_SITE_URL=https://midaniq.com' .env; then
    sed -i 's|^NEXT_PUBLIC_SITE_URL=https://midaniq.com|NEXT_PUBLIC_SITE_URL=http://localhost:3300|' .env
    echo -e "${YELLOW}  ⚠️  تم تغيير SITE_URL لـ localhost:3300${NC}"
fi

# ── التحقق من وجود ENCRYPTION_KEY ──
if ! grep -q '^ENCRYPTION_KEY=' .env || grep -q '^ENCRYPTION_KEY=$' .env; then
    ENCRYPTION_KEY=$(openssl rand -hex 32 2>/dev/null || node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
    echo "ENCRYPTION_KEY=$ENCRYPTION_KEY" >> .env
    echo -e "${YELLOW}  ⚠️  تم إضافة ENCRYPTION_KEY${NC}"
else
    echo -e "${GREEN}  ✅ ENCRYPTION_KEY موجود${NC}"
fi

# ── التحقق من CSRF_SECRET ──
if ! grep -q '^CSRF_SECRET=' .env || grep -q '^CSRF_SECRET=$' .env; then
    CSRF_SECRET=$(openssl rand -hex 32 2>/dev/null || node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
    echo "CSRF_SECRET=$CSRF_SECRET" >> .env
    echo -e "${YELLOW}  ⚠️  تم إضافة CSRF_SECRET${NC}"
else
    echo -e "${GREEN}  ✅ CSRF_SECRET موجود${NC}"
fi

# ── إضافة connect_timeout لـ DATABASE_URL إذا غير موجود ──
if ! grep -q 'connect_timeout' .env; then
    sed -i 's|^\(DATABASE_URL=.*\)$|\1\&connect_timeout=30|' .env
    sed -i 's|^\(DIRECT_DATABASE_URL=.*\)$|\1\&connect_timeout=30|' .env
    echo -e "${YELLOW}  ⚠️  تم إضافة connect_timeout=30${NC}"
fi

# ── إضافة MODERATION_ENABLED إذا غير موجود ──
if ! grep -q '^MODERATION_ENABLED=' .env; then
    echo "MODERATION_ENABLED=true" >> .env
    echo -e "${YELLOW}  ⚠️  تم إضافة MODERATION_ENABLED${NC}"
fi

echo ""

# ── الخطوة 2: قراءة بيانات قاعدة البيانات ──
echo -e "${CYAN}🔍 [2/8] قراءة بيانات قاعدة البيانات...${NC}"

DB_URL=$(grep -E '^DATABASE_URL=' .env | grep -v '^#' | head -1 | sed 's/^DATABASE_URL=//' | tr -d '"' | tr -d "'")

if [ -z "$DB_URL" ]; then
    echo -e "${RED}❌ DATABASE_URL غير موجود في .env${NC}"
    exit 1
fi

# Parse PostgreSQL URL
DB_URL_CLEAN="${DB_URL#postgresql://}"
DB_URL_CLEAN="${DB_URL_CLEAN#postgres://}"
DB_USER_PASS="${DB_URL_CLEAN%%@*}"
DB_HOST_DB="${DB_URL_CLEAN#*@}"
DB_USER="${DB_USER_PASS%%:*}"
DB_PASS="${DB_USER_PASS#*:}"
DB_HOST_DB_FULL="${DB_HOST_DB%%\?*}"
DB_NAME="${DB_HOST_DB_FULL##*/}"
DB_HOST_PORT="${DB_HOST_DB_FULL%%/*}"
DB_HOST="${DB_HOST_PORT%%:*}"
DB_PORT="${DB_HOST_PORT##*:}"

if [ "$DB_HOST" = "$DB_PORT" ] || [ -z "$DB_PORT" ]; then
    DB_PORT="5432"
fi

echo -e "${BLUE}  المستخدم:       $DB_USER${NC}"
echo -e "${BLUE}  المضيف:         $DB_HOST${NC}"
echo -e "${BLUE}  المنفذ:         $DB_PORT${NC}"
echo -e "${BLUE}  قاعدة البيانات: $DB_NAME${NC}"
echo ""

# ── الخطوة 3: تنظيف المجلد الأب من ملفات npm المتعارضة ──
echo -e "${CYAN}🧹 [3/8] تنظيف الملفات المتعارضة...${NC}"

PARENT_DIR="$(dirname "$PROJECT_DIR")"
CONFLICTS_FOUND=0

for f in "$PARENT_DIR/package-lock.json" "$PARENT_DIR/package.json"; do
    if [ -f "$f" ]; then
        rm -f "$f"
        echo -e "${YELLOW}  حذف: $(basename "$f")${NC}"
        CONFLICTS_FOUND=1
    fi
done

if [ -d "$PARENT_DIR/node_modules" ]; then
    rm -rf "$PARENT_DIR/node_modules"
    echo -e "${YELLOW}  حذف: node_modules (المجلد الأب)${NC}"
    CONFLICTS_FOUND=1
fi

if [ "$CONFLICTS_FOUND" = "0" ]; then
    echo -e "${GREEN}  ✅ لا توجد ملفات متعارضة${NC}"
fi
echo ""

# ── الخطوة 4: تثبيت/تشغيل PostgreSQL ──
echo -e "${CYAN}🗄️  [4/8] التحقق من PostgreSQL...${NC}"

if ! command -v psql &> /dev/null; then
    echo -e "${YELLOW}  📦 PostgreSQL غير مثبت — جارٍ التثبيت...${NC}"
    sudo apt-get update -qq
    sudo apt-get install -y -qq postgresql postgresql-contrib
    echo -e "${GREEN}  ✅ تم تثبيت PostgreSQL${NC}"
else
    echo -e "${GREEN}  ✅ PostgreSQL موجود${NC}"
fi

# تشغيل PostgreSQL
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
    echo -e "${YELLOW}  🔄 تشغيل PostgreSQL...${NC}"
    sudo systemctl start postgresql 2>/dev/null || sudo service postgresql start 2>/dev/null || true
    sleep 3
    if pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
        echo -e "${GREEN}  ✅ PostgreSQL يعمل${NC}"
    else
        echo -e "${RED}  ❌ فشل تشغيل PostgreSQL${NC}"
        echo "  جرّب: sudo systemctl start postgresql"
        exit 1
    fi
else
    echo -e "${GREEN}  ✅ PostgreSQL يعمل${NC}"
fi
echo ""

# ── الخطوة 5: إنشاء المستخدم وقاعدة البيانات ──
echo -e "${CYAN}👤 [5/8] إنشاء المستخدم وقاعدة البيانات...${NC}"

USER_EXISTS=$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" 2>/dev/null || echo "")

if [ "$USER_EXISTS" = "1" ]; then
    echo -e "${GREEN}  ✅ المستخدم ${DB_USER} موجود — تحديث كلمة المرور${NC}"
    sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" 2>/dev/null || true
else
    sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';" 2>/dev/null
    echo -e "${GREEN}  ✅ تم إنشاء المستخدم ${DB_USER}${NC}"
fi

DB_EXISTS=$(sudo -u postgres psql -lqt 2>/dev/null | cut -d \| -f 1 | grep -qw "${DB_NAME}" && echo "1" || echo "")

if [ "$DB_EXISTS" = "1" ]; then
    echo -e "${GREEN}  ✅ قاعدة البيانات ${DB_NAME} موجودة${NC}"
else
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" 2>/dev/null
    echo -e "${GREEN}  ✅ تم إنشاء قاعدة البيانات ${DB_NAME}${NC}"
fi

# منح الصلاحيات
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -d "${DB_NAME}" -c "GRANT ALL ON SCHEMA public TO ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -d "${DB_NAME}" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO ${DB_USER};" 2>/dev/null || true
sudo -u postgres psql -d "${DB_NAME}" -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO ${DB_USER};" 2>/dev/null || true
echo ""

# ── الخطوة 6: إصلاح pg_hba.conf ──
echo -e "${CYAN}🔐 [6/8] التحقق من اتصال قاعدة البيانات...${NC}"

if PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -c "SELECT 1;" &>/dev/null; then
    echo -e "${GREEN}  ✅ الاتصال بقاعدة البيانات ناجح!${NC}"
else
    echo -e "${YELLOW}  ⚠️  الاتصال فشل — جارٍ إصلاح pg_hba.conf...${NC}"
    
    PG_HBA=$(sudo -u postgres psql -c "SHOW hba_file;" -t 2>/dev/null | tr -d ' \n')
    
    if [ -n "$PG_HBA" ] && [ -f "$PG_HBA" ]; then
        sudo cp "$PG_HBA" "${PG_HBA}.bak.$(date +%Y%m%d%H%M%S)"
        
        sudo sed -i 's/local\s*all\s*all\s*peer/local   all             all                                     md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*127\.0\.0\.1\/32\s*scram-sha-256/host    all             all             127.0.0.1\/32            md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*::1\/128\s*scram-sha-256/host    all             all             ::1\/128                 md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*127\.0\.0\.1\/32\s*ident/host    all             all             127.0.0.1\/32            md5/' "$PG_HBA"
        sudo sed -i 's/host\s*all\s*all\s*::1\/128\s*ident/host    all             all             ::1\/128                 md5/' "$PG_HBA"
        
        sudo systemctl reload postgresql 2>/dev/null || sudo service postgresql reload 2>/dev/null || true
        echo -e "${GREEN}  ✅ تم تعديل pg_hba.conf وإعادة تحميل PostgreSQL${NC}"
        
        sleep 2
        if PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -c "SELECT 1;" &>/dev/null; then
            echo -e "${GREEN}  ✅ الاتصال ناجح الآن!${NC}"
        else
            echo -e "${RED}  ❌ الاتصال فشل حتى بعد الإصلاح${NC}"
            echo "  تحقق يدوياً: PGPASSWORD='كلمة_المرور' psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME"
            exit 1
        fi
    else
        echo -e "${RED}  ❌ لم يتم العثور على pg_hba.conf${NC}"
        exit 1
    fi
fi
echo ""

# ── الخطوة 7: حذف ملفات SQLite وتجهيز Prisma ──
echo -e "${CYAN}🗂️  [7/8] تنظيف ملفات SQLite وتجهيز قاعدة البيانات...${NC}"

# حذف ملفات SQLite القديمة
SQLITE_FOUND=0
for f in prisma/dev.db prisma/dev.db-shm prisma/dev.db-wal prisma/dev.db.bak prisma/db/custom.db; do
    if [ -f "$PROJECT_DIR/$f" ]; then
        rm -f "$PROJECT_DIR/$f"
        echo -e "${YELLOW}  حذف: $f${NC}"
        SQLITE_FOUND=1
    fi
done
if [ "$SQLITE_FOUND" = "0" ]; then
    echo -e "${GREEN}  ✅ لا توجد ملفات SQLite${NC}"
fi

# تثبيت التبعيات
if [ ! -d "$PROJECT_DIR/node_modules" ]; then
    echo -e "${YELLOW}  📦 تثبيت التبعيات (npm install)...${NC}"
    npm install --prefix "$PROJECT_DIR"
    echo -e "${GREEN}  ✅ تم تثبيت التبعيات${NC}"
else
    echo -e "${GREEN}  ✅ node_modules موجود${NC}"
fi

# إنشاء Prisma Client
echo -e "${YELLOW}  🔄 إنشاء Prisma Client...${NC}"
npx --prefix "$PROJECT_DIR" prisma generate
echo -e "${GREEN}  ✅ تم إنشاء Prisma Client${NC}"

# تحديث هيكل قاعدة البيانات
echo -e "${YELLOW}  🔄 تحديث هيكل الجداول...${NC}"
npx --prefix "$PROJECT_DIR" prisma db push --accept-data-loss 2>&1
echo -e "${GREEN}  ✅ تم تحديث الهيكل${NC}"
echo ""

# ── الخطوة 8: إنشاء المستخدم التجريبي (Seed) ──
echo -e "${CYAN}🌱 [8/8] إنشاء بيانات المستخدم التجريبي...${NC}"

SEED_SUCCESS=0

# المحاولة 1: seed-standalone.js (مستقل — يستخدم Prisma مباشرة بدون أي imports من src/)
echo -e "${YELLOW}  🔄 محاولة 1: seed-standalone.js (مستقل)...${NC}"
if [ -f "$PROJECT_DIR/prisma/seed-standalone.js" ]; then
    node "$PROJECT_DIR/prisma/seed-standalone.js" 2>&1
fi

# تحقق فوري: هل أُنشئ مستخدمين؟
USER_COUNT=$(PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -tAc 'SELECT COUNT(*) FROM "User";' 2>/dev/null || echo "0")
USER_COUNT=$(echo "$USER_COUNT" | tr -d ' ')

if [[ "$USER_COUNT" =~ ^[0-9]+$ ]] && [ "$USER_COUNT" -gt 0 ]; then
    SEED_SUCCESS=1
    echo -e "${GREEN}  ✅ تم إنشاء $USER_COUNT مستخدم${NC}"
else
    # المحاولة 2: node -e مباشرة (بدون ملفات — الطريقة المجرّبة)
    echo -e "${YELLOW}  ⚠️  محاولة 2: إنشاء مباشر عبر node + Prisma...${NC}"
    node -e '
const { PrismaClient } = require("@prisma/client");
const c = require("crypto");
const prisma = new PrismaClient();
const salt = c.randomBytes(16).toString("hex");
const hash = c.scryptSync("SeedPass1!", salt, 64).toString("hex");
const pw = salt + ":" + hash;
prisma.user.upsert({
  where: { email: "owner@midaniq.com" },
  update: { password: pw, role: "OWNER", emailVerified: true, isVerified: true, name: "مالك ميدان" },
  create: { email: "owner@midaniq.com", password: pw, name: "مالك ميدان", role: "OWNER", userType: "economist", emailVerified: true, isVerified: true }
}).then(u => {
  console.log("  ✅ المستخدم:", u.email, "| role:", u.role);
  return prisma.siteSettings.upsert({
    where: { id: "main" },
    update: {},
    create: { id: "main", registrationEnabled: true }
  });
}).then(() => prisma.user.count()).then(n => {
  console.log("  ✅ إجمالي المستخدمين:", n);
  return prisma.$disconnect();
}).catch(e => {
  console.error("  ❌ خطأ:", e.message);
  return prisma.$disconnect();
});
' 2>&1

    USER_COUNT=$(PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -tAc 'SELECT COUNT(*) FROM "User";' 2>/dev/null || echo "0")
    USER_COUNT=$(echo "$USER_COUNT" | tr -d ' ')

    if [[ "$USER_COUNT" =~ ^[0-9]+$ ]] && [ "$USER_COUNT" -gt 0 ]; then
        SEED_SUCCESS=1
        echo -e "${GREEN}  ✅ تم إنشاء $USER_COUNT مستخدم (Prisma مباشر)${NC}"
    fi
fi

# المحاولة 3: prisma db seed (النسخة الكاملة مع بيانات تجريبية)
if [ "$SEED_SUCCESS" = "0" ]; then
    echo -e "${YELLOW}  ⚠️  محاولة 3: npx prisma db seed...${NC}"
    npx --prefix "$PROJECT_DIR" prisma db seed 2>&1

    USER_COUNT=$(PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -tAc 'SELECT COUNT(*) FROM "User";' 2>/dev/null || echo "0")
    USER_COUNT=$(echo "$USER_COUNT" | tr -d ' ')

    if [[ "$USER_COUNT" =~ ^[0-9]+$ ]] && [ "$USER_COUNT" -gt 0 ]; then
        SEED_SUCCESS=1
        echo -e "${GREEN}  ✅ تم إنشاء $USER_COUNT مستخدم (prisma seed)${NC}"
    fi
fi

# ── التحقق النهائي ──
echo ""
echo -e "${CYAN}══════════════════════════════════════════${NC}"
echo -e "${CYAN}          التحقق النهائي${NC}"
echo -e "${CYAN}══════════════════════════════════════════${NC}"

TABLE_COUNT=$(PGPASSWORD="${DB_PASS}" psql -h "$DB_HOST" -p "$DB_PORT" -U "${DB_USER}" -d "${DB_NAME}" -tAc "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null || echo "ERROR")

echo ""
echo -e "${BLUE}  الجداول:   $TABLE_COUNT${NC}"
echo -e "${BLUE}  المستخدمين: $USER_COUNT${NC}"
echo ""

if [[ "$USER_COUNT" =~ ^[0-9]+$ ]] && [ "$USER_COUNT" -gt 0 ]; then
    echo -e "${GREEN}══════════════════════════════════════════${NC}"
    echo -e "${GREEN}       ✅ الإعداد مكتمل بنجاح! ✅${NC}"
    echo -e "${GREEN}══════════════════════════════════════════${NC}"
    echo ""
    echo -e "${CYAN}  بيانات الدخول التجريبية:${NC}"
    echo -e "  البريد:       ${GREEN}owner@midaniq.com${NC}"
    echo -e "  كلمة المرور:  ${GREEN}SeedPass1!${NC}"
    echo ""
    echo -e "${CYAN}  لتشغيل المشروع:${NC}"
    echo -e "  ${GREEN}npm run dev${NC}"
    echo -e "  ثم افتح: ${GREEN}http://localhost:3300${NC}"
    echo ""
    echo -e "${YELLOW}  ⚠️  ملاحظات مهمة:${NC}"
    echo "  - تم تعطيل FORCE_SECURE_COOKIE للتطوير المحلي"
    echo "  - تم تغيير NODE_ENV إلى development"
    echo "  - عند النشر، استعد القيم الأصلية من: $BACKUP_ENV"
    echo ""
else
    echo -e "${YELLOW}══════════════════════════════════════════${NC}"
    echo -e "${YELLOW}    ⚠️  قاعدة البيانات جاهزة لكن لا يوجد مستخدمين${NC}"
    echo -e "${YELLOW}══════════════════════════════════════════${NC}"
    echo ""
    echo "أنشئ المستخدم يدوياً:"
    echo "  npx tsx prisma/seed.ts"
    echo ""
fi