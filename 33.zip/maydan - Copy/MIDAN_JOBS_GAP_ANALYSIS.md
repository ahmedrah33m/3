# MIDAN JOBS 2.0 — Gap Analysis

> PHASE 2 of the mandatory master-prompt sequence (§271). Built on the completed Phase 1 audit.
> Scope: transform the Midan **Job Board** into a **Midan Talent & Hiring Platform** — Jobs + Talent + ATS + AI + Labor Intelligence — without breaking existing Midan features (§268).

---

## 1. The mandatory capability table (§3)

| Capability | موجود | جزئي | مفقود | المطلوب |
| ---------- | ----- | ---- | ----- | ------- |
| Job Board | ✅ |  |  | Keep as the main entry point; keep every existing route working |
| Search | ✅ |  |  | Basic contains + filters exist; needs real engine (taxtonomy, boolean, Arabic, ranking) |
| Advanced Filters |  | ✅ |  | category/type/province/search exist; missing work mode, salary, skills, language, verified-only, deadline, experience |
| Candidate Profile | ✅ |  |  | User.resumeData + CVBuilder exist; needs structured Professional Profile + completeness + public page |
| Talent Directory |  | ✅ |  | CV Bank is employer-facing search; needs public `/talent` directory + cards + invite to apply |
| Job Matching |  | ✅ |  | Rule-based screening match exists; needs hybrid score (taxonomy + rule + vector + weight config) + explainability |
| Job Alerts |  | ✅ |  | De-facto via SavedSearch.alertEnabled; needs dedicated JobAlert model + channels (email/in-app/push/Telegram) + frequencies |
| Application Tracker | ✅ |  |  | Candidate applications + stage audit exist; needs kanban UI + Application detail + analytics |
| Employer Profile |  | ✅ |  | Company dashboard exists; needs public `/company/[slug]` + careers page + verification status |
| ATS |  | ✅ |  | Screening + talent pools + pipeline stages exist; needs full pipeline UI (Applicants→Screening→Shortlist→Interview→Offer→Hired), scorecards, team, bulk ops |
| Screening | ✅ |  |  | Rule-based 9-category + verdict + auto-shortlist; needs configurable weights + HR-visible explanation + scoring questions |
| Messaging | ✅ |  |  | Three parallel systems (legacy Message, ChatRoom, JobMessage) + orphans; needs one unified Midan Messages for candidate↔employer with inbox/unread/block/report |
| AI Resume | ✅ |  |  | CV versioning models exist but unused by builder; needs AI Tailor (no invented data) + ATS checker |
| Cover Letter |  | ✅ |  | CvCoverLetter model exists; needs AI generator wired to apply flow |
| Interview AI |  | ✅ |  | Interview model + evaluations; needs AI coach + mock interview + scheduling + scorecards + calendar/availability |
| Salary Intelligence |  |  | ❌ | Nothing exists (only per-job salary fields); needs aggregates (P25/median/P75, sample size, date range) from real Midan data |
| Verification |  | ✅ |  | Company + email verification exist; needs Job Verification levels + scam engine + report job + PrivacyControls |
| Careers Page |  |  | ❌ | No `/company/[slug]/careers`; needs SEO indexable careers + embed intent |
| Analytics |  | ✅ |  | Employer dashboard + stats + admin analytics exist; needs per-job funnel, source analytics, admin Jobs dashboard, exports |
| Labor Market Intelligence |  |  | ❌ | Nothing exists; needs demand-by-skill/province, Iraq map, market reports — data-driven only, AI never source of truth |

Legend: ✅ موجود — builds on existing;  جزئي` ø — partial/exists-in-form (needs upgrade); ❌ — missing.

---

## 2. What already exists (from audit — extend, don't replace)

### Jobs domain
- `GET /api/jobs` (filters category/type/province/search/sector, sort newest/most_viewed, page/limit 20, admin mode w/ status), expiry cron `/api/cron/expire-jobs`, province normalization via `src/lib/job-provinces.ts` (`PROVINCE_ALIASES` 19 govs Arabic/English/Kurdish + `provinceWhere`).
- `POST /api/jobs` → `createJob` (`JobCreateSchema`, pricing `JOB_POST`, wallet pay + coupon, `CompanyFreePeriod`, `autoPublishJob`, `JOB_OPPORTUNITY` notif). `POST /api/jobs/quick-publish` → Telegram (`PublishChannel`/`PublishLog`).
- UI: `JobsPage.tsx` (infinite scroll, debounce), `JobDetail.tsx`, `JobsListingsView`, `IraqJobsMap.tsx`; `CVBuilder.tsx` mounted inside `(main)/jobs/page.tsx`.
- Taxa nomically duplicated constants: `JobCreationForm.tsx` (CATEGORIES 15, SECTORS 15, JOB_TYPES 8, JOB_LEVELS 6, EXPERIENCE/EDUCATION/LANGUAGE/CURRENCY/BENEFITS/APPLICATION_METHODS/PUBLISH_CHANNELS), `JobsPage.tsx`, `CvBankPage.tsx`, `OpenToWorkToggle.tsx`. Three governorate lists diverge (`job-provinces.ts` vs `feasibility/iraq.ts` vs `location-service` static).

### Company / employer
- `GET /api/jobs/employer/dashboard` + `/stats?from=&to=`. `CompanyDashboard.tsx`.
- `TalentPool` + members, Talent CRM (`CRM_STAGES` 8, `upsertCrmEntry`), `JobCandidateMatch`, `CandidateInvitation`, `talent-marketplace.service.ts` (`matchCandidatesForJob`, `inviteCandidates`).
- CV Bank `cv-bank.service.ts` (822 lines): tiers `CV_BANK_FREE|BASIC|PROFESSIONAL|ENTERPRISE`, wallet subscription, monthly cycle limit → 429, search by name/jobTitle/bio/profession/governorate/university/educationLevel.

### CV / candidate
- `CVBuilder.tsx` (1,648 lines, 5 tabs/12 steps, 20-criterion completeness, PDF html2canvas-pro + jsPDF).
- GAP: `/api/cv-builder` persists only `user.resumeData`; `CvVersion`/`CvAnalytics`/`CvFile`/`CvTemplate`/`CvJobMatch`/`SkillGraph`/`CvRecommendation`/`CvCoverLetter` (schema L4514–4658) are only touched by `api/cv-builder/versions/*` — **two disconnected persistence paths**.
- CV Bank models `CandidateNote` L4774 / `CandidateRating` L4791 / `SavedCandidate`. User CV fields L267–291 (resumeData, openToWork, jobTypes[], gender, dateOfBirth, nationality, expectedSalary, employmentType, yearsOfExperience, educationLevel, university, gpa, languages Json, resumeFile, cvVisibleInBank, cvBankScore).

### Applications / ATS
- `POST /api/jobs/[id]/apply` + withdraw (`DELETE …?applicationId=`, JOB-001 fix). Candidate list `/api/jobs/candidate/applications?stage=`. Pipeline `PATCH /api/jobs/[id]/pipeline`. Auto-screen `/api/applications/[id]/screen`.
- `PIPELINE_STAGES` (11: RECEIVED→HIRED/REJECTED/WITHDRAWN, incl. `SCREENING`), `ApplicationStageChange` L4753, `JobScreeningQuestion` L6815 / `ScreeningAnswer` L6830, `Interview` L6322 (eval fields), `Offer` L6398 (accept → EmploymentContract + HIRED), `screening.service.ts` (438: 9-category, `computeVerdict`, auto-shortlist pools «المؤهلون تلقائيًا»/«مرشحون محتملون»).

### Messaging / notifications
- Legacy `Message` L1283 (+`MessageReaction` L5408, `MessageReadReceipt` L5420), API `src/app/api/messages/**` (list/send/mark-as-read/edit-within-5min/soft-delete).
- `ChatRoom` L1566 / `ChatRoomMessage` L1578 (Socket.IO), `JobMessage` L4872 (job thread `/api/jobs/[id]/messages`).
- `Conversation` L5379 / `ConversationParticipant` L5393 **orphaned** (no FK from Message); `ConversationContext` only in `schema-additions-phase1.prisma:302`.
- Notification engine exists (`NotificationType` enum, push web-push + Socket.IO, bullmq worker), no notification center UI with per-category tabs.

### Database core facts
- 8,752-line schema, ~370 models, `String @id @default(cuid())`, few enums (UserRole, NotificationType, PipelineStage, CvBankTier, ContactMethod, MessageType, CompanySize, SubscriptionPlan/Status…).
- `Job` denormalized: skillsRequired/languages/benefits/location/questions/attachments/applicationMethods as `Json?`, salaryFrom/To, salaryCurrency, isFeatured/isUrgent/isRemote/isVerified. `JobApplication.unique=[jobId, applicantId]`, matchScore.
- Missing: **no JobAlert model, no JobSkill/JobLocation/JobBenefit/JobLanguage/JobQuestion/JobView, no FK on Interview/Offer, no unified company identity** (`publishedBy → User` legacy vs newer `Company` entity; join tables store bare `companyId` = legacy user id).
- Server DB has **no `_prisma_migrations` table** → conventional raw-SQL migration applies.
- Pre-existing server DB drift (payroll/live/HR tables absent, `ResearchJournal.updatedAt` default drift) — out of scope, warn only.

### AI
- `ai.service.ts` (`askMidanAI` w/ memory + privacy, domain system prompts), `ai-cache.ts` (SHA-256 keys summarize/sentiment/moderate), 12 `/api/ai/*` routes, cold-path callers (`economic.service.ts:324`, `feasibility/parser.ts:199`). Screening/matching is **rule-based, no embeddings**.

---

## 3. Gap Analysis, capability by capability

### 3.1 Job Board → structured Job object (§12–24, §114–117, §124–129, §184–185)
What exists: Job denormalized with `Json?` columns; public browse/search; expiry cron.
Gap:
- Structured attributes: normalised title (§13), department, subcategory, responsibilities/requirements/preferredQualifications (splits from description), work mode enum (On-site/Hybrid/Remote/Remote-in-country/Region/Worldwide §16), allowed countries/cities, timezone requirements, salary period + bonus/commission/equity (§61), experience years, verification status (§25), application method enum (Internal/External/Email/URL §114–115).
- Verified Jobs levels: Unverified→Email Verified→Company Verified→Job Reviewed→Midan Verified (§25).
- Job safety engine + risk flag, Report Job (reason enum §27) → moderation queue (§102).
- `/jobs/[slug]` URL + JobPosting structured data + OG/canonical (§124–125). Keep `/jobs/[id]` working (IDOR tests exist).
- Taxonomy pages `/jobs/hr`, `/jobs/oil-and-gas`, `/jobs/baghdad`, `/jobs/remote`, `/jobs/internships` (§184) as real queries.
- Job freshness states Published/Active/Closing Soon/Expired/Closed + reminders to employer (§22–23).
- QR for jobs, share to WhatsApp/Telegram/LinkedIn/Facebook/X/Email/Copy/QR (§96, §128).

### 3.2 Advanced search & filters (§17–20, §88–90, §229–231)
What exists: `contains` + category/type/province, sort, page/limit.
Gap:
- Filters: work mode, employment type, experience, education, salary range + currency, benefits, language, date posted, deadline, verified-only.
- Boolean search AND/OR/NOT where feasible (§18); Arabic search (موارد بشرية/HR/هش ار/Human Resources §89, §254); smart search → structured filters (§19); AI semantic search for phrasing (§90) — **AI optional, must never gate the core listing.**
- Ranking config (relevance/freshness/verification/salary/match) + clear Sponsored/Featured label (§229–230).
- Search index only if data volume demands (§88); for this cycle prefer Prisma across normalized job_skills + taxonomy + ILIKE/instance.
- Centralize taxonomy (roles/industries/skills/technologies/seniority) once (§87) and reuse everywhere (currently 5+ duplicated arrays).

### 3.3 Professional Profile (§4–11, §255, §264, §265)
What exists: User profile fields L267–291, CVBuilder, `user.resumeData`.
Gap:
- Midan Professional Identity: Basic (headline/bio/country/province/city/Timezone) + Career (experiences/companies/roles/types/years/education/certificates/projects/achievements/portfolio) + Skills (tools/technologies/soft/industry) + Languages (language/proficiency/evidence) + Preferences (target role/sectors/min salary/type/full|part-time|contract|internship|freelance) + Work Mode + Availability + Search Status (§5).
- Profile completion % (weighted sections Basic/Career/Experience/Education/Skills/Languages/Preferences/Portfolio/Verification §6).
- Public profile `/profile/[username]` (or `/midan/profile/`) with Share/Copy/Download CV/QR (§7), privacy Visibility Public/Employers-Only/Private + hide employer/salary/phone/email/location (§8).
- Skills graph: Skill entity + category + synonyms + parent + level (Beginner..Expert) + evidence types (self/verified/certificate/assessment/experience §10). Verify skill flows (§11). `SkillGraph` model exists but unused.
- Unify persistence: CVBuilder must write CvVersion (+ metadata; keep resumeData mirror), relate CvJobMatch/CvRecommendation/CvCoverLetter to it (§47, §201).
- CV parsing (PDF/DOCX via pdfjs-dist, already a dep) → structured profile → **user review before save** (§194, §219).
- Anti-duplicate profile detection (§193).

### 3.4 Talent Directory + Talent Search (§28–32, §169–172, §198)
What exists: CV Bank search (employers-only, paid tiers), talent pools, candidate invitations, Talent CRM.
Gap:
- Public-ish `/talent` route for employers; Talent Result Card (photo/name/headline/role/time/experience/top skills/location/availability/work mode/completion/verification/match%) with View Profile / Message / Save / Invite to Apply (§30).
- Talent filters by role/skills/industry/experience/education/location/work mode/salary expectation/availability/languages/verification/search status (§29).
- Candidate privacy switches (Allow Employer Search, Allow Direct Messages, Allow Talent Recommendations §32).
- Daily outreach limits + spam detector + report/block employer + conversation controls (§31).
- Saved talent searches (§169), candidate lists/pools/tags (§170–172), employer candidate comparison (§198).

### 3.5 Job Matching Engine (§33–38, §74–75, §226, §251)
What exists: `screening.service.ts` rule-based 9-category + `calculateMatchScore` + verdict + auto-shortlist; `JobCandidateMatch` model.
Gap:
- Hybrid Matching: Hard filters → structured/taxonomy matching → semantic (precomputed embeddings, no LLM per request §224) → weighted score with **configurable weights** (§36) → explanation (§35).
- Explainable breakdown: Overall + Skills/Experience/Role/Location/Work Mode/Salary/Language + "لماذا هذه الوظيفة مناسبة لك؟" bullets + Blocking Requirements (§35, §37).
- `Candidate Fit Score` configurable by HR (required/preferred/knockout/weight §65); Matching test suite A–D (§251).
- Personalized "Jobs For You" + always-available "Browse All Jobs" (§38); similar jobs by role/skill/industry/level/location/work mode (§39).
- Employer Recommended Candidates per job (§74) with "Invite to Apply" accept/ignore/apply (§75).
- Fairness: no protected characteristics in ranking/score/rec (age, gender, race, religion, health, origin, marital status §66, §112).

### 3.6 Job Alerts (§41–42, §106, §203)
What exists: `SavedSearch.alertEnabled/alertFrequency`; NotificationType.
Gap:
- **New model `JobAlert`** (query snapshot: role/keywords/location/salary-min/currency/skill( Odoo) + frequency Daily|Instant|Weekly §41).
- Channels Email/In-App/Push/Telegram/WhatsApp-chan according to available integrations (§42); cron/queue digest (bullmq exists).
- Deadline reminders + saved-job change alerts (salary/location/deadline/work mode §202–203).
- Rate-limit to avoid spam; digest = "وجدنا 6 وظائف…" without blast (§180).

### 3.7 Applications & Tracker (§43–47, §114–117, §175–178)
What exists: apply + withdraw, candidate applications list, pipeline PATCH, ApplicationStageChange audit, screening answers.
Gap:
- Application detail view (job/company/applied date/CV version/cover letter/questions/notes/follow-up/interview link+date/salary/status §45).
- Tracker statuses Saved→Applied→Viewed→Screening→Shortlisted→Interview→Assessment→Offer→Hired→Rejected/Withdrawn mapped onto existing PIPELINE_STAGES (§43); Kanban drag & drop (§44).
- Application analytics for user (apps/responses/interviews/offers/conversion/avg response §46, §178).
- CV Version + Cover Letter Version bound to each application (§47, §114) — requires unified CvVersion persistence (3.3).
- Quick Apply review confirmation (§116); application safety checks (§117).

### 3.8 Employer Dashboard → Employer Center (§54–60, §63–76, §199, §164)
What exists: dashboard + stats APIs, CompanyDashboard.tsx, job creation form, screening, talent pools.
Gap:
- Dashboard sections Overview/Jobs/Candidates/Talent Search/Applications/ATS/Messages/Interview/Analytics/Company Profile/Billing/Team/Settings (§57).
- Job creation wizard 10 steps (§58) with AI Job Description Writer (editable, §59) and Job Quality Score pre-publish (§60).
- Company team roles (Owner/Admin/Recruiter/Hiring Manager/Interviewer/Viewer) + permissions View/Edit/Comment/Rate/Message/Manage/Admin (§68, §164). `UserCompanyRole` model already exists.
- Offer management extended: salary/currency/start date/employment type/benefits/conditions/status (§73); rejection templates (Generic/Personalized reviewable §177); message templates (interview invite/request info/rejection/offer/follow-up; AI assist NOT auto-send §72).
- Employer weekly digest (new apps/candidate matches/job perf/upcoming interviews/expiring jobs §182).

### 3.9 ATS (§63–70, §176)
What exists: pipeline stages, screening verdict, talent pools, Interview model, evaluations.
Gap:
- ATS pipeline UI per job: Applicants→Screening→Shortlisted→Interview→Assessment→Offer→Hired→Rejected (§63), Candidate Application Record (candidate/job/CV/cover/answers/score/notes/stage/tags/interview/messages/activity §64).
- AI Candidate Summary (important experiences/matched skills/missing requirements/interview checkpoints) — no protected-attribute inferences (§66).
- Structured candidate review (skills X/Y, experience meets, etc. §67), Candidate Score explained (§65).
- Interview management: schedule/interviewer/date/time/timezone/meeting link/notes/scorecard (§69) + scorecards (technical/communication/problem solving/role knowledge/culture/leadership §70) + candidate availability calendar (§206) + timezone compatibility (§207). `Interview` model has no FK — needs proper relations.
- Bulk operations with limits (§168); private HR notes (§199); audit transparency of ATS actions (§103).

### 3.10 Chat / Messaging (§71–72, §105, §205)
What exists: three messaging stacks + orphaned Conversation tables.
Gap:
- **Unified Midan Messages**: candidate↔employer with inbox/unread/archive/block/report, conversation controls (§71, §31).
- Concrete plan: adopt ONE canonical path. Preferred: bridge into the existing Socket.IO ChatRoom model OR extend legacy Message; resolve the orphaned Conversation/ConversationParticipant (create FKs or drop the addendum models) — decision in Phase 3.
- Message templates + AI writing assist (not auto-send §72). Outbound click tracking for external applies (§115).
- Interview calendar integration (Google/Outlook) future-facing (§205).

### 3.11 AI Resume / Cover Letter / Interview / Career Coach (§48–53, §59, §108–111)
What exists: `ai.service.ts`, `/api/ai/*` routes, ai-cache, poem `CvVersion/CvCoverLetter/…` models, pdfjs-dist.
Gap:
- AI Resume Tailor (master CV + job → suggested changes/keyword gaps/relevant experience/potential weak areas/tailored resume; **no invented experience/numbers/companies/certificates/skills/achievements §48, §252**).
- ATS CV checker (keyword coverage/formatting/sections/role/experience/education/skills → explained ATS compatibility, no fake number §49).
- AI Cover Letter generator (profile+CV+job+optional notes, no fabrication §50, §153).
- AI Interview Coach (HR/technical/role/company/behavioral/STAR/remote points §51) + Mock Interview loop question→answer→analysis→feedback→next (§52).
- Midan Career AI (qualified questions; salary/demand answers only from Midan data; no invented market data §53, §245–246; learning roadmap future §139).
- AI modules separated per concern; AI never source of truth (§109); hallucination protection (§110); explainability (§111); prompt versioning (§157).

### 3.12 Verification & Trust (§24–26, §55, §232–236)
What exists: Company verification (email/website), user email/phone verify service.
Gap:
- Job-level verification + levels (§24–25), `EmploymentVerification` relation exists (plain String).
- Scam risk engine → flags → moderation review (never auto-delete solely on AI §26).
- Trust panel on job detail (company verified/salary provided/application destination/last verified/posted/deadline §232); Midan Trust mental model (§233).
- Verification Center for user (email/phone/identity-optional/skills/certificates §234); employer verification (business email/domain/website/documents/admin approval §235); certificate fields (ID/issuer/dates/URL §236).
- Verification cases model §104 + moderation queue §102 + audit logs §103.

### 3.13 Salary Intelligence (§82–83, §141, §242, §210)
What exists: per-job salaryFrom/To/currency; feasibility salary tables (unrelated, paid).
Gap:
- **New models**: `SalaryRecord` (role/industry/location/experience/currency/min/max/period/verified flag/source/jobId) + `SalaryAggregate` (p25/median/p75/min/max/sample size/date range/location/industry/experience §82).
- Sources: job ads + verified employer + candidate expectations + historical; never single source; show sample size; don't show as universal truth if sample small (§82–83).
- `/api/salary` + «See Salary Insights» integration in job page (§141); currency handling IQD/USD/EUR/GBP/AED/SAR w/ stored rate+date (§210).

### 3.14 Skills Intelligence (§84–85, §138, §243–245, §87)
What exists: `SkillGraph` model (unused), skills arrays in CVBuilder.
Gap:
- Skills Gap intelligence (current skills vs demand → top missing skills §84), from real job data only (§138).
- Career Path visualization (HR Assistant→HR Officer→…) + required skills/experience/certificates when data exists (§85).
- Job detail skills box: top required / your skills / missing (§243); candidate market position without unsupported claims (§244).

### 3.15 Labor Market Intelligence + Maps (§79–86, §143–144, §258)
What exists: `IraqJobsMap.tsx` + `jobs-map-data.ts` + `iraq-map-data.ts` (region map data), weekly/quarterly feasibility reports (different domain but reusable patterns).
Gap:
- **New models**: `LaborMarketSnapshot` (period/geo/industry/role/aggregates §104). Demand by skill (§80) and demand by province on Iraq map (§81, §143), job heatmap (§144).
- Market Report (monthly/quarterly/annual: new jobs, demand by sector, skills, salaries, provinces, remote share, trends §86). Data-driven; only when enough data; AI never invents (§53, §110). `/api/labor-market` (§165).
- Economic ecosystem integration (research/news/events/company economic data when reliable public sources §142, §187, §264).

### 3.16 Monetization & Admin (§97–103, §211–215, §223)
What exists: ServicePrice + wallet payments (JOB_POST, CV_BANK_*), Featured/Urgent flags, employer stats, admin moderation roles.
Gap:
- All paid services behind Admin config (pricing table, no hardcoded prices §97, §211) + coupons (first-job/bulk/NGO/startup discounts §212) + promotion tracking (impressions/clicks/apps/cost/conversion §213) + billing (§214). Free launch strategy: posting free first (§215).
- Jobs Admin sections: Jobs/Companies/Candidates/Applications/Reports/Verification/Moderation/Skills/Categories/Locations/Salary Data/Alerts/AI/Analytics/Pricing/Sources/Integrations (§101).
- AI Admin control (models/prompts/thresholds/weights/token usage/errors/moderation §223) + AI cost control (§224).
- Employer Quality Score internal indicators, no public ranking without policy (§148).

### 3.17 Cross-cutting: events, caching, security, tests, RTL (§105–107, §159–161, §250–258, §121–123, §120)
- Event-driven backbone (JOB_CREATED/PUBLISHED/EXPIRED, APPLICATION_*, INTERVIEW_SCHEDULED, MESSAGE_RECEIVED, PROFILE_UPDATED, SKILL_VERIFIED, COMPANY_VERIFIED §105) feeding notifications/analytics/recommendations/AI. BullMQ exists.
- Notification center with tabs (All/Jobs/Applications/Messages/Career/System §107) + deadline/follow-up/interview reminders (§203–204).
- Caching strategy (§159); performance: no AI per request (§160).
- Security: reuse middleware/rate-limits/CSRF/IDOR tests; file upload MIME+size+private storage (§162); candidate data private to team (§163, §199); API pattern follows existing `/api/*` + services (§165).
- Tests: profile, CV parsing, skill normalization, job parsing, search, matching (A–D), applications, ATS, messages, alerts, salary calc, permissions, verification, exports (§250–257). Arabic search tests (§254). E2E candidate + employer flows (§255–256) via vitest + jsdom (existing 22 test files pattern).
- RTL/Arabic first throughout + bilingual (AR/EN) profiles and jobs (§121–122); AI translation without semantic drift (§123).
- Mobile-first screens (§120); instrumentation via Sentry (§249).

---

## 4. Proposed Migration Plan

Principles: additive-first, raw SQL migration file (server has no `_prisma_migrations`), backfill from existing data, no deletes/renames of live columns, keep every existing route working, apply locally + verify then apply to server container (prisma diff via `prisma@6.19.3 migrate diff --from-schema-datasource … --to-schema-datamodel …` inside `maydan-app`, pg via internal `postgres` service).

Ordered steps (each its own migration + deploy + verify):
1. **Schema additions M1 — taxonomy & structure**: `JobCategory`/`Skill`/`SkillAlias`/`Role` tables + seed from existing constants (backfill `Job.category`→normalized refs later, keep string columns readable). Add `Job` structured columns: `workMode`, `salaryPeriod`, `salaryBonus?`Json, `experienceYearsMin/Max`, `normalizedTitle`, `subcategory`, `applicationMethod`, `allowedCountries/Cities` Json, `verificationStatus`, `timezoneRequirements` Json, `isSponsored`, `lastVerifiedAt`. All nullable/backfilled → safe.
2. **Schema additions M2 — job relations**: `JobSkill`, `JobLocation`, `JobBenefit`, `JobLanguage`, `JobQuestionRef` (JOIN tables reading FROM existing Json where possible; write-on-create from wizard). Keep JSON columns as denormalized cache.
3. **Schema additions M3 — identity**: `Job.companyId` nullable FK to `Company` together with existing `publishedBy`; backfill where `publishedBy` relates to a Company; leave legacy fields intact. `Interview`/`Offer` — add FKs to `JobApplication` (nullable, backfilled by jobId+applicantId match) — **no drop of existing columns**.
4. **Schema additions M4 — jobs intelligence**: `JobAlert` (criteria Json + frequency + channels + lastSentAt + schedule), `JobView` (jobId/userId/session/date for analytics), `SalaryRecord` + `SalaryAggregate`, `LaborMarketSnapshot`, `JobReport` (report reason enum), `JobVerificationCase`, `CandidateProfileView`, `OutboundClick` (application-method analytics), `AlertDeliveryLog`.
5. **Schema additions M5 — talent**: `TalentDirectoryEntry` (or extend User flags), `PrivacyControl` (search/dm/recommendations toggles; or extend User fields §8), profile skill/experience/education/project tables OR reuse CVBuilder `CvData` types — decide in Phase 3; prefer reusing existing JSON-backed structs + CvVersion as the normalized store.
6. **Feature flags**: env-config `FEATURE_*` per §260, default off except value of the on by default core.
7. **Code changes**: services-first (extend `job.service.ts`/`screening.service.ts`/`cv-bank.service.ts`), new services `matching.service.ts`, `alert.service.ts`, `salary.service.ts`, `labor-market.service.ts`, `verification.service.ts`, `tracker.service.ts`, `message unification`. New API routes mirror existing pattern (`api-utils`/`requireAuth`/services). UI: extend `(main)/jobs/**` + `CompanyDashboard` + new `/talent` + `/profile/[username]` + `/company/[slug]`(+careers) + notifications center. No deletion of existing files; new pages additive; `navigation-config.ts` gains entries gated by roles+flags.
8. **Data backfill jobs**: migration-time `UPDATE` from JSON career snapshots where parseable; cron jobs (bulm pile) for alert digests, freshness reminders, market snapshots, salary aggregation.

Timing: keep each of the 32 phases shippable + verifiable (`tsc --noEmit`, `next typegen`, `vitest run`, prod `next build`), deploy per phase on the server as feasibility was deployed (§269 requires What-changed/Files/DB/APIs/UI/Tests/Issues/Next after each phase; no phase-to-phase jump on critical errors).

---

## 5. Risks & Mitigations

| Risk | Impact | Mitigation |
| ---- | ------ | ---------- |
| Jobs is the live main surface; regression breaks existing usage | High | Zero-delete rule; every change verified on `/jobs`, `/jobs/[id]`, apply, saved, employer paths; existing 22 vitest files + IDOR tests kept green; additive pages first |
| Denormalized `Job` Json + many consumers → inconsistent reads | Medium | Keep JSON columns readable as cache; write-through from structured columns; one source of truth per attribute documented in data dictionary |
| Server DB has no versioned migrations + existing drift (payroll/HR tables absent) | High | Hand-applied raw SQL; candid diff locally, apply to `postgres` service, verify `\dt` + spot queries; never run `prisma migrate reset`; keep drift list separate |
| Taxa nomy duplication across 5+ components | Medium | Centralize in one lib (roles/skills/governorates/job-types) during Phase 3; migrate all consumers in one step; test search + forms |
| Identity split (publishedBy User vs Company) | High | Bifurcate access via helper `getJobCompany(job)` reading either path; M3 adds `companyId` FK backfilled; never assume both exist |
| Three parallel messaging systems | High | Phase 3 decides canonical path; adopt one for candidate↔employer (ChatRoom w/ Socket.IO is the live/real-time path); orphaned Conversation models resolved (FK or drop addendum) — no data loss to production Message rows |
| AI features could hallucinate data | Medium | AI-generated content always user-reviewed before save (§194/§219/§59); matching uses rule+taxonomy first, embeddings precomputed, LLM last and cache-heavy (§224); explicit no- fabrication prompts + tests (§252) |
| Salary/labor-market claims without data | Medium | Show sample size/date/geo on every aggregate; suppress when n small; AI only paraphrases Midan-own aggregates (§82/§83/§110) |
| Matching fairness / protected characteristics | High | Rule-based filters exclude sensitive fields by construction; AI prompts forbid inference; test suite §251 Case C/D; review checklist in code review |
| Posting/spam abuse (employers + candidates) | Medium | Reuse middleware rate limits; daily outreach caps; message/application limits; report/block; admin moderation queue |
| Large per-phase deploy overhead | Medium | Parallel working + batched verification; server deploy reuses feasibility scripts (7-Zip tar trick; prisma diff; raw SQL; image rebuild) |
| Existing server DB drift (payroll/live/HR) | Low (blocked work) | Documented separately; never touched by these migrations; side-by-side in monitoring |

---

## 6. Phased roadmap (§271) mapped to work state

| Phase | Deliverable | Depends on |
| ---- | ----------- | ---------- |
| 1 – Audit Existing Midan | ✅ DONE (12-section report presented) | – |
| 2 – Gap Analysis | ✅ THIS DOCUMENT | 1 |
| 3 – Architecture | schema migrations M1–M5, central taxonomy lib, services/API layout, feature flags, messaging canonical path, data dictionary | 2 |
| 4 – Professional Profile | identity + completion + public page + privacy + CV versioning unification + parser + skills graph | 3 |
| 5 – Company Profile | `/company/[slug]` (+careers), verify, team roles | 3 |
| 6 – Structured Job Model | M1+M2 applied; wizard upgrade; quality score | 3–5 |
| 7 – Search & Filters | taxonomy search engine, advanced filters, smart/Arabic, ranking, sponsored labels | 6 |
| 8 – Applications & Tracker | detail, kanban, analytics, quick apply | 4,6 |
| 9 – Talent Directory | `/talent`, cards, search, privacy toggles, outreach limits | 4 |
| 10 – Job Matching | hybrid engine, weights config, explainable breakdown, similar/for-you, recommends | 4,6,9 |
| 11 – Job Alerts | JobAlert model + schedule + channels + digest | 4,6 |
| 12 – Messaging | unified Midan Messages + templates + CRM-like controls | 3,4 |
| 13 – Employer Dashboard | Employer Center sections + weekly digest | 6–9,12 |
| 14 – ATS | pipeline UI, record, summaries, bulk ops | 6–9 |
| 15 – Screening & Interviews | configurable scoring, interview mgmt, scorecards, availability | 14 |
| 16 – Verification & Trust | job/company verification levels, scam engine, report, audit | 6 |
| 17 – AI Resume | tailor + ATS checker + versioning | 4,6,16 |
| 18 – AI Cover Letter | generator wired to apply | 4,17 |
| 19 – AI Interview | coach + mock + scorecard AI assist | 15 |
| 20 – AI Career Coach | advice from own data only | 4,10,21 |
| 21 – Salary Intelligence | SalaryRecord/Aggregate + insights + currency | 6,16 |
| 22 – Skills Intelligence | skill gap, career paths, job skills box | 4,10,21 |
| 23 – Labor Market Intelligence | demand-by-skill/province + reports | 21–22 |
| 24 – Iraq Jobs Map | map drill-down + heatmap | 2,23 |
| 25 – External Job Sources | feeds/RSS import + attribution + dedup | 6 |
| 26 – Job Distribution | social cards, QR, Google for Jobs, distribution jobs | 6,16 |
| 27 – Employer Monetization | admin pricing, coupons, promotion tracking, billing | 13,16 |
| 28 – Analytics | admin dashboard, funnel, quality metrics | 6–23 |
| 29 – Security | file safety, privacy, audit, coverage of new routes | 16 |
| 30 – Testing | §250–257 suites incl. matching A–D, Arabic search, E2E | all previous |
| 31 – Performance | caching, index tuning, no-AI-per-request polish | 30 |
| 32 – Production Deployment | server migration + build + health + SEO verify | 31 |

Per §269: after each phase deliver What was changed / Files changed / Database changes / APIs added / UI changes / Tests performed / Known issues / Next Phase; do not advance on critical errors.