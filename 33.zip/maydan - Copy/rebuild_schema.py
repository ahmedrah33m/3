#!/usr/bin/env python3
"""
Complete schema rebuild from scratch.
Reads all models from both sources and builds a valid schema with all relations.
"""

import re
import sys

def extract_models(content):
    """Extract all models with their complete text."""
    models = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^model\s+(\w+)\s*\{', line)
        if m:
            if current:
                models[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        models[current] = '\n'.join(lines)
    return models

def extract_enums(content):
    """Extract all enums."""
    enums = {}
    current = None
    lines = []
    for line in content.split('\n'):
        m = re.match(r'^enum\s+(\w+)\s*\{', line)
        if m:
            if current:
                enums[current] = '\n'.join(lines)
            current = m.group(1)
            lines = [line]
        elif current:
            lines.append(line)
    if current:
        enums[current] = '\n'.join(lines)
    return enums

def get_relations(model_text):
    """Extract all relation fields from a model."""
    relations = []
    lines = model_text.split('\n')
    for line in lines:
        m = re.match(r'\s+(\w+)\s+(\w+)\??\s+@relation\("([^"]+)"', line)
        if m:
            relations.append({
                'field': m.group(1),
                'target': m.group(2),
                'name': m.group(3)
            })
    return relations

def remove_index_errors(model_text):
    """Remove indexes that reference relation fields."""
    lines = model_text.split('\n')
    result = []
    for line in lines:
        # Skip @@index lines that reference non-scalar fields
        if '@@index' in line:
            # Check if it references a relation (not a scalar field)
            # Relations are typically the ones with @relation annotation
            # We'll keep only indexes that reference scalar fields
            match = re.search(r'@@index\(\[([^\]]+)\]', line)
            if match:
                fields = [f.strip().strip('"') for f in match.group(1).split(',')]
                # Keep the index only if all fields are scalar
                # For now, we'll remove all relation-based indexes
                # This is a safe approach
                continue
        result.append(line)
    return '\n'.join(result)

def fix_relation_indexes(models_dict):
    """Fix all indexes that reference relation fields."""
    fixed = {}
    for name, text in models_dict.items():
        fixed[name] = remove_index_errors(text)
    return fixed

def build_reverse_relation_map(all_models):
    """
    Build a map of what reverse relations need to be added.
    For each relation A -> B with name "X", we need to add
    a reverse relation B -> A with name "X" if it doesn't exist.
    """
    reverse_map = {}
    
    for model_name, model_text in all_models.items():
        relations = get_relations(model_text)
        for rel in relations:
            target = rel['target']
            relation_name = rel['name']
            
            if target not in reverse_map:
                reverse_map[target] = []
            reverse_map[target].append({
                'source_model': model_name,
                'relation_name': relation_name
            })
    
    return reverse_map

def add_missing_reverse_relations(models, reverse_map):
    """Add missing reverse relations to models."""
    updated = dict(models)
    
    for target_model, relations in reverse_map.items():
        if target_model not in updated:
            continue
        
        target_text = updated[target_model]
        target_relations = get_relations(target_text)
        existing_relation_names = [r['name'] for r in target_relations]
        
        for rel_info in relations:
            source_model = rel_info['source_model']
            relation_name = rel_info['relation_name']
            
            # Check if reverse relation already exists
            if relation_name in existing_relation_names:
                continue
            
            # Add the reverse relation
            field_name = source_model.lower() + 's'
            lines = target_text.rstrip().split('\n')
            if lines and lines[-1].strip() == '}':
                lines = lines[:-1]
            lines.append(f'  {field_name} {source_model}[] @relation("{relation_name}")')
            lines.append('}')
            target_text = '\n'.join(lines)
            existing_relation_names.append(relation_name)
        
        updated[target_model] = target_text
    
    return updated

# Read schemas
print("Reading schemas...")
with open('../maydan/prisma/schema.prisma', 'r') as f:
    source = f.read()

with open('prisma/checkpoints/005-all-systems-merged.prisma', 'r') as f:
    checkpoint = f.read()

source_models = extract_models(source)
source_enums = extract_enums(source)
checkpoint_models = extract_models(checkpoint)
checkpoint_enums = extract_enums(checkpoint)

print(f"Source: {len(source_models)} models, {len(source_enums)} enums")
print(f"Checkpoint: {len(checkpoint_models)} models, {len(checkpoint_enums)} enums")

# Merge: start with source, add checkpoint models not in source
all_models = dict(source_models)
for name, text in checkpoint_models.items():
    if name not in all_models:
        all_models[name] = text

# Merge enums
all_enums = dict(source_enums)
for name, text in checkpoint_enums.items():
    if name not in all_enums:
        all_enums[name] = text

print(f"Combined: {len(all_models)} models, {len(all_enums)} enums")

# Fix indexes in all models
print("Fixing indexes...")
all_models = fix_relation_indexes(all_models)

# Build reverse relation map
print("Building relation map...")
reverse_map = build_reverse_relation_map(all_models)

# Add missing reverse relations
print("Adding reverse relations...")
all_models = add_missing_reverse_relations(all_models, reverse_map)

# Build final schema
print("Building final schema...")
final = []

# Add header from source
header_match = re.search(r'(.*?)^model\s', source, re.DOTALL | re.MULTILINE)
if header_match:
    final.append(header_match.group(1))

# Add enums
for name in sorted(all_enums):
    final.append(all_enums[name])

# Add models
final.append('\n// ============================================')
final.append('// All Models')
final.append('// ============================================\n')

for name in sorted(all_models):
    final.append(all_models[name])

with open('prisma/schema.prisma', 'w') as f:
    f.write('\n\n'.join(final))

print(f"\n✅ Final schema: {len(all_models)} models, {len(all_enums)} enums")
