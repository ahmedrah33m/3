/**
 * Complete schema builder
 * Reads base schema, adds all new models + reverse relations, validates
 */

const fs = require('fs');

// Read base schema
const base = fs.readFileSync('prisma/schema.base.prisma', 'utf8');
const baseLines = base.split('\n');

// Parse existing models from base schema
const existingModels = [];
let currentModel = null;

for (const line of baseLines) {
  const trimmed = line.trim();
  if (trimmed.startsWith('model ') && trimmed.includes('{')) {
    const name = trimmed.split(/\s+/)[1];
    currentModel = { name, lines: [], relations: [] };
    existingModels.push(currentModel);
  } else if (trimmed === '}' && currentModel) {
    currentModel.lines.push(line);
    currentModel = null;
  }
  if (currentModel) {
    currentModel.lines.push(line);
  }
}

console.log(`Existing models: ${existingModels.length}`);

// Find unique insertion points for each existing model
function findModelEnd(modelName) {
  const idx = baseLines.findIndex(l => l.trim().startsWith(`model ${modelName} `) && l.trim().includes('{'));
  if (idx === -1) return -1;
  let depth = 0;
  for (let i = idx; i < baseLines.length; i++) {
    const t = baseLines[i].trim();
    if (t.includes('{')) depth++;
    if (t.includes('}')) depth--;
    if (depth === 0 && t === '}') return i;
  }
  return -1;
}

// New models to add
const newModels = [];

newModels.push(`model EmploymentContract {
  id                String   @id @default(cuid())
  employeeId        String?
  companyId         String
  offerId           String?  @unique
  contractType      String   @default("FULL_TIME")
  contractNumber    String?  @unique
  startDate         DateTime
  endDate           DateTime?
  probationMonths   Int      @default(3)
  probationEndDate  DateTime?
  terminationDate   DateTime?
  terminationReason String?
  baseSalary        Decimal  @db.Decimal(18, 3)
  salaryCurrency    String   @default("IQD")
  paymentFrequency  String   @default("MONTHLY")
  paymentMethod     String   @default("BANK_TRANSFER")
  workingHours      String?
  benefits          Json?
  leavePolicyId     String?
  attachments       Json?
  companySignedAt   DateTime?
  companySignedById String?
  employeeSignedAt  DateTime?
  employeeSignature String?
  companySignature  String?
  version           Int      @default(1)
  parentContractId  String?
  status            String   @default("DRAFT")
  contractFileUrl   String?
  createdById       String
  approvedById      String?
  approvedAt        DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee? @relation("EmploymentContractEmployee", fields: [employeeId], references: [id], onDelete: SetNull)
  company           Company  @relation("EmploymentContractCompany", fields: [companyId], references: [id], onDelete: Cascade)
  offer             Offer?   @relation("EmploymentContractOffer", fields: [offerId], references: [id], onDelete: SetNull)
  salaryStructures SalaryStructure[] @relation("SalaryStructureContract")
  payrollEmployees PayrollEmployee[] @relation("PayrollEmployeeContract")
  @@index([employeeId])
  @@index([companyId])
  @@index([offerId])
  @@index([status])
  @@index([startDate])
}`);

newModels.push(`model SalaryStructure {
  id                String   @id @default(cuid())
  employeeId        String
  contractId        String
  companyId         String
  effectiveFrom     DateTime
  effectiveTo       DateTime?
  isActive          Boolean  @default(true)
  baseSalary        Decimal  @db.Decimal(18, 3)
  currency          String   @default("IQD")
  totalAllowances   Decimal  @default(0) @db.Decimal(18, 3)
  totalDeductions   Decimal  @default(0) @db.Decimal(18, 3)
  grossSalary       Decimal  @default(0) @db.Decimal(18, 3)
  netSalary         Decimal  @default(0) @db.Decimal(18, 3)
  createdById       String
  approvedById      String?
  approvedAt        DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
  employee          Employee          @relation("SalaryStructureEmployee", fields: [employeeId], references: [id], onDelete: Cascade)
  contract          EmploymentContract @relation("SalaryStructureContract", fields: [contractId], references: [id], onDelete: Cascade)
  company           Company           @relation("SalaryStructureCompany", fields: [companyId], references: [id], onDelete: Cascade)
  salaryComponents SalaryComponent[] @relation("SalaryComponentStructure")
  allowances Allowance[] @relation("AllowanceStructure")
  deductions Deduction[] @relation("DeductionStructure")
  bonuses Bonus[] @relation("BonusStructure")
  @@index([employeeId])
  @@index([contractId])
  @@index([companyId])
  @@index([isActive])
  @@index([effectiveFrom])
}`);

console.log(`New models defined: ${newModels.length}`);

// Reverse relations to add to existing models
const reverseRelations = {
  Employee: `  employmentContracts EmploymentContract[] @relation("EmploymentContractEmployee")
  salaryStructures SalaryStructure[] @relation("SalaryStructureEmployee")
  allowances Allowance[] @relation("AllowanceEmployee")
  deductions Deduction[] @relation("DeductionEmployee")
  bonuses Bonus[] @relation("BonusEmployee")
  overtimes Overtime[] @relation("OvertimeEmployee")
  attendances Attendance[] @relation("AttendanceEmployee")
  leaveRecords LeaveRecord[] @relation("LeaveRecordEmployee")
  payrollEmployees PayrollEmployee[] @relation("PayrollEmployeeEmployee")
  payslips Payslip[] @relation("PayslipEmployee2")
  payrollHistories PayrollHistory[] @relation("PayrollHistoryEmployee")
  adjustments Adjustment[] @relation("AdjustmentEmployee2")
  employeeDocuments EmployeeDocument[] @relation("EmployeeDocumentEmployee")
  employeeOnboardings EmployeeOnboarding[] @relation("EmployeeOnboardingEmployee")
  onboardingTaskInstances OnboardingTaskInstance[] @relation("OnboardingTaskInstanceEmployee")`,
  
  Company: `  employmentContracts EmploymentContract[] @relation("EmploymentContractCompany")
  salaryStructures SalaryStructure[] @relation("SalaryStructureCompany")
  salaryComponents SalaryComponent[] @relation("SalaryComponentCompany")
  allowances Allowance[] @relation("AllowanceCompany")
  deductions Deduction[] @relation("DeductionCompany")
  bonuses Bonus[] @relation("BonusCompany")
  overtimes Overtime[] @relation("OvertimeCompany")
  shifts Shift[] @relation("ShiftCompany")
  attendances Attendance[] @relation("AttendanceCompany")
  leavePolicies LeavePolicy[] @relation("LeavePolicyCompany")
  leaveRecords LeaveRecord[] @relation("LeaveRecordCompany")
  payrollPeriods PayrollPeriod[] @relation("PayrollPeriodCompany")
  payrollRuns PayrollRun[] @relation("PayrollRunCompany")
  payrollEmployees PayrollEmployee[] @relation("PayrollEmployeeCompany")
  payslips Payslip[] @relation("PayslipCompany")
  payrollHistories PayrollHistory[] @relation("PayrollHistoryCompany")
  payrollRules PayrollRule[] @relation("PayrollRuleCompany")
  taxRules TaxRule[] @relation("TaxRuleCompany")
  adjustments Adjustment[] @relation("AdjustmentCompany")
  employeeDocuments EmployeeDocument[] @relation("EmployeeDocumentCompany")
  onboardingTemplates OnboardingTemplate[] @relation("OnboardingTemplateCompany")
  onboardingTasks OnboardingTask[] @relation("OnboardingTaskCompany")
  employeeOnboardings EmployeeOnboarding[] @relation("EmployeeOnboardingCompany")`,
  
  Offer: `  employmentContract EmploymentContract? @relation("EmploymentContractOffer")`,
  
  User: `  employmentVerifications EmploymentVerification[] @relation("EmploymentVerificationUser")
  employeeOnboardings EmployeeOnboarding[] @relation("OnboardingAssignedTo")
  liveRooms LiveRoom[] @relation("LiveRoomHost")
  liveRoomParticipants LiveRoomParticipant[] @relation("LiveRoomParticipantUser")
  liveRoomMessages LiveRoomMessage[] @relation("LiveRoomMessageUser")
  liveTranscripts LiveTranscript[] @relation("LiveTranscriptSpeaker")
  liveRoomNotifications LiveRoomNotification[] @relation("LiveRoomNotificationUser")
  liveRoomModerationLogs LiveRoomModerationLog[] @relation("ModerationTarget")
  liveRoomModerationActions LiveRoomModerationLog[] @relation("ModerationAction")
  liveRoomHistories LiveRoomHistory[] @relation("LiveRoomHistoryUser")
  liveRoomReactions LiveRoomReaction[] @relation("LiveRoomReactionUser")
  liveRoomInvitesSent LiveRoomInvite[] @relation("InviteSender")
  liveRoomInvitesReceived LiveRoomInvite[] @relation("InviteRecipient")`
};

console.log(`Reverse relations defined for: ${Object.keys(reverseRelations).join(', ')}`);

// Insert reverse relations into existing models
let modifiedBase = base;
for (const [modelName, relations] of Object.entries(reverseRelations)) {
  const endIdx = findModelEnd(modelName);
  if (endIdx === -1) {
    console.log(`WARNING: Could not find model ${modelName}`);
    continue;
  }
  // Insert before the closing }
  const before = baseLines.slice(0, endIdx);
  const after = baseLines.slice(endIdx);
  baseLines.splice(endIdx, 0, relations);
  // Re-read modified base
  modifiedBase = baseLines.join('\n');
  // Re-find insertion points since indices changed
  // Re-parse
  existingModels.length = 0;
  currentModel = null;
  for (const line of baseLines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('model ') && trimmed.includes('{')) {
      const name = trimmed.split(/\s+/)[1];
      currentModel = { name, lines: [] };
      existingModels.push(currentModel);
    } else if (trimmed === '}' && currentModel) {
      currentModel = null;
    }
  }
}

console.log(`Modified base with reverse relations`);

// Now append all new models at the end
const output = baseLines.join('\n') + '\n\n// ============================================\n// New Models (from additions)\n// ============================================\n\n' + newModels.join('\n\n');

// Write to schema.prisma
fs.writeFileSync('prisma/schema.prisma', output);
console.log(`Written ${output.split('\n').length} lines to schema.prisma`);

// Count models
const modelCount = (output.match(/^model /gm) || []).length;
console.log(`Total models: ${modelCount}`);
