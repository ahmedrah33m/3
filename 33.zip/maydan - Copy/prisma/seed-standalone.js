/**
 * سكريبت إنشاء مستخدم تجريبي مستقل
 * لا يعتمد على أي استيراد من src/ — يُستخدم كـ fallback موثوق
 *
 * الاستخدام: node prisma/seed-standalone.js
 * أو: npx tsx prisma/seed-standalone.ts
 */
const { PrismaClient } = require("@prisma/client")
const crypto = require("crypto")

const prisma = new PrismaClient()

const SEED_PASSWORD = "SeedPass1!"

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex")
  const hash = crypto.scryptSync(password, salt, 64).toString("hex")
  return `${salt}:${hash}`
}

async function main() {
  console.log("🌱 إنشاء المستخدم التجريبي...")

  const passwordHash = hashPassword(SEED_PASSWORD)

  const owner = await prisma.user.upsert({
    where: { email: "owner@midaniq.com" },
    update: {
      password: passwordHash,
      role: "OWNER",
      name: "مالك ميدان",
      emailVerified: true,
      isVerified: true,
    },
    create: {
      email: "owner@midaniq.com",
      password: passwordHash,
      name: "مالك ميدان",
      role: "OWNER",
      userType: "economist",
      emailVerified: true,
      isVerified: true,
    },
  })

  console.log("✅ المستخدم الرئيسي:", owner.email, "| Role:", owner.role)

  const settings = await prisma.siteSettings.upsert({
    where: { id: "main" },
    update: {},
    create: {
      id: "main",
      registrationEnabled: true,
    },
  })

  console.log("✅ إعدادات الموقع: registrationEnabled =", settings.registrationEnabled)

  const userCount = await prisma.user.count()
  console.log(`✅ إجمالي المستخدمين في قاعدة البيانات: ${userCount}`)
}

main()
  .catch((e) => {
    console.error("❌ خطأ في seed-standalone:", e.message)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })