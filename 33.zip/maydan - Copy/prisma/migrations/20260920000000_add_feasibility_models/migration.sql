﻿-- CreateTable
CREATE TABLE "FeasibilityStudy" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "projectType" TEXT NOT NULL DEFAULT 'OTHER',
    "sector" TEXT,
    "subSector" TEXT,
    "niche" TEXT,
    "templateKey" TEXT,
    "country" TEXT NOT NULL DEFAULT 'IQ',
    "governorate" TEXT,
    "city" TEXT,
    "area" TEXT,
    "projectMode" TEXT,
    "projectPhase" TEXT NOT NULL DEFAULT 'IDEA',
    "startYear" INTEGER NOT NULL DEFAULT 2026,
    "operatingYear" INTEGER NOT NULL DEFAULT 2027,
    "forecastYears" INTEGER NOT NULL DEFAULT 5,
    "currency" TEXT NOT NULL DEFAULT 'IQD',
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "currentStep" INTEGER NOT NULL DEFAULT 1,
    "version" INTEGER NOT NULL DEFAULT 1,
    "understanding" JSONB,
    "metadata" JSONB,
    "discountRate" DECIMAL(6,3) NOT NULL DEFAULT 15,
    "inflationRate" DECIMAL(6,3) NOT NULL DEFAULT 4,
    "fxRateUsd" DECIMAL(14,4) NOT NULL DEFAULT 1300,
    "fxRateEur" DECIMAL(14,4) NOT NULL DEFAULT 1400,
    "taxRateDefault" DECIMAL(6,3) NOT NULL DEFAULT 15,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityStudy_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityProduct" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT,
    "sku" TEXT,
    "unit" TEXT NOT NULL DEFAULT 'ظˆط­ط¯ط©',
    "price" DECIMAL(18,3) NOT NULL,
    "unitCost" DECIMAL(18,3),
    "avgDailyUnits" DECIMAL(12,3) NOT NULL DEFAULT 0,
    "operatingDaysPerMonth" INTEGER NOT NULL DEFAULT 30,
    "seasonalityFactor" DECIMAL(6,3) NOT NULL DEFAULT 1,
    "rampUpFactor" DECIMAL(6,3) NOT NULL DEFAULT 1,
    "growthRate" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityProduct_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityRevenueStream" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'PRIMARY',
    "monthlyAmount" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "growthRate" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityRevenueStream_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityCapexItem" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'OTHER',
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "unitCost" DECIMAL(18,3) NOT NULL,
    "depreciable" BOOLEAN NOT NULL DEFAULT true,
    "usefulLifeYears" INTEGER,
    "salvageValue" DECIMAL(18,3),
    "purchaseYear" INTEGER NOT NULL DEFAULT 0,
    "financingMethod" TEXT NOT NULL DEFAULT 'CASH',
    "prepaidMonths" INTEGER,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityCapexItem_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityOpexItem" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "costBehavior" TEXT NOT NULL DEFAULT 'FIXED',
    "category" TEXT NOT NULL DEFAULT 'OTHER',
    "monthlyAmount" DECIMAL(18,3),
    "variablePercent" DECIMAL(8,4),
    "linkedToRevenue" BOOLEAN NOT NULL DEFAULT false,
    "growthRate" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "startYear" INTEGER NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityOpexItem_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityEmployee" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "jobTitle" TEXT NOT NULL,
    "department" TEXT,
    "count" INTEGER NOT NULL DEFAULT 1,
    "monthlySalary" DECIMAL(18,3) NOT NULL,
    "allowances" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "employerCostRate" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "annualBonus" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "hiringYear" INTEGER NOT NULL DEFAULT 0,
    "salaryGrowthRate" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "fullTime" BOOLEAN NOT NULL DEFAULT true,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityEmployee_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityUtility" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'ELECTRICITY',
    "description" TEXT,
    "monthlyBaseAmount" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "quantity" DECIMAL(14,3),
    "unit" TEXT,
    "costPerUnit" DECIMAL(14,4),
    "seasonalFactor" DECIMAL(6,3) NOT NULL DEFAULT 1,
    "growthRate" DECIMAL(6,3) NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityUtility_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityTax" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "rate" DECIMAL(8,4) NOT NULL,
    "appliesTo" TEXT NOT NULL DEFAULT 'NET_INCOME',
    "exemptForYears" INTEGER NOT NULL DEFAULT 0,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityTax_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityWorkingCapital" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "arDays" INTEGER NOT NULL DEFAULT 0,
    "inventoryDays" INTEGER NOT NULL DEFAULT 0,
    "apDays" INTEGER NOT NULL DEFAULT 0,
    "cashReserveMonths" DECIMAL(5,2) NOT NULL DEFAULT 1,
    "minCashAmount" DECIMAL(18,3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityWorkingCapital_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityFundingSource" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "sourceType" TEXT NOT NULL DEFAULT 'OWNER_EQUITY',
    "amount" DECIMAL(18,3) NOT NULL,
    "isGrant" BOOLEAN NOT NULL DEFAULT false,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityFundingSource_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityLoan" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "principal" DECIMAL(18,3) NOT NULL,
    "annualInterestRate" DECIMAL(8,4) NOT NULL,
    "termMonths" INTEGER NOT NULL,
    "gracePeriodMonths" INTEGER NOT NULL DEFAULT 0,
    "interestOnlyDuringGrace" BOOLEAN NOT NULL DEFAULT false,
    "startYear" INTEGER NOT NULL DEFAULT 0,
    "paymentFrequency" TEXT NOT NULL DEFAULT 'MONTHLY',
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityLoan_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityAssumption" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "value" JSONB NOT NULL,
    "source" TEXT NOT NULL DEFAULT 'USER_INPUT',
    "status" TEXT NOT NULL DEFAULT 'USER_PROVIDED',
    "reference" TEXT,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityAssumption_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityRisk" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'OTHER',
    "probability" INTEGER NOT NULL DEFAULT 50,
    "impact" INTEGER NOT NULL DEFAULT 50,
    "score" INTEGER NOT NULL DEFAULT 0,
    "mitigation" TEXT,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityRisk_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityMarketDatum" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'OTHER',
    "value" JSONB NOT NULL,
    "unit" TEXT,
    "sourceName" TEXT,
    "sourceUrl" TEXT,
    "sourceType" TEXT NOT NULL DEFAULT 'OTHER',
    "collectedAt" TIMESTAMP(3),
    "status" TEXT NOT NULL DEFAULT 'USER_PROVIDED',
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityMarketDatum_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityCompetitor" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "category" TEXT,
    "priceLevel" TEXT NOT NULL DEFAULT 'MEDIUM',
    "priceReference" DECIMAL(18,3),
    "monthlySalesEst" DECIMAL(18,3),
    "strength" JSONB,
    "weakness" JSONB,
    "marketShareEst" DECIMAL(8,4),
    "notes" TEXT,
    "source" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityCompetitor_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityScenario" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "name" TEXT NOT NULL DEFAULT 'BASE',
    "label" TEXT,
    "adjustments" JSONB,
    "results" JSONB,
    "kpis" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeasibilityScenario_pkey" PRIMARY KEY ("id")
);
-- CreateTable
CREATE TABLE "FeasibilityExportRecord" (
    "id" TEXT NOT NULL,
    "studyId" TEXT NOT NULL,
    "format" TEXT NOT NULL DEFAULT 'PDF',
    "status" TEXT NOT NULL DEFAULT 'GENERATED',
    "fileUrl" TEXT,
    "message" TEXT,
    "requestedBy" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "FeasibilityExportRecord_pkey" PRIMARY KEY ("id")
);
-- CreateIndex
CREATE INDEX "FeasibilityStudy_userId_idx" ON "FeasibilityStudy"("userId");
-- CreateIndex
CREATE INDEX "FeasibilityStudy_userId_status_idx" ON "FeasibilityStudy"("userId", "status");
-- CreateIndex
CREATE INDEX "FeasibilityStudy_userId_updatedAt_idx" ON "FeasibilityStudy"("userId", "updatedAt");
-- CreateIndex
CREATE INDEX "FeasibilityProduct_studyId_idx" ON "FeasibilityProduct"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityRevenueStream_studyId_idx" ON "FeasibilityRevenueStream"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityCapexItem_studyId_idx" ON "FeasibilityCapexItem"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityOpexItem_studyId_idx" ON "FeasibilityOpexItem"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityEmployee_studyId_idx" ON "FeasibilityEmployee"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityUtility_studyId_idx" ON "FeasibilityUtility"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityTax_studyId_idx" ON "FeasibilityTax"("studyId");
-- CreateIndex
CREATE UNIQUE INDEX "FeasibilityWorkingCapital_studyId_key" ON "FeasibilityWorkingCapital"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityFundingSource_studyId_idx" ON "FeasibilityFundingSource"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityLoan_studyId_idx" ON "FeasibilityLoan"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityAssumption_studyId_idx" ON "FeasibilityAssumption"("studyId");
-- CreateIndex
CREATE UNIQUE INDEX "FeasibilityAssumption_studyId_key_key" ON "FeasibilityAssumption"("studyId", "key");
-- CreateIndex
CREATE INDEX "FeasibilityRisk_studyId_idx" ON "FeasibilityRisk"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityMarketDatum_studyId_idx" ON "FeasibilityMarketDatum"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityCompetitor_studyId_idx" ON "FeasibilityCompetitor"("studyId");
-- CreateIndex
CREATE INDEX "FeasibilityScenario_studyId_idx" ON "FeasibilityScenario"("studyId");
-- CreateIndex
CREATE UNIQUE INDEX "FeasibilityScenario_studyId_name_key" ON "FeasibilityScenario"("studyId", "name");
-- CreateIndex
CREATE INDEX "FeasibilityExportRecord_studyId_idx" ON "FeasibilityExportRecord"("studyId");
-- AddForeignKey
ALTER TABLE "FeasibilityStudy" ADD CONSTRAINT "FeasibilityStudy_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityProduct" ADD CONSTRAINT "FeasibilityProduct_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityRevenueStream" ADD CONSTRAINT "FeasibilityRevenueStream_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityCapexItem" ADD CONSTRAINT "FeasibilityCapexItem_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityOpexItem" ADD CONSTRAINT "FeasibilityOpexItem_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityEmployee" ADD CONSTRAINT "FeasibilityEmployee_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityUtility" ADD CONSTRAINT "FeasibilityUtility_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityTax" ADD CONSTRAINT "FeasibilityTax_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityWorkingCapital" ADD CONSTRAINT "FeasibilityWorkingCapital_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityFundingSource" ADD CONSTRAINT "FeasibilityFundingSource_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityLoan" ADD CONSTRAINT "FeasibilityLoan_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityAssumption" ADD CONSTRAINT "FeasibilityAssumption_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityRisk" ADD CONSTRAINT "FeasibilityRisk_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityMarketDatum" ADD CONSTRAINT "FeasibilityMarketDatum_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityCompetitor" ADD CONSTRAINT "FeasibilityCompetitor_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityScenario" ADD CONSTRAINT "FeasibilityScenario_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
-- AddForeignKey
ALTER TABLE "FeasibilityExportRecord" ADD CONSTRAINT "FeasibilityExportRecord_studyId_fkey" FOREIGN KEY ("studyId") REFERENCES "FeasibilityStudy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
