-- CreateTable
CREATE TABLE "ResearchJournal" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "nameAr" TEXT,
    "issn" TEXT,
    "publisher" TEXT,
    "publisherAr" TEXT,
    "country" TEXT NOT NULL DEFAULT 'Iraq',
    "language" TEXT NOT NULL DEFAULT 'ar',
    "category" TEXT NOT NULL,
    "description" TEXT,
    "scope" TEXT,
    "impactFactor" TEXT,
    "scopus" BOOLEAN NOT NULL DEFAULT false,
    "openAccess" BOOLEAN NOT NULL DEFAULT false,
    "indexedIn" JSONB,
    "frequency" TEXT,
    "reviewTime" TEXT,
    "acceptanceRate" TEXT,
    "apcFee" TEXT,
    "submissionUrl" TEXT,
    "website" TEXT,
    "email" TEXT,
    "coverImage" TEXT,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ResearchJournal_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ResearchJournal_category_idx" ON "ResearchJournal"("category");

-- CreateIndex
CREATE INDEX "ResearchJournal_status_idx" ON "ResearchJournal"("status");

-- Seed: دليل المجلات العلمية (بيانات مرجعية)
INSERT INTO "ResearchJournal"
  ("id", "name", "nameAr", "issn", "publisher", "publisherAr", "country", "language", "category", "description", "scope", "impactFactor", "scopus", "openAccess", "indexedIn", "frequency", "reviewTime", "acceptanceRate", "apcFee", "submissionUrl", "website", "email", "status", "createdAt", "updatedAt")
VALUES
  (
    'jrnl-ijes', 'Iraqi Journal of Economic Sciences', 'المجلة العراقية للعلوم الاقتصادية',
    '1812-7601', 'University of Baghdad', 'جامعة بغداد، كلية الإدارة والاقتصاد',
    'Iraq', 'ar', 'اقتصادي',
    'مجلة أكاديمية محكمة تصدر عن كلية الإدارة والاقتصاد في جامعة بغداد، وتغطي الأبحاث الاقتصادية والمالية والتنموية الخاصة بالعراق والمنطقة العربية.',
    'الاقتصاد الكلي والنقدي، التنمية الاقتصادية، التمويل والمصارف، الطاقة والبترول، التجارة والسياسات الاقتصادية.',
    '0.45', false, true,
    '["Google Scholar", "EBSCO", "DOAJ"]',
    'فصلية', '3-6 أشهر', '35%', NULL,
    'https://coadec.uobaghdad.edu.iq/', 'https://coadec.uobaghdad.edu.iq/', 'ijes@coadec.uobaghdad.edu.iq',
    'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  ),
  (
    'jrnl-jeas', 'Journal of Economics and Administrative Sciences', 'مجلة العلوم الاقتصادية والإدارية',
    '1026-6219', 'University of Baghdad', 'جامعة بغداد',
    'Iraq', 'ar', 'اقتصاد وإدارة',
    'مجلة علمية محكمة تصدرها جامعة بغداد وتستقبل أوراق العمل البحثية في مجالي الاقتصاد والعلوم الإدارية مع التركيز على التطبيقات العراقية.',
    'الاقتصاد التطبيقي، الإدارة العامة، إدارة الأعمال، المحاسبة والتدقيق، الإحصاء التطبيقي.',
    '0.38', false, false,
    '["Google Scholar", "EBSCO"]',
    'فصلية', '4-8 أشهر', '40%', NULL,
    'https://jeasg.uobaghdad.edu.iq/', 'https://jeasg.uobaghdad.edu.iq/', 'jeas@coadec.uobaghdad.edu.iq',
    'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  ),
  (
    'jrnl-aer', 'Arab Economic Review', 'مجلة الاقتصاد العربي',
    '1816-9894', 'Elsevier', 'إلزيفير',
    'International', 'en', 'اقتصاد دولي',
    'مجلة دولية محكمة تُعنى بالاقتصاد العربي وتحولاته، وتنشر دراسات حول النمو والتنويع الاقتصادي وأثر السياسات المالية والنقدية في الاقتصادات العربية.',
    'الاقتصاد الكلي، السياسات المالية والنقدية، التجارة الخارجية، الاستثمار الأجنبي، الاقتصاد القياسي.',
    '1.2', true, false,
    '["Scopus", "EBSCO", "ProQuest"]',
    'ربع سنوية', '2-4 أشهر', '22%', 'USD 1500',
    NULL, NULL, NULL,
    'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  ),
  (
    'jrnl-med', 'Middle East Development Journal', 'مجلة تنمية الشرق الأوسط',
    '1793-8198', 'Taylor & Francis', 'تايلور وفرانسيس',
    'International', 'en', 'تنمية اقتصادية',
    'مجلة أكاديمية محكمة تنشرها Routledge ضمن تايلور وفرانسيس، وتتناول قضايا التنمية الاقتصادية والاجتماعية في منطقة الشرق الأوسط وشمال أفريقيا.',
    'التنمية الاقتصادية، سوق العمل، التنمية البشرية، الحوكمة والمؤسسات، إعادة إعمار الاقتصادات.',
    '0.89', true, false,
    '["Scopus", "EBSCO"]',
    'فصلية', '3-5 أشهر', '28%', 'USD 1900',
    NULL, NULL, NULL,
    'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  ),
  (
    'jrnl-ksu', 'Journal of King Saud University - Economics', 'مجلة جامعة الملك سعود للاقتصاد',
    '1018-5941', 'King Saud University', 'جامعة الملك سعود',
    'Saudi Arabia', 'en', 'اقتصادي',
    'مجلة محكمة تصدر عن جامعة الملك سعود بالشراكة مع إلزيفير، متاحة بنموذج الوصول المفتوح، وتغطي الاقتصاد التطبيقي والنظري والسياسات الاقتصادية.',
    'الاقتصاد التطبيقي، الاقتصاد القياسي، المالية العامة، الطاقة والعملات، السياسات الاقتصادية.',
    '1.5', true, true,
    '["Scopus", "DOAJ"]',
    'ربع سنوية', '2-3 أشهر', '18%', 'USD 1200',
    NULL, 'https://www.ksu.edu.sa/', NULL,
    'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
  );