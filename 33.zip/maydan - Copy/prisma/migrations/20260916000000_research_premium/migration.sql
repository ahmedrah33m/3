-- Mark research as premium (paid) content
ALTER TABLE "Research" ADD COLUMN IF NOT EXISTS "isPremium" BOOLEAN NOT NULL DEFAULT false;