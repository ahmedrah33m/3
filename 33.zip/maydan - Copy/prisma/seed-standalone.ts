/**
 * سكريبت إنشاء مستخدم تجريبي مستقل
 * لا يعتمد على أي استيراد من src/ — يُستخدم كـ fallback موثوق
 *
 * الاستخدام: npx tsx prisma/seed-standalone.ts
 */
import { PrismaClient } from '@prisma/client'
import { randomBytes, scryptSync } from 'crypto'

const prisma = new PrismaClient()

const SEED_PASSWORD = 'SeedPass1!'

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

async function main() {
  console.log('🌱 إنشاء المستخدم التجريبي...')

  const passwordHash = hashPassword(SEED_PASSWORD)

  // إنشاء أو تحديث المستخدم الرئيسي
  const owner = await prisma.user.upsert({
    where: { email: 'owner@midaniq.com' },
    update: {
      password: passwordHash,
      role: 'OWNER',
      name: 'مدير ميدان',
      emailVerified: new Date(),
      isVerified: true,
    },
    create: {
      id: 'user_owner',
      email: 'owner@midaniq.com',
      password: passwordHash,
      name: 'مدير ميدان',
      role: 'OWNER',
      userType: 'economist',
      emailVerified: new Date(),
      isVerified: true,
    },
  })

  console.log('✅ المستخدم الرئيسي:', owner.email, '| Role:', owner.role)

  // إنشاء إعدادات الموقع إذا غير موجودة
  const settings = await prisma.siteSettings.upsert({
    where: { id: 'main' },
    update: {},
    create: {
      id: 'main',
      registrationEnabled: true,
    },
  })

  console.log('✅ إعدادات الموقع: registrationEnabled =', settings.registrationEnabled)

  const userCount = await prisma.user.count()
  console.log(`✅ إجمالي المستخدمين في قاعدة البيانات: ${userCount}`)
}

main()
  .catch((e) => {
    console.error('❌ خطأ في seed-standalone:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })