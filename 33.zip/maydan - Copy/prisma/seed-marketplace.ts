import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// تصنيفات الخدمات من متطلبات سوق ميدان
const serviceCategories = [
  { name: 'نجارة', nameEn: 'Carpentry', icon: '🪵', description: 'أعمال النجارة والخشب' },
  { name: 'كهرباء', nameEn: 'Electrician', icon: '⚡', description: 'أعمال كهربائية عامة ومنزلية' },
  { name: 'سباكة', nameEn: 'Plumbing', icon: '🚰', description: 'أعمال السباكة والتمديدات' },
  { name: 'حدادة', nameEn: 'Blacksmith', icon: '🔩', description: 'أعمال الحدادة واللحام' },
  { name: 'صباغة', nameEn: 'Painting', icon: '🎨', description: 'أعمال الدهان والصباغة' },
  { name: 'ميكانيك', nameEn: 'Mechanics', icon: '🔧', description: 'ميكانيك سيارات ومعدات' },
  { name: 'تكييف وتبريد', nameEn: 'HVAC', icon: '❄️', description: 'تركيب وصيانة التكييف' },
  { name: 'كاميرات مراقبة', nameEn: 'CCTV', icon: '📹', description: 'تركيب وصيانة كاميرات المراقبة' },
  { name: 'تصميم', nameEn: 'Design', icon: '🎯', description: 'تصميم جرافيكي وهوية بصرية' },
  { name: 'برمجة وتطوير', nameEn: 'Programming', icon: '💻', description: 'برمجة وتطوير المواقع والتطبيقات' },
  { name: 'ترجمة', nameEn: 'Translation', icon: '🌐', description: 'ترجمة اللغات' },
  { name: 'محاسبة', nameEn: 'Accounting', icon: '🧾', description: 'خدمات محاسبية وضريبية' },
  { name: 'محاماة', nameEn: 'Law', icon: '⚖️', description: 'استشارات وخدمات قانونية' },
  { name: 'استشارات', nameEn: 'Consulting', icon: '💼', description: 'استشارات إدارية واقتصادية' },
  { name: 'تدريس', nameEn: 'Tutoring', icon: '📚', description: 'دروس خصوصية وتعليم' },
  { name: 'تصوير', nameEn: 'Photography', icon: '📷', description: 'تصوير فوتوغرافي وفيديو' },
  { name: 'رعاية بيطرية', nameEn: 'Veterinary', icon: '🐾', description: 'رعاية الطيور والحيوانات' },
  { name: 'خدمات تنظيف', nameEn: 'Cleaning', icon: '🧹', description: 'تنظيف منازل ومكاتب' },
  { name: 'نقل وتوصيل', nameEn: 'Transport', icon: '🚚', description: 'نقل أثاث وبضائع' },
  { name: 'شحن', nameEn: 'Shipping', icon: '📦', description: 'شحن محلي ودولي' },
  { name: 'صحة وجمال', nameEn: 'Beauty & Health', icon: '💇', description: 'خدمات العناية والجمال' },
  { name: 'طبخ وضيافة', nameEn: 'Catering', icon: '🍽️', description: 'خدمات طعام وضيافة' },
]

// تصنيفات المنتجات
const productCategories = [
  { name: 'منتجات جديدة', nameEn: 'New Products', icon: '🛍️', description: 'منتجات جديدة بجميع الأنواع' },
  { name: 'منتجات مستعملة', nameEn: 'Used Products', icon: '♻️', description: 'منتجات مستعملة بحالة جيدة' },
  { name: 'منتجات محلية', nameEn: 'Local Products', icon: '🏷️', description: 'منتجات عراقية محلية' },
  { name: 'منتجات يدوية', nameEn: 'Handmade', icon: '✋', description: 'منتجات حرفية يدوية' },
  { name: 'معدات البناء', nameEn: 'Construction Equipment', icon: '🏗️', description: 'معدات البناء والإنشاءات' },
  { name: 'معدات المصانع', nameEn: 'Factory Equipment', icon: '🏭', description: 'معدات المصانع والإنتاج' },
  { name: 'معدات زراعية', nameEn: 'Agricultural Equipment', icon: '🌾', description: 'معدات الزراعة والري' },
  { name: 'معدات طبية', nameEn: 'Medical Equipment', icon: '🏥', description: 'أجهزة ومعدات طبية' },
  { name: 'معدات الورش', nameEn: 'Workshop Tools', icon: '🔨', description: 'أدوات ومعدات الورش' },
  { name: 'معدات كهربائية', nameEn: 'Electrical Equipment', icon: '🔌', description: 'أجهزة ومعدات كهربائية' },
]

async function main() {
  let created = 0
  for (const c of serviceCategories) {
    const existing = await prisma.marketplaceCategory.findFirst({ where: { name: c.name, type: 'SERVICE' } })
    if (!existing) {
      await prisma.marketplaceCategory.create({
        data: {
          ...c,
          type: 'SERVICE',
          slug: `${c.nameEn.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36)}`,
          sort: created,
        },
      })
      created++
    }
  }
  for (const c of productCategories) {
    const existing = await prisma.marketplaceCategory.findFirst({ where: { name: c.name, type: 'PRODUCT' } })
    if (!existing) {
      await prisma.marketplaceCategory.create({
        data: {
          ...c,
          type: 'PRODUCT',
          slug: `${c.nameEn.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${Date.now().toString(36)}`,
          sort: created,
        },
      })
      created++
    }
  }
  console.log(`[Marketplace Seed] ✅ ${created} تصنيف جديد`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => prisma.$disconnect())
