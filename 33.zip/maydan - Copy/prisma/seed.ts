import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/auth'

const prisma = new PrismaClient()
const SEED_PASSWORD = 'SeedPass1!'

const allUserIds = [
'user_owner',
  'user_admin',
  'user_admin2',
  'user_moderator',
  'user_mod2',
  'user_mod3',
  'user_ahmad',
  'user_sara',
  'user_omar',
  'user_fatima',
  'user_ali',
  'user_zainab',
  'user_expert7',
  'user_expert8',
  'user_expert9',
  'user_expert10',
  'user_mustafa',
  'user_huda',
  'user_member3',
  'user_member4',
  'user_member5',
  'user_member6',
  'user_member7',
  'user_member8',
  'user_member9',
  'user_member10',
  'user_member11',
  'user_member12',
  'user_member13',
  'user_member14'
]

const commentContents = [
  "تحليل ممتاز ومعمق. أتفق تماماً مع النقاط المطروحة في هذا المقال.",
  "مقال شامل يغطي الجوانب المختلفة للموضوع. شكراً على هذا الجهد المتميز.",
  "أود الإضافة بأن الوضع يحتاج إلى معالجة جذرية وليس ترقيعية كما هو حاصل حالياً.",
  "هل يمكن التوسع في الحديث عن الحلول المقترحة ومعالجة التحديات المذكورة؟",
  "متابعة ممتازة. أتمنى أن تتوسعوا في تغطية هذا الموضوع المهم للقارئ العراقي.",
  "الفجوة بين النظرية والتطبيق لا تزال كبيرة في الواقع العراقي وتحتاج إلى معالجة عاجلة.",
  "تجربتي الشخصية تؤكد ما ذكرتم. الواقع على الأرض أسوأ مما يُصور في التقارير الرسمية.",
  "شكراً على هذا التحليل الموضوعي والبعيد عن التحيز الإعلامي والسياسي.",
  "أختلف معكم في بعض النقاط لكن المقال جيد عموماً ويستحق القراءة والتأمل.",
  "الفساد الإداري والمالي هو العائق الأكبر أمام أي إصلاح اقتصادي حقيقي في العراق.",
  "نحتاج إلى المزيد من الدراسات الميدانية والأبحاث التطبيقية وليس فقط التنظير الأكاديمي.",
  "المقارنة مع تجارب دول المنطقة مفيدة جداً لفهم وضعنا الاقتصادي وتحديد أولويات الإصلاح.",
  "أتمنى أن تصل هذه الأصوات الموضوعية إلى صناع القرار والمسؤولين عن السياسات الاقتصادية.",
  "القطاع الخاص يحتاج إلى حماية ودعم حقيقي من الدولة وليس مجرد شعارات وتصريحات إعلامية.",
  "المشكلة ليست في غياب الخطط والاستراتيجيات بل في غياب الإرادة الحقيقية للتنفيذ.",
  "الشفافية والمساءلة هما مفتاح أي إصلاح ناجح ومستدام في جميع القطاعات الاقتصادية.",
  "هذا هو التحليل الأفضل والأكثر شمولية الذي قرأته حول هذا الموضوع المهم.",
  "أقترح إجراء دراسة ميدانية شاملة للتأكد من دقة هذه الأرقام والمعطيات.",
  "التعليم الاقتصادي والمالي هو الأساس لأي تغيير حقيقي في ثقافة المجتمع.",
  "البيروقراطية المعقدة والإجراءات الروتينية تقتل أي مبادرة استثمارية في مهدها.",
]

async function main() {
  console.log('🌱 Seeding database...')

  // ???????????????????????????????????????????????????????????????????
  // حماية البيانات الحقيقية من المحو العرضي
  // ???????????????????????????????????????????????????????????????????
  // عند إعادة تشغيل النظام (npm run db:seed) كان السكربت يفرّغ كل الجداول
  // عبر TRUNCATE CASCADE فيُمحى أي منشور/عضو حقيقي. الآن نتحقق أولاً:
  //   - إن وُجد مستخدمون فعلاً في القاعدة ولم يُضبط SEED_FORCE=true ?
  //     نتخطّى الزرع بالكامل ونحافظ على البيانات الحقيقية.
  //   - لفرض إعادة الزرع الاستهلالية: SEED_FORCE=true npm run db:seed
  // ???????????????????????????????????????????????????????????????????
  if (process.env.SEED_FORCE !== 'true') {
    const existingUsers = await prisma.user.count()
    if (existingUsers > 0) {
      console.log(`?? تم العثور على ${existingUsers} مستخدم موجود — تخطّي الزرع للحفاظ على البيانات الحقيقية.`)
      console.log('   (لفرض إعادة الزرع الاستهلالية ومحو كل البيانات شغّل: SEED_FORCE=true npm run db:seed)')
      return
    }
  }


  // ─────────────────────────────────────────────────────────────
  // Reset database — robust, idempotent, FK-order-independent
  // ─────────────────────────────────────────────────────────────
  // The previous implementation called `prisma.user.deleteMany()` after a handful
  // of sibling `deleteMany()` calls, but the schema has ~250 models — many of
  // them (AuditLog, Notification, Message, Connection, Follow, Post,
  // PromotionCampaign, …) reference User WITHOUT `onDelete: Cascade`. Trying to
  // delete User while those tables still hold rows triggers:
  //   `Foreign key constraint violated on the constraint: AuditLog_adminId_fkey`
  // and aborts the seed halfway — leaving the DB in a broken state where the
  // User table retains stale rows (with stale `articlesCount`) while the
  // Article table is already empty. That is exactly the bug pattern users see
  // when the profile sidebar shows "1 مقالات" but the Articles tab is empty.
  //
  // Fix: use PostgreSQL `TRUNCATE … CASCADE` to wipe ALL public tables in a
  // single statement. This (a) bypasses FK ordering entirely, (b) is much
  // faster than per-table deleteMany on large datasets, (c) is idempotent.
  // For SQLite (dev fallback) we keep the explicit ordered deleteMany list,
  // extended with the previously-missing AuditLog/Notification/Message/etc.
  // ─────────────────────────────────────────────────────────────

  const isPostgres = (process.env.DATABASE_URL || '').startsWith('postgres')

  if (isPostgres) {
    console.log('🧹 PostgreSQL detected — TRUNCATE all tables (CASCADE)...')
    // List all tables in public schema (excluding Prisma's own migrations table)
    const tables = await prisma.$queryRawUnsafe<{ tablename: string }[]>(`
      SELECT tablename
      FROM pg_tables
      WHERE schemaname = 'public'
        AND tablename <> '_prisma_migrations'
      ORDER BY tablename;
    `)
    // Disable FK triggers for this session (belt + suspenders — TRUNCATE CASCADE
    // already handles ordering, but this protects against any leftover triggers)
    await prisma.$executeRawUnsafe('SET session_replication_role = replica;')
    try {
      // TRUNCATE all tables in one shot — CASCADE makes order irrelevant
      const tableNames = tables.map((t) => `"${t.tablename}"`).join(', ')
      if (tableNames) {
        await prisma.$executeRawUnsafe(`TRUNCATE TABLE ${tableNames} CASCADE;`)
      }
      console.log(`  ✓ Truncated ${tables.length} tables`)
    } finally {
      // Restore FK enforcement
      await prisma.$executeRawUnsafe('SET session_replication_role = origin;')
    }
  } else {
    console.log('🧹 SQLite detected — ordered deleteMany (FK-safe order)...')
    // Delete in dependency order: leaves (no FKs out) first, roots (User) last.
    // Includes the previously-missing AuditLog, Notification, Message, Connection,
    // Post, PromotionCampaign, etc. that caused FK violations.
    await prisma.auditLog.deleteMany()
    await prisma.notification.deleteMany()
    await prisma.message.deleteMany()
    await prisma.conversationParticipant.deleteMany()
    await prisma.conversation.deleteMany()
    await prisma.connection.deleteMany()
    await prisma.follow.deleteMany()
    await prisma.userActivityLog.deleteMany()
    await prisma.userActivity.deleteMany()
    await prisma.passwordResetCode.deleteMany()
    await prisma.userSession.deleteMany()
    await prisma.systemError.deleteMany()
    await prisma.errorReport.deleteMany()
    await prisma.securityEvent.deleteMany()
    await prisma.apiKeyRecord.deleteMany()
    await prisma.accountDeletionRequest.deleteMany()
    await prisma.passwordChangeLog.deleteMany()
    await prisma.profileView.deleteMany()
    await prisma.profileViewLog.deleteMany()
    await prisma.readingListItem.deleteMany()
    await prisma.readingList.deleteMany()
    await prisma.post.deleteMany()
    await prisma.repost.deleteMany()
    await prisma.promotionCampaign.deleteMany()
    await prisma.ad.deleteMany()
    await prisma.advertiserAccount.deleteMany()
    await prisma.payment.deleteMany()
    await prisma.invoice.deleteMany()
    await prisma.walletTransaction.deleteMany()
    await prisma.wallet.deleteMany()
    await prisma.subscription.deleteMany()
    await prisma.commission.deleteMany()
    await prisma.referral.deleteMany()
    await prisma.pushSubscription.deleteMany()
    // QA / community
    await prisma.quizAnswer.deleteMany()
    await prisma.quizOptionRecord.deleteMany()
    await prisma.quizAttempt.deleteMany()
    await prisma.quizQuestion.deleteMany()
    await prisma.quiz.deleteMany()
    await prisma.userLessonProgress.deleteMany()
    await prisma.lesson.deleteMany()
    await prisma.learningPath.deleteMany()
    // Content
    await prisma.articleTag.deleteMany()
    await prisma.hashtag.deleteMany()
    await prisma.economicTerm.deleteMany()
    await prisma.like.deleteMany()
    await prisma.discussionReply.deleteMany()
    await prisma.discussionMedia.deleteMany()
    await prisma.discussion.deleteMany()
    await prisma.comment.deleteMany()
    await prisma.articleMedia.deleteMany()
    await prisma.article.deleteMany()
    await prisma.job.deleteMany()
    // Config (last, since they have no FK to User)
    await prisma.siteSettings.deleteMany()
    await prisma.pricingConfig.deleteMany()
    await prisma.paymentDestination.deleteMany()
    // Finally — safe to delete users (all dependents already cleared)
    await prisma.user.deleteMany()
    console.log('  ✓ Cleared all tables in FK-safe order')
  }

  // ===== USERS (30) =====
  const usersData = [
    {
      id: 'user_owner',
      email: 'owner@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'مالك المنصة',
      bio: 'مالك ومؤسس منصة ميدان الاقتصاد - المرجع الاقتصادي العراقي.',
      avatar: '',
      jobTitle: 'مؤسس المنصة',
      organization: 'ميدان الاقتصاد',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'OWNER',
      emailVerified: true,
      followersCount: 0,
      followingCount: 0,
      articlesCount: 0,
    },
    {
      id: 'user_admin',
      email: 'admin@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'عبدالرحمن المنصوري',
      bio: 'مسؤول الإدارة في منصة ميدان الاقتصاد. مسؤول عن مراقبة المحتوى وإدارة المستخدمين.',
      avatar: '',
      jobTitle: 'مسؤول النظام',
      organization: 'ميدان الاقتصاد',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'ADMIN',
      emailVerified: true,
      followersCount: 0,
      followingCount: 0,
      articlesCount: 0,
    },
    {
      id: 'user_admin2',
      email: 'admin2@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'نور الدين العبيدي',
      bio: 'مسؤول تقني في منصة ميدان الاقتصاد. متخصص في تطوير المنصات الرقمية وإدارة الأنظمة.',
      avatar: '',
      jobTitle: 'مسؤول تقني',
      organization: 'ميدان الاقتصاد',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'ADMIN',
      emailVerified: true,
      followersCount: 0,
      followingCount: 0,
      articlesCount: 0,
    },
    {
      id: 'user_moderator',
      email: 'moderator@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'حسين الكرملي',
      bio: 'مشرف في منصة ميدان الاقتصاد. مسؤول عن مراجعة المقالات والنقاشات وضمان جودة المحتوى.',
      avatar: '',
      jobTitle: 'مشرف المحتوى',
      organization: 'ميدان الاقتصاد',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'MODERATOR',
      emailVerified: true,
      followersCount: 0,
      followingCount: 0,
      articlesCount: 0,
    },
    {
      id: 'user_mod2',
      email: 'moderator2@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'ليلى حسن البغدادي',
      bio: 'مشرفة محتوى في منصة ميدان الاقتصاد. صحفية سابقة مع خبرة 8 سنوات في الإعلام الاقتصادي.',
      avatar: '',
      jobTitle: 'مشرفة محتوى',
      organization: 'ميدان الاقتصاد',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'MODERATOR',
      emailVerified: true,
      followersCount: 0,
      followingCount: 0,
      articlesCount: 0,
    },
    {
      id: 'user_mod3',
      email: 'moderator3@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'ياسر طلال الربيعي',
      bio: 'مشرف مجتمع في منصة ميدان الاقتصاد. مسؤول عن إدارة النقاشات والتعليقات.',
      avatar: '',
      jobTitle: 'مشرف مجتمع',
      organization: 'ميدان الاقتصاد',
      location: 'أربيل، العراق',
      isVerified: true,
      role: 'MODERATOR',
      emailVerified: true,
      followersCount: 0,
      followingCount: 0,
      articlesCount: 0,
    },
    {
      id: 'user_ahmad',
      email: 'ahmad@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'أحمد محمد الشمري',
      bio: 'أستاذ الاقتصاد في الجامعة المستنصرية، متخصص في اقتصاديات النفط والطاقة. عضو الجمعية الاقتصادية العراقية وصاحب أكثر من 50 بحثاً منشورا.',
      avatar: '/uploads/avatars/ahmad.jpg',
      jobTitle: 'أستاذ اقتصاد',
      organization: 'الجامعة المستنصرية',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 342,
      followingCount: 89,
      articlesCount: 8,
    },
    {
      id: 'user_sara',
      email: 'sara@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'سارة عبدالله الحسني',
      bio: 'محللة مالية في بنك الرافدين، حاصلة على الماجستير في المالية الدولية من جامعة لندن.',
      avatar: '/uploads/avatars/sara.jpg',
      jobTitle: 'محللة مالية أولى',
      organization: 'بنك الرافدين',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 256,
      followingCount: 67,
      articlesCount: 5,
    },
    {
      id: 'user_omar',
      email: 'omar@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'عمر حسين الكنعاني',
      bio: 'مستثمر ورائد أعمال في مجال التقنية المالية. مؤسس شركة فينتك العراق.',
      avatar: '/uploads/avatars/omar.jpg',
      jobTitle: 'رائد أعمال',
      organization: 'فينتك العراق',
      location: 'أربيل، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 189,
      followingCount: 45,
      articlesCount: 3,
    },
    {
      id: 'user_fatima',
      email: 'fatima@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'فاطمة يوسف العبيدي',
      bio: 'خبيرة في التجارة الدولية والاقتصاد السياسي. عملت في الأمم المتحدة لبرنامج التنمية الصناعية.',
      avatar: '/uploads/avatars/fatima.jpg',
      jobTitle: 'خبيرة اقتصاد سياسي',
      organization: 'مستقلة',
      location: 'البصرة، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 412,
      followingCount: 34,
      articlesCount: 7,
    },
    {
      id: 'user_ali',
      email: 'ali@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'علي جعفر الربيعي',
      bio: 'خبير في سوق العراق للأوراق المالية. محلل فني وأساسي مع خبرة 15 عاماً.',
      avatar: '/uploads/avatars/ali.jpg',
      jobTitle: 'محلل أسواق مالية',
      organization: 'مجموعة الرشيد للاستثمار',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 523,
      followingCount: 28,
      articlesCount: 10,
    },
    {
      id: 'user_zainab',
      email: 'zainab@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'زينب كريم الموسوي',
      bio: 'باحثة اقتصادية في مركز الدراسات الاقتصادية العراقية. حاصلة على الدكتوراه في التنمية الاقتصادية.',
      avatar: '/uploads/avatars/zainab.jpg',
      jobTitle: 'باحثة اقتصادية',
      organization: 'مركز الدراسات الاقتصادية',
      location: 'النجف، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 178,
      followingCount: 56,
      articlesCount: 4,
    },
    {
      id: 'user_expert7',
      email: 'khalid@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'خالد عبدال Amir العامري',
      bio: 'خبير في السياسات النقدية والمصرفية. عمل مستشاراً للبنك المركزي العراقي لمدة 12 عاماً.',
      avatar: '',
      jobTitle: 'خبير سياسات نقدية',
      organization: 'مستشار مستقل',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 267,
      followingCount: 42,
      articlesCount: 6,
    },
    {
      id: 'user_expert8',
      email: 'nadia@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'نادية محمد الجبوري',
      bio: 'أستاذة الاقتصاد الدولي في جامعة الموصل. متخصصة في العلاقات الاقتصادية الإقليمية.',
      avatar: '',
      jobTitle: 'أستاذة اقتصاد دولي',
      organization: 'جامعة الموصل',
      location: 'الموصل، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 198,
      followingCount: 51,
      articlesCount: 5,
    },
    {
      id: 'user_expert9',
      email: 'bassem@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'باسم حسين الكناني',
      bio: 'مدير تنفيذي سابق في شركة نفط الجنوب. خبير في إدارة القطاع النفطي والطاقة.',
      avatar: '',
      jobTitle: 'خبير قطاع نفطي',
      organization: 'مستشار نفطي',
      location: 'البصرة، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 314,
      followingCount: 39,
      articlesCount: 8,
    },
    {
      id: 'user_expert10',
      email: 'ruaa@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'رؤى صالح التميمي',
      bio: 'خبيرة في التنمية المستدامة والاقتصاد الأخضر. حاصلة على الماجستير من جامعة كامبريدج.',
      avatar: '',
      jobTitle: 'خبيرة تنمية مستدامة',
      organization: 'منظمة التنمية الخضراء',
      location: 'بغداد، العراق',
      isVerified: true,
      role: 'EXPERT',
      emailVerified: false,
      followersCount: 156,
      followingCount: 63,
      articlesCount: 4,
    },
    {
      id: 'user_mustafa',
      email: 'mustafa@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'مصطفى صالح التميمي',
      bio: 'صحفي اقتصادي ومحرر في قسم الاقتصاد بجريدة الصباح.',
      avatar: '/uploads/avatars/mustafa.jpg',
      jobTitle: 'صحفي اقتصادي',
      organization: 'جريدة الصباح',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 89,
      followingCount: 134,
      articlesCount: 2,
    },
    {
      id: 'user_huda',
      email: 'huda@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'هدى عادل النعيمي',
      bio: 'مهتمة بالاقتصاد العراقي وطالبة ماجستير في المحاسبة.',
      avatar: '/uploads/avatars/huda.jpg',
      jobTitle: 'طالبة ماجستير',
      organization: 'جامعة بغداد',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 45,
      followingCount: 78,
      articlesCount: 1,
    },
    {
      id: 'user_member3',
      email: 'jassim@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'جاسم محمد الربيعي',
      bio: 'محاسب في وزارة المالية العراقية. مهتم بالسياسات الضريبية والإصلاح المالي.',
      avatar: '',
      jobTitle: 'محاسب',
      organization: 'وزارة المالية',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 34,
      followingCount: 89,
      articlesCount: 1,
    },
    {
      id: 'user_member4',
      email: 'amal@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'أمل كريم الساعدي',
      bio: 'مديرة مشروع في منظمة غير حكومية تعنى بتمكين المرأة اقتصادياً في العراق.',
      avatar: '',
      jobTitle: 'مديرة مشروع',
      organization: 'منظمة التنمية المجتمعية',
      location: 'النجف، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 67,
      followingCount: 45,
      articlesCount: 2,
    },
    {
      id: 'user_member5',
      email: 'haider@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'حيدر عزيز المالكي',
      bio: 'صاحب متجر إلكتروني متخصص في التجارة الرقمية والتجارة الإلكترونية.',
      avatar: '',
      jobTitle: 'رائد أعمال',
      organization: 'متجر عراق أونلاين',
      location: 'كربلاء، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 23,
      followingCount: 56,
      articlesCount: 0,
    },
    {
      id: 'user_member6',
      email: 'zahraa@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'زهراء أحمد الخفاجي',
      bio: 'طالبة اقتصاد في الجامعة المستنصرية. مهتمة بالاقتصاد السلوكي وسياسات التنمية.',
      avatar: '',
      jobTitle: 'طالبة اقتصاد',
      organization: 'الجامعة المستنصرية',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 28,
      followingCount: 67,
      articlesCount: 1,
    },
    {
      id: 'user_member7',
      email: 'omar2@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'عمر فاضل الشمري',
      bio: 'مهندس بترول يعمل في حقول نفط كركوك. مهتم بقطاع الطاقة والنفط.',
      avatar: '',
      jobTitle: 'مهندس بترول',
      organization: 'شركة نفط الشمال',
      location: 'كركوك، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 56,
      followingCount: 34,
      articlesCount: 0,
    },
    {
      id: 'user_member8',
      email: 'sajda@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'سجدة حسين العبيدي',
      bio: 'مديرة موارد بشرية في شركة استثمارية. مهتمة بسوق العمل والتعليم المهني.',
      avatar: '',
      jobTitle: 'مديرة موارد بشرية',
      organization: 'شركة الاستثمار الوطنية',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 41,
      followingCount: 72,
      articlesCount: 1,
    },
    {
      id: 'user_member9',
      email: 'ali2@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'علي كاظم الزبيدي',
      bio: 'متداول في بورصة بغداد. مهتم بالتحليل الفني والأساسي للأسهم.',
      avatar: '',
      jobTitle: 'متداول أسهم',
      organization: 'مستقل',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 78,
      followingCount: 45,
      articlesCount: 2,
    },
    {
      id: 'user_member10',
      email: 'mariam@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'مريم عبدالله النعيمي',
      bio: 'باحثة في شؤون الاقتصاد الزراعي والأمن الغذائي في العراق.',
      avatar: '',
      jobTitle: 'باحثة اقتصاد زراعي',
      organization: 'وزارة الزراعة',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 19,
      followingCount: 87,
      articlesCount: 0,
    },
    {
      id: 'user_member11',
      email: 'hassan@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'حسن طه الجبوري',
      bio: 'مصرفي يعمل في القطاع المصرفي العراقي منذ 10 سنوات.',
      avatar: '',
      jobTitle: 'مصرفي',
      organization: 'بنك العراق التجاري',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 35,
      followingCount: 63,
      articlesCount: 1,
    },
    {
      id: 'user_member12',
      email: 'noor@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'نور سعيد الكناني',
      bio: 'مصمم واجهات مستخدم يعمل في مجال التقنية المالية.',
      avatar: '',
      jobTitle: 'مصمم UI/UX',
      organization: 'شركة ديجيتال العراق',
      location: 'أربيل، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 52,
      followingCount: 41,
      articlesCount: 0,
    },
    {
      id: 'user_member13',
      email: 'abbas@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'عباس محمد اللامي',
      bio: 'مدرس اقتصاد في ثانوية تجارية. مهتم بالتعليم الاقتصادي ونشر الوعي المالي.',
      avatar: '',
      jobTitle: 'مدرس اقتصاد',
      organization: 'ثانوية بغداد التجارية',
      location: 'بغداد، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 15,
      followingCount: 92,
      articlesCount: 1,
    },
    {
      id: 'user_member14',
      email: 'dunya@midaniq.com',
      password: hashPassword(SEED_PASSWORD),
      name: 'دنيا خالد الموسوي',
      bio: 'صحفية مستقلة متخصصة في الشؤون الاقتصادية والتنمية.',
      avatar: '',
      jobTitle: 'صحفية مستقلة',
      organization: 'مستقلة',
      location: 'البصرة، العراق',
      isVerified: false,
      role: 'USER',
      emailVerified: false,
      followersCount: 63,
      followingCount: 55,
      articlesCount: 2,
    },
  ]
  for (const u of usersData) { await prisma.user.create({ data: u }) }
  console.log('  ✓ 30 users created')

  // ===== ARTICLES (120) =====
  const articlesData = [
    {
      id: 'art_1',
      title: `ارتفاع أسعار النفط إلى 85 دولاراً مع تزايد الطلب العالمي`,
      summary: `تقرير إخباري عن ارتفاع أسعار النفط إلى 85 دولاراً مع تزايد الطلب العالمي`,
      content: `ارتفاع أسعار النفط إلى 85 دولاراً مع تزايد الطلب العالمي

تقرير إخباري عن ارتفاع أسعار النفط إلى 85 دولاراً مع تزايد الطلب العالمي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: true,
      viewCount: 100,
      likeCount: 10,
      commentCount: 1,
      publishedAt: new Date('2025-01-01T10:00:00.000Z'),
    },
    {
      id: 'art_2',
      title: `البنك المركزي يعلن عن خطة جديدة لاستقرار سعر الصرف`,
      summary: `تقرير إخباري عن البنك المركزي يعلن عن خطة جديدة لاستقرار سعر الصرف`,
      content: `البنك المركزي يعلن عن خطة جديدة لاستقرار سعر الصرف

تقرير إخباري عن البنك المركزي يعلن عن خطة جديدة لاستقرار سعر الصرف. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: true,
      viewCount: 137,
      likeCount: 23,
      commentCount: 8,
      publishedAt: new Date('2025-02-02T10:00:00.000Z'),
    },
    {
      id: 'art_3',
      title: `العراق يوقع اتفاقية تجارية جديدة مع تركيا`,
      summary: `تقرير إخباري عن العراق يوقع اتفاقية تجارية جديدة مع تركيا`,
      content: `العراق يوقع اتفاقية تجارية جديدة مع تركيا

تقرير إخباري عن العراق يوقع اتفاقية تجارية جديدة مع تركيا. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: true,
      viewCount: 174,
      likeCount: 36,
      commentCount: 15,
      publishedAt: new Date('2025-03-03T10:00:00.000Z'),
    },
    {
      id: 'art_4',
      title: `إطلاق مشروع وطني للتحول الرقمي في القطاع المصرفي`,
      summary: `تقرير إخباري عن إطلاق مشروع وطني للتحول الرقمي في القطاع المصرفي`,
      content: `إطلاق مشروع وطني للتحول الرقمي في القطاع المصرفي

تقرير إخباري عن إطلاق مشروع وطني للتحول الرقمي في القطاع المصرفي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: true,
      viewCount: 211,
      likeCount: 49,
      commentCount: 7,
      publishedAt: new Date('2025-04-04T10:00:00.000Z'),
    },
    {
      id: 'art_5',
      title: `ارتفاع احتياطيات النقد الأجنبي إلى 65 مليار دولار`,
      summary: `تقرير إخباري عن ارتفاع احتياطيات النقد الأجنبي إلى 65 مليار دولار`,
      content: `ارتفاع احتياطيات النقد الأجنبي إلى 65 مليار دولار

تقرير إخباري عن ارتفاع احتياطيات النقد الأجنبي إلى 65 مليار دولار. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: true,
      viewCount: 248,
      likeCount: 62,
      commentCount: 14,
      publishedAt: new Date('2025-05-05T10:00:00.000Z'),
    },
    {
      id: 'art_6',
      title: `افتتاح بورصة السلع العراقية رسمياً في بغداد`,
      summary: `تقرير إخباري عن افتتاح بورصة السلع العراقية رسمياً في بغداد`,
      content: `افتتاح بورصة السلع العراقية رسمياً في بغداد

تقرير إخباري عن افتتاح بورصة السلع العراقية رسمياً في بغداد. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 285,
      likeCount: 75,
      commentCount: 6,
      publishedAt: new Date('2025-06-06T10:00:00.000Z'),
    },
    {
      id: 'art_7',
      title: `البنك الدولي يمنح العراق قرضاً بقيمة مليار دولار للإصلاح الاقتصادي`,
      summary: `تقرير إخباري عن البنك الدولي يمنح العراق قرضاً بقيمة مليار دولار للإصلاح الاقتصادي`,
      content: `البنك الدولي يمنح العراق قرضاً بقيمة مليار دولار للإصلاح الاقتصادي

تقرير إخباري عن البنك الدولي يمنح العراق قرضاً بقيمة مليار دولار للإصلاح الاقتصادي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 322,
      likeCount: 88,
      commentCount: 13,
      publishedAt: new Date('2025-07-07T10:00:00.000Z'),
    },
    {
      id: 'art_8',
      title: `انخفاض معدل التضخم إلى 4.2% خلال الربع الأول`,
      summary: `تقرير إخباري عن انخفاض معدل التضخم إلى 4.2% خلال الربع الأول`,
      content: `انخفاض معدل التضخم إلى 4.2% خلال الربع الأول

تقرير إخباري عن انخفاض معدل التضخم إلى 4.2% خلال الربع الأول. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 359,
      likeCount: 101,
      commentCount: 5,
      publishedAt: new Date('2025-08-08T10:00:00.000Z'),
    },
    {
      id: 'art_9',
      title: `وزارة النفط تعلن عن اكتشاف حقل نفطي جديد في البصرة`,
      summary: `تقرير إخباري عن وزارة النفط تعلن عن اكتشاف حقل نفطي جديد في البصرة`,
      content: `وزارة النفط تعلن عن اكتشاف حقل نفطي جديد في البصرة

تقرير إخباري عن وزارة النفط تعلن عن اكتشاف حقل نفطي جديد في البصرة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 396,
      likeCount: 114,
      commentCount: 12,
      publishedAt: new Date('2025-09-09T10:00:00.000Z'),
    },
    {
      id: 'art_10',
      title: `إطلاق استراتيجية وطنية للطاقة المتجددة حتى 2030`,
      summary: `تقرير إخباري عن إطلاق استراتيجية وطنية للطاقة المتجددة حتى 2030`,
      content: `إطلاق استراتيجية وطنية للطاقة المتجددة حتى 2030

تقرير إخباري عن إطلاق استراتيجية وطنية للطاقة المتجددة حتى 2030. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 433,
      likeCount: 127,
      commentCount: 4,
      publishedAt: new Date('2025-10-10T10:00:00.000Z'),
    },
    {
      id: 'art_11',
      title: `العراق يشارك في القمة الاقتصادية لدول الشرق الأوسط`,
      summary: `تقرير إخباري عن العراق يشارك في القمة الاقتصادية لدول الشرق الأوسط`,
      content: `العراق يشارك في القمة الاقتصادية لدول الشرق الأوسط

تقرير إخباري عن العراق يشارك في القمة الاقتصادية لدول الشرق الأوسط. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: false,
      viewCount: 470,
      likeCount: 140,
      commentCount: 11,
      publishedAt: new Date('2025-11-11T10:00:00.000Z'),
    },
    {
      id: 'art_12',
      title: `ارتفاع صادرات العراق غير النفطية بنسبة 18%`,
      summary: `تقرير إخباري عن ارتفاع صادرات العراق غير النفطية بنسبة 18%`,
      content: `ارتفاع صادرات العراق غير النفطية بنسبة 18%

تقرير إخباري عن ارتفاع صادرات العراق غير النفطية بنسبة 18%. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 507,
      likeCount: 153,
      commentCount: 3,
      publishedAt: new Date('2025-12-12T10:00:00.000Z'),
    },
    {
      id: 'art_13',
      title: `مشروع قانون جديد للإصلاح الضريبي في البرلمان العراقي`,
      summary: `تقرير إخباري عن مشروع قانون جديد للإصلاح الضريبي في البرلمان العراقي`,
      content: `مشروع قانون جديد للإصلاح الضريبي في البرلمان العراقي

تقرير إخباري عن مشروع قانون جديد للإصلاح الضريبي في البرلمان العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 544,
      likeCount: 166,
      commentCount: 10,
      publishedAt: new Date('2025-01-13T10:00:00.000Z'),
    },
    {
      id: 'art_14',
      title: `توقيع اتفاقية استثمارية مع شركة ألمانية لقطاع الكهرباء`,
      summary: `تقرير إخباري عن توقيع اتفاقية استثمارية مع شركة ألمانية لقطاع الكهرباء`,
      content: `توقيع اتفاقية استثمارية مع شركة ألمانية لقطاع الكهرباء

تقرير إخباري عن توقيع اتفاقية استثمارية مع شركة ألمانية لقطاع الكهرباء. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 581,
      likeCount: 179,
      commentCount: 2,
      publishedAt: new Date('2025-02-14T10:00:00.000Z'),
    },
    {
      id: 'art_15',
      title: `ارتفاع تحويلات العراقيين في الخارج إلى 7 مليارات دولار`,
      summary: `تقرير إخباري عن ارتفاع تحويلات العراقيين في الخارج إلى 7 مليارات دولار`,
      content: `ارتفاع تحويلات العراقيين في الخارج إلى 7 مليارات دولار

تقرير إخباري عن ارتفاع تحويلات العراقيين في الخارج إلى 7 مليارات دولار. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 618,
      likeCount: 192,
      commentCount: 9,
      publishedAt: new Date('2025-03-15T10:00:00.000Z'),
    },
    {
      id: 'art_16',
      title: `إطلاق صندوق استثماري وطني بدعم حكومي`,
      summary: `تقرير إخباري عن إطلاق صندوق استثماري وطني بدعم حكومي`,
      content: `إطلاق صندوق استثماري وطني بدعم حكومي

تقرير إخباري عن إطلاق صندوق استثماري وطني بدعم حكومي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 655,
      likeCount: 205,
      commentCount: 1,
      publishedAt: new Date('2025-04-16T10:00:00.000Z'),
    },
    {
      id: 'art_17',
      title: `العراق يحتل المرتبة الأولى عربياً في احتياطي النفط المؤكد`,
      summary: `تقرير إخباري عن العراق يحتل المرتبة الأولى عربياً في احتياطي النفط المؤكد`,
      content: `العراق يحتل المرتبة الأولى عربياً في احتياطي النفط المؤكد

تقرير إخباري عن العراق يحتل المرتبة الأولى عربياً في احتياطي النفط المؤكد. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 692,
      likeCount: 218,
      commentCount: 8,
      publishedAt: new Date('2025-05-17T10:00:00.000Z'),
    },
    {
      id: 'art_18',
      title: `مبادرة حكومية لدعم المشاريع الصغيرة والمتوسطة بتمويل 500 مليون دولار`,
      summary: `تقرير إخباري عن مبادرة حكومية لدعم المشاريع الصغيرة والمتوسطة بتمويل 500 مليون دولار`,
      content: `مبادرة حكومية لدعم المشاريع الصغيرة والمتوسطة بتمويل 500 مليون دولار

تقرير إخباري عن مبادرة حكومية لدعم المشاريع الصغيرة والمتوسطة بتمويل 500 مليون دولار. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 729,
      likeCount: 231,
      commentCount: 15,
      publishedAt: new Date('2025-06-18T10:00:00.000Z'),
    },
    {
      id: 'art_19',
      title: `افتتاح مركز التمويل الإسلامي في بغداد`,
      summary: `تقرير إخباري عن افتتاح مركز التمويل الإسلامي في بغداد`,
      content: `افتتاح مركز التمويل الإسلامي في بغداد

تقرير إخباري عن افتتاح مركز التمويل الإسلامي في بغداد. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 766,
      likeCount: 244,
      commentCount: 7,
      publishedAt: new Date('2025-07-19T10:00:00.000Z'),
    },
    {
      id: 'art_20',
      title: `تقرير: الاقتصاد العراقي ينمو بنسبة 4.8% خلال 2025`,
      summary: `تقرير إخباري عن تقرير - الاقتصاد العراقي ينمو بنسبة 4.8% خلال 2025`,
      content: `تقرير: الاقتصاد العراقي ينمو بنسبة 4.8% خلال 2025

تقرير إخباري عن تقرير - الاقتصاد العراقي ينمو بنسبة 4.8% خلال 2025. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 803,
      likeCount: 257,
      commentCount: 14,
      publishedAt: new Date('2025-08-20T10:00:00.000Z'),
    },
    {
      id: 'art_21',
      title: `البنك المركزي يطلق منصة إلكترونية للتحويلات الخارجية`,
      summary: `تقرير إخباري عن البنك المركزي يطلق منصة إلكترونية للتحويلات الخارجية`,
      content: `البنك المركزي يطلق منصة إلكترونية للتحويلات الخارجية

تقرير إخباري عن البنك المركزي يطلق منصة إلكترونية للتحويلات الخارجية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: true,
      viewCount: 840,
      likeCount: 20,
      commentCount: 6,
      publishedAt: new Date('2025-09-21T10:00:00.000Z'),
    },
    {
      id: 'art_22',
      title: `وزارة التخطيط تعلن عن خطة خمسية جديدة للتنمية`,
      summary: `تقرير إخباري عن وزارة التخطيط تعلن عن خطة خمسية جديدة للتنمية`,
      content: `وزارة التخطيط تعلن عن خطة خمسية جديدة للتنمية

تقرير إخباري عن وزارة التخطيط تعلن عن خطة خمسية جديدة للتنمية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 877,
      likeCount: 33,
      commentCount: 13,
      publishedAt: new Date('2025-10-22T10:00:00.000Z'),
    },
    {
      id: 'art_23',
      title: `ارتفاع أسعار الذهب في السوق العراقي مع تزايد الطلب`,
      summary: `تقرير إخباري عن ارتفاع أسعار الذهب في السوق العراقي مع تزايد الطلب`,
      content: `ارتفاع أسعار الذهب في السوق العراقي مع تزايد الطلب

تقرير إخباري عن ارتفاع أسعار الذهب في السوق العراقي مع تزايد الطلب. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 914,
      likeCount: 46,
      commentCount: 5,
      publishedAt: new Date('2025-11-23T10:00:00.000Z'),
    },
    {
      id: 'art_24',
      title: `إطلاق برنامج تدريب مهني لشباب العراق بالتعاون مع اليونيسف`,
      summary: `تقرير إخباري عن إطلاق برنامج تدريب مهني لشباب العراق بالتعاون مع اليونيسف`,
      content: `إطلاق برنامج تدريب مهني لشباب العراق بالتعاون مع اليونيسف

تقرير إخباري عن إطلاق برنامج تدريب مهني لشباب العراق بالتعاون مع اليونيسف. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 951,
      likeCount: 59,
      commentCount: 12,
      publishedAt: new Date('2025-12-24T10:00:00.000Z'),
    },
    {
      id: 'art_25',
      title: `الاتحاد الأوروبي يعلن عن حزمة مساعدات اقتصادية للعراق`,
      summary: `تقرير إخباري عن الاتحاد الأوروبي يعلن عن حزمة مساعدات اقتصادية للعراق`,
      content: `الاتحاد الأوروبي يعلن عن حزمة مساعدات اقتصادية للعراق

تقرير إخباري عن الاتحاد الأوروبي يعلن عن حزمة مساعدات اقتصادية للعراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 988,
      likeCount: 72,
      commentCount: 4,
      publishedAt: new Date('2025-01-25T10:00:00.000Z'),
    },
    {
      id: 'art_26',
      title: `زيادة إنتاج العراق من الغاز الطبيعي بنسبة 25%`,
      summary: `تقرير إخباري عن زيادة إنتاج العراق من الغاز الطبيعي بنسبة 25%`,
      content: `زيادة إنتاج العراق من الغاز الطبيعي بنسبة 25%

تقرير إخباري عن زيادة إنتاج العراق من الغاز الطبيعي بنسبة 25%. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 1025,
      likeCount: 85,
      commentCount: 11,
      publishedAt: new Date('2025-02-26T10:00:00.000Z'),
    },
    {
      id: 'art_27',
      title: `مؤتمر دولي للاستثمار في العراق يعقد في لندن`,
      summary: `تقرير إخباري عن مؤتمر دولي للاستثمار في العراق يعقد في لندن`,
      content: `مؤتمر دولي للاستثمار في العراق يعقد في لندن

تقرير إخباري عن مؤتمر دولي للاستثمار في العراق يعقد في لندن. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 1062,
      likeCount: 98,
      commentCount: 3,
      publishedAt: new Date('2025-03-27T10:00:00.000Z'),
    },
    {
      id: 'art_28',
      title: `ارتفاع الإيرادات الضريبية بنسبة 30% مقارنة بالعام الماضي`,
      summary: `تقرير إخباري عن ارتفاع الإيرادات الضريبية بنسبة 30% مقارنة بالعام الماضي`,
      content: `ارتفاع الإيرادات الضريبية بنسبة 30% مقارنة بالعام الماضي

تقرير إخباري عن ارتفاع الإيرادات الضريبية بنسبة 30% مقارنة بالعام الماضي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 1099,
      likeCount: 111,
      commentCount: 10,
      publishedAt: new Date('2025-04-28T10:00:00.000Z'),
    },
    {
      id: 'art_29',
      title: `إطلاق تطبيق وطني للدفع الإلكتروني`,
      summary: `تقرير إخباري عن إطلاق تطبيق وطني للدفع الإلكتروني`,
      content: `إطلاق تطبيق وطني للدفع الإلكتروني

تقرير إخباري عن إطلاق تطبيق وطني للدفع الإلكتروني. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 1136,
      likeCount: 124,
      commentCount: 2,
      publishedAt: new Date('2025-05-01T10:00:00.000Z'),
    },
    {
      id: 'art_30',
      title: `العراق يتقدم 10 مراتب في مؤشر سهولة الأعمال العالمي`,
      summary: `تقرير إخباري عن العراق يتقدم 10 مراتب في مؤشر سهولة الأعمال العالمي`,
      content: `العراق يتقدم 10 مراتب في مؤشر سهولة الأعمال العالمي

تقرير إخباري عن العراق يتقدم 10 مراتب في مؤشر سهولة الأعمال العالمي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'NEWS',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 1173,
      likeCount: 137,
      commentCount: 9,
      publishedAt: new Date('2025-06-02T10:00:00.000Z'),
    },
    {
      id: 'art_31',
      title: `تأثير الحروب التجارية على الاقتصاد العراقي: تحليل معمق`,
      summary: `تحليل معمق لـ تأثير الحروب التجارية على الاقتصاد العراقي - تحليل معمق`,
      content: `تأثير الحروب التجارية على الاقتصاد العراقي: تحليل معمق

تحليل معمق لـ تأثير الحروب التجارية على الاقتصاد العراقي - تحليل معمق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: false,
      viewCount: 1210,
      likeCount: 150,
      commentCount: 1,
      publishedAt: new Date('2025-07-03T10:00:00.000Z'),
    },
    {
      id: 'art_32',
      title: `النموذج الاقتصادي العراقي: بين الريع والتنوع`,
      summary: `تحليل معمق لـ النموذج الاقتصادي العراقي - بين الريع والتنوع`,
      content: `النموذج الاقتصادي العراقي: بين الريع والتنوع

تحليل معمق لـ النموذج الاقتصادي العراقي - بين الريع والتنوع. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 1247,
      likeCount: 163,
      commentCount: 8,
      publishedAt: new Date('2025-08-04T10:00:00.000Z'),
    },
    {
      id: 'art_33',
      title: `تقييم أداء السياسة النقدية في العراق خلال العقد الأخير`,
      summary: `تحليل معمق لـ تقييم أداء السياسة النقدية في العراق خلال العقد الأخير`,
      content: `تقييم أداء السياسة النقدية في العراق خلال العقد الأخير

تحليل معمق لـ تقييم أداء السياسة النقدية في العراق خلال العقد الأخير. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 1284,
      likeCount: 176,
      commentCount: 15,
      publishedAt: new Date('2025-09-05T10:00:00.000Z'),
    },
    {
      id: 'art_34',
      title: `أزمة المياه وتأثيرها على الأمن الاقتصادي العراقي`,
      summary: `تحليل معمق لـ أزمة المياه وتأثيرها على الأمن الاقتصادي العراقي`,
      content: `أزمة المياه وتأثيرها على الأمن الاقتصادي العراقي

تحليل معمق لـ أزمة المياه وتأثيرها على الأمن الاقتصادي العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 1321,
      likeCount: 189,
      commentCount: 7,
      publishedAt: new Date('2025-10-06T10:00:00.000Z'),
    },
    {
      id: 'art_35',
      title: `العلاقة بين الإنفاق الحكومي والنمو الاقتصادي في العراق`,
      summary: `تحليل معمق لـ العلاقة بين الإنفاق الحكومي والنمو الاقتصادي في العراق`,
      content: `العلاقة بين الإنفاق الحكومي والنمو الاقتصادي في العراق

تحليل معمق لـ العلاقة بين الإنفاق الحكومي والنمو الاقتصادي في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 1358,
      likeCount: 202,
      commentCount: 14,
      publishedAt: new Date('2025-11-07T10:00:00.000Z'),
    },
    {
      id: 'art_36',
      title: `تحليل هيكل سوق العمل العراقي والتحديات المستقبلية`,
      summary: `تحليل معمق لـ تحليل هيكل سوق العمل العراقي والتحديات المستقبلية`,
      content: `تحليل هيكل سوق العمل العراقي والتحديات المستقبلية

تحليل معمق لـ تحليل هيكل سوق العمل العراقي والتحديات المستقبلية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 1395,
      likeCount: 215,
      commentCount: 6,
      publishedAt: new Date('2025-12-08T10:00:00.000Z'),
    },
    {
      id: 'art_37',
      title: `التكامل الاقتصادي العربي: فرص العراق وتحدياته`,
      summary: `تحليل معمق لـ التكامل الاقتصادي العربي - فرص العراق وتحدياته`,
      content: `التكامل الاقتصادي العربي: فرص العراق وتحدياته

تحليل معمق لـ التكامل الاقتصادي العربي - فرص العراق وتحدياته. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 1432,
      likeCount: 228,
      commentCount: 13,
      publishedAt: new Date('2025-01-09T10:00:00.000Z'),
    },
    {
      id: 'art_38',
      title: `اقتصاد الظل في العراق: الحجم والأسباب والحلول`,
      summary: `تحليل معمق لـ اقتصاد الظل في العراق - الحجم والأسباب والحلول`,
      content: `اقتصاد الظل في العراق: الحجم والأسباب والحلول

تحليل معمق لـ اقتصاد الظل في العراق - الحجم والأسباب والحلول. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 1469,
      likeCount: 241,
      commentCount: 5,
      publishedAt: new Date('2025-02-10T10:00:00.000Z'),
    },
    {
      id: 'art_39',
      title: `تأثير التحول الأخضر على مستقبل القطاع النفطي العراقي`,
      summary: `تحليل معمق لـ تأثير التحول الأخضر على مستقبل القطاع النفطي العراقي`,
      content: `تأثير التحول الأخضر على مستقبل القطاع النفطي العراقي

تحليل معمق لـ تأثير التحول الأخضر على مستقبل القطاع النفطي العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 1506,
      likeCount: 254,
      commentCount: 12,
      publishedAt: new Date('2025-03-11T10:00:00.000Z'),
    },
    {
      id: 'art_40',
      title: `الاقتصاد الرقمي في العراق: الواقع والآفاق`,
      summary: `تحليل معمق لـ الاقتصاد الرقمي في العراق - الواقع والآفاق`,
      content: `الاقتصاد الرقمي في العراق: الواقع والآفاق

تحليل معمق لـ الاقتصاد الرقمي في العراق - الواقع والآفاق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 1543,
      likeCount: 17,
      commentCount: 4,
      publishedAt: new Date('2025-04-12T10:00:00.000Z'),
    },
    {
      id: 'art_41',
      title: `تحليل الفجوة بين القطاعين العام والخاص في العراق`,
      summary: `تحليل معمق لـ تحليل الفجوة بين القطاعين العام والخاص في العراق`,
      content: `تحليل الفجوة بين القطاعين العام والخاص في العراق

تحليل معمق لـ تحليل الفجوة بين القطاعين العام والخاص في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: true,
      viewCount: 1580,
      likeCount: 30,
      commentCount: 11,
      publishedAt: new Date('2025-05-13T10:00:00.000Z'),
    },
    {
      id: 'art_42',
      title: `التضخم في العراق: الأسباب الجذرية وسبل المعالجة`,
      summary: `تحليل معمق لـ التضخم في العراق - الأسباب الجذرية وسبل المعالجة`,
      content: `التضخم في العراق: الأسباب الجذرية وسبل المعالجة

تحليل معمق لـ التضخم في العراق - الأسباب الجذرية وسبل المعالجة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 1617,
      likeCount: 43,
      commentCount: 3,
      publishedAt: new Date('2025-06-14T10:00:00.000Z'),
    },
    {
      id: 'art_43',
      title: `الاستثمار الأجنبي المباشر في العراق: المعوقات والحلول`,
      summary: `تحليل معمق لـ الاستثمار الأجنبي المباشر في العراق - المعوقات والحلول`,
      content: `الاستثمار الأجنبي المباشر في العراق: المعوقات والحلول

تحليل معمق لـ الاستثمار الأجنبي المباشر في العراق - المعوقات والحلول. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 1654,
      likeCount: 56,
      commentCount: 10,
      publishedAt: new Date('2025-07-15T10:00:00.000Z'),
    },
    {
      id: 'art_44',
      title: `تحليل منظومة الدفع والإقراض في العراق`,
      summary: `تحليل معمق لـ تحليل منظومة الدفع والإقراض في العراق`,
      content: `تحليل منظومة الدفع والإقراض في العراق

تحليل معمق لـ تحليل منظومة الدفع والإقراض في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 1691,
      likeCount: 69,
      commentCount: 2,
      publishedAt: new Date('2025-08-16T10:00:00.000Z'),
    },
    {
      id: 'art_45',
      title: `أثر العقوبات الدولية على اقتصادات المنطقة وانعكاسها على العراق`,
      summary: `تحليل معمق لـ أثر العقوبات الدولية على اقتصادات المنطقة وانعكاسها على العراق`,
      content: `أثر العقوبات الدولية على اقتصادات المنطقة وانعكاسها على العراق

تحليل معمق لـ أثر العقوبات الدولية على اقتصادات المنطقة وانعكاسها على العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 1728,
      likeCount: 82,
      commentCount: 9,
      publishedAt: new Date('2025-09-17T10:00:00.000Z'),
    },
    {
      id: 'art_46',
      title: `تحليل جدوى مشاريع الشراكة بين القطاعين العام والخاص`,
      summary: `تحليل معمق لـ تحليل جدوى مشاريع الشراكة بين القطاعين العام والخاص`,
      content: `تحليل جدوى مشاريع الشراكة بين القطاعين العام والخاص

تحليل معمق لـ تحليل جدوى مشاريع الشراكة بين القطاعين العام والخاص. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 1765,
      likeCount: 95,
      commentCount: 1,
      publishedAt: new Date('2025-10-18T10:00:00.000Z'),
    },
    {
      id: 'art_47',
      title: `التنمية البشرية في العراق: مؤشرات وتحديات`,
      summary: `تحليل معمق لـ التنمية البشرية في العراق - مؤشرات وتحديات`,
      content: `التنمية البشرية في العراق: مؤشرات وتحديات

تحليل معمق لـ التنمية البشرية في العراق - مؤشرات وتحديات. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 1802,
      likeCount: 108,
      commentCount: 8,
      publishedAt: new Date('2025-11-19T10:00:00.000Z'),
    },
    {
      id: 'art_48',
      title: `تأثير تغير المناخ على الاقتصاد العراقي`,
      summary: `تحليل معمق لـ تأثير تغير المناخ على الاقتصاد العراقي`,
      content: `تأثير تغير المناخ على الاقتصاد العراقي

تحليل معمق لـ تأثير تغير المناخ على الاقتصاد العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 1839,
      likeCount: 121,
      commentCount: 15,
      publishedAt: new Date('2025-12-20T10:00:00.000Z'),
    },
    {
      id: 'art_49',
      title: `تحليل قطاع التأمين في العراق: فرص النمو والتحديات`,
      summary: `تحليل معمق لـ تحليل قطاع التأمين في العراق - فرص النمو والتحديات`,
      content: `تحليل قطاع التأمين في العراق: فرص النمو والتحديات

تحليل معمق لـ تحليل قطاع التأمين في العراق - فرص النمو والتحديات. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 1876,
      likeCount: 134,
      commentCount: 7,
      publishedAt: new Date('2025-01-21T10:00:00.000Z'),
    },
    {
      id: 'art_50',
      title: `السياسة المالية في العراق: بين الإنفاق الجاري والاستثماري`,
      summary: `تحليل معمق لـ السياسة المالية في العراق - بين الإنفاق الجاري والاستثماري`,
      content: `السياسة المالية في العراق: بين الإنفاق الجاري والاستثماري

تحليل معمق لـ السياسة المالية في العراق - بين الإنفاق الجاري والاستثماري. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 1913,
      likeCount: 147,
      commentCount: 14,
      publishedAt: new Date('2025-02-22T10:00:00.000Z'),
    },
    {
      id: 'art_51',
      title: `تحليل سوق العقارات في بغداد والمدن الرئيسية`,
      summary: `تحليل معمق لـ تحليل سوق العقارات في بغداد والمدن الرئيسية`,
      content: `تحليل سوق العقارات في بغداد والمدن الرئيسية

تحليل معمق لـ تحليل سوق العقارات في بغداد والمدن الرئيسية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: false,
      viewCount: 1950,
      likeCount: 160,
      commentCount: 6,
      publishedAt: new Date('2025-03-23T10:00:00.000Z'),
    },
    {
      id: 'art_52',
      title: `التجارة الإلكترونية في العراق: نمو متسارع بلا تنظيم`,
      summary: `تحليل معمق لـ التجارة الإلكترونية في العراق - نمو متسارع بلا تنظيم`,
      content: `التجارة الإلكترونية في العراق: نمو متسارع بلا تنظيم

تحليل معمق لـ التجارة الإلكترونية في العراق - نمو متسارع بلا تنظيم. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 1987,
      likeCount: 173,
      commentCount: 13,
      publishedAt: new Date('2025-04-24T10:00:00.000Z'),
    },
    {
      id: 'art_53',
      title: `قطاع الصناعة في العراق: الواقع المتدهور والآمال المفقودة`,
      summary: `تحليل معمق لـ قطاع الصناعة في العراق - الواقع المتدهور والآمال المفقودة`,
      content: `قطاع الصناعة في العراق: الواقع المتدهور والآمال المفقودة

تحليل معمق لـ قطاع الصناعة في العراق - الواقع المتدهور والآمال المفقودة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 2024,
      likeCount: 186,
      commentCount: 5,
      publishedAt: new Date('2025-05-25T10:00:00.000Z'),
    },
    {
      id: 'art_54',
      title: `تحليل هشاشة الاقتصاد العراقي أمام الصدمات الخارجية`,
      summary: `تحليل معمق لـ تحليل هشاشة الاقتصاد العراقي أمام الصدمات الخارجية`,
      content: `تحليل هشاشة الاقتصاد العراقي أمام الصدمات الخارجية

تحليل معمق لـ تحليل هشاشة الاقتصاد العراقي أمام الصدمات الخارجية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 2061,
      likeCount: 199,
      commentCount: 12,
      publishedAt: new Date('2025-06-26T10:00:00.000Z'),
    },
    {
      id: 'art_55',
      title: `الدين العام العراقي: تطوره وتأثيره على الاستقرار المالي`,
      summary: `تحليل معمق لـ الدين العام العراقي - تطوره وتأثيره على الاستقرار المالي`,
      content: `الدين العام العراقي: تطوره وتأثيره على الاستقرار المالي

تحليل معمق لـ الدين العام العراقي - تطوره وتأثيره على الاستقرار المالي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'ANALYSIS',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 2098,
      likeCount: 212,
      commentCount: 4,
      publishedAt: new Date('2025-07-27T10:00:00.000Z'),
    },
    {
      id: 'art_56',
      title: `لماذا يحتاج العراق إلى ثورة تعليمية اقتصادية؟`,
      summary: `رأي وخبرة حول لماذا يحتاج العراق إلى ثورة تعليمية اقتصادية`,
      content: `لماذا يحتاج العراق إلى ثورة تعليمية اقتصادية؟

رأي وخبرة حول لماذا يحتاج العراق إلى ثورة تعليمية اقتصادية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 135,
      likeCount: 225,
      commentCount: 11,
      publishedAt: new Date('2025-08-28T10:00:00.000Z'),
    },
    {
      id: 'art_57',
      title: `رأي: الإصلاح الاقتصادي يبدأ من محاربة الفساد`,
      summary: `رأي وخبرة حول رأي - الإصلاح الاقتصادي يبدأ من محاربة الفساد`,
      content: `رأي: الإصلاح الاقتصادي يبدأ من محاربة الفساد

رأي وخبرة حول رأي - الإصلاح الاقتصادي يبدأ من محاربة الفساد. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 172,
      likeCount: 238,
      commentCount: 3,
      publishedAt: new Date('2025-09-01T10:00:00.000Z'),
    },
    {
      id: 'art_58',
      title: `هل يعيش العراق فقاعة عقارية؟`,
      summary: `رأي وخبرة حول هل يعيش العراق فقاعة عقارية`,
      content: `هل يعيش العراق فقاعة عقارية؟

رأي وخبرة حول هل يعيش العراق فقاعة عقارية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 209,
      likeCount: 251,
      commentCount: 10,
      publishedAt: new Date('2025-10-02T10:00:00.000Z'),
    },
    {
      id: 'art_59',
      title: `رأي: دور المرأة في التنمية الاقتصادية لا يزال مهمشاً`,
      summary: `رأي وخبرة حول رأي - دور المرأة في التنمية الاقتصادية لا يزال مهمشاً`,
      content: `رأي: دور المرأة في التنمية الاقتصادية لا يزال مهمشاً

رأي وخبرة حول رأي - دور المرأة في التنمية الاقتصادية لا يزال مهمشاً. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 246,
      likeCount: 14,
      commentCount: 2,
      publishedAt: new Date('2025-11-03T10:00:00.000Z'),
    },
    {
      id: 'art_60',
      title: `لماذا فشلت خطط التنمية المتعاقبة في العراق؟`,
      summary: `رأي وخبرة حول لماذا فشلت خطط التنمية المتعاقبة في العراق`,
      content: `لماذا فشلت خطط التنمية المتعاقبة في العراق؟

رأي وخبرة حول لماذا فشلت خطط التنمية المتعاقبة في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 283,
      likeCount: 27,
      commentCount: 9,
      publishedAt: new Date('2025-12-04T10:00:00.000Z'),
    },
    {
      id: 'art_61',
      title: `رأي: التحول الرقمي ليس ترفاً بل ضرورة اقتصادية`,
      summary: `رأي وخبرة حول رأي - التحول الرقمي ليس ترفاً بل ضرورة اقتصادية`,
      content: `رأي: التحول الرقمي ليس ترفاً بل ضرورة اقتصادية

رأي وخبرة حول رأي - التحول الرقمي ليس ترفاً بل ضرورة اقتصادية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: true,
      viewCount: 320,
      likeCount: 40,
      commentCount: 1,
      publishedAt: new Date('2025-01-05T10:00:00.000Z'),
    },
    {
      id: 'art_62',
      title: `هل يمكن للعراق أن يتعلم من تجربة رواندا الاقتصادية؟`,
      summary: `رأي وخبرة حول هل يمكن للعراق أن يتعلم من تجربة رواندا الاقتصادية`,
      content: `هل يمكن للعراق أن يتعلم من تجربة رواندا الاقتصادية؟

رأي وخبرة حول هل يمكن للعراق أن يتعلم من تجربة رواندا الاقتصادية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 357,
      likeCount: 53,
      commentCount: 8,
      publishedAt: new Date('2025-02-06T10:00:00.000Z'),
    },
    {
      id: 'art_63',
      title: `رأي: البطالة ليست مشكلة اقتصادية فقط بل أمنية أيضاً`,
      summary: `رأي وخبرة حول رأي - البطالة ليست مشكلة اقتصادية فقط بل أمنية أيضاً`,
      content: `رأي: البطالة ليست مشكلة اقتصادية فقط بل أمنية أيضاً

رأي وخبرة حول رأي - البطالة ليست مشكلة اقتصادية فقط بل أمنية أيضاً. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 394,
      likeCount: 66,
      commentCount: 15,
      publishedAt: new Date('2025-03-07T10:00:00.000Z'),
    },
    {
      id: 'art_64',
      title: `الاحتياطي النفطي الاستراتيجي: ضرورة أم ترف؟`,
      summary: `رأي وخبرة حول الاحتياطي النفطي الاستراتيجي - ضرورة أم ترف`,
      content: `الاحتياطي النفطي الاستراتيجي: ضرورة أم ترف؟

رأي وخبرة حول الاحتياطي النفطي الاستراتيجي - ضرورة أم ترف. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 431,
      likeCount: 79,
      commentCount: 7,
      publishedAt: new Date('2025-04-08T10:00:00.000Z'),
    },
    {
      id: 'art_65',
      title: `رأي: يجب إلغاء الدعم الحكومي العشوائي واستبداله بدعم مستهدف`,
      summary: `رأي وخبرة حول رأي - يجب إلغاء الدعم الحكومي العشوائي واستبداله بدعم مستهدف`,
      content: `رأي: يجب إلغاء الدعم الحكومي العشوائي واستبداله بدعم مستهدف

رأي وخبرة حول رأي - يجب إلغاء الدعم الحكومي العشوائي واستبداله بدعم مستهدف. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 468,
      likeCount: 92,
      commentCount: 14,
      publishedAt: new Date('2025-05-09T10:00:00.000Z'),
    },
    {
      id: 'art_66',
      title: `لماذا يفضل العراقيون الادخار بالذهب بدل البنوك؟`,
      summary: `رأي وخبرة حول لماذا يفضل العراقيون الادخار بالذهب بدل البنوك`,
      content: `لماذا يفضل العراقيون الادخار بالذهب بدل البنوك؟

رأي وخبرة حول لماذا يفضل العراقيون الادخار بالذهب بدل البنوك. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 505,
      likeCount: 105,
      commentCount: 6,
      publishedAt: new Date('2025-06-10T10:00:00.000Z'),
    },
    {
      id: 'art_67',
      title: `رأي: التعليم الاقتصادي في المدارس العراقية حاجة ملحة`,
      summary: `رأي وخبرة حول رأي - التعليم الاقتصادي في المدارس العراقية حاجة ملحة`,
      content: `رأي: التعليم الاقتصادي في المدارس العراقية حاجة ملحة

رأي وخبرة حول رأي - التعليم الاقتصادي في المدارس العراقية حاجة ملحة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 542,
      likeCount: 118,
      commentCount: 13,
      publishedAt: new Date('2025-07-11T10:00:00.000Z'),
    },
    {
      id: 'art_68',
      title: `هل نحن بحاجة إلى بنك مركزي مستقل حقاً؟`,
      summary: `رأي وخبرة حول هل نحن بحاجة إلى بنك مركزي مستقل حقاً`,
      content: `هل نحن بحاجة إلى بنك مركزي مستقل حقاً؟

رأي وخبرة حول هل نحن بحاجة إلى بنك مركزي مستقل حقاً. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 579,
      likeCount: 131,
      commentCount: 5,
      publishedAt: new Date('2025-08-12T10:00:00.000Z'),
    },
    {
      id: 'art_69',
      title: `رأي: الاقتصاد غير الرسمي يقتل الابتكار ويقتل المنافسة`,
      summary: `رأي وخبرة حول رأي - الاقتصاد غير الرسمي يقتل الابتكار ويقتل المنافسة`,
      content: `رأي: الاقتصاد غير الرسمي يقتل الابتكار ويقتل المنافسة

رأي وخبرة حول رأي - الاقتصاد غير الرسمي يقتل الابتكار ويقتل المنافسة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 616,
      likeCount: 144,
      commentCount: 12,
      publishedAt: new Date('2025-09-13T10:00:00.000Z'),
    },
    {
      id: 'art_70',
      title: `مستقبل العملات الرقمية في العراق: فرصة أم خطر؟`,
      summary: `رأي وخبرة حول مستقبل العملات الرقمية في العراق - فرصة أم خطر`,
      content: `مستقبل العملات الرقمية في العراق: فرصة أم خطر؟

رأي وخبرة حول مستقبل العملات الرقمية في العراق - فرصة أم خطر. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 653,
      likeCount: 157,
      commentCount: 4,
      publishedAt: new Date('2025-10-14T10:00:00.000Z'),
    },
    {
      id: 'art_71',
      title: `رأي: يجب فتح قطاع الاتصالات للمنافسة الحقيقية`,
      summary: `رأي وخبرة حول رأي - يجب فتح قطاع الاتصالات للمنافسة الحقيقية`,
      content: `رأي: يجب فتح قطاع الاتصالات للمنافسة الحقيقية

رأي وخبرة حول رأي - يجب فتح قطاع الاتصالات للمنافسة الحقيقية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: false,
      viewCount: 690,
      likeCount: 170,
      commentCount: 11,
      publishedAt: new Date('2025-11-15T10:00:00.000Z'),
    },
    {
      id: 'art_72',
      title: `لماذا يتأخر العراق في مؤشرات الشفافية الاقتصادية؟`,
      summary: `رأي وخبرة حول لماذا يتأخر العراق في مؤشرات الشفافية الاقتصادية`,
      content: `لماذا يتأخر العراق في مؤشرات الشفافية الاقتصادية؟

رأي وخبرة حول لماذا يتأخر العراق في مؤشرات الشفافية الاقتصادية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 727,
      likeCount: 183,
      commentCount: 3,
      publishedAt: new Date('2025-12-16T10:00:00.000Z'),
    },
    {
      id: 'art_73',
      title: `رأي: الإصلاح المصرفي شرط أساسي للنمو الاقتصادي`,
      summary: `رأي وخبرة حول رأي - الإصلاح المصرفي شرط أساسي للنمو الاقتصادي`,
      content: `رأي: الإصلاح المصرفي شرط أساسي للنمو الاقتصادي

رأي وخبرة حول رأي - الإصلاح المصرفي شرط أساسي للنمو الاقتصادي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 764,
      likeCount: 196,
      commentCount: 10,
      publishedAt: new Date('2025-01-17T10:00:00.000Z'),
    },
    {
      id: 'art_74',
      title: `هل يمكن للقطاع الزراعي أن ينقذ الاقتصاد العراقي؟`,
      summary: `رأي وخبرة حول هل يمكن للقطاع الزراعي أن ينقذ الاقتصاد العراقي`,
      content: `هل يمكن للقطاع الزراعي أن ينقذ الاقتصاد العراقي؟

رأي وخبرة حول هل يمكن للقطاع الزراعي أن ينقذ الاقتصاد العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 801,
      likeCount: 209,
      commentCount: 2,
      publishedAt: new Date('2025-02-18T10:00:00.000Z'),
    },
    {
      id: 'art_75',
      title: `رأي: الهجرة والعمالة الأجنبية وتأثيرها على سوق العمل`,
      summary: `رأي وخبرة حول رأي - الهجرة والعمالة الأجنبية وتأثيرها على سوق العمل`,
      content: `رأي: الهجرة والعمالة الأجنبية وتأثيرها على سوق العمل

رأي وخبرة حول رأي - الهجرة والعمالة الأجنبية وتأثيرها على سوق العمل. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'OPINION',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 838,
      likeCount: 222,
      commentCount: 9,
      publishedAt: new Date('2025-03-19T10:00:00.000Z'),
    },
    {
      id: 'art_76',
      title: `تقرير: حالة الاقتصاد العراقي في الربع الأول من 2025`,
      summary: `تقرير شامل عن تقرير - حالة الاقتصاد العراقي في الربع الأول من 2025`,
      content: `تقرير: حالة الاقتصاد العراقي في الربع الأول من 2025

تقرير شامل عن تقرير - حالة الاقتصاد العراقي في الربع الأول من 2025. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 875,
      likeCount: 235,
      commentCount: 1,
      publishedAt: new Date('2025-04-20T10:00:00.000Z'),
    },
    {
      id: 'art_77',
      title: `تقرير أداء بورصة بغداد: مؤشرات وتحليل`,
      summary: `تقرير شامل عن تقرير أداء بورصة بغداد - مؤشرات وتحليل`,
      content: `تقرير أداء بورصة بغداد: مؤشرات وتحليل

تقرير شامل عن تقرير أداء بورصة بغداد - مؤشرات وتحليل. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 912,
      likeCount: 248,
      commentCount: 8,
      publishedAt: new Date('2025-05-21T10:00:00.000Z'),
    },
    {
      id: 'art_78',
      title: `تقرير القطاع المصرفي العراقي 2025`,
      summary: `تقرير شامل عن تقرير القطاع المصرفي العراقي 2025`,
      content: `تقرير القطاع المصرفي العراقي 2025

تقرير شامل عن تقرير القطاع المصرفي العراقي 2025. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 949,
      likeCount: 11,
      commentCount: 15,
      publishedAt: new Date('2025-06-22T10:00:00.000Z'),
    },
    {
      id: 'art_79',
      title: `تقرير التنمية البشرية في العراق`,
      summary: `تقرير شامل عن تقرير التنمية البشرية في العراق`,
      content: `تقرير التنمية البشرية في العراق

تقرير شامل عن تقرير التنمية البشرية في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 986,
      likeCount: 24,
      commentCount: 7,
      publishedAt: new Date('2025-07-23T10:00:00.000Z'),
    },
    {
      id: 'art_80',
      title: `تقرير حالة سوق العمل والبطالة`,
      summary: `تقرير شامل عن تقرير حالة سوق العمل والبطالة`,
      content: `تقرير حالة سوق العمل والبطالة

تقرير شامل عن تقرير حالة سوق العمل والبطالة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 1023,
      likeCount: 37,
      commentCount: 14,
      publishedAt: new Date('2025-08-24T10:00:00.000Z'),
    },
    {
      id: 'art_81',
      title: `تقرير أداء الميزانية العامة: الإنفاق والإيرادات`,
      summary: `تقرير شامل عن تقرير أداء الميزانية العامة - الإنفاق والإيرادات`,
      content: `تقرير أداء الميزانية العامة: الإنفاق والإيرادات

تقرير شامل عن تقرير أداء الميزانية العامة - الإنفاق والإيرادات. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: true,
      viewCount: 1060,
      likeCount: 50,
      commentCount: 6,
      publishedAt: new Date('2025-09-25T10:00:00.000Z'),
    },
    {
      id: 'art_82',
      title: `تقرير قطاع النفط والطاقة: الإنتاج والتصدير`,
      summary: `تقرير شامل عن تقرير قطاع النفط والطاقة - الإنتاج والتصدير`,
      content: `تقرير قطاع النفط والطاقة: الإنتاج والتصدير

تقرير شامل عن تقرير قطاع النفط والطاقة - الإنتاج والتصدير. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 1097,
      likeCount: 63,
      commentCount: 13,
      publishedAt: new Date('2025-10-26T10:00:00.000Z'),
    },
    {
      id: 'art_83',
      title: `تقرير التجارة الخارجية العراقية`,
      summary: `تقرير شامل عن تقرير التجارة الخارجية العراقية`,
      content: `تقرير التجارة الخارجية العراقية

تقرير شامل عن تقرير التجارة الخارجية العراقية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 1134,
      likeCount: 76,
      commentCount: 5,
      publishedAt: new Date('2025-11-27T10:00:00.000Z'),
    },
    {
      id: 'art_84',
      title: `تقرير قطاع الإسكان والعقارات في العراق`,
      summary: `تقرير شامل عن تقرير قطاع الإسكان والعقارات في العراق`,
      content: `تقرير قطاع الإسكان والعقارات في العراق

تقرير شامل عن تقرير قطاع الإسكان والعقارات في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 1171,
      likeCount: 89,
      commentCount: 12,
      publishedAt: new Date('2025-12-28T10:00:00.000Z'),
    },
    {
      id: 'art_85',
      title: `تقرير حالة البنية التحتية في العراق`,
      summary: `تقرير شامل عن تقرير حالة البنية التحتية في العراق`,
      content: `تقرير حالة البنية التحتية في العراق

تقرير شامل عن تقرير حالة البنية التحتية في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 1208,
      likeCount: 102,
      commentCount: 4,
      publishedAt: new Date('2025-01-01T10:00:00.000Z'),
    },
    {
      id: 'art_86',
      title: `تقرير قطاع الاتصالات وتكنولوجيا المعلومات`,
      summary: `تقرير شامل عن تقرير قطاع الاتصالات وتكنولوجيا المعلومات`,
      content: `تقرير قطاع الاتصالات وتكنولوجيا المعلومات

تقرير شامل عن تقرير قطاع الاتصالات وتكنولوجيا المعلومات. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 1245,
      likeCount: 115,
      commentCount: 11,
      publishedAt: new Date('2025-02-02T10:00:00.000Z'),
    },
    {
      id: 'art_87',
      title: `تقرير حالة التعليم المهني والتقني في العراق`,
      summary: `تقرير شامل عن تقرير حالة التعليم المهني والتقني في العراق`,
      content: `تقرير حالة التعليم المهني والتقني في العراق

تقرير شامل عن تقرير حالة التعليم المهني والتقني في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 1282,
      likeCount: 128,
      commentCount: 3,
      publishedAt: new Date('2025-03-03T10:00:00.000Z'),
    },
    {
      id: 'art_88',
      title: `تقرير قطاع الصناعة والتعدين`,
      summary: `تقرير شامل عن تقرير قطاع الصناعة والتعدين`,
      content: `تقرير قطاع الصناعة والتعدين

تقرير شامل عن تقرير قطاع الصناعة والتعدين. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 1319,
      likeCount: 141,
      commentCount: 10,
      publishedAt: new Date('2025-04-04T10:00:00.000Z'),
    },
    {
      id: 'art_89',
      title: `تقرير حالة البيئة والاقتصاد الأخضر`,
      summary: `تقرير شامل عن تقرير حالة البيئة والاقتصاد الأخضر`,
      content: `تقرير حالة البيئة والاقتصاد الأخضر

تقرير شامل عن تقرير حالة البيئة والاقتصاد الأخضر. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 1356,
      likeCount: 154,
      commentCount: 2,
      publishedAt: new Date('2025-05-05T10:00:00.000Z'),
    },
    {
      id: 'art_90',
      title: `تقرير التحول الرقمي في القطاع الحكومي`,
      summary: `تقرير شامل عن تقرير التحول الرقمي في القطاع الحكومي`,
      content: `تقرير التحول الرقمي في القطاع الحكومي

تقرير شامل عن تقرير التحول الرقمي في القطاع الحكومي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'REPORT',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 1393,
      likeCount: 167,
      commentCount: 9,
      publishedAt: new Date('2025-06-06T10:00:00.000Z'),
    },
    {
      id: 'art_91',
      title: `بحث: تأثير أسعار النفط على النمو الاقتصادي في العراق 2003-2024`,
      summary: `بحث علمي حول بحث - تأثير أسعار النفط على النمو الاقتصادي في العراق 2003-2024`,
      content: `بحث: تأثير أسعار النفط على النمو الاقتصادي في العراق 2003-2024

بحث علمي حول بحث - تأثير أسعار النفط على النمو الاقتصادي في العراق 2003-2024. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: false,
      viewCount: 1430,
      likeCount: 180,
      commentCount: 1,
      publishedAt: new Date('2025-07-07T10:00:00.000Z'),
    },
    {
      id: 'art_92',
      title: `بحث: العلاقة بين الاستثمار في التعليم والنمو الاقتصادي`,
      summary: `بحث علمي حول بحث - العلاقة بين الاستثمار في التعليم والنمو الاقتصادي`,
      content: `بحث: العلاقة بين الاستثمار في التعليم والنمو الاقتصادي

بحث علمي حول بحث - العلاقة بين الاستثمار في التعليم والنمو الاقتصادي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 1467,
      likeCount: 193,
      commentCount: 8,
      publishedAt: new Date('2025-08-08T10:00:00.000Z'),
    },
    {
      id: 'art_93',
      title: `بحث: تحليل قياسي لمحددات التضخم في العراق`,
      summary: `بحث علمي حول بحث - تحليل قياسي لمحددات التضخم في العراق`,
      content: `بحث: تحليل قياسي لمحددات التضخم في العراق

بحث علمي حول بحث - تحليل قياسي لمحددات التضخم في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 1504,
      likeCount: 206,
      commentCount: 15,
      publishedAt: new Date('2025-09-09T10:00:00.000Z'),
    },
    {
      id: 'art_94',
      title: `بحث: دور القطاع المالي في تعزيز النمو الاقتصادي`,
      summary: `بحث علمي حول بحث - دور القطاع المالي في تعزيز النمو الاقتصادي`,
      content: `بحث: دور القطاع المالي في تعزيز النمو الاقتصادي

بحث علمي حول بحث - دور القطاع المالي في تعزيز النمو الاقتصادي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 1541,
      likeCount: 219,
      commentCount: 7,
      publishedAt: new Date('2025-10-10T10:00:00.000Z'),
    },
    {
      id: 'art_95',
      title: `بحث: تأثير السياسات المالية على توزيع الدخل في العراق`,
      summary: `بحث علمي حول بحث - تأثير السياسات المالية على توزيع الدخل في العراق`,
      content: `بحث: تأثير السياسات المالية على توزيع الدخل في العراق

بحث علمي حول بحث - تأثير السياسات المالية على توزيع الدخل في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 1578,
      likeCount: 232,
      commentCount: 14,
      publishedAt: new Date('2025-11-11T10:00:00.000Z'),
    },
    {
      id: 'art_96',
      title: `بحث: الاقتصاد الدائري كنموذج بديل للاقتصاد العراقي`,
      summary: `بحث علمي حول بحث - الاقتصاد الدائري كنموذج بديل للاقتصاد العراقي`,
      content: `بحث: الاقتصاد الدائري كنموذج بديل للاقتصاد العراقي

بحث علمي حول بحث - الاقتصاد الدائري كنموذج بديل للاقتصاد العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 1615,
      likeCount: 245,
      commentCount: 6,
      publishedAt: new Date('2025-12-12T10:00:00.000Z'),
    },
    {
      id: 'art_97',
      title: `بحث: تقييم سياسات البنك المركزي في مواجهة الأزمات المالية`,
      summary: `بحث علمي حول بحث - تقييم سياسات البنك المركزي في مواجهة الأزمات المالية`,
      content: `بحث: تقييم سياسات البنك المركزي في مواجهة الأزمات المالية

بحث علمي حول بحث - تقييم سياسات البنك المركزي في مواجهة الأزمات المالية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 1652,
      likeCount: 258,
      commentCount: 13,
      publishedAt: new Date('2025-01-13T10:00:00.000Z'),
    },
    {
      id: 'art_98',
      title: `بحث: تحليل اقتصادي لقطاع المياه في العراق`,
      summary: `بحث علمي حول بحث - تحليل اقتصادي لقطاع المياه في العراق`,
      content: `بحث: تحليل اقتصادي لقطاع المياه في العراق

بحث علمي حول بحث - تحليل اقتصادي لقطاع المياه في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 1689,
      likeCount: 21,
      commentCount: 5,
      publishedAt: new Date('2025-02-14T10:00:00.000Z'),
    },
    {
      id: 'art_99',
      title: `بحث: دور ريادة الأعمال في التنويع الاقتصادي`,
      summary: `بحث علمي حول بحث - دور ريادة الأعمال في التنويع الاقتصادي`,
      content: `بحث: دور ريادة الأعمال في التنويع الاقتصادي

بحث علمي حول بحث - دور ريادة الأعمال في التنويع الاقتصادي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 1726,
      likeCount: 34,
      commentCount: 12,
      publishedAt: new Date('2025-03-15T10:00:00.000Z'),
    },
    {
      id: 'art_100',
      title: `بحث: تأثير التكنولوجيا المالية على الشمول المالي في العراق`,
      summary: `بحث علمي حول بحث - تأثير التكنولوجيا المالية على الشمول المالي في العراق`,
      content: `بحث: تأثير التكنولوجيا المالية على الشمول المالي في العراق

بحث علمي حول بحث - تأثير التكنولوجيا المالية على الشمول المالي في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 1763,
      likeCount: 47,
      commentCount: 4,
      publishedAt: new Date('2025-04-16T10:00:00.000Z'),
    },
    {
      id: 'art_101',
      title: `بحث: النقل والمواصلات وأثره على التنمية الاقتصادية`,
      summary: `بحث علمي حول بحث - النقل والمواصلات وأثره على التنمية الاقتصادية`,
      content: `بحث: النقل والمواصلات وأثره على التنمية الاقتصادية

بحث علمي حول بحث - النقل والمواصلات وأثره على التنمية الاقتصادية. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: true,
      viewCount: 1800,
      likeCount: 60,
      commentCount: 11,
      publishedAt: new Date('2025-05-17T10:00:00.000Z'),
    },
    {
      id: 'art_102',
      title: `بحث: تحليل جدوى الاستثمار في الطاقة الشمسية في العراق`,
      summary: `بحث علمي حول بحث - تحليل جدوى الاستثمار في الطاقة الشمسية في العراق`,
      content: `بحث: تحليل جدوى الاستثمار في الطاقة الشمسية في العراق

بحث علمي حول بحث - تحليل جدوى الاستثمار في الطاقة الشمسية في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 1837,
      likeCount: 73,
      commentCount: 3,
      publishedAt: new Date('2025-06-18T10:00:00.000Z'),
    },
    {
      id: 'art_103',
      title: `بحث: اقتصاديات الصحة العامة في العراق`,
      summary: `بحث علمي حول بحث - اقتصاديات الصحة العامة في العراق`,
      content: `بحث: اقتصاديات الصحة العامة في العراق

بحث علمي حول بحث - اقتصاديات الصحة العامة في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 1874,
      likeCount: 86,
      commentCount: 10,
      publishedAt: new Date('2025-07-19T10:00:00.000Z'),
    },
    {
      id: 'art_104',
      title: `بحث: تأثير الهجرة على سوق العمل والاقتصاد العراقي`,
      summary: `بحث علمي حول بحث - تأثير الهجرة على سوق العمل والاقتصاد العراقي`,
      content: `بحث: تأثير الهجرة على سوق العمل والاقتصاد العراقي

بحث علمي حول بحث - تأثير الهجرة على سوق العمل والاقتصاد العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 1911,
      likeCount: 99,
      commentCount: 2,
      publishedAt: new Date('2025-08-20T10:00:00.000Z'),
    },
    {
      id: 'art_105',
      title: `بحث: تقييم برامج الإصلاح الاقتصادي في العراق`,
      summary: `بحث علمي حول بحث - تقييم برامج الإصلاح الاقتصادي في العراق`,
      content: `بحث: تقييم برامج الإصلاح الاقتصادي في العراق

بحث علمي حول بحث - تقييم برامج الإصلاح الاقتصادي في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'RESEARCH',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 1948,
      likeCount: 112,
      commentCount: 9,
      publishedAt: new Date('2025-09-21T10:00:00.000Z'),
    },
    {
      id: 'art_106',
      title: `دراسة: التحول نحو الاقتصاد الأخضر في العراق - الفرص والتحديات`,
      summary: `دراسة تحليلية حول دراسة - التحول نحو الاقتصاد الأخضر في العراق - الفرص والتحديات`,
      content: `دراسة: التحول نحو الاقتصاد الأخضر في العراق - الفرص والتحديات

دراسة تحليلية حول دراسة - التحول نحو الاقتصاد الأخضر في العراق - الفرص والتحديات. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 1985,
      likeCount: 125,
      commentCount: 1,
      publishedAt: new Date('2025-10-22T10:00:00.000Z'),
    },
    {
      id: 'art_107',
      title: `دراسة: تأثير إصلاح القطاع المصرفي على الشمول المالي`,
      summary: `دراسة تحليلية حول دراسة - تأثير إصلاح القطاع المصرفي على الشمول المالي`,
      content: `دراسة: تأثير إصلاح القطاع المصرفي على الشمول المالي

دراسة تحليلية حول دراسة - تأثير إصلاح القطاع المصرفي على الشمول المالي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 2022,
      likeCount: 138,
      commentCount: 8,
      publishedAt: new Date('2025-11-23T10:00:00.000Z'),
    },
    {
      id: 'art_108',
      title: `دراسة: الاقتصاد السياسي للفساد في العراق`,
      summary: `دراسة تحليلية حول دراسة - الاقتصاد السياسي للفساد في العراق`,
      content: `دراسة: الاقتصاد السياسي للفساد في العراق

دراسة تحليلية حول دراسة - الاقتصاد السياسي للفساد في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 2059,
      likeCount: 151,
      commentCount: 15,
      publishedAt: new Date('2025-12-24T10:00:00.000Z'),
    },
    {
      id: 'art_109',
      title: `دراسة: واقع المشاريع الصغيرة والمتوسطة في العراق`,
      summary: `دراسة تحليلية حول دراسة - واقع المشاريع الصغيرة والمتوسطة في العراق`,
      content: `دراسة: واقع المشاريع الصغيرة والمتوسطة في العراق

دراسة تحليلية حول دراسة - واقع المشاريع الصغيرة والمتوسطة في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 2096,
      likeCount: 164,
      commentCount: 7,
      publishedAt: new Date('2025-01-25T10:00:00.000Z'),
    },
    {
      id: 'art_110',
      title: `دراسة: قطاع السياحة الدينية وأثره على الاقتصاد الوطني`,
      summary: `دراسة تحليلية حول دراسة - قطاع السياحة الدينية وأثره على الاقتصاد الوطني`,
      content: `دراسة: قطاع السياحة الدينية وأثره على الاقتصاد الوطني

دراسة تحليلية حول دراسة - قطاع السياحة الدينية وأثره على الاقتصاد الوطني. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 133,
      likeCount: 177,
      commentCount: 14,
      publishedAt: new Date('2025-02-26T10:00:00.000Z'),
    },
    {
      id: 'art_111',
      title: `دراسة: التحول الحضري وتأثيره على الاقتصاد المحلي`,
      summary: `دراسة تحليلية حول دراسة - التحول الحضري وتأثيره على الاقتصاد المحلي`,
      content: `دراسة: التحول الحضري وتأثيره على الاقتصاد المحلي

دراسة تحليلية حول دراسة - التحول الحضري وتأثيره على الاقتصاد المحلي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_ahmad',
      featured: false,
      viewCount: 170,
      likeCount: 190,
      commentCount: 6,
      publishedAt: new Date('2025-03-27T10:00:00.000Z'),
    },
    {
      id: 'art_112',
      title: `دراسة: دور المرأة في سوق العمل العراقي`,
      summary: `دراسة تحليلية حول دراسة - دور المرأة في سوق العمل العراقي`,
      content: `دراسة: دور المرأة في سوق العمل العراقي

دراسة تحليلية حول دراسة - دور المرأة في سوق العمل العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/china-trade.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_sara',
      featured: false,
      viewCount: 207,
      likeCount: 203,
      commentCount: 13,
      publishedAt: new Date('2025-04-28T10:00:00.000Z'),
    },
    {
      id: 'art_113',
      title: `دراسة: اقتصاديات المياه العابرة للحدود وأثرها على العراق`,
      summary: `دراسة تحليلية حول دراسة - اقتصاديات المياه العابرة للحدود وأثرها على العراق`,
      content: `دراسة: اقتصاديات المياه العابرة للحدود وأثرها على العراق

دراسة تحليلية حول دراسة - اقتصاديات المياه العابرة للحدود وأثرها على العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/reconstruction.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_omar',
      featured: false,
      viewCount: 244,
      likeCount: 216,
      commentCount: 5,
      publishedAt: new Date('2025-05-01T10:00:00.000Z'),
    },
    {
      id: 'art_114',
      title: `دراسة: تقييم برامج الدعم الحكومي للقطاع الزراعي`,
      summary: `دراسة تحليلية حول دراسة - تقييم برامج الدعم الحكومي للقطاع الزراعي`,
      content: `دراسة: تقييم برامج الدعم الحكومي للقطاع الزراعي

دراسة تحليلية حول دراسة - تقييم برامج الدعم الحكومي للقطاع الزراعي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/agriculture.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_fatima',
      featured: false,
      viewCount: 281,
      likeCount: 229,
      commentCount: 12,
      publishedAt: new Date('2025-06-02T10:00:00.000Z'),
    },
    {
      id: 'art_115',
      title: `دراسة: واقع التجارة الإلكترونية في العراق والمنطقة`,
      summary: `دراسة تحليلية حول دراسة - واقع التجارة الإلكترونية في العراق والمنطقة`,
      content: `دراسة: واقع التجارة الإلكترونية في العراق والمنطقة

دراسة تحليلية حول دراسة - واقع التجارة الإلكترونية في العراق والمنطقة. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/budget-2024.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_ali',
      featured: false,
      viewCount: 318,
      likeCount: 242,
      commentCount: 4,
      publishedAt: new Date('2025-07-03T10:00:00.000Z'),
    },
    {
      id: 'art_116',
      title: `دراسة: أثر البنية التحتية الرقمية على جاذبية الاستثمار`,
      summary: `دراسة تحليلية حول دراسة - أثر البنية التحتية الرقمية على جاذبية الاستثمار`,
      content: `دراسة: أثر البنية التحتية الرقمية على جاذبية الاستثمار

دراسة تحليلية حول دراسة - أثر البنية التحتية الرقمية على جاذبية الاستثمار. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/tourism.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_zainab',
      featured: false,
      viewCount: 355,
      likeCount: 255,
      commentCount: 11,
      publishedAt: new Date('2025-08-04T10:00:00.000Z'),
    },
    {
      id: 'art_117',
      title: `دراسة: منظومة الابتكار في العراق - الواقع والآفاق`,
      summary: `دراسة تحليلية حول دراسة - منظومة الابتكار في العراق - الواقع والآفاق`,
      content: `دراسة: منظومة الابتكار في العراق - الواقع والآفاق

دراسة تحليلية حول دراسة - منظومة الابتكار في العراق - الواقع والآفاق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert7',
      featured: false,
      viewCount: 392,
      likeCount: 18,
      commentCount: 3,
      publishedAt: new Date('2025-09-05T10:00:00.000Z'),
    },
    {
      id: 'art_118',
      title: `دراسة: تأثير التغير المناخي على الأمن الغذائي العراقي`,
      summary: `دراسة تحليلية حول دراسة - تأثير التغير المناخي على الأمن الغذائي العراقي`,
      content: `دراسة: تأثير التغير المناخي على الأمن الغذائي العراقي

دراسة تحليلية حول دراسة - تأثير التغير المناخي على الأمن الغذائي العراقي. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/dinar-exchange.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert8',
      featured: false,
      viewCount: 429,
      likeCount: 31,
      commentCount: 10,
      publishedAt: new Date('2025-10-06T10:00:00.000Z'),
    },
    {
      id: 'art_119',
      title: `دراسة: التحليل الاقتصادي لقطاع الصيدلة في العراق`,
      summary: `دراسة تحليلية حول دراسة - التحليل الاقتصادي لقطاع الصيدلة في العراق`,
      content: `دراسة: التحليل الاقتصادي لقطاع الصيدلة في العراق

دراسة تحليلية حول دراسة - التحليل الاقتصادي لقطاع الصيدلة في العراق. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/stock-exchange.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert9',
      featured: false,
      viewCount: 466,
      likeCount: 44,
      commentCount: 2,
      publishedAt: new Date('2025-11-07T10:00:00.000Z'),
    },
    {
      id: 'art_120',
      title: `دراسة: واقع التعليم التقني والمهني واحتياجات سوق العمل`,
      summary: `دراسة تحليلية حول دراسة - واقع التعليم التقني والمهني واحتياجات سوق العمل`,
      content: `دراسة: واقع التعليم التقني والمهني واحتياجات سوق العمل

دراسة تحليلية حول دراسة - واقع التعليم التقني والمهني واحتياجات سوق العمل. يعد هذا الموضوع من أهم المواضيع الاقتصادية التي تهم المجتمع العراقي في المرحلة الحالية. تتناول هذه المقالة الجوانب المختلفة للموضوع مع تقديم تحليل معمق وآراء الخبراء في هذا الشأن.

يؤكد المتخصصون على أهمية معالجة هذا الموضوع بشكل جدي ومسؤول، مع الأخذ بعين الاعتبار الظروف الاقتصادية الراهنة التي يمر بها العراق والمنطقة. وتتطلب المعالجة الفعالة تبني سياسات اقتصادية شاملة ومتكاملة تراعي مصالح جميع الأطراف المعنية.

وتشير البيانات المتاحة إلى وجود فرص حقيقية للتحسن والتطوير في هذا المجال، شريطة توفير الإرادة السياسية والبيئة التشريعية المناسبة. كما يؤكد الخبراء على ضرورة تعزيز الشفافية والمساءلة في إدارة الموارد الاقتصادية.

وفي الختام، يوصي المتخصصون بضرورة الاستمرار في متابعة هذا الموضوع وتطوير الحلول المناسبة بما يخدم المصلحة الاقتصادية الوطنية ويعزز من استقرار الاقتصاد العراقي ونموه المستدام.`,
      coverImage: '/uploads/posts/fintech-iraq.jpg',
      category: 'STUDY',
      status: 'PUBLISHED',
      authorId: 'user_expert10',
      featured: false,
      viewCount: 503,
      likeCount: 57,
      commentCount: 9,
      publishedAt: new Date('2025-12-08T10:00:00.000Z'),
    },
  ]
  for (const a of articlesData) { await prisma.article.create({ data: a }) }
  console.log('  ✓ 120 articles created')

  // ===== DISCUSSIONS (30) =====
  const discussionsData = [
    {
      id: 'disc_1',
      title: `ما هو تأثير انضمام العراق إلى اتفاقية الشراكة الاقتصادية الإقليمية؟`,
      content: `ما هو تأثير انضمام العراق إلى اتفاقية الشراكة الاقتصادية الإقليمية؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_moderator',
      category: 'POLICY',
      viewCount: 50,
      replyCount: 2,
      isPinned: true,
      isLocked: false,
    },
    {
      id: 'disc_2',
      title: `هل يجب على الحكومة رفع الدعم عن المحروقات؟`,
      content: `هل يجب على الحكومة رفع الدعم عن المحروقات؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_mod2',
      category: 'POLICY',
      viewCount: 97,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_3',
      title: `نقاش: السياسة الضريبية الجديدة وتأثيرها على المستثمرين`,
      content: `نقاش: السياسة الضريبية الجديدة وتأثيرها على المستثمرين

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_mod3',
      category: 'POLICY',
      viewCount: 144,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_4',
      title: `كيف يمكن تحسين بيئة الأعمال في العراق؟`,
      content: `كيف يمكن تحسين بيئة الأعمال في العراق؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_ahmad',
      category: 'POLICY',
      viewCount: 191,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_5',
      title: `رأيكم في مشروع قانون الشركات الجديد؟`,
      content: `رأيكم في مشروع قانون الشركات الجديد؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_sara',
      category: 'POLICY',
      viewCount: 238,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_6',
      title: `هل نجحت سياسة البنك المركزي في خفض التضخم؟`,
      content: `هل نجحت سياسة البنك المركزي في خفض التضخم؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_omar',
      category: 'POLICY',
      viewCount: 285,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_7',
      title: `هل حان وقت الاستثمار في بورصة بغداد؟`,
      content: `هل حان وقت الاستثمار في بورصة بغداد؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_fatima',
      category: 'MARKET',
      viewCount: 332,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_8',
      title: `توقعات أسعار النفط للنصف الثاني من 2025`,
      content: `توقعات أسعار النفط للنصف الثاني من 2025

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_ali',
      category: 'MARKET',
      viewCount: 379,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_9',
      title: `السوق العقاري في بغداد: فقاعة أم نمو حقيقي؟`,
      content: `السوق العقاري في بغداد: فقاعة أم نمو حقيقي؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_zainab',
      category: 'MARKET',
      viewCount: 426,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_10',
      title: `أفضل القطاعات للاستثمار في العراق حالياً`,
      content: `أفضل القطاعات للاستثمار في العراق حالياً

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_expert7',
      category: 'MARKET',
      viewCount: 473,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_11',
      title: `تأثير أسعار الفائدة على سوق الأسهم العراقي`,
      content: `تأثير أسعار الفائدة على سوق الأسهم العراقي

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_expert8',
      category: 'MARKET',
      viewCount: 520,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_12',
      title: `الذهب مقابل الدولار: أين يفضل العراقيون الاستثمار؟`,
      content: `الذهب مقابل الدولار: أين يفضل العراقيون الاستثمار؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_expert9',
      category: 'MARKET',
      viewCount: 567,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_13',
      title: `فرص الاستثمار في قطاع الطاقة المتجددة في العراق`,
      content: `فرص الاستثمار في قطاع الطاقة المتجددة في العراق

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_expert10',
      category: 'INVESTMENT',
      viewCount: 614,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_14',
      title: `هل الاستثمار في العقارات لا يزال مربحاً؟`,
      content: `هل الاستثمار في العقارات لا يزال مربحاً؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_mustafa',
      category: 'INVESTMENT',
      viewCount: 661,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_15',
      title: `تجارب ناجحة في ريادة الأعمال في العراق`,
      content: `تجارب ناجحة في ريادة الأعمال في العراق

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_huda',
      category: 'INVESTMENT',
      viewCount: 708,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_16',
      title: `الاستثمار في التقنية المالية: فرص ومخاطر`,
      content: `الاستثمار في التقنية المالية: فرص ومخاطر

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member3',
      category: 'INVESTMENT',
      viewCount: 755,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_17',
      title: `كيف تبدأ مشروعك الخاص في العراق؟`,
      content: `كيف تبدأ مشروعك الخاص في العراق؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member4',
      category: 'INVESTMENT',
      viewCount: 802,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_18',
      title: `أفضل برامج التمويل للمشاريع الصغيرة`,
      content: `أفضل برامج التمويل للمشاريع الصغيرة

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member5',
      category: 'INVESTMENT',
      viewCount: 849,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_19',
      title: `التبادل التجاري مع إيران: المنافع والمخاطر`,
      content: `التبادل التجاري مع إيران: المنافع والمخاطر

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member6',
      category: 'TRADE',
      viewCount: 96,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_20',
      title: `فرص التصدير للمنتجات العراقية`,
      content: `فرص التصدير للمنتجات العراقية

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member7',
      category: 'TRADE',
      viewCount: 143,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_21',
      title: `تأثير الرسوم الجمركية على التجارة الداخلية`,
      content: `تأثير الرسوم الجمركية على التجارة الداخلية

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member8',
      category: 'TRADE',
      viewCount: 190,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_22',
      title: `التجارة الإلكترونية: مستقبل التجارة في العراق`,
      content: `التجارة الإلكترونية: مستقبل التجارة في العراق

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member9',
      category: 'TRADE',
      viewCount: 237,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_23',
      title: `اتفاقية التجارة الحرة مع الأردن: ما الفوائد؟`,
      content: `اتفاقية التجارة الحرة مع الأردن: ما الفوائد؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member10',
      category: 'TRADE',
      viewCount: 284,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_24',
      title: `واقع قطاع النقل اللوجستي وتأثيره على التجارة`,
      content: `واقع قطاع النقل اللوجستي وتأثيره على التجارة

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member11',
      category: 'TRADE',
      viewCount: 331,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_25',
      title: `كيف ننشر الثقافة الاقتصادية في المجتمع العراقي؟`,
      content: `كيف ننشر الثقافة الاقتصادية في المجتمع العراقي؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member12',
      category: 'GENERAL',
      viewCount: 378,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_26',
      title: `تجربتكم مع البنوك الرقمية في العراق`,
      content: `تجربتكم مع البنوك الرقمية في العراق

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member13',
      category: 'GENERAL',
      viewCount: 425,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_27',
      title: `نصائح مالية للشباب العراقي`,
      content: `نصائح مالية للشباب العراقي

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_member14',
      category: 'GENERAL',
      viewCount: 472,
      replyCount: 12,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_28',
      title: `كيف تدير ميزانيتك الشهرية بفعالية؟`,
      content: `كيف تدير ميزانيتك الشهرية بفعالية؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_owner',
      category: 'GENERAL',
      viewCount: 519,
      replyCount: 17,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_29',
      title: `أفضل الكتب والمصادر لتعلم الاقتصاد`,
      content: `أفضل الكتب والمصادر لتعلم الاقتصاد

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_admin',
      category: 'GENERAL',
      viewCount: 566,
      replyCount: 2,
      isPinned: false,
      isLocked: false,
    },
    {
      id: 'disc_30',
      title: `المدخرات والاستثمار: كيف تبدأ؟`,
      content: `المدخرات والاستثمار: كيف تبدأ؟

أود فتح نقاش حول هذا الموضوع المهم لسماع آراء الخبراء والمهتمين. ما هي تجاربكم وتوصياتكم في هذا الشأن؟ أعتقد أن هذا الموضوع يستحق نقاشاً معمقاً لما له من تأثير على الاقتصاد العراقي.`,
      authorId: 'user_admin2',
      category: 'GENERAL',
      viewCount: 613,
      replyCount: 7,
      isPinned: false,
      isLocked: false,
    },
  ]
  for (const d of discussionsData) { await prisma.discussion.create({ data: d }) }
  console.log('  ✓ 30 discussions created')

  // ===== COMMENTS (120) =====
  let cmtIdx = 0
  for (let artIdx = 0; artIdx < 120; artIdx++) {
    const numComments = artIdx < 12 ? 2 : 1
    for (let j = 0; j < numComments; j++) {
      cmtIdx++
      if (cmtIdx > 120) break
      await prisma.comment.create({ data: {
        id: `cmt_${cmtIdx}`,
        content: commentContents[(artIdx + j) % commentContents.length],
        articleId: `art_${artIdx + 1}`,
        authorId: allUserIds[cmtIdx % allUserIds.length],
        likeCount: Math.floor(Math.random() * 20),
      }})
    }
  }
  console.log('  ✓ Comments created')

  // ===== DISCUSSION REPLIES (60+) =====
  const replyContents = ["أتفق معك تماماً في هذا الرأي. الواقع يؤكد ما تقوله.", "شكراً على إثارة هذا الموضوع المهم. لدي إضافة حول هذا الشأن.", "تجربتي في هذا المجال تختلف قليلاً عما ذكرت.", "هل يمكنك توضيح هذه النقطة أكثر؟ أعتقد أن هناك جوانب أخرى.", "البيانات المتاحة تدعم ما ذهبت إليه. شكراً للإضافة.", "أعتقد أن الحل يكمن في التطبيق وليس في التخطيط فقط."]
  for (let discIdx = 0; discIdx < 30; discIdx++) {
    const numReplies = 2
    for (let j = 0; j < numReplies; j++) {
      await prisma.discussionReply.create({ data: {
        content: replyContents[(discIdx + j) % replyContents.length],
        discussionId: `disc_${discIdx + 1}`,
        authorId: allUserIds[(discIdx + j + 3) % allUserIds.length],
        likeCount: Math.floor(Math.random() * 15),
      }})
    }
  }
  console.log('  ✓ Discussion replies created')

  // ===== JOBS (20) =====
  const jobsData = [
    {
      id: 'job_1',
      title: 'محلل مالي أول',
      company: 'بنك الرافدين',
      location: 'بغداد',
      type: 'full-time',
      salary: '3,000,000 - 4,500,000 د.ع',
      description: 'نبحث عن محلل مالي أول للعمل في بنك الرافدين. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مالية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-01-15T00:00:00.000Z'),
    },
    {
      id: 'job_2',
      title: 'محاسب قانوني',
      company: 'شركة التدقيق الموحد',
      location: 'بغداد',
      type: 'full-time',
      salary: '2,500,000 - 3,500,000 د.ع',
      description: 'نبحث عن محاسب قانوني للعمل في شركة التدقيق الموحد. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مالية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-02-15T00:00:00.000Z'),
    },
    {
      id: 'job_3',
      title: 'مدير محفظة استثمارية',
      company: 'مجموعة الرشيد للاستثمار',
      location: 'بغداد',
      type: 'full-time',
      salary: '5,000,000 - 7,000,000 د.ع',
      description: 'نبحث عن مدير محفظة استثمارية للعمل في مجموعة الرشيد للاستثمار. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مالية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-03-15T00:00:00.000Z'),
    },
    {
      id: 'job_4',
      title: 'محلل مخاطر ائتمانية',
      company: 'بنك التجاري العراقي',
      location: 'بغداد',
      type: 'full-time',
      salary: '2,800,000 - 3,800,000 د.ع',
      description: 'نبحث عن محلل مخاطر ائتمانية للعمل في بنك التجاري العراقي. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مالية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-04-15T00:00:00.000Z'),
    },
    {
      id: 'job_5',
      title: 'مهندس بترول',
      company: 'شركة نفط الجنوب',
      location: 'البصرة',
      type: 'full-time',
      salary: '4,000,000 - 6,000,000 د.ع',
      description: 'نبحث عن مهندس بترول للعمل في شركة نفط الجنوب. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'نفط',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-05-15T00:00:00.000Z'),
    },
    {
      id: 'job_6',
      title: 'مشرف عمليات نفطية',
      company: 'شركة نفط الشمال',
      location: 'كركوك',
      type: 'full-time',
      salary: '3,500,000 - 5,000,000 د.ع',
      description: 'نبحث عن مشرف عمليات نفطية للعمل في شركة نفط الشمال. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'نفط',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-06-15T00:00:00.000Z'),
    },
    {
      id: 'job_7',
      title: 'محلل أسواق طاقة',
      company: 'وزارة النفط',
      location: 'بغداد',
      type: 'full-time',
      salary: '3,200,000 - 4,500,000 د.ع',
      description: 'نبحث عن محلل أسواق طاقة للعمل في وزارة النفط. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'نفط',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-01-15T00:00:00.000Z'),
    },
    {
      id: 'job_8',
      title: 'مهندس سلامة بيئية',
      company: 'شركة نفط ميسان',
      location: 'ميسان',
      type: 'full-time',
      salary: '3,000,000 - 4,200,000 د.ع',
      description: 'نبحث عن مهندس سلامة بيئية للعمل في شركة نفط ميسان. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'نفط',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-02-15T00:00:00.000Z'),
    },
    {
      id: 'job_9',
      title: 'مدير فرع بنكي',
      company: 'بنك العراق التجاري',
      location: 'بغداد',
      type: 'full-time',
      salary: '4,500,000 - 6,500,000 د.ع',
      description: 'نبحث عن مدير فرع بنكي للعمل في بنك العراق التجاري. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مصرفية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-03-15T00:00:00.000Z'),
    },
    {
      id: 'job_10',
      title: 'مطور أنظمة مصرفية',
      company: 'بنك الرافدين',
      location: 'بغداد',
      type: 'full-time',
      salary: '3,500,000 - 5,000,000 د.ع',
      description: 'نبحث عن مطور أنظمة مصرفية للعمل في بنك الرافدين. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مصرفية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-04-15T00:00:00.000Z'),
    },
    {
      id: 'job_11',
      title: 'مسؤول امتثال مصرفي',
      company: 'البنك العراقي التجاري',
      location: 'بغداد',
      type: 'full-time',
      salary: '3,000,000 - 4,500,000 د.ع',
      description: 'نبحث عن مسؤول امتثال مصرفي للعمل في البنك العراقي التجاري. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مصرفية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-05-15T00:00:00.000Z'),
    },
    {
      id: 'job_12',
      title: 'محلل مالي مصرفي',
      company: 'بنك الشرق الأوسط العراقي',
      location: 'أربيل',
      type: 'full-time',
      salary: '2,500,000 - 3,500,000 د.ع',
      description: 'نبحث عن محلل مالي مصرفي للعمل في بنك الشرق الأوسط العراقي. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'مصرفية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-06-15T00:00:00.000Z'),
    },
    {
      id: 'job_13',
      title: 'مطور تطبيقات مالية',
      company: 'فينتك العراق',
      location: 'أربيل',
      type: 'full-time',
      salary: '3,800,000 - 5,500,000 د.ع',
      description: 'نبحث عن مطور تطبيقات مالية للعمل في فينتك العراق. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'رقمية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-01-15T00:00:00.000Z'),
    },
    {
      id: 'job_14',
      title: 'مصمم واجهات مستخدم',
      company: 'شركة ديجيتال العراق',
      location: 'بغداد',
      type: 'part-time',
      salary: '2,000,000 - 3,000,000 د.ع',
      description: 'نبحث عن مصمم واجهات مستخدم للعمل في شركة ديجيتال العراق. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'رقمية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-02-15T00:00:00.000Z'),
    },
    {
      id: 'job_15',
      title: 'محلل بيانات مالية',
      company: 'شركة البيانات الذكية',
      location: 'بغداد',
      type: 'full-time',
      salary: '3,200,000 - 4,800,000 د.ع',
      description: 'نبحث عن محلل بيانات مالية للعمل في شركة البيانات الذكية. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'رقمية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-03-15T00:00:00.000Z'),
    },
    {
      id: 'job_16',
      title: 'مدير تسويق رقمي',
      company: 'متجر عراق أونلاين',
      location: 'كربلاء',
      type: 'full-time',
      salary: '2,500,000 - 3,500,000 د.ع',
      description: 'نبحث عن مدير تسويق رقمي للعمل في متجر عراق أونلاين. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'رقمية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-04-15T00:00:00.000Z'),
    },
    {
      id: 'job_17',
      title: 'مستشار استثماري',
      company: 'شركة الاستثمار الوطنية',
      location: 'بغداد',
      type: 'full-time',
      salary: '4,000,000 - 6,000,000 د.ع',
      description: 'نبحث عن مستشار استثماري للعمل في شركة الاستثمار الوطنية. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'استثمارية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-05-15T00:00:00.000Z'),
    },
    {
      id: 'job_18',
      title: 'محلل سوق أوراق مالية',
      company: 'بورصة بغداد',
      location: 'بغداد',
      type: 'full-time',
      salary: '3,000,000 - 4,500,000 د.ع',
      description: 'نبحث عن محلل سوق أوراق مالية للعمل في بورصة بغداد. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'استثمارية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-06-15T00:00:00.000Z'),
    },
    {
      id: 'job_19',
      title: 'مدير صندوق استثماري',
      company: 'شركة الأوراق المالية',
      location: 'بغداد',
      type: 'full-time',
      salary: '5,000,000 - 8,000,000 د.ع',
      description: 'نبحث عن مدير صندوق استثماري للعمل في شركة الأوراق المالية. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'استثمارية',
      publishedBy: 'user_owner',
      expiresAt: new Date('2026-01-15T00:00:00.000Z'),
    },
    {
      id: 'job_20',
      title: 'خبير تقييم مشاريع',
      company: 'صندوق التنمية الدولي',
      location: 'بغداد',
      type: 'contract',
      salary: '4,500,000 - 6,500,000 د.ع',
      description: 'نبحث عن خبير تقييم مشاريع للعمل في صندوق التنمية الدولي. يتطلب هذا المنصب خبرة عملية لا تقل عن 3 سنوات في المجال ذي الصلة، مع إجادة اللغة العربية والإنجليزية. يقدم العمل بيئة عمل محفزة وفرص تطوير مهني مستمرة.',
      requirements: 'خبرة عملية لا تقل عن 3 سنوات، شهادة جامعية في التخصص ذي الصلة، مهارات تحليلية وتواصلية ممتازة',
      category: 'استثمارية',
      publishedBy: 'user_admin',
      expiresAt: new Date('2026-02-15T00:00:00.000Z'),
    },
  ]
  for (const j of jobsData) { await prisma.job.create({ data: j }) }
  console.log('  ✓ 20 jobs created')

  // ===== LIKES (250+) =====
  let likeCount = 0
  for (let artIdx = 0; artIdx < 120; artIdx++) {
    const numLikes = Math.floor(Math.random() * 3) + 1
    for (let j = 0; j < numLikes; j++) {
      try {
        await prisma.like.create({ data: {
          userId: allUserIds[(artIdx * 3 + j + 5) % allUserIds.length],
          articleId: `art_${artIdx + 1}`,
          type: j === 0 ? 'LIKE' : (Math.random() > 0.5 ? 'LIKE' : 'BOOKMARK'),
        }})
        likeCount++
      } catch(e) {}
    }
  }
  console.log(`  ✓ ${likeCount} likes created`)

  // ===== FOLLOWS (50+) =====
  let followCount = 0
  const expertIds = ["user_ahmad", "user_sara", "user_omar", "user_fatima", "user_ali", "user_zainab", "user_expert7", "user_expert8", "user_expert9", "user_expert10"]
  const memberIds = ["user_mustafa", "user_huda", "user_member3", "user_member4", "user_member5", "user_member6", "user_member7", "user_member8", "user_member9", "user_member10", "user_member11", "user_member12", "user_member13", "user_member14"]
  for (const expertId of expertIds) {
    for (let j = 0; j < 5; j++) {
      try {
        await prisma.follow.create({ data: {
          followerId: memberIds[j % memberIds.length],
          followingId: expertId,
        }})
        followCount++
      } catch(e) {}
    }
  }
  console.log(`  ✓ ${followCount} follows created`)

  // ===== ECONOMIC TERMS (30) =====
  const termsData = [
    {
      termAr: 'التضخم',
      termEn: 'Inflation',
      definition: 'ارتفاع مستوى الأسعار العام للسلع والخدمات خلال فترة زمنية محددة، مما يؤدي إلى انخفاض القوة الشرائية للنقود',
      category: 'اقتصاد كلي',
      examples: 'مثال: إذا ارتفع معدل التضخم من 3% إلى 5%، فإن قيمة الـ 1000 دينار الشرائية تنخفض',
      relatedTerms: 'انكماش,ركود',
    },
    {
      termAr: 'الناتج المحلي الإجمالي',
      termEn: 'Gross Domestic Product (GDP)',
      definition: 'إجمالي قيمة جميع السلع والخدمات النهائية المنتجة داخل حدود الدولة خلال فترة زمنية معينة',
      category: 'اقتصاد كلي',
      examples: 'مثال: الناتج المحلي الإجمالي للعراق بلغ حوالي 260 مليار دولار في 2023',
      relatedTerms: 'دخل قومي,نمو اقتصادي',
    },
    {
      termAr: 'سعر الصرف',
      termEn: 'Exchange Rate',
      definition: 'قيمة عملة دولة ما مقومة بوحدة عملة دولة أخرى، ويحدد مقدار العملة الأجنبية التي يمكن الحصول عليها مقابل وحدة من العملة المحلية',
      category: 'مالية',
      examples: 'مثال: سعر صرف الدينار العراقي مقابل الدولار هو 1320 دينار لكل دولار',
      relatedTerms: 'تعويم,تثبيت',
    },
    {
      termAr: 'العرض والطلب',
      termEn: 'Supply and Demand',
      definition: 'القوى الأساسية التي تحدد الأسعار في السوق الحرة، حيث يحدد العرض كمية السلع المتاحة والطلب رغبة المستهلكين في الشراء',
      category: 'اقتصاد كلي',
      examples: 'مثال: ارتفاع الطلب على النفط مع ثبات العرض يؤدي إلى ارتفاع الأسعار',
      relatedTerms: 'توازن سوقي,فائض',
    },
    {
      termAr: 'الميزانية العامة',
      termEn: 'Government Budget',
      definition: 'بيان مالي شامل يوضح الإيرادات المتوقعة والنفقات المخططة للحكومة خلال فترة مالية محددة',
      category: 'مالية',
      examples: 'مثال: ميزانية العراق لعام 2024 بلغت 198 تريليون دينار',
      relatedTerms: 'عجز مالي,فائض مالي',
    },
    {
      termAr: 'السياسة النقدية',
      termEn: 'Monetary Policy',
      definition: 'مجموعة الإجراءات التي يتخذها البنك المركزي للتأثير على عرض النقد وأسعار الفائدة لتحقيق أهداف اقتصادية',
      category: 'مالية',
      examples: 'مثال: رفع البنك المركزي أسعار الفائدة لمكافحة التضخم',
      relatedTerms: 'سياسة مالية,تيسير كمي',
    },
    {
      termAr: 'الاستثمار الأجنبي المباشر',
      termEn: 'Foreign Direct Investment (FDI)',
      definition: 'استثمار تقوم به شركة أو فرد من دولة في أصول أو مشروعات في دولة أخرى بهدف الإدارة والتحكم',
      category: 'استثمار',
      examples: 'مثال: استثمار شركة ألمانية في بناء محطة طاقة شمسية في العراق',
      relatedTerms: 'محفظة استثمارية,تدفقات رأسمالية',
    },
    {
      termAr: 'المنافسة الحرة',
      termEn: 'Free Competition',
      definition: 'حالة السوق التي يتنافس فيها البائعون بحرية على جذب المشترين دون قيود أو احتكار',
      category: 'تجارة',
      examples: 'مثال: فتح السوق العراقي أمام شركات الاتصالات الأجنبية يعزز المنافسة',
      relatedTerms: 'احتكار,كارتل',
    },
    {
      termAr: 'الاحتياطي النقدي',
      termEn: 'Foreign Exchange Reserves',
      definition: 'الأصول بالعملات الأجنبية والذهب التي تحتفظ بها الدولة لدعم عملتها والوفاء بالالتزامات الدولية',
      category: 'مالية',
      examples: 'مثال: احتياطي العراق النقدي بلغ حوالي 65 مليار دولار',
      relatedTerms: 'احتياطي ذهب,سيولة دولية',
    },
    {
      termAr: 'الركود الاقتصادي',
      termEn: 'Economic Recession',
      definition: 'انخفاض النشاط الاقتصادي يستمر لفترتين ربعيتين متتاليتين على الأقل، يرافقه ارتفاع في البطالة وانخفاض الإنتاج',
      category: 'اقتصاد كلي',
      examples: 'مثال: الركود العالمي عام 2020 بسبب جائحة كورونا',
      relatedTerms: 'انكماش,كساد',
    },
    {
      termAr: 'الفائدة البسيطة',
      termEn: 'Simple Interest',
      definition: 'النسبة المئوية التي تُحسب على المبلغ الأصلي فقط دون احتساب الفائدة المركبة',
      category: 'مصرفية',
      examples: 'مثال: فائدة 5% على قرض 1,000,000 دينار = 50,000 دينار سنوياً',
      relatedTerms: 'فائدة مركبة,سعر الفائدة',
    },
    {
      termAr: 'الائتمان',
      termEn: 'Credit',
      definition: 'اتفاقية يقدم بموجبها المقرض مالاً أو سلعة للمقترض على أن يسدده لاحقاً مع الفائدة',
      category: 'مصرفية',
      examples: 'مثال: القروض السكنية التي تقدمها المصارف العراقية',
      relatedTerms: 'قرض,تسليف',
    },
    {
      termAr: 'التهرب الضريبي',
      termEn: 'Tax Evasion',
      definition: 'الامتناع غير القانوني عن دفع الضرائب المستحقة من خلال إخفاء الدخل أو التلاعب في البيانات المالية',
      category: 'مالية',
      examples: 'مثال: عدم الإفصاح عن جميع مصادر الدخل في الإقرار الضريبي',
      relatedTerms: 'تجنب ضريبي,امتثال ضريبي',
    },
    {
      termAr: 'التجارة الحرة',
      termEn: 'Free Trade',
      definition: 'سياسة تجارية تسمح بتدفق السلع والخدمات بين الدول دون قيود جمركية أو حواجز تجارية',
      category: 'تجارة',
      examples: 'مثال: اتفاقية التجارة الحرة بين العراق والأردن',
      relatedTerms: 'حماية تجارية,رسوم جمركية',
    },
    {
      termAr: 'ميزان المدفوعات',
      termEn: 'Balance of Payments',
      definition: 'سجل محاسبي شامل لجميع المعاملات الاقتصادية بين مقيمي الدولة وباقي العالم خلال فترة زمنية محددة',
      category: 'اقتصاد كلي',
      examples: 'مثال: فائض ميزان المدفوعات العراقي بفضل صادرات النفط',
      relatedTerms: 'حساب جاري,حساب رأسمالي',
    },
    {
      termAr: 'الخصخصة',
      termEn: 'Privatization',
      definition: 'عملية نقل ملكية أو إدارة المؤسسات والمرافق العامة إلى القطاع الخاص',
      category: 'اقتصاد كلي',
      examples: 'مثال: خصخصة شركات الاتصالات في العراق',
      relatedTerms: 'تأميم,قطاع عام',
    },
    {
      termAr: 'الدين العام',
      termEn: 'Public Debt',
      definition: 'إجمالي المبالغ التي تقترضها الحكومة من الجهات الداخلية والخارجية لتمويل عجز الميزانية',
      category: 'مالية',
      examples: 'مثال: الدين الخارجي للعراق بلغ حوالي 30 مليار دولار',
      relatedTerms: 'دين خارجي,دين محلي',
    },
    {
      termAr: 'الشمول المالي',
      termEn: 'Financial Inclusion',
      definition: 'توفير فرص الوصول إلى الخدمات المالية الأساسية لجميع فئات المجتمع بتكلفة معقولة وطرق مناسبة',
      category: 'مصرفية',
      examples: 'مثال: مبادرة البنك المركزي لزيادة نسبة المشمولين مالياً إلى 50%',
      relatedTerms: 'محفظة رقمية,مصرفية إلكترونية',
    },
    {
      termAr: 'التنويع الاقتصادي',
      termEn: 'Economic Diversification',
      definition: 'استراتيجية تهدف إلى تقليل الاعتماد على قطاع واحد وتطوير قطاعات اقتصادية متعددة',
      category: 'اقتصاد كلي',
      examples: 'مثال: خطط العراق للتنويع بعيداً عن النفط',
      relatedTerms: 'اقتصاد ريعي,تنمية مستدامة',
    },
    {
      termAr: 'السوق الموازية',
      termEn: 'Parallel Market',
      definition: 'سوق غير رسمية تتداول فيها العملات الأجنبية بأسعار تختلف عن السعر الرسمي المحدد من البنك المركزي',
      category: 'مالية',
      examples: 'مثال: الفجوة بين سعر الدولار الرسمي وسعر السوق الموازية في العراق',
      relatedTerms: 'سوق سوداء,سعر رسمي',
    },
    {
      termAr: 'حقوق السحب الخاصة',
      termEn: 'Special Drawing Rights (SDR)',
      definition: 'أداة احتياطي دولية أنشأها صندوق النقد الدولي لتعزيز السيولة العالمية',
      category: 'مالية',
      examples: 'مثال: تخصيص حقوق سحب خاصة للعراق من صندوق النقد الدولي',
      relatedTerms: 'صندوق النقد,احتياطي دولي',
    },
    {
      termAr: 'الكفاءة الحدية',
      termEn: 'Marginal Efficiency',
      definition: 'معدل العائد المتوقع من استثمار إضافي في أصل رأسمالي، وهي مفهوم أساسي في نظرية الاستثمار',
      category: 'استثمار',
      examples: 'مثال: حساب العائد المتوقع من استثمار إضافي في مشروع صناعي',
      relatedTerms: 'تكلفة حدية,عائد على الاستثمار',
    },
    {
      termAr: 'المنظومة المصرفية',
      termEn: 'Banking System',
      definition: 'مجموعة المؤسسات والقواعد والآليات التي تنظم عمليات الإقراض والاقتراض والوساطة المالية في الاقتصاد',
      category: 'مصرفية',
      examples: 'مثال: المنظومة المصرفية العراقية تضم أكثر من 70 مصرفاً',
      relatedTerms: 'بنك مركزي,مصارف تجارية',
    },
    {
      termAr: 'التمويل الأصغر',
      termEn: 'Microfinance',
      definition: 'تقديم خدمات مالية صغيرة مثل القروض والتأمين للفئات ذات الدخل المحدود التي لا تستفيد من المصارف التقليدية',
      category: 'مصرفية',
      examples: 'مثال: برامج التمويل الأصغر للسيدات الريفيات في العراق',
      relatedTerms: 'قرض صغير,تمويل مجتمعي',
    },
    {
      termAr: 'صندوق الثروة السيادية',
      termEn: 'Sovereign Wealth Fund',
      definition: 'صندوق استثماري تملكه الدولة ويدير أصولاً مالية بهدف تحقيق عوائد طويلة الأمد للأجيال القادمة',
      category: 'استثمار',
      examples: 'مثال: مقترح إنشاء صندوق ثروة سيادية عراقي من عائدات النفط',
      relatedTerms: 'ادخار وطني,استثمار حكومي',
    },
    {
      termAr: 'التجارة البينية',
      termEn: 'Intra-trade',
      definition: 'التبادل التجاري بين دول المنطقة أو التكتل الاقتصادي الواحد',
      category: 'تجارة',
      examples: 'مثال: التجارة البينية بين العراق وتركيا وإيران',
      relatedTerms: 'تكامل إقليمي,اتفاقيات تجارية',
    },
    {
      termAr: 'الاقتصاد الدائري',
      termEn: 'Circular Economy',
      definition: 'نموذج اقتصادي يهدف إلى تقليل الهدر وزيادة إعادة استخدام الموارد من خلال التدوير والتجديد',
      category: 'اقتصاد كلي',
      examples: 'مثال: تدوير النفايات الصناعية في البصرة لتحويلها إلى منتجات جديدة',
      relatedTerms: 'استدامة,اقتصاد أخضر',
    },
    {
      termAr: 'التكلفة الضريبية',
      termEn: 'Tax Burden',
      definition: 'إجمالي الضرائب المفروضة على الأفراد والشركات كنسبة من الدخل أو الناتج المحلي الإجمالي',
      category: 'مالية',
      examples: 'مثال: التكلفة الضريبية في العراق أقل من المتوسط العالمي',
      relatedTerms: 'ضريبة دخل,ضريبة القيمة المضافة',
    },
    {
      termAr: 'العجز التجاري',
      termEn: 'Trade Deficit',
      definition: 'حالة تتجاوز فيها واردات الدولة صادراتها خلال فترة زمنية محددة',
      category: 'تجارة',
      examples: 'مثال: العجز التجاري العراقي في السلع غير النفطية',
      relatedTerms: 'فائض تجاري,ميزان تجاري',
    },
    {
      termAr: 'العملة الرقمية',
      termEn: 'Digital Currency',
      definition: 'شكل من أشكال العملة المتوفرة فقط بصيغة رقمية وليس لها وجود مادي كالنقود الورقية',
      category: 'رقمية',
      examples: 'مثال: مشروع الدينار الرقمي العراقي',
      relatedTerms: 'عملة مشفرة,بلوك تشين',
    },
  ]
  for (const t of termsData) { await prisma.economicTerm.create({ data: t }) }
  console.log('  ✓ 30 economic terms created')

  // ===== HASHTAGS (30) + ARTICLE TAGS =====
  const hashtagsData = ["اقتصاد_عراقي", "نفط_وطاقة", "دينار_عراقي", "بورصة_بغداد", "استثمار_في_العراق", "تنمية_مستدامة", "إصلاح_اقتصادي", "قطاع_خاص", "مصارف_عراقية", "تجارة_دولية", "تقنية_مالية", "بنك_مركزي", "ميزانية_العراق", "بطالة_الشباب", "أمن_غذائي", "زراعة_عراقية", "سياحة_دينية", "بنية_تحتية", "تعليم_اقتصادي", "شمول_مالي", "إعادة_إعمار", "تحول_رقمي", "طاقة_متجددة", "صادرات_غير_نفطية", "سعر_الصرف", "سياسة_نقدية", "فينتك_العراق", "ريادة_أعمال", "اقتصاد_أخضر", "تجارة_إلكترونية"]
  for (let i = 0; i < hashtagsData.length; i++) {
    const tag = hashtagsData[i]
    const hashtag = await prisma.hashtag.create({ data: { tag, usageCount: Math.floor(Math.random() * 20) + 5 } })
    // Link to articles
    for (let a = 0; a < 4; a++) {
      const artIdx = (i * 4 + a) % 120
      try {
        await prisma.articleTag.create({ data: { articleId: `art_${artIdx + 1}`, hashtagId: hashtag.id } })
      } catch(e) {}
    }
  }
  console.log('  ✓ 30 hashtags created with article links')

  // ===== LEARNING PATHS (5) + LESSONS (45) =====
  const pathsData = [
    {
      id: 'path_1',
      title: 'أساسيات الاقتصاد',
      description: 'مسار تعليمي شامل يقدم المفاهيم الأساسية في علم الاقتصاد، بدءاً من العرض والطلب وصولاً إلى السياسات الاقتصادية الكلية والجزئية.',
      category: 'أساسيات الاقتصاد',
      difficulty: 'BEGINNER',
      icon: '📚',
      lessonsCount: 9,
      duration: 135,
      enrolledCount: 56,
    },
    {
      id: 'path_2',
      title: 'الأسواق المالية',
      description: 'مسار متخصص في فهم الأسواق المالية وأنواع الأوراق المالية وآليات التداول والتحليل المالي.',
      category: 'الأسواق المالية',
      difficulty: 'INTERMEDIATE',
      icon: '📈',
      lessonsCount: 9,
      duration: 135,
      enrolledCount: 234,
    },
    {
      id: 'path_3',
      title: 'الاقتصاد العراقي',
      description: 'مسار يركز على خصوصيات الاقتصاد العراقي وتاريخه وتحدياته الحالية وفرص الإصلاح والتنويع.',
      category: 'الاقتصاد العراقي',
      difficulty: 'INTERMEDIATE',
      icon: '🇮🇶',
      lessonsCount: 9,
      duration: 135,
      enrolledCount: 225,
    },
    {
      id: 'path_4',
      title: 'التقنية المالية',
      description: 'مسار تعليمي حول التقنية المالية والتحول الرقمي في القطاع المالي والمصرفي وتطبيقاته في العراق.',
      category: 'التقنية المالية',
      difficulty: 'ADVANCED',
      icon: '💳',
      lessonsCount: 9,
      duration: 135,
      enrolledCount: 217,
    },
    {
      id: 'path_5',
      title: 'التجارة الدولية',
      description: 'مسار شامل حول مبادئ التجارة الدولية والاتفاقيات التجارية وتأثيرها على الاقتصاد العراقي.',
      category: 'التجارة الدولية',
      difficulty: 'INTERMEDIATE',
      icon: '🌍',
      lessonsCount: 9,
      duration: 135,
      enrolledCount: 195,
    },
  ]
  for (const p of pathsData) { await prisma.learningPath.create({ data: p }) }
  const allLessons = [
    {
      pathId: 'path_1',
      title: 'مقدمة في علم الاقتصاد',
      content: 'محتوى درس: مقدمة في علم الاقتصاد. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 1,
      duration: 10,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_1',
      title: 'العرض والطلب: القوى المحركة للسوق',
      content: 'محتوى درس: العرض والطلب: القوى المحركة للسوق. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 2,
      duration: 12,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_1',
      title: 'النظم الاقتصادية: الرأسمالية والاشتراكية والمختلطة',
      content: 'محتوى درس: النظم الاقتصادية: الرأسمالية والاشتراكية والمختلطة. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 3,
      duration: 14,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_1',
      title: 'مفهوم التضخم وأسبابه',
      content: 'محتوى درس: مفهوم التضخم وأسبابه. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 4,
      duration: 16,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_1',
      title: 'البطالة: أنواعها وآثارها الاقتصادية',
      content: 'محتوى درس: البطالة: أنواعها وآثارها الاقتصادية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 5,
      duration: 18,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_1',
      title: 'الناتج المحلي الإجمالي ومقاييس النمو',
      content: 'محتوى درس: الناتج المحلي الإجمالي ومقاييس النمو. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 6,
      duration: 20,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_1',
      title: 'السياسة المالية ودور الحكومة',
      content: 'محتوى درس: السياسة المالية ودور الحكومة. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 7,
      duration: 22,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_1',
      title: 'السياسة النقدية ودور البنك المركزي',
      content: 'محتوى درس: السياسة النقدية ودور البنك المركزي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 8,
      duration: 24,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_1',
      title: 'التجارة الدولية وميزان المدفوعات',
      content: 'محتوى درس: التجارة الدولية وميزان المدفوعات. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 9,
      duration: 26,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_2',
      title: 'مقدمة في الأسواق المالية',
      content: 'محتوى درس: مقدمة في الأسواق المالية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 1,
      duration: 10,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_2',
      title: 'بورصة بغداد: نشأتها وتطورها',
      content: 'محتوى درس: بورصة بغداد: نشأتها وتطورها. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 2,
      duration: 12,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_2',
      title: 'أنواع الأوراق المالية',
      content: 'محتوى درس: أنواع الأوراق المالية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 3,
      duration: 14,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_2',
      title: 'آليات التداول والتصفية',
      content: 'محتوى درس: آليات التداول والتصفية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 4,
      duration: 16,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_2',
      title: 'التحليل الأساسي للأسهم',
      content: 'محتوى درس: التحليل الأساسي للأسهم. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 5,
      duration: 18,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_2',
      title: 'التحليل الفني: قراءة الرسوم البيانية',
      content: 'محتوى درس: التحليل الفني: قراءة الرسوم البيانية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 6,
      duration: 20,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_2',
      title: 'إدارة المحفظة الاستثمارية',
      content: 'محتوى درس: إدارة المحفظة الاستثمارية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 7,
      duration: 22,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_2',
      title: 'مخاطر الاستثمار وإدارتها',
      content: 'محتوى درس: مخاطر الاستثمار وإدارتها. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 8,
      duration: 24,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_2',
      title: 'التنظيم والرقابة في الأسواق المالية',
      content: 'محتوى درس: التنظيم والرقابة في الأسواق المالية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 9,
      duration: 26,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_3',
      title: 'نظرة تاريخية على الاقتصاد العراقي',
      content: 'محتوى درس: نظرة تاريخية على الاقتصاد العراقي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 1,
      duration: 10,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_3',
      title: 'الاقتصاد الريعي والاعتماد على النفط',
      content: 'محتوى درس: الاقتصاد الريعي والاعتماد على النفط. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 2,
      duration: 12,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_3',
      title: 'سعر صرف الدينار العراقي',
      content: 'محتوى درس: سعر صرف الدينار العراقي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 3,
      duration: 14,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_3',
      title: 'الميزانية العامة وتهمة الإنفاق',
      content: 'محتوى درس: الميزانية العامة وتهمة الإنفاق. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 4,
      duration: 16,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_3',
      title: 'القطاع المصرفي العراقي',
      content: 'محتوى درس: القطاع المصرفي العراقي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 5,
      duration: 18,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_3',
      title: 'التحديات الهيكلية للاقتصاد العراقي',
      content: 'محتوى درس: التحديات الهيكلية للاقتصاد العراقي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 6,
      duration: 20,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_3',
      title: 'فرص التنويع الاقتصادي',
      content: 'محتوى درس: فرص التنويع الاقتصادي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 7,
      duration: 22,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_3',
      title: 'الاستثمار الأجنبي في العراق',
      content: 'محتوى درس: الاستثمار الأجنبي في العراق. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 8,
      duration: 24,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_3',
      title: 'آفاق الإصلاح الاقتصادي',
      content: 'محتوى درس: آفاق الإصلاح الاقتصادي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 9,
      duration: 26,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_4',
      title: 'مقدمة في التقنية المالية',
      content: 'محتوى درس: مقدمة في التقنية المالية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 1,
      duration: 10,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_4',
      title: 'المدفوعات الرقمية والمحافظ الإلكترونية',
      content: 'محتوى درس: المدفوعات الرقمية والمحافظ الإلكترونية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 2,
      duration: 12,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_4',
      title: 'التمويل الجماعي والتمويل الجماعي',
      content: 'محتوى درس: التمويل الجماعي والتمويل الجماعي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 3,
      duration: 14,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_4',
      title: 'البلوك تشين والعملات المشفرة',
      content: 'محتوى درس: البلوك تشين والعملات المشفرة. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 4,
      duration: 16,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_4',
      title: 'التأمين الرقمي',
      content: 'محتوى درس: التأمين الرقمي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 5,
      duration: 18,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_4',
      title: 'الذكاء الاصطناعي في الخدمات المالية',
      content: 'محتوى درس: الذكاء الاصطناعي في الخدمات المالية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 6,
      duration: 20,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_4',
      title: 'الأمن السيبراني في القطاع المالي',
      content: 'محتوى درس: الأمن السيبراني في القطاع المالي. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 7,
      duration: 22,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_4',
      title: 'التنظيم والامتثال في التقنية المالية',
      content: 'محتوى درس: التنظيم والامتثال في التقنية المالية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 8,
      duration: 24,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_4',
      title: 'مستقبل التقنية المالية في العراق',
      content: 'محتوى درس: مستقبل التقنية المالية في العراق. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 9,
      duration: 26,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_5',
      title: 'مبادئ التجارة الدولية',
      content: 'محتوى درس: مبادئ التجارة الدولية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 1,
      duration: 10,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_5',
      title: 'نظريات التجارة: من آدم سميث إلى اليوم',
      content: 'محتوى درس: نظريات التجارة: من آدم سميث إلى اليوم. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 2,
      duration: 12,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_5',
      title: 'الاتفاقيات التجارية الدولية',
      content: 'محتوى درس: الاتفاقيات التجارية الدولية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 3,
      duration: 14,
      type: 'TEXT',
      isFree: true,
    },
    {
      pathId: 'path_5',
      title: 'الرسوم الجمركية والحماية التجارية',
      content: 'محتوى درس: الرسوم الجمركية والحماية التجارية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 4,
      duration: 16,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_5',
      title: 'منظمة التجارة العالمية ودورها',
      content: 'محتوى درس: منظمة التجارة العالمية ودورها. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 5,
      duration: 18,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_5',
      title: 'التجارة الإقليمية والاتفاقيات الثنائية',
      content: 'محتوى درس: التجارة الإقليمية والاتفاقيات الثنائية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 6,
      duration: 20,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_5',
      title: 'العلاقات التجارية العراقية الإقليمية',
      content: 'محتوى درس: العلاقات التجارية العراقية الإقليمية. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 7,
      duration: 22,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_5',
      title: 'التجارة الإلكترونية العابرة للحدود',
      content: 'محتوى درس: التجارة الإلكترونية العابرة للحدود. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 8,
      duration: 24,
      type: 'TEXT',
      isFree: false,
    },
    {
      pathId: 'path_5',
      title: 'مستقبل التجارة الدولية في الشرق الأوسط',
      content: 'محتوى درس: مستقبل التجارة الدولية في الشرق الأوسط. يتناول هذا الدرس المفاهيم الأساسية المتعلقة بالموضوع بالتفصيل مع أمثلة عملية من الواقع الاقتصادي العراقي والإقليمي.',
      order: 9,
      duration: 26,
      type: 'TEXT',
      isFree: false,
    },
  ]
  for (const l of allLessons) { await prisma.lesson.create({ data: l }) }
  console.log('  ✓ 5 learning paths with 45 lessons created')

  
  // ===== QUIZZES (3) with questions =====
  await prisma.quiz.create({
    data: {
      id: 'quiz_1',
      title: 'اختبار الاقتصاد العراقي',
      description: 'اختبر معرفتك بالاقتصاد العراقي وتاريخه وتحدياته الحالية',
      category: 'اقتصاد عراقي',
      difficulty: 'INTERMEDIATE',
      timeLimit: 20,
      questionsCount: 10,
      questions: {
        create: [
          {
            question: 'ما هي نسبة اعتماد العراق على النفط في إيراداته المالية؟',
            correctAnswer: 2,
            order: 1,
            explanation: 'الإجابة الصحيحة هي: أكثر من 70%',
            optionRecords: {
              create: [
                { text: 'أكثر من 50%', optionIndex: 0, isCorrect: false },
                { text: 'أكثر من 90%', optionIndex: 1, isCorrect: false },
                { text: 'أكثر من 70%', optionIndex: 2, isCorrect: true },
                { text: 'أكثر من 80%', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو سعر صرف الدينار العراقي الرسمي مقابل الدولار؟',
            correctAnswer: 1,
            order: 2,
            explanation: 'الإجابة الصحيحة هي: 1320 دينار',
            optionRecords: {
              create: [
                { text: '1150 دينار', optionIndex: 0, isCorrect: false },
                { text: '1320 دينار', optionIndex: 1, isCorrect: true },
                { text: '1500 دينار', optionIndex: 2, isCorrect: false },
                { text: '1200 دينار', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'متى تأسست بورصة العراق للأوراق المالية؟',
            correctAnswer: 0,
            order: 3,
            explanation: 'الإجابة الصحيحة هي: 2004',
            optionRecords: {
              create: [
                { text: '2004', optionIndex: 0, isCorrect: true },
                { text: '2010', optionIndex: 1, isCorrect: false },
                { text: '1995', optionIndex: 2, isCorrect: false },
                { text: '2015', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو أكبر شريك تجاري للعراق حالياً؟',
            correctAnswer: 2,
            order: 4,
            explanation: 'الإجابة الصحيحة هي: الصين',
            optionRecords: {
              create: [
                { text: 'الولايات المتحدة', optionIndex: 0, isCorrect: false },
                { text: 'تركيا', optionIndex: 1, isCorrect: false },
                { text: 'الصين', optionIndex: 2, isCorrect: true },
                { text: 'إيران', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'كم يبلغ احتياطي العراق من النقد الأجنبي تقريباً؟',
            correctAnswer: 1,
            order: 5,
            explanation: 'الإجابة الصحيحة هي: 65 مليار دولار',
            optionRecords: {
              create: [
                { text: '40 مليار دولار', optionIndex: 0, isCorrect: false },
                { text: '65 مليار دولار', optionIndex: 1, isCorrect: true },
                { text: '80 مليار دولار', optionIndex: 2, isCorrect: false },
                { text: '30 مليار دولار', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما نسبة مساهمة القطاع الزراعي في الناتج المحلي العراقي؟',
            correctAnswer: 0,
            order: 6,
            explanation: 'الإجابة الصحيحة هي: أقل من 5%',
            optionRecords: {
              create: [
                { text: 'أقل من 5%', optionIndex: 0, isCorrect: true },
                { text: '10%', optionIndex: 1, isCorrect: false },
                { text: '15%', optionIndex: 2, isCorrect: false },
                { text: '20%', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو حجم ميزانية العراق لعام 2024 تقريباً؟',
            correctAnswer: 1,
            order: 7,
            explanation: 'الإجابة الصحيحة هي: 198 تريليون دينار',
            optionRecords: {
              create: [
                { text: '100 تريليون دينار', optionIndex: 0, isCorrect: false },
                { text: '198 تريليون دينار', optionIndex: 1, isCorrect: true },
                { text: '250 تريليون دينار', optionIndex: 2, isCorrect: false },
                { text: '150 تريليون دينار', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي نسبة البطالة بين الشباب في العراق تقريباً؟',
            correctAnswer: 2,
            order: 8,
            explanation: 'الإجابة الصحيحة هي: 25%',
            optionRecords: {
              create: [
                { text: '10%', optionIndex: 0, isCorrect: false },
                { text: '15%', optionIndex: 1, isCorrect: false },
                { text: '25%', optionIndex: 2, isCorrect: true },
                { text: '35%', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'أين يقع مقر البنك المركزي العراقي؟',
            correctAnswer: 0,
            order: 9,
            explanation: 'الإجابة الصحيحة هي: بغداد',
            optionRecords: {
              create: [
                { text: 'بغداد', optionIndex: 0, isCorrect: true },
                { text: 'البصرة', optionIndex: 1, isCorrect: false },
                { text: 'أربيل', optionIndex: 2, isCorrect: false },
                { text: 'الموصل', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو إجمالي عدد المصارف المرخصة في العراق تقريباً؟',
            correctAnswer: 1,
            order: 10,
            explanation: 'الإجابة الصحيحة هي: أكثر من 70',
            optionRecords: {
              create: [
                { text: 'أقل من 30', optionIndex: 0, isCorrect: false },
                { text: 'أكثر من 70', optionIndex: 1, isCorrect: true },
                { text: '50', optionIndex: 2, isCorrect: false },
                { text: '100', optionIndex: 3, isCorrect: false },
              ]
            }
          },
        ]
      }
    }
  })
  await prisma.quiz.create({
    data: {
      id: 'quiz_2',
      title: 'اختبار النفط والطاقة',
      description: 'اختبر معرفتك بقطاع النفط والطاقة في العراق والمنطقة',
      category: 'نفط وطاقة',
      difficulty: 'ADVANCED',
      timeLimit: 25,
      questionsCount: 10,
      questions: {
        create: [
          {
            question: 'كم يحتل العراق من المرتبة عالمياً في احتياطي النفط المؤكد؟',
            correctAnswer: 0,
            order: 1,
            explanation: 'الإجابة الصحيحة هي: الثانية',
            optionRecords: {
              create: [
                { text: 'الثانية', optionIndex: 0, isCorrect: true },
                { text: 'الخامسة', optionIndex: 1, isCorrect: false },
                { text: 'الأولى', optionIndex: 2, isCorrect: false },
                { text: 'العاشرة', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي أكبر حقل نفطي في العراق؟',
            correctAnswer: 2,
            order: 2,
            explanation: 'الإجابة الصحيحة هي: حقل مجنون',
            optionRecords: {
              create: [
                { text: 'حقل الرميلة', optionIndex: 0, isCorrect: false },
                { text: 'حقل كركوك', optionIndex: 1, isCorrect: false },
                { text: 'حقل مجنون', optionIndex: 2, isCorrect: true },
                { text: 'حقل غرب القرنة', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما نسبة صادرات العراق النفطية إلى الصين تقريباً؟',
            correctAnswer: 1,
            order: 3,
            explanation: 'الإجابة الصحيحة هي: 60%',
            optionRecords: {
              create: [
                { text: '30%', optionIndex: 0, isCorrect: false },
                { text: '60%', optionIndex: 1, isCorrect: true },
                { text: '40%', optionIndex: 2, isCorrect: false },
                { text: '20%', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو معدل تصدير العراق اليومي من النفط تقريباً؟',
            correctAnswer: 2,
            order: 4,
            explanation: 'الإجابة الصحيحة هي: 4.5 مليون برميل',
            optionRecords: {
              create: [
                { text: '2 مليون برميل', optionIndex: 0, isCorrect: false },
                { text: '3.5 مليون برميل', optionIndex: 1, isCorrect: false },
                { text: '4.5 مليون برميل', optionIndex: 2, isCorrect: true },
                { text: '5 مليون برميل', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي الاتفاقية النفطية الشهيرة بين العراق والصين؟',
            correctAnswer: 0,
            order: 5,
            explanation: 'الإجابة الصحيحة هي: النفط مقابل الإعمار',
            optionRecords: {
              create: [
                { text: 'النفط مقابل الإعمار', optionIndex: 0, isCorrect: true },
                { text: 'النفط مقابل الغذاء', optionIndex: 1, isCorrect: false },
                { text: 'النفط مقابل التكنولوجيا', optionIndex: 2, isCorrect: false },
                { text: 'النفط مقابل الأسلحة', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي أكبر شركة نفطية حكومية في العراق؟',
            correctAnswer: 1,
            order: 6,
            explanation: 'الإجابة الصحيحة هي: شركة نفط الجنوب',
            optionRecords: {
              create: [
                { text: 'شركة نفط الشمال', optionIndex: 0, isCorrect: false },
                { text: 'شركة نفط الجنوب', optionIndex: 1, isCorrect: true },
                { text: 'شركة نفط ميسان', optionIndex: 2, isCorrect: false },
                { text: 'شركة نفط ديالى', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما نسبة إسهام قطاع النفط في الناتج المحلي العراقي؟',
            correctAnswer: 2,
            order: 7,
            explanation: 'الإجابة الصحيحة هي: أكثر من 60%',
            optionRecords: {
              create: [
                { text: '30%', optionIndex: 0, isCorrect: false },
                { text: '50%', optionIndex: 1, isCorrect: false },
                { text: 'أكثر من 60%', optionIndex: 2, isCorrect: true },
                { text: '40%', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو مشروع خط أنابيب النفط الاستراتيجي بين العراق والأردن؟',
            correctAnswer: 0,
            order: 8,
            explanation: 'الإجابة الصحيحة هي: خط البصرة-عقبة',
            optionRecords: {
              create: [
                { text: 'خط البصرة-عقبة', optionIndex: 0, isCorrect: true },
                { text: 'خط كركوك-سيهان', optionIndex: 1, isCorrect: false },
                { text: 'خط بغداد-عمان', optionIndex: 2, isCorrect: false },
                { text: 'خط الموصل-حلب', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي التحديات الرئيسية لقطاع الغاز في العراق؟',
            correctAnswer: 1,
            order: 9,
            explanation: 'الإجابة الصحيحة هي: حرق الغاز المصاحب وعدم الاستثمار',
            optionRecords: {
              create: [
                { text: 'غياب الاحتياطيات', optionIndex: 0, isCorrect: false },
                { text: 'حرق الغاز المصاحب وعدم الاستثمار', optionIndex: 1, isCorrect: true },
                { text: 'ارتفاع تكاليف الإنتاج', optionIndex: 2, isCorrect: false },
                { text: 'عدم وجود طلب', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو هدف العراق من إنتاج الطاقة المتجددة حتى 2030؟',
            correctAnswer: 2,
            order: 10,
            explanation: 'الإجابة الصحيحة هي: 15-20%',
            optionRecords: {
              create: [
                { text: '5%', optionIndex: 0, isCorrect: false },
                { text: '10%', optionIndex: 1, isCorrect: false },
                { text: '15-20%', optionIndex: 2, isCorrect: true },
                { text: '30%', optionIndex: 3, isCorrect: false },
              ]
            }
          },
        ]
      }
    }
  })
  await prisma.quiz.create({
    data: {
      id: 'quiz_3',
      title: 'اختبار المصطلحات الاقتصادية',
      description: 'اختبر معرفتك بالمصطلحات الاقتصادية الأساسية والمتقدمة',
      category: 'مصطلحات اقتصادية',
      difficulty: 'BEGINNER',
      timeLimit: 15,
      questionsCount: 10,
      questions: {
        create: [
          {
            question: 'ما هو التضخم؟',
            correctAnswer: 0,
            order: 1,
            explanation: 'الإجابة الصحيحة هي: ارتفاع مستوى الأسعار العام',
            optionRecords: {
              create: [
                { text: 'ارتفاع مستوى الأسعار العام', optionIndex: 0, isCorrect: true },
                { text: 'انخفاض الأسعار', optionIndex: 1, isCorrect: false },
                { text: 'ثبات الأسعار', optionIndex: 2, isCorrect: false },
                { text: 'تقلب الأسعار فقط', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو الناتج المحلي الإجمالي؟',
            correctAnswer: 1,
            order: 2,
            explanation: 'الإجابة الصحيحة هي: إجمالي قيمة السلع والخدمات المنتجة',
            optionRecords: {
              create: [
                { text: 'إجمالي دخل الأفراد', optionIndex: 0, isCorrect: false },
                { text: 'إجمالي قيمة السلع والخدمات المنتجة', optionIndex: 1, isCorrect: true },
                { text: 'إجمالي الصادرات', optionIndex: 2, isCorrect: false },
                { text: 'إجمالي الاستيرادات', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي السياسة النقدية؟',
            correctAnswer: 2,
            order: 3,
            explanation: 'الإجابة الصحيحة هي: إجراءات البنك المركزي للتحكم في عرض النقد',
            optionRecords: {
              create: [
                { text: 'سياسة الإنفاق الحكومي', optionIndex: 0, isCorrect: false },
                { text: 'سياسة الضرائب', optionIndex: 1, isCorrect: false },
                { text: 'إجراءات البنك المركزي للتحكم في عرض النقد', optionIndex: 2, isCorrect: true },
                { text: 'سياسة التجارة الخارجية', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو الاحتياطي النقدي الأجنبي؟',
            correctAnswer: 0,
            order: 4,
            explanation: 'الإجابة الصحيحة هي: الأصول بالعملات الأجنبية لدى الدولة',
            optionRecords: {
              create: [
                { text: 'الأصول بالعملات الأجنبية لدى الدولة', optionIndex: 0, isCorrect: true },
                { text: 'الذهب المحفوظ في البنوك', optionIndex: 1, isCorrect: false },
                { text: 'الأموال المودعة في المصارف', optionIndex: 2, isCorrect: false },
                { text: 'الديون الخارجية', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو الاستثمار الأجنبي المباشر؟',
            correctAnswer: 1,
            order: 5,
            explanation: 'الإجابة الصحيحة هي: استثمار يهدف للإدارة والتحكم في مشروع بدولة أخرى',
            optionRecords: {
              create: [
                { text: 'شراء الأسهم فقط', optionIndex: 0, isCorrect: false },
                { text: 'استثمار يهدف للإدارة والتحكم في مشروع بدولة أخرى', optionIndex: 1, isCorrect: true },
                { text: 'القروض الخارجية', optionIndex: 2, isCorrect: false },
                { text: 'التبرعات الدولية', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو العجز التجاري؟',
            correctAnswer: 2,
            order: 6,
            explanation: 'الإجابة الصحيحة هي: زيادة الواردات على الصادرات',
            optionRecords: {
              create: [
                { text: 'زيادة الصادرات على الواردات', optionIndex: 0, isCorrect: false },
                { text: 'توازن الصادرات والواردات', optionIndex: 1, isCorrect: false },
                { text: 'زيادة الواردات على الصادرات', optionIndex: 2, isCorrect: true },
                { text: 'انخفاض الصادرات والواردات معا', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هي الخصخصة؟',
            correctAnswer: 0,
            order: 7,
            explanation: 'الإجابة الصحيحة هي: نقل الملكية من القطاع العام إلى الخاص',
            optionRecords: {
              create: [
                { text: 'نقل الملكية من القطاع العام إلى الخاص', optionIndex: 0, isCorrect: true },
                { text: 'تأميم الشركات', optionIndex: 1, isCorrect: false },
                { text: 'إغلاق الشركات الحكومية', optionIndex: 2, isCorrect: false },
                { text: 'دمج الشركات', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو الشمول المالي؟',
            correctAnswer: 1,
            order: 8,
            explanation: 'الإجابة الصحيحة هي: توفير الخدمات المالية لجميع فئات المجتمع',
            optionRecords: {
              create: [
                { text: 'زيادة أرباح البنوك', optionIndex: 0, isCorrect: false },
                { text: 'توفير الخدمات المالية لجميع فئات المجتمع', optionIndex: 1, isCorrect: true },
                { text: 'إلغاء الضرائب', optionIndex: 2, isCorrect: false },
                { text: 'خصخصة المصارف', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو ميزان المدفوعات؟',
            correctAnswer: 2,
            order: 9,
            explanation: 'الإجابة الصحيحة هي: سجل المعاملات الاقتصادية مع الخارج',
            optionRecords: {
              create: [
                { text: 'حساب الرواتب الحكومية', optionIndex: 0, isCorrect: false },
                { text: 'إجمالي الديون الخارجية', optionIndex: 1, isCorrect: false },
                { text: 'سجل المعاملات الاقتصادية مع الخارج', optionIndex: 2, isCorrect: true },
                { text: 'ميزانية الدولة', optionIndex: 3, isCorrect: false },
              ]
            }
          },
          {
            question: 'ما هو التنويع الاقتصادي؟',
            correctAnswer: 0,
            order: 10,
            explanation: 'الإجابة الصحيحة هي: تقليل الاعتماد على قطاع واحد وتطوير قطاعات متعددة',
            optionRecords: {
              create: [
                { text: 'تقليل الاعتماد على قطاع واحد وتطوير قطاعات متعددة', optionIndex: 0, isCorrect: true },
                { text: 'زيادة الإنتاج النفطي', optionIndex: 1, isCorrect: false },
                { text: 'الاعتماد على الزراعة فقط', optionIndex: 2, isCorrect: false },
                { text: 'استيراد منتجات متنوعة', optionIndex: 3, isCorrect: false },
              ]
            }
          },
        ]
      }
    }
  })
  console.log('  ✓ 3 quizzes with 30 questions created')
// ===== SITE SETTINGS =====
  await prisma.siteSettings.upsert({
    where: { id: 'main' },
    update: {},
    create: { id: 'main', siteName: 'ميدان الاقتصاد', siteDescription: 'المرجع الاقتصادي العراقي' }
  })

  // ===== PRICING CONFIG =====
  await prisma.pricingConfig.upsert({
    where: { id: 'default' },
    update: {},
    create: { id: 'default' }
  })

  // ===== PAYMENT DESTINATION =====
  await prisma.paymentDestination.upsert({
    where: { id: 'default' },
    update: {},
    create: { id: 'default' }
  })
  console.log('  ✓ Site settings, pricing, and payment config created')

  console.log('\n🎉 Seeding complete!')
}

main()
  .catch((e) => { console.error(e); process.exit(1) })
  .finally(async () => { await prisma.$disconnect() })
