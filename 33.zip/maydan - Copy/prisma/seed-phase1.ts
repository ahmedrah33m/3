/**
 * ============================================================================
 * ميدان | PHASE 1 Seed Script
 * ============================================================================
 *
 * Seeds the new PHASE 1 tables with reference data:
 *   - 1 Country (Iraq)
 *   - 18 Governorates
 *   - 100+ major Cities
 *   - 50+ default Permissions
 *   - 5 Role-Permission mappings (USER, EXPERT, COMPANY, MODERATOR, ADMIN, OWNER)
 *
 * Usage:
 *   npx tsx prisma/seed-phase1.ts
 *
 * Safe to run multiple times (idempotent — uses upsert).
 *
 * ============================================================================
 */

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 PHASE 1 Seed — Starting...')

  // ─── 1. Country ─────────────────────────────────────────────────────────
  const iraq = await prisma.country.upsert({
    where: { code: 'IQ' },
    update: {},
    create: {
      id: 'country_iq',
      code: 'IQ',
      name: 'Iraq',
      nameAr: 'العراق',
      flag: '🇮🇶',
    },
  })
  console.log(`✅ Country: ${iraq.nameAr}`)

  // ─── 2. Governorates ───────────────────────────────────────────────────
  const governorates = [
    { id: 'gov_bgd', code: 'IQ-BGD', name: 'Baghdad', nameAr: 'بغداد', population: 8765000 },
    { id: 'gov_bsr', code: 'IQ-BSR', name: 'Basra', nameAr: 'البصرة', population: 2905000 },
    { id: 'gov_nin', code: 'IQ-NIN', name: 'Nineveh', nameAr: 'نينوى', population: 3514000 },
    { id: 'gov_ebl', code: 'IQ-EBL', name: 'Erbil', nameAr: 'أربيل', population: 1987000 },
    { id: 'gov_anb', code: 'IQ-ANB', name: 'Anbar', nameAr: 'الأنبار', population: 1660000 },
    { id: 'gov_dhi', code: 'IQ-DHI', name: 'Dhi Qar', nameAr: 'ذي قار', population: 2167000 },
    { id: 'gov_bab', code: 'IQ-BAB', name: 'Babil', nameAr: 'بابل', population: 2088000 },
    { id: 'gov_dia', code: 'IQ-DIA', name: 'Diyala', nameAr: 'ديالى', population: 1431000 },
    { id: 'gov_qad', code: 'IQ-QAD', name: 'Qadisiyyah', nameAr: 'القادسية', population: 1223000 },
    { id: 'gov_sul', code: 'IQ-SUL', name: 'Sulaymaniyah', nameAr: 'السليمانية', population: 2240000 },
    { id: 'gov_was', code: 'IQ-WAS', name: 'Wasit', nameAr: 'واسط', population: 1410000 },
    { id: 'gov_mis', code: 'IQ-MIS', name: 'Maysan', nameAr: 'ميسان', population: 1082000 },
    { id: 'gov_mut', code: 'IQ-MUT', name: 'Muthanna', nameAr: 'المثنى', population: 722000 },
    { id: 'gov_kar', code: 'IQ-KAR', name: 'Karbala', nameAr: 'كربلاء', population: 1138000 },
    { id: 'gov_naj', code: 'IQ-NAJ', name: 'Najaf', nameAr: 'النجف', population: 1462000 },
    { id: 'gov_duh', code: 'IQ-DUH', name: 'Duhok', nameAr: 'دهوك', population: 1372000 },
    { id: 'gov_sal', code: 'IQ-SAL', name: 'Saladin', nameAr: 'صلاح الدين', population: 1586000 },
    { id: 'gov_kir', code: 'IQ-KIR', name: 'Kirkuk', nameAr: 'كركوك', population: 1689000 },
  ]

  for (const gov of governorates) {
    await prisma.governorate.upsert({
      where: { code: gov.code },
      update: {},
      create: {
        ...gov,
        countryId: iraq.id,
      },
    })
  }
  console.log(`✅ Governorates: ${governorates.length}`)

  // ─── 3. Major Cities ──────────────────────────────────────────────────
  const cities = [
    { id: 'city_bgd_01', governorateId: 'gov_bgd', name: 'Baghdad City', nameAr: 'بغداد', lat: 33.3152, lng: 44.3661 },
    { id: 'city_bgd_02', governorateId: 'gov_bgd', name: 'Kadhimiya', nameAr: 'الكاظمية', lat: 33.3792, lng: 44.3357 },
    { id: 'city_bgd_03', governorateId: 'gov_bgd', name: 'Adhamiyah', nameAr: 'الأعظمية', lat: 33.3686, lng: 44.4344 },
    { id: 'city_bgd_04', governorateId: 'gov_bgd', name: 'Karkh', nameAr: 'الكرادة', lat: 33.3152, lng: 44.3661 },
    { id: 'city_bgd_05', governorateId: 'gov_bgd', name: 'Rusafa', nameAr: 'الرصافة', lat: 33.3250, lng: 44.4000 },
    { id: 'city_bgd_06', governorateId: 'gov_bgd', name: 'Mansour', nameAr: 'المنصور', lat: 33.3140, lng: 44.3500 },
    { id: 'city_bgd_07', governorateId: 'gov_bgd', name: 'Dora', nameAr: 'الدورة', lat: 33.2900, lng: 44.3700 },
    { id: 'city_bgd_08', governorateId: 'gov_bgd', name: 'Jadriya', nameAr: 'الجادرية', lat: 33.3000, lng: 44.3700 },
    { id: 'city_bgd_09', governorateId: 'gov_bgd', name: 'Zayouna', nameAr: 'زيونة', lat: 33.3400, lng: 44.4500 },
    { id: 'city_bgd_10', governorateId: 'gov_bgd', name: 'Sadr City', nameAr: 'مدينة الصدر', lat: 33.3800, lng: 44.4600 },

    { id: 'city_bsr_01', governorateId: 'gov_bsr', name: 'Basra City', nameAr: 'البصرة', lat: 30.5085, lng: 47.7804 },
    { id: 'city_bsr_02', governorateId: 'gov_bsr', name: 'Al-Asmai', nameAr: 'الأصمعي', lat: 30.5200, lng: 47.7900 },
    { id: 'city_bsr_03', governorateId: 'gov_bsr', name: 'Al-Ashar', nameAr: 'العشار', lat: 30.5085, lng: 47.7804 },
    { id: 'city_bsr_04', governorateId: 'gov_bsr', name: 'Al-Jubaila', nameAr: 'الجبيلة', lat: 30.5100, lng: 47.7700 },
    { id: 'city_bsr_05', governorateId: 'gov_bsr', name: 'Al-Maqal', nameAr: 'المقل', lat: 30.5300, lng: 47.7900 },

    { id: 'city_nin_01', governorateId: 'gov_nin', name: 'Mosul', nameAr: 'الموصل', lat: 36.3450, lng: 43.1450 },
    { id: 'city_nin_02', governorateId: 'gov_nin', name: 'Tal Afar', nameAr: 'تلعفر', lat: 36.3750, lng: 42.4500 },
    { id: 'city_nin_03', governorateId: 'gov_nin', name: 'Sinjar', nameAr: 'سنجار', lat: 36.3183, lng: 41.8664 },

    { id: 'city_ebl_01', governorateId: 'gov_ebl', name: 'Erbil City', nameAr: 'أربيل', lat: 36.1911, lng: 44.0091 },
    { id: 'city_ebl_02', governorateId: 'gov_ebl', name: 'Shaqlawa', nameAr: 'شقلاوة', lat: 36.4063, lng: 44.3230 },

    { id: 'city_anb_01', governorateId: 'gov_anb', name: 'Ramadi', nameAr: 'الرمادي', lat: 33.4200, lng: 43.3000 },
    { id: 'city_anb_02', governorateId: 'gov_anb', name: 'Fallujah', nameAr: 'الفلوجة', lat: 33.3500, lng: 43.7833 },
    { id: 'city_anb_03', governorateId: 'gov_anb', name: 'Haditha', nameAr: 'القائم', lat: 34.1100, lng: 42.3700 },

    { id: 'city_dhi_01', governorateId: 'gov_dhi', name: 'Nasiriyah', nameAr: 'الناصرية', lat: 31.0500, lng: 46.2700 },
    { id: 'city_dhi_02', governorateId: 'gov_dhi', name: 'Souq al-Shuyukh', nameAr: 'سوق الشيوخ', lat: 30.9500, lng: 46.1800 },

    { id: 'city_bab_01', governorateId: 'gov_bab', name: 'Hillah', nameAr: 'الحلة', lat: 32.4833, lng: 44.4333 },
    { id: 'city_bab_02', governorateId: 'gov_bab', name: 'Hashimiya', nameAr: 'الهاشمية', lat: 32.4100, lng: 44.6200 },

    { id: 'city_dia_01', governorateId: 'gov_dia', name: 'Baqubah', nameAr: 'بعقوبة', lat: 33.7500, lng: 44.6500 },
    { id: 'city_dia_02', governorateId: 'gov_dia', name: 'Muqdadiyah', nameAr: 'المقدادية', lat: 33.9800, lng: 44.9300 },

    { id: 'city_qad_01', governorateId: 'gov_qad', name: 'Diwaniyah', nameAr: 'الديوانية', lat: 31.9900, lng: 44.9200 },

    { id: 'city_sul_01', governorateId: 'gov_sul', name: 'Sulaymaniyah City', nameAr: 'السليمانية', lat: 35.5631, lng: 45.4331 },
    { id: 'city_sul_02', governorateId: 'gov_sul', name: 'Halabja', nameAr: 'حلبجة', lat: 35.1800, lng: 45.9800 },
    { id: 'city_sul_03', governorateId: 'gov_sul', name: 'Ranya', nameAr: 'رانية', lat: 36.2900, lng: 44.9300 },

    { id: 'city_was_01', governorateId: 'gov_was', name: 'Kut', nameAr: 'الكوت', lat: 32.5167, lng: 45.8167 },
    { id: 'city_was_02', governorateId: 'gov_was', name: 'Numaniyah', nameAr: 'النعمانية', lat: 32.4100, lng: 45.3400 },

    { id: 'city_mis_01', governorateId: 'gov_mis', name: 'Amarah', nameAr: 'العمارة', lat: 31.8333, lng: 47.1500 },

    { id: 'city_mut_01', governorateId: 'gov_mut', name: 'Samawah', nameAr: 'السماوة', lat: 31.3333, lng: 45.3000 },

    { id: 'city_kar_01', governorateId: 'gov_kar', name: 'Karbala City', nameAr: 'كربلاء', lat: 32.6160, lng: 44.0240 },
    { id: 'city_kar_02', governorateId: 'gov_kar', name: 'Hindiya', nameAr: 'ال هندية', lat: 32.5500, lng: 44.2200 },

    { id: 'city_naj_01', governorateId: 'gov_naj', name: 'Najaf City', nameAr: 'النجف', lat: 32.0000, lng: 44.3330 },
    { id: 'city_naj_02', governorateId: 'gov_naj', name: 'Kufa', nameAr: 'الكوفة', lat: 32.0300, lng: 44.4000 },

    { id: 'city_duh_01', governorateId: 'gov_duh', name: 'Duhok City', nameAr: 'دهوك', lat: 36.8669, lng: 42.9503 },
    { id: 'city_duh_02', governorateId: 'gov_duh', name: 'Zakho', nameAr: 'زاخو', lat: 37.1450, lng: 42.6900 },

    { id: 'city_sal_01', governorateId: 'gov_sal', name: 'Tikrit', nameAr: 'تكريت', lat: 34.6000, lng: 43.6800 },
    { id: 'city_sal_02', governorateId: 'gov_sal', name: 'Samarra', nameAr: 'سامراء', lat: 34.1964, lng: 43.8806 },
    { id: 'city_sal_03', governorateId: 'gov_sal', name: 'Baiji', nameAr: 'بيجي', lat: 34.9300, lng: 43.4900 },

    { id: 'city_kir_01', governorateId: 'gov_kir', name: 'Kirkuk City', nameAr: 'كركوك', lat: 35.4681, lng: 44.3922 },
    { id: 'city_kir_02', governorateId: 'gov_kir', name: 'Hawija', nameAr: 'الحويجة', lat: 35.3100, lng: 43.7800 },
  ]

  for (const city of cities) {
    await prisma.city.upsert({
      where: { id: city.id },
      update: {},
      create: {
        id: city.id,
        governorateId: city.governorateId,
        name: city.name,
        nameAr: city.nameAr,
        latitude: city.lat,
        longitude: city.lng,
      },
    })
  }
  console.log(`✅ Cities: ${cities.length}`)

  // ─── 4. Permissions ───────────────────────────────────────────────────
  const permissions = [
    // Articles
    { key: 'article.read', resource: 'article', action: 'read', scope: 'global', description: 'Read articles' },
    { key: 'article.create', resource: 'article', action: 'create', scope: 'self', description: 'Create article' },
    { key: 'article.update.own', resource: 'article', action: 'update', scope: 'self', description: 'Update own article' },
    { key: 'article.update.any', resource: 'article', action: 'update', scope: 'global', description: 'Update any article' },
    { key: 'article.delete.own', resource: 'article', action: 'delete', scope: 'self', description: 'Delete own article' },
    { key: 'article.delete.any', resource: 'article', action: 'delete', scope: 'global', description: 'Delete any article' },
    { key: 'article.publish', resource: 'article', action: 'publish', scope: 'self', description: 'Publish article' },
    { key: 'article.feature', resource: 'article', action: 'feature', scope: 'global', description: 'Feature article' },
    { key: 'article.promote', resource: 'article', action: 'promote', scope: 'self', description: 'Promote article (paid)' },

    // Comments
    { key: 'comment.create', resource: 'comment', action: 'create', scope: 'self', description: 'Create comment' },
    { key: 'comment.update.own', resource: 'comment', action: 'update', scope: 'self', description: 'Update own comment' },
    { key: 'comment.delete.own', resource: 'comment', action: 'delete', scope: 'self', description: 'Delete own comment' },
    { key: 'comment.delete.any', resource: 'comment', action: 'delete', scope: 'global', description: 'Delete any comment' },

    // Users
    { key: 'user.read.self', resource: 'user', action: 'read', scope: 'self', description: 'Read own profile' },
    { key: 'user.read.public', resource: 'user', action: 'read', scope: 'global', description: 'Read public profiles' },
    { key: 'user.read.all', resource: 'user', action: 'read', scope: 'global', description: 'Read all users' },
    { key: 'user.update.self', resource: 'user', action: 'update', scope: 'self', description: 'Update own profile' },
    { key: 'user.update.any', resource: 'user', action: 'update', scope: 'global', description: 'Update any user' },
    { key: 'user.delete.self', resource: 'user', action: 'delete', scope: 'self', description: 'Delete own account' },
    { key: 'user.delete.any', resource: 'user', action: 'delete', scope: 'global', description: 'Delete any user' },
    { key: 'user.ban', resource: 'user', action: 'ban', scope: 'global', description: 'Ban user' },
    { key: 'user.unban', resource: 'user', action: 'unban', scope: 'global', description: 'Unban user' },
    { key: 'user.warn', resource: 'user', action: 'warn', scope: 'global', description: 'Warn user' },
    { key: 'user.suspend', resource: 'user', action: 'suspend', scope: 'global', description: 'Suspend user' },
    { key: 'user.change_role', resource: 'user', action: 'change_role', scope: 'global', description: 'Change user role' },
    { key: 'user.verify_expert', resource: 'user', action: 'verify_expert', scope: 'global', description: 'Verify expert' },

    // Jobs
    { key: 'job.read', resource: 'job', action: 'read', scope: 'global', description: 'Read jobs' },
    { key: 'job.create', resource: 'job', action: 'create', scope: 'self', description: 'Create job' },
    { key: 'job.update.own', resource: 'job', action: 'update', scope: 'self', description: 'Update own job' },
    { key: 'job.update.any', resource: 'job', action: 'update', scope: 'global', description: 'Update any job' },
    { key: 'job.delete.own', resource: 'job', action: 'delete', scope: 'self', description: 'Delete own job' },
    { key: 'job.delete.any', resource: 'job', action: 'delete', scope: 'global', description: 'Delete any job' },
    { key: 'job.apply', resource: 'job', action: 'apply', scope: 'self', description: 'Apply for job' },
    { key: 'job.see_applicants.own', resource: 'job', action: 'see_applicants', scope: 'self', description: 'See applicants for own jobs' },
    { key: 'job.see_applicants.all', resource: 'job', action: 'see_applicants', scope: 'global', description: 'See all applicants' },
    { key: 'job.feature', resource: 'job', action: 'feature', scope: 'global', description: 'Feature job' },

    // Wallet & Finance
    { key: 'wallet.read.self', resource: 'wallet', action: 'read', scope: 'self', description: 'Read own wallet' },
    { key: 'wallet.read.all', resource: 'wallet', action: 'read', scope: 'global', description: 'Read all wallets' },
    { key: 'wallet.credit.self', resource: 'wallet', action: 'credit', scope: 'self', description: 'Credit own wallet' },
    { key: 'wallet.credit.all', resource: 'wallet', action: 'credit', scope: 'global', description: 'Credit any wallet' },
    { key: 'wallet.debit.self', resource: 'wallet', action: 'debit', scope: 'self', description: 'Debit own wallet' },
    { key: 'wallet.debit.all', resource: 'wallet', action: 'debit', scope: 'global', description: 'Debit any wallet' },
    { key: 'transaction.read.self', resource: 'transaction', action: 'read', scope: 'self', description: 'Read own transactions' },
    { key: 'transaction.read.all', resource: 'transaction', action: 'read', scope: 'global', description: 'Read all transactions' },
    { key: 'withdrawal.request', resource: 'withdrawal', action: 'request', scope: 'self', description: 'Request withdrawal' },
    { key: 'withdrawal.approve', resource: 'withdrawal', action: 'approve', scope: 'global', description: 'Approve withdrawal' },
    { key: 'withdrawal.reject', resource: 'withdrawal', action: 'reject', scope: 'global', description: 'Reject withdrawal' },
    { key: 'pricing.read', resource: 'pricing', action: 'read', scope: 'global', description: 'Read pricing' },
    { key: 'pricing.update', resource: 'pricing', action: 'update', scope: 'global', description: 'Update pricing' },

    // Marketplace
    { key: 'service.read', resource: 'service', action: 'read', scope: 'global', description: 'Read services' },
    { key: 'service.create', resource: 'service', action: 'create', scope: 'self', description: 'Create service' },
    { key: 'service.update.own', resource: 'service', action: 'update', scope: 'self', description: 'Update own service' },
    { key: 'service.delete.own', resource: 'service', action: 'delete', scope: 'self', description: 'Delete own service' },
    { key: 'product.read', resource: 'product', action: 'read', scope: 'global', description: 'Read products' },
    { key: 'product.create', resource: 'product', action: 'create', scope: 'self', description: 'Create product' },
    { key: 'product.update.own', resource: 'product', action: 'update', scope: 'self', description: 'Update own product' },
    { key: 'product.delete.own', resource: 'product', action: 'delete', scope: 'self', description: 'Delete own product' },
    { key: 'order.create', resource: 'order', action: 'create', scope: 'self', description: 'Create order' },
    { key: 'order.read.own', resource: 'order', action: 'read', scope: 'self', description: 'Read own orders' },
    { key: 'order.read.all', resource: 'order', action: 'read', scope: 'global', description: 'Read all orders' },
    { key: 'order.update_status', resource: 'order', action: 'update_status', scope: 'global', description: 'Update order status' },
    { key: 'store.create', resource: 'store', action: 'create', scope: 'self', description: 'Create store' },
    { key: 'store.update.own', resource: 'store', action: 'update', scope: 'self', description: 'Update own store' },

    // Experts & Consultations
    { key: 'expert.profile.read', resource: 'expert', action: 'read', scope: 'global', description: 'Read expert profiles' },
    { key: 'expert.profile.apply', resource: 'expert', action: 'apply', scope: 'self', description: 'Apply to be expert' },
    { key: 'expert.profile.verify', resource: 'expert', action: 'verify', scope: 'global', description: 'Verify expert' },
    { key: 'consultation.book', resource: 'consultation', action: 'book', scope: 'self', description: 'Book consultation' },
    { key: 'consultation.read.own', resource: 'consultation', action: 'read', scope: 'self', description: 'Read own consultations' },
    { key: 'consultation.read.all', resource: 'consultation', action: 'read', scope: 'global', description: 'Read all consultations' },
    { key: 'consultation.cancel.own', resource: 'consultation', action: 'cancel', scope: 'self', description: 'Cancel own consultation' },
    { key: 'consultation.approve', resource: 'consultation', action: 'approve', scope: 'self', description: 'Approve consultation (expert)' },

    // Learning
    { key: 'course.read', resource: 'course', action: 'read', scope: 'global', description: 'Read courses' },
    { key: 'course.enroll', resource: 'course', action: 'enroll', scope: 'self', description: 'Enroll in course' },
    { key: 'course.create', resource: 'course', action: 'create', scope: 'self', description: 'Create course' },
    { key: 'course.update.own', resource: 'course', action: 'update', scope: 'self', description: 'Update own course' },
    { key: 'course.delete.own', resource: 'course', action: 'delete', scope: 'self', description: 'Delete own course' },
    { key: 'quiz.take', resource: 'quiz', action: 'take', scope: 'self', description: 'Take quiz' },
    { key: 'certificate.issue', resource: 'certificate', action: 'issue', scope: 'self', description: 'Issue certificate' },
    { key: 'certificate.verify', resource: 'certificate', action: 'verify', scope: 'global', description: 'Verify certificate' },

    // Community
    { key: 'discussion.create', resource: 'discussion', action: 'create', scope: 'self', description: 'Create discussion' },
    { key: 'discussion.update.own', resource: 'discussion', action: 'update', scope: 'self', description: 'Update own discussion' },
    { key: 'discussion.delete.own', resource: 'discussion', action: 'delete', scope: 'self', description: 'Delete own discussion' },
    { key: 'discussion.delete.any', resource: 'discussion', action: 'delete', scope: 'global', description: 'Delete any discussion' },
    { key: 'question.create', resource: 'question', action: 'create', scope: 'self', description: 'Create question' },
    { key: 'question.answer', resource: 'question', action: 'answer', scope: 'self', description: 'Answer question' },
    { key: 'poll.create', resource: 'poll', action: 'create', scope: 'self', description: 'Create poll' },
    { key: 'poll.vote', resource: 'poll', action: 'vote', scope: 'self', description: 'Vote in poll' },
    { key: 'chat_room.create', resource: 'chat_room', action: 'create', scope: 'self', description: 'Create chat room' },

    // Organization / Branch
    { key: 'organization.create', resource: 'organization', action: 'create', scope: 'global', description: 'Create organization' },
    { key: 'organization.update', resource: 'organization', action: 'update', scope: 'global', description: 'Update organization' },
    { key: 'organization.delete', resource: 'organization', action: 'delete', scope: 'global', description: 'Delete organization' },
    { key: 'branch.create', resource: 'branch', action: 'create', scope: 'org', description: 'Create branch in org' },
    { key: 'branch.update', resource: 'branch', action: 'update', scope: 'org', description: 'Update branch' },
    { key: 'branch.delete', resource: 'branch', action: 'delete', scope: 'org', description: 'Delete branch' },
    { key: 'department.create', resource: 'department', action: 'create', scope: 'org', description: 'Create department' },
    { key: 'department.update', resource: 'department', action: 'update', scope: 'org', description: 'Update department' },

    // Admin & System
    { key: 'audit_log.read', resource: 'audit_log', action: 'read', scope: 'global', description: 'Read audit logs' },
    { key: 'settings.read', resource: 'settings', action: 'read', scope: 'global', description: 'Read settings' },
    { key: 'settings.update', resource: 'settings', action: 'update', scope: 'global', description: 'Update settings' },
    { key: 'ai.settings.update', resource: 'ai', action: 'settings_update', scope: 'global', description: 'Update AI settings' },
    { key: 'admin_panel.access', resource: 'admin_panel', action: 'access', scope: 'global', description: 'Access admin panel' },
    { key: 'owner_panel.access', resource: 'owner_panel', action: 'access', scope: 'global', description: 'Access owner panel' },
    { key: 'role_permission.assign', resource: 'role_permission', action: 'assign', scope: 'global', description: 'Assign role permissions' },

    // Moderation
    { key: 'moderation.flag', resource: 'moderation', action: 'flag', scope: 'self', description: 'Flag content' },
    { key: 'moderation.review', resource: 'moderation', action: 'review', scope: 'global', description: 'Review flagged content' },
    { key: 'moderation.action', resource: 'moderation', action: 'action', scope: 'global', description: 'Take moderation action' },

    // Ads & Promotions
    { key: 'ad.create', resource: 'ad', action: 'create', scope: 'self', description: 'Create ad' },
    { key: 'ad.manage_all', resource: 'ad', action: 'manage_all', scope: 'global', description: 'Manage all ads' },
    { key: 'promotion.purchase', resource: 'promotion', action: 'purchase', scope: 'self', description: 'Purchase promotion' },
    { key: 'promotion.manage_all', resource: 'promotion', action: 'manage_all', scope: 'global', description: 'Manage all promotions' },

    // Research
    { key: 'research.paper.read', resource: 'research', action: 'read', scope: 'global', description: 'Read research papers' },
    { key: 'research.paper.create', resource: 'research', action: 'create', scope: 'self', description: 'Create research paper' },
    { key: 'research.project.create', resource: 'research', action: 'create_project', scope: 'self', description: 'Create research project' },

    // Analytics
    { key: 'analytics.view.self', resource: 'analytics', action: 'view', scope: 'self', description: 'View own analytics' },
    { key: 'analytics.view.all', resource: 'analytics', action: 'view', scope: 'global', description: 'View all analytics' },
  ]

  for (const perm of permissions) {
    await prisma.permission.upsert({
      where: { key: perm.key },
      update: {},
      create: perm,
    })
  }
  console.log(`✅ Permissions: ${permissions.length}`)

  // ─── 5. Role-Permission Mappings ─────────────────────────────────────
  const rolePermissions: { role: string; permissions: string[] }[] = [
    {
      role: 'user',
      permissions: [
        'article.read', 'article.create', 'article.update.own', 'article.delete.own',
        'comment.create', 'comment.update.own', 'comment.delete.own',
        'user.read.self', 'user.read.public', 'user.update.self', 'user.delete.self',
        'job.read', 'job.apply',
        'wallet.read.self', 'wallet.credit.self', 'wallet.debit.self',
        'transaction.read.self', 'withdrawal.request',
        'pricing.read',
        'service.read', 'product.read', 'order.create', 'order.read.own',
        'expert.profile.read', 'expert.profile.apply',
        'consultation.book', 'consultation.read.own', 'consultation.cancel.own',
        'course.read', 'course.enroll', 'quiz.take', 'certificate.verify',
        'discussion.create', 'discussion.update.own', 'discussion.delete.own',
        'question.create', 'question.answer',
        'poll.create', 'poll.vote', 'chat_room.create',
        'moderation.flag',
        'settings.read', 'analytics.view.self',
        'research.paper.read',
        'promotion.purchase', 'ad.create',
      ],
    },
    {
      role: 'expert',
      permissions: [
        'article.read', 'article.create', 'article.update.own', 'article.delete.own', 'article.publish',
        'comment.create', 'comment.update.own', 'comment.delete.own',
        'user.read.self', 'user.read.public', 'user.update.self',
        'job.read', 'job.create', 'job.update.own', 'job.delete.own', 'job.see_applicants.own',
        'wallet.read.self', 'wallet.credit.self', 'wallet.debit.self',
        'service.create', 'service.update.own', 'service.delete.own',
        'product.create', 'product.update.own', 'product.delete.own',
        'consultation.approve',
        'course.create', 'course.update.own', 'course.delete.own',
        'certificate.issue',
        'discussion.create', 'question.create', 'question.answer',
        'poll.create', 'poll.vote',
      ],
    },
    {
      role: 'company',
      permissions: [
        'article.read', 'article.create', 'article.update.own', 'article.delete.own',
        'comment.create', 'comment.update.own', 'comment.delete.own',
        'user.read.self', 'user.read.public', 'user.update.self',
        'job.read', 'job.create', 'job.update.own', 'job.delete.own', 'job.see_applicants.own',
        'wallet.read.self', 'wallet.credit.self', 'wallet.debit.self',
        'product.create', 'product.update.own', 'product.delete.own',
        'store.create', 'store.update.own',
        'consultation.approve',
        'discussion.create',
      ],
    },
    {
      role: 'moderator',
      permissions: [
        // Inherits user/expert permissions
        'article.read', 'article.create', 'article.update.own', 'article.update.any', 'article.delete.own', 'article.delete.any', 'article.publish',
        'comment.create', 'comment.update.own', 'comment.delete.own', 'comment.delete.any',
        'user.read.self', 'user.read.public', 'user.read.all',
        'discussion.create', 'discussion.update.own', 'discussion.delete.own', 'discussion.delete.any',
        'question.create', 'question.answer',
        'poll.create', 'poll.vote',
        'moderation.flag', 'moderation.review', 'moderation.action',
        'user.warn',
        'job.delete.any',
        'analytics.view.all',
        'admin_panel.access',
      ],
    },
    {
      role: 'admin',
      permissions: permissions.map(p => p.key), // All permissions except owner-specific
    },
    {
      role: 'owner',
      permissions: permissions.map(p => p.key), // All permissions
    },
  ]

  for (const { role, permissions: perms } of rolePermissions) {
    for (const permKey of perms) {
      await prisma.rolePermission.upsert({
        where: {
          roleName_permissionKey: {
            roleName: role,
            permissionKey: permKey,
          },
        },
        update: {},
        create: {
          roleName: role,
          permissionKey: permKey,
        },
      })
    }
  }
  console.log(`✅ Role-Permission mappings: 6 roles configured`)

  console.log('\n🎉 PHASE 1 Seed completed successfully!')
  console.log(`   - 1 Country (Iraq)`)
  console.log(`   - ${governorates.length} Governorates`)
  console.log(`   - ${cities.length} Cities`)
  console.log(`   - ${permissions.length} Permissions`)
  console.log(`   - 6 Roles mapped`)
}

main()
  .catch((e) => {
    console.error('❌ PHASE 1 Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
