import { PrismaClient, UserRole, ArticleCategory, ArticleStatus, DiscussionCategory } from '@prisma/client'
import { hash } from 'bcryptjs'

const prisma = new PrismaClient()

function randomInt(min: number, max: number) { return Math.floor(Math.random() * (max - min + 1)) + min }
function randomDate(daysBack: number) {
  const d = new Date()
  d.setDate(d.getDate() - randomInt(0, daysBack))
  d.setHours(randomInt(6, 22), randomInt(0, 59))
  return d
}
function pick<T>(arr: T[]): T { return arr[randomInt(0, arr.length - 1)] }
function shuffle<T>(arr: T[]): T[] { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = randomInt(0, i); [a[i], a[j]] = [a[j], a[i]] } return a }

const PASSWORD_HASH = await hash('Test123456', 10)

async function main() {
  console.log('🚀 بدء ملء قاعدة البيانات بمحتوى اقتصادي عراقي...\n')

  // ════════════════════════════════════════════
  // 1. USERS
  // ════════════════════════════════════════════
  console.log('👤 إنشاء المستخدمين...')

  const usersData = [
    // OWNER
    { email: 'ahmed@midaniq.com', name: 'أحمد الرحيمي', password: PASSWORD_HASH, role: 'OWNER' as UserRole, jobTitle: 'مؤسس المنصة', organization: 'ميدان الاقتصاد', bio: 'مؤسس ومدير منصة ميدان الاقتصاد، خبير في الاقتصاد الرقمي والتقنية المالية', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 5000, reputationLevel: 'ECONOMIC_EXPERT' },
    // ADMINS
    { email: 'admin1@midaniq.com', name: 'زينب الموسوي', password: PASSWORD_HASH, role: 'ADMIN' as UserRole, jobTitle: 'مدير المحتوى', organization: 'ميدان الاقتصاد', bio: 'مديرة محتوى متخصصة في الإعلام الاقتصادي والتحليل المالي', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 3000, reputationLevel: 'ECONOMIC_ANALYST' },
    { email: 'admin2@midaniq.com', name: 'علي الربيعي', password: PASSWORD_HASH, role: 'ADMIN' as UserRole, jobTitle: 'مدير المجتمع', organization: 'ميدان الاقتصاد', bio: 'متخصص في إدارة المجتمعات الرقمية ومحتوى الأعمال', location: 'أربيل، العراق', isVerified: true, emailVerified: true, reputationPoints: 2500, reputationLevel: 'ECONOMIC_ANALYST' },
    // MODERATORS
    { email: 'mod1@midaniq.com', name: 'فاطمة الجبوري', password: PASSWORD_HASH, role: 'MODERATOR' as UserRole, jobTitle: 'مشرف محتوى', bio: 'مشرفة محتوى اقتصادي مع خبرة في التحرير والتحقق من المعلومات', location: 'النجف، العراق', isVerified: true, emailVerified: true, reputationPoints: 1500, reputationLevel: 'ACTIVE_MEMBER' },
    { email: 'mod2@midaniq.com', name: 'محمد الخفاجي', password: PASSWORD_HASH, role: 'MODERATOR' as UserRole, jobTitle: 'مشرف نقاشات', bio: 'مهتم بالنقاشات الاقتصادية وإدارة الحوارات المهنية', location: 'كربلاء، العراق', isVerified: true, emailVerified: true, reputationPoints: 1200, reputationLevel: 'ACTIVE_MEMBER' },
    { email: 'mod3@midaniq.com', name: 'نور الهاشمي', password: PASSWORD_HASH, role: 'MODERATOR' as UserRole, jobTitle: 'مشرف مجتمع', bio: 'متخصصة في الإعلام الاقتصادي وإدارة المحتوى الرقمي', location: 'البصرة، العراق', isVerified: true, emailVerified: true, reputationPoints: 1100, reputationLevel: 'ACTIVE_MEMBER' },
    // EXPERTS
    { email: 'dr.sara@midaniq.com', name: 'د. سارة العبيدي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'محللة مالية أولى', organization: 'البنك المركزي العراقي', bio: 'خبيرة في السياسة النقدية وسعر الصرف مع 15 عاماً من الخبرة في القطاع المصرفي العراقي. حاصلة على دكتوراه في الاقتصاد من جامعة بغداد', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 4200, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 850 },
    { email: 'ammar@midaniq.com', name: 'م. عمار الكندي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'خبير استثماري', organization: 'هيئة الاستثمار الوطنية', bio: 'مستشار استثماري متخصص في جذب رؤوس الأموال الأجنبية وتقييم الفرص الاستثمارية في العراق. خبرة 12 عاماً في الاستثمار الدولي', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 3800, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 720 },
    { email: 'nadia@midaniq.com', name: 'أ. نادية الحسيني', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'اقتصادية وباحثة', organization: 'جامعة المستنصرية', bio: 'أستاذة الاقتصاد الكلي المتخصصة في دراسة أثر الإصلاحات الاقتصادية على بيئة الأعمال في العراق والمنطقة', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 3500, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 630 },
    { email: 'dr.kareem@midaniq.com', name: 'د. كريم المخزومي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'أكاديمي اقتصاد', organization: 'جامعة بغداد', bio: 'باحث متخصص في اقتصاديات النفط والطاقة وعلاقتها بالتنمية المستدامة في الدول النفطية. نشر أكثر من 30 بحثاً علمياً', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 3200, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 580 },
    { email: 'layla@midaniq.com', name: 'م. ليلى الجبوري', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'خبيرة تجارة دولية', organization: 'غرفة تجارة بغداد', bio: 'متخصصة في التبادل التجاري العراقي مع دول الجوار وتحليل اتفاقيات التجارة الحرة وأثرها على الاقتصاد المحلي', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 2900, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 490 },
    { email: 'omar.econ@midaniq.com', name: 'د. عمر التميمي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'خبير نفطي', organization: 'وزارة النفط العراقية', bio: 'خبير في صناعة النفط والغاز وحصص الإنتاج ضمن أوبك وتحليل أسواق الطاقة العالمية وأثرها على الاقتصاد العراقي', location: 'البصرة، العراق', isVerified: true, emailVerified: true, reputationPoints: 3600, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 670 },
    { email: 'huda@midaniq.com', name: 'أ. هدى الشمري', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'خبيرة مصرفية إسلامية', organization: 'بنك العراق الإسلامي', bio: 'رائدة في الصيرفة الإسلامية والتمويل المتوافق مع الشريعة في العراق. خبرة 10 سنوات في تطوير المنتجات المصرفية الإسلامية', location: 'أربيل، العراق', isVerified: true, emailVerified: true, reputationPoints: 2700, reputationLevel: 'ECONOMIC_EXPERT', followersCount: 420 },
    { email: 'mustafa@midaniq.com', name: 'م. مصطفى الزيدي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'محلل أسواق مالية', organization: 'بورصة بغداد', bio: 'محلل فني وأساسي لأسواق الأوراق المالية العراقية مع خبرة في تقييم الشركات المدرجة وتحليل الاتجاهات', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 2400, reputationLevel: 'ECONOMIC_ANALYST', followersCount: 380 },
    { email: 'dr.amin@midaniq.com', name: 'د. أمين الدليمي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'خبير اقتصاد زراعي', organization: 'وزارة الزراعة', bio: 'متخصص في اقتصاديات القطاع الزراعي العراقي وأزمات المياه وأثر التغير المناخي على الأمن الغذائي', location: 'ذي قار، العراق', isVerified: true, emailVerified: true, reputationPoints: 2100, reputationLevel: 'ECONOMIC_ANALYST', followersCount: 310 },
    { email: 'rania@midaniq.com', name: 'أ. رانيا الصالحي', password: PASSWORD_HASH, role: 'EXPERT' as UserRole, jobTitle: 'خبيرة اقتصاد رقمي', organization: 'Zain Iraq', bio: 'رائدة في مجال التقنية المالية والاقتصاد الرقمي في العراق. متخصصة في تحويل المدفوعات الرقمية وريادة الأعمال التكنولوجية', location: 'بغداد، العراق', isVerified: true, emailVerified: true, reputationPoints: 2300, reputationLevel: 'ECONOMIC_ANALYST', followersCount: 450 },
    // REGULAR USERS
    { email: 'user1@midaniq.com', name: 'حسين اليعقوبي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'محاسب', organization: 'شركة الورقاء', bio: 'محاسب مهتم بالتحليل المالي والاستثمار', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 450, reputationLevel: 'MEMBER', followersCount: 35 },
    { email: 'user2@midaniq.com', name: 'زينب العامري', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'طالبة ماجستير اقتصاد', organization: 'جامعة بغداد', bio: 'طالبة دراسات عليا مهتمة بالسياسات الاقتصادية', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 320, reputationLevel: 'MEMBER', followersCount: 28 },
    { email: 'user3@midaniq.com', name: 'ياسر الساعدي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'مدير مبيعات', organization: 'مجموعة الشرق', bio: 'مهتم بأسواق المال والاستثمار الشخصي', location: 'البصرة، العراق', emailVerified: true, reputationPoints: 280, reputationLevel: 'MEMBER', followersCount: 22 },
    { email: 'user4@midaniq.com', name: 'مريم الطائي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'صحفية اقتصادية', organization: 'الشرق الأوسط', bio: 'صحفية متخصصة في الشؤون الاقتصادية العراقية', location: 'أربيل، العراق', emailVerified: true, reputationPoints: 520, reputationLevel: 'ACTIVE_MEMBER', followersCount: 85 },
    { email: 'user5@midaniq.com', name: 'أحمد المالكي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'موظف بنكي', organization: 'بنك الرافدين', bio: 'موظف في القطاع المصرفي مهتم بالتطوير المهني', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 180, reputationLevel: 'MEMBER', followersCount: 15 },
    { email: 'user6@midaniq.com', name: 'سحر العنزي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'مستشارة ضرائب', organization: 'مكتب العنزي للضرائب', bio: 'مستشارة ضريبية ومالية مستقلة', location: 'السليمانية، العراق', emailVerified: true, reputationPoints: 380, reputationLevel: 'MEMBER', followersCount: 42 },
    { email: 'user7@midaniq.com', name: 'عبدالله النعيمي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'رائد أعمال', bio: 'رائد أعمال شاب مهتم ببيئة الأعمال العراقية', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 250, reputationLevel: 'MEMBER', followersCount: 55 },
    { email: 'user8@midaniq.com', name: 'إيمان الشهابي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'محللة بيانات', organization: 'شركة آسيا للاتصالات', bio: 'محللة بيانات مهتمة بالتحليل الاقتصادي الرقمي', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 190, reputationLevel: 'MEMBER', followersCount: 18 },
    { email: 'user9@midaniq.com', name: 'صالح المياحي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'تاجر عقارات', bio: 'مستثمر في قطاع العقارات العراقي', location: 'البصرة، العراق', emailVerified: true, reputationPoints: 340, reputationLevel: 'MEMBER', followersCount: 30 },
    { email: 'user10@midaniq.com', name: 'لمياء البدري', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'باحثة اقتصادية', organization: 'مركز دراسات العراق', bio: 'باحثة في قضايا التنمية والاقتصاد العراقي', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 420, reputationLevel: 'ACTIVE_MEMBER', followersCount: 48 },
    { email: 'user11@midaniq.com', name: 'فراس الكعبي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'مهندس بترول', organization: 'شركة نفط الجنوب', bio: 'مهندس بترول مهتم بسياسات النفط العراقي', location: 'البصرة، العراق', emailVerified: true, reputationPoints: 160, reputationLevel: 'MEMBER', followersCount: 12 },
    { email: 'user12@midaniq.com', name: 'حنان السعدي', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'مدربة ريادة أعمال', bio: 'مدربة ومعلمة في مجال ريادة الأعمال والاقتصاد', location: 'النجف، العراق', emailVerified: true, reputationPoints: 290, reputationLevel: 'MEMBER', followersCount: 38 },
    { email: 'user13@midaniq.com', name: 'رعد الحمداني', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'مستشار مالي', organization: 'شركة الأمان للاستشارات', bio: 'مستشار مالي مستقل متخصص في التخطيط المالي الشخصي', location: 'بغداد، العراق', emailVerified: true, reputationPoints: 350, reputationLevel: 'MEMBER', followersCount: 25 },
    { email: 'user14@midaniq.com', name: 'بلقيس الأزدمرني', password: PASSWORD_HASH, role: 'USER' as UserRole, jobTitle: 'طالبة إدارة أعمال', organization: 'جامعة الموصل', bio: 'طالبة إدارة أعمال مهتمة بقطاع التجارة الإلكترونية', location: 'الموصل، العراق', emailVerified: true, reputationPoints: 140, reputationLevel: 'MEMBER', followersCount: 10 },
  ]

  const users: any[] = []
  for (const ud of usersData) {
    const user = await prisma.user.upsert({
      where: { email: ud.email },
      update: {},
      create: { ...ud, articlesCount: 0, followersCount: ud.followersCount || 0, followingCount: randomInt(5, 30) }
    })
    users.push(user)
  }
  console.log(`✅ تم إنشاء ${users.length} مستخدم`)

  const owner = users[0], admins = users.slice(1,3), mods = users.slice(3,6), experts = users.slice(6,16), regulars = users.slice(16)
  const allAuthors = [...experts, ...regulars.slice(0, 6)]

  // ════════════════════════════════════════════
  // 2. ARTICLES (120+)
  // ════════════════════════════════════════════
  console.log('📝 إنشاء المنشورات والمقالات...')

  const articlesData = [
    // === NEWS POSTS (30) ===
    { title: 'ارتفاع إنتاج النفط العراقي إلى 4.5 مليون برميل يومياً', content: 'أعلنت وزارة النفط العراقية عن ارتفاع معدلات الإنتاج النفطي إلى 4.5 مليون برميل يومياً خلال الشهر الجاري، متجاوزة الحصة المخصصة ضمن اتفاق أوبك بلس. وقال المتحدث باسم الوزارة إن الزيادة تأتي استجابة للطلب العالمي المتنامي مع الحفاظ على استقرار الأسواق.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'البنك المركزي يخفض سعر الفائدة إلى 5.5%', content: 'قرر البنك المركزي العراقي خفض سعر الفائدة الأساسي من 6% إلى 5.5% في خطوة تهدف إلى تحفيز الاقتراض ودعم النشاط الاقتصادي. وأوضح البنك في بيان أن القرار جاء بناءً على تحسن مؤشرات التضخم واستقرار سعر صرف الدينار.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'افتتاح بورصة بغداد لجلسات التداول الإلكتروني الجديدة', content: 'بدأت بورصة بغداد للأوراق المالية تطبيق نظام التداول الإلكتروني الجديد الذي يتيح للمستثمرين تنفيذ الصفقات عبر منصة رقمية متطورة، مما يقلل زمن التنفيذ ويزيد الشفافية في العمليات التداولية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'مشاركة عراقية واسعة في معرض إكسبو المالية بدبي', content: 'شارك وفد عراقي رفيع المستوى في معرض إكسبو المالية بدبي حيث عرض فرص الاستثمار المتاحة في العراق خاصة في قطاعات الطاقة والبنية التحتية والتقنية المالية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'إطلاق مشروع التحول الرقمي في المصارف الحكومية', content: 'أعلن البنك المركزي عن إطلاق المرحلة الثانية من مشروع التحول الرقمي الذي يشمل بنك الرافدين وبنك الرشيد بهدف رقمنة جميع العمليات المصرفية وتحسين جودة الخدمات المقدمة للمواطنين.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'ارتفاع تحويلات العراقيين بالخارج بنسبة 18%', content: 'سجلت التحويلات المالية للمغتربين العراقيين ارتفاعاً ملحوظاً بنسبة 18% خلال الربع الأول مقارنة بنفس الفترة من العام الماضي، مما يعكس تحسناً في الثقة بالقطاع المصرفي العراقي.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'اتفاقية جديدة مع تركيا لتسهيل التبادل التجاري', content: 'وقّع العراق وتركيا اتفاقية تجارية جديدة تهدف إلى تسهيل حركة البضائع عبر المنافذ الحدودية وتقليل القيود الجمركية وتشجيع الاستثمار المتبادل بين البلدين.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بدء العمل بمشروع المحطة الشمسية في الناصرية', content: 'انطلقت الأعمال الإنشائية في محطة الناصرية للطاقة الشمسية بقدرة إنتاجية 100 ميغاواط، كأول مشروع كبير للطاقة المتجددة في جنوب العراق بتمويل من صندوق أبوظبي للتنمية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'قفزة في مؤشر بورصة بغداد بنسبة 7.3%', content: 'حقق مؤشر بورصة بغداد للأوراق المالية قفزة كبيرة بنسبة 7.3% خلال تداولات الأسبوع مدفوعة بارتفاع أسهم قطاع المصارف والصناعة مع توقعات إيجابية بالموازنة الجديدة.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'العراق يوقع عقداً مع شركة شل لتطوير حقل ماجنون', content: 'وقع العراق عقداً مع شركة شل النفطية لتطوير حقل ماجنون النفطي بطاقة إنتاجية مستهدفة تبلغ 400 ألف برميل يومياً مع استثمارات تقدر بـ 3 مليارات دولار.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'إطلاق منصة إلكترونية لتمويل المشاريع الصغيرة', content: 'أطلقت وزارة العمل والشؤون الاجتماعية منصة إلكترونية جديدة لتمويل المشاريع الصغيرة والمتوسطة بقروض ميسرة تصل إلى 50 مليون دينار عراقي بفائدة 3% فقط.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'ارتفاع أسعار العقارات في بغداد بنسبة 22%', content: 'شهد سوق العقارات في بغداد ارتفاعاً حاداً في الأسعار بنسبة 22% خلال النصف الأول من العام الحالي، خاصة في مناطق الكرادة والمنصور والزيونة بسبب الطلب المتزايد.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'حصة إقليم كردستان في الموازنة الاتحادية الجديدة', content: 'أقرت الحكومة الاتحادية تخصيص 12.67% من الموازنة الاتحادية لإقليم كردستان مقابل تسليم 400 ألف برميل نفط يومياً للحكومة المركزية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'مبادرة زراعية جديدة لدعم مزارعي القمح', content: 'أطلقت وزارة الزراعة مبادرة جديدة لدعم مزارعي القمح تشمل توفير البذور المحسنة والأسمدة بأسعار مدعومة مع ضمان شراء المحاصيل بأسعار تنافسية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دخول ثلاث شركات أجنبية لسوق التأمين العراقي', content: 'حصلت ثلاث شركات تأمين دولية على تراخيص العمل في السوق العراقي مما سيعزز المنافسة ويوفر منتجات تأمينية متنوعة للمستهلكين العراقيين.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'افتتاح مركز الأعمال العراقي الصيني في بغداد', content: 'افتُتح مركز الأعمال العراقي الصيني في العاصمة بغداد بهدف تسهيل التعاون التجاري والاستثماري بين البلدين وتوفير خدمات استشارية للمستثمرين.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'انخفاض التضخم إلى 3.8% في العراق', content: 'أعلن الجهاز المركزي للإحصاء انخفاض معدل التضخم السنوي إلى 3.8% مقارنة بـ 5.2% في العام الماضي بفضل سياسات البنك المركزي في ضبط السيولة.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'السياحة الدينية تحقق إيرادات بقيمة 2 مليار دولار', content: 'حققت السياحة الدينية في النجف وكربلاء إيرادات بقيمة 2 مليار دولار خلال الموسم الحالي مع توقعات بزيادة أعداد الزوار الإيرانيين والخليجيين.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'البنك الدولي يمنح العراق قرضاً بقيمة 500 مليون دولار', content: 'وافق البنك الدولي على منح العراق قرضاً بقيمة 500 مليون دولار لدعم إصلاحات القطاع المالي وتحسين إدارة الموارد العامة وتعزيز الشفافية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تأسيس صندوق سيادي عراقي لإدارة الفوائض النفطية', content: 'وافق مجلس الوزراء على تأسيس صندوق سيادي لإدارة الفوائض النفطية وتنويع مصادر الدخل الوطني وحماية الاقتصاد من تقلبات أسعار النفط.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'إطلاق تطبيق الدفع الإلكتروني بين المصارف العراقية', content: 'أطلق البنك المركزي تطبيق الدفع الإلكتروني الموحد الذي يتيح التحويل الفوري بين حسابات المصارف العراقية المختلفة مجاناً.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'موافقة على قانون الاستثمار الجديد في مجلس النواب', content: 'وافق مجلس النواب العراقي بالقراءة الأولى على مشروع قانون الاستثمار الجديد الذي يتضمن حوافز ضريبية وتسهيلات إدارية للمستثمرين الأجانب.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تصدير النفط الكردي عبر ميناء جيهان يتعافى', content: 'تعافت صادرات النفط الكردي عبر ميناء جيهان التركي إلى مستويات تتجاوز 400 ألف برميل يومياً بعد حل الخلافات بين أربيل وبغداد.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'زيادة حصة العراق من مياه الفرات وال دجلة', content: 'أسفرت المفاوضات مع تركيا عن اتفاق مؤقت لزيادة حصة العراق من مياه نهر الفرات إلى 500 متر مكعب في الثانية خلال فترة الصيف.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بدء تسجيل الشركات إلكترونياً في السجل التجاري', content: 'أعلنت وزارة التجارة عن إطلاق خدمة التسجيل الإلكتروني للشركات في السجل التجاري مما يختصر مدة التسجيل من 30 يوماً إلى 3 أيام فقط.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'إقرار الموازنة الاتحادية بقيمة 198 تريليون دينار', content: 'أقر مجلس النواب الموازنة الاتحادية لعام 2026 بقيمة إجمالية تبلغ 198 تريليون دينار عراقي مع تخصيص 40% للنفقات الاستثمارية وبند رواتب بلغ 56 تريليون دينار.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'أزمة نقص الأسمنت ترفع أسعار البناء في البصرة', content: 'شهدت البصرة أزمة حادة في نقص مادة الأسمنت أدت إلى ارتفاع أسعار البناء بنسبة 30% مما أثر سلباً على قطاع المقاولات والإسكان.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'توقيع اتفاقية تجارة حرب بين العراق ومصر', content: 'وقع العراق ومصر اتفاقية تجارة حرب تتيح التبادل المباشر للمنتجات الزراعية والصناعية مع إعفاءات جمركية متبادلة على 200 سلعة أساسية.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الشركة الوطنية للنفط تعلن اكتشاف حقل جديد في ميسان', content: 'أعلنت الشركة الوطنية للنفط عن اكتشاف حقل نفطي جديد في محافظة ميسان باحتياطي يقدر بمليار برميل مع خطط لبدء الإنتاج التجريبي خلال عامين.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'إطلاق مبادرة وطنية لدعم الشركات الناشئة', content: 'أطلقت رئاسة الوزراء مبادرة وطنية لدعم الشركات الناشئة بتخصيص صندوق بقيمة 100 مليار دينار وتوفير حاضنات أعمال في المحافظات.', category: 'NEWS' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },

    // === ANALYSIS ARTICLES (25) ===
    { title: 'تحليل معمق: أثر قرار أوبك بلس على الاقتصاد العراقي', content: 'يمثل قرار منظمة أوبك وحلفائها بتخفيض الإنتاج النفطي تحدياً مزدوجاً للاقتصاد العراقي الذي يعتمد على النفط لأكثر من 90% من إيراداته الحكومية. فمن جهة، يدعم القرار أسعار النفط فوق 80 دولاراً للبرميل مما يضمن مستويات إيرادات مقبولة، ومن جهة أخرى يحد من القدرة الإنتاجية للعراق البالغة 5 مليون برميل يومياً. تتطلب الموازنة الاتحادية العراقية سعر برميل يزيد عن 70 دولاراً لتحقيق التوازن المالي، وأي انخفاض دون هذا المستوى يعني عجزاً مالياً يستوجب الاقتراض أو تقليص الإنفاق الاستثماري. التحليل يشير إلى أن العراق بحاجة ماسة لتنويع مصادر الدخل وتقليل الاعتماد على النفط من خلال تطوير القطاعات غير النفطية كالزراعة والسياحة والصناعة. كما يجب الاستفادة من الفوائض النفطية في أوقات الارتفاع لبناء احتياطيات مالية تحمي الاقتصاد في فترات الانخفاض. التجربة النرويجية مع صندوق الثروة السيادية تقدم نموذجاً يمكن الاستفادة منه في إدارة الثروة النفطية العراقية بطريقة مستدامة تحفظ حقوق الأجيال القادمة.', summary: 'تحليل شامل لأثر قرارات أوبك بلس على الإيرادات النفطية والموازنة العراقية مع توصيات لتنويع الاقتصاد', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus, featured: true },
    { title: 'مزاد العملة في العراق: آلية العمل والمخاطر المحتملة', content: 'يُعد مزاد العملة الذي يديره البنك المركزي العراقي من أهم الأدوات المستخدمة للحفاظ على استقرار سعر صرف الدينار مقابل الدولار. يعمل المزاد على تزويد المصارف بالعملة الأجنبية اللازمة لتمويل التجارة الخارجية والتحويلات الشخصية بسعر صرف رسمي ثابت. لكن المزاد واجه انتقادات متعددة تتعلق بتسرب الدولارات إلى أسواق مجاورة واستخدامه في غسيل الأموال وتمويل عمليات تهريب العملة. في العام الماضي، أجرى البنك المركزي إصلاحات جوهرية شملت تشديد شروط المشاركة في المزاد وربط التحويلات بنظام المستندات الدولية وتقليل الحصص الفردية للمصارف. هذه الإصلاحات أدت إلى انخفاض حجم المزاد من 300 مليون دولار يومياً إلى أقل من 150 مليوناً مع تحسن ملحوظ في نسبة الامتثال. التحدي الأكبر يبقى في تحقيق التوازن بين ضبط التهريب وعدم خنق التجارة المشروعة التي تحتاج للعملة الأجنبية لاستيراد السلع الأساسية.', summary: 'دراسة تحليلية لآلية مزاد العملة في البنك المركزي العراقي والإصلاحات الأخيرة', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'القطاع المصرفي العراقي: واقع التحديات وفرق الإصلاح', content: 'يواجه القطاع المصرفي العراقي تحديات هيكلية عميقة تعيق دوره في دعم التنمية الاقتصادية. المصارف الحكومية مثل بنك الرافدين وبنك الرشيد تسيطر على أكثر من 70% من الودائع لكنها تعاني من بيروقراطية شديدة وتقنيات قديمة. في المقابل، تقدم المصارف الأجنبية والمصرف الإسلامي خدمات أفضل لكن حصتها السوقية محدودة. نسبة الشمول المالي في العراق لا تتجاوز 23% وهي من الأدنى في المنطقة مما يعني أن أغلب العراقيين خارج النظام المصرفي الرسمي. التحول الرقمي يمثل فرصة ذهبية لتجاوز هذه التحديات خاصة مع انتشار الهواتف الذكية وتطبيقات الدفع الإلكتروني مثل زين كاش وآسيا حوالة. البنك المركزي يسعى لرفع نسبة الشمول المالي إلى 50% خلال ثلاث سنوات من خلال تسهيل فتح الحسابات المصرفية ودعم المحافظ الإلكترونية وتشجيع المصارف على تقديم خدمات مصرفية رقمية متكاملة.', summary: 'تحليل واقع القطاع المصرفي العراقي واستراتيجيات التحديث والشمول المالي', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'أزمة المياه في العراق: الأبعاد الاقتصادية والسياسية', content: 'تواجه العراق أزمة مياه تاريخية تهدد الأمن الغذايي والاستقرار الاقتصادي في البلاد. يعتمد العراق بشكل شبه كلي على نهري دجلة والفرات اللذين ينبعان من تركيا وإيران، وكلاهما يبني سدوداً تقلل الحصة العراقية بشكل كبير. انخفض تدفق نهر الفرات بأكثر من 50% خلال العقدين الماضيين مما أثر على ملايين الهكتارات من الأراضي الزراعية في وسط وجنوب العراق. اقتصادياً، تقدر خسائر القطاع الزراعي بسبب شح المياه بمليارات الدولارات سنوياً مع هجرة مئات الآلاف من المزارعين نحو المدن. الحلول المقترحة تشمل التفاوض الدولي لضمان الحصص المائية والاستثمار في تقنيات الري الحديثة وإعادة تأهيل شبكات الري المتضررة ومعالجة مشكلة الملوحة في جنوب العراق.', summary: 'دراسة تحليلية لأزمة المياه في العراق وتداعياتها الاقتصادية والاجتماعية', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus, featured: true },
    { title: 'سعر صرف الدينار: بين الثبات والتحرير', content: 'يشكل سعر صرف الدينار العراقي أحد أكثر القضايا الاقتصادية حساسية في الساحة العراقية. منذ قرار تخفيض قيمة الدينار في أواخر 2020 من 1180 إلى 1450 دينار للدولار، والنقاش مستمر حول جدوى العودة للسعر السابق أم التمسك بالسعر الحالي. الحجة الرئيسية للاستقرار عند السعر الحالي تتعلق بتوفير احتياطيات النقد الأجنبي وتقليل العبء على ميزانية البنك المركزي. في المقابل، يرى المؤيدون للعودة أن التخفيض رفع تكاليف الاستيراد بشكل كبير وأدى إلى موجة تضخم ضربت الطبقات الفقيرة والمتوسطة. الحقيقة هي أن أي قرار يتعلق بسعر الصرف يجب أن يكون جزءاً من حزمة إصلاحات اقتصادية شاملة تشمل ضبط الإنفاق الحكومي ومكافحة الفساد وتنويع مصادر الدخل.', summary: 'تحليل خيارات السياسة النقدية بشأن سعر صرف الدينار العراقي', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'اقتصاد ما بعد النفط: رؤية العراق 2030', content: 'تزداد الحاجة يوماً بعد يوم لصياغة رؤية اقتصادية واضحة للعراق تتجاوز الاعتماد على النفط. تجربة الإمارات والسعودية في تنويع الاقتصاد تقدم دروساً قيمة يمكن الاستفادة منها. العراق يمتلك مقومات تنافسية في قطاعات عدة أبرزها الزراعة حيث يملك أراضٍ خصبة ومناخاً متنوعاً والسياحة الدينية التي تجذب ملايين الزوار سنوياً والصناعة التحويلية التي يمكن تطويرها بالاستفادة من المواد الخام المتوفرة محلياً. رؤية 2030 يجب أن تشمل تحديد قطاعات اقتصادية واعدة وتقديم حوافز للمستثمرين المحليين والأجانب وتطوير البنية التحتية الرقمية واللوجستية وإصلاح المنظومة التعليمية لتخريج كوادر قادرة على المنافسة في اقتصاد المعرفة.', summary: 'رؤية استراتيجية لتنويع الاقتصاد العراقي وبناء قطاعات غير نفطية مستدامة', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'التجارة الإلكترونية في العراق: فرص وتحديات سوق ناشئ', content: 'يشهد سوق التجارة الإلكترونية في العراق نمواً متسارعاً مدعوماً بانتشار الهواتف الذكية وتحسن البنية التحتية للإنترنت. تقدر قيمة سوق التجارة الإلكتروني في العراق بنحو 3 مليارات دولار مع توقعات بنمو سنوي يفوق 25%. منصات مثل ماركت العراق وبيك بغداد وبازاريا بدأت تفرض وجودها وتقدم خدمات توصيل متنوعة. التحديات الرئيسية تتمثل في ضعف أنظمة الدفع الإلكتروني وعدم وجود تشريعات واضحة لحماية المستهلك الرقمي ومشاكل البنية اللوجستية في المناطق النائية. الحلول تتطلب تعاوناً بين القطاعين العام والخاص لتطوير بنية تحتية رقمية متكاملة وتشريعات حديثة.', summary: 'تحليل واقع التجارة الإلكترونية في العراق وآفاق تطورها', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الفساد المالي في العراق: الخسائر والحلول المقترحة', content: 'يمثل الفساد المالي أكبر عائق أمام التنمية الاقتصادية في العراق حيث تشير التقديرات إلى هدر مئات المليارات من الدولارات منذ 2003. آليات الفساد تتنوع بين عقود وهمية وتخصيص وظائف وهمية وتهريب أموال عبر المزاد المركزي للعملة ومشاريع استثمارية صورية. مكافحة الفساد تتطلب إصلاحات مؤسسية شاملة تشمل استقلالية القضاء وتفعيل هيئة النزاهة ورقمنة العمليات الحكومية وتعزيز الشفافية في إدارة الأموال العامة ومحاسبة الفاسدين بغض النظر عن مناصبهم.', summary: 'دراسة عن حجم الفساد المالي في العراق وآليات مكافحته', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'العلاقات الاقتصادية العراقية - الإيرانية: تداخلات وتحديات', content: 'تتميز العلاقات الاقتصادية بين العراق وإيران بتعقيد بالغ يجمع بين الروابط التجارية القوية والتبعية الاقتصادية من جهة والتحديات السياسية من جهة أخرى. إيران هي الشريك التجاري الأول للعراق بحجم تبادل يتجاوز 12 مليار دولار سنوياً وتستحوذ على حصة كبيرة من سوق المستلزمات المنزلية والمواد الغذائية والطاقة في العراق. العقوبات الأمريكية على إيران خلقت وضعاً معقداً للعراق الذي يسعى للحفاظ على علاقاته مع الجار الإيراني دون تعريض نظامه المالي لعقوبات ثانوية. ملف الغاز الإيراني المستورد لتشغيل محطات الكهرباء العراقية يبقى الأكثر حساسية حيث يعتمد العراق على إيران لتشغيل محطات توليد رئيسية.', summary: 'تحليل العلاقات الاقتصادية العراقية-الإيرانية وتأثير العقوبات الدولية', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'قطاع التأمين في العراق: سوق واعد ينتظر الانطلاق', content: 'يُعد قطاع التأمين في العراق من القطاعات الواعدة التي لم تستغل إمكاناتها الكاملة بعد. حجم سوق التأمين العراقي لا يتجاوز 200 مليون دولار وهو رقم متواضع مقارنة بحجم الاقتصاد وعدد السكان. التأمين الإلزامي على السيارات يشكل النسبة الأكبر من الأقساط المكتتبة بينما تبقى فروع التأمين على الحياة والتأمين الصحي متخلفة. الصيرفة الإسلامية والتكافل يقدمان فرصة نمو كبيرة خاصة مع تفضيل شريحة واسعة من العراقيين التعاملات المتوافقة مع الشريعة. التحدي يكمن في ضعف الثقة بقطاع التأمين وقلة الوعي بأهمية المنتجات التأمينية والحاجة لتطوير الكوادر المهنية.', summary: 'تحليل قطاع التأمين العراقي وفرص النمو المتاحة', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الاستثمار الأجنبي المباشر في العراق: المعوقات والحلول', content: 'رغم امتلاك العراق لمقومات استثمارية جيدة من موقع استراتيجي وموارد طبيعية وسوق استهلاكية واسعة، إلا أن تدفقات الاستثمار الأجنبي المباشر تبقى دون المستوى المأمول. تشير البيانات إلى أن العراق استقطب أقل من 3 مليارات دولار كاستثمار أجنبي مباشر خلال السنوات الخمس الأخيرة وهو رقم متواضع مقارنة بدول المنطقة. المعوقات الرئيسية تشمل البيروقراطية المفرطة وضعف حماية المستثمر الأجنبي وعدم استقرار الإطار التشريعي وانتشار الفساد الإداري وتعقيد إجراءات تسجيل الشركات والحصول على التراخيص. قانون الاستثمار رقم 13 لسنة 2006 قدم بعض الحوافز لكنه يحتاج لتحديثات جوهرية لتواكب التطورات الاقتصادية العالمية.', summary: 'دراسة معوقات الاستثمار الأجنبي المباشر في العراق واستراتيجيات جذب رأس المال', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الصيرفة الإسلامية في العراق: نمو متسارع وتحديات تنظيمية', content: 'يشهد قطاع الصيرفة الإسلامية في العراق نمواً ملحوظاً مع دخول مصارف إسلامية جديدة وزيادة الطلب على المنتجات المالية المتوافقة مع الشريعة. البنك المركزي أنشأ قسمًا متخصصاً للصيرفة الإسلامية وأصدر تعليمات تنظيمية خاصة بالمصارف الإسلامية. من أبرز التحديات التي يواجهها القطاع هي تطوير أدوات مالية إسلامية مبتكرة قادرة على المنافسة مع المنتجات التقليدية وتأهيل الكوادر البشرية المتخصصة في فقه المعاملات المالية وتوحيد المعايير الشرعية.', summary: 'تقييم نمو الصيرفة الإسلامية في العراق والتحديات التنظيمية', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'أثر التغير المناخي على الاقتصاد العراقي', content: 'يتعرض العراق لتأثيرات التغير المناخي بشكل حاد يجعله من أكثر الدول تأثراً عالمياً. ارتفاع درجات الحرارة بمعدل يفوق المتوسط العالمي وتناقص هطول الأمطار وتكرار العواصف الترابية تهدد القطاعات الحيوية. تقدر الخسائر الاقتصادية الناجمة عن التغير المناخي بنحو 7% من الناتج المحلي الإجمالي بحلول 2050 إذا لم تتخذ إجراءات تكيفية فعالة. الزراعة هي الأكثر تضرراً حيث أدى شح المياه إلى تقليص المساحات المزروعة بنسبة 40% في بعض المحافظات الجنوبية. القطاع الصحي يتكبد تكاليف باهظة بسبب الأمراض المرتبطة بالتلوث والحرارة المفرطة.', summary: 'تحليل تأثيرات التغير المناخي على مختلف القطاعات الاقتصادية العراقية', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'النظام الضريبي العراقي: بين الإصلاح والتحصيل', content: 'يعاني النظام الضريبي العراقي من خلل هيكلي يتمثل في الاعتماد المفرط على الضرائب غير المباشرة وضعف تحصيل الضرائب المباشرة. نسبة الضرائب إلى الناتج المحلي الإجمالي في العراق لا تتجاوز 3% وهي من الأدنى عالمياً. الإصلاح الضريبي المطلوب يشمل تحديث التشريعات وتبسيط الإجراءات ومكافحة التهرب الضريبي وتوسيع القاعدة الضريبية وتطوير أنظمة التحصيل الإلكتروني.', summary: 'دراسة النظام الضريبي العراقي وسبل تطويره', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'سوق العقارات العراقي: فقاعة أم نمو حقيقي؟', content: 'أثار الارتفاع المتسارع في أسعار العقارات العراقية نقاشاً حاداً حول ما إذا كان السوق يشهد نمواً حقيقياً مبنياً على الأساسيات أم فقاعة عقارية خطيرة. أسعار الأراضي في بغداد ارتفعت بنسب تتراوح بين 100 و300% خلال السنوات الخمس الأخيرة مدفوعة بتدفقات النقد النفطي وضعف الفرص الاستثمارية البديلة والطلب المتزايد على السكن. المخاطر تكمن في احتمال انخفاض أسعار النفط مما سيقلل السيولة المتاحة ويعرض السوق لتصحيح حاد.', summary: 'تحليل سوق العقارات العراقي وتقييم مخاطر الفقاعة', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الدين العام العراقي: حجم المخاطر وسبل إدارته', content: 'بلغ الدين العام العراقي مستويات مقلقة تتجاوز 60 مليار دولار وهو ما يمثل نحو 35% من الناتج المحلي الإجمالي. رغم أن هذه النسبة تبدو مقبولة مقارنة بدول أخرى إلا أن المخاطر تكمن في طبيعة الدين وارتباطه بالمتغيرات النفطية. الجزء الأكبر من الدين الخارجي مُقوم بالدولار مما يعرض العراق لمخاطر سعر الصرف. إدارة الدين تتطلب استراتيجية واضحة تشمل جدولة الديون ذات التكلفة العالية والاستفادة من القروض الميسرة وتقليل الاقتراض لأغراض الاستهلاك.', summary: 'تحليل حجم الدين العام العراقي واستراتيجيات إدارته', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'قطاع الكهرباء في العراق: التحديات المستمرة والحلول الممكنة', content: 'يبقى قطاع الكهرباء العراقي أحد أكثر القطاعات تعثراً رغم استثمار عشرات المليارات من الدولارات منذ 2003. المشكلة لا تكمن فقط في القدرة الإنتاجية بل في منظومة التوزيع والتحصيل. الفاقد في شبكة الكهرباء يتجاوز 40% بسبب التقادم والسرقات والتحصيل لا يغطي 20% من التكاليف. الحلول المقترحة تشمل الاستثمار في الطاقة الشمسية وتحسين كفاءة الشبكة وتركيب عدادات ذكية ومكافحة السرقات.', summary: 'تحليل واقع قطاع الكهرباء في العراق وسبل تطويره', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الاقتصاد غير الرسمي في العراق: الحجم والأبعاد', content: 'يُقدر حجم الاقتصاد غير الرسمي في العراق بنحو 40-50% من الناتج المحلي الإجمالي وهو من أعلى النسب عالمياً. يشمل هذا القطاع الأنشطة التجارية غير المسجلة والمهن الحرة غير المنظمة والتهريب والسوق الموازية للنقد الأجنبي. الاقتصاد غير الرسمي يوفر فرص عمل لملايين العراقيين لكنه يحرم الخزينة من إيرادات ضريبية كبيرة ويخلق منافسة غير عادية مع القطاع الرسمي. إدماج هذا القطاع يتطلب تسهيل إجراءات التسجيل وتقديم حوافز ضريبية وتوفير الحماية الاجتماعية للعاملين فيه.', summary: 'دراسة حجم الاقتصاد غير الرسمي في العراق واستراتيجيات إدماجه', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'البطالة في العراق: الأسباب الهيكلية والحلول المستدامة', content: 'تمثل البطالة أحد أخطر التحديات الاقتصادية والاجتماعية في العراق حيث تبلغ النسبة الرسمية نحو 15% بينما تشير تقديرات غير رسمية إلى تجاوزها 30% بين الشباب. البطالة هيكلية بالأساس ناتجة عن خلل في سوق العمل حيث يهيمن القطاع العام على التوظيف بينما يعاني القطاع الخاص من ضعف شديد. سوق العمل العراقي يعاني أيضاً من فجوة بين مخرجات التعليم ومتطلبات سوق العمل وهيمنة الواسطة والمحسوبية في التوظيف.', summary: 'تحليل أزمة البطالة في العراق وأسبابها الهيكلية', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'المنافذ الحدودية العراقية: منابع الفساد وبوابات التجارة', content: 'تمثل المنافذ الحدودية العراقية ثغرة كبيرة في الاقتصاد الوطني حيث تقدر خسائر التهريب الجمركي بمليارات الدولارات سنوماً. العراق يمتلك 14 منفذاً حدودياً برياً إضافة للمطارات والموانئ البحرية. الفساد في المنافذ يتخذ أشكالاً متعددة من الرشوات لتسهيل دخول البضائع إلى التهريب المنظم للمواد الممنوعة. إصلاح المنافذ يتطلب رقمنة الإجراءات وتوحيد الرسوم وتطبيق نظام النافذة الواحدة وتقليل عدد نقاط التفتيش الداخلية.', summary: 'تحليل واقع المنافذ الحدودية العراقية وآليات إصلاحها', category: 'ANALYSIS' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },

    // === OPINION POSTS (20) ===
    { title: 'لماذا يحتاج العراق لصندوق سيادي فوراً؟', content: 'الاعتماد على النفط يجعل اقتصادنا رهين تقلبات الأسواق العالمية. صندوق سيادي يحول الفوائض المؤقتة إلى ثروة دائمة تحمي الأجيال القادمة وتوفر استقراراً مالياً في أوقات الأزمات.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: التحول الرقمي ليس ترفاً بل ضرورة اقتصادية', content: 'العراق يتأخر عن ركب التحول الرقمي بينما تتسارع دول المنطقة في تبني التقنيات الحديثة. الحكومة الإلكترونية والتجارة الرقمية والتعليم عن بعد لم تعد خيارات ثانوية بل ركائز أساسية لاقتصاد حديث ومتنوع.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'هل يمكن للسياحة الدينية إنقاذ الاقتصاد العراقي؟', content: 'تجذب العتبات المقدسة ملايين الزوار سنوياً لكن الإيرادات تبقى دون الإمكانات الحقيقية. الاستثمار في البنية التحتية السياحية وتطوير الخدمات الفندقية يمكن أن يضاعف الإيرادات عدة مرات.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'القطاع الخاص العراقي: مظلومية التشريعات وغياب الدعم', content: 'يعاني رجال الأعمال العراقيون من بيئة تشريعية معقدة وبيروقراطية خانقة ومنافسة غير عادلة مع القطاع العام. الإصلاح الحقيقي يبدأ بتمكين القطاع الخاص من لعب دوره كمحرك أساسي للتنمية.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: التعليم الاقتصادي ضرورة وطنية', content: 'الأمية الاقتصادية في العراق تشكل عائقاً حقيقياً أمام التنمية. المواطن الذي لا يفهم مبادئ الادخار والاستثمار وإدارة المال لا يمكنه المساهمة بفاعلية في بناء اقتصاد قوي.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'المرأة العراقية في سوق العمل: كفاءة مهدرة', content: 'نسبة مشاركة المرأة العراقية في القوى العاملة لا تتجاوز 13% وهي من الأدنى عالمياً. إدماج المرأة اقتصادياً ليس فقط قضية عدالة اجتماعية بل عامل نمو حقيقي يمكن أن يضيف مليارات الدولارات للناتج المحلي.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'لماذا فشلت خطط التنويع الاقتصادي في العراق؟', content: 'رغم الحديث المتكرر عن التنويع الاقتصادي منذ عقود لم تتحقق إنجازات ملموسة على أرض الواقع. السبب الأساسي هو غياب الإرادة السياسية الحقيقية والتنفيذ الجاد والاستمرارية في تطبيق الخطط المرسومة.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: الزراعة العراقية يمكن أن تكون العمود الفقري للاقتصاد', content: 'يمتلك العراق أراضٍ زراعية شاسعة ومناخاً متنوعاً وموارد مائية كافية إن أُديرت بشكل صحيح. إعادة إحياء القطاع الزراعي يمكن أن يوفر ملايين فرص العمل ويقلل الاعتماد على الاستيراد.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الريادة والابتكار: الطريق نحو اقتصاد المعرفة', content: 'الشباب العراقي يمتلك طاقات إبداعية هائلة تحتاج فقط لبيئة محفزة ودعم مؤسسي. حاضنات الأعمال والتمويل الجريء والتشريعات الداعمة يمكن أن تحول العراق لمركز إقليمي للابتكار.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: الشفافية المالية مفتاح الثقة الاقتصادية', content: 'غياب الشفافية في إدارة الأموال العامة يقوض ثقة المواطن والمستثمر على حد سواء. نشر البيانات المالية الحكومية وفتح المعلومات للمواطنين خطوة أساسية نحو بناء اقتصاد نزيه ومستدام.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'الاتفاقيات التجارية العراقية: هل تخدم المصالح الوطنية؟', content: 'تشكيل الاتفاقيات التجارية يجب أن يراعي التوازن بين فتح الأسواق وحماية المنتج المحلي. بعض الاتفاقيات الحالية تخدم الأطراف الأخرى أكثر مما تخدم الاقتصاد العراقي.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: الإصلاح المصرفي شرط لا غنى عنه للتنمية', content: 'بدون نظام مصرفي فعال وشفاف لن يتمكن العراق من بناء اقتصاد تنافسي. المصارف الحكومية بحاجة لإعادة هيكلة جذرية والمصارف الخاصة تحتاج لمزيد من الصلاحيات والحوافز.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'أزمة السكن في العراق: حلول جذرية مطلوبة', content: 'يواجه ملايين العراقيين أزمة سكن حادة مع ارتفاع أسعار العقارات والإيجارات. الحلول الجذرية تتطلب إطلاق مشاريع إسكان وطنية ضخمة وتقديم قروض عقارية ميسرة وتفعيل قانون الإيجار الجديد.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: اللامركزية الاقتصادية مفتاح التنمية المتوازنة', content: 'تركيز القرارات الاقتصادية في بغداد أضر بالمحافظات الأخرى وعطل تنميتها. منح المحافظات صلاحيات اقتصادية أوسع سيسرع من وتيرة التنمية ويقلل الفوارق الإقليمية.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'التبعية الاقتصادية للنفط: سجن ذهبي ينبغي الخروج منه', content: 'الاعتماد على النفط يمنحنا راحة مؤقتة لكنه يسلبنا القدرة على بناء اقتصاد مقاوم للصدمات. كل يوم نؤجل التنويع الاقتصادي هو يوم يزيد من ضعفنا الهيكلي.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: الإصلاح الضريبي ضرورة ملحة', content: 'النظام الضريبي العراقي ظالم وغير فعال. يضغط على الموظفين ذوي الدخل المحدود بينما يفلت كبار التجار والمهنيون من الالتزامات الضريبية. الإصلاح يجب أن يكون عادلاً وشاملاً.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'التجارة الحدودية: فرصة اقتصادية أم منفذ للتهريب؟', content: 'المناطق الحدودية في العراق تعج بالنشاط التجاري لكن جزءاً كبيراً منه غير رسمي. تنظيم هذه التجارة وتحويلها لقنوات رسمية يمكن أن يضيف مليارات الدولارات للاقتصاد.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: الاستثمار في رأس المال البشري أهم من البنية التحتية', content: 'بناء المدارس والمستشفيات دون الاستثمار في المعلمين والأطباء يعد هدراً للموارد. التنمية الحقيقية تبدأ بالإنسان وأولوية الإنفاق يجب أن تتجه نحو التعليم والصحة.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'المعونات الاجتماعية: تحول من الإعانة إلى التمكين', content: 'برامج الإعانات الحالية تخلق تبعية بدلاً من تمكين المواطنين اقتصادياً. التحويل نحو برامج التدريب المهني وريادة الأعمال والتمويل الصغير أكثر فعالية واستدامة.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },
    { title: 'رأي: الشراكة بين القطاعين العام والخاص نموذج ناجح عالمياً', content: 'تجارب الدول الناجحة تثبت أن الشراكة بين القطاعين العام والخاص يمكن أن تحقق إنجازات كبيرة في البنية التحتية والخدمات. العراق يحتاج لإطار تشريعي واضح ينظم هذه الشراكات ويحمي المصلحة العامة.', category: 'OPINION' as ArticleCategory, mediaType: 'POST', status: 'PUBLISHED' as ArticleStatus },

    // === REPORT ARTICLES (15) ===
    { title: 'تقرير: أداء الاقتصاد العراقي خلال الربع الأول من 2026', content: 'شهد الاقتصاد العراقي خلال الربع الأول من عام 2026 أداءً متبايناً بين استقرار نسبي في القطاع النفطي وتحديات مستمرة في القطاعات غير النفطية. بلغ متوسط إنتاج النفط 4.3 مليون برميل يومياً بمتوسط سعر 82 دولاراً مما حقق إيرادات بقيمة 31 مليار دولار. معدل النمو الاقتصادي بلغ 2.8% مدفوعاً بالنفط بينما سجل القطاع غير النفطي نمواً متواضعاً بنسبة 1.2%. التضخم استقر عند 3.8% واحتياطي النقد الأجنبي ارتفع إلى 68 مليار دولار. الصادرات غير النفطية شكلت 2% فقط من إجمالي الصادرات مما يؤكد استمرار الاعتماد المفرط على النفط.', summary: 'تقرير فصلي شامل عن أداء الاقتصاد العراقي مع إحصائيات ومؤشرات رئيسية', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus, featured: true },
    { title: 'تقرير صادر عن البنك المركزي: استقرار القطاع المالي', content: 'أصدر البنك المركزي العراقي تقريره السنوي عن استقرار القطاع المالي والذي أكد استقرار النظام المالي خلال العام الماضي مع تحسن في مؤشرات كفاية رأس المال ونسبة القروض المتعثرة. كفاية رأس مال القطاع المصرفي بلغت 15.3% متجاوزة الحد الأدنى المطلوب بنسبة 12%. نسبة القروض المتعثرة انخفضت من 8.5% إلى 6.2% بفضل سياسات إعادة هيكلة الديون. التحويلات الإلكترونية ارتفعت بنسبة 45% مما يعكس تقدماً في التحول الرقمي.', summary: 'تقرير البنك المركزي السنوي عن استقرار القطاع المالي العراقي', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير هيئة الاستثمار: المشاريع المرخصة خلال 2025', content: 'أصدرت الهيئة الوطنية للاستثمار تقريراً مفصلاً عن المشاريع المرخصة التي بلغت 87 مشروعاً باستثمارات إجمالية قدرها 4.2 مليار دولار. القطاع الصناعي حصل على النصيب الأكبر بنسبة 35% يليه القطاع العقاري بنسبة 28% ثم القطاع الزراعي بنسبة 15%. المشاريع المنجزة بلغت 23 مشروعاً فقط مما يشير إلى بطء التنفيذ.', summary: 'تقرير شامل عن المشاريع الاستثمارية المرخصة في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير الجهاز المركزي للإحصاء: المؤشرات السكانية والاقتصادية', content: 'أصدر الجهاز المركزي للإحصاء تقريره السنوي الذي يتضمن أحدث البيانات السكانية والاقتصادية. يقدر عدد سكان العراق بنحو 44 مليون نسمة بمعدل نمو سنوي 2.4%. نسبة السكان دون سن 25 تمثل 60% من إجمالي السكان مما يشكل فرصة ديموغرافية و تحدياً توظيفياً في آن واحد. معدل البطالة بين الشباب بلغ 28% وهو ضعف المعدل العام.', summary: 'تقرير إحصائي شامل عن المؤشرات السكانية والاقتصادية في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير قطاعي: واقع الصناعة العراقية', content: 'يشكل القطاع الصناعي نحو 2% فقط من الناتج المحلي الإجمالي العراقي وهي نسبة متدنية جداً تعكس تراجع القطاع بشكل حاد منذ ثمانينيات القرن الماضي. المصانع الحكومية تعمل بطاقة إنتاجية لا تتجاوز 20% بينما يواجه القطاع الخاص الصناعي تحديات متعددة أبرزها ارتفاع تكاليف الطاقة وضعف البنية التحتية والمنافسة غير المتكافئة مع السلع المستوردة.', summary: 'تقرير عن واقع القطاع الصناعي العراقي وتحدياته', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: حجم التبادل التجاري العراقي مع دول الجوار', content: 'بلغ حجم التبادل التجاري العراقي مع دول الجوار 28 مليار دولار خلال العام الماضي. تركيا تأتي في المركز الأول بحجم تبادل يتجاوز 14 مليار دولار تليها إيران بـ 12 مليار دولار. الصادرات العراقية لدول الجوار تقتصر على النفط والمشتقات بينما تشمل الواردات مجموعة واسعة من السلع الاستهلاكية والغذائية والصناعية.', summary: 'تقرير عن حجم التبادل التجاري العراقي مع الدول المجاورة', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير الأمن الغذائي في العراق 2026', content: 'كشف تقرير الأمن الغذايي الصادر عن وزارة التخطيط عن تدهور مؤشرات الأمن الغذايي في العراق حيث يعتمد البلد على الاستيراد لتلبية أكثر من 60% من احتياجاته الغذايية. فاتورة الاستيراد الغذايي تتجاوز 8 مليارات دولار سنوياً مع توقعات بارتفاعها بسبب التضخم العالمي وأزمات المناخ.', summary: 'تقرير عن حالة الأمن الغذائي في العراق وتحدياته', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: واقع النقل والمواصلات في العراق', content: 'يعاني قطاع النقل والمواصلات في العراق من إهمال طويل أدى إلى تدهور البنية التحتية بشكل كبير. شبكة السكك الحديدية متوقفة منذ سنوات والمطارات الإقليمية تعاني من قصور في الخدمات وميناء أم قصر بحاجة لتطوير عاجل. خسائر الاقتصاد العراقي بسبب سوء البنية التحتية للنقل تقدر بنحو 5 مليارات دولار سنوياً.', summary: 'تقرير عن واقع قطاع النقل والمواصلات في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: التعليم العالي وسوق العمل في العراق', content: 'كشف تقرير مشترك بين وزارة التعليم ووزارة التخطيط عن فجوة كبيرة بين مخرجات التعليم العالي ومتطلبات سوق العمل. 65% من خريجي الجامعات العراقية يعملون خارج تخصصاتهم ونسبة البطالة بين حملة الشهادات الجامعية تصل إلى 22%.', summary: 'تقرير عن العلاقة بين التعليم العالي وسوق العمل', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: واقع الخدمات الصحية في العراق', content: 'يواجه القطاع الصحي العراقي تحديات متعددة أبرزها نقص الأطباء المتخصصين حيث لا تتجاوز نسبة الأطباء لكل 1000 مواطن 0.8 طبيب مقارنة بالمعدل العالمي البالغ 1.5. الإنفاق الصحي لا يتجاوز 3% من الموازنة العامة وهو أقل من توصيات منظمة الصحة العالمية بـ 5% على الأقل.', summary: 'تقرير عن واقع الخدمات الصحية في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: قطاع الاتصالات وتكنولوجيا المعلومات', content: 'شهد قطاع الاتصالات في العراق نمواً ملحوظاً حيث تجاوز عدد المشتركين في خدمات الإنترنت 30 مليون مشترك بنسبة انتشار تصل إلى 68%. شركات الاتصالات الثلاث الكبرى زين وآسيا وكورك تنافسية بقوة خاصة في خدمات البيانات والإنترنت.', summary: 'تقرير عن قطاع الاتصالات وتكنولوجيا المعلومات في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: واقع الطاقة المتجددة في العراق', content: 'رغم الإمكانات الشمسية الهائلة التي يتمتع بها العراق حيث تتجاوز سطوع الشمس 3000 ساعة سنوياً، إلا أن مساهمة الطاقة المتجددة في مزيج الطاقة لا تتجاوز 1%. أول مشروع شمسي كبير بطاقة 100 ميغاواط في الناصرية بدأ العمل هذا العام مع خطط لبلوغ 5 غيغاواط بحلول 2030.', summary: 'تقرير عن واقع الطاقة المتجددة ومشاريعها في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: أداء بورصة بغداد للأوراق المالية', content: 'سجلت بورصة بغداد أداءً مميزاً خلال النصف الأول من العام حيث ارتفع مؤشر السوق العام بنسبة 15% مدعوماً بارتفاع أسهم المصارف وشركات الاتصالات. عدد الشركات المدرجة بلغ 102 شركة بقيمة سوقية إجمالية تتجاوز 3 تريليون دينار. حجم التداول اليومي ارتفع بنسبة 40% مقارنة بالعام السابق.', summary: 'تقرير عن أداء بورصة بغداد ومؤشرات التداول', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: المنافسة في السوق العراقي', content: 'أصدرت هيئة حماية المستهلك تقريراً عن واقع المنافسة في السوق العراقي كشف عن هيمنة شركات قليلة على قطاعات حيوية كالاتصالات والإسمنت والحديد مما يؤدي لارتفاع الأسعار وضعف جودة الخدمات. التوصيات شملت تعزيز دور هيئة المنافسة وفتح الأسواق أمام المنافسين الجدد.', summary: 'تقرير عن واقع المنافسة في الأسواق العراقية', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'تقرير: المرأة والاقتصاد في العراق', content: 'كشف تقرير حديث عن تفاقم الفجوة الاقتصادية بين الجنسين في العراق حيث تحتل البلاد مراتب متأخرة في مؤشرات المشاركة الاقتصادية للمرأة. فقط 13% من النساء العراقيات في سن العمل يمارسن نشاطاً اقتصادياً مقابل 70% للرجال. الفجوة في الأجور بين الجنسين تصل إلى 35%.', summary: 'تقرير عن وضع المرأة اقتصادياً في العراق', category: 'REPORT' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },

    // === RESEARCH ARTICLES (15) ===
    { title: 'بحث: أثر السياسة النقدية على التضخم في العراق 2015-2025', content: 'تهدف هذه الدراسة إلى تحليل أثر أدوات السياسة النقدية التي يستخدمها البنك المركزي العراقي على معدلات التضخم خلال الفترة 2015-2025. استخدمت الدراسة منهجية الاقتصاد القياسي بتطبيق نموذج الانحدار الذاتي للفجوات الموزعة المبطأة للفحص المشترك لعلاقة السببية طويلة الأمد بين سعر الفائدة وعرض النقود وسعر الصرف ومعدل التضخم. أظهرت النتائج وجود علاقة عكسية ذات دلالة إحصائية بين سعر الفائدة والتضخم بينما كان أثر عرض النقود إيجابياً ومعنوياً. سعر الصرف أثر بشكل محدود على التضخم في الأجل القصير لكن تأثيره يتعاظم في الأجل الطويل.', summary: 'بحث قياسي يحلل أثر أدوات السياسة النقدية على معدلات التضخم في العراق', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تقييم كفاءة الإنفاق العام في العراق', content: 'تناولت هذه الدراسة تقييم كفاءة الإنفاق العام في العراق باستخدام منهجية تحليل المغلف البياني ومؤشرات كفاءة الإنفاق الصحي والتعليمي مقارنة بدول المنطقة. توصلت الدراسة إلى أن كفاءة الإنفاق العام في العراق متدنية حيث يحتل المرتبة 11 من أصل 14 دولة عربية. الهدر في الإنفاق الاستثماري يقدر بنحو 35% بسبب سوء التخطيط والفساد وتأخر التنفيذ.', summary: 'بحث أكاديمي لتقييم كفاءة الإنفاق العام في العراق', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: العلاقة بين الانفتاح التجاري والنمو الاقتصادي', content: 'بحثت هذه الدراسة في طبيعة العلاقة السببية بين الانفتاح التجاري والنمو الاقتصادي في العراق خلال الفترة 2004-2025. باستخدام منهجية تودا وياماموتو للسببية توصلت الدراسة إلى وجود علاقة سببية أحادية الاتجاه من النمو الاقتصادي نحو الانفتاح التجاري وليس العكس مما يعني أن النمو الاقتصادي في العراق مدفوع بالنفط وليس بالتجارة الحرة.', summary: 'بحث أكاديمي في العلاقة بين الانفتاح التجاري والنمو الاقتصادي العراقي', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: دور التمويل الأصغر في الحد من الفقر في العراق', content: 'هدفت هذه الدراسة إلى تقييم دور برامج التمويل الأصغر في الحد من الفقر وتمكين المرأة اقتصادياً في المحافظات العراقية. شملت الدراسة عينة من 500 مستفيدة من برامج التمويل الأصغر في بغداد والبصرة وأربيل. أظهرت النتائج تحسن دخل 73% من المستفيدات وزيادة قدرتهن على الادخار بنسبة 45% وتحسن مؤشرات الصحة والتعليم لأسرهن.', summary: 'بحث ميداني عن أثر التمويل الأصغر على الحد من الفقر', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: تحليل هيكل الصادرات العراقية وفرص التنويع', content: 'قدمت هذه الدراسة تحليلاً مفصلاً لهيكل الصادرات العراقية خلال العقدين الماضيين مع التركيز على فرص تنويع الصادرات غير النفطية. أظهرت النتائج أن الصادرات النفطية تشكل 98% من إجمالي الصادرات بينما تشكل التمور والمنتجات الزراعية والجلود والكبريت النسبة الباقية. الدراسة حددت فرصاً واعدة في تصدير المنتجات البتروكيميائية والأسمدة والتمور عالية الجودة والمنتجات الحرفية.', summary: 'بحث تحليلي لهيكل الصادرات العراقية وآفاق التنويع', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: أثر التحول الرقمي على الشمول المالي في العراق', content: 'استكشفت هذه الدراسة أثر التحول الرقمي في القطاع المصرفي على توسيع نطاق الشمول المالي في العراق. أظهرت النتائج أن استخدام المحافظ الإلكترونية ارتفع من 2% إلى 18% خلال ثلاث سنوات وأن التحويلات الرقمية ساهمت بنسبة 35% من إجمالي التحويلات الشخصية. التحدي الأكبر يكمن في ضعف البنية التحتية الرقمية في المناطق الريفية وانعدام الثقة بالنظام المالي الرقمي.', summary: 'بحث عن أثر التحول الرقمي على الشمول المالي', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: اقتصاديات إعادة تدوير النفايات في بغداد', content: 'تناول هذا البحث الجدوى الاقتصادية والبيئية لمشاريع إعادة تدوير النفايات في بغداد التي تنتج نحو 8 آلاف طن من النفايات يومياً. أظهرت الدراسة أن إعادة تدوير 50% من النفايات القابلة للتدوير يمكن أن تولد إيرادات سنوية تبلغ 200 مليون دولار وتوفر أكثر من 10 آلاف فرصة عمل مباشرة وغير مباشرة مع تقليل التلوث البيئي.', summary: 'بحث عن جدوى إعادة تدوير النفايات في بغداد', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تأثير سعر الصرف على الميزان التجاري العراقي', content: 'حللت هذه الدراسة تأثير التغيرات في سعر صرف الدينار العراقي على الميزان التجاري خلال الفترة 2010-2025. توصلت إلى أن تخفيض قيمة الدينار لم يؤدِ لتحسين الميزان التجاري كما تنص نظرية مارشال-ليرنر لأن الطلب العراقي على الواردات غير مرن بسبب اعتماد البلد على السلع الأساسية المستوردة التي لا بديل محلياً لها.', summary: 'بحث اقتصادي قياسي حول أثر سعر الصرف على الميزان التجاري', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: نمذجة التنبؤ بأسعار النفط وأثرها على الموازنة العراقية', content: 'طورت هذه الدراسة نموذجاً قياسياً للتنبؤ بأسعار النفط باستخدام شبكات الذاكرة الطويلة قصيرة المدى ومقارنتها بالنماذج التقليدية. أظهرت النتائج تفوق نموذج الشبكات العصبية بدقة تنبؤ تصل إلى 89%. بناءً على النموذج تم حساب سعر التوازن للموازنة العراقية الذي يضمن تغطية النفقات دون عجز والذي بلغ 74 دولاراً للبرميل.', summary: 'بحث تطبيقي لنمذجة أسعار النفط وتأثيرها على الموازنة', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: التحليل الاقتصادي لقطاع السياحة الدينية في النجف وكربلاء', content: 'قامت هذه الدراسة بتحليل اقتصادي شامل لقطاع السياحة الدينية في محافظتي النجف وكربلاء اللتين تستقبلان أكثر من 15 مليون زائر سنوياً. أظهرت النتائج أن متوسط إنفاق الزائر يبلغ 350 دولاراً فقط مقارنة بـ 1200 دولار في الدول المنافسة مما يشير لضعف جودة الخدمات السياحية. الدراسة أوصت بالاستثمار في الفنادق ذات التصنيف العالمي وتطوير قطاع النقل السياحي وتنويع المنتجات السياحية.', summary: 'دراسة اقتصادية لقطاع السياحة الدينية في العتبات المقدسة', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: دور الموانئ العراقية في تنمية التجارة الخارجية', content: 'ركّز هذا البحث على تقييم أداء الموانئ العراقية خاصة ميناء أم قصر وأثرها في تنمية التجارة الخارجية. أظهرت النتائج أن وقت الانتظار للسفن في ميناء أم قصر يصل إلى 7 أيام مقارنة بيوم واحد في ميناء جبل علي الإماراتي مما يزيد التكاليف ويضعف التنافسية. الحلول تشمل تطوير البنية التحتية ورقمنة الإجراءات وتوسيع الأرصفة.', summary: 'بحث عن دور الموانئ في تنمية التجارة الخارجية العراقية', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: اقتصاديات المياه في حوضي دجلة والفرات', content: 'قدمت هذه الدراسة تحليلاً اقتصادياً لأزمة المياه في حوضي نهري دجلة والفرات وتداعياتها على القطاع الزراعي العراقي. قدرت الدراسة الخسائر الاقتصادية الناجمة عن شح المياه بنحو 4 مليارات دولار سنوياً مع توقعات بارتفاعها إلى 8 مليارات بحلول 2035 إذا استمرت الاتجاهات الحالية.', summary: 'دراسة اقتصادية لأزمة المياه في حوضي دجلة والفرات', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: تقييم فعالية السياسات الزراعية في العراق', content: 'قيّم هذا البحث فعالية السياسات الزراعية المتبعة في العراق خلال الفترة 2010-2025 باستخدام مؤشرات الإنتاجية والاكتفاء الذاتي. أظهرت النتائج تراجع نسبة الاكتفاء الذاتي في القمح من 60% إلى 35% رغم تخصيص ميزانيات ضخمة للدعم الزراعي. الفجوة تكمن في عدم وصول الدعم للمستفيدين الحقيقيين وغياب الرقابة على جودة المدخلات الزراعية.', summary: 'بحث تقييمي لفعالية السياسات الزراعية العراقية', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: التحليل المكاني للفقر في المحافظات العراقية', content: 'استخدمت هذه الدراسة تقنيات نظم المعلومات الجغرافية لتحليل التوزيع المكاني للفقر في المحافظات العراقية الثماني عشرة. كشفت النتائج عن تفاوتات حادة حيث تبلغ نسبة الفقر في المثنى وديالى أكثر من 40% مقابل أقل من 10% في أربيل وبغداد. العوامل المؤثرة تشمل البطالة وانخفاض مستوى التعليم وضعف البنية التحتية والتبعية الاقتصادية للزراعة.', summary: 'دراسة مكانية لتوزيع الفقر في المحافظات العراقية', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'بحث: آليات تمويل المشاريع الصغيرة والمتوسطة في العراق', content: 'استعرض هذا البحث الآليات التمويلية المتاحة للمشاريع الصغيرة والمتوسطة في العراق وقيّم فعاليتها. أظهرت النتائج أن 85% من أصحاب المشاريع يواجهون صعوبات في الحصول على تمويل بنكي بسبب اشتراطات الضمانات العالية وإجراءات الموافقة المعقدة. الحلول البديلة تشمل صناديق التمويل الجريء والتمويل الجماعي والبرامج الحكومية الميسرة.', summary: 'بحث عن آليات تمويل المشاريع الصغيرة والمتوسطة في العراق', category: 'RESEARCH' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },

    // === STUDY ARTICLES (15) ===
    { title: 'دراسة: مقارنة النموذج الاقتصادي العراقي مع نماذج دول الخليج', content: 'تناولت هذه الدراسة المقارنة مقاربة منهجية بين النموذج الاقتصادي العراقي ونماذج دول الخليج العربي خاصة الإمارات والسعودية وعُمان. رغم اشتراك العراق مع دول الخليج في الاعتماد على النفط إلا أن الفوارق كبيرة في مجالات التنويع الاقتصادي والشفافية المالية وجودة المؤسسات. الإمارات نجحت في رفع مساهمة القطاع غير النفطي إلى 70% من الناتج المحلي بينما لا يزال العراق يعتمد على النفط بنسبة 95% من الإيرادات. العوامل التفسيرية تشمل استقرار السياسات الاقتصادية والاستثمار في رأس المال البشري والبنية التحتية المؤسسية القوية.', summary: 'دراسة مقارنة بين النموذج الاقتصادي العراقي ونماذج خليجية', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة حالة: تجربة بنك الرافدين في التحول الرقمي', content: 'تناولت هذه الدراسة تجربة بنك الرافدين وهو أكبر مصرف حكومي عراقي في التحول نحو الخدمات المصرفية الرقمية. البنك الذي يخدم أكثر من 5 ملايين عميل بدأ مشروع التحول الرقمي عام 2024 بتطبيق مصرفي ذكي ونظام إلكتروني متكامل للحوالات. المرحلة الأولى شملت رقمنة عمليات الإيداع والسحب والتحويل وفتح الحسابات إلكترونياً. النتائج الأولية أظهرت ارتفاع رضا العملاء بنسبة 40% وتقليل وقت المعاملات من 30 دقيقة إلى 5 دقائق.', summary: 'دراسة حالة عن تحول بنك الرافدين الرقمي', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تقييم أثر برنامج الإقراض الزراعي', content: 'قيّمت هذه الدراسة أثر برنامج الإقراض الزراعي الذي تنفذه المصارف المتخصصة بالتعاون مع وزارة الزراعة على الإنتاجية والدخل في القطاع الزراعي. شملت العينة 300 مزارع مستفيد في ست محافظات. أظهرت النتائج تحسن الإنتاجية بنسبة 35% في المتوسط وزيادة الدخل بنسبة 28% للمستفيدين مقارنة بغيرهم.', summary: 'دراسة تقييمية لبرنامج الإقراض الزراعي في العراق', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تحليل سوق العمل العراقي والفجوات المهارية', content: 'حللت هذه الدراسة سوق العمل العراقي وحددت الفجوات المهارية الرئيسية التي تعيق التوظيف والإنتاجية. أظهرت النتائج وجود طلب مرتفع على مهارات التقنية المالية وإدارة المشاريع والتسويق الرقمي واللغات الأجنبية بينما تشكل مخرجات التعليم النظرية عبئاً على سوق العمل. 78% من أصحاب العمل يفضلون الخبرة العملية على الشهادات الأكاديمية.', summary: 'دراسة تحليلية لسوق العمل العراقي وفجوات المهارات', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تأثير التدفقات النفطية على أسعار الصرف في الأسواق الموازية', content: 'درست هذه الورقة العلاقة بين حجم التدفقات النفطية والفارق بين سعر الصرف الرسمي وسعر السوق الموازية في العراق. وجدت أن الفارق يتراوح بين 2-8% ويتأثر بشكل أساسي بمخاطر العقوبات المصرفية ومحدودية قنوات التحويل الخارجي أكثر من حجم السيولة النفطية.', summary: 'دراسة عن تأثير التدفقات النفطية على أسعار الصرف الموازية', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: الاقتصاد السياسي للفساد في العراق - تحليل مؤسسي', content: 'اعتمدت هذه الدراسة على الإطار المؤسسي لتحليل جذور الفساد في العراق وعلاقته بهيكل الدولة الريعية. النتائج تشير إلى أن الاقتصاد الريعي النفطي يخلق حوافز هيكلية للفساد من خلال توزيع الريع بدون رقابة فعالة وغياب المساءلة. الإصلاح يتطلب تحولاً جذرياً في بنية الدولة الاقتصادية نحو الاعتماد على الضرائب بدل النفط.', summary: 'دراسة في الاقتصاد السياسي للفساد في العراق', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة حالة: منصة زين كاش والتحول نحو المدفوعات الرقمية', content: 'تناولت هذه الدراسة حالة منصة زين كاش كنموذج ناجح للتحول نحو المدفوعات الرقمية في العراق. المنصة التي أطلقت عام 2015 نمت لتخدم أكثر من 4 ملايين مستخدم وتعالج تحويلات بقيمة تتجاوز 2 مليار دولار سنوياً. عوامل النجاح تشمل البنية التحتية القوية لشركة زين والشراكات مع المصارف والقطاع الحكومي وسهولة الاستخدام.', summary: 'دراسة حالة عن منصة زين كاش كنموذج للدفع الرقمي', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تقييم سياسات الدعم السلعي في العراق', content: 'تناولت هذه الدراسة تقييم نظام الدعم السلعي المتبع في العراق خاصة التمويل الذاتي للمواد الغذائية. النظام الحالي يعاني من تسرب كبير حيث لا يستفيد المستهدفون الفعليون بالكامل وتقدر نسبة التسرب بنحو 30%. البديل المقترح هو التحول نحو التحويلات النقدية المشروطة الموجهة للفئات الأحق.', summary: 'دراسة تقييمية لسياسات الدعم السلعي في العراق', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: العلاقة بين التعليم التقني والمهني وسوق العمل', content: 'بحثت هذه الدراسة في مدى توافق مخرجات التعليم التقني والمهني مع متطلبات سوق العمل العراقي. أظهرت النتائج أن 62% من خريجي المعاهد التقنية يجدون فرص عمل خلال سنة واحدة مقارنة بـ 28% فقط لخريجي الكليات النظرية مما يؤكد أهمية التعليم المهني.', summary: 'دراسة عن العلاقة بين التعليم المهني وسوق العمل', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تحليل سلاسل القيمة في القطاع الزراعي العراقي', content: 'حللت هذه الدراسة سلاسل القيمة لأهم المنتجات الزراعية العراقية: التمور والقمح والطماطم. كشفت النتائج عن فاقد يتراوح بين 25-40% في مراحل ما بعد الحصاد بسبب ضعف التخزين والنقل والتصنيع. الاستثمار في سلاسل القيمة يمكن أن يضاعف قيمة المنتجات الزراعية ويوفر ملايين فرص العمل.', summary: 'دراسة تحليلية لسلاسل القيمة في القطاع الزراعي', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: اقتصاديات الطاقة الشمسية في جنوب العراق', content: 'قيّمت هذه الدراسة الجدوى الاقتصادية لمشاريع الطاقة الشمسية في محافظات جنوب العراق التي تتمتع بأعلى معدلات الإشعاع الشمسي عالمياً. أظهرت النتائج أن تكلفة إنتاج الكهرباء الشمسية انخفضت إلى 3 سنتات لكل كيلووات ساعة مما يجعلها تنافسية مقارنة بالتوليد التقليدي بالغاز.', summary: 'دراسة جدوى اقتصادية للطاقة الشمسية في جنوب العراق', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: واقع وآفاق الصادرات العراقية غير النفطية', content: 'استعرضت هذه الدراسة واقع الصادرات العراقية غير النفطية وحددت الفرص والتحديات أمام تطويرها. التمور العراقية تشكل أهم الصادرات الزراعية بحصة سوقية عالمية تبلغ 7% رغم تراجعها من 80% في السبعينيات. المنتجات البتروكيميائية والأسمدة تمثل فرصاً واعدة للاستفادة من المواد الخال النفطية.', summary: 'دراسة عن واقع وآفاق الصادرات غير النفطية العراقية', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تقييم البنية التحتية الرقمية في العراق', content: 'قيّمت هذه الدراسة جاهزية البنية التحتية الرقمية في العراق للتحول نحو الاقتصاد الرقمي. أظهرت النتائج أن سرعة الإنترنت في العراق لا تزال دون المتوسط الإقليمي وأن نسبة تغطية شبكات الجيل الرابع لا تتجاوز 55% من المناطق الحضرية. مركز البيانات الحكومي بحاجة لتحديث شامل والبنية التحتية السيبرانية تحتاج لتعزيزات أمنية كبيرة.', summary: 'دراسة تقييمية للبنية التحتية الرقمية في العراق', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: نموذج اقتصادي لتحليل أثر الدعم الحكومي على القطاع الصناعي', content: 'طورت هذه الدراسة نموذجاً اقتصادياً لتحليل أثر الدعم الحكومي على أداء القطاع الصناعي العراقي. أظهرت المحاكاة أن الدعم الموجه للمواد الخام والطاقة أكثر فعالية من الدعم المباشر للمنتجات النهائية وأن الشرط الأساسي لنجاح الدعم هو وجود نظام رقابي فعال يمنع الفساد والتسرب.', summary: 'دراسة لنمذجة أثر الدعم الحكومي على القطاع الصناعي', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
    { title: 'دراسة: تحليل العلاقة بين الإنفاق العسكري والتنمية الاقتصادية', content: 'بحثت هذه الدراسة في العلاقة بين حجم الإنفاق العسكري والإنفاق على التنمية في العراق. أظهرت النتائج أن العراق يخصص نحو 15% من موازنته للإنفاق العسكري مقارنة بـ 5% للإنفاق الاستثماري التنموي. إعادة توجيه جزء من الإنفاق العسكري نحو التعليم والبنية التحتية يمكن أن تعزز النمو الاقتصادي بنسبة 1.5% سنوياً.', summary: 'دراسة تحليلية للعلاقة بين الإنفاق العسكري والتنمية', category: 'STUDY' as ArticleCategory, mediaType: 'ARTICLE', status: 'PUBLISHED' as ArticleStatus },
  ]

  const articles: any[] = []
  for (let i = 0; i < articlesData.length; i++) {
    const ad = articlesData[i]
    const author = allAuthors[i % allAuthors.length]
    const article = await prisma.article.create({
      data: {
        ...ad,
        authorId: author.id,
        viewCount: randomInt(50, 5000),
        likeCount: randomInt(5, 200),
        commentCount: randomInt(0, 30),
        createdAt: randomDate(90),
      }
    })
    articles.push(article)
  }
  console.log(`✅ تم إنشاء ${articles.length} منشور ومقال`)

  // ════════════════════════════════════════════
  // 3. HASHTAGS
  // ════════════════════════════════════════════
  console.log('# إنشاء الوسوم...')
  const tagNames = ['النفط_العراقي', 'سعر_الصرف', 'بورصة_بغداد', 'الاستثمار_الأجنبي', 'القطاع_المصرفي', 'التجارة_الدولية', 'الاقتصاد_الزراعي', 'البنية_التحتية', 'الاقتصاد_الرقمي', 'المالية_العامة', 'التنمية_المستدامة', 'السياحة_الدينية', 'العقارات', 'التأمين', 'التعليم_الاقتصادي', 'أوبك', 'البنك_المركزي', 'الموازنة_الاتحادية', 'الدينار_العراقي', 'الصيرفة_الإسلامية', 'الطاقة_المتجددة', 'الفساد_المالي', 'الشمول_المالي', 'ريادة_الأعمال', 'التمويل_الأصغر', 'أزمة_المياه', 'التضخم', 'البطالة', 'الدين_العام', 'التجارة_الإلكترونية']
  const hashtags: any[] = []
  for (const tag of tagNames) {
    const ht = await prisma.hashtag.upsert({ where: { tag }, update: {}, create: { tag, usageCount: randomInt(3, 30) } })
    hashtags.push(ht)
  }
  // Connect random tags to articles
  for (const article of articles) {
    const numTags = randomInt(1, 4)
    const selectedTags = shuffle(hashtags).slice(0, numTags)
    for (const ht of selectedTags) {
      await prisma.articleTag.upsert({
        where: { articleId_hashtagId: { articleId: article.id, hashtagId: ht.id } },
        update: {},
        create: { articleId: article.id, hashtagId: ht.id }
      }).catch(() => {})
    }
  }
  console.log(`✅ تم إنشاء ${hashtags.length} وسم`)

  // ════════════════════════════════════════════
  // 4. COMMENTS
  // ════════════════════════════════════════════
  console.log('💬 إنشاء التعليقات...')
  const commentTexts = [
    'مقال ممتاز يسلط الضوء على نقاط جوهرية في الاقتصاد العراقي',
    'شكراً على هذا التحليل المعمق، أتمنى أن تُتخذ إجراءات عملية بناءً عليه',
    'أوافقك الرأي في معظم النقاط لكن أختلف حول الحلول المقترحة',
    'هل يمكنكم تزويدنا بالمصادر والإحصائيات المذكورة في المقال؟',
    'هذا الموضوع يستحق نقاشاً أوسع في المجتمع الاقتصادي العراقي',
    'تجربة الدول الأخرى يمكن أن نستفيد منها لكن يجب تكييفها مع الواقع العراقي',
    'القطاع الخاص يحتاج فعلاً لدعم حقيقي وليس شعارات فقط',
    'البيانات المذكورة دقيقة وتتطابق مع ما نراه على أرض الواقع',
    'نحتاج لمزيد من الدراسات الميدانية قبل اتخاذ أي قرارات',
    'أقترح إضافة تحليل لأثر هذه السياسات على الطبقة المتوسطة',
    'الشفافية هي المفتاح كما ذكرت وحتى الآن نفتقد لها في معظم المؤسسات',
    'رأيي أن الإصلاح يجب أن يبدأ من القضاء المستقل ومكافحة الفساد',
    'موضوع مهم جداً ويستحق المتابعة والتعمق فيه',
    'الارتباط بين النفط والسياسة في العراق معقد ويحتاج لمعالجة جذرية',
    'أتمنى أن تُنشر مثل هذه التحليلات في وسائل الإعلام الواسعة',
  ]
  const comments: any[] = []
  for (let i = 0; i < 120; i++) {
    const article = pick(articles)
    const author = pick([...experts, ...regulars])
    const comment = await prisma.comment.create({
      data: {
        content: pick(commentTexts),
        articleId: article.id,
        authorId: author.id,
        likeCount: randomInt(0, 25),
        createdAt: randomDate(60),
      }
    }).catch(() => null)
    if (comment) comments.push(comment)
  }
  console.log(`✅ تم إنشاء ${comments.length} تعليق`)

  // ════════════════════════════════════════════
  // 5. LIKES
  // ════════════════════════════════════════════
  console.log('❤️ إنشاء الإعجابات...')
  let likeCount = 0
  for (let i = 0; i < 250; i++) {
    const article = pick(articles)
    const user = pick(users)
    await prisma.like.upsert({
      where: { userId_articleId_type: { userId: user.id, articleId: article.id, type: 'LIKE' } },
      update: {},
      create: { userId: user.id, articleId: article.id, type: 'LIKE' }
    }).catch(() => {}).then(() => { likeCount++ })
  }
  // Some bookmarks
  for (let i = 0; i < 50; i++) {
    const article = pick(articles)
    const user = pick([...experts, ...regulars])
    await prisma.like.upsert({
      where: { userId_articleId_type: { userId: user.id, articleId: article.id, type: 'BOOKMARK' } },
      update: {},
      create: { userId: user.id, articleId: article.id, type: 'BOOKMARK' }
    }).catch(() => {})
  }
  console.log(`✅ تم إنشاء ~${likeCount} إعجاب وحفظ`)

  // ════════════════════════════════════════════
  // 6. FOLLOWS
  // ════════════════════════════════════════════
  console.log('👥 إنشاء المتابعات...')
  let followCount = 0
  for (const expert of experts) {
    const numFollowers = randomInt(5, 14)
    const followers = shuffle(regulars).slice(0, numFollowers)
    for (const follower of followers) {
      await prisma.follow.upsert({
        where: { followerId_followingId: { followerId: follower.id, followingId: expert.id } },
        update: {},
        create: { followerId: follower.id, followingId: expert.id }
      }).catch(() => {}).then(() => { followCount++ })
    }
  }
  console.log(`✅ تم إنشاء ~${followCount} متابعة`)

  // ════════════════════════════════════════════
  // 7. DISCUSSIONS
  // ════════════════════════════════════════════
  console.log('💬 إنشاء النقاشات...')
  const discussionsData = [
    { title: 'هل يجب على العراق الانسحاب من أوبك بلس؟', content: 'فرضت أوبك بلس قيوداً على إنتاج العراق النفطي مما أثر سلباً على الإيرادات. هل حان الوقت لإعادة النظر في العضوية والالتزام بالحصص الإنتاجية؟ البعض يرى أن العراق يجب أن ينتج بحسب طاقته الكاملة لتعظيم الإيرادات بينما يرى آخرون أن الانسحاب سيؤدي لانهيار الأسعار وضرر أكبر.', category: 'POLICY' as DiscussionCategory },
    { title: 'مزاد العملة: إصلاحه أم إلغاؤه؟', content: 'مزاد العملة في البنك المركزي العراقي من أكثر القضايا خلافاً. البعض يطالب بإلغائه لأنه يسهل تهريب العملة والبعض يرى أنه ضروري لاستقرار سعر الصرف. ما هو رأيكم في الحل الأمثل؟', category: 'POLICY' as DiscussionCategory },
    { title: 'الخصخصة في العراق: هل هي الحل لمشاكل القطاع العام؟', content: 'يعاني القطاع العام العراقي من ترهل وفشل ذريع في تقديم الخدمات. هل خصخصة المؤسسات الحكومية المتعثرة هي الحل أم أن الإصلاح الداخلي كافٍ؟ ناقشوا تجارب الدول الأخرى ومدى إمكانية تطبيقها في العراق.', category: 'POLICY' as DiscussionCategory },
    { title: 'أثر العقوبات الأمريكية على إيران في الاقتصاد العراقي', content: 'العقوبات المفروضة على إيران تنعكس بشكل مباشر على الاقتصاد العراقي خاصة في ملفات الطاقة والتجارة الحدودية والتحويلات المالية. كيف يمكن للعراق حماية مصالحه الاقتصادية دون التعرض لعقوبات ثانوية؟', category: 'TRADE' as DiscussionCategory },
    { title: 'كيف يمكن تنشيط بورصة بغداد لتكون منافسة إقليمياً؟', content: 'بورصة بغداد تحتل مراتب متأخرة عربياً من حيث القيمة السوقية وحجم التداول. ما هي الخطوات العملية اللازمة لجذب الشركات الكبرى للاكتتاب وزيادة السيولة وتحسين بيئة التداول؟', category: 'MARKET' as DiscussionCategory },
    { title: 'أفضل الفرص الاستثمارية في العراق لعام 2026', content: 'مع تحسن البيئة الأمنية والاستقرار النسبي، ما هي القطاعات التي ترونها الأكثر جاذبية للاستثمار في العراق هذا العام؟ العقارات أم الطاقة المتجددة أم التقنية المالية أم الزراعة؟ شاركوا آراءكم وتجاربكم.', category: 'INVESTMENT' as DiscussionCategory },
    { title: 'أزمة المياه: هل الحل دبلوماسي أم تقني؟', content: 'تعاني العراق من شح مياه متزايد بسبب السدود التركية والإيرانية. هل الحل يكمن في المفاوضات الدبلوماسية لضمان الحصص المائية أم في الاستثمار في تقنيات تحلية المياه والري الذكي؟', category: 'POLICY' as DiscussionCategory },
    { title: 'مستقبل الدينار الرقمي العراقي', content: 'البنك المركزي يدرس إطلاق عملة رقمية رسمية. هل يمكن للدينار الرقمي أن يعزز الشمول المالي ويقلل الاعتماد على الدولار أم أن التحديات التقنية والأمنية أكبر من الفوائد المتوقعة؟', category: 'MARKET' as DiscussionCategory },
    { title: 'تجربة العراق مع القروض الدولية: هل هي ضرورة أم فخ؟', content: 'يلجأ العراق للاقتراض من البنك الدولي وصندوق النقد لتغطية العجز المالي. هل هذه القروض تساعد فعلاً في الإصلاح الاقتصادي أم تزيد من عبء الدين وتفرض شروطاً تضر بالسيادة الاقتصادية؟', category: 'INVESTMENT' as DiscussionCategory },
    { title: 'المنافذ الحدودية: بين السيادة الوطنية والمصالح التجارية', content: 'المنافذ الحدودية العراقية ساحة صراع بين مصالح سياسية واقتصادية متعددة. كيف يمكن تنظيم المنافذ بطريقة تخدم الاقتصاد الوطني وتحد من التهريب والفساد؟', category: 'TRADE' as DiscussionCategory },
    { title: 'هل يمكن للزراعة العراقية أن تعود لعهدها الذهبي؟', content: 'كان العراق سلة غذاء المنطقة في الماضي. مع التقدم التقني والاستثمار المناسب هل يمكن استعادة هذا الدور رغم أزمة المياه والتغير المناخي؟', category: 'INVESTMENT' as DiscussionCategory },
    { title: 'التجارة الإلكترونية والتحديات القانونية في العراق', content: 'ينمو قطاع التجارة الإلكترونية بسرعة في العراق لكن التشريعات لا تزال متخلفة. ما القوانين الضرورية لحماية المستهلك وتنظيم المنافسة وضمان جودة المنتجات المباعة عبر الإنترنت؟', category: 'TRADE' as DiscussionCategory },
    { title: 'دور المغتربين العراقيين في التنمية الاقتصادية', content: 'يوجد ملايين العراقيين في الخارج يمتلكون خبرات ورؤوس أموال ضخمة. كيف يمكن استقطابهم للمساهمة في التنمية الاقتصادية في الوطن؟ ما هي الحوافز والتسهيلات المطلوبة؟', category: 'GENERAL' as DiscussionCategory },
    { title: 'التعليم الاقتصادي في المدارس العراقية: هل هو كافٍ؟', content: 'معظم العراقيين يخرجون من النظام التعليمي دون فهم أساسي للاقتصاد والمال. هل يجب إدراج مادة الاقتصاد في المناهج المدرسية؟ وكيف يمكن تعزيز الثقافة المالية لدى الشباب؟', category: 'GENERAL' as DiscussionCategory },
    { title: 'تأثير الذكاء الاصطناعي على سوق العمل العراقي', content: 'يهدد الذكاء الاصطناعي ملايين الوظائف حول العالم. كيف سيتأثر سوق العمل العراقي بهذا التحول وهل نحن مستعدون لتأهيل القوى العاملة لمهارات المستقبل؟', category: 'MARKET' as DiscussionCategory },
    { title: 'الصندوق السيادي: تجارب ناجحة نستفيد منها', content: 'النرويج والإمارات والكويت تمتلك صناديق سيادية ناجحة تحمي اقتصاداتها من تقلبات النفط. ما هي أبرز الدروس التي يمكن للعراق الاستفادة منها في تأسيس صندوقه السيادي؟', category: 'INVESTMENT' as DiscussionCategory },
    { title: 'كيف نعالج مشكلة الفجوة بين بغداد والأقاليم اقتصادياً؟', content: 'تعاني المحافظات العراقية خارج بغداد من إهمال اقتصادي واضح. ما هي الحلول العملية لتحقيق تنمية متوازنة وتقليل الفوارق الاقتصادية بين العاصمة والمحافظات الأخرى؟', category: 'POLICY' as DiscussionCategory },
    { title: 'قطاع التأمين الصحي في العراق: بين الحاجة والعرض', content: 'يفتقر معظم العراقيين لتأمين صحي فعّال. كيف يمكن تطوير قطاع التأمين الصحي ليغطي شريحة أكبر من المواطنين بأسعار معقولة وجودة مقبولة؟', category: 'MARKET' as DiscussionCategory },
    { title: 'التبادل التجاري مع الصين: فرص ومخاطر', content: 'الصين شريك تجاري رئيسي للعراق خاصة في مجال البنية التحتية والنفط. كيف يمكن تعظيم الاستفادة من هذه العلاقة وتجنب المخاطر المرتبطة بالدين الصيني والتبعية الاقتصادية؟', category: 'TRADE' as DiscussionCategory },
    { title: 'أثر الانتخابات على الاستقرار الاقتصادي في العراق', content: 'تؤثر الدورات الانتخابية في العراق بشكل كبير على السياسات الاقتصادية والإنفاق الحكومي. كيف يمكن ضمان استمرارية السياسات الاقتصادية بغض النظر عن التغيرات السياسية؟', category: 'GENERAL' as DiscussionCategory },
    { title: 'النظام الضريبي: كيف نجعله عادلاً وفعالاً؟', content: 'الضرائب في العراق ظالمة وغير فعالة كما يراها كثيرون. ضريبة كسبة بغداد مثلاً تضغط على صغار التجار بينما يفلت كبار المستوردين. ما هي إصلاحاتكم المقترحة؟', category: 'POLICY' as DiscussionCategory },
    { title: 'الاستثمار في العقارات التجارية: هل لا يزال مجدياً؟', content: 'شهدت أسعار العقارات التجارية في بغداد ارتفاعات كبيرة. هل لا يزال الاستثمار في هذا القطاع مربحاً أم أننا أمام فقاعة على وشك الانفجار؟', category: 'INVESTMENT' as DiscussionCategory },
    { title: 'تطوير الموانئ العراقية: أولوية وطنية', content: 'ميناء أم قصر يعاني من اختناقات شديدة تزيد تكاليف التجارة العراقية. ما هي المشاريع المطلوبة لتطوير الموانئ العراقية وجعلها تنافسية إقليمياً؟', category: 'TRADE' as DiscussionCategory },
    { title: 'أثر تحرير سعر الصرف على الاقتصاد العراقي', content: 'بعض الاقتصاديين يطالبون بتحرير سعر صرف الدينار وتركه لقوى السوق. ما هي الآثار المتوقعة لهذا القرار على التضخم والاستثمار والطبقة المتوسطة؟', category: 'MARKET' as DiscussionCategory },
    { title: 'المرأة الريادية في العراق: تحديات ونجاحات', content: 'تزداد أعداد النساء اللواتي يدخلن عالم ريادة الأعمال في العراق رغم التحديات الاجتماعية والتمويلية. شاركوا تجاربكم وقصص نجاحكم لتحفيز المزيد من النساء.', category: 'GENERAL' as DiscussionCategory },
    { title: 'الطاقة النووية السلمية: هل هي خيار للعراق؟', content: 'أعلنت عدة دول عربية عن خطط لبناء مفاعلات نووية سلمية لتوليد الكهرباء. هل يجب على العراق دخول هذا المجال لتقليل الاعتماد على الغاز المستورد؟', category: 'INVESTMENT' as DiscussionCategory },
    { title: 'تطوير القطاع اللوجستي في العراق', content: 'يحتاج العراق لقطاع لوجستي متطور لدعم التجارة الخارجية والاستثمار. ما هي متطلبات تطوير هذا القطاع وهل يمكن للقطاع الخاص قيادة هذا التحول؟', category: 'TRADE' as DiscussionCategory },
    { title: 'التعليم التقني كبديل للتعليم الأكاديمي', content: 'سوق العمل العراقي يحتاج مهارات تقنية وحرفية أكثر من شهادات أكاديمية نظرية. كيف نعيد توجيه الشباب نحو التعليم المهني والتقني؟', category: 'GENERAL' as DiscussionCategory },
    { title: 'مستقبل النفط العراقي في عصر التحول الطاقوي', content: 'العالم يتجه نحو الطاقة النظيفة وتقليل الاعتماد على الوقود الأحفوري. كيف يجب أن يستعد العراق لهذا التحول الكوني الذي قد يقلص الطلب على النفط خلال العقود القادمة؟', category: 'MARKET' as DiscussionCategory },
    { title: 'إصلاح نظام الرواتب في القطاع العام', content: 'يشكل بند الرواتب أكثر من 40% من الموازنة العراقية. كيف يمكن إصلاح نظام الرواتب ليكون أكثر عدالة وكفاءة دون المساس بمستوى معيشة الموظفين؟', category: 'POLICY' as DiscussionCategory },
  ]
  const discussions: any[] = []
  for (const dd of discussionsData) {
    const author = pick([...experts, ...regulars])
    const disc = await prisma.discussion.create({
      data: {
        ...dd,
        authorId: author.id,
        viewCount: randomInt(30, 2000),
        replyCount: randomInt(2, 20),
        isPinned: Math.random() > 0.85,
        createdAt: randomDate(75),
      }
    })
    discussions.push(disc)
  }
  console.log(`✅ تم إنشاء ${discussions.length} نقاش`)

  // Discussion Replies
  console.log('↩️ إنشاء ردود النقاشات...')
  const replyTexts = [
    'أتفق معك تماماً في هذه النقطة. الإصلاح الاقتصادي يحتاج لإرادة سياسية حقيقية',
    'رأي ممتاز لكن أعتقد أن الحل يتطلب مقاربة أكثر شمولية',
    'البيانات التي ذكرتها دقيقة لكن الاستنتاجات تحتاج لمراجعة',
    'تجربة الإمارات في هذا المجال تستحق الدراسة والاستفادة',
    'المشكلة الأساسية في التنفيذ وليس في التخطيط والتصميم',
    'أضيف إلى ما ذكرت أن التعليم والتدريب عنصر أساسي في أي إصلاح',
    'هل يمكنك توضيح النقطة المتعلقة بالتمويل أكثر؟',
    'الحل المقترح يحتاج لجدول زمني واضح ومؤشرات قياس',
    'من واقع عملي في القطاع أرى أن الواقع أسوأ مما يُصور',
    'شكراً على هذا الطرح المتميز نحتاج لمزيد من النقاشات المفتوحة',
  ]
  let replyCount = 0
  for (const disc of discussions) {
    const numReplies = randomInt(2, 6)
    for (let r = 0; r < numReplies; r++) {
      await prisma.discussionReply.create({
        data: {
          content: pick(replyTexts),
          discussionId: disc.id,
          authorId: pick([...experts, ...regulars]).id,
          likeCount: randomInt(0, 15),
          createdAt: randomDate(50),
        }
      }).catch(() => {})
      replyCount++
    }
  }
  console.log(`✅ تم إنشاء ~${replyCount} رد`)

  // ════════════════════════════════════════════
  // 8. JOBS
  // ════════════════════════════════════════════
  console.log('💼 إنشاء الوظائف...')
  const jobsData = [
    { title: 'محلل مالي أول', company: 'البنك المركزي العراقي', location: 'بغداد', type: 'full-time', salary: '3,500,000 - 5,000,000 د.ع', description: 'مطلوب محلل مالي أول للعمل في قسم البحث والإحصاء بالبنك المركزي العراقي. يتطلب خبرة لا تقل عن 5 سنوات في التحليل المالي وإجادة اللغة الإنجليزية.', requirements: 'بكالوريوس اقتصاد أو مالية، خبرة 5+ سنوات، إجادة Excel وبرامج التحليل المالي', category: 'مالية' },
    { title: 'خبير اقتصادي', company: 'وزارة التخطيط', location: 'بغداد', type: 'full-time', salary: '4,000,000 - 6,000,000 د.ع', description: 'مطلوب خبير اقتصادي للمساهمة في إعداد الخطط التنموية الخمسية وتحليل المؤشرات الاقتصادية الوطنية.', requirements: 'ماجستير اقتصاد على الأقل، خبرة في التخطيط الاستراتيجي والتحليل الاقتصادي الكلي', category: 'اقتصاد' },
    { title: 'مدير استثمار', company: 'هيئة الاستثمار الوطنية', location: 'بغداد', type: 'full-time', salary: '5,000,000 - 8,000,000 د.ع', description: 'مطلوب مدير استثمار لإدارة محفظة المشاريع الاستثمارية وتقييم الفرص الجديدة والتفاوض مع المستثمرين الدوليين.', requirements: 'ماجستير إدارة أعمال، خبرة 8+ سنوات في إدارة الاستثمارات، إجادة اللغة الإنجليزية', category: 'استثمار' },
    { title: 'محاسب قانوني', company: 'شركة التمور العراقية', location: 'البصرة', type: 'full-time', salary: '2,500,000 - 3,500,000 د.ع', description: 'مطلوب محاسب قانوني للعمل في الشركة العامة للتمور العراقية مع مسؤولية إعداد القوائم المالية والتقارير الضريبية.', requirements: 'بكالوريوس محاسبة، شهادة محاسب قانوني، خبرة 3+ سنوات', category: 'محاسبة' },
    { title: 'مستشار ضريبي', company: 'مكتب الفرات للاستشارات', location: 'بغداد', type: 'part-time', salary: '2,000,000 - 3,000,000 د.ع', description: 'مطلوب مستشار ضريبي لتقديم الاستشارات الضريبية للشركات والمؤسسات وتحسين الامتثال الضريبي.', requirements: 'بكالوريوس محاسبة أو قانون، خبرة في التشريعات الضريبية العراقية', category: 'ضرائب' },
    { title: 'اقتصادي أول - قطاع النفط', company: 'وزارة النفط', location: 'بغداد', type: 'full-time', salary: '4,500,000 - 7,000,000 د.ع', description: 'مطلوب اقتصادي أول متخصص في قطاع النفط لتحليل الأسواق العالمية وإعداد تقارير الأثر الاقتصادي لقرارات أوبك.', requirements: 'ماجستير اقتصاد نفطي، خبرة 7+ سنوات، إجادة الإنجليزية', category: 'نفط' },
    { title: 'مدير مخاطر مالية', company: 'بنك العراق الإسلامي', location: 'بغداد', type: 'full-time', salary: '4,000,000 - 6,500,000 د.ع', description: 'مطلوب مدير مخاطر مالية لإطار إدارة المخاطر في البنك وضمان الامتثال بالمعايير الدولية.', requirements: 'بكالوريوس مالية، شهادة FRM أو PRM، خبرة 5+ سنوات في إدارة المخاطر', category: 'مصارف' },
    { title: 'محلل أسواق مالية', company: 'بورصة بغداد', location: 'بغداد', type: 'full-time', salary: '3,000,000 - 4,500,000 د.ع', description: 'مطلوب محلل أسواق للعمل في قسم البحث والتطوير ببورصة بغداد وإعداد التقارير اليومية والأسبوعية.', requirements: 'بكالوريوس مالية أو اقتصاد، خبرة في تحليل الأسواق المالية، إجادة برامج التحليل الفني', category: 'أسواق' },
    { title: 'مدير محافظ استثمارية', company: 'شركة الرافدين للاستثمار', location: 'بغداد', type: 'full-time', salary: '5,500,000 - 9,000,000 د.ع', description: 'مطلوب مدير محافظ استثمارية لإدارة صناديق الاستثمار وتحقيق عوائد تنافسية للمستثمرين.', requirements: 'ماجستير مالية، شهادة CFA، خبرة 10+ سنوات في إدارة المحافظ', category: 'استثمار' },
    { title: 'خبير تجارة إلكترونية', company: 'Zain Iraq', location: 'بغداد', type: 'full-time', salary: '3,500,000 - 5,500,000 د.ع', description: 'مطلوب خبير تجارة إلكترونية لتطوير منصات الدفع الرقمي وتوسيع خدمات التجارة الإلكترونية.', requirements: 'بكالوريوس تقنية معلومات أو أعمال، خبرة في التجارة الرقمية وFinTech', category: 'رقمي' },
    { title: 'باحث اقتصادي', company: 'مركز دراسات العراق', location: 'بغداد', type: 'contract', salary: '2,500,000 - 3,500,000 د.ع', description: 'مطلوب باحث اقتصادي لإعداد دراسات وتقارير حول القضايا الاقتصادية العراقية والإقليمية.', requirements: 'ماجستير اقتصاد، خبرة في البحث العلمي والنشر الأكاديمي', category: 'بحث' },
    { title: 'مدير تطوير أعمال', company: 'غرفة تجارة بغداد', location: 'بغداد', type: 'full-time', salary: '3,800,000 - 5,500,000 د.ع', description: 'مطلوب مدير تطوير أعمال لتعزيز العلاقات التجارية الدولية وتنظيم البعثات التجارية والمعارض.', requirements: 'بكالوريوس إدارة أعمال، خبرة 5+ سنوات في تطوير الأعمال والعلاقات الدولية', category: 'تجارة' },
    { title: 'أخصائي مالية عامة', company: 'وزارة المالية', location: 'بغداد', type: 'full-time', salary: '3,000,000 - 4,500,000 د.ع', description: 'مطلوب أخصائي مالية عامة للعمل في إعداد الموازنة الاتحادية ومراقبة الإنفاق الحكومي.', requirements: 'بكالوريوس مالية عامة، خبرة 3+ سنوات في الميزانية الحكومية', category: 'مالية عامة' },
    { title: 'مدير مشروع بنية تحتية', company: 'شركة الصين الوطنية', location: 'البصرة', type: 'contract', salary: '6,000,000 - 10,000,000 د.ع', description: 'مطلوب مدير مشروع لإدارة مشروع بنية تحتية كبير في البصرة بقيمة 500 مليون دولار.', requirements: 'بكالوريوس هندسة مدنية، خبرة 10+ سنوات في إدارة المشاريع الكبرى، PMP', category: 'بنية تحتية' },
    { title: 'خبير تأمين وإكتواري', company: 'شركة التأمين الوطنية', location: 'بغداد', type: 'full-time', salary: '3,500,000 - 5,000,000 د.ع', description: 'مطلوب خبير إكتواري لتسعير منتجات التأمين وتقييم المخاطر الاكتوارية.', requirements: 'بكالوريوس رياضيات أو إحصاء، شهادة إكتوارية، خبرة 5+ سنوات', category: 'تأمين' },
    { title: 'مصمم منتجات مالية رقمية', company: 'آسيا حوالة', location: 'أربيل', type: 'full-time', salary: '3,000,000 - 4,500,000 د.ع', description: 'مطلوب مصمم منتجات مالية رقمية لتطوير حلول الدفع والمحافظ الإلكترونية.', requirements: 'بكالوريوس تقنية أو تصميم، خبرة في FinTech وتصميم UX', category: 'رقمي' },
    { title: 'مستشار زراعي', company: 'المنظمة العربية للتنمية الزراعية', location: 'ذي قار', type: 'contract', salary: '2,500,000 - 3,500,000 د.ع', description: 'مطلوب مستشار زراعي لتقديم الدعم الفني للمزارعين في محافظات الجنوب.', requirements: 'بكالوريوس زراعة، خبرة في الإرشاد الزراعي وتقنيات الري الحديثة', category: 'زراعة' },
    { title: 'مدير التمويل المستدام', company: 'برنامج الأمم المتحدة الإنمائي', location: 'بغداد', type: 'contract', salary: '$3,000 - $5,000', description: 'مطلوب مدير التمويل المستدام لتطوير استراتيجيات التمويل الأخضر والمستدام في العراق.', requirements: 'ماجستير اقتصاد أو مالية، خبرة في التمويل المستدد وأهداف التنمية المستدامة', category: 'تنمية مستدامة' },
    { title: 'أخصائي تحليل بيانات اقتصادية', company: 'الجهاز المركزي للإحصاء', location: 'بغداد', type: 'full-time', salary: '2,800,000 - 4,000,000 د.ع', description: 'مطلوب أخصائي تحليل بيانات لمعالجة وتحليل البيانات الاقتصادية والاجتماعية الوطنية.', requirements: 'بكالوريوس إحصاء أو اقتصاد قياسي، إجادة Python وR وSQL', category: 'بيانات' },
    { title: 'مستشار استثمار عقاري', company: 'شركة دار العقارية', location: 'بغداد', type: 'full-time', salary: '3,000,000 - 5,000,000 د.ع + عمولات', description: 'مطلوب مستشار استثمار عقاري لتقييم الفرص العقارية وتقديم المشورة للمستثمرين.', requirements: 'بكالوريوس إدارة عقارات أو مالية، خبرة في سوق العقارات العراقي', category: 'عقارات' },
  ]
  const jobs: any[] = []
  for (const jd of jobsData) {
    const publisher = pick([...admins, owner, ...experts.slice(0, 3)])
    const job = await prisma.job.create({
      data: {
        ...jd,
        publishedBy: publisher.id,
        expiresAt: new Date(Date.now() + randomInt(30, 90) * 24 * 60 * 60 * 1000),
        viewsCount: randomInt(50, 800),
      }
    })
    jobs.push(job)
  }
  console.log(`✅ تم إنشاء ${jobs.length} وظيفة`)

  // ════════════════════════════════════════════
  // 9. ECONOMIC TERMS
  // ════════════════════════════════════════════
  console.log('📖 إنشاء المصطلحات الاقتصادية...')
  const termsData = [
    { termAr: 'التضخم', termEn: 'Inflation', definition: 'ارتفاع مستوى الأسعار العام للسلع والخدمات في اقتصاد ما خلال فترة زمنية محددة مما يؤدي لانخفاض القوة الشرائية للنقود', category: 'اقتصاد كلي', examples: 'إذا ارتفع مؤشر أسعار المستهلك من 100 إلى 105 فإن معدل التضخم يكون 5%' },
    { termAr: 'سعر الصرف', termEn: 'Exchange Rate', definition: 'قيمة عملة دولة ما مقاسة بعملة دولة أخرى ويحدد كم وحدة من العملة الأجنبية يمكن الحصول عليها مقابل وحدة واحدة من العملة المحلية', category: 'مالية', examples: 'سعر صرف الدينار العراقي مقابل الدولار هو 1450 دينار لكل دولار' },
    { termAr: 'الناتج المحلي الإجمالي', termEn: 'GDP', definition: 'القيمة السوقية الإجمالية لجميع السلع والخدمات النهائية المنتجة داخل حدود دولة معينة خلال فترة زمنية محددة عادة سنة واحدة', category: 'اقتصاد كلي', examples: 'الناتج المحلي الإجمالي للعراق بلغ 264 مليار دولار في 2024' },
    { termAr: 'الميزان التجاري', termEn: 'Trade Balance', definition: 'الفارق بين قيمة الصادرات والواردات لبلد ما خلال فترة معينة فإذا زادت الصادرات عن الواردات يسمى فائضاً تجارياً والعكس عجزاً تجارياً', category: 'تجارة دولية', examples: 'العراق يعاني من عجز تجاري في السلع غير النفطية' },
    { termAr: 'السياسة النقدية', termEn: 'Monetary Policy', definition: 'مجموعة الإجراءات التي يتخذها البنك المركزي للتأثير على عرض النقود وأسعار الفائدة لتحقيق أهداف اقتصادية كاستقرار الأسعار وتشجيع النمو', category: 'مالية', examples: 'خفض البنك المركزي سعر الفائدة لتحفيز الاقتراض والاستثمار' },
    { termAr: 'السياسة المالية', termEn: 'Fiscal Policy', definition: 'استخدام الحكومة للإنفاق العام والضرائب للتأثير على الاقتصاد وتحقيق أهداف التنمية والاستقرار الاقتصادي', category: 'مالية عامة', examples: 'زيادة الإنفاق الحكومي على البنية التحتية لتحفيز النمو الاقتصادي' },
    { termAr: 'الاستثمار الأجنبي المباشر', termEn: 'FDI', definition: 'استثمار تقوم به شركة أو فرد من دولة في أصول أو مشروعات تقع في دولة أخرى بهدف الحصول على سيطرة إدارية دائمة', category: 'استثمار', examples: 'إنشاء شركة تركية لمصنع أسمنت في البصرة' },
    { termAr: 'السوق الموازية', termEn: 'Parallel Market', definition: 'سوق غير رسمية تتداول فيها العملات الأجنبية بأسعار تختلف عن السعر الرسمي المحدد من البنك المركزي', category: 'مالية', examples: 'سعر الدولار في السوق الموازية أعلى من السعر الرسمي بـ 50 دينار' },
    { termAr: 'الصكوك الإسلامية', termEn: 'Islamic Bonds (Sukuk)', definition: 'شهادات مالية متساوية القيمة تمثل ملكية مشاعة في أصول أو مشروعات استثمارية وفق أحكام الشريعة الإسلامية', category: 'مصارف إسلامية', examples: 'إصدار صكوك بمبلغ 500 مليون دولار لتمويل مشروع بنية تحتية' },
    { termAr: 'الركود الاقتصادي', termEn: 'Economic Recession', definition: 'انخفاض النشاط الاقتصادي يستمر لفترة تتجاوز ستة أشهر ويتجلى في تراجع الناتج المحلي وارتفاع البطالة وانخفاض الإنفاق الاستهلاكي', category: 'اقتصاد كلي', examples: 'ركود 2020 الناجم عن جائحة كورونا أدى لانكماش الاقتصاد العالمي بنسبة 3.5%' },
    { termAr: 'الكفاية الحدية لرأس المال', termEn: 'Capital Adequacy Ratio', definition: 'نسبة رأس مال المصرف إلى أصوله المرجحة بالمخاطر وتُستخدم لضمان قدرة المصرف على امتصاص الخسائر', category: 'مصارف', examples: 'الحد الأدنى لكفاية رأس المال حسب بازل 3 هو 8%' },
    { termAr: 'العجز المالي', termEn: 'Fiscal Deficit', definition: 'الفرق بين إيرادات الدولة ونفقاتها خلال فترة مالية واحدة عندما تتجاوز النفقات الإيرادات', category: 'مالية عامة', examples: 'العجز المالي في الموازنة العراقية بلغ 15 تريليون دينار' },
    { termAr: 'الدين العام', termEn: 'Public Debt', definition: 'إجمالي المبالغ التي تقترضها الحكومة من الدائنين المحليين والأجانب لتمويل عجز الموازنة والمشاريع الاستثمارية', category: 'مالية عامة', examples: 'الدين العام العراقي يتجاوز 60 مليار دولار' },
    { termAr: 'الاحتياطي النقدي', termEn: 'Foreign Reserves', definition: 'الأصول بالعملات الأجنبية التي يحتفظ بها البنك المركزي لضمان استقرار العملة الوطنية وسداد الالتزامات الخارجية', category: 'مالية', examples: 'احتياطي النقد الأجنبي في العراق يبلغ 68 مليار دولار' },
    { termAr: 'النمو الاقتصادي', termEn: 'Economic Growth', definition: 'زيادة الناتج المحلي الإجمالي الحقيقي لبلد ما خلال فترة زمنية محددة مما يعكس تحسن مستوى المعيشة وخلق فرص عمل جديدة', category: 'اقتصاد كلي', examples: 'نمو الاقتصاد العراقي بنسبة 2.8% خلال 2025' },
    { termAr: 'مزاد العملة', termEn: 'Currency Auction', definition: 'آلية يديرها البنك المركزي العراقي لبيع الدولار للمصارف بسعر صرف رسمي ثابت بهدف توفير العملة الأجنبية وتحقيق استقرار سعر الصرف', category: 'مالية', examples: 'يبيع البنك المركزي 150 مليون دولار يومياً عبر المزاد' },
    { termAr: 'الصندوق السيادي', termEn: 'Sovereign Wealth Fund', definition: 'صندوق استثمار تملكه الدولة يُدار بشكل مستقل لاستثمار الفوائض المالية وتنويع مصادر الدخل وحماية الاقتصاد من تقلبات الأسعار', category: 'استثمار', examples: 'صندوق النرويج السيادي يدير أصولاً تتجاوز 1.4 تريليون دولار' },
    { termAr: 'الشمول المالي', termEn: 'Financial Inclusion', definition: 'توفير وإتاحة الخدمات المالية الرسمية لجميع شرائح المجتمع بأسعار معقولة بما فيها الفئات ذات الدخل المنخفض', category: 'مصارف', examples: 'نسبة الشمول المالي في العراق 23% فقط' },
    { termAr: 'التكلفة الحدية', termEn: 'Marginal Cost', definition: 'التكلفة الإضافية الناتجة عن إنتاج وحدة واحدة إضافية من السلعة أو الخدمة وتُستخدم في تحديد مستوى الإنتاج الأمثل', category: 'اقتصاد جزئي', examples: 'إذا كانت تكلفة إنتاج 100 وحدة 1000 دولار وإنتاج 101 وحدة 1015 دولار فإن التكلفة الحدية 15 دولار' },
    { termAr: 'العائد على الاستثمار', termEn: 'ROI', definition: 'نسبة صافي الربح إلى تكلفة الاستثمار وتُستخدم لتقييم كفاءة الاستثمار ومقارنة الفرص المختلفة', category: 'استثمار', examples: 'إذا استثمرت 1000 دولار وحصلت على 1200 دولار فإن العائد 20%' },
    { termAr: 'الخصخصة', termEn: 'Privatization', definition: 'نقل ملكية وإدارة المؤسسات العامة إلى القطاع الخاص بهدف تحسين الكفاءة وتقليل الأعباء المالية على الحكومة', category: 'اقتصاد كلي', examples: 'خصخصة شركات الاتصالات في أوروبا الشرقية أدت لتحسين جودة الخدمات' },
    { termAr: 'المنافسة الاحتكارية', termEn: 'Monopolistic Competition', definition: 'سوق يضم عدداً كبيراً من البائعين يقدمون منتجات متمايزة وليست متطابقة مما يمنح كل بائع قدرة جزئية على التسعير', category: 'اقتصاد جزئي', examples: 'سوق المطاعم في بغداد مثال على المنافسة الاحتكارية' },
    { termAr: 'سعر الفائدة', termEn: 'Interest Rate', definition: 'النسبة المئوية التي يطلبها المُقرض من المقترض مقابل استخدام أمواله خلال فترة زمنية محددة عادة سنة واحدة', category: 'مالية', examples: 'سعر الفائدة في العراق 5.5% حالياً' },
    { termAr: 'الائتمان', termEn: 'Credit', definition: 'اتفاقية يقدم بموجبها المُقرض مبلغاً من المال للمقترض على أن يسدده لاحقاً مع الفوائد المستحقة', category: 'مصارف', examples: 'القروض الشخصية والتمويل العقاري أشكال مختلفة من الائتمان' },
    { termAr: 'القوة الشرائية', termEn: 'Purchasing Power', definition: 'كمية السلع والخدمات التي يمكن لوحدة نقدية واحدة شراؤها وتتأثر بمستوى الأسعار ومعدل التضخم', category: 'اقتصاد كلي', examples: 'انخفاض القوة الشرائية للدينار بسبب التضخم' },
    { termAr: 'التنمية المستدامة', termEn: 'Sustainable Development', definition: 'التنمية التي تلبي احتياجات الحاضر دون المساس بقدرة الأجيال القادمة على تلبية احتياجاتها مع الموازنة بين النمو الاقتصادي والعدالة الاجتماعية وحماية البيئة', category: 'تنمية', examples: 'أهداف التنمية المستدامة 2030 للأمم المتحدة' },
    { termAr: 'الاقتصاد الرقمي', termEn: 'Digital Economy', definition: 'النشاط الاقتصادي القائم على التقنيات الرقمية والإنترنت بما يشمل التجارة الإلكترونية والخدمات الرقمية والعملات المشفرة', category: 'رقمي', examples: 'منصات الدفع الإلكتروني والتجارة الإلكترونية في العراق' },
    { termAr: 'التجارة الحرة', termEn: 'Free Trade', definition: 'سياسة تجارية تسمح بتبادل السلع والخدمات بين الدول دون قيود جمركية أو حواجز تجارية كرسوم الاستيراد والحصص الكمية', category: 'تجارة دولية', examples: 'اتفاقية التجارة الحرة بين العراق ومصر' },
    { termAr: 'الركود التضخمي', termEn: 'Stagflation', definition: 'حالة اقتصادية تجمع بين الركود الاقتصادي وارتفاع معدل التضخم في آن واحد مما يجعل السياسات التقليدية غير فعالة', category: 'اقتصاد كلي', examples: 'أزمة النفط في السبعينيات تسببت بركود تضخمي عالمي' },
    { termAr: 'التجارة الإلكترونية', termEn: 'E-commerce', definition: 'بيع وشراء السلع والخدمات عبر الإنترنت وتشمل التجارة بين الشركات والمستهلكين والتجارة بين المستهلكين أنفسهم', category: 'رقمي', examples: 'منصات مثل ماركت العراق وبازاريا' },
    { termAr: 'التسعير المعتمد على القيمة', termEn: 'Value-based Pricing', definition: 'استراتيجية تسعير تعتمد على القيمة المدركة للمنتج من قبل العميل وليس على تكلفة الإنتاج أو أسعار المنافسين', category: 'تسويق', examples: 'تسعير منتج آبل بناءً على القيمة المضافة المدركة' },
  ]
  for (const td of termsData) {
    await prisma.economicTerm.upsert({
      where: { termAr: td.termAr },
      update: {},
      create: td
    }).catch(() => {})
  }
  console.log(`✅ تم إنشاء ${termsData.length} مصطلح اقتصادي`)

  // ════════════════════════════════════════════
  // 10. SITE SETTINGS & PRICING
  // ════════════════════════════════════════════
  console.log('⚙️ إنشاء إعدادات الموقع...')
  await prisma.siteSettings.upsert({
    where: { id: 'main' },
    update: {},
    create: { id: 'main', siteName: 'ميدان الاقتصاد', siteDescription: 'المرجع الاقتصادي العراقي الأول - منصة متخصصة في التحليل الاقتصادي والنقاشات المهنية' }
  })
  await prisma.pricingConfig.upsert({
    where: { id: 'default' },
    update: {},
    create: { id: 'default', cvPrice: 2.0, jobPrice: 1.0, currency: 'USD' }
  })
  console.log('✅ تم إنشاء إعدادات الموقع والتسعير')

  // ════════════════════════════════════════════
  // 11. LEARNING PATHS
  // ════════════════════════════════════════════
  console.log('📚 إنشاء المسارات التعليمية...')
  const pathsData = [
    { title: 'أساسيات الاقتصاد العراقي', description: 'تعلم المفاهيم الأساسية للاقتصاد العراقي وهياكل السوق والسياسات المالية والنقدية', category: 'اقتصاد كلي', icon: '📊', difficulty: 'BEGINNER' as any, lessonsCount: 8, duration: 240 },
    { title: 'الاستثمار للمبتدئين', description: 'دليل شامل لفهم أساسيات الاستثمار وأنواع الأصول وكيفية بناء محفظة استثمارية متنوعة', category: 'استثمار', icon: '💰', difficulty: 'BEGINNER' as any, lessonsCount: 6, duration: 180 },
    { title: 'التحليل المالي والمحاسبة', description: 'إتقان قراءة القوائم المالية وتحليل الأداء المالي للشركات واتخاذ قرارات استثمارية مبنية على البيانات', category: 'محاسبة', icon: '📈', difficulty: 'INTERMEDIATE' as any, lessonsCount: 10, duration: 360 },
    { title: 'الاقتصاد الكلي المتقدم', description: 'دراسة معمقة للنظريات الاقتصادية الكلية وتطبيقاتها على الاقتصاد العراقي والسياسات النقدية والمالية', category: 'اقتصاد كلي', icon: '🌍', difficulty: 'ADVANCED' as any, lessonsCount: 12, duration: 480 },
    { title: 'الأسواق المالية والتداول', description: 'فهم آلية عمل الأسواق المالية وأدوات التداول والتحليل الفني والأساسي مع تطبيقات عملية على بورصة بغداد', category: 'أسواق مالية', icon: '💹', difficulty: 'INTERMEDIATE' as any, lessonsCount: 9, duration: 300 },
  ]
  for (const pd of pathsData) {
    const path = await prisma.learningPath.create({ data: { ...pd, enrolledCount: randomInt(50, 500), order: 0 } })
    // Create a few lessons per path
    const lessonTitles = {
      'أساسيات الاقتصاد العراقي': ['مقدمة في الاقتصاد', 'العرض والطلب', 'الناتج المحلي الإجمالي', 'التضخم وأثره', 'سوق العمل', 'السياسة النقدية', 'الموازنة العامة', 'اقتصاد ما بعد النفط'],
      'الاستثمار للمبتدئين': ['ما هو الاستثمار؟', 'أنواع الأصول', 'الأسهم والسندات', 'الصناديق الاستثمارية', 'إدارة المخاطر', 'بناء المحفظة'],
      'التحليل المالي والمحاسبة': ['مقدمة في المحاسبة', 'قائمة الدخل', 'قائمة المركز المالي', 'قائمة التدفقات النقدية', 'النسب المالية', 'تحليل الربحية', 'تحليل السيولة', 'تحليل المديونية', 'التقييم المالي', 'دراسة حالة عملية'],
      'الاقتصاد الكلي المتقدم': ['نماذج النمو الاقتصادي', 'نموذج IS-LM', 'نموذج مندل-فليمينغ', 'توقعات رشيدية', 'دورات الأعمال', 'السياسة النقدية المتقدمة', 'السياسة المالية والدين العام', 'الاقتصاد المفتوح', 'السوق النقدية', 'مصادر النمو', 'الاقتصاد السياسي', 'إصلاحات هيكلية'],
      'الأسواق المالية والتداول': ['مقدمة في الأسواق المالية', 'بورصة بغداد', 'التحليل الأساسي', 'التحليل الفني', 'المؤشرات الفنية', 'إدارة المحافظ', 'التداول الإلكتروني', 'المشتقات المالية', 'السلوك المالي'],
    }
    const titles = lessonTitles[pd.title as keyof typeof lessonTitles] || []
    for (let i = 0; i < titles.length; i++) {
      await prisma.lesson.create({
        data: {
          pathId: path.id,
          title: titles[i],
          content: `محتوى درس ${titles[i]} - يتم تطوير المحتوى التعليمي بشكل مفصل مع أمثلة عملية من الاقتصاد العراقي وتمارين تفاعلية.`,
          order: i + 1,
          duration: randomInt(20, 45),
          type: 'TEXT',
          isFree: i < 3,
        }
      })
    }
  }
  console.log('✅ تم إنشاء 5 مسارات تعليمية مع دروسها')

  // ════════════════════════════════════════════
  // 12. QUIZZES
  // ════════════════════════════════════════════
  console.log('📝 إنشاء الاختبارات...')
  const quiz1 = await prisma.quiz.create({ data: { title: 'اختبار أساسيات الاقتصاد العراقي', description: 'اختبر معلوماتك حول المفاهيم الأساسية للاقتصاد العراقي', category: 'اقتصاد', difficulty: 'BEGINNER', questionsCount: 5, timeLimit: 10 } })
  const q1Questions = [
    { question: 'ما هو أكبر قطاع مساهم في الناتج المحلي الإجمالي العراقي؟', correctAnswer: 0, options: ['النفط والتعدين', 'الزراعة', 'الصناعة', 'السياحة'] },
    { question: 'ما هو اسم البنك المركزي في العراق؟', correctAnswer: 1, options: ['بنك العراق', 'البنك المركزي العراقي', 'المصرف الوطني', 'بنك بغداد'] },
    { question: 'ما هي العملة الرسمية للعراق؟', correctAnswer: 2, options: ['الريال', 'الليرة', 'الدينار', 'الدرهم'] },
    { question: 'أين تقع بورصة بغداد للأوراق المالية؟', correctAnswer: 0, options: ['بغداد', 'البصرة', 'أربيل', 'الموصل'] },
    { question: 'ما نسبة مساهمة النفط في الصادرات العراقية؟', correctAnswer: 3, options: ['50%', '70%', '85%', 'أكثر من 95%'] },
  ]
  for (let i = 0; i < q1Questions.length; i++) {
    const q = await prisma.quizQuestion.create({ data: { quizId: quiz1.id, question: q1Questions[i].question, correctAnswer: q1Questions[i].correctAnswer, order: i + 1 } })
    for (let j = 0; j < q1Questions[i].options.length; j++) {
      await prisma.quizOptionRecord.create({ data: { questionId: q.id, text: q1Questions[i].options[j], order: j + 1 } })
    }
  }

  const quiz2 = await prisma.quiz.create({ data: { title: 'اختبار معلوماتك عن النفط العراقي', description: 'هل تعرف enough عن صناعة النفط في العراق؟', category: 'نفط', difficulty: 'INTERMEDIATE', questionsCount: 5, timeLimit: 12 } })
  const q2Questions = [
    { question: 'ما هو ترتيب العراق بين دول أوبك من حيث الاحتياطي النفطي؟', correctAnswer: 1, options: ['الأول', 'الثاني', 'الثالث', 'الرابع'] },
    { question: 'أين يقع حقل غرب القرنة النفطي؟', correctAnswer: 2, options: ['كركوك', 'بغداد', 'البصرة', 'ميسان'] },
    { question: 'ما هو الحقل النفطي الأكبر في العراق؟', correctAnswer: 0, options: ['حقل مغني', 'حقل كركوك', 'حقل غرب القرنة', 'حقل الزبير'] },
    { question: 'متى تأسست منظمة أوبك؟', correctAnswer: 3, options: ['1958', '1962', '1968', '1960'] },
    { question: 'ما هي الدولة التي تستورد أكبر كمية من النفط العراقي؟', correctAnswer: 1, options: ['الولايات المتحدة', 'الصين', 'الهند', 'كوريا الجنوبية'] },
  ]
  for (let i = 0; i < q2Questions.length; i++) {
    const q = await prisma.quizQuestion.create({ data: { quizId: quiz2.id, question: q2Questions[i].question, correctAnswer: q2Questions[i].correctAnswer, order: i + 1 } })
    for (let j = 0; j < q2Questions[i].options.length; j++) {
      await prisma.quizOptionRecord.create({ data: { questionId: q.id, text: q2Questions[i].options[j], order: j + 1 } })
    }
  }

  const quiz3 = await prisma.quiz.create({ data: { title: 'اختبار المصطلحات الاقتصادية', description: 'اختقد فهمك للمصطلحات الاقتصادية المتداولة في العراق', category: 'مصطلحات', difficulty: 'BEGINNER', questionsCount: 5, timeLimit: 8 } })
  const q3Questions = [
    { question: 'ما معنى التضخم الاقتصادي؟', correctAnswer: 0, options: ['ارتفاع مستوى الأسعار العام', 'انخفاض الأسعار', 'استقرار الأسعار', 'تقلب الأسعار فقط'] },
    { question: 'ما هو الشمول المالي؟', correctAnswer: 2, options: ['زيادة الضرائب', 'طباعة العملة', 'توفير الخدمات المالية للجميع', 'رفع سعر الفائدة'] },
    { question: 'ما هو المزاد المركزي للعملة؟', correctAnswer: 1, options: ['سوق للأسهم', 'آلية لبيع الدولار للمصارف', 'سوق للذهب', 'نظام الدفع الإلكتروني'] },
    { question: 'ما هو الصندوق السيادي؟', correctAnswer: 3, options: ['صندوق تقاعدي', 'صندوق زكاة', 'صندوق إعانات', 'صندوق استثمار حكومي للفوائض'] },
    { question: 'ما هو الاقتصاد الرقمي؟', correctAnswer: 2, options: ['اقتصاد زراعي', 'اقتصاد نفطي', 'نشاط اقتصادي قائم على التقنيات الرقمية', 'اقتصاد تقليدي'] },
  ]
  for (let i = 0; i < q3Questions.length; i++) {
    const q = await prisma.quizQuestion.create({ data: { quizId: quiz3.id, question: q3Questions[i].question, correctAnswer: q3Questions[i].correctAnswer, order: i + 1 } })
    for (let j = 0; j < q3Questions[i].options.length; j++) {
      await prisma.quizOptionRecord.create({ data: { questionId: q.id, text: q3Questions[i].options[j], order: j + 1 } })
    }
  }
  console.log('✅ تم إنشاء 3 اختبارات مع أسئلتها')

  // ════════════════════════════════════════════
  // 13. UPDATE USER ARTICLES COUNT
  // ════════════════════════════════════════════
  console.log('🔄 تحديث عداد المقالات للمستخدمين...')
  for (const user of users) {
    const count = await prisma.article.count({ where: { authorId: user.id, status: 'PUBLISHED' } })
    await prisma.user.update({ where: { id: user.id }, data: { articlesCount: count } })
  }

  // ════════════════════════════════════════════
  // SUMMARY
  // ════════════════════════════════════════════
  console.log('\n' + '='.repeat(60))
  console.log('🎉 تم ملء قاعدة البيانات بنجاح!')
  console.log('='.repeat(60))
  console.log(`👤 المستخدمين: ${users.length}`)
  console.log(`📝 المنشورات والمقالات: ${articles.length}`)
  console.log(`💬 النقاشات: ${discussions.length}`)
  console.log(`💼 الوظائف: ${jobs.length}`)
  console.log(`# الوسوم: ${hashtags.length}`)
  console.log(`📖 المصطلحات الاقتصادية: ${termsData.length}`)
  console.log(`📚 المسارات التعليمية: 5`)
  console.log(`📝 الاختبارات: 3`)
  console.log('='.repeat(60))
}

main()
  .catch((e) => {
    console.error('❌ خطأ:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
