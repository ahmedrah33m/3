#!/bin/bash
# ============================================
# Maydan Al-Iqtisad — Script التثبيت والتشغيل
# ميدان الاقتصاد — Installation & Deployment Script
# ============================================
# Usage: bash deploy.sh
# Run this on the server as root
# ============================================

set -e

# ── الألوان ──
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  ميدان الاقتصاد — Maydan Al-Iqtisad${NC}"
    echo -e "${BLUE}  ═════════════════════════════════════════════════${NC}\n"
}

print_step() {
    echo -e "\n${GREEN}[✓] $1${NC}"
}

print_warn() {
    echo -e "${YELLOW}[!] $1${NC}"
}

print_error() {
    echo -e "${RED}[✗] $1${NC}"
}

# ============================================
# الخطوة 0: التحقق من الصلاحيات
# ============================================
print_header

if [ "$EUID" -ne 0 ]; then
    print_error "يجب تشغيل السكربت بصلاحيات root"
    echo "sudo bash deploy.sh"
    exit 1
fi

print_step "صلاحيات root مُتحقق منها"

# ============================================
# الخطوة 1: التحقق من المتطلبات
# ============================================
echo -e "\n${BLUE}── الخطوة 1: التحقق من المتطلبات ──${NC}"

# Docker
if ! command -v docker &> /dev/null; then
    print_warn "Docker غير مُثبّت — جاري التثبيت..."
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
fi
print_step "Docker $(docker --version | awk '{print $3}')"

# Docker Compose
if ! docker compose version &> /dev/null; then
    print_warn "Docker Compose غير مُثبّت — جاري التثبيت..."
    apt-get update && apt-get install -y docker-compose-plugin
fi
print_step "Docker Compose $(docker compose version | awk '{print $NF}')"

# Git
if ! command -v git &> /dev/null; then
    print_warn "Git غير مُثبّت — جاري التثبيت..."
    apt-get update && apt-get install -y git
fi
print_step "Git $(git --version | awk '{print $3}')"

# ============================================
# الخطوة 2: إنشاء مجلدات التخزين
# ============================================
echo -e "\n${BLUE}── الخطوة 2: إنشاء مجلدات التخزين ──${NC}"

mkdir -p /mnt/postgresql
mkdir -p /mnt/redis
mkdir -p /mnt/hdd/minio-data
mkdir -p /mnt/hdd/minio-data/uploads
mkdir -p /mnt/hdd/backups
mkdir -p /mnt/hdd/logs
print_step "مجلدات التخزين جاهزة"

# ============================================
# الخطوة 3: نسخ المشروع
# ============================================
echo -e "\n${BLUE}── الخطوة 3: نسخ المشروع ──${NC}"

PROJECT_DIR="/opt/maydan"

if [ -d "$PROJECT_DIR" ]; then
    print_warn "المجلد $PROJECT_DIR موجود مسبقاً — جاري التحديث..."
    cd "$PROJECT_DIR"
    git pull 2>/dev/null || true
else
    # إذا كان المشروع مُنسوخ من Windows
    if [ -d "/tmp/maydan-deploy" ]; then
        cp -r /tmp/maydan-deploy "$PROJECT_DIR"
    else
        print_error "المشروع غير موجود. انسخه يدوياً إلى $PROJECT_DIR"
        echo "  scp -r . root@server:/opt/maydan"
        exit 1
    fi
    cd "$PROJECT_DIR"
fi
print_step "المشروع في $PROJECT_DIR"

# ============================================
# الخطوة 4: إعداد ملف .env
# ============================================
echo -e "\n${BLUE}── الخطوة 4: إعداد ملف .env ──${NC}"

if [ ! -f ".env" ]; then
    print_error "ملف .env غير موجود!"
    exit 1
fi

# توليد كلمة مرور PostgreSQL قوية
DB_PASS=$(openssl rand -hex 16)

# توليد أسرار التطبيق
JWT_SECRET=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(openssl rand -hex 32)
SESSION_SECRET=$(openssl rand -hex 32)
CSRF_SECRET=$(openssl rand -hex 32)
INTERNAL_API_SECRET=$(openssl rand -hex 32)

# تحديث .env
sed -i "s|JWT_SECRET=.*|JWT_SECRET=$JWT_SECRET|" .env
sed -i "s|ENCRYPTION_KEY=.*|ENCRYPTION_KEY=$ENCRYPTION_KEY|" .env
sed -i "s|SESSION_SECRET=.*|SESSION_SECRET=$SESSION_SECRET|" .env
sed -i "s|CSRF_SECRET=.*|CSRF_SECRET=$CSRF_SECRET|" .env
sed -i "s|INTERNAL_API_SECRET=.*|INTERNAL_API_SECRET=$INTERNAL_API_SECRET|" .env
sed -i "s|DATABASE_URL=.*|DATABASE_URL=postgresql://maydan:$DB_PASS@localhost:5432/maydan_db?schema=public\&connection_limit=5|" .env
sed -i "s|DIRECT_DATABASE_URL=.*|DIRECT_DATABASE_URL=postgresql://maydan:$DB_PASS@localhost:5432/maydan_db?schema=public\&connect_timeout=30|" .env
sed -i "s|NODE_ENV=.*|NODE_ENV=production|" .env
sed -i "s|FORCE_SECURE_COOKIE=.*|FORCE_SECURE_COOKIE=true|" .env

# تحديث كلمة مرور PostgreSQL في docker-compose.yml
sed -i "s|POSTGRES_PASSWORD:-[a-f0-9]*|POSTGRES_PASSWORD:-$DB_PASS|g" docker-compose.yml

# حفظ كلمة المرور
echo "$DB_PASS" > /opt/maydan/.db_password

print_step "ملف .env مُحدّث بأسرار حقيقية"
print_step "كلمة مرور قاعدة البيانات: $DB_PASS (محفوظة في /opt/maydan/.db_password)"

# ============================================
# الخطوة 5: بناء وتشغيل Docker
# ============================================
echo -e "\n${BLUE}── الخطوة 5: بناء وتشغيل Docker ──${NC}"

print_warn "جاري بناء الصور (قد يستغرق 5-10 دقائق)..."
docker compose build --no-cache

print_warn "جاري تشغيل الخدمات..."
docker compose up -d

# انتظار الخدمات
print_warn "انتظار قاعدة البيانات..."
sleep 15

# التحقق من صحة PostgreSQL
for i in {1..30}; do
    if docker compose exec postgres pg_isready -U maydan -d maydan_db &>/dev/null; then
        break
    fi
    sleep 2
done
print_step "PostgreSQL جاهز"

# ============================================
# الخطوة 6: ترحيل قاعدة البيانات
# ============================================
echo -e "\n${BLUE}── الخطوة 6: ترحيل قاعدة البيانات ──${NC}"

print_warn "جاري ترحيل قاعدة البيانات..."
docker compose run --rm migrator

print_step "قاعدة البيانات مُرحّلة"

# ============================================
# الخطوة 7: زراعة البيانات الأولية
# ============================================
echo -e "\n${BLUE}── الخطوة 7: زراعة البيانات الأولية ──${NC}"

print_warn "جاري زراعة البيانات الأولية..."
docker compose exec app npx prisma db seed || print_warn "البذور موجودة مسبقاً أو فشلت"

print_step "البيانات الأولية جاهزة"

# ============================================
# الخطوة 8: التحقق من الصحة
# ============================================
echo -e "\n${BLUE}── الخطوة 8: التحقق من صحة النظام ──${NC}"

sleep 10

HEALTH=$(curl -s http://localhost:3300/api/health 2>/dev/null || echo "{}")
STATUS=$(echo "$HEALTH" | grep -o '"status":"[^"]*"' | head -1 | cut -d'"' -f4)

if [ "$STATUS" = "healthy" ] || [ "$STATUS" = "degraded" ]; then
    print_step "النظام يعمل — الحالة: $STATUS"
else
    print_warn "النظام قد لا يكون جاهزاً بعد — تحقق يدوياً:"
    echo "  curl http://localhost:3300/api/health"
    echo "  docker compose logs app --tail=50"
fi

# ============================================
# الخطوة 9: إعداد النسخ الاحتياطي
# ============================================
echo -e "\n${BLUE}── الخطوة 9: إعداد النسخ الاحتياطي ──${NC}"

# إنشاء سكربت النسخ الاحتياطي
cat > /opt/maydan/scripts/backup.sh << 'BACKUP_EOF'
#!/bin/bash
set -e
BACKUP_DIR="/backups/$(date +%Y-%m-%d_%H-%M-%S)"
mkdir -p "$BACKUP_DIR"

echo "[$(date)] Starting backup..."

# PostgreSQL backup
docker compose exec -T postgres pg_dump -U maydan maydan_db | gzip > "$BACKUP_DIR/database.sql.gz"
echo "[$(date)] Database backup complete"

# Redis backup
docker compose exec -T redis redis-cli BGSAVE
sleep 5
docker compose cp redis:/data/dump.rdb "$BACKUP_DIR/redis-dump.rdb" 2>/dev/null || true
echo "[$(date)] Redis backup complete"

# Cleanup old backups (keep 30 days)
find /backups -maxdepth 1 -type d -mtime +30 -exec rm -rf {} \;

echo "[$(date)] Backup saved to $BACKUP_DIR"
BACKUP_EOF

chmod +x /opt/maydan/scripts/backup.sh

# إعداد cron job للنسخ الاحتياطي اليومي
(crontab -l 2>/dev/null; echo "0 3 * * * cd /opt/maydan && docker compose run --rm backup >> /mnt/hdd/logs/backup.log 2>&1") | sort -u | crontab -

print_step "النسخ الاحتياطي مُعد — يومياً الساعة 3:00 صباحاً"

# ============================================
# الخطوة 10: ملخص نهائي
# ============================================
echo -e "\n${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  ✅ التثبيت مكتمل!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"

echo -e "\n${YELLOW}── معلومات الوصول ──${NC}"
echo -e "  الموقع:       ${GREEN}https://midaniq.com${NC}"
echo -e "  لوحة MinIO:   ${GREEN}https://midaniq.com/minio/${NC}"
echo -e "  Health Check:  ${GREEN}http://localhost:3300/api/health${NC}"

echo -e "\n${YELLOW}── كلمة مرور قاعدة البيانات ──${NC}"
echo -e "  محفوظة في: ${GREEN}/opt/maydan/.db_password${NC}"

echo -e "\n${YELLOW}── أوامر مفيدة ──${NC}"
echo "  عرض الحالة:     docker compose ps"
echo "  عرض السجلات:    docker compose logs -f app"
echo "  إعادة تشغيل:    docker compose restart app"
echo "  إيقاف:          docker compose down"
echo "  نسخ احتياطي:    docker compose run --rm backup"
echo "  ترحيل DB:       docker compose run --rm migrator"
echo "  تحديث:          git pull && docker compose build && docker compose up -d"

echo -e "\n${YELLOW}── خطوة التالية ──${NC}"
echo "  1. أضف SMTP_PASSWORD في .env (كلمة مرور البريد)"
echo "  2. أضف GOOGLE_CLIENT_ID و GOOGLE_CLIENT_SECRET في .env"
echo "  3. أعد تشغيل: docker compose restart app"
