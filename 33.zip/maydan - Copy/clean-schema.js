const fs = require('fs');

let content = fs.readFileSync('prisma/schema.prisma', 'utf8');
const lines = content.split('\n');

// Step 1: Parse all models and remove duplicates
const models = [];
let currentModel = null;
let currentLines = [];
let braceCount = 0;
const seenModels = new Set();

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const trimmed = line.trim();
  
  // Skip comments and empty lines outside models
  if (!currentModel && (trimmed.startsWith('//') || trimmed === '')) {
    continue;
  }
  
  const match = trimmed.match(/^model (\w+) \{/);
  if (match) {
    // Save previous model
    if (currentModel && !seenModels.has(currentModel)) {
      seenModels.add(currentModel);
      models.push({ name: currentModel, lines: currentLines });
    }
    currentModel = match[1];
    currentLines = [line];
    braceCount = 1;
  } else if (currentModel) {
    currentLines.push(line);
    braceCount += (line.match(/\{/g) || []).length;
    braceCount -= (line.match(/\}/g) || []).length;
    if (braceCount === 0) {
      if (!seenModels.has(currentModel)) {
        seenModels.add(currentModel);
        models.push({ name: currentModel, lines: currentLines });
      }
      currentModel = null;
      currentLines = [];
    }
  }
}

if (currentModel && !seenModels.has(currentModel)) {
  models.push({ name: currentModel, lines: currentLines });
}

console.log('Parsed models:', models.length);

// Step 2: For each model, remove duplicate fields
for (const model of models) {
  const seenFields = new Set();
  const uniqueLines = [];
  
  for (const line of model.lines) {
    const trimmed = line.trim();
    
    // Check if this is a field line
    const fieldMatch = trimmed.match(/^(\w+)\s+/);
    if (fieldMatch && !trimmed.startsWith('model ') && !trimmed.startsWith('@@')) {
      const fieldName = fieldMatch[1];
      if (seenFields.has(fieldName)) {
        continue; // Skip duplicate
      }
      seenFields.add(fieldName);
    }
    
    uniqueLines.push(line);
  }
  
  model.lines = uniqueLines;
}

// Step 3: Find new models that need back-relations
const backRelations = {
  'Employee': ['employmentContracts EmploymentContract[]','salaryStructures SalaryStructure[]','allowances Allowance[]','deductions Deduction[]','bonuses Bonus[]','overtimes Overtime[]','attendances Attendance[]','leaveRecords LeaveRecord[]','payrollEmployees PayrollEmployee[]','adjustments Adjustment[]','employeeDocuments EmployeeDocument[]','employeeOnboardings EmployeeOnboarding[]','employmentVerifications EmploymentVerification[]'],
  'Company': ['employmentContracts EmploymentContract[]','salaryStructures SalaryStructure[]','salaryComponents SalaryComponent[]','allowances Allowance[]','deductions Deduction[]','bonuses Bonus[]','overtimes Overtime[]','shifts Shift[]','attendances Attendance[]','leavePolicies LeavePolicy[]','leaveRecords LeaveRecord[]','payrollPeriods PayrollPeriod[]','payrollRuns PayrollRun[]','payrollEmployees PayrollEmployee[]','payslips Payslip[]','payrollHistories PayrollHistory[]','payrollRules PayrollRule[]','taxRules TaxRule[]','adjustments Adjustment[]','employeeDocuments EmployeeDocument[]','onboardingTemplates OnboardingTemplate[]','onboardingTasks OnboardingTask[]','employeeOnboardings EmployeeOnboarding[]','payrollPayments PayrollPayment[]'],
  'User': ['employmentVerifications EmploymentVerification[]','employeeDocuments EmployeeDocument[]','onboardingNotes OnboardingNote[]','employeeOnboardings EmployeeOnboarding[] @relation("OnboardingAssignedTo")','liveRoomNotifications LiveRoomNotification[]','liveRoomHistories LiveRoomHistory[]','liveRoomReactions LiveRoomReaction[]','liveRoomModerationLogs LiveRoomModerationLog[] @relation("ModerationTarget")','liveRoomModerationActions LiveRoomModerationLog[] @relation("ModerationAction")','liveRoomInvitesSent LiveRoomInvite[] @relation("InviteSender")','liveRoomInvitesReceived LiveRoomInvite[] @relation("InviteRecipient")'],
  'LiveRoom': ['liveRoomNotifications LiveRoomNotification[]','liveRoomModerationLogs LiveRoomModerationLog[]','liveRoomHistories LiveRoomHistory[]','liveRoomReactions LiveRoomReaction[]','liveRoomInvites LiveRoomInvite[]'],
  'PayrollRun': ['payments PayrollPayment[]'],
  'OnboardingTemplate': ['onboardingTasks OnboardingTask[]','employeeOnboardings EmployeeOnboarding[]'],
  'OnboardingTask': ['dependentTasks OnboardingTask[] @relation("TaskDependency")','taskInstances OnboardingTaskInstance[]'],
  'EmployeeOnboarding': ['taskInstances OnboardingTaskInstance[]','onboardingNotes OnboardingNote[]'],
  'Shift': ['attendances Attendance[]'],
  'LeavePolicy': ['leaveRecords LeaveRecord[]'],
};

// Add back-relations to models
for (const model of models) {
  const rels = backRelations[model.name];
  if (!rels) continue;
  
  // Find closing brace
  const closingIdx = model.lines.length - 1;
  
  // Check if back-relations already exist
  const modelContent = model.lines.join('\n');
  const missingRels = rels.filter(r => {
    const fieldName = r.split(' ')[0];
    return !modelContent.includes(fieldName);
  });
  
  if (missingRels.length > 0) {
    // Insert before closing brace
    const insertIdx = closingIdx;
    model.lines.splice(insertIdx, 0, '', '  // Back-relations', ...missingRels.map(r => '  ' + r));
  }
}

// Step 4: Rebuild schema
const output = [];
output.push('generator client {');
output.push('  provider = "prisma-client-js"');
output.push('}');
output.push('');
output.push('datasource db {');
output.push('  provider = "postgresql"');
output.push('  url      = env("DATABASE_URL")');
output.push('}');
output.push('');

for (const model of models) {
  output.push(...model.lines);
  output.push('');
}

fs.writeFileSync('prisma/schema.prisma', output.join('\n'));
console.log('Written schema.prisma');
