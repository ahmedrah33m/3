import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAuth, handleApiError } from '@/lib/session'
import { successResponse, validationError, errorResponse } from '@/lib/api-utils'
import { createAdvertisement, getPublicAds, trackAdClick, trackAdImpression, AdvertisementError } from '@/services/advertisement.service'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const position = searchParams.get('position') || 'sidebar'
    const category = searchParams.get('category')

    const where: any = {
      isActive: true,
      position,
    }

    // Filter by end date
    where.endDate = { gte: new Date() }

    // Optional category filter
    if (category) {
      where.targetCategory = category
    }

    const ads = await db.ad.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 5,
    })

    return successResponse({ ads })
  } catch (error) {
    console.error('Get ads error:', error)
    return errorResponse('حدث خطأ', 'INTERNAL_ERROR', 500)
  }
}

// PUT - Track clicks/impressions (requires auth - issue #10)
export async function PUT(request: NextRequest) {
  try {
    await requireAuth()

    const body = await request.json()
    const { adId, action } = body

    if (!adId || !action) {
      return validationError('adId', 'معرّف الإعلان والإجراء مطلوبان')
    }

    if (action === 'click') {
      await trackAdClick(adId)
    } else {
      await trackAdImpression(adId)
    }

    return successResponse({})
  } catch (error) {
    if (error && typeof error === 'object' && 'statusCode' in error) {
      return handleApiError(error)
    }
    console.error('Track ad error:', error)
    return errorResponse('حدث خطأ', 'INTERNAL_ERROR', 500)
  }
}

// POST - Create new ad (requires auth + wallet payment)
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await request.json()
    const { title, description, imageUrl, linkUrl, position, targetCategory, durationDays } = body

    if (!title || !linkUrl) {
      return validationError('title/linkUrl', 'عنوان الإعلان ورابطه مطلوبان')
    }

    const result = await createAdvertisement(user.id, {
      title,
      description,
      imageUrl,
      linkUrl,
      position,
      targetCategory,
      durationDays,
    })

    return successResponse(result, 201)
  } catch (error) {
    if (error instanceof AdvertisementError) {
      return errorResponse(error.message, error.code || 'ADVERTISEMENT_ERROR', error.statusCode)
    }
    if (error && typeof error === 'object' && 'statusCode' in error) {
      return handleApiError(error)
    }
    console.error('Create ad error:', error)
    return errorResponse('حدث خطأ أثناء إنشاء الإعلان', 'INTERNAL_ERROR', 500)
  }
}
