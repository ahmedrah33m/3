import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { handleApiError, getCurrentUser } from '@/lib/session'
import { statusToCode } from '@/lib/api-utils'

export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'all' // all, stats, me, category
    const category = searchParams.get('category')
    const rarity = searchParams.get('rarity')
    const search = searchParams.get('search')
    const showSecret = searchParams.get('showSecret') === 'true'
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '100')

    const currentUser = await getCurrentUser()

    // ── Global Stats ──
    if (type === 'stats') {
      const [
        totalAchievements, totalSecret, totalSeasonal,
        totalEarners, totalPoints,
      ] = await Promise.all([
        db.achievement.count({ where: showSecret ? {} : { isSecret: false } }),
        db.achievement.count({ where: { isSecret: true } }),
        db.achievement.count({ where: { isSeasonal: true, isSecret: false } }),
        db.userAchievement.count({ where: { isCompleted: true } }),
        db.userAchievement.aggregate({ where: { isCompleted: true }, _sum: { progress: true } }),
      ])

      let myStats = null
      if (currentUser) {
        const [myEarned, myTotal, myPoints, myFavorites] = await Promise.all([
          db.userAchievement.count({ where: { userId: currentUser.id, isCompleted: true } }),
          db.userAchievement.count({ where: { userId: currentUser.id } }),
          db.userAchievement.aggregate({
            where: { userId: currentUser.id, isCompleted: true },
            _sum: { progress: true },
          }),
          db.userAchievement.count({ where: { userId: currentUser.id, isFavorite: true } }),
        ])
        // Find closest to completion
        const closestToComplete = await db.userAchievement.findFirst({
          where: {
            userId: currentUser.id,
            isCompleted: false,
          },
          include: { achievement: true },
          orderBy: { progress: 'desc' },
        })
        // Find latest completed
        const latestCompleted = await db.userAchievement.findFirst({
          where: { userId: currentUser.id, isCompleted: true },
          include: { achievement: true },
          orderBy: { unlockedAt: 'desc' },
        })

        myStats = {
          earned: myEarned,
          total: myTotal,
          points: myPoints._sum.progress || 0,
          favorites: myFavorites,
          percentage: myTotal > 0 ? Math.round((myEarned / Math.max(1, totalAchievements)) * 100) : 0,
          closestToComplete: closestToComplete ? {
            key: closestToComplete.achievement.key,
            name: closestToComplete.achievement.name,
            nameEn: closestToComplete.achievement.nameEn,
            icon: closestToComplete.achievement.icon,
            progress: closestToComplete.progress,
            threshold: closestToComplete.achievement.threshold,
            rarity: closestToComplete.achievement.rarity,
          } : null,
          latestCompleted: latestCompleted ? {
            key: latestCompleted.achievement.key,
            name: latestCompleted.achievement.name,
            nameEn: latestCompleted.achievement.nameEn,
            icon: latestCompleted.achievement.icon,
            unlockedAt: latestCompleted.unlockedAt,
            rarity: latestCompleted.achievement.rarity,
          } : null,
        } as any
      }

      // Rarity breakdown
      const rarityBreakdown = await db.achievement.groupBy({
        by: ['rarity'],
        _count: true,
        where: showSecret ? {} : { isSecret: false },
      })

      // Category breakdown
      const categoryBreakdown = await db.achievement.groupBy({
        by: ['category'],
        _count: true,
        where: showSecret ? {} : { isSecret: false },
      })

      return NextResponse.json({
        stats: {
          total: totalAchievements,
          secret: totalSecret,
          seasonal: totalSeasonal,
          totalEarners,
          totalPoints: totalPoints._sum.progress || 0,
          rarityBreakdown: Object.fromEntries(rarityBreakdown.map(r => [r.rarity, r._count])),
          categoryBreakdown: Object.fromEntries(categoryBreakdown.map(c => [c.category, c._count])),
        },
        myStats,
      })
    }

    // ── List Achievements ──
    const where: any = {}
    if (!showSecret) where.isSecret = false
    if (category && category !== 'all') where.category = category
    if (rarity && rarity !== 'all') where.rarity = rarity
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { nameEn: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const [achievements, total] = await Promise.all([
      db.achievement.findMany({
        where,
        orderBy: [
          { category: 'asc' },
          { tier: 'asc' },
          { points: 'desc' },
        ],
        skip: (page - 1) * limit,
        take: limit,
        ...(currentUser ? {
          include: {
            userAchievements: {
              where: { userId: currentUser.id },
              take: 1,
            },
          },
        } : {}),
      }),
      db.achievement.count({ where }),
    ])

    const enriched = achievements.map((a: any) => ({
      ...a,
      userProgress: a.userAchievements?.[0] || null,
      userAchievements: undefined,
    }))

    return NextResponse.json({ achievements: enriched, total, page, limit })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const body = await request.json()
    const { action, achievementKey, isFavorite } = body

    // Toggle favorite
    if (action === 'toggleFavorite' && achievementKey) {
      const achievement = await db.achievement.findUnique({ where: { key: achievementKey } })
      if (!achievement) return NextResponse.json({ success: false, error: 'Not found', code: statusToCode(404) }, { status: 404 })

      const existing = await db.userAchievement.findUnique({
        where: { userId_achievementId: { userId: currentUser.id, achievementId: achievement.id } },
      })

      if (existing) {
        await db.userAchievement.update({
          where: { id: existing.id },
          data: { isFavorite: !existing.isFavorite },
        })
        return NextResponse.json({ isFavorite: !existing.isFavorite })
      }

      // Create if doesn't exist
      await db.userAchievement.create({
        data: {
          userId: currentUser.id,
          achievementId: achievement.id,
          isFavorite: true,
        },
      })
      return NextResponse.json({ isFavorite: true })
    }

    return NextResponse.json({ success: false, error: 'Invalid action', code: statusToCode(400) }, { status: 400 })
  } catch (error) {
    return handleApiError(error)
  }
}
