import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { handleApiError, requireAuth } from '@/lib/session'

export const dynamic = 'force-dynamic'

const ACHIEVEMENTS = [
  // ═══════════ PROFILE ═══════════
  { key: 'first_signup', name: 'الانضمام لميدان', nameEn: 'Join Midan', description: 'إنشاء حساب جديد على منصة ميدان', descriptionEn: 'Create a new account on Midan', icon: '👤', category: 'PROFILE', rarity: 'COMMON', tier: 1, points: 5, xpReward: 10, threshold: 1 },
  { key: 'profile_50', name: 'ملف نصف مكتمل', nameEn: 'Half Profile', description: 'إكمال 50% من الملف الشخصي', descriptionEn: 'Complete 50% of your profile', icon: '📋', category: 'PROFILE', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 50 },
  { key: 'profile_100', name: 'الملف المثالي', nameEn: 'Perfect Profile', description: 'إكمال الملف الشخصي بنسبة 100%', descriptionEn: 'Complete your profile 100%', icon: '✅', category: 'PROFILE', rarity: 'UNCOMMON', tier: 2, points: 25, xpReward: 50, threshold: 100 },
  { key: 'avatar_uploaded', name: 'الصورة الشخصية', nameEn: 'Profile Photo', description: 'رفع صورة شخصية', descriptionEn: 'Upload a profile photo', icon: '📸', category: 'PROFILE', rarity: 'COMMON', tier: 1, points: 5, xpReward: 10, threshold: 1 },
  { key: 'account_verified', name: 'حساب موثق', nameEn: 'Verified Account', description: 'توثيق الحساب بالبريد الإلكتروني', descriptionEn: 'Verify your account via email', icon: '🔒', category: 'PROFILE', rarity: 'UNCOMMON', tier: 2, points: 15, xpReward: 30, threshold: 1 },
  { key: 'cv_added', name: 'منشئ السيرة الذاتية', nameEn: 'CV Builder', description: 'إضافة سيرة ذاتية باستخدام منشئ ميدان', descriptionEn: 'Add a CV using Midan builder', icon: '📄', category: 'PROFILE', rarity: 'UNCOMMON', tier: 2, points: 15, xpReward: 30, threshold: 1 },
  { key: 'linkedin_connected', name: 'متصل بلينكدإن', nameEn: 'LinkedIn Connected', description: 'ربط حساب LinkedIn', descriptionEn: 'Connect your LinkedIn account', icon: '🔗', category: 'PROFILE', rarity: 'UNCOMMON', tier: 2, points: 10, xpReward: 20, threshold: 1 },
  { key: 'scholar_connected', name: 'متصل بـ Google Scholar', nameEn: 'Scholar Connected', description: 'ربط حساب Google Scholar', descriptionEn: 'Connect your Google Scholar account', icon: '🎓', category: 'PROFILE', rarity: 'RARE', tier: 3, points: 20, xpReward: 40, threshold: 1 },
  { key: 'skills_added', name: 'خبير المهارات', nameEn: 'Skills Expert', description: 'إضافة 10 مهارات للملف الشخصي', descriptionEn: 'Add 10 skills to your profile', icon: '⚡', category: 'PROFILE', rarity: 'COMMON', tier: 1, points: 10, xpReward: 15, threshold: 10 },
  { key: 'experience_added', name: 'خبرة مثبتة', nameEn: 'Verified Experience', description: 'إضافة خبرة مهنية واحدة على الأقل', descriptionEn: 'Add at least one work experience', icon: '💼', category: 'PROFILE', rarity: 'COMMON', tier: 1, points: 10, xpReward: 15, threshold: 1 },
  { key: 'certifications_added', name: 'شهادات معتمدة', nameEn: 'Certified Professional', description: 'إضافة شهادة مهنية واحدة على الأقل', descriptionEn: 'Add at least one professional certification', icon: '🏆', category: 'PROFILE', rarity: 'UNCOMMON', tier: 2, points: 15, xpReward: 25, threshold: 1 },

  // ═══════════ LEARNING ═══════════
  { key: 'first_course', name: 'الدورة الأولى', nameEn: 'First Course', description: 'إكمال أول دورة تدريبية', descriptionEn: 'Complete your first training course', icon: '📚', category: 'LEARNING', rarity: 'COMMON', tier: 1, points: 15, xpReward: 30, threshold: 1 },
  { key: 'courses_5', name: 'متعلم متمرس', nameEn: 'Seasoned Learner', description: 'إكمال 5 دورات تدريبية', descriptionEn: 'Complete 5 training courses', icon: '📖', category: 'LEARNING', rarity: 'UNCOMMON', tier: 2, points: 30, xpReward: 60, threshold: 5 },
  { key: 'courses_20', name: 'طالب متفوق', nameEn: 'Top Student', description: 'إكمال 20 دورة تدريبية', descriptionEn: 'Complete 20 training courses', icon: '🏅', category: 'LEARNING', rarity: 'RARE', tier: 3, points: 75, xpReward: 150, threshold: 20 },
  { key: 'courses_50', name: 'أكاديمي بارز', nameEn: 'Distinguished Academic', description: 'إكمال 50 دورة تدريبية', descriptionEn: 'Complete 50 training courses', icon: '🎓', category: 'LEARNING', rarity: 'EPIC', tier: 4, points: 150, xpReward: 300, threshold: 50 },
  { key: 'quiz_excellent', name: 'نابغة الاختبارات', nameEn: 'Quiz Genius', description: 'اجتياز اختبار بدرجة ممتازة (90%+)', descriptionEn: 'Pass a quiz with excellent grade (90%+)', icon: '🧠', category: 'LEARNING', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },
  { key: 'learning_path_complete', name: 'مسار مكتمل', nameEn: 'Path Completed', description: 'إنهاء مسار تدريبي كامل', descriptionEn: 'Complete an entire learning path', icon: '🛤️', category: 'LEARNING', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 1 },
  { key: 'pro_certificate', name: 'شهادة احترافية', nameEn: 'Professional Certificate', description: 'الحصول على شهادة احترافية من ميدان', descriptionEn: 'Earn a professional certificate from Midan', icon: '🎖️', category: 'LEARNING', rarity: 'RARE', tier: 3, points: 40, xpReward: 80, threshold: 1 },
  { key: 'hours_100', name: '100 ساعة تعلم', nameEn: '100 Hours Learning', description: 'التعلم لمدة 100 ساعة', descriptionEn: 'Learn for 100 hours total', icon: '⏱️', category: 'LEARNING', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 100 },
  { key: 'quiz_perfect', name: 'النتيجة المثالية', nameEn: 'Perfect Score', description: 'الحصول على 100% في أي اختبار', descriptionEn: 'Get 100% on any quiz', icon: '💯', category: 'LEARNING', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 1 },

  // ═══════════ WRITING ═══════════
  { key: 'first_article', name: 'الكتابة الأولى', nameEn: 'First Article', description: 'نشر أول مقال', descriptionEn: 'Publish your first article', icon: '✍️', category: 'WRITING', rarity: 'COMMON', tier: 1, points: 15, xpReward: 30, threshold: 1 },
  { key: 'first_analysis', name: 'محلل أول', nameEn: 'First Analysis', description: 'نشر أول تحليل اقتصادي', descriptionEn: 'Publish your first economic analysis', icon: '📊', category: 'WRITING', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },
  { key: 'first_report', name: 'كاتب التقارير', nameEn: 'Report Writer', description: 'نشر أول تقرير', descriptionEn: 'Publish your first report', icon: '📋', category: 'WRITING', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },
  { key: 'first_research_article', name: 'باحث ناشئ', nameEn: 'Rising Researcher', description: 'نشر أول بحث', descriptionEn: 'Publish your first research paper', icon: '🔬', category: 'WRITING', rarity: 'RARE', tier: 3, points: 30, xpReward: 60, threshold: 1 },
  { key: 'articles_10', name: 'كاتب نشط', nameEn: 'Active Writer', description: 'نشر 10 مقالات', descriptionEn: 'Publish 10 articles', icon: '📝', category: 'WRITING', rarity: 'UNCOMMON', tier: 2, points: 30, xpReward: 60, threshold: 10 },
  { key: 'articles_50', name: 'كاتب محترف', nameEn: 'Professional Writer', description: 'نشر 50 مقالاً', descriptionEn: 'Publish 50 articles', icon: '📚', category: 'WRITING', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 50 },
  { key: 'articles_100', name: 'كاتب النخبة', nameEn: 'Elite Writer', description: 'نشر 100 مقال', descriptionEn: 'Publish 100 articles', icon: '👑', category: 'WRITING', rarity: 'LEGENDARY', tier: 5, points: 250, xpReward: 500, threshold: 100 },
  { key: 'book_published', name: 'مؤلف كتاب', nameEn: 'Book Author', description: 'نشر كتاب على منصة ميدان', descriptionEn: 'Publish a book on Midan', icon: '📕', category: 'WRITING', rarity: 'LEGENDARY', tier: 5, points: 200, xpReward: 400, threshold: 1 },
  { key: 'economic_study', name: 'دراسة اقتصادية', nameEn: 'Economic Study', description: 'نشر دراسة اقتصادية', descriptionEn: 'Publish an economic study', icon: '📈', category: 'WRITING', rarity: 'RARE', tier: 3, points: 40, xpReward: 80, threshold: 1 },

  // ═══════════ RESEARCH ═══════════
  { key: 'first_research', name: 'البحث الأول', nameEn: 'First Research', description: 'رفع أول بحث على المنصة', descriptionEn: 'Upload your first research paper', icon: '📄', category: 'RESEARCH', rarity: 'COMMON', tier: 1, points: 15, xpReward: 30, threshold: 1 },
  { key: 'first_citation', name: 'أول اقتباس', nameEn: 'First Citation', description: 'الحصول على أول اقتباس لبحثك', descriptionEn: 'Get your first citation', icon: '🔗', category: 'RESEARCH', rarity: 'UNCOMMON', tier: 2, points: 25, xpReward: 50, threshold: 1 },
  { key: 'citations_10', name: 'باحث مقتبس', nameEn: 'Cited Researcher', description: 'الحصول على 10 اقتباسات', descriptionEn: 'Get 10 citations', icon: '📑', category: 'RESEARCH', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 10 },
  { key: 'downloads_100', name: 'بحث مطلوب', nameEn: 'In-Demand Paper', description: 'تحقيق 100 تحميل', descriptionEn: 'Reach 100 downloads', icon: '⬇️', category: 'RESEARCH', rarity: 'RARE', tier: 3, points: 40, xpReward: 80, threshold: 100 },
  { key: 'views_1000', name: 'بحث شهير', nameEn: 'Popular Research', description: 'تحقيق 1000 مشاهدة', descriptionEn: 'Reach 1,000 views', icon: '👁️', category: 'RESEARCH', rarity: 'EPIC', tier: 4, points: 60, xpReward: 120, threshold: 1000 },
  { key: 'monthly_best', name: 'أفضل بحث في الشهر', nameEn: 'Monthly Best Paper', description: 'الحصول على لقب أفضل بحث في الشهر', descriptionEn: 'Win best paper of the month', icon: '🏆', category: 'RESEARCH', rarity: 'LEGENDARY', tier: 5, points: 150, xpReward: 300, threshold: 1 },
  { key: 'joint_research', name: 'بحث مشترك', nameEn: 'Joint Research', description: 'نشر بحث مشترك مع باحث آخر', descriptionEn: 'Co-author a research paper', icon: '🤝', category: 'RESEARCH', rarity: 'UNCOMMON', tier: 2, points: 25, xpReward: 50, threshold: 1 },
  { key: 'data_uploaded', name: 'بيانات بحثية', nameEn: 'Research Data', description: 'رفع بيانات بحثية', descriptionEn: 'Upload research data', icon: '📊', category: 'RESEARCH', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },

  // ═══════════ QA ═══════════
  { key: 'first_question', name: 'السؤال الأول', nameEn: 'First Question', description: 'طرح أول سؤال', descriptionEn: 'Ask your first question', icon: '❓', category: 'QA', rarity: 'COMMON', tier: 1, points: 5, xpReward: 10, threshold: 1 },
  { key: 'first_answer', name: 'الإجابة الأولى', nameEn: 'First Answer', description: 'كتابة أول إجابة', descriptionEn: 'Write your first answer', icon: '💬', category: 'QA', rarity: 'COMMON', tier: 1, points: 5, xpReward: 10, threshold: 1 },
  { key: 'first_verified_answer', name: 'إجابة معتمدة', nameEn: 'Verified Answer', description: 'الحصول على أول إجابة معتمدة', descriptionEn: 'Get your first verified answer', icon: '✅', category: 'QA', rarity: 'UNCOMMON', tier: 2, points: 25, xpReward: 50, threshold: 1 },
  { key: 'answers_100', name: 'إجابات كثيرة', nameEn: 'Prolific Answerer', description: 'كتابة 100 إجابة', descriptionEn: 'Write 100 answers', icon: '💭', category: 'QA', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 100 },
  { key: 'votes_1000', name: 'أصوات الإعجاب', nameEn: 'Fan Favorite', description: 'الحصول على 1000 تصويت إيجابي', descriptionEn: 'Get 1,000 upvotes', icon: '👍', category: 'QA', rarity: 'LEGENDARY', tier: 5, points: 200, xpReward: 400, threshold: 1000 },
  { key: 'community_expert', name: 'خبير المجتمع', nameEn: 'Community Expert', description: 'تحقيق لقب خبير المجتمع', descriptionEn: 'Earn the community expert title', icon: '🧠', category: 'QA', rarity: 'RARE', tier: 3, points: 75, xpReward: 150, threshold: 1 },

  // ═══════════ COMMUNITY ═══════════
  { key: 'first_comment', name: 'التعليق الأول', nameEn: 'First Comment', description: 'كتابة أول تعليق', descriptionEn: 'Write your first comment', icon: '💭', category: 'COMMUNITY', rarity: 'COMMON', tier: 1, points: 5, xpReward: 10, threshold: 1 },
  { key: 'comments_100', name: 'معلق نشط', nameEn: 'Active Commenter', description: 'كتابة 100 تعليق', descriptionEn: 'Write 100 comments', icon: '💬', category: 'COMMUNITY', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 100 },
  { key: 'likes_1000', name: 'محب المجتمع', nameEn: 'Community Beloved', description: 'الحصول على 1000 إعجاب', descriptionEn: 'Get 1,000 likes', icon: '❤️', category: 'COMMUNITY', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 1000 },
  { key: 'invite_10', name: 'صانع المجتمع', nameEn: 'Community Builder', description: 'دعوة 10 أعضاء جدد', descriptionEn: 'Invite 10 new members', icon: '📨', category: 'COMMUNITY', rarity: 'UNCOMMON', tier: 2, points: 30, xpReward: 60, threshold: 10 },
  { key: 'group_created', name: 'مُنشئ مجموعة', nameEn: 'Group Creator', description: 'إنشاء مجموعة في المجتمع', descriptionEn: 'Create a community group', icon: '👥', category: 'COMMUNITY', rarity: 'UNCOMMON', tier: 2, points: 15, xpReward: 30, threshold: 1 },
  { key: 'debate_participant', name: 'مشارك في نقاش', nameEn: 'Debate Participant', description: 'المشاركة في نقاش عام', descriptionEn: 'Participate in a public debate', icon: '🗣️', category: 'COMMUNITY', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 1 },
  { key: 'debate_host', name: 'مُنظم جلسة نقاشية', nameEn: 'Debate Host', description: 'تنظيم جلسة نقاشية', descriptionEn: 'Host a discussion session', icon: '🎙️', category: 'COMMUNITY', rarity: 'RARE', tier: 3, points: 40, xpReward: 80, threshold: 1 },

  // ═══════════ EXPERT ═══════════
  { key: 'first_consultation', name: 'الاستشارة الأولى', nameEn: 'First Consultation', description: 'إجراء أول استشارة', descriptionEn: 'Complete your first consultation', icon: '💼', category: 'EXPERT', rarity: 'COMMON', tier: 1, points: 20, xpReward: 40, threshold: 1 },
  { key: 'first_client', name: 'أول عميل', nameEn: 'First Client', description: 'الحصول على أول عميل', descriptionEn: 'Get your first client', icon: '🤝', category: 'EXPERT', rarity: 'UNCOMMON', tier: 2, points: 25, xpReward: 50, threshold: 1 },
  { key: 'five_star', name: 'تقييم خمس نجوم', nameEn: 'Five Star Rating', description: 'الحصول على تقييم 5 نجوم', descriptionEn: 'Receive a 5-star rating', icon: '⭐', category: 'EXPERT', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },
  { key: 'consultations_50', name: 'خبير متمرس', nameEn: 'Expert Consultant', description: 'إجراء 50 استشارة', descriptionEn: 'Complete 50 consultations', icon: '📊', category: 'EXPERT', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 50 },
  { key: 'platform_income', name: 'دخل من المنصة', nameEn: 'Platform Income', description: 'تحقيق أول دخل من المنصة', descriptionEn: 'Earn your first income from the platform', icon: '💰', category: 'EXPERT', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 1 },
  { key: 'recommended_expert', name: 'خبير موصى به', nameEn: 'Recommended Expert', description: 'الحصول على توصية من عميل', descriptionEn: 'Receive a client recommendation', icon: '🎖️', category: 'EXPERT', rarity: 'RARE', tier: 3, points: 40, xpReward: 80, threshold: 1 },

  // ═══════════ EVENTS ═══════════
  { key: 'first_event_attend', name: 'حضور أول فعالية', nameEn: 'First Event', description: 'حضور أول فعالية', descriptionEn: 'Attend your first event', icon: '📅', category: 'EVENTS', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 1 },
  { key: 'conference_attend', name: 'حضور مؤتمر', nameEn: 'Conference Attendee', description: 'حضور مؤتمر رسمي', descriptionEn: 'Attend an official conference', icon: '🏛️', category: 'EVENTS', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },
  { key: 'event_host', name: 'منظم فعاليات', nameEn: 'Event Organizer', description: 'تنظيم فعالية على المنصة', descriptionEn: 'Organize an event on the platform', icon: '🎪', category: 'EVENTS', rarity: 'RARE', tier: 3, points: 40, xpReward: 80, threshold: 1 },
  { key: 'speaker', name: 'متحدث رسمي', nameEn: 'Official Speaker', description: 'الظهور كمتحدث رسمي', descriptionEn: 'Appear as an official speaker', icon: '🎤', category: 'EVENTS', rarity: 'RARE', tier: 3, points: 35, xpReward: 70, threshold: 1 },
  { key: 'workshop_attend', name: 'ورشة عمل', nameEn: 'Workshop Attendee', description: 'المشاركة في ورشة عمل', descriptionEn: 'Participate in a workshop', icon: '🔧', category: 'EVENTS', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 1 },
  { key: 'events_10', name: ' attendee مخلص', nameEn: 'Loyal Attendee', description: 'المشاركة في 10 فعاليات', descriptionEn: 'Attend 10 events', icon: '🎟️', category: 'EVENTS', rarity: 'EPIC', tier: 4, points: 75, xpReward: 150, threshold: 10 },

  // ═══════════ DICTIONARY ═══════════
  { key: 'first_term', name: 'أول مصطلح', nameEn: 'First Term', description: 'إضافة أول مصطلح اقتصادي', descriptionEn: 'Add your first economic term', icon: '📖', category: 'DICTIONARY', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 1 },
  { key: 'first_approved_term', name: 'مصطلح معتمد', nameEn: 'Approved Term', description: 'الحصول على اعتماد أول مصطلح', descriptionEn: 'Get your first term approved', icon: '✅', category: 'DICTIONARY', rarity: 'UNCOMMON', tier: 2, points: 15, xpReward: 30, threshold: 1 },
  { key: 'terms_100', name: 'محرر اقتصادي', nameEn: 'Economic Editor', description: 'إضافة 100 مصطلح', descriptionEn: 'Add 100 economic terms', icon: '📚', category: 'DICTIONARY', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 100 },

  // ═══════════ INVESTMENT ═══════════
  { key: 'first_opportunity', name: 'أول فرصة', nameEn: 'First Opportunity', description: 'إضافة أول فرصة استثمارية', descriptionEn: 'Add your first investment opportunity', icon: '💼', category: 'INVESTMENT', rarity: 'COMMON', tier: 1, points: 15, xpReward: 30, threshold: 1 },
  { key: 'opportunity_rated', name: 'فرصة مقيّمة', nameEn: 'Rated Opportunity', description: 'تقييم فرصة استثمارية', descriptionEn: 'Rate an investment opportunity', icon: '⭐', category: 'INVESTMENT', rarity: 'COMMON', tier: 1, points: 5, xpReward: 10, threshold: 1 },
  { key: 'opportunities_50', name: 'مستثمر نشط', nameEn: 'Active Investor', description: 'متابعة 50 فرصة استثمارية', descriptionEn: 'Follow 50 investment opportunities', icon: '📈', category: 'INVESTMENT', rarity: 'EPIC', tier: 4, points: 80, xpReward: 160, threshold: 50 },

  // ═══════════ VOLUNTEER ═══════════
  { key: 'first_volunteer_hour', name: 'ساعة تطوع الأولى', nameEn: 'First Volunteer Hour', description: 'إتمام أول ساعة تطوع', descriptionEn: 'Complete your first volunteer hour', icon: '🤲', category: 'VOLUNTEER', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 1 },
  { key: 'volunteer_100', name: '100 ساعة تطوع', nameEn: '100 Volunteer Hours', description: 'إتمام 100 ساعة تطوع', descriptionEn: 'Complete 100 volunteer hours', icon: '🌟', category: 'VOLUNTEER', rarity: 'LEGENDARY', tier: 5, points: 200, xpReward: 400, threshold: 100 },
  { key: 'awareness_campaign', name: 'حملة توعوية', nameEn: 'Awareness Campaign', description: 'المشاركة في حملة توعوية', descriptionEn: 'Participate in an awareness campaign', icon: '📢', category: 'VOLUNTEER', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1 },
  { key: 'initiative_leader', name: 'قائد مبادرة', nameEn: 'Initiative Leader', description: 'قيادة مبادرة تطوعية', descriptionEn: 'Lead a volunteer initiative', icon: '🚀', category: 'VOLUNTEER', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 1 },
  { key: 'community_ambassador', name: 'سفير المجتمع', nameEn: 'Community Ambassador', description: 'تحقيق لقب سفير المجتمع', descriptionEn: 'Earn the community ambassador title', icon: '🌍', category: 'VOLUNTEER', rarity: 'LEGENDARY', tier: 5, points: 150, xpReward: 300, threshold: 1 },

  // ═══════════ STREAKS ═══════════
  { key: 'streak_7', name: 'سلسلة 7 أيام', nameEn: '7-Day Streak', description: 'تسجيل الدخول 7 أيام متتالية', descriptionEn: 'Log in 7 consecutive days', icon: '🔥', category: 'STREAK', rarity: 'COMMON', tier: 1, points: 15, xpReward: 30, threshold: 7 },
  { key: 'streak_30', name: 'سلسلة 30 يوم', nameEn: '30-Day Streak', description: 'تسجيل الدخول 30 يوماً متتالياً', descriptionEn: 'Log in 30 consecutive days', icon: '🔥', category: 'STREAK', rarity: 'UNCOMMON', tier: 2, points: 50, xpReward: 100, threshold: 30 },
  { key: 'streak_100', name: 'سلسلة 100 يوم', nameEn: '100-Day Streak', description: 'تسجيل الدخول 100 يوماً متتالياً', descriptionEn: 'Log in 100 consecutive days', icon: '🔥', category: 'STREAK', rarity: 'EPIC', tier: 4, points: 150, xpReward: 300, threshold: 100 },
  { key: 'streak_365', name: 'سلسلة سنة كاملة', nameEn: '365-Day Streak', description: 'تسجيل الدخول 365 يوماً متتالياً', descriptionEn: 'Log in 365 consecutive days', icon: '🔥', category: 'STREAK', rarity: 'LEGENDARY', tier: 5, points: 500, xpReward: 1000, threshold: 365 },

  // ═══════════ MILESTONES ═══════════
  { key: 'points_100', name: '100 نقطة', nameEn: '100 Points', description: 'الحصول على 100 نقطة سمعة', descriptionEn: 'Earn 100 reputation points', icon: '⭐', category: 'MILESTONE', rarity: 'COMMON', tier: 1, points: 10, xpReward: 20, threshold: 100 },
  { key: 'points_500', name: '500 نقطة', nameEn: '500 Points', description: 'الحصول على 500 نقطة سمعة', descriptionEn: 'Earn 500 reputation points', icon: '⭐', category: 'MILESTONE', rarity: 'UNCOMMON', tier: 2, points: 25, xpReward: 50, threshold: 500 },
  { key: 'points_1000', name: '1000 نقطة', nameEn: '1,000 Points', description: 'الحصول على 1000 نقطة سمعة', descriptionEn: 'Earn 1,000 reputation points', icon: '⭐', category: 'MILESTONE', rarity: 'RARE', tier: 3, points: 50, xpReward: 100, threshold: 1000 },
  { key: 'points_5000', name: '5000 نقطة', nameEn: '5,000 Points', description: 'الحصول على 5000 نقطة سمعة', descriptionEn: 'Earn 5,000 reputation points', icon: '⭐', category: 'MILESTONE', rarity: 'EPIC', tier: 4, points: 150, xpReward: 300, threshold: 5000 },
  { key: 'points_10000', name: '10000 نقطة', nameEn: '10,000 Points', description: 'الحصول على 10000 نقطة سمعة', descriptionEn: 'Earn 10,000 reputation points', icon: '⭐', category: 'MILESTONE', rarity: 'LEGENDARY', tier: 5, points: 300, xpReward: 600, threshold: 10000 },
  { key: 'level_expert', name: 'خبير اقتصادي', nameEn: 'Economic Expert', description: 'الوصول للمستوى الأعلى: خبير اقتصادي', descriptionEn: 'Reach the highest level: Economic Expert', icon: '👑', category: 'MILESTONE', rarity: 'LEGENDARY', tier: 5, points: 200, xpReward: 400, threshold: 1 },

  // ═══════════ SECRET ACHIEVEMENTS ═══════════
  { key: 'secret_easter_egg', name: 'إنجاز مخفي', nameEn: 'Hidden Achievement', description: 'اكتشف المفاجأة الكبرى!', descriptionEn: 'Discover the grand surprise!', icon: '❓', category: 'MILESTONE', rarity: 'MYTHIC', tier: 6, points: 100, xpReward: 200, threshold: 1, isSecret: true },
  { key: 'secret_night_owl', name: 'بومة الليل', nameEn: 'Night Owl', description: 'تنشر محتوى بعد منتصف الليل', descriptionEn: 'Publish content after midnight', icon: '🦉', category: 'WRITING', rarity: 'RARE', tier: 3, points: 15, xpReward: 30, threshold: 1, isSecret: true },
  { key: 'secret_speed_demon', name: 'سريع كالبرق', nameEn: 'Lightning Fast', description: 'تنشر إجابة خلال 60 ثانية من طرح السؤال', descriptionEn: 'Answer within 60 seconds of a question being posted', icon: '⚡', category: 'QA', rarity: 'RARE', tier: 3, points: 20, xpReward: 40, threshold: 1, isSecret: true },
  { key: 'secret_polyglot', name: 'متعدد اللغات', nameEn: 'Polyglot', description: 'تنشر محتوى بالعربية والإنجليزية', descriptionEn: 'Publish content in both Arabic and English', icon: '🌐', category: 'WRITING', rarity: 'UNCOMMON', tier: 2, points: 20, xpReward: 40, threshold: 1, isSecret: true },

  // ═══════════ SEASONAL ═══════════
  { key: 'seasonal_researcher_2026', name: 'باحث العام 2026', nameEn: 'Researcher of 2026', description: 'أفضل باحث في عام 2026', descriptionEn: 'Best researcher of 2026', icon: '🏆', category: 'SEASONAL', rarity: 'LEGENDARY', tier: 5, points: 200, xpReward: 400, threshold: 1, isSeasonal: true },
  { key: 'seasonal_analyst_2026', name: 'أفضل محلل اقتصادي 2026', nameEn: 'Top Analyst 2026', description: 'أفضل محلل اقتصادي في عام 2026', descriptionEn: 'Top economic analyst of 2026', icon: '📊', category: 'SEASONAL', rarity: 'LEGENDARY', tier: 5, points: 200, xpReward: 400, threshold: 1, isSeasonal: true },
  { key: 'seasonal_rising_star', name: 'نجم صاعد', nameEn: 'Rising Star', description: 'تحقيق نمو استثنائي خلال شهر واحد', descriptionEn: 'Achieve exceptional growth in one month', icon: '🌟', category: 'SEASONAL', rarity: 'EPIC', tier: 4, points: 100, xpReward: 200, threshold: 1, isSeasonal: true },
]

export async function POST(request: NextRequest) {
  try {
    // حماية مسارات البذر — تعطيل في الإنتاج
    if (process.env.NODE_ENV === 'production') {
      return NextResponse.json(
        { success: false, error: 'Seed routes are disabled in production' },
        { status: 403 }
      )
    }

    await requireAuth()
    let created = 0
    let skipped = 0

    for (const ach of ACHIEVEMENTS) {
      const existing = await db.achievement.findUnique({ where: { key: ach.key } })
      if (existing) {
        skipped++
        continue
      }
      await db.achievement.create({
        data: {
          ...ach,
          nameEn: ach.nameEn || ach.name,
          descriptionEn: ach.descriptionEn || ach.description,
          isSecret: ach.isSecret || false,
          isSeasonal: ach.isSeasonal || false,
          chainParentId: null,
          chainOrder: null,
          totalEarners: 0,
          requirements: undefined,
          rewards: JSON.stringify({ xp: ach.xpReward, points: ach.points }),
        },
      })
      created++
    }

    return NextResponse.json({ created, skipped, total: ACHIEVEMENTS.length })
  } catch (error) {
    return handleApiError(error)
  }
}
