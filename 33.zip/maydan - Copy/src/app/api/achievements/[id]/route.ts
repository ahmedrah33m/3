import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { handleApiError } from '@/lib/session'
import { statusToCode } from '@/lib/api-utils'

export const dynamic = 'force-dynamic'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const achievement = await db.achievement.findUnique({
      where: { id },
      include: {
        _count: { select: { userAchievements: true } },
      },
    })

    if (!achievement) {
      return NextResponse.json({ success: false, error: 'Not found', code: statusToCode(404) }, { status: 404 })
    }

    return NextResponse.json({ achievement })
  } catch (error) {
    return handleApiError(error)
  }
}
