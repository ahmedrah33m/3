import { db } from '@/lib/db'
import { requireAuth, handleApiError } from '@/lib/session'
import { NextResponse } from 'next/server'

// POST — إنشاء حساب معلن (يتطلب auth، userId من الجلسة)
export async function POST(request: Request) {
  try {
    const user = await requireAuth()

    const body = await request.json()
    const { companyName, contactEmail, contactPhone, businessType } = body

    const dbAny = db as any
    const existing = await dbAny.advertiserAccount.findUnique({
      where: { userId: user.id },
    })

    if (existing) {
      return NextResponse.json(
        { message: 'يوجد حساب معلن مسبقاً لهذا المستخدم' },
        { status: 409 }
      )
    }

    const account = await dbAny.advertiserAccount.create({
      data: {
        userId: user.id,  // ✅ من الجلسة
        companyName: companyName || null,
        contactEmail: contactEmail || user.email,
        contactPhone: contactPhone || null,
        businessType: businessType || 'INDIVIDUAL',
        balance: 0,
        totalSpent: 0,
        isVerified: false,
      },
    })

    return NextResponse.json(
      {
        message: 'تم إنشاء حساب المعلن بنجاح',
        data: account,
      },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}

// GET — جلب حساب المعلن للمستخدم الحالي (يتطلب auth)
export async function GET() {
  try {
    const user = await requireAuth()

    const dbAny = db as any
    const account = await dbAny.advertiserAccount.findUnique({
      where: { userId: user.id },
      include: {
        user: {
          select: { id: true, name: true, email: true, avatar: true },
        },
      },
    })

    if (!account) {
      return NextResponse.json(
        { message: 'حساب المعلن غير موجود' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      message: 'تم جلب بيانات حساب المعلن بنجاح',
      data: account,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
