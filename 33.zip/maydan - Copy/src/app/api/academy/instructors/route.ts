import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - List real academy instructors (approved) with aggregated stats.
export async function GET() {
  try {
    const profiles = await db.instructorProfile.findMany({
      where: { isApproved: true },
      include: {
        user: { select: { id: true, name: true, avatar: true, jobTitle: true } },
      },
      orderBy: { totalStudents: 'desc' },
      take: 50,
    })

    const instructors = profiles.map((p) => {
      let specialty = p.user.jobTitle || ''
      if (!specialty && p.specializations) {
        try {
          const specs = JSON.parse(p.specializations as unknown as string) as string[]
          specialty = specs.join('، ')
        } catch {
          specialty = ''
        }
      }
      return {
        id: p.userId,
        name: p.user.name || 'مدرّب',
        avatar: p.user.avatar || undefined,
        specialty,
        students: p.totalStudents,
        courses: p.totalCourses,
        rating: p.avgRating,
        bio: p.bio || '',
      }
    })

    return NextResponse.json({ instructors })
  } catch (error) {
    console.error('Academy instructors error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
