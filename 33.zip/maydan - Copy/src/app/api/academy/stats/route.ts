import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

export async function GET() {
  try {
    const [totalCourses, totalStudents, totalCertificates, instructors, courses] = await Promise.all([
      db.learningPath.count({ where: { isPublished: true } }),
      db.enrollment.count(),
      db.certificate.count(),
      db.learningPath.findMany({
        where: { authorId: { not: null } },
        select: { authorId: true },
        distinct: ['authorId'],
      }),
      db.learningPath.findMany({
        where: { isPublished: true },
        select: { avgRating: true, ratingCount: true, duration: true },
      }),
    ])

    const totalHours = courses.reduce((acc, c) => acc + c.duration, 0)
    const rated = courses.filter(c => c.avgRating > 0)
    const avgRating = rated.length > 0
      ? rated.reduce((acc, c) => acc + c.avgRating, 0) / rated.length
      : 0

    return NextResponse.json({
      totalCourses,
      totalStudents,
      totalCertificates,
      totalInstructors: instructors.length,
      totalHours: Math.round(totalHours / 60),
      avgRating: Math.round(avgRating * 10) / 10,
    })
  } catch (error) {
    console.error('Academy stats error:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch stats', code: statusToCode(500) }, { status: 500 })
  }
}
