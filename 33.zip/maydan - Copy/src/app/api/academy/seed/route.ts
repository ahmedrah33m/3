import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

const SEED_COURSES = [
  {
    title: 'مبادئ الاقتصاد الكلي',
    titleEn: 'Principles of Macroeconomics',
    description: 'دورة شاملة في المفاهيم الاقتصادية الأساسية: العرض والطلب، التضخم، النمو الاقتصادي، السياسة النقدية والمالية',
    category: 'economics', difficulty: 'BEGINNER', price: 0, originalPrice: 0,
    duration: 480, lessonsCount: 24, enrolledCount: 1250, avgRating: 4.8, ratingCount: 320,
    authorName: 'د. أحمد محمد', isFeatured: true, isPublished: true, language: 'ar',
    whatYouLearn: '["فهم مفاهيم العرض والطلب","تحليل مؤشرات الاقتصاد الكلي","دور السياسة النقدية","فهم آليات التضخم وال deflation"]',
    requirements: '["لا يوجد متطلبات مسبقة","الرغبة في التعلم"]',
    sections: [
      { title: 'مقدمة في الاقتصاد', lessons: [
        { title: 'ما هو الاقتصاد؟', duration: 15, type: 'VIDEO', isFree: true, content: 'مقدمة شاملة لمفهوم الاقتصاد وأهميته في الحياة اليومية' },
        { title: 'المفاهيم الأساسية', duration: 20, type: 'VIDEO', isFree: true, content: 'شرح المفاهيم الأساسية مثل العرض والطلب والسعر' },
        { title: 'أنواع الأنظمة الاقتصادية', duration: 25, type: 'VIDEO', isFree: false, content: 'النظام الرأسمالي والاشتراكي والاقتصاد المختلط' },
      ]},
      { title: 'العرض والطلب', lessons: [
        { title: 'قانون العرض والطلب', duration: 25, type: 'VIDEO', isFree: false, content: 'شرح تفصيلي لقانون العرض والطلب وتأثيره على الأسعار' },
        { title: 'توازن السوق', duration: 20, type: 'VIDEO', isFree: false, content: 'كيف يتحقق التوازن في السوق الحر' },
        { title: 'مرونة العرض والطلب', duration: 22, type: 'VIDEO', isFree: false, content: 'فهم مرونة العرض ومرونة الطلب' },
      ]},
      { title: 'النمو الاقتصادي', lessons: [
        { title: 'مقدمة في النمو الاقتصادي', duration: 30, type: 'VIDEO', isFree: false, content: 'مؤشرات النمو الاقتصادي وقياسه' },
        { title: 'عوامل النمو', duration: 25, type: 'VIDEO', isFree: false, content: 'العوامل المؤثرة في النمو الاقتصادي' },
      ]},
    ],
  },
  {
    title: 'المحاسبة المالية للمبتدئين',
    titleEn: 'Financial Accounting for Beginners',
    description: 'تعلم أساسيات المحاسبة من الصفر: قوائم الدخل، الميزان العمومي، التدفق النقدي',
    category: 'accounting', difficulty: 'BEGINNER', price: 0, originalPrice: 0,
    duration: 720, lessonsCount: 36, enrolledCount: 980, avgRating: 4.7, ratingCount: 210,
    authorName: 'أ. سارة أحمد', isFeatured: true, isPublished: true, language: 'ar',
    whatYouLearn: '["إعداد القوائم المالية","فهم الميزان العمومي","تحليل التدفقات النقدية"]',
    requirements: '["أساسيات الحاسوب"]',
    sections: [
      { title: 'مقدمة في المحاسبة', lessons: [
        { title: 'تاريخ المحاسبة', duration: 15, type: 'VIDEO', isFree: true, content: 'نظرة تاريخية على تطور المحاسبة' },
        { title: 'مبادئ المحاسبة الأساسية', duration: 20, type: 'VIDEO', isFree: true, content: 'المبادئ المحاسبية المتعارف عليها' },
      ]},
      { title: 'القوائم المالية', lessons: [
        { title: 'قائمة الدخل', duration: 25, type: 'VIDEO', isFree: false, content: 'إعداد وتحليل قائمة الدخل' },
        { title: 'الميزان العمومي', duration: 30, type: 'VIDEO', isFree: false, content: 'إعداد الميزان العمومي والتحقق من التوازن' },
        { title: 'قائمة التدفقات النقدية', duration: 25, type: 'VIDEO', isFree: false, content: 'إعداد قائمة التدفقات النقدية' },
      ]},
    ],
  },
  {
    title: 'تحليل البيانات بـ Power BI',
    titleEn: 'Data Analysis with Power BI',
    description: 'إتقان الأداة الأقوى لتحليل البيانات وإنشاء لوحات معلومات تفاعلية',
    category: 'powerbi', difficulty: 'INTERMEDIATE', price: 50000, originalPrice: 75000,
    duration: 900, lessonsCount: 45, enrolledCount: 2100, avgRating: 4.9, ratingCount: 450,
    authorName: 'م. علي حسن', isFeatured: true, isPublished: true, language: 'ar',
    whatYouLearn: '["بناء نماذج بيانات","إنشاء تقارير تفاعلية","إتقان DAX","مشاركة اللوحات"]',
    requirements: '["معرفة أساسية بـ Excel","جهاز حاسوب بمواصفات مناسبة"]',
    sections: [
      { title: 'أساسيات Power BI', lessons: [
        { title: 'تثبيت Power BI', duration: 10, type: 'VIDEO', isFree: true, content: 'خطوات التثبيت والإعداد' },
        { title: 'واجهة المستخدم', duration: 20, type: 'VIDEO', isFree: true, content: 'شرح واجهة المستخدم وأقسامها' },
      ]},
      { title: 'تحليل البيانات', lessons: [
        { title: 'استيراد البيانات', duration: 25, type: 'VIDEO', isFree: false, content: 'طرق استيراد البيانات من مصادر مختلفة' },
        { title: 'DAX fundamentals', duration: 30, type: 'VIDEO', isFree: false, content: 'أساسيات لغة DAX' },
      ]},
    ],
  },
  {
    title: 'مقدمة في Python للبيانات',
    titleEn: 'Python for Data',
    description: 'تعلم البرمجة لتحليل البيانات الاقتصادية باستخدام Python وPandas',
    category: 'python', difficulty: 'INTERMEDIATE', price: 75000, originalPrice: 100000,
    duration: 1200, lessonsCount: 60, enrolledCount: 1500, avgRating: 4.6, ratingCount: 280,
    authorName: 'م. خالد عمر', isFeatured: true, isPublished: true, language: 'ar',
    whatYouLearn: '["أساسيات Python","تحليل البيانات بـ Pandas","التصور البياني","التعلم الآلي"]',
    requirements: '["معرفة أساسية بالبرمجة","جهاز حاسوب"]',
    sections: [
      { title: 'أساسيات Python', lessons: [
        { title: 'تثبيت Python', duration: 15, type: 'VIDEO', isFree: true, content: 'تثبيت Python وإعداد بيئة العمل' },
        { title: 'المتغيرات والأنواع', duration: 25, type: 'VIDEO', isFree: true, content: 'أنواع البيانات في Python' },
      ]},
      { title: 'Pandas للبيانات', lessons: [
        { title: 'مقدمة في Pandas', duration: 30, type: 'VIDEO', isFree: false, content: 'شرح مكتبة Pandas' },
      ]},
    ],
  },
  {
    title: 'تحليل النفط والغاز',
    titleEn: 'Oil & Gas Analysis',
    description: 'فهم صناعة النفط من الإنتاج إلى التكرير: الجيولوجيا، الهندسة، الأسواق',
    category: 'oil_gas', difficulty: 'ADVANCED', price: 100000, originalPrice: 150000,
    duration: 600, lessonsCount: 30, enrolledCount: 650, avgRating: 4.5, ratingCount: 120,
    authorName: 'م. حسين جعفر', isFeatured: false, isPublished: true, language: 'ar',
    whatYouLearn: '["فهم صناعة النفط الشاملة","تحليل أسعار النفط","دور أوبك","مشاريع الغاز"]',
    requirements: '["خلفية في الهندسة أو العلوم"]',
    sections: [
      { title: 'مقدمة في صناعة النفط', lessons: [
        { title: 'تاريخ النفط', duration: 20, type: 'VIDEO', isFree: true, content: 'تاريخ اكتشاف النفط واستخدامه' },
      ]},
    ],
  },
  {
    title: 'الإدارة الاستراتيجية',
    titleEn: 'Strategic Management',
    description: 'تطوير مهارات التخطيط الاستراتيجي واتخاذ القرارات',
    category: 'management', difficulty: 'INTERMEDIATE', price: 40000, originalPrice: 60000,
    duration: 480, lessonsCount: 24, enrolledCount: 890, avgRating: 4.4, ratingCount: 180,
    authorName: 'د. فاطمة علي', isFeatured: false, isPublished: true, language: 'ar',
    whatYouLearn: '["صياغة الاستراتيجيات","تحليل البيئة التنافسية","القيادة الفعالة"]',
    requirements: '["خبرة إدارية مفضّلة"]',
    sections: [
      { title: 'مبادئ الاستراتيجية', lessons: [
        { title: 'ما هي الاستراتيجية؟', duration: 20, type: 'VIDEO', isFree: true, content: 'تعريف الاستراتيجية وأهميتها' },
      ]},
    ],
  },
  {
    title: 'تحليل الأسهم والاستثمارات',
    titleEn: 'Stock & Investment Analysis',
    description: 'تعلم تحليل الشركات واتخاذ قرارات الاستثمار الصحيحة',
    category: 'investment', difficulty: 'ADVANCED', price: 80000, originalPrice: 120000,
    duration: 840, lessonsCount: 42, enrolledCount: 1800, avgRating: 4.8, ratingCount: 380,
    authorName: 'م. محمد رشيد', isFeatured: true, isPublished: true, language: 'ar',
    whatYouLearn: '["التحليل المالي","التحليل الفني","إدارة المحافظة","تقييم المخاطر"]',
    requirements: '["基础知识 في المالية"]',
    sections: [
      { title: 'أساسيات الاستثمار', lessons: [
        { title: 'مقدمة في الأسواق المالية', duration: 25, type: 'VIDEO', isFree: true, content: 'نظرة عامة على الأسواق المالية' },
      ]},
    ],
  },
  {
    title: 'الذكاء الاصطناعي في الأعمال',
    titleEn: 'AI in Business',
    description: 'كيفية استخدام AI في التحليلات الاقتصادية والقرارات الاستراتيجية',
    category: 'ai', difficulty: 'ADVANCED', price: 120000, originalPrice: 180000,
    duration: 960, lessonsCount: 48, enrolledCount: 2500, avgRating: 4.9, ratingCount: 520,
    authorName: 'د. نور حسين', isFeatured: true, isPublished: true, language: 'ar',
    whatYouLearn: '["أساسيات AI","التعلم الآلي","معالجة اللغات الطبيعية","التحليل التنبؤي"]',
    requirements: '["معرفة بـ Python","معرفة رياضيات أساسية"]',
    sections: [
      { title: 'مقدمة في الذكاء الاصطناعي', lessons: [
        { title: 'ما هو الذكاء الاصطناعي', duration: 20, type: 'VIDEO', isFree: true, content: 'مقدمة شاملة في مفاهيم الذكاء الاصطناعي' },
      ]},
    ],
  },
  {
    title: 'Excel للمحترفين',
    titleEn: 'Excel for Professionals',
    description: 'إتقان Excel من الأساسيات حتى الدوال المتقدمة والجداول المحورية',
    category: 'excel', difficulty: 'BEGINNER', price: 25000, originalPrice: 40000,
    duration: 600, lessonsCount: 30, enrolledCount: 3200, avgRating: 4.7, ratingCount: 600,
    authorName: 'م. رنا صلاح', isFeatured: false, isPublished: true, language: 'ar',
    whatYouLearn: '["الدوال الأساسية والمتقدمة","الجداول المحورية","الرسوم البيانية","VBA"]',
    requirements: '["جهاز حاسوب مع Excel"]',
    sections: [
      { title: 'أساسيات Excel', lessons: [
        { title: 'واجهة Excel', duration: 10, type: 'VIDEO', isFree: true, content: 'شرح واجهة Excel' },
      ]},
    ],
  },
  {
    title: 'ريادة الأعمال في العراق',
    titleEn: 'Entrepreneurship in Iraq',
    description: 'بناء وتطوير مشروعك الناشئ في البيئة العراقية',
    category: 'entrepreneurship', difficulty: 'INTERMEDIATE', price: 35000, originalPrice: 50000,
    duration: 720, lessonsCount: 36, enrolledCount: 780, avgRating: 4.3, ratingCount: 150,
    authorName: 'م. حسن كريم', isFeatured: false, isPublished: true, language: 'ar',
    whatYouLearn: '["تصديق فكرتك","خطة العمل","التسويق","التمويل"]',
    requirements: '["فكرة مشروع"]',
    sections: [
      { title: 'بناء الفكرة', lessons: [
        { title: 'كيف تختار فكرتك', duration: 20, type: 'VIDEO', isFree: true, content: 'طرق اختيار فكرة المشروع المناسبة' },
      ]},
    ],
  },
  {
    title: 'التسويق الرقمي',
    titleEn: 'Digital Marketing',
    description: 'استراتيجيات التسويق عبر الإنترنت ووسائل التواصل الاجتماعي',
    category: 'marketing', difficulty: 'INTERMEDIATE', price: 45000, originalPrice: 65000,
    duration: 600, lessonsCount: 30, enrolledCount: 1100, avgRating: 4.6, ratingCount: 230,
    authorName: 'أ. مريم حسين', isFeatured: false, isPublished: true, language: 'ar',
    whatYouLearn: '["SEO","الإعلانات المدفوعة","التسويق بالمحتوى","تحليل النتائج"]',
    requirements: '["معرفة بالإنترنت"]',
    sections: [
      { title: 'أساسيات التسويق الرقمي', lessons: [
        { title: 'مقدمة في التسويق الرقمي', duration: 15, type: 'VIDEO', isFree: true, content: 'نظرة عامة على عالم التسويق الرقمي' },
      ]},
    ],
  },
  {
    title: 'إدارة المشاريع Agile',
    titleEn: 'Agile Project Management',
    description: 'تعلم منهجيات Agile وScrum لإدارة المشاريع بفعالية',
    category: 'project_mgmt', difficulty: 'INTERMEDIATE', price: 55000, originalPrice: 80000,
    duration: 480, lessonsCount: 24, enrolledCount: 650, avgRating: 4.5, ratingCount: 130,
    authorName: 'م. سمير ياسين', isFeatured: false, isPublished: true, language: 'ar',
    whatYouLearn: '["مبادئ Agile","دور Scrum Master","Sprint Planning","أدوات إدارة المشاريع"]',
    requirements: '["خبرة في العمل الجماعي"]',
    sections: [
      { title: 'مقدمة في Agile', lessons: [
        { title: ' Agile vs Waterfall', duration: 20, type: 'VIDEO', isFree: true, content: 'مقارنة بين المناهج البرمجية' },
      ]},
    ],
  },
]

const SEED_QUIZZES = [
  {
    title: 'اختبار المفاهيم الاقتصادية الأساسية',
    description: 'اختبار شامل للمفاهيم الاقتصادية الأساسية',
    category: 'economics', difficulty: 'BEGINNER', timeLimit: 30,
    questions: [
      { question: 'ما هو التعريف الصحيح لـ GDP؟', options: ['إجمالي المنتجات والسلع في странة','إجمالي القيمة المضافة لجميع السلع والخدمات النهائية','إجمالي الإيرادات الحكومية','إجمالي الاستيراد والتصدير'], correctAnswer: 1, explanation: 'GDP يمثل إجمالي القيمة المضافة لجميع السلع والخدمات النهائية المُنتجة داخل الدولة خلال فترة محددة' },
      { question: 'ماذا يحدث عندما يزداد العرض والطلب معاً؟', options: ['يزداد السعر بالتأكيد','ينقص السعر بالتأكيد','لا يتغير السعر','لا يمكن التنبؤ بالسعر بدون معرفة حجم التغير'], correctAnswer: 3, explanation: 'عندما يزداد العرض والطلب معاً، يعتمد تغير السعر على حجم التغير في كل منهما' },
      { question: 'ما هو التضخم؟', options: ['انخفاض الأسعار بشكل عام','ارتفاع الأسعار بشكل عام وت持续推进','ثبات الأسعار','زيادة الإنتاج فقط'], correctAnswer: 1, explanation: 'التضخم هو الارتفاع المستمر في المستوى العام للأسعار' },
      { question: 'ما هي الأداة الرئيسية للسياسة النقدية؟', options: ['الضرائب','سعر الفائدة','الميزانية الحكومية','التعريفات الجمركية'], correctAnswer: 1, explanation: 'سعر الفائدة هو الأداة الرئيسية للبنوك المركزية في تنفيذ السياسة النقدية' },
      { question: 'ما هو العرض والطلب؟', options: ['نظام محاسبي','العلاقة بين الكمية المطلوبة والكمية المعروضة والسعر','نوع من أنواع الضرائب','法则 اقتصادية قديمة'], correctAnswer: 1, explanation: 'قانون العرض والطلب يشرح العلاقة بين الكمية المطلوبة والكمية المعروضة وتأثيرها على السعر' },
    ],
  },
  {
    title: 'اختبار المحاسبة المالية',
    description: 'اختبار في أساسيات المحاسبة المالية',
    category: 'accounting', difficulty: 'BEGINNER', timeLimit: 45,
    questions: [
      { question: 'ما هي المعادلة المحاسبية الأساسية؟', options: ['الأصول = الخصوم + حقوق الملكية','الأصول = الخصوم - حقوق الملكية','الإيرادات = المصروفات','الدخل = المصروفات'], correctAnswer: 0, explanation: 'المعادلة المحاسبية: الأصول = الخصوم + حقوق الملكية' },
      { question: 'في قائمة الدخل، ما هو صافي الربح؟', options: ['الإيرادات فقط','الإيرادات - تكلفة البضاعة المباعة','الإيرادات - جميع المصروفات','المصروفات فقط'], correctAnswer: 2, explanation: 'صافي الربح = الإيرادات - جميع المصروفات' },
      { question: 'ما هو الميزان العمومي؟', options: ['قائمة بالمدفوعات فقط','قائمة تظهر حسابات الأصول والخصوم والحقوق','قائمة بالميزانية الحكومية','تقرير عن المبيعات'], correctAnswer: 1, explanation: 'الميزان العمومي يسرد جميع الحسابات ويظهر التوازن بين الأصول والخصوم وحقوق الملكية' },
      { question: 'ما هو التدفق النقدي؟', options: [' movements في النقد خلال فترة محددة','قيمة الأصول النقدية فقط','صافي الأرباح','الرصيد البنكي'], correctAnswer: 0, explanation: 'التدفق النقدي يمثل حركة النقد الداخلة والخارجة خلال فترة معينة' },
    ],
  },
  {
    title: 'اختبار Power BI',
    description: 'اختبار في أساسيات تحليل البيانات بـ Power BI',
    category: 'powerbi', difficulty: 'INTERMEDIATE', timeLimit: 25,
    questions: [
      { question: 'ما هو DAX في Power BI؟', options: ['لغة استعلام بيانات','لغة تعريف النماذج والتحليل','اسم البرنامج','نوع من البيانات'], correctAnswer: 1, explanation: 'DAX (Data Analysis Expressions) هي لغة تعريف النماذج والتحليل في Power BI' },
      { question: 'ما هي مكونات Power BI الأساسية؟', options: ['Power Query فقط','Power Query + Power Pivot + Power View','Excel + Word','البيانات فقط'], correctAnswer: 1, explanation: 'Power BI يتكون من Power Query لاستيراد البيانات، Power Pivot للنمذجة، وPower View للتصور' },
      { question: 'كيف تستورد البيانات في Power BI؟', options: ['نسخ ولصق','من مصادر متعددة عبر Get Data','طباعة البيانات','إرسال بريد إلكتروني'], correctAnswer: 1, explanation: 'تُستورد البيانات عبر ميزة Get Data التي تدعم مصادر بيانات متعددة' },
    ],
  },
  {
    title: 'اختبار Python الأساسي',
    description: 'اختبار في أساسيات برمجة Python',
    category: 'python', difficulty: 'INTERMEDIATE', timeLimit: 40,
    questions: [
      { question: 'ما هي طريقة طباعة النص في Python؟', options: ['echo("text")','print("text")','console.log("text")','printf("text")'], correctAnswer: 1, explanation: 'في Python نستخدم print() لطباعة النصوص' },
      { question: 'ما هو نوع البيانات list في Python؟', options: ['نوع رقمي','مصفوفة منظمة (mutable sequence)','نوع نصي فقط','قيمة منطقية'], correctAnswer: 1, explanation: 'List هو نوع بيانات يمثل تسلسلاً من العناصر يمكن تعديله' },
      { question: 'كيف تُعرّف دالة في Python؟', options: ['function name() {}','def name():','func name():','d function name()'], correctAnswer: 1, explanation: 'في Python نستخدم كلمة def لتعريف الدوال' },
    ],
  },
  {
    title: 'اختبار الذكاء الاصطناعي',
    description: 'اختبار في مفاهيم الذكاء الاصطناعي والتعلم الآلي',
    category: 'ai', difficulty: 'ADVANCED', timeLimit: 50,
    questions: [
      { question: 'ما هو التعلم الآلي (Machine Learning)؟', options: ['برمجة الحاسوب يدوياً','نظام يتعلم من البيانات دون برمجة صريحة','نوع من أنواع القواعد','برنامج حاسوبي عادي'], correctAnswer: 1, explanation: 'التعلم الآلي هو فرع من الذكاء الاصطناعي يمكّن الأنظمة من التعلم والتحسين من البيانات' },
      { question: 'ما هي الشبكات العصبية الاصطناعية؟', options: ['شبكات إنترنت','نماذج حاسوبية مستلهمة من الدماغ البشري','نوع من الطاقة','أجهزة حاسوب'], correctAnswer: 1, explanation: 'الشبكات العصبية الاصطناعية هي نماذج حاسوبية مستلهمة من هيكل وعمل الدماغ البشري' },
      { question: 'ما هو التعلم العميق (Deep Learning)؟', options: ['تعلم في المكتبات','استخدام شبكات عصبية متعددة الطبقات','تعلم اللغة العربية','برمجة قواعد البيانات'], correctAnswer: 1, explanation: 'التعلم العميق يستخدم شبكات عصبية بطبقات متعددة لمعالجة البيانات المعقدة' },
      { question: 'ما هي معالجة اللغات الطبيعية (NLP)؟', options: ['ترجمة اللغات الآلية فقط','فهم وتحليل ومعالجة اللغة البشرية','إدخال البيانات يدوياً','طباعة النصوص'], correctAnswer: 1, explanation: 'NLP هو مجال من الذكاء الاصطناعي يهتم بفهم وتحليل ومعالجة اللغة البشرية' },
    ],
  },
  {
    title: 'اختبار تحليل النفط والغاز',
    description: 'اختبار متقدم في صناعة النفط والغاز',
    category: 'oil_gas', difficulty: 'ADVANCED', timeLimit: 60,
    questions: [
      { question: 'ما هي عضوية OPEC؟', options: ['منظمة الدول المصدرة للنفط','منظمة الدول المستوردة للغاز','منظمة الدول الأوروبية','منظمة الدول الآسيوية'], correctAnswer: 0, explanation: 'OPEC هي منظمة الدول المصدرة للنفط، تأسست عام 1960' },
      { question: 'ما هو البرميل الواحد باللتر تقريباً؟', options: ['100 لتر','159 لتر','200 لتر','50 لتر'], correctAnswer: 1, explanation: 'برميل واحد يساوي تقريباً 159 لتر' },
      { question: 'ما هي مراحل تكرير النفط؟', options: ['تقطير فقط','تقطير + تحويل كيميائي + تنقية','تصدير فقط','استخراج فقط'], correctAnswer: 1, explanation: 'يشمل التكرير التقطير التحتي والتحويل الكيميائي والتنقية' },
    ],
  },
]

// Skills granted per course category (flows into Skill Passport + Professional Passport).
const SKILLS_BY_CATEGORY: Record<string, string[]> = {
  economics: ['الاقتصاد الكلي'],
  accounting: ['المحاسبة المالية'],
  powerbi: ['Power BI', 'تحليل البيانات'],
  python: ['Python', 'تحليل البيانات'],
  oil_gas: ['تحليل النفط والغاز'],
  management: ['الإدارة الاستراتيجية'],
  investment: ['تحليل الأسهم', 'الاستثمار'],
  ai: ['الذكاء الاصطناعي'],
  excel: ['Excel'],
  entrepreneurship: ['ريادة الأعمال'],
  marketing: ['التسويق الرقمي'],
  project_mgmt: ['إدارة المشاريع'],
}

export async function POST() {
  try {
    // حماية مسارات البذر — تعطيل في الإنتاج
    if (process.env.NODE_ENV === 'production') {
      return NextResponse.json(
        { success: false, error: 'Seed routes are disabled in production' },
        { status: 403 }
      )
    }

    const existingCourses = await db.learningPath.count()
    if (existingCourses > 0) {
      return NextResponse.json({ message: 'Database already seeded', courses: existingCourses })
    }

    let coursesCreated = 0
    for (const courseData of SEED_COURSES) {
      const { sections, titleEn, ...courseFields } = courseData
        const course = await db.learningPath.create({
          data: {
            ...courseFields,
            difficulty: courseFields.difficulty as 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED',
            skills: SKILLS_BY_CATEGORY[courseData.category] || [],
            lastUpdated: new Date(),
          },
        })

      let lessonOrder = 0
      for (const sectionData of sections) {
        const section = await db.courseSection.create({
          data: {
            courseId: course.id,
            title: sectionData.title,
            order: sections.indexOf(sectionData),
          },
        })

        for (const lessonData of sectionData.lessons) {
          await db.lesson.create({
            data: {
              pathId: course.id,
              sectionId: section.id,
              title: lessonData.title,
              content: lessonData.content,
              duration: lessonData.duration,
              type: lessonData.type,
              isFree: lessonData.isFree,
              order: lessonOrder++,
            },
          })
        }
      }
      coursesCreated++
    }

    let quizzesCreated = 0
    for (const quizData of SEED_QUIZZES) {
      const quiz = await db.quiz.create({
        data: {
          title: quizData.title,
          description: quizData.description,
          category: quizData.category,
          difficulty: quizData.difficulty as 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED',
          timeLimit: quizData.timeLimit,
          questionsCount: quizData.questions.length,
        },
      })

      for (let i = 0; i < quizData.questions.length; i++) {
        const q = quizData.questions[i]
        await db.quizQuestion.create({
          data: {
            quizId: quiz.id,
            question: q.question,
            correctAnswer: q.correctAnswer,
            explanation: q.explanation,
            order: i,
            optionRecords: {
              create: q.options.map((opt, j) => ({
                text: opt,
                optionIndex: j,
                isCorrect: j === q.correctAnswer,
              })),
            },
          },
        })
      }
      quizzesCreated++
    }

    return NextResponse.json({
      success: true,
      courses: coursesCreated,
      quizzes: quizzesCreated,
      totalLessons: SEED_COURSES.reduce((a, c) => a + c.sections.reduce((b, s) => b + s.lessons.length, 0), 0),
      totalQuestions: SEED_QUIZZES.reduce((a, q) => a + q.questions.length, 0),
    })
  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json({ success: false, error: String(error), code: statusToCode(500) }, { status: 500 })
  }
}
