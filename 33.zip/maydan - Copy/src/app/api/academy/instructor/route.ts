import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - Get instructor application status or profile
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const [application, profile] = await Promise.all([
      db.instructorApplication.findFirst({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
      }),
      db.instructorProfile.findUnique({
        where: { userId: user.id },
      }),
    ])

    return NextResponse.json({ application, profile })
  } catch (error) {
    console.error('Instructor GET error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}

// POST - Submit instructor application
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const existing = await db.instructorProfile.findUnique({
      where: { userId: user.id },
    })
    if (existing?.isApproved) {
      return NextResponse.json({ success: false, error: 'Already approved', code: statusToCode(409) }, { status: 409 })
    }

    const pending = await db.instructorApplication.findFirst({
      where: { userId: user.id, status: 'PENDING' },
    })
    if (pending) {
      return NextResponse.json({ success: false, error: 'Application pending', code: statusToCode(409) }, { status: 409 })
    }

    const body = await request.json()
    const { fullName, email, phone, specializations, experience, motivation } = body

    if (!fullName || !email || !experience || !motivation) {
      return NextResponse.json({ success: false, error: 'Missing required fields', code: statusToCode(400) }, { status: 400 })
    }

    const application = await db.instructorApplication.create({
      data: {
        userId: user.id,
        fullName,
        email,
        phone: phone || null,
        specializations: JSON.stringify(specializations || []),
        experience,
        motivation,
      },
    })

    return NextResponse.json({ success: true, application })
  } catch (error) {
    console.error('Instructor POST error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
