import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - Get instructor dashboard data
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const profile = await db.instructorProfile.findUnique({
      where: { userId: user.id },
    })
    if (!profile?.isApproved) {
      return NextResponse.json({ success: false, error: 'Not an approved instructor', code: statusToCode(403) }, { status: 403 })
    }

    const [courses, totalStudents, totalEarnings, recentEnrollments] = await Promise.all([
      db.learningPath.findMany({
        where: { authorId: user.id },
        include: {
          _count: { select: { enrollments: true, reviews: true } },
          sections: { include: { lessons: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      db.enrollment.count({
        where: { course: { authorId: user.id } },
      }),
      db.courseOrder.aggregate({
        where: { course: { authorId: user.id }, status: 'COMPLETED' },
        _sum: { amount: true },
      }),
      db.enrollment.findMany({
        where: { course: { authorId: user.id } },
        include: {
          user: { select: { id: true, name: true, avatar: true } },
          course: { select: { title: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      }),
    ])

    const totalLessons = courses.reduce((acc, c) => acc + c.sections.reduce((a, s) => a + s.lessons.length, 0), 0)
    const avgRating = courses.filter(c => c.avgRating > 0).reduce((acc, c, _, arr) => acc + c.avgRating / arr.length, 0)

    return NextResponse.json({
      courses: courses.map(c => ({
        id: c.id,
        title: c.title,
        category: c.category,
        difficulty: c.difficulty,
        price: c.price,
        enrolledCount: c._count.enrollments,
        reviewCount: c._count.reviews,
        avgRating: c.avgRating,
        lessonsCount: c.sections.reduce((a, s) => a + s.lessons.length, 0),
        isPublished: c.isPublished,
        createdAt: c.createdAt,
      })),
      stats: {
        totalCourses: courses.length,
        totalStudents,
        totalLessons,
        totalEarnings: totalEarnings._sum.amount || 0,
        avgRating: Math.round(avgRating * 10) / 10,
      },
      recentEnrollments: recentEnrollments.map(e => ({
        student: e.user,
        course: e.course.title,
        date: e.createdAt,
      })),
    })
  } catch (error) {
    console.error('Instructor dashboard error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
