import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// POST - Create a new course (instructor only)
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const profile = await db.instructorProfile.findUnique({
      where: { userId: user.id },
    })
    if (!profile?.isApproved) {
      return NextResponse.json({ success: false, error: 'Not an approved instructor', code: statusToCode(403) }, { status: 403 })
    }

    const body = await request.json()
    const {
      title, titleEn, description, category, difficulty,
      price, originalPrice, duration, language,
      whatYouLearn, requirements, subscriptionType,
      sections,
    } = body

    if (!title || !description || !category) {
      return NextResponse.json({ success: false, error: 'Missing required fields', code: statusToCode(400) }, { status: 400 })
    }

    const totalLessons = sections?.reduce(
      (acc: number, s: { lessons?: unknown[] }) => acc + (s.lessons?.length || 0), 0
    ) || 0

    const course = await db.learningPath.create({
      data: {
        title,
        description,
        category,
        difficulty: difficulty || 'BEGINNER',
        price: price || 0,
        originalPrice: originalPrice || 0,
        duration: duration || 0,
        lessonsCount: totalLessons,
        sectionsCount: sections?.length || 0,
        authorId: user.id,
        language: language || 'ar',
        whatYouLearn: whatYouLearn ? JSON.stringify(whatYouLearn) : undefined,
        requirements: requirements ? JSON.stringify(requirements) : undefined,
        subscriptionType: subscriptionType || 'ONE_TIME',
        isPublished: false,
      },
    })

    if (sections && Array.isArray(sections)) {
      let lessonOrder = 0
      for (let si = 0; si < sections.length; si++) {
        const sec = sections[si]
        const section = await db.courseSection.create({
          data: {
            courseId: course.id,
            title: sec.title,
            order: si,
          },
        })

        if (sec.lessons && Array.isArray(sec.lessons)) {
          for (const les of sec.lessons) {
            await db.lesson.create({
              data: {
                pathId: course.id,
                sectionId: section.id,
                title: les.title,
                content: les.content || '',
                duration: les.duration || 0,
                type: les.type || 'TEXT',
                isFree: les.isFree || false,
                videoUrl: les.videoUrl || null,
                order: lessonOrder++,
              },
            })
          }
        }
      }
    }

    return NextResponse.json({ success: true, courseId: course.id })
  } catch (error) {
    console.error('Create course error:', error)
    return NextResponse.json({ success: false, error: 'Failed to create course', code: statusToCode(500) }, { status: 500 })
  }
}
