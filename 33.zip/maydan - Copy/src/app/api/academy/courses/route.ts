import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const search = searchParams.get('search')
    const sort = searchParams.get('sort') || 'featured'
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const where: any = { isPublished: true }

    if (category && category !== 'all') {
      where.category = category
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let orderBy: any = { createdAt: 'desc' }
    switch (sort) {
      case 'featured': orderBy = [{ isFeatured: 'desc' }, { enrolledCount: 'desc' }]; break
      case 'latest': orderBy = { lastUpdated: 'desc' }; break
      case 'popular': orderBy = { viewCount: 'desc' }; break
      case 'rating': orderBy = { avgRating: 'desc' }; break
      case 'free': where.price = 0; orderBy = { enrolledCount: 'desc' }; break
    }

    const [courses, total] = await Promise.all([
      db.learningPath.findMany({
        where,
        orderBy,
        take: limit,
        skip: offset,
        include: {
          author: { select: { id: true, name: true, avatar: true } },
          sections: { include: { lessons: true } },
          _count: { select: { enrollments: true, reviews: true } },
        },
      }),
      db.learningPath.count({ where }),
    ])

    return NextResponse.json({ courses, total, offset, limit })
  } catch (error) {
    console.error('Academy courses error:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch courses', code: statusToCode(500) }, { status: 500 })
  }
}
