import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ enrollments: [] })
    }

    const enrollments = await db.enrollment.findMany({
      where: { userId: user.id },
      include: {
        course: {
          include: {
            author: { select: { id: true, name: true, avatar: true } },
            sections: { include: { lessons: true }, orderBy: { order: 'asc' } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ enrollments })
  } catch (error) {
    console.error('Enrollments error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
