import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - Generate personalized learning path
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    // Get or create profile
    let profile = await db.userLearningProfile.findUnique({
      where: { userId: user.id },
    })
    if (!profile) {
      profile = await db.userLearningProfile.create({
        data: { userId: user.id },
      })
    }

    // Get user's enrollments and completed courses
    const enrollments = await db.enrollment.findMany({
      where: { userId: user.id },
      select: { courseId: true, progress: true },
    })
    const enrolledCourseIds = enrollments.map(e => e.courseId)
    const completedCourseIds = enrollments.filter(e => e.progress >= 100).map(e => e.courseId)

    // Get user's quiz results by category
    const quizAttempts = await db.quizAttempt.findMany({
      where: { userId: user.id },
      include: { quiz: { select: { category: true } } },
    })

    // Calculate skill levels per category from quiz scores
    const categoryScores: Record<string, number[]> = {}
    for (const attempt of quizAttempts) {
      const cat = attempt.quiz.category
      if (!categoryScores[cat]) categoryScores[cat] = []
      categoryScores[cat].push((attempt.score / attempt.totalQuestions) * 100)
    }

    const skillLevels: Record<string, number> = {}
    for (const [cat, scores] of Object.entries(categoryScores)) {
      const avg = scores.reduce((a, b) => a + b, 0) / scores.length
      skillLevels[cat] = avg >= 80 ? 5 : avg >= 65 ? 4 : avg >= 50 ? 3 : avg >= 30 ? 2 : 1
    }

    // Get all published courses
    const allCourses = await db.learningPath.findMany({
      where: { isPublished: true },
      include: {
        sections: { include: { lessons: { select: { id: true } } } },
        _count: { select: { enrollments: true } },
      },
    })

    // Get user's interests and goals
    const interests = profile.interests ? JSON.parse(profile.interests as unknown as string) : []
    const goals = profile.goals ? JSON.parse(profile.goals as unknown as string) : []
    const role = profile.role || 'student'

    // === RECOMMENDATION ALGORITHM ===
    interface ScoredCourse {
      course: typeof allCourses[0]
      score: number
      reasons: string[]
    }

    const scored: ScoredCourse[] = []

    for (const course of allCourses) {
      // Skip already enrolled
      if (enrolledCourseIds.includes(course.id)) continue

      let score = 0
      const reasons: string[] = []

      // 1. SKILL GAP - Low skill in this category
      const courseSkill = skillLevels[course.category] || 0
      if (courseSkill < 3 && courseSkill > 0) {
        score += (5 - courseSkill) * 20
        reasons.push('skill_gap')
      } else if (courseSkill === 0 && enrolledCourseIds.length > 0) {
        // Not assessed in this category = potential gap
        score += 15
        reasons.push('unassessed_category')
      }

      // 2. INTEREST ALIGNMENT
      if (interests.includes(course.category)) {
        score += 25
        reasons.push('interest_aligned')
      }

      // 3. ROLE-BASED RECOMMENDATIONS
      const roleCategoryMap: Record<string, string[]> = {
        researcher: ['economics', 'data_analysis', 'python', 'ai', 'excel'],
        student: ['economics', 'accounting', 'excel', 'powerbi', 'english'],
        employee: ['management', 'hr', 'leadership', 'project_mgmt', 'excel'],
        company: ['management', 'finance', 'marketing', 'hr', 'project_mgmt'],
        entrepreneur: ['entrepreneurship', 'marketing', 'finance', 'excel', 'powerbi'],
      }
      if (roleCategoryMap[role]?.includes(course.category)) {
        score += 20
        reasons.push('role_relevant')
      }

      // 4. GOAL ALIGNMENT
      if (goals.includes('certification')) {
        score += 15
        reasons.push('certification_path')
      }
      if (goals.includes('career_change') && ['economics', 'finance', 'data_analysis', 'ai'].includes(course.category)) {
        score += 10
        reasons.push('career_transition')
      }
      if (goals.includes('skill_upgrade') && course.difficulty === 'INTERMEDIATE') {
        score += 10
        reasons.push('skill_upgrade')
      }

      // 5. POPULARITY (social proof)
      const popularity = course._count.enrollments
      if (popularity > 1000) score += 15
      else if (popularity > 500) score += 10
      else if (popularity > 200) score += 5
      if (popularity > 500) reasons.push('popular')

      // 6. HIGH RATING
      if (course.avgRating >= 4.7) { score += 12; reasons.push('top_rated') }
      else if (course.avgRating >= 4.3) { score += 6 }

      // 7. DIFFICULTY MATCH
      if (profile.difficultyPref === 'adaptive') {
        // Adaptive: recommend based on current level
        if (courseSkill <= 1 && course.difficulty === 'BEGINNER') { score += 10; reasons.push('level_match') }
        else if (courseSkill >= 2 && courseSkill <= 3 && course.difficulty === 'INTERMEDIATE') { score += 10; reasons.push('level_match') }
        else if (courseSkill >= 4 && course.difficulty === 'ADVANCED') { score += 10; reasons.push('level_match') }
      } else if (profile.difficultyPref === course.difficulty.toLowerCase()) {
        score += 10
        reasons.push('level_match')
      }

      // 8. FREE COURSES (lower barrier)
      if (course.price.toNumber() === 0) score += 5

      if (score > 0) {
        scored.push({ course, score, reasons })
      }
    }

    // Sort by score and take top 20
    scored.sort((a, b) => b.score - a.score)
    const topRecommendations = scored.slice(0, 20)

    // Save recommendations to DB
    // Clear old pending recommendations
    await db.personalizedRecommendation.deleteMany({
      where: { profileId: profile.id, status: 'PENDING' },
    })

    // Create new recommendations
    const recData = topRecommendations.map((r, i) => ({
      profileId: profile.id,
      courseId: r.course.id,
      reason: r.reasons[0] || 'general',
      priority: topRecommendations.length - i,
    }))

    if (recData.length > 0) {
      await db.personalizedRecommendation.createMany({ data: recData })
    }

    // Update skill levels in profile
    await db.userLearningProfile.update({
      where: { userId: user.id },
      data: {
        skillLevels: JSON.stringify(skillLevels),
        testResults: JSON.stringify(categoryScores),
      },
    })

    // Get fresh recommendations from DB
    const recommendations = await db.personalizedRecommendation.findMany({
      where: { profileId: profile.id },
      include: { course: true },
      orderBy: { priority: 'desc' },
      take: 20,
    })

    // Generate milestones
    const milestones = generateMilestones(enrollments.length, completedCourseIds.length, quizAttempts.length, { streak: 0 })

    return NextResponse.json({
      profile: {
        ...profile,
        skillLevels: JSON.parse((profile.skillLevels as unknown as string) || '{}'),
        interests: JSON.parse((profile.interests as unknown as string) || '[]'),
        goals: JSON.parse((profile.goals as unknown as string) || '[]'),
      },
      recommendations,
      skillLevels,
      milestones,
      stats: {
        enrolled: enrollments.length,
        completed: completedCourseIds.length,
        quizzesTaken: quizAttempts.length,
        avgQuizScore: quizAttempts.length > 0
          ? Math.round(quizAttempts.reduce((a, at) => a + (at.score / at.totalQuestions) * 100, 0) / quizAttempts.length)
          : 0,
      },
    })
  } catch (error) {
    console.error('Personalized path error:', error)
    return NextResponse.json({ success: false, error: 'Failed to generate path', code: statusToCode(500) }, { status: 500 })
  }
}

function generateMilestones(
  enrolled: number,
  completed: number,
  quizzesTaken: number,
  profile: { streak?: number }
) {
  const milestones: Array<{
    type: string
    title: string
    points: number
    achieved: boolean
    target?: number
    current?: number
  }> = []

  // Course milestones
  if (enrolled >= 1) milestones.push({ type: 'first_enrollment', title: 'أول تسجيل', points: 50, achieved: true })
  else milestones.push({ type: 'first_enrollment', title: 'أول تسجيل', points: 50, achieved: false, target: 1, current: enrolled })

  if (completed >= 1) milestones.push({ type: 'first_completion', title: 'أول إتمام', points: 100, achieved: true })
  else milestones.push({ type: 'first_completion', title: 'أول إتمام', points: 100, achieved: false, target: 1, current: completed })

  if (completed >= 5) milestones.push({ type: 'five_courses', title: 'خريج ميدان', points: 500, achieved: true })
  else milestones.push({ type: 'five_courses', title: 'خريج ميدان', points: 500, achieved: false, target: 5, current: completed })

  if (completed >= 10) milestones.push({ type: 'ten_courses', title: 'خبير ميدان', points: 1000, achieved: true })
  else milestones.push({ type: 'ten_courses', title: 'خبير ميدان', points: 1000, achieved: false, target: 10, current: completed })

  // Quiz milestones
  if (quizzesTaken >= 1) milestones.push({ type: 'first_quiz', title: 'أول اختبار', points: 25, achieved: true })
  if (quizzesTaken >= 10) milestones.push({ type: 'quiz_master', title: 'سيد الاختبارات', points: 300, achieved: true })

  // Streak milestones
  const streak = profile.streak ?? 0
  if (streak >= 7) milestones.push({ type: 'streak_7', title: 'أسبوع متواصل', points: 200, achieved: true })
  if (streak >= 30) milestones.push({ type: 'streak_30', title: 'شهر متواصل', points: 1000, achieved: true })

  return milestones
}
