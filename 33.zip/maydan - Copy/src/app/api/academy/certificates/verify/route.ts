import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const certId = searchParams.get('id')
    if (!certId) {
      return NextResponse.json({ valid: false })
    }

    const certificate = await db.certificate.findUnique({
      where: { certificateId: certId },
      include: {
        user: { select: { name: true } },
      },
    })

    if (!certificate) {
      return NextResponse.json({ valid: false })
    }

    return NextResponse.json({
      valid: true,
      certificate: {
        certificateId: certificate.certificateId,
        title: certificate.title,
        studentName: certificate.user.name || 'غير محدد',
        courseName: certificate.title,
        issuedAt: certificate.issuedAt.toLocaleDateString('ar-IQ'),
        score: certificate.score,
      },
    })
  } catch (error) {
    console.error('Certificate verify error:', error)
    return NextResponse.json({ valid: false }, { status: 500 })
  }
}
