import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { handleApiError } from '@/lib/session'
import { statusToCode } from '@/lib/api-utils'

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const certificate = await db.certificate.findUnique({
      where: { certificateId: id },
      include: {
        user: { select: { id: true, name: true, avatar: true } },
      },
    })

    if (!certificate) {
      return NextResponse.json({ success: false, error: 'الشهادة غير موجودة', code: statusToCode(404) }, { status: 404 })
    }

    return NextResponse.json({ certificate })
  } catch (error) {
    return handleApiError(error)
  }
}
