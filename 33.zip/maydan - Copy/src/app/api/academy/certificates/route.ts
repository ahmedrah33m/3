import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'
import { linkCertificateToPassports } from '@/services/learning-passport.service'

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const certificates = await db.certificate.findMany({
      where: { userId: user.id },
      orderBy: { issuedAt: 'desc' },
    })

    return NextResponse.json({ certificates })
  } catch (error) {
    console.error('Certificates error:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch certificates', code: statusToCode(500) }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const { courseId, score } = await request.json()
    if (!courseId) {
      return NextResponse.json({ success: false, error: 'Course ID required', code: statusToCode(400) }, { status: 400 })
    }

    const enrollment = await db.enrollment.findUnique({
      where: { userId_courseId: { userId: user.id, courseId } },
    })
    if (!enrollment || enrollment.progress < 100) {
      return NextResponse.json({ success: false, error: 'Course not completed', code: statusToCode(400) }, { status: 400 })
    }

    const existing = await db.certificate.findFirst({
      where: { userId: user.id, pathId: courseId },
    })
    if (existing) {
      return NextResponse.json({ certificate: existing })
    }

    const course = await db.learningPath.findUnique({
      where: { id: courseId },
      select: { title: true },
    })
    if (!course) {
      return NextResponse.json({ success: false, error: 'Course not found', code: statusToCode(404) }, { status: 404 })
    }

    const certificateId = `CERT-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`
    const certificate = await db.certificate.create({
      data: {
        userId: user.id,
        pathId: courseId,
        title: course.title,
        description: `شهادة إتمام دورة ${course.title}`,
        type: 'COURSE',
        score: score || null,
        certificateId,
      },
    })

    // Link completion to the Skill Passport + Professional Passport (learning pipeline terminus).
    const courseSkills = await db.learningPath
      .findUnique({ where: { id: courseId }, select: { skills: true } })
      .catch(() => null)
    await linkCertificateToPassports(user.id, courseSkills?.skills || [], {
      source: 'COURSE',
      title: course.title,
      certificateId,
    })

    return NextResponse.json({ success: true, certificate })
  } catch (error) {
    console.error('Generate certificate error:', error)
    return NextResponse.json({ success: false, error: 'Failed to generate certificate', code: statusToCode(500) }, { status: 500 })
  }
}
