import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - List quizzes with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const search = searchParams.get('search')
    const difficulty = searchParams.get('difficulty')
    const limit = parseInt(searchParams.get('limit') || '20')

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const where: any = {}

    if (category) where.category = category
    if (difficulty) where.difficulty = difficulty
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const quizzes = await db.quiz.findMany({
      where,
      take: limit,
      orderBy: { attemptsCount: 'desc' },
      include: {
        _count: { select: { questions: true, attempts: true } },
      },
    })

    return NextResponse.json({ quizzes })
  } catch (error) {
    console.error('Quiz list error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}

// POST - Create a new quiz (instructor only)
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const profile = await db.instructorProfile.findUnique({
      where: { userId: user.id },
    })
    if (!profile?.isApproved) {
      return NextResponse.json({ success: false, error: 'Not an instructor', code: statusToCode(403) }, { status: 403 })
    }

    const body = await request.json()
    const { title, description, category, difficulty, timeLimit, questions } = body

    if (!title || !questions || !Array.isArray(questions) || questions.length === 0) {
      return NextResponse.json({ success: false, error: 'Title and questions required', code: statusToCode(400) }, { status: 400 })
    }

    const quiz = await db.quiz.create({
      data: {
        title,
        description: description || '',
        category: category || 'general',
        difficulty: difficulty || 'BEGINNER',
        timeLimit: timeLimit || 0,
        questionsCount: questions.length,
        questions: {
          create: questions.map((q: { question: string; correctAnswer: number; explanation?: string; options: string[] }, i: number) => ({
            question: q.question,
            correctAnswer: q.correctAnswer,
            explanation: q.explanation || null,
            order: i,
            optionRecords: {
              create: q.options.map((opt: string, j: number) => ({
                text: opt,
                optionIndex: j,
                isCorrect: j === q.correctAnswer,
              })),
            },
          })),
        },
      },
    })

    return NextResponse.json({ success: true, quiz })
  } catch (error) {
    console.error('Create quiz error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
