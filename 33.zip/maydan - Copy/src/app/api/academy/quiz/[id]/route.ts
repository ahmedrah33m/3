import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - Get quiz questions for taking (without correct answers)
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const quiz = await db.quiz.findUnique({
      where: { id },
      include: {
        questions: {
          orderBy: { order: 'asc' },
          include: {
            optionRecords: {
              orderBy: { optionIndex: 'asc' },
              select: { id: true, text: true, optionIndex: true },
            },
          },
        },
      },
    })

    if (!quiz) {
      return NextResponse.json({ success: false, error: 'Quiz not found', code: statusToCode(404) }, { status: 404 })
    }

    // Check user's previous attempts
    const user = await getCurrentUser()
    let userAttempts = 0
    let bestScore = 0
    if (user) {
      const attempts = await db.quizAttempt.findMany({
        where: { quizId: id, userId: user.id },
        select: { score: true, totalQuestions: true },
      })
      userAttempts = attempts.length
      bestScore = attempts.length > 0
        ? Math.max(...attempts.map(a => Math.round((a.score / a.totalQuestions) * 100)))
        : 0
    }

    return NextResponse.json({
      quiz: {
        id: quiz.id,
        title: quiz.title,
        description: quiz.description,
        category: quiz.category,
        difficulty: quiz.difficulty,
        timeLimit: quiz.timeLimit,
        questionsCount: quiz.questionsCount,
      },
      questions: quiz.questions.map(q => ({
        id: q.id,
        question: q.question,
        order: q.order,
        options: q.optionRecords.map(o => ({
          id: o.id,
          text: o.text,
          optionIndex: o.optionIndex,
        })),
      })),
      userAttempts,
      bestScore,
    })
  } catch (error) {
    console.error('Quiz GET error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
