import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'
import { linkCertificateToPassports } from '@/services/learning-passport.service'

// POST - Submit quiz answers
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const body = await request.json()
    const { answers, timeTaken } = body
    // answers: { questionId: selectedOptionIndex }[]

    if (!answers || !Array.isArray(answers)) {
      return NextResponse.json({ success: false, error: 'Answers required', code: statusToCode(400) }, { status: 400 })
    }

    // Get questions with correct answers
    const questions = await db.quizQuestion.findMany({
      where: { quizId: id },
      include: { optionRecords: true },
    })

    if (questions.length === 0) {
      return NextResponse.json({ success: false, error: 'Quiz not found', code: statusToCode(404) }, { status: 404 })
    }

    // Grade answers
    let score = 0
    const answerRecords: any[] = []
    for (const q of questions) {
      const userAnswer = answers.find((a: { questionId: string }) => a.questionId === q.id)
      const selectedOption = userAnswer?.questionId ? userAnswer.questionId : -1
      // Check if userAnswer has the selected option
      const selected = userAnswer ? (userAnswer as Record<string, unknown>).selectedOption as number : -1
      const isCorrect = selected === q.correctAnswer
      if (isCorrect) score++

      answerRecords.push({
        questionId: q.id,
        selectedOption: selected,
        isCorrect,
      })
    }

    const totalQuestions = questions.length
    const scorePercent = Math.round((score / totalQuestions) * 100)

    // Save attempt
    const attempt = await db.quizAttempt.create({
      data: {
        quizId: id,
        userId: user.id,
        score,
        totalQuestions,
        answerRecords: {
          create: answerRecords,
        },
      },
    })

    // Update quiz stats
    await db.quiz.update({
      where: { id },
      data: { attemptsCount: { increment: 1 } },
    })

    // Check if should generate certificate (score >= 70%)
    let certificate: Awaited<ReturnType<typeof db.certificate.create>> | null = null
    if (scorePercent >= 70) {
      const quiz = await db.quiz.findUnique({ where: { id }, select: { title: true } })
      const certId = `CERT-QZ-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`
      certificate = await db.certificate.create({
        data: {
          userId: user.id,
          quizId: id,
          title: `شهادة اختبار: ${quiz?.title || ''}`,
          description: `تم الاجتياز بدرجة ${scorePercent}%`,
          type: 'QUIZ',
          score: scorePercent,
          certificateId: certId,
        },
      })

      // Link quiz pass to the Skill Passport + Professional Passport.
      await linkCertificateToPassports(user.id, [quiz?.title || 'مهارة'], {
        source: 'QUIZ',
        title: quiz?.title || 'اختبار مهارة',
        certificateId: certId,
      })
    }

    return NextResponse.json({
      success: true,
      result: {
        score,
        totalQuestions,
        scorePercent,
        passed: scorePercent >= 70,
        timeTaken: timeTaken || 0,
        attemptId: attempt.id,
      },
      certificate,
    })
  } catch (error) {
    console.error('Quiz submit error:', error)
    return NextResponse.json({ success: false, error: 'Failed', code: statusToCode(500) }, { status: 500 })
  }
}
