import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'

// GET - Get or create user learning profile
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    let profile = await db.userLearningProfile.findUnique({
      where: { userId: user.id },
      include: {
        recommendations: {
          include: { course: true },
          orderBy: { priority: 'desc' },
          take: 20,
        },
        milestones: { orderBy: { achievedAt: 'desc' } },
        skillAssessments: { orderBy: { assessedAt: 'desc' } },
      },
    })

    if (!profile) {
      profile = await db.userLearningProfile.create({
        data: { userId: user.id },
        include: {
          recommendations: { include: { course: true } },
          milestones: true,
          skillAssessments: true,
        },
      })
    }

    // Get enrollment stats
    const enrollments = await db.enrollment.findMany({
      where: { userId: user.id },
      include: { course: { select: { category: true, avgRating: true, difficulty: true } } },
    })

    const completedCourses = enrollments.filter(e => e.progress >= 100).length
    const inProgressCourses = enrollments.filter(e => e.progress > 0 && e.progress < 100).length
    const totalHoursLearned = enrollments.reduce((acc, e) => acc + (e.progress / 100) * 10, 0) // rough estimate

    // Get quiz stats
    const quizAttempts = await db.quizAttempt.findMany({
      where: { userId: user.id },
      select: { score: true, totalQuestions: true },
    })
    const avgQuizScore = quizAttempts.length > 0
      ? quizAttempts.reduce((acc, a) => acc + (a.score / a.totalQuestions) * 100, 0) / quizAttempts.length
      : 0

    // Get certificates
    const certificateCount = await db.certificate.count({
      where: { userId: user.id },
    })

    return NextResponse.json({
      profile,
      stats: {
        enrolledCourses: enrollments.length,
        completedCourses,
        inProgressCourses,
        totalHoursLearned: Math.round(totalHoursLearned),
        avgQuizScore: Math.round(avgQuizScore),
        certificateCount,
        totalPoints: profile.recommendations.filter(r => r.status === 'COMPLETED').length * 100,
      },
    })
  } catch (error) {
    console.error('Profile error:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch profile', code: statusToCode(500) }, { status: 500 })
  }
}

// POST - Update profile (role, goals, interests, weekly goal)
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const body = await request.json()
    const { role, goals, interests, weeklyGoal, preferredLang, difficultyPref } = body

    const profile = await db.userLearningProfile.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        role: role || 'student',
        goals: goals ? JSON.stringify(goals) : undefined,
        interests: interests ? JSON.stringify(interests) : undefined,
        weeklyGoal: weeklyGoal || 5,
        preferredLang: preferredLang || 'ar',
        difficultyPref: difficultyPref || 'adaptive',
      },
      update: {
        ...(role && { role }),
        ...(goals && { goals: JSON.stringify(goals) }),
        ...(interests && { interests: JSON.stringify(interests) }),
        ...(weeklyGoal && { weeklyGoal }),
        ...(preferredLang && { preferredLang }),
        ...(difficultyPref && { difficultyPref }),
      },
    })

    return NextResponse.json({ success: true, profile })
  } catch (error) {
    console.error('Update profile error:', error)
    return NextResponse.json({ success: false, error: 'Failed to update profile', code: statusToCode(500) }, { status: 500 })
  }
}
