import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/session'
import { db } from '@/lib/db'
import { statusToCode } from '@/lib/api-utils'
// WALLET-001 FIX: Direct wallet modification is forbidden — all wallet mutations
// must go through `payFromWallet()` so that an immutable `WalletTransaction`
// ledger entry is created atomically alongside the balance update.
import { payFromWallet } from '@/lib/wallet-service'
import { logAudit } from '@/lib/audit'

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
    }

    const { courseId } = await request.json()
    if (!courseId) {
      return NextResponse.json({ success: false, error: 'Course ID required', code: statusToCode(400) }, { status: 400 })
    }

    // Check if already enrolled
    const existing = await db.enrollment.findUnique({
      where: { userId_courseId: { userId: user.id, courseId } },
    })
    if (existing) {
      return NextResponse.json({ success: false, error: 'Already enrolled', code: statusToCode(409) }, { status: 409 })
    }

    // Check course exists and is published
    const course = await db.learningPath.findUnique({
      where: { id: courseId },
      select: { id: true, isPublished: true, price: true },
    })
    if (!course || !course.isPublished) {
      return NextResponse.json({ success: false, error: 'Course not found', code: statusToCode(404) }, { status: 404 })
    }

    // If paid, debit wallet through the unified wallet service (creates WalletTransaction atomically).
    if (course.price.toNumber() > 0) {
      const result = await payFromWallet({
        userId: user.id,
        amount: course.price.toNumber(),
        serviceType: 'COURSE',
        serviceId: courseId,
        description: `Enrollment in course ${courseId}`,
      })

      if (!result.success) {
        const status = result.error === 'الرصيد غير كافي' ? 402 : 400
        return NextResponse.json({ success: false, error: result.error || 'Payment failed', code: statusToCode(status) }, { status })
      }

      await db.courseOrder.create({
        data: { userId: user.id, courseId, amount: course.price },
      })

      // AUDIT FIX: log the money movement.
      try {
        await logAudit(user.id, 'WALLET_DEBIT' as any, 'WalletTransaction' as any, result.walletTxId, {
          amount: course.price.toNumber(),
          serviceType: 'COURSE',
          serviceId: courseId,
        })
      } catch {
        // Audit log is best-effort — must not block enrollment.
      }
    }

    const enrollment = await db.enrollment.create({
      data: { userId: user.id, courseId },
    })

    await db.learningPath.update({
      where: { id: courseId },
      data: { enrolledCount: { increment: 1 } },
    })

    return NextResponse.json({ success: true, enrollment })
  } catch (error) {
    console.error('Enroll error:', error)
    return NextResponse.json({ success: false, error: 'Failed to enroll', code: statusToCode(500) }, { status: 500 })
  }
}
