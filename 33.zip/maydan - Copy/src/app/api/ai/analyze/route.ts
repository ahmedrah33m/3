import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, hasRole, AuthError, handleApiError } from '@/lib/session';
import {
  generateAISummary,
  generateSummary,
  analyzeAISentiment,
  analyzeSentiment,
  moderateAIContent,
  moderateContent,
  getAIInstance,
} from '@/lib/ai-utils';
import { logAIAction, logSystemError } from '@/lib/logger';
import { db } from '@/lib/db';
import { statusToCode } from '@/lib/api-utils'

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Require authentication with OWNER/ADMIN role
    const user = await requireAuth();

    if (!hasRole(user, ['OWNER', 'ADMIN'])) {
      return NextResponse.json({ success: false, error: 'غير مصرح. يتطلب صلاحيات مالك أو مسؤول', code: statusToCode(403) }, { status: 403 });
    }

    // Parse request body
    let body: { articleId?: string; content?: string };
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ success: false, error: 'طلب غير صالح', code: statusToCode(400) }, { status: 400 });
    }

    const { articleId, content } = body;

    // Must provide either articleId or content
    if (!articleId && (!content || typeof content !== 'string' || content.trim().length === 0)) {
      return NextResponse.json({ success: false, error: 'يجب توفير معرف المقالة أو المحتوى', code: statusToCode(400) }, { status: 400 });
    }

    let analysisText = content || '';
    let article: {
      id: string;
      title: string;
      content: string | null;
      aiSummary: string | null;
      sentiment: string | null;
      aiScore: number | null;
    } | null = null;

    // If articleId provided, fetch from database
    if (articleId) {
      try {
        article = await db.article.findUnique({
          where: { id: articleId },
          select: {
            id: true,
            title: true,
            content: true,
            aiSummary: true,
            sentiment: true,
            aiScore: true,
          },
        });

        if (!article) {
          return NextResponse.json({ success: false, error: 'المقالة غير موجودة', code: statusToCode(404) }, { status: 404 });
        }

        // Use article title + content for analysis
        analysisText = [article.title, article.content || '']
          .filter(Boolean)
          .join('\n\n');

        if (analysisText.trim().length === 0) {
          return NextResponse.json({ success: false, error: 'المقالة لا تحتوي على محتوى كافٍ للتحليل', code: statusToCode(400) }, { status: 400 });
        }
      } catch (dbError) {
        await logSystemError({
          type: 'db_error',
          severity: 'medium',
          message: `Failed to fetch article for analysis: ${dbError instanceof Error ? dbError.message : 'Unknown'}`,
          url: '/api/ai/analyze',
          method: 'POST',
        });
        return NextResponse.json({ success: false, error: 'خطأ في الوصول إلى قاعدة البيانات', code: statusToCode(400) }, { status: 400 });
      }
    }

    // Ensure analysisText is valid
    if (!analysisText || typeof analysisText !== 'string') {
      analysisText = '';
    }

    // Run all AI analyses in parallel, each with its own fallback
    const [summaryResult, sentimentResult, moderationResult, qualityResult] = await Promise.all([
      // Summary
      (async () => {
        try {
          const s = await generateAISummary(analysisText, user.id);
          return { summary: s || '', source: 'ai' as const };
        } catch {
          return { summary: generateSummary(analysisText), source: 'fallback' as const };
        }
      })(),

      // Sentiment
      (async () => {
        try {
          const s = await analyzeAISentiment(analysisText, user.id);
          return { ...s, source: 'ai' as const };
        } catch {
          return { ...analyzeSentiment(analysisText), source: 'fallback' as const };
        }
      })(),

      // Moderation
      (async () => {
        try {
          const m = await moderateAIContent(analysisText, user.id);
          return { ...m, source: 'ai' as const };
        } catch {
          return { ...moderateContent(analysisText), source: 'fallback' as const };
        }
      })(),

      // Quality score
      generateQualityScore(analysisText, user.id).catch(() => ({
        score: 50,
        source: 'fallback' as const,
      })),
    ]);

    // Determine overall source
    const sources = [
      summaryResult.source,
      sentimentResult.source,
      moderationResult.source,
      qualityResult.source,
    ];
    const overallSource = sources.every((s) => s === 'ai')
      ? 'ai'
      : sources.some((s) => s === 'ai')
        ? 'partial'
        : 'fallback';

    // Save all results to article if it was fetched by ID
    if (article) {
      try {
        await db.article.update({
          where: { id: article.id },
          data: {
            aiSummary: summaryResult.summary,
            sentiment: sentimentResult.sentiment,
            aiScore: qualityResult.score,
            isFlagged: !moderationResult.safe,
            flagReason:
              moderationResult.flags.length > 0
                ? moderationResult.flags.join(', ')
                : null,
          },
        });
      } catch (updateError) {
        console.error('Failed to save analysis results to article:', updateError);
      }
    }

    const duration = Date.now() - startTime;

    await logAIAction({
      operation: 'analysis',
      model: overallSource === 'ai' ? 'z-ai' : 'fallback',
      durationMs: duration,
      success: true,
      userId: user.id,
      metadata: {
        articleId: articleId || null,
        contentLength: analysisText.length,
        overallSource,
        summarySource: summaryResult.source,
        sentimentSource: sentimentResult.source,
        moderationSource: moderationResult.source,
        qualitySource: qualityResult.source,
      },
    });

    return NextResponse.json({
      summary: summaryResult.summary,
      sentiment: {
        sentiment: sentimentResult.sentiment,
        score: sentimentResult.score,
      },
      moderation: {
        safe: moderationResult.safe,
        flags: moderationResult.flags,
        score: moderationResult.score,
      },
      qualityScore: qualityResult.score,
      source: overallSource,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return handleApiError(error);
    }

    const duration = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'خطأ غير معروف';

    await logSystemError({
      type: 'ai_error',
      severity: 'high',
      message: `Analyze API error: ${errorMessage}`,
      method: 'POST',
      url: '/api/ai/analyze',
    });

    await logAIAction({
      operation: 'analysis',
      model: 'fallback',
      durationMs: duration,
      success: false,
      errorMessage,
    });

    // Never return 500
    return NextResponse.json({
      summary: 'لم يتم إجراء التحليل. يرجى المحاولة لاحقاً.',
      sentiment: { sentiment: 'neutral', score: 0 },
      moderation: { safe: true, flags: [], score: 0.5 },
      qualityScore: 0,
      source: 'fallback' as const,
    });
  }
}

/**
 * Generate a quality score (0-100) using AI
 */
async function generateQualityScore(
  content: string,
  userId?: string
): Promise<{ score: number; source: 'ai' | 'fallback' }> {
  const ai = await getAIInstance();

  if (ai) {
    try {
      const response = await ai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content:
              'أنت مقيم محتوى لمنصة ميدان الاقتصاد. قيّم جودة المحتوى الاقتصادي من 0 إلى 100 بناءً على: الدقة والشفافية، عمق التحليل، المصادر الموثوقة، الوضوح والتنظيم. أجب بصيغة JSON فقط: {"score": number, "reasons": ["reason1", ...]}',
          },
          {
            role: 'user',
            content: `قيّم جودة المحتوى الاقتصادي التالي:\n\n${content.slice(0, 3000)}`,
          },
        ],
      });

      const result = response?.choices?.[0]?.message?.content;
      if (result && typeof result === 'string') {
        try {
          const jsonMatch = result.match(/\{[\s\S]*?\}/);
          if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            const score =
              typeof parsed.score === 'number'
                ? Math.min(100, Math.max(0, Math.round(parsed.score)))
                : null;
            if (score !== null) {
              return { score, source: 'ai' };
            }
          }
        } catch {
          // JSON parsing failed, fall through
        }
      }
    } catch (error) {
      console.error('AI quality scoring failed:', error);
    }
  }

  // Fallback: heuristic quality score
  return heuristicQualityScore(content);
}

/**
 * Heuristic-based quality score fallback
 */
function heuristicQualityScore(content: string): { score: number; source: 'fallback' } {
  let score = 40;

  const wordCount = content.split(/\s+/).length;
  if (wordCount > 500) score += 20;
  else if (wordCount > 200) score += 15;
  else if (wordCount > 100) score += 10;
  else if (wordCount > 50) score += 5;

  if (content.includes('\n\n')) score += 5;
  if (/\d+/.test(content)) score += 5;
  if (content.includes('%') || content.includes('نسبة')) score += 5;

  const economicKeywords = [
    'اقتصاد', 'استثمار', 'سوق', 'نمو', 'تضخم', 'ناتج محلي',
    'ميزانية', 'دينار', 'نفط', 'صادرات', 'واردات', 'بورصة',
    'GDP', 'inflation', 'market', 'investment',
  ];
  const lowerContent = content.toLowerCase();
  const keywordMatches = economicKeywords.filter((kw) =>
    lowerContent.includes(kw.toLowerCase())
  ).length;
  score += Math.min(15, keywordMatches * 3);

  if (content.includes('#') || content.includes('**')) score += 5;
  if (content.includes('•') || content.includes('-') || content.includes('*'))
    score += 5;

  return { score: Math.min(100, score), source: 'fallback' };
}
