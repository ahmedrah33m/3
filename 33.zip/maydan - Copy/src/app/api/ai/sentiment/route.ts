import { NextRequest, NextResponse } from 'next/server';
// SEC-7 FIX: Was `optionalAuth` — anonymous users could abuse AI compute.
// Now requires authentication.
import { requireAuth, AuthError, handleApiError } from '@/lib/session';
import type { SessionUser } from '@/lib/session';
import { analyzeAISentiment, analyzeSentiment } from '@/lib/ai-utils';
import { logAIAction, logSystemError } from '@/lib/logger';
import { db } from '@/lib/db';
import { getAIResponseWithCache, generateAIHash, getTTLForOperation } from '@/lib/ai-cache';
import { statusToCode } from '@/lib/api-utils'

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // SEC-7 FIX: Require authentication (was optionalAuth — anonymous users could abuse AI compute).
    const user: SessionUser = await requireAuth();

    // Parse request body
    let body: { articleId?: string; text?: string };
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ success: false, error: 'طلب غير صالح', code: statusToCode(400) }, { status: 400 });
    }

    const { articleId, text } = body;

    // Must provide either articleId or text
    if (!articleId && (!text || typeof text !== 'string' || text.trim().length === 0)) {
      return NextResponse.json({ success: false, error: 'يجب توفير معرف المقالة أو النص', code: statusToCode(400) }, { status: 400 });
    }

    let analysisText = text || '';
    let article: {
      id: string;
      title: string;
      content: string | null;
      sentiment: string | null;
    } | null = null;

    // If articleId provided, fetch from database
    if (articleId) {
      try {
        article = await db.article.findUnique({
          where: { id: articleId },
          select: {
            id: true,
            title: true,
            content: true,
            sentiment: true,
          },
        });

        if (!article) {
          return NextResponse.json({ success: false, error: 'المقالة غير موجودة', code: statusToCode(404) }, { status: 404 });
        }

        // Use article title + content for sentiment analysis
        analysisText = [article.title, article.content || '']
          .filter(Boolean)
          .join('\n\n');

        if (analysisText.trim().length === 0) {
          return NextResponse.json({ success: false, error: 'المقالة لا تحتوي على محتوى كافٍ لتحليل المشاعر', code: statusToCode(400) }, { status: 400 });
        }

        // Return existing sentiment if available
        if (article.sentiment) {
          await logAIAction({
            operation: 'sentiment',
            model: 'cached',
            durationMs: Date.now() - startTime,
            success: true,
            userId: user?.id,
            metadata: { articleId, cached: true },
          });

          return NextResponse.json({
            sentiment: article.sentiment,
            score: 0.5,
            source: 'cached' as const,
          });
        }
      } catch (dbError) {
        await logSystemError({
          type: 'db_error',
          severity: 'medium',
          message: `Failed to fetch article for sentiment: ${dbError instanceof Error ? dbError.message : 'Unknown'}`,
          url: '/api/ai/sentiment',
          method: 'POST',
        });
        return NextResponse.json({ success: false, error: 'خطأ في الوصول إلى قاعدة البيانات', code: statusToCode(400) }, { status: 400 });
      }
    }

    // Ensure analysisText is a valid string
    if (!analysisText || typeof analysisText !== 'string') {
      analysisText = '';
    }

    // Analyze sentiment using AI with fallback — مع كاش AI
    let sentimentResult: { sentiment: string; score: number };
    let source: 'ai' | 'fallback' | 'cached';

    // ── كاش AI — تحليل المشاعر قابل للتخزين (نفس النص = نفس النتيجة) ──
    const cacheKey = `sentiment:${generateAIHash(analysisText, { op: 'sentiment' })}`
    const ttl = getTTLForOperation('sentiment') // 5 دقائق
    const cachedResult = await getAIResponseWithCache(
      cacheKey,
      async () => {
        try {
          const result = await analyzeAISentiment(analysisText, user?.id);
          return JSON.stringify(result);
        } catch (aiError) {
          console.error('AI sentiment failed, using keyword fallback:', aiError);
          const result = analyzeSentiment(analysisText);
          return JSON.stringify({ ...result, _source: 'fallback' });
        }
      },
      ttl
    );

    try {
      const parsed = JSON.parse(cachedResult);
      sentimentResult = { sentiment: parsed.sentiment, score: parsed.score };
      source = parsed._source === 'fallback' ? 'fallback' : 'ai';
    } catch {
      // فشل في الكاش — استخدم التحليل المباشر
      try {
        sentimentResult = await analyzeAISentiment(analysisText, user?.id);
        source = 'ai';
      } catch (aiError) {
        console.error('AI sentiment failed, using keyword fallback:', aiError);
        sentimentResult = analyzeSentiment(analysisText);
        source = 'fallback';
      }
    }

    const duration = Date.now() - startTime;

    // Save sentiment to article if it was fetched by ID
    if (article) {
      try {
        await db.article.update({
          where: { id: article.id },
          data: { sentiment: sentimentResult.sentiment },
        });
      } catch (updateError) {
        console.error('Failed to save sentiment to article:', updateError);
      }
    }

    await logAIAction({
      operation: 'sentiment',
      model: source,
      durationMs: duration,
      success: true,
      userId: user?.id,
      metadata: {
        articleId: articleId || null,
        textLength: analysisText.length,
        sentiment: sentimentResult.sentiment,
        score: sentimentResult.score,
        source,
      },
    });

    return NextResponse.json({
      sentiment: sentimentResult.sentiment,
      score: sentimentResult.score,
      source,
    });
  } catch (error) {
    const duration = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'خطأ غير معروف';

    await logSystemError({
      type: 'ai_error',
      severity: 'medium',
      message: `Sentiment API error: ${errorMessage}`,
      method: 'POST',
      url: '/api/ai/sentiment',
    });

    await logAIAction({
      operation: 'sentiment',
      model: 'fallback',
      durationMs: duration,
      success: false,
      errorMessage,
    });

    // Never return 500 - return neutral fallback
    return NextResponse.json({
      sentiment: 'neutral',
      score: 0,
      source: 'fallback' as const,
    });
  }
}
