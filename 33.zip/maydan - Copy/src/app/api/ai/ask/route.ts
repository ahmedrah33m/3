import { NextRequest } from 'next/server'
import { requireAuth, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { askMidanAI, AI_DOMAINS } from '@/services/ai.service'

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth()
    const { domain, prompt } = await req.json().catch(() => ({}))
    const d = AI_DOMAINS.includes(domain) ? domain : 'GENERAL'
    return successResponse(await askMidanAI(d, prompt || '', user.id))
  } catch (error) {
    return handleApiError(error)
  }
}
