import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, AuthError, handleApiError } from '@/lib/session';
import { getAIInstance, isAIReady } from '@/lib/ai-utils';
import { logAIAction, logSystemError } from '@/lib/logger';
import { statusToCode } from '@/lib/api-utils'

const SYSTEM_PROMPT = `أنت مساعد اقتصادي ذكي متخصص في الاقتصاد العراقي والعربي والعالمي لمنصة "ميدان الاقتصاد". مهمتك تقديم تحليلات اقتصادية دقيقة ومفيدة.

إرشادات الاستجابة:
- أجب باللغة العربية دائماً ما لم يطلب المستخدم لغة أخرى
- قدم تحليلاً اقتصادياً شاملاً ومبنياً على حقائق
- استخدم بيانات وأرقاماً عند الإمكان
- نظّم إجابتك بنقاط واضحة عند الحاجة
- اذكر المصادر أو المراجع المتاحة عند الإمكان
- بيّن التأثيرات المباشرة وغير المباشرة للمسألة المطروحة
- قدّم توصيات عملية عند الحاجة
- إذا كنت غير متأكد من معلومة، وضّح ذلك بصراحة
- اربط الموضوع بالواقع العراقي عند الإمكان
- لا تقدم نصائح استثمارية محددة كشراء أو بيع، بل قدم تحليلاً أولياً للاستئناس
- نبّه دائماً إلى أن التحليل أولي ولا يُغني عن استشارة المتخصصين`;

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Authenticate user
    const user = await requireAuth();

    // Parse request body
    let body: { message?: string; context?: string };
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ success: false, error: 'طلب غير صالح', code: statusToCode(400) }, { status: 400 });
    }

    const { message, context } = body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return NextResponse.json({ success: false, error: 'الرسالة مطلوبة', code: statusToCode(400) }, { status: 400 });
    }

    if (message.length > 5000) {
      return NextResponse.json({ success: false, error: 'الرسالة طويلة جداً. الحد الأقصى 5000 حرف', code: statusToCode(400) }, { status: 400 });
    }

    // Try AI chat completion
    const aiReady = await isAIReady();
    if (aiReady) {
      try {
        const ai = await getAIInstance();
        if (ai) {
          const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
            {
              role: 'system',
              content: SYSTEM_PROMPT,
            },
          ];

          // Add context if provided (conversation history)
          if (context && typeof context === 'string' && context.trim().length > 0) {
            // Parse context as previous conversation turns
            const contextLines = context.split('\n').filter(Boolean);
            for (const line of contextLines) {
              if (line.startsWith('المستخدم: ')) {
                messages.push({
                  role: 'user',
                  content: line.replace('المستخدم: ', ''),
                });
              } else if (line.startsWith('المساعد: ')) {
                messages.push({
                  role: 'assistant',
                  content: line.replace('المساعد: ', ''),
                });
              }
            }
          }

          messages.push({
            role: 'user',
            content: message,
          });

          const response = await ai.chat.completions.create({
            messages,
          });

          const aiResponse = response?.choices?.[0]?.message?.content;
          if (aiResponse && typeof aiResponse === 'string' && aiResponse.trim().length > 0) {
            const duration = Date.now() - startTime;
            await logAIAction({
              operation: 'chat',
              model: 'z-ai',
              durationMs: duration,
              success: true,
              userId: user.id,
              metadata: { messageLength: message.length, hasContext: !!context },
            });

            return NextResponse.json({
              response: aiResponse.trim(),
              source: 'ai' as const,
            });
          }
        }
      } catch (aiError) {
        const duration = Date.now() - startTime;
        const errorMessage = aiError instanceof Error ? aiError.message : 'Unknown AI error';

        await logAIAction({
          operation: 'chat',
          model: 'z-ai',
          durationMs: duration,
          success: false,
          errorMessage,
          userId: user.id,
        });

        console.error('AI chat failed, using fallback:', aiError);
      }
    }

    // Fallback response
    const fallbackResponse = generateFallbackResponse(message);
    const duration = Date.now() - startTime;

    await logAIAction({
      operation: 'chat',
      model: 'fallback',
      durationMs: duration,
      success: true,
      userId: user.id,
      metadata: { messageLength: message.length, hasContext: !!context, fallbackUsed: true },
    });

    return NextResponse.json({
      response: fallbackResponse,
      source: 'fallback' as const,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return handleApiError(error);
    }

    const duration = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'خطأ غير معروف';

    await logSystemError({
      type: 'ai_error',
      severity: 'medium',
      message: `Chat API error: ${errorMessage}`,
      method: 'POST',
      url: '/api/ai/chat',
    });

    // Never return 500 - return a helpful fallback
    return NextResponse.json({
      response:
        'عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً. يمكنك أيضاً تصفح المقالات الاقتصادية المتاحة في المنصة.',
      source: 'fallback' as const,
    });
  }
}

/**
 * Generate a helpful static fallback response based on the user's message
 */
function generateFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase();

  // Oil & Energy
  if (
    lowerMessage.includes('نفط') ||
    lowerMessage.includes('بترول') ||
    lowerMessage.includes('طاقة') ||
    lowerMessage.includes('oil') ||
    lowerMessage.includes('energy') ||
    lowerMessage.includes('50 دولار') ||
    lowerMessage.includes('سعر النفط')
  ) {
    return `**تأثير أسعار النفط على الاقتصاد العراقي**

يعتمد الاقتصاد العراقي بشكل كبير على إيرادات النفط، حيث تشكل نحو 90% من الإيرادات الحكومية و40% من الناتج المحلي الإجمالي.

**في حال انخفاض النفط إلى 50 دولاراً:**

• **العجز المالي**: سينخفض الإيراد الفعلي للموازنة بشكل كبير مقارنة بالتقديرات المبنية على أسعار أعلى، مما يزيد العجز المالي
• **قيمة الدينار**: قد يتعرض الدينار العراقي لضغوط انخفاض نتيجة تراجع الاحتياطيات الأجنبية
• **المشاريع**: تراجع الإنفاق الاستثماري وتأجيل المشاريع التنموية
• **القطاع الخاص**: قد تنخفض القدرة الشرائية مما يؤثر على الأنشطة التجارية
• **فرص تنويع**: يشكل هذا تحفيزاً لتسريع خطط التنويع الاقتصادي

**توصيات:**
- متابعة البيانات الرسمية من البنك المركزي العراقي
- الاطلاع على تحليلات الخبراء في منصة ميدان
- دراسة فرص الاستثمار في قطاعات غير نفطية

*ملاحظة: هذا تحليل أولي للاستئناس ولا يُغني عن استشارة المتخصصين*`;
  }

  // Currency & Exchange
  if (
    lowerMessage.includes('دينار') ||
    lowerMessage.includes('عملة') ||
    lowerMessage.includes('صرف') ||
    lowerMessage.includes('دولار') ||
    lowerMessage.includes('currency') ||
    lowerMessage.includes('dinar') ||
    lowerMessage.includes('exchange')
  ) {
    return `**سعر صرف الدينار العراقي**

يتأثر سعر صرف الدينار العراقي بعدة عوامل رئيسية:

• **الإيرادات النفطية**: المصدر الرئيسي للعملة الأجنبية، وأي تغير في أسعار النفط ينعكس مباشرة
• **السياسة النقدية**: قرارات البنك المركزي العراقي حول عرض النقد وسعر الصرف المرجعي
• **الاحتياطيات**: حجم الاحتياطيات الأجنبية يحدد قدرة البنك المركزي على دعم الدينار
• **الطلب المحلي**: الطلب على الدولار للاستيراد والسفر والادخار

**التأثير على الاستثمار:**
- استقرار سعر الصرف يشجع الاستثمار الأجنبي
- التذبذب يزيد من مخاطر الاستثمار لكنه يخلق فرصاً للمضاربة
- الفجوة بين السعر الرسمي والسوق الموازي تعكس الضغوط الاقتصادية

*ننصح بمتابعة البيانات الرسمية من البنك المركزي العراقي والاطلاع على تحليلات الخبراء في المنصة*`;
  }

  // Investment
  if (
    lowerMessage.includes('استثمار') ||
    lowerMessage.includes('استثمر') ||
    lowerMessage.includes('investment') ||
    lowerMessage.includes('فرص') ||
    lowerMessage.includes('قطاع')
  ) {
    return `**القطاعات الواعدة للاستثمار في العراق**

يوفر العراق فرصاً استثمارية متنوعة في عدة قطاعات:

• **القطاع العقاري**: طلب متزايد على الإسكان مع نمو السكان
• **الزراعة**: إمكانات كبيرة مع توفر الأراضي الصالحة والمياه
• **التكنولوجيا**: نمو سريع في قطاع التقنية والشركات الناشئة
• **الطاقة المتجددة**: فرص في الطاقة الشمسية خصوصاً في جنوب العراق
• **الصناعة**: معالجة المواد الخام محلياً بدلاً من التصدير
• **السياحة**: إمكانات سياحية دينية وتاريخية وترفيهية

**عوامل يجب مراعاتها:**
- البيئة التنظيمية والإطار القانوني
- البنية التحتية المتاحة
- توفر الكوادر البشرية المؤهلة
- الاستقرار الأمني في المنطقة المستهدفة

*يُنصح بإجراء دراسة جدوى تفصيلية قبل أي قرار استثماري*`;
  }

  // Monetary policy & inflation
  if (
    lowerMessage.includes('تضخم') ||
    lowerMessage.includes('بنك مركزي') ||
    lowerMessage.includes('سياسة نقدية') ||
    lowerMessage.includes('فائدة') ||
    lowerMessage.includes('inflation') ||
    lowerMessage.includes('monetary')
  ) {
    return `**السياسة النقدية والتضخم في العراق**

يلعب البنك المركزي العراقي دوراً محورياً في التحكم بالتضخم عبر عدة أدوات:

• **سعر الفائدة**: رفع الفائدة يقلل من الإقراض والإنفاق ويحد التضخم
• **الاحتياطي الإلزامي**: تغيير نسبة الاحتياطي يؤثر على حجم الإقراض
• **عمليات السوق المفتوحة**: بيع وشراء السندات لتنظيم السيولة
• **سعر الصرف**: استقرار الدينار يحد من التضخم المستورد

**التحديات:**
- التضخم المستورد نتيجة الاعتماد على الاستيراد
- التمويل الحكومي عبر البنك المركزي
- الفجوة بين السعر الرسمي والموازي

*يمكنك الاطلاع على المؤشرات الاقتصادية المحدثة في قسم الاقتصاد بالمنصة*`;
  }

  // Economic diversification
  if (
    lowerMessage.includes('تنويع') ||
    lowerMessage.includes('اقتصاد غير نفطي') ||
    lowerMessage.includes('diversif') ||
    lowerMessage.includes('إصلاح')
  ) {
    return `**تنويع الاقتصاد العراقي بعيداً عن النفط**

التنويع الاقتصادي ضرورة استراتيجية للعراق لعدة أسباب:

• **تقلب أسعار النفط**: الاعتماد على مصدر واحد يجعل الاقتصاد هشاً
• **نمو السكان**: الحاجة لخلق فرص عمل كافية للشباب
• **التنمية المستدامة**: بناء اقتصاد مقاوم للصدمات الخارجية

**محاور التنويع المقترحة:**
1. تطوير القطاع الزراعي وتحقيق الأمن الغذائي
2. تعزيز الصناعة التحويلية وقيمة مضافة محلية
3. الاستثمار في التعليم وبناء رأس المال البشري
4. تطوير قطاع الخدمات المالية والمصرفية
5. تحسين بيئة الأعمال لجذب الاستثمار الأجنبي
6. دعم ريادة الأعمال والشركات الناشئة

*يمكنك الاطلاع على دراسات ومقالات مفصلة حول هذا الموضوع في المنصة*`;
  }

  // Market & Stock
  if (
    lowerMessage.includes('سوق') ||
    lowerMessage.includes('بورصة') ||
    lowerMessage.includes('أسهم') ||
    lowerMessage.includes('market') ||
    lowerMessage.includes('stock')
  ) {
    return `**سوق العراق للأوراق المالية**

يوفر سوق العراق للأوراق المالية فرصاً استثمارية في عدة قطاعات:

• **القطاع المصرفي**: البنوك التجارية والإسلامية المدرجة
• **القطاع الصناعي**: شركات الصناعة الغذائية والكيميائية
• **القطاع الخدمي**: شركات الاتصالات والفنادق
• **القطاع الزراعي**: شركات الزراعة والأغذية

**ملاحظات مهمة:**
- يُنصح بالتعرف على الشركات المدرجة وقراءة تقاريرها المالية
- يجب فهم آليات التداول والرسوم المطبقة
- التنويع في المحفظة الاستثمارية يقلل المخاطر

*هذا تحليل أولي ولا يُعد نصيحة استثمارية*`;
  }

  // Budget
  if (
    lowerMessage.includes('موازنة') ||
    lowerMessage.includes('ميزانية') ||
    lowerMessage.includes('budget') ||
    lowerMessage.includes('إنفاق') ||
    lowerMessage.includes('عجز')
  ) {
    return `**الموازنة العامة العراقية**

تعتمد الموازنة العراقية بشكل أساسي على الإيرادات النفطية:

• **الإيرادات**: النفط يشكل حوالي 90% من الإيرادات العامة
• **النفقات**: الرواتب والتقاعدات تمثل نحو 60% من النفقات الجارية
• **الاستثمار**: يخصص جزء للمشاريع التنموية والبنية التحتية
• **العجز**: يظهر العجز عند انخفاض أسعار النفط عن التقديرات

**تحديات الموازنة:**
- الاعتماد المفرط على النفط
- ارتفاع نسبة النفقات الجارية مقابل الاستثمارية
- صعوبة التنبؤ بالإيرادات بسبب تقلب الأسعار

*يمكنك متابعة المؤشرات الاقتصادية والتحليلات المحدثة في منصة ميدان*`;
  }

  // Default fallback
  return `شكراً لسؤالك. فيما يلي بعض النقاط العامة حول الموضوع:

**يمكنني مساعدتك في:**
• تحليل الأسواق المالية والاقتصادية
• شرح المؤشرات الاقتصادية وتأثيراتها
• مناقشة فرص الاستثمار في العراق
• تحليل السياسات النقدية والمالية
• دراسة تأثير أسعار النفط والعملات

**نصائح عامة:**
- تابع المؤشرات الاقتصادية المحدثة في قسم الاقتصاد
- اقرأ المقالات والتحليلات من الخبراء في المنصة
- شارك في النقاشات الاقتصادية لتبادل الآراء

*حالياً، خدمة المساعد الذكي تعمل في الوضع المبدئي. يمكنك المحاولة مرة أخرى لاحقاً للحصول على تحليل أكثر تفصيلاً*`;
}
