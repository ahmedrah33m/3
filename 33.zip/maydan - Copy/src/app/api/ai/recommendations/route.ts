import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAIInstance, generateSmartRecommendations } from '@/lib/ai-utils'
import { statusToCode } from '@/lib/api-utils'
// SEC-6 FIX: This endpoint previously accepted `userId` from the request body
// without authentication — an IDOR that let any caller read another user's
// liked/bookmarked articles. Now we authenticate and use the session user's ID,
// ignoring any `userId` field in the request body.
import { requireAuth } from '@/lib/session'

export async function POST(req: Request) {
  try {
    // SEC-6 FIX: Require authentication and use the authenticated user's ID.
    const authUser = await requireAuth()

    const body = await req.json()
    // Ignore any `userId` from body — always use the authenticated user's ID.
    const userId = authUser.id
    const { articleId, count = 5 } = body

    // Fetch user's activity history
    const likedArticles = await db.like.findMany({
      where: { userId, type: 'LIKE', articleId: { not: null } },
      select: { articleId: true },
      take: 20,
    })

    const bookmarkedArticles = await db.like.findMany({
      where: { userId, type: 'BOOKMARK', articleId: { not: null } },
      select: { articleId: true },
      take: 20,
    })

    const userActivities = await db.userActivity.findMany({
      where: { userId, action: { in: ['VIEW', 'READ'] }, targetType: 'ARTICLE' },
      select: { targetId: true },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })

    // Gather article IDs the user has interacted with
    const interactedIds = new Set<string>()
    for (const like of likedArticles) if (like.articleId) interactedIds.add(like.articleId)
    for (const bm of bookmarkedArticles) if (bm.articleId) interactedIds.add(bm.articleId)
    for (const act of userActivities) if (act.targetId) interactedIds.add(act.targetId)
    if (articleId) interactedIds.add(articleId)

    // Fetch interacted articles for context
    const interactedArticles = await db.article.findMany({
      where: { id: { in: Array.from(interactedIds) }, status: 'PUBLISHED', deletedAt: null },
      select: {
        id: true,
        title: true,
        category: true,
        tagRelations: { include: { hashtag: { select: { tag: true } } } },
      },
    })

    // Fetch available articles for recommendation pool
    const availableArticles = await db.article.findMany({
      where: {
        status: 'PUBLISHED',
        deletedAt: null,
        id: { notIn: Array.from(interactedIds) },
      },
      select: {
        id: true,
        title: true,
        category: true,
        tagRelations: { include: { hashtag: { select: { tag: true } } } },
      },
      orderBy: { viewCount: 'desc' },
    })

    // Common select for returning full article data
    const articleSelect = {
      id: true,
      title: true,
      summary: true,
      category: true,
      tagRelations: { include: { hashtag: { select: { tag: true } } } },
      viewCount: true,
      likeCount: true,
      createdAt: true,
      mediaRecords: { select: { url: true, type: true } },
      mediaType: true,
      authorId: true,
      author: {
        select: {
          id: true,
          name: true,
          avatar: true,
          jobTitle: true,
          isVerified: true,
        },
      },
    }

    // If user has no history, return trending articles
    if (interactedArticles.length === 0) {
      const trending = await db.article.findMany({
        where: { status: 'PUBLISHED', deletedAt: null },
        select: articleSelect,
        take: count,
        orderBy: { viewCount: 'desc' },
      })

      return NextResponse.json({ recommendations: trending, source: 'trending' })
    }

    // Try AI-powered recommendations first
    const ai = await getAIInstance()
    let recommendedIds: string[] | null = null

    if (ai) {
      try {
        // Build context for AI
        const userInterests = interactedArticles.map((a: any) => ({
          id: a.id,
          title: a.title,
          category: a.category,
          tags: a.tagRelations.map((tr: any) => tr.hashtag.tag),
        }))

        const pool = availableArticles.map((a: any) => ({
          id: a.id,
          title: a.title,
          category: a.category,
          tags: a.tagRelations.map((tr: any) => tr.hashtag.tag),
        }))

        const completion = await ai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content:
                'أنت خبير في توصية المحتوى الاقتصادي. بناءً على اهتمامات المستخدم التالية والمقالات المتاحة، قم باقتراح أفضل المقالات. أعد النتائج كـ JSON array يحتوي على articleIds مرتبة حسب الأفضلية. أرجع فقط JSON array بدون أي نص إضافي.',
            },
            {
              role: 'user',
              content: JSON.stringify({
                userInterests,
                availableArticles: pool,
                count,
              }),
            },
          ],
          temperature: 0.3,
        })

        let aiResult = completion.choices[0]?.message?.content || '[]'

        // Extract JSON from AI response (handle markdown code blocks)
        const jsonMatch = aiResult.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          aiResult = jsonMatch[0]
        }

        try {
          const parsed = JSON.parse(aiResult)
          if (Array.isArray(parsed) && parsed.length > 0) {
            recommendedIds = parsed
          }
        } catch {
          // JSON parse failed, will use fallback
        }
      } catch (aiError) {
        console.error('AI recommendations failed, using content-based fallback:', aiError)
      }
    }

    // Fallback: Content-based recommendations using category/tag matching
    if (!recommendedIds || recommendedIds.length === 0) {
      const scores = generateSmartRecommendations(
        interactedArticles.map((a: any) => ({
          id: a.id,
          category: a.category,
          tags: a.tagRelations.map((tr: any) => tr.hashtag.tag).join(','),
        })),
        availableArticles.map((a: any) => ({
          id: a.id,
          category: a.category,
          tags: a.tagRelations.map((tr: any) => tr.hashtag.tag).join(','),
        })),
        count
      )

      if (scores.length > 0) {
        recommendedIds = scores.map((s: any) => s.articleId)
      } else {
        // Ultimate fallback: return most viewed articles from the pool
        recommendedIds = availableArticles.slice(0, count).map((a: any) => a.id)
      }
    }

    // Fetch full article data for recommended IDs
    const recommendations = await db.article.findMany({
      where: {
        id: { in: recommendedIds },
        status: 'PUBLISHED',
        deletedAt: null,
      },
      select: articleSelect,
    })

    // Sort by recommendation order
    const ordered = (recommendedIds ?? [])
      .map((id: any) => recommendations.find((a: any) => a.id === id))
      .filter(Boolean)
      .slice(0, count)

    return NextResponse.json({ recommendations: ordered, source: ai ? 'ai' : 'content-based' })
  } catch (error) {
    console.error('AI Recommendations error:', error)

    // Last-resort fallback: return trending articles without user context
    try {
      const trending = await db.article.findMany({
        where: { status: 'PUBLISHED', deletedAt: null },
        select: {
          id: true,
          title: true,
          summary: true,
          category: true,
          tagRelations: { include: { hashtag: { select: { tag: true } } } },
          viewCount: true,
          likeCount: true,
          createdAt: true,
          mediaRecords: { select: { url: true, type: true } },
          mediaType: true,
          authorId: true,
          author: {
            select: {
              id: true,
              name: true,
              avatar: true,
              jobTitle: true,
              isVerified: true,
            },
          },
        },
        take: 5,
        orderBy: { viewCount: 'desc' },
      })

      return NextResponse.json({ recommendations: trending, source: 'trending-fallback' })
    } catch {
      // Even the fallback failed — return empty rather than crashing
      return NextResponse.json({ success: false, error: 'حدث خطأ أثناء جلب التوصيات. يرجى المحاولة لاحقاً.', code: statusToCode(500) }, { status: 500 })
    }
  }
}
