import { NextRequest } from 'next/server'
import { requireAuth, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { setPrivacy } from '@/services/ai.service'

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth()
    const { privacy } = await req.json().catch(() => ({ privacy: {} }))
    return successResponse({ memory: await setPrivacy(user.id, privacy || {}) })
  } catch (error) { return handleApiError(error) }
}
