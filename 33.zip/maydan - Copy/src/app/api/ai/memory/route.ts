import { NextRequest } from 'next/server'
import { requireAuth, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { getMemory, saveMemory } from '@/services/ai.service'

export async function GET() {
  try {
    const user = await requireAuth()
    return successResponse({ memory: await getMemory(user.id) })
  } catch (error) { return handleApiError(error) }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth()
    const body = await req.json().catch(() => ({}))
    return successResponse({ memory: await saveMemory(user.id, body) })
  } catch (error) { return handleApiError(error) }
}
