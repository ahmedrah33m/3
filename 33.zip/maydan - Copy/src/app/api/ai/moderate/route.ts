import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, AuthError, handleApiError } from '@/lib/session';
import { moderateAIContent, moderateContent } from '@/lib/ai-utils';
import { logAIAction, logSystemError } from '@/lib/logger';
import { getAIResponseWithCache, generateAIHash, getTTLForOperation } from '@/lib/ai-cache';
import { statusToCode } from '@/lib/api-utils'

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Require authentication
    const user = await requireAuth();

    // Parse request body
    let body: { content?: string; type?: string };
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ success: false, error: 'طلب غير صالح', code: statusToCode(400) }, { status: 400 });
    }

    const { content, type } = body;

    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      return NextResponse.json({ success: false, error: 'المحتوى مطلوب للمراجعة', code: statusToCode(400) }, { status: 400 });
    }

    if (content.length > 50000) {
      return NextResponse.json({ success: false, error: 'المحتوى طويل جداً. الحد الأقصى 50000 حرف', code: statusToCode(400) }, { status: 400 });
    }

    // Moderate content using AI with fallback — مع كاش AI (1 ساعة)
    let moderationResult: { safe: boolean; flags: string[]; score: number };
    let source: 'ai' | 'fallback' | 'cached';

    // ── كاش AI — الإشراف قابل للتخزين (نفس المحتوى = نفس الحكم) ──
    const cacheKey = `moderate:${generateAIHash(content, { op: 'moderate', type })}`
    const ttl = getTTLForOperation('moderate') // 1 ساعة
    const cachedResult = await getAIResponseWithCache(
      cacheKey,
      async () => {
        try {
          const result = await moderateAIContent(content, user.id);
          return JSON.stringify(result);
        } catch (aiError) {
          console.error('AI moderation failed, using keyword fallback:', aiError);
          const result = moderateContent(content);
          return JSON.stringify({ ...result, _source: 'fallback' });
        }
      },
      ttl
    );

    try {
      const parsed = JSON.parse(cachedResult);
      moderationResult = { safe: parsed.safe, flags: parsed.flags || [], score: parsed.score };
      source = parsed._source === 'fallback' ? 'fallback' : 'ai';
    } catch {
      // فشل الكاش — استخدم التحليل المباشر
      try {
        moderationResult = await moderateAIContent(content, user.id);
        source = 'ai';
      } catch (aiError) {
        console.error('AI moderation failed, using keyword fallback:', aiError);
        moderationResult = moderateContent(content);
        source = 'fallback';
      }
    }

    const duration = Date.now() - startTime;

    await logAIAction({
      operation: 'moderation',
      model: source,
      durationMs: duration,
      success: true,
      userId: user.id,
      metadata: {
        contentType: type || 'general',
        contentLength: content.length,
        safe: moderationResult.safe,
        flags: moderationResult.flags,
        score: moderationResult.score,
        source,
      },
    });

    return NextResponse.json({
      safe: moderationResult.safe,
      flags: moderationResult.flags,
      score: moderationResult.score,
      source,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return handleApiError(error);
    }

    const duration = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'خطأ غير معروف';

    await logSystemError({
      type: 'ai_error',
      severity: 'medium',
      message: `Moderation API error: ${errorMessage}`,
      method: 'POST',
      url: '/api/ai/moderate',
    });

    await logAIAction({
      operation: 'moderation',
      model: 'fallback',
      durationMs: duration,
      success: false,
      errorMessage,
    });

    // Never return 500 - return safe result with low confidence
    return NextResponse.json({
      safe: true,
      flags: [],
      score: 0.5,
      source: 'fallback' as const,
    });
  }
}
