import { NextRequest, NextResponse } from 'next/server';
import { requireAuth, hasRole, AuthError, handleApiError } from '@/lib/session';
import {
  generateAISummary,
  generateSummary,
  analyzeAISentiment,
  analyzeSentiment,
  getAIInstance,
} from '@/lib/ai-utils';
import { logAIAction, logSystemError } from '@/lib/logger';
import { db } from '@/lib/db';
import { statusToCode } from '@/lib/api-utils'

const BATCH_SIZE = 5;

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    // Require authentication with OWNER role only
    const user = await requireAuth();

    if (!hasRole(user, ['OWNER'])) {
      return NextResponse.json({ success: false, error: 'غير مصرح. يتطلب صلاحيات مالك فقط', code: statusToCode(403) }, { status: 403 });
    }

    // Find all articles without aiScore
    let articles: Array<{
      id: string;
      title: string;
      content: string | null;
    }>;

    try {
      articles = await db.article.findMany({
        where: {
          aiScore: null,
          status: 'PUBLISHED',
        },
        select: {
          id: true,
          title: true,
          content: true,
        },
        orderBy: { createdAt: 'desc' },
        take: 50,
      });
    } catch (dbError) {
      await logSystemError({
        type: 'db_error',
        severity: 'high',
        message: `Bulk analyze: failed to fetch articles: ${dbError instanceof Error ? dbError.message : 'Unknown'}`,
        url: '/api/ai/bulk-analyze',
        method: 'POST',
      });

      return NextResponse.json({ success: false, error: 'خطأ في الوصول إلى قاعدة البيانات', code: statusToCode(400) }, { status: 400 });
    }

    const total = articles.length;

    if (total === 0) {
      return NextResponse.json({
        processed: 0,
        total: 0,
        results: [],
      });
    }

    // Process in batches
    const results: Array<{
      articleId: string;
      title: string;
      summary: string;
      sentiment: string;
      sentimentScore: number;
      qualityScore: number;
      source: string;
      error?: string;
    }> = [];

    let processed = 0;

    for (let i = 0; i < articles.length; i += BATCH_SIZE) {
      const batch = articles.slice(i, i + BATCH_SIZE);

      // Process batch in parallel
      const batchResults = await Promise.allSettled(
        batch.map(async (article) => {
          try {
            const articleText = [article.title, article.content || '']
              .filter(Boolean)
              .join('\n\n');

            if (!articleText || articleText.trim().length === 0) {
              return {
                articleId: article.id,
                title: article.title,
                summary: '',
                sentiment: 'neutral',
                sentimentScore: 0,
                qualityScore: 0,
                source: 'skipped',
                error: 'محتوى فارغ',
              };
            }

            // Run analyses in parallel for this article
            const [summaryResult, sentimentResult, qualityResult] = await Promise.all([
              // Summary - try AI then fallback
              generateAISummary(articleText, user.id).catch(() =>
                generateSummary(articleText)
              ),
              // Sentiment - try AI then fallback
              analyzeAISentiment(articleText, user.id).catch(() =>
                analyzeSentiment(articleText)
              ),
              // Quality score
              generateBulkQualityScore(articleText).catch(() => ({
                score: 50,
                source: 'fallback' as const,
              })),
            ]);

            // Determine source based on results
            const articleSource = 'mixed';

            // Update article record
            try {
              await db.article.update({
                where: { id: article.id },
                data: {
                  aiSummary: summaryResult || generateSummary(articleText),
                  sentiment: sentimentResult.sentiment,
                  aiScore: qualityResult.score,
                },
              });
            } catch (updateError) {
              console.error(`Failed to update article ${article.id}:`, updateError);
            }

            return {
              articleId: article.id,
              title: article.title,
              summary: summaryResult || generateSummary(articleText),
              sentiment: sentimentResult.sentiment,
              sentimentScore: sentimentResult.score,
              qualityScore: qualityResult.score,
              source: articleSource,
            };
          } catch (articleError) {
            const errorMsg =
              articleError instanceof Error ? articleError.message : 'خطأ غير معروف';
            return {
              articleId: article.id,
              title: article.title,
              summary: '',
              sentiment: 'neutral',
              sentimentScore: 0,
              qualityScore: 0,
              source: 'error',
              error: errorMsg,
            };
          }
        })
      );

      // Collect batch results
      for (const result of batchResults) {
        if (result.status === 'fulfilled') {
          results.push(result.value);
          processed++;
        } else {
          processed++;
        }
      }

      // Small delay between batches to avoid overwhelming the system
      if (i + BATCH_SIZE < articles.length) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }

    const duration = Date.now() - startTime;

    await logAIAction({
      operation: 'bulk_analysis',
      model: 'mixed',
      durationMs: duration,
      success: true,
      userId: user.id,
      metadata: {
        totalArticles: total,
        processedArticles: processed,
        batchSize: BATCH_SIZE,
        errorsCount: results.filter((r) => r.error).length,
      },
    });

    return NextResponse.json({
      processed,
      total,
      results,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return handleApiError(error);
    }

    const duration = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'خطأ غير معروف';

    await logSystemError({
      type: 'ai_error',
      severity: 'high',
      message: `Bulk analyze API error: ${errorMessage}`,
      method: 'POST',
      url: '/api/ai/bulk-analyze',
    });

    await logAIAction({
      operation: 'bulk_analysis',
      model: 'fallback',
      durationMs: duration,
      success: false,
      errorMessage,
    });

    // Never return 500
    return NextResponse.json({
      processed: 0,
      total: 0,
      results: [],
      error: 'حدث خطأ أثناء المعالجة. يرجى المحاولة لاحقاً.',
    });
  }
}

/**
 * Generate quality score for bulk analysis
 */
async function generateBulkQualityScore(
  content: string
): Promise<{ score: number; source: 'ai' | 'fallback' }> {
  const ai = await getAIInstance();

  if (ai) {
    try {
      const response = await ai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content:
              'أنت مقيم محتوى لمنصة ميدان الاقتصاد. قيّم جودة المحتوى الاقتصادي من 0 إلى 100. أجب برقم فقط.',
          },
          {
            role: 'user',
            content: `قيّم جودة المحتوى التالي:\n\n${content.slice(0, 2000)}`,
          },
        ],
      });

      const result = response?.choices?.[0]?.message?.content;
      if (result && typeof result === 'string') {
        const numMatch = result.match(/(\d+)/);
        if (numMatch) {
          const score = parseInt(numMatch[1], 10);
          if (score >= 0 && score <= 100) {
            return { score, source: 'ai' };
          }
        }
      }
    } catch (error) {
      console.error('AI quality scoring failed in bulk:', error);
    }
  }

  return heuristicQualityScore(content);
}

/**
 * Heuristic-based quality score for bulk processing
 */
function heuristicQualityScore(content: string): { score: number; source: 'fallback' } {
  let score = 40;

  const wordCount = content.split(/\s+/).length;
  if (wordCount > 500) score += 20;
  else if (wordCount > 200) score += 15;
  else if (wordCount > 100) score += 10;
  else if (wordCount > 50) score += 5;

  if (content.includes('\n\n')) score += 5;
  if (/\d+/.test(content)) score += 5;
  if (content.includes('%') || content.includes('نسبة')) score += 5;

  const economicKeywords = [
    'اقتصاد', 'استثمار', 'سوق', 'نمو', 'تضخم', 'ناتج محلي',
    'ميزانية', 'دينار', 'نفط', 'صادرات', 'واردات', 'بورصة',
    'GDP', 'inflation', 'market', 'investment',
  ];
  const lowerContent = content.toLowerCase();
  const keywordMatches = economicKeywords.filter((kw) =>
    lowerContent.includes(kw.toLowerCase())
  ).length;
  score += Math.min(15, keywordMatches * 3);

  if (content.includes('#') || content.includes('**')) score += 5;
  if (content.includes('•') || content.includes('-') || content.includes('*'))
    score += 5;

  return { score: Math.min(100, score), source: 'fallback' };
}
