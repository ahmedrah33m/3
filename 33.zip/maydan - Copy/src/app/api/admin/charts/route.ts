import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextResponse } from 'next/server'

// GET /api/admin/charts — بيانات حقيقية للرسوم البيانية (بدون Math.random)
export async function GET() {
  try {
    await requireAdmin()

    const now = new Date()
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

    // ── بيانات حقيقية من DB ──────────────────────────────────
    const [recentUsers, articles, totalUsers, totalArticlesCount, totalViewsAgg, totalLikesAgg, totalCommentsAgg] = await Promise.all([
      // المستخدمون الجدد آخر 30 يوم
      db.user.findMany({
        where: { createdAt: { gte: thirtyDaysAgo } },
        select: { id: true, createdAt: true },
        orderBy: { createdAt: 'asc' },
      }),
      // كل المقالات (للـ category distribution)
      db.article.findMany({
        where: { status: 'PUBLISHED' },
        select: { id: true, category: true, createdAt: true, viewCount: true, likeCount: true, commentCount: true },
      }),
      // إجمالي المستخدمين
      db.user.count(),
      // إجمالي المقالات المنشورة
      db.article.count({ where: { status: 'PUBLISHED' } }),
      // إجمالي المشاهدات
      db.article.aggregate({ _sum: { viewCount: true } }),
      // إجمالي الإعجابات
      db.article.aggregate({ _sum: { likeCount: true } }),
      // إجمالي التعليقات
      db.article.aggregate({ _sum: { commentCount: true } }),
    ])

    const totalViews = Number(totalViewsAgg._sum.viewCount || 0)
    const totalLikes = Number(totalLikesAgg._sum.likeCount || 0)
    const totalComments = Number(totalCommentsAgg._sum.commentCount || 0)

    // ── حسابات أسبوعية ────────────────────────────────────────
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    const newUsersThisWeek = recentUsers.filter((u) => u.createdAt >= sevenDaysAgo).length
    const newArticlesThisWeek = articles.filter((a) => a.createdAt && a.createdAt >= sevenDaysAgo).length

    // الأسبوع السابق لمقارنة النمو
    const fourteenDaysAgo = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000)
    const prevWeekUsers = recentUsers.filter(
      (u) => u.createdAt >= fourteenDaysAgo && u.createdAt < sevenDaysAgo
    ).length
    const prevWeekArticles = articles.filter(
      (a) => a.createdAt && a.createdAt >= fourteenDaysAgo && a.createdAt < sevenDaysAgo
    ).length

    const userGrowthPercent = prevWeekUsers > 0
      ? Math.round(((newUsersThisWeek - prevWeekUsers) / prevWeekUsers) * 100)
      : (newUsersThisWeek > 0 ? 100 : 0)

    const articleGrowthPercent = prevWeekArticles > 0
      ? Math.round(((newArticlesThisWeek - prevWeekArticles) / prevWeekArticles) * 100)
      : (newArticlesThisWeek > 0 ? 100 : 0)

    // ✅ بدلاً من Math.random: احسب نسبة نمو المشاهدات من بيانات حقيقية
    // قارن مشاهدات آخر 7 أيام مع 7 أيام قبلها
    const viewsLast7Days = articles
      .filter((a) => a.createdAt && a.createdAt >= sevenDaysAgo)
      .reduce((sum, a) => sum + (a.viewCount || 0), 0)
    const viewsPrev7Days = articles
      .filter((a) => a.createdAt && a.createdAt >= fourteenDaysAgo && a.createdAt < sevenDaysAgo)
      .reduce((sum, a) => sum + (a.viewCount || 0), 0)
    const viewsGrowthPercent = viewsPrev7Days > 0
      ? Math.round(((viewsLast7Days - viewsPrev7Days) / viewsPrev7Days) * 100)
      : (viewsLast7Days > 0 ? 100 : 0)

    // ── بيانات يومية حقيقية (آخر 30 يوم) ─────────────────────
    const dailyUsers: { date: string; count: number }[] = []
    const dailyArticles: { date: string; count: number }[] = []
    const dailyViews: { date: string; count: number }[] = []
    const engagementData: { date: string; likes: number; comments: number; shares: number }[] = []

    for (let i = 29; i >= 0; i--) {
      const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000)
      const dateStr = date.toISOString().split('T')[0]
      const dayStart = new Date(dateStr + 'T00:00:00.000Z')
      const dayEnd = new Date(dateStr + 'T23:59:59.999Z')

      // بيانات حقيقية: المستخدمون المسجلون في هذا اليوم
      const usersOnDay = recentUsers.filter(
        (u) => u.createdAt >= dayStart && u.createdAt <= dayEnd
      ).length

      // بيانات حقيقية: المقالات المنشورة في هذا اليوم
      const articlesOnDay = articles.filter(
        (a) => a.createdAt && a.createdAt >= dayStart && a.createdAt <= dayEnd
      )

      // بيانات حقيقية: مشاهدات المقالات المنشورة في هذا اليوم
      const viewsOnDay = articlesOnDay.reduce((sum, a) => sum + (a.viewCount || 0), 0)

      // بيانات حقيقية: تفاعل المقالات المنشورة في هذا اليوم
      const likesOnDay = articlesOnDay.reduce((sum, a) => sum + (a.likeCount || 0), 0)
      const commentsOnDay = articlesOnDay.reduce((sum, a) => sum + (a.commentCount || 0), 0)

      dailyUsers.push({ date: dateStr, count: usersOnDay })
      dailyArticles.push({ date: dateStr, count: articlesOnDay.length })
      dailyViews.push({ date: dateStr, count: viewsOnDay })

      // ✅ engagementData ببيانات حقيقية (likes + comments + reposts من DB)
      // ملاحظة: shares غير متتبعة حالياً، استخدم 0 أو أضف field في المستقبل
      engagementData.push({
        date: dateStr,
        likes: likesOnDay,
        comments: commentsOnDay,
        shares: 0, // غير متتبع حالياً في schema
      })
    }

    // ── تجميع أسبوعي (آخر 4 أسابيع) ──────────────────────────
    const weeklyUsers: { label: string; count: number }[] = []
    const weeklyArticles: { label: string; count: number }[] = []
    const weeklyViews: { label: string; count: number }[] = []
    for (let w = 3; w >= 0; w--) {
      const start = new Date(now.getTime() - (w + 1) * 7 * 24 * 60 * 60 * 1000)
      const end = new Date(now.getTime() - w * 7 * 24 * 60 * 60 * 1000)
      const startStr = start.toISOString().split('T')[0]
      const endStr = end.toISOString().split('T')[0]
      const label = `${startStr.slice(5)}/${endStr.slice(5)}`

      const wUsers = dailyUsers
        .filter(d => d.date >= startStr && d.date < endStr)
        .reduce((s, d) => s + d.count, 0)
      const wArticles = dailyArticles
        .filter(d => d.date >= startStr && d.date < endStr)
        .reduce((s, d) => s + d.count, 0)
      const wViews = dailyViews
        .filter(d => d.date >= startStr && d.date < endStr)
        .reduce((s, d) => s + d.count, 0)

      weeklyUsers.push({ label, count: wUsers })
      weeklyArticles.push({ label, count: wArticles })
      weeklyViews.push({ label, count: wViews })
    }

    // ── تجميع شهري (آخر 6 أشهر) — بيانات حقيقية ─────────────
    const monthlyUsers: { label: string; count: number }[] = []
    const monthlyArticles: { label: string; count: number }[] = []
    const monthlyViews: { label: string; count: number }[] = []

    for (let m = 5; m >= 0; m--) {
      const monthStart = new Date(now.getFullYear(), now.getMonth() - m, 1)
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - m + 1, 1)
      const monthStr = monthStart.toLocaleDateString('ar-IQ', { month: 'short' })

      // ✅ بيانات حقيقية: مستخدمون سُجّلوا في هذا الشهر
      const monthUsers = await db.user.count({
        where: { createdAt: { gte: monthStart, lt: monthEnd } },
      })
      const monthArticles = await db.article.count({
        where: { createdAt: { gte: monthStart, lt: monthEnd }, status: 'PUBLISHED' },
      })
      const monthViewsAgg = await db.article.aggregate({
        where: { createdAt: { gte: monthStart, lt: monthEnd } },
        _sum: { viewCount: true },
      })
      const monthViews = Number(monthViewsAgg._sum.viewCount || 0)

      monthlyUsers.push({ label: monthStr, count: monthUsers })
      monthlyArticles.push({ label: monthStr, count: monthArticles })
      monthlyViews.push({ label: monthStr, count: monthViews })
    }

    // ── توزيع المقالات حسب الفئة (بيانات حقيقية) ─────────────
    const categoryMap: Record<string, string> = {
      ANALYSIS: 'تحليل',
      REPORT: 'تقرير',
      STUDY: 'دراسة',
      OPINION: 'رأي',
      NEWS: 'أخبار',
      RESEARCH: 'بحث',
    }
    const categoriesCount: Record<string, number> = {}
    articles.forEach((a) => {
      const cat = categoryMap[a.category] || a.category
      categoriesCount[cat] = (categoriesCount[cat] || 0) + 1
    })

    const categoryDistribution = Object.entries(categoriesCount).map(([name, value]) => ({
      name,
      value,
    }))

    const topCategories = Object.entries(categoriesCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, count: value }))

    // ✅ activeUsersThisWeek: بيانات حقيقية (آخر تسجيل دخول خلال 7 أيام)
    const activeUsersThisWeek = await db.user.count({
      where: { lastLoginAt: { gte: sevenDaysAgo } },
    })

    return NextResponse.json({
      daily: { users: dailyUsers, articles: dailyArticles, views: dailyViews },
      weekly: { users: weeklyUsers, articles: weeklyArticles, views: weeklyViews },
      monthly: { users: monthlyUsers, articles: monthlyArticles, views: monthlyViews },
      categoryDistribution,
      totalUsers,
      activeUsersThisWeek,
      kpiSummary: {
        totalUsers,
        newUsersThisWeek,
        userGrowthPercent,
        totalArticles: totalArticlesCount,
        newArticlesThisWeek,
        articleGrowthPercent,
        totalViews,
        viewsGrowthPercent,
        totalLikes,
        totalComments,
      },
      engagementData,
      topCategories,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
