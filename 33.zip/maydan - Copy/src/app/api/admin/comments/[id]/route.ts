import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()

    const { id } = await params

    const comment = await db.comment.findUnique({ where: { id } })
    if (!comment) {
      return NextResponse.json({ success: false, error: 'التعليق غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    // Delete likes on this comment
    await db.like.deleteMany({ where: { commentId: id } })

    // Delete replies (recursively find all nested replies)
    const allReplyIds: string[] = []
    async function collectReplies(parentId: string) {
      const replies = await db.comment.findMany({ where: { parentId }, select: { id: true } })
      for (const reply of replies) {
        allReplyIds.push(reply.id)
        await db.like.deleteMany({ where: { commentId: reply.id } })
        await collectReplies(reply.id)
      }
    }
    await collectReplies(id)

    // Delete all replies
    for (const replyId of allReplyIds) {
      await db.comment.delete({ where: { id: replyId } })
    }

    // Delete the comment itself
    await db.comment.delete({ where: { id } })

    // Decrement article commentCount
    await db.article.update({
      where: { id: comment.articleId },
      data: { commentCount: { decrement: 1 + allReplyIds.length } },
    })

    await logAudit(admin.id, AuditActions.COMMENT_DELETE, TargetTypes.COMMENT, id, { content: comment.content.slice(0, 100) })

    return NextResponse.json({ message: 'تم حذف التعليق بنجاح' })
  } catch (error) {
    return handleApiError(error)
  }
}
