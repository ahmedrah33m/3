import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { statusToCode } from '@/lib/api-utils'

// POST /api/admin/auto-publish/retry — Retry a failed publish (actual re-publish)
export async function POST(request: NextRequest) {
  try {
    await requireAdmin()
    const { logId } = await request.json()

    if (!logId) {
      return NextResponse.json({ success: false, error: 'معرّف السجل مطلوب', code: statusToCode(400) }, { status: 400 })
    }

    const log = await db.publishLog.findUnique({
      where: { id: logId },
      include: { channel: true },
    })

    if (!log) {
      return NextResponse.json({ success: false, error: 'السجل غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    if (log.status !== 'failed') {
      return NextResponse.json({ success: false, error: 'يمكن إعادة المحاولة فقط للمنشورات الفاشلة', code: statusToCode(400) }, { status: 400 })
    }

    if (log.retryCount >= log.maxRetries) {
      return NextResponse.json({ success: false, error: 'تم تجاوز الحد الأقصى لإعادة المحاولة', code: statusToCode(400) }, { status: 400 })
    }

    // Update to publishing
    await db.publishLog.update({
      where: { id: logId },
      data: { status: 'publishing', errorMessage: null, retryCount: { increment: 1 } },
    })

    // Trigger actual re-publish in background
    const { retryPublish } = await import('@/lib/auto-publish-service')
    retryPublish(logId).catch(() => {})

    return NextResponse.json({ message: 'تمت بدء إعادة المحاولة' })
  } catch (error) {
    return handleApiError(error)
  }
}

// GET /api/admin/auto-publish/retry?channelId=xxx — Get failed logs
export async function GET(request: NextRequest) {
  try {
    await requireAdmin()
    const { searchParams } = new URL(request.url)
    const channelId = searchParams.get('channelId')

    const where: any = { status: 'failed' }
    if (channelId) where.channelId = channelId

    const failedLogs = await db.publishLog.findMany({
      where,
      take: 50,
      orderBy: { createdAt: 'desc' },
      include: { channel: { select: { name: true, platform: true } } },
    })

    return NextResponse.json({ failedLogs })
  } catch (error) {
    return handleApiError(error)
  }
}