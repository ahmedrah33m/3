import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { getDefaultTemplate } from '@/lib/auto-publish-service'

// ═══════════════════════════════════════════════
// PUT /api/admin/auto-publish/[id] — Update channel
// ═══════════════════════════════════════════════
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireAdmin()
    const { id } = await params
    const body = await req.json()
    const { name, identifier, accessToken, categories, template, isActive, autoPublish, metadata } = body

    const channel = await db.publishChannel.update({
      where: { id },
      data: {
        ...(name !== undefined && { name }),
        ...(identifier !== undefined && { identifier }),
        ...(accessToken !== undefined && { accessToken }),
        ...(categories !== undefined && { categories: JSON.stringify(categories) }),
        ...(template !== undefined && { template }),
        ...(isActive !== undefined && { isActive }),
        ...(autoPublish !== undefined && { autoPublish }),
        ...(metadata !== undefined && { metadata: JSON.stringify(metadata) }),
      },
    })

    return NextResponse.json({ channel, message: 'تم تحديث القناة' })
  } catch (error) {
    return handleApiError(error)
  }
}

// ═══════════════════════════════════════════════
// DELETE /api/admin/auto-publish/[id] — Delete channel
// ═══════════════════════════════════════════════
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireAdmin()
    const { id } = await params

    await db.publishLog.deleteMany({ where: { channelId: id } })
    await db.publishChannel.delete({ where: { id } })

    return NextResponse.json({ message: 'تم حذف القناة وجميع سجلات النشر' })
  } catch (error) {
    return handleApiError(error)
  }
}