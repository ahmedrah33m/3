import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { getDefaultTemplate, testChannelConnection, getAllChannels } from '@/lib/auto-publish-service'
import { statusToCode } from '@/lib/api-utils'

// ═══════════════════════════════════════════════
// GET /api/admin/auto-publish — Dashboard data
// ═══════════════════════════════════════════════
export async function GET() {
  try {
    await requireAdmin()
    const channels = await getAllChannels()

    const now = new Date()
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())

    const [totalLogs, publishedToday, failedToday, recentLogs] = await Promise.all([
      db.publishLog.count(),
      db.publishLog.count({ where: { status: 'published', createdAt: { gte: startOfDay } } }),
      db.publishLog.count({ where: { status: 'failed', createdAt: { gte: startOfDay } } }),
      db.publishLog.findMany({
        take: 20,
        orderBy: { createdAt: 'desc' },
        include: { channel: { select: { name: true, platform: true, logoUrl: true } } },
      }),
    ])

    return NextResponse.json({
      channels,
      stats: {
        totalChannels: channels.length,
        activeChannels: channels.filter(c => c.isActive && c.autoPublish).length,
        totalPublished: totalLogs,
        todayPublished: publishedToday,
        todayFailed: failedToday,
      },
      recentLogs,
      defaultTemplates: {
        telegram: getDefaultTemplate('telegram'),
        whatsapp: getDefaultTemplate('whatsapp'),
        facebook: getDefaultTemplate('facebook'),
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// ═══════════════════════════════════════════════
// POST /api/admin/auto-publish — Add new channel
// ═══════════════════════════════════════════════
export async function POST(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { name, platform, identifier, accessToken, categories, template, autoPublish, metadata } = body

    if (!name || !platform || !identifier) {
      return NextResponse.json({ success: false, error: 'الاسم والمنصة والمعرّف مطلوبون', code: statusToCode(400) }, { status: 400 })
    }

    const channel = await db.publishChannel.create({
      data: {
        name,
        platform,
        identifier,
        accessToken: accessToken || null,
        categories: JSON.stringify(categories || []),
        template: template || getDefaultTemplate(platform),
        autoPublish: autoPublish !== false,
        isActive: true,
        metadata: JSON.stringify(metadata || {}),
      },
    })

    return NextResponse.json({ channel, message: 'تم إضافة القناة بنجاح' }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}