import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'

const MONTHS = 6

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

// GET /api/admin/finance/report — aggregated revenue/finance dashboard for admins
export async function GET(_request: NextRequest) {
  try {
    await requireAdmin()

    const now = new Date()
    const since = new Date(now.getFullYear(), now.getMonth() - (MONTHS - 1), 1)

    // ── KPIs ──
    const [
      paidInvoices,
      walletAgg,
      topUpAgg,
      withdrawalAgg,
    ] = await Promise.all([
      db.invoice.findMany({
        where: { status: 'PAID' },
        select: { amount: true, commission: true, netAmount: true, serviceType: true, createdAt: true },
      }),
      db.wallet.aggregate({
        _sum: { balance: true, totalDeposited: true, totalEarnings: true },
      }),
      db.topUpRequest.aggregate({
        where: { status: 'APPROVED' },
        _sum: { amount: true },
        _count: { _all: true },
      }),
      db.withdrawalRequest.aggregate({
        where: { status: 'COMPLETED' },
        _sum: { amount: true },
        _count: { _all: true },
      }),
    ])

    const approvedTopUps = Number(topUpAgg._sum.amount ?? 0)
    const completedWithdrawals = Number(withdrawalAgg._sum.amount ?? 0)
    const userBalances = Number(walletAgg._sum.balance ?? 0)
    const totalDeposited = Number(walletAgg._sum.totalDeposited ?? 0)
    const totalEarnings = Number(walletAgg._sum.totalEarnings ?? 0)

    const totalRevenue = paidInvoices.reduce((s, i) => s + Number(i.amount), 0)
    const platformCommission = paidInvoices.reduce((s, i) => s + Number(i.commission), 0)

    // ── Monthly series (revenue + commission, last 6 months) ──
    const monthly: Record<string, { revenue: number; commission: number }> = {}
    for (let i = 0; i < MONTHS; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      monthly[monthKey(d)] = { revenue: 0, commission: 0 }
    }
    for (const inv of paidInvoices) {
      if (inv.createdAt < since) continue
      const k = monthKey(inv.createdAt)
      if (monthly[k]) {
        monthly[k].revenue += Number(inv.amount)
        monthly[k].commission += Number(inv.commission)
      }
    }
    const monthlySeries = Object.entries(monthly).map(([month, v]) => ({ month, ...v }))

    // ── By service type ──
    const byServiceMap: Record<string, { revenue: number; count: number }> = {}
    for (const inv of paidInvoices) {
      const key = inv.serviceType || 'OTHER'
      if (!byServiceMap[key]) byServiceMap[key] = { revenue: 0, count: 0 }
      byServiceMap[key].revenue += Number(inv.amount)
      byServiceMap[key].count += 1
    }
    const byService = Object.entries(byServiceMap)
      .map(([serviceType, v]) => ({ serviceType, ...v }))
      .sort((a, b) => b.revenue - a.revenue)

    // ── Recent wallet transactions with user info ──
    const txs = await db.walletTransaction.findMany({
      orderBy: { createdAt: 'desc' },
      take: 30,
    })
    const walletIds = [...new Set(txs.map(t => t.walletId))]
    const wallets = walletIds.length
      ? await db.wallet.findMany({ where: { id: { in: walletIds } }, select: { id: true, userId: true } })
      : []
    const userIds = [...new Set(wallets.map(w => w.userId))]
    const users = userIds.length
      ? await db.user.findMany({ where: { id: { in: userIds } }, select: { id: true, name: true, email: true, avatar: true } })
      : []
    const walletUser = new Map(wallets.map(w => [w.id, w.userId]))
    const userMap = new Map(users.map(u => [u.id, u]))
    const recentTransactions = txs.map(t => ({
      id: t.id,
      type: t.type,
      amount: Number(t.amount),
      serviceType: t.serviceType,
      serviceId: t.serviceId,
      status: t.status,
      description: t.description,
      createdAt: t.createdAt,
      user: userMap.get(walletUser.get(t.walletId) || '') || null,
    }))

    // ── Pending approvals ──
    const [pendingTopUps, pendingWithdrawals] = await Promise.all([
      db.topUpRequest.count({ where: { status: 'PENDING_REVIEW' } }),
      db.withdrawalRequest.count({ where: { status: 'PENDING_REVIEW' } }),
    ])

    return NextResponse.json({
      kpis: {
        totalRevenue,
        platformCommission,
        approvedTopUps,
        completedWithdrawals,
        userBalances,
        totalDeposited,
        totalEarnings,
        pendingTopUps,
        pendingWithdrawals,
        paidInvoiceCount: paidInvoices.length,
      },
      monthlySeries,
      byService,
      recentTransactions,
    })
  } catch (error) {
    return handleApiError(error)
  }
}