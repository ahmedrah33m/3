import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    // Get audit logs for bulk notifications
    const logs = await db.auditLog.findMany({
      where: { action: 'BULK_NOTIFICATION' },
      include: {
        admin: { select: { name: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: (page - 1) * limit,
    })

    const history = logs.map((log: any) => {
      const details = log.details ? JSON.parse(log.details) : {}
      return {
        id: log.id,
        title: details.title || 'بدون عنوان',
        targetAudience: details.targetAudience || 'الكل',
        type: details.type || 'معلومة',
        priority: details.priority || 'عادي',
        sentCount: details.sentCount || 0,
        adminName: log.admin.name || log.admin.email,
        createdAt: log.createdAt,
      }
    })

    return NextResponse.json({ history, total: logs.length })
  } catch (error) {
    return handleApiError(error)
  }
}
