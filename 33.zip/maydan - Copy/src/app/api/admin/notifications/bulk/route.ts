import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function POST(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    const body = await request.json()
    const { title, message, targetAudience, type, priority } = body

    if (!title || !message) {
      return NextResponse.json({ success: false, error: 'العنوان والرسالة مطلوبان', code: statusToCode(400) }, { status: 400 })
    }

    // Determine target users
    let users
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)

    switch (targetAudience) {
      case 'experts':
        users = await db.user.findMany({ where: { role: 'EXPERT', isBanned: false } })
        break
      case 'premium':
        users = await db.user.findMany({
          where: { isBanned: false },
          include: { subscriptions: true },
        })
        users = users.filter((u: any) => u.subscriptions?.some?.((s: any) => s.plan === 'PREMIUM' || s.plan === 'BASIC'))
        break
      case 'new':
        users = await db.user.findMany({ where: { createdAt: { gte: thirtyDaysAgo }, isBanned: false } })
        break
      default: // all
        users = await db.user.findMany({ where: { isBanned: false } })
    }

    // Create notifications in batches
    const batchSize = 50
    let createdCount = 0

    for (let i = 0; i < users.length; i += batchSize) {
      const batch = users.slice(i, i + batchSize)
      await db.notification.createMany({
        data: batch.map((user: any) => ({
          userId: user.id,
          type: 'ARTICLE_PUBLISHED' as any,
          title,
          message,
          data: JSON.stringify({ type, priority, isBulk: true }),
        })),
      })
      createdCount += batch.length
    }

    await logAudit(admin.id, AuditActions.BULK_NOTIFICATION, TargetTypes.NOTIFICATION, undefined, {
      title,
      targetAudience,
      type,
      priority,
      sentCount: createdCount,
    })

    return NextResponse.json({ message: `تم إرسال الإشعار إلى ${createdCount} مستخدم`, count: createdCount })
  } catch (error) {
    return handleApiError(error)
  }
}
