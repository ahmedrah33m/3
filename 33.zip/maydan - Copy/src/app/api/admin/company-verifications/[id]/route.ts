import { requireAuth, handleApiError } from '@/lib/session'
import { successResponse, errorResponse } from '@/lib/api-utils'
import {
  listCompanyVerifications,
  reviewCompanyVerification,
  CompanyVerificationError,
} from '@/services/company-verification.service'

// GET /api/admin/company-verifications?status=PENDING&page=1&limit=20 — قائمة طلبات تحقق الشركات
export async function GET(request: Request) {
  try {
    const user = await requireAuth()
    if (!['OWNER', 'ADMIN', 'MODERATOR'].includes(user.role)) {
      return errorResponse('ليست لديك صلاحية الإدارة', 'FORBIDDEN', 403)
    }

    const url = new URL(request.url)
    const status = url.searchParams.get('status') || undefined
    const page = Number(url.searchParams.get('page')) || 1
    const limit = Math.min(Number(url.searchParams.get('limit')) || 20, 100)

    const result = await listCompanyVerifications({ status, page, limit })
    return successResponse(result)
  } catch (error: unknown) {
    return handleApiError(error)
  }
}

// POST /api/admin/company-verifications/{id} — مراجعة طلب (APPROVED/REJECTED) + تحديث حالة الشركة
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await requireAuth()
    if (!['OWNER', 'ADMIN', 'MODERATOR'].includes(user.role)) {
      return errorResponse('ليست لديك صلاحية الإدارة', 'FORBIDDEN', 403)
    }

    const { id } = await params
    const body = await request.json().catch(() => ({}))
    const decision =
      body.decision === 'APPROVED' || body.decision === 'REJECTED' ? body.decision : null

    if (!decision) {
      return errorResponse('يرجى تحديد القرار (APPROVED أو REJECTED)', 'VALIDATION_ERROR', 400)
    }

    const result = await reviewCompanyVerification({
      verificationId: id,
      reviewerId: user.id,
      decision,
      notes: typeof body.notes === 'string' && body.notes.trim() ? body.notes.trim() : undefined,
    })
    return successResponse(result)
  } catch (error: unknown) {
    if (error instanceof CompanyVerificationError) {
      return errorResponse(error.message, 'COMPANY_VERIFICATION_ERROR', error.statusCode)
    }
    return handleApiError(error)
  }
}
