import { successResponse, errorResponse } from '@/lib/api-utils'
import { requireAuth, handleApiError } from '@/lib/session'
import {
  listCompanyVerifications,
  CompanyVerificationError,
} from '@/services/company-verification.service'

// GET /api/admin/company-verifications — قائمة طلبات التحقق (الإدارة) مع فلترة بالحالة
export async function GET(request: Request) {
  try {
    const user = await requireAuth()
    if (!['OWNER', 'ADMIN', 'MODERATOR'].includes(user.role)) {
      return errorResponse('ليست لديك صلاحية الإدارة', 'FORBIDDEN', 403)
    }

    const url = new URL(request.url)
    const status = url.searchParams.get('status') || undefined
    const page = Number(url.searchParams.get('page')) || 1
    const limit = Number(url.searchParams.get('limit')) || 20

    const result = await listCompanyVerifications({ status, page, limit })
    return successResponse(result)
  } catch (error: unknown) {
    if (error instanceof CompanyVerificationError) {
      return errorResponse(error.message, 'COMPANY_VERIFICATION_ERROR', error.statusCode)
    }
    return handleApiError(error)
  }
}
