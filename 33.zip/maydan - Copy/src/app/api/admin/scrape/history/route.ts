import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { listLogs } from '@/lib/scraper-service'

// ═══════════════════════════════════════════════
// GET /api/admin/scrape/history — سجل العمليات
// ═══════════════════════════════════════════════
export async function GET(request: NextRequest) {
  try {
    await requireAdmin()
    const limitParam = request.nextUrl.searchParams.get('limit')
    const limit = Math.min(parseInt(limitParam || '50', 10) || 50, 200)

    const logs = await listLogs(limit)
    return NextResponse.json({ logs })
  } catch (error) {
    return handleApiError(error)
  }
}
