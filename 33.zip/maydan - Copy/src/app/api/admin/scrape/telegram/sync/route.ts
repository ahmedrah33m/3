import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { syncSource } from '@/lib/scraper-service'
import { statusToCode } from '@/lib/api-utils'

// ═══════════════════════════════════════════════
// POST /api/admin/scrape/telegram/sync — مزامنة مصدر
// ═══════════════════════════════════════════════
export async function POST(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { sourceId } = body

    if (!sourceId) {
      return NextResponse.json({ success: false, error: 'معرّف المصدر مطلوب', code: statusToCode(400) }, { status: 400 })
    }

    const result = await syncSource(sourceId)
    if (!result.success) {
      return NextResponse.json(result, { status: 400 })
    }

    return NextResponse.json(result)
  } catch (error) {
    return handleApiError(error)
  }
}
