import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { listSources, addSource } from '@/lib/scraper-service'
import { statusToCode } from '@/lib/api-utils'

// ═══════════════════════════════════════════════
// GET /api/admin/scrape/telegram/channels — قنوات تيليجرام
// ═══════════════════════════════════════════════
export async function GET() {
  try {
    await requireAdmin()
    const sources = await listSources('telegram')
    return NextResponse.json({ sources })
  } catch (error) {
    return handleApiError(error)
  }
}

// ═══════════════════════════════════════════════
// POST /api/admin/scrape/telegram/channels — إضافة قناة
// ═══════════════════════════════════════════════
export async function POST(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { name, url, identifier, autoPublish, scrapeInterval, publishAsUserId, defaultCategory, defaultProvince, filterKeywords, excludeKeywords } = body

    if (!name || !name.trim()) {
      return NextResponse.json({ success: false, error: 'اسم القناة مطلوب', code: statusToCode(400) }, { status: 400 })
    }
    if (!url || !url.trim()) {
      return NextResponse.json({ success: false, error: 'رابط القناة مطلوب (مثال: @channel_username أو رابط t.me)', code: statusToCode(400) }, { status: 400 })
    }

    const source = await addSource({
      name,
      type: 'telegram',
      url,
      identifier: identifier || url,
      autoPublish: autoPublish !== false,
      scrapeInterval,
      publishAsUserId,
      defaultCategory,
      defaultProvince,
      filterKeywords,
      excludeKeywords,
    })

    return NextResponse.json({ source, message: 'تمت إضافة القناة بنجاح' }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
