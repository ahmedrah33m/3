import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { listSources, addSource } from '@/lib/scraper-service'
import { statusToCode } from '@/lib/api-utils'

// ═══════════════════════════════════════════════
// GET /api/admin/scrape/web — مصادر الويب
// ═══════════════════════════════════════════════
export async function GET() {
  try {
    await requireAdmin()
    const sources = await listSources('website')
    return NextResponse.json({ sources })
  } catch (error) {
    return handleApiError(error)
  }
}

// ═══════════════════════════════════════════════
// POST /api/admin/scrape/web — إضافة مصدر ويب
// ═══════════════════════════════════════════════
export async function POST(request: NextRequest) {
  try {
    await requireAdmin()
    const body = await request.json()
    const { name, url, autoPublish, scrapeInterval, filterKeywords, excludeKeywords } = body

    if (!name || !name.trim()) {
      return NextResponse.json({ success: false, error: 'اسم الموقع مطلوب', code: statusToCode(400) }, { status: 400 })
    }
    if (!url || !url.trim()) {
      return NextResponse.json({ success: false, error: 'رابط الموقع مطلوب', code: statusToCode(400) }, { status: 400 })
    }

    const source = await addSource({
      name,
      type: 'website',
      url,
      autoPublish: autoPublish !== false,
      scrapeInterval,
      filterKeywords,
      excludeKeywords,
    })

    return NextResponse.json({ source, message: 'تمت إضافة الموقع بنجاح' }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
