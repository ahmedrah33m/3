import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { updateSource, deleteSource, syncSource } from '@/lib/scraper-service'
import { statusToCode } from '@/lib/api-utils'

// ═══════════════════════════════════════════════
// PATCH /api/admin/scrape/web/[id] — تحديث مصدر ويب
// ═══════════════════════════════════════════════
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin()
    const { id } = await params
    const body = await request.json()

    const updates: Record<string, unknown> = {}
    if (typeof body.name === 'string') updates.name = body.name
    if (typeof body.url === 'string') updates.url = body.url
    if (typeof body.isActive === 'boolean') updates.isActive = body.isActive
    if (typeof body.autoPublish === 'boolean') updates.autoPublish = body.autoPublish
    if (typeof body.scrapeInterval === 'number') updates.scrapeInterval = body.scrapeInterval
    if (body.filterKeywords !== undefined) updates.filterKeywords = Array.isArray(body.filterKeywords) ? body.filterKeywords.join(', ') : body.filterKeywords
    if (body.excludeKeywords !== undefined) updates.excludeKeywords = Array.isArray(body.excludeKeywords) ? body.excludeKeywords.join(', ') : body.excludeKeywords

    const source = await updateSource(id, updates)
    if (!source) {
      return NextResponse.json({ success: false, error: 'المصدر غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    return NextResponse.json({ source, message: 'تم تحديث المصدر' })
  } catch (error) {
    return handleApiError(error)
  }
}

// ═══════════════════════════════════════════════
// DELETE /api/admin/scrape/web/[id] — حذف مصدر ويب
// ═══════════════════════════════════════════════
export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin()
    const { id } = await params
    const deleted = await deleteSource(id)
    if (!deleted) {
      return NextResponse.json({ success: false, error: 'المصدر غير موجود', code: statusToCode(404) }, { status: 404 })
    }
    return NextResponse.json({ message: 'تم حذف المصدر' })
  } catch (error) {
    return handleApiError(error)
  }
}

// ═══════════════════════════════════════════════
// POST /api/admin/scrape/web/[id] — مزامنة مصدر ويب
// ═══════════════════════════════════════════════
export async function POST(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin()
    const { id } = await params

    const result = await syncSource(id)
    if (!result.success) {
      return NextResponse.json(result, { status: 400 })
    }

    return NextResponse.json(result)
  } catch (error) {
    return handleApiError(error)
  }
}
