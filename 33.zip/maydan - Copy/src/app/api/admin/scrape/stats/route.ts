import { NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { getScraperStats } from '@/lib/scraper-service'

// ═══════════════════════════════════════════════
// GET /api/admin/scrape/stats — إحصائيات الجالب
// ═══════════════════════════════════════════════
export async function GET() {
  try {
    await requireAdmin()
    const stats = await getScraperStats()
    return NextResponse.json(stats)
  } catch (error) {
    return handleApiError(error)
  }
}
