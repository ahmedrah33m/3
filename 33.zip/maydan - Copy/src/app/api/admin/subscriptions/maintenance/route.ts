import { requireAdmin, handleApiError } from '@/lib/session'
import { runSubscriptionMaintenance } from '@/lib/subscription-maintenance'
import { NextResponse } from 'next/server'

export async function POST() {
  try {
    await requireAdmin()
    const result = await runSubscriptionMaintenance()
    return NextResponse.json({ success: true, ...result })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function GET() {
  try {
    await requireAdmin()
    return NextResponse.json({ success: true, message: 'POST لتشغيل صيانة الاشتراكات' })
  } catch (error) {
    return handleApiError(error)
  }
}