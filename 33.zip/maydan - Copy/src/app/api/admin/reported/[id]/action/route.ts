import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()
    const { id } = await params
    const body = await request.json()
    const { action } = body

    const type = body.type || 'ARTICLE'

    if (action === 'dismiss') {
      if (type === 'ARTICLE') {
        await db.article.update({
          where: { id },
          data: { isFlagged: false, flagReason: null },
        })
      }
      await logAudit(admin.id, AuditActions.REPORT_DISMISS, type, id, { action: 'dismiss' })
      return NextResponse.json({ message: 'تم تجاهل الإبلاغ' })
    }

    if (action === 'delete') {
      if (type === 'ARTICLE') {
        const article = await db.article.findUnique({ where: { id } })
        if (article) {
          await db.comment.deleteMany({ where: { articleId: id } })
          await db.like.deleteMany({ where: { articleId: id } })
          await db.article.delete({ where: { id } })
          await db.user.update({
            where: { id: article.authorId },
            data: { articlesCount: { decrement: 1 } },
          })
        }
      } else if (type === 'COMMENT') {
        await db.comment.delete({ where: { id } })
      } else if (type === 'DISCUSSION') {
        await db.discussionReply.deleteMany({ where: { discussionId: id } })
        await db.discussion.delete({ where: { id } })
      }
      await logAudit(admin.id, AuditActions.REPORT_DELETE, type, id, { action: 'delete' })
      return NextResponse.json({ message: 'تم حذف المحتوى المبلغ عنه' })
    }

    if (action === 'approve') {
      if (type === 'ARTICLE') {
        await db.article.update({
          where: { id },
          data: { isFlagged: false, flagReason: null },
        })
      }
      await logAudit(admin.id, AuditActions.REPORT_APPROVE, type, id, { action: 'approve' })
      return NextResponse.json({ message: 'تم الموافقة على المحتوى' })
    }

    return NextResponse.json({ success: false, error: 'إجراء غير صالح', code: statusToCode(400) }, { status: 400 })
  } catch (error) {
    return handleApiError(error)
  }
}
