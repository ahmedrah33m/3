import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()
    const { id } = await params
    const body = await request.json()
    const { comment, type } = body

    if (!comment || !comment.trim()) {
      return NextResponse.json({ success: false, error: 'يجب كتابة تعليق', code: statusToCode(400) }, { status: 400 })
    }

    await logAudit(admin.id, AuditActions.REPORT_COMMENT, type || 'ARTICLE', id, {
      moderatorComment: comment,
    })

    return NextResponse.json({ message: 'تم إضافة التعليق' })
  } catch (error) {
    return handleApiError(error)
  }
}
