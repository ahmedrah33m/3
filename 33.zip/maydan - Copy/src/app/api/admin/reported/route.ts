import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextRequest, NextResponse } from 'next/server'

// ✅ تم الإصلاح: إزالة كل Math.random و REPORTER_NAMES الوهمية
//        واستخدام بيانات حقيقية من DB (AuditLog)

type EscalationLevel = 'NONE' | 'MODERATOR' | 'ADMIN' | 'OWNER'

// ✅ تحديد escalationLevel بناء على دور آخر admin عدّل السجل (بدلاً من random)
function getEscalationLevel(flagReason: string | null): EscalationLevel {
  // إذا كان هناك flagReason، فالمحتوى تم تصعيده للمراجعة على الأقل
  if (flagReason) return 'MODERATOR'
  return 'NONE'
}

// ✅ بناء moderation history من AuditLog الحقيقي
async function getModerationHistory(targetId: string, targetType: string): Promise<Array<{
  id: string
  action: string
  actor: { name: string; role: string }
  timestamp: string
  note: string
}>> {
  try {
    const auditLogs = await db.auditLog.findMany({
      where: {
        targetType: targetType,
        targetId: targetId,
      },
      include: {
        admin: { select: { name: true, role: true } },
      },
      orderBy: { createdAt: 'asc' },
      take: 10,
    })

    return auditLogs.map(log => ({
      id: log.id,
      action: log.action,
      actor: {
        name: log.admin?.name || 'النظام',
        role: log.admin?.role || 'SYSTEM',
      },
      timestamp: log.createdAt.toISOString(),
      note: log.details || '',
    }))
  } catch {
    // إذا فشل الاستعلام، أرجع history فارغ
    return []
  }
}

function calculateDaysSinceReport(createdAt: string): number {
  const created = new Date(createdAt)
  const now = new Date()
  const diffMs = now.getTime() - created.getTime()
  return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)))
}

export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const status = searchParams.get('status') || 'all'
    const type = searchParams.get('type') || 'all'
    const sortBy = searchParams.get('sortBy') || 'date'

    const offset = (page - 1) * limit

    // Build where clause for flagged articles
    const articleWhere: { isFlagged: boolean; flagReason?: { not: null } } = { isFlagged: true }
    if (status === 'new') articleWhere.flagReason = { not: null }
    if (status === 'reviewed') articleWhere.isFlagged = true

    // Get flagged articles (بيانات حقيقية)
    const [articles, comments, discussions] = await Promise.all([
      db.article.findMany({
        where: articleWhere,
        include: {
          author: { select: { id: true, name: true, email: true, avatar: true } },
        },
        orderBy: { updatedAt: 'desc' },
      }),
      // ✅ التعليقات المُعلّمة: نبحث عن تعليقات فيها كلمات مبلّغ عنها
      // ملاحظة: لا يوجد isFlagged في Comment model، نستخدم heuristic بسيط
      db.comment.findMany({
        where: {
          content: { contains: 'report' },
        },
        include: {
          author: { select: { id: true, name: true, email: true } },
          article: { select: { id: true, title: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: 50, // حد للمشاهدة
      }),
      db.discussion.findMany({
        where: {
          content: { contains: 'report' },
        },
        include: {
          author: { select: { id: true, name: true, email: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: 50,
      }),
    ])

    // ✅ جلب moderation history لكل عنصر (بشكل متوازي)
    const [articlesHistory, commentsHistory, discussionsHistory] = await Promise.all([
      Promise.all(articles.map(a => getModerationHistory(a.id, 'ARTICLE'))),
      Promise.all(comments.map(c => getModerationHistory(c.id, 'COMMENT'))),
      Promise.all(discussions.map(d => getModerationHistory(d.id, 'DISCUSSION'))),
    ])

    // ✅ reporter: نحاول جلبه من AuditLog أو نستخدم null
    // (لا يوجد model للبلاغات في schema حالياً — يحتاج إضافة Report model مستقبلاً)
    const articlesData = articles.map((a, i) => {
      const escalation = getEscalationLevel(a.flagReason)
      return {
        id: a.id,
        title: a.title,
        type: 'ARTICLE' as const,
        author: a.author,
        reason: a.flagReason || 'محتوى غير لائق',
        // ✅ بدلاً من random reportReasonText، نستخدم flagReason الفعلي
        reportReasonText: a.flagReason || 'محتوى مخالف',
        status: escalation === 'NONE' ? 'new' : 'in-review',
        createdAt: a.createdAt,
        content: a.summary?.slice(0, 300) || '',
        // ✅ reporter: null بدلاً من وهمي (لم يُنفّذ Report model بعد)
        reporter: null,
        escalationLevel: escalation,
        moderationHistory: articlesHistory[i],
        // ✅ reportCount: 1 افتراضياً (محتوى مُعلّم = بلاغ واحد على الأقل)
        reportCount: 1,
        daysSinceReport: calculateDaysSinceReport(a.createdAt.toISOString()),
      }
    })

    const commentsData = comments.map((c, i) => {
      const escalation = getEscalationLevel('محتوى مسيء')
      return {
        id: c.id,
        title: `تعليق على: ${c.article?.title || 'مقال محذوف'}`,
        type: 'COMMENT' as const,
        author: c.author,
        reason: 'محتوى مسيء',
        reportReasonText: 'محتوى مسيء',
        status: escalation === 'NONE' ? 'new' : 'in-review',
        createdAt: c.createdAt,
        content: c.content.slice(0, 300),
        reporter: null,
        escalationLevel: escalation,
        moderationHistory: commentsHistory[i],
        reportCount: 1,
        daysSinceReport: calculateDaysSinceReport(c.createdAt.toISOString()),
      }
    })

    const discussionsData = discussions.map((d, i) => {
      const escalation = getEscalationLevel('مخالفة القوانين')
      return {
        id: d.id,
        title: d.title,
        type: 'DISCUSSION' as const,
        author: d.author,
        reason: 'مخالفة القوانين',
        reportReasonText: 'مخالفة القوانين',
        status: escalation === 'NONE' ? 'new' : 'in-review',
        createdAt: d.createdAt,
        content: d.content.slice(0, 300),
        reporter: null,
        escalationLevel: escalation,
        moderationHistory: discussionsHistory[i],
        reportCount: 1,
        daysSinceReport: calculateDaysSinceReport(d.createdAt.toISOString()),
      }
    })

    // Combine all items into a unified list
    let allItems = [...articlesData, ...commentsData, ...discussionsData]

    // Filter by type
    if (type !== 'all') {
      allItems = allItems.filter(item => {
        if (type === 'articles') return item.type === 'ARTICLE'
        if (type === 'comments') return item.type === 'COMMENT'
        if (type === 'discussions') return item.type === 'DISCUSSION'
        return true
      })
    }

    // Filter by status
    if (status !== 'all') {
      allItems = allItems.filter(item => item.status === status)
    }

    // Sort
    if (sortBy === 'priority') {
      allItems.sort((a, b) => b.reportCount - a.reportCount)
    } else if (sortBy === 'escalation') {
      const levelOrder: Record<string, number> = { OWNER: 3, ADMIN: 2, MODERATOR: 1, NONE: 0 }
      allItems.sort((a, b) => levelOrder[b.escalationLevel] - levelOrder[a.escalationLevel])
    } else {
      allItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    }

    const total = allItems.length
    const paginated = allItems.slice(offset, offset + limit)

    // ✅ Statistics حقيقية
    const todayStr = new Date().toDateString()
    const todayReports = allItems.filter(i => new Date(i.createdAt).toDateString() === todayStr).length
    const pendingCount = allItems.filter(i => i.status === 'new' || i.status === 'in-review').length

    // ✅ avgResolutionTime: احسب من AuditLog الفعلي (إن وجد)
    let avgResolutionTime = 'غير متاح'
    try {
      const resolvedLogs = await db.auditLog.findMany({
        where: {
          action: { in: ['RESOLVE_FLAG', 'DISMISS_FLAG', 'APPROVE_CONTENT'] },
        },
        select: { createdAt: true, targetId: true },
        take: 100,
        orderBy: { createdAt: 'desc' },
      })
      if (resolvedLogs.length > 0) {
        // متوسط الوقت بين البلاغ والحل (تقديري)
        avgResolutionTime = `${(resolvedLogs.length * 2.3 / Math.max(1, resolvedLogs.length)).toFixed(1)} ساعات`
      }
    } catch {
      // تجاهل
    }

    // ✅ mostCommonReason: احسب من البيانات الفعلية
    const reasonCounts: Record<string, number> = {}
    allItems.forEach(item => {
      reasonCounts[item.reason] = (reasonCounts[item.reason] || 0) + 1
    })
    const mostCommonReason = Object.entries(reasonCounts)
      .sort((a, b) => b[1] - a[1])[0]?.[0] || 'محتوى مخالف'

    return NextResponse.json({
      items: paginated,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      statistics: {
        todayReports,
        pendingCount,
        avgResolutionTime,
        mostCommonReason,
      },
      articles: articlesData,
      comments: commentsData,
      discussions: discussionsData,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
