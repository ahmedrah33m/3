import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireOwner } from '@/lib/session'
import { logSystemError } from '@/lib/logger'
import { statusToCode } from '@/lib/api-utils'

// ── GET: List system errors with pagination and filters ──
export async function GET(request: NextRequest) {
  try {
    await requireOwner()

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || undefined
    const severity = searchParams.get('severity') || undefined
    const resolved = searchParams.get('resolved')
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)))
    const skip = (page - 1) * limit

    const where: Record<string, unknown> = {}
    if (type) where.type = type
    if (severity) where.severity = severity
    if (resolved !== null && resolved !== '') {
      where.resolved = resolved === 'true'
    }

    const [errors, total] = await Promise.all([
      db.systemError.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.systemError.count({ where }),
    ])

    // ── Counts by severity ──
    const countsBySeverityRaw = await db.systemError.groupBy({
      by: ['severity'],
      _count: { id: true },
      where: { resolved: false },
    })
    const countsBySeverity: Record<string, number> = {}
    for (const row of countsBySeverityRaw) {
      countsBySeverity[row.severity] = row._count.id
    }

    // ── Counts by type ──
    const countsByTypeRaw = await db.systemError.groupBy({
      by: ['type'],
      _count: { id: true },
      where: { resolved: false },
    })
    const countsByType: Record<string, number> = {}
    for (const row of countsByTypeRaw) {
      countsByType[row.type] = row._count.id
    }

    return NextResponse.json({
      errors,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      countsBySeverity,
      countsByType,
    })
  } catch (error) {
    console.error('Errors GET error:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch errors', code: statusToCode(500) }, { status: 500 })
  }
}

// ── POST: Log a new error from client side ──
export async function POST(request: NextRequest) {
  try {
    const user = await requireOwner()

    const body = await request.json()
    const { type, message, stack, url, statusCode } = body

    if (!type || !message) {
      return NextResponse.json({ success: false, error: 'type and message are required', code: statusToCode(400) }, { status: 400 })
    }

    const severity = typeof body.severity === 'string' ? body.severity : 'medium'

    const errorRecord = await db.systemError.create({
      data: {
        type,
        severity,
        message,
        stack: stack || null,
        url: url || null,
        statusCode: statusCode || null,
        userId: user.id,
        userAgent: request.headers.get('user-agent') || null,
        ipAddress: request.headers.get('x-forwarded-for') || null,
      },
    })

    return NextResponse.json({ id: errorRecord.id }, { status: 201 })
  } catch (error) {
    console.error('Error POST error:', error)
    return NextResponse.json({ success: false, error: 'Failed to log error', code: statusToCode(500) }, { status: 500 })
  }
}

// ── PATCH: Resolve errors ──
export async function PATCH(request: NextRequest) {
  try {
    const user = await requireOwner()

    const body = await request.json()
    const { id, resolveAll, type } = body

    if (id) {
      // ── Resolve a single error ──
      const existing = await db.systemError.findUnique({ where: { id } })
      if (!existing) {
        return NextResponse.json({ success: false, error: 'Error not found', code: statusToCode(404) }, { status: 404 })
      }

      await db.systemError.update({
        where: { id },
        data: {
          resolved: true,
          resolvedAt: new Date(),
          resolvedBy: user.id,
        },
      })

      return NextResponse.json({ resolved: 1 })
    }

    if (resolveAll) {
      // ── Resolve all errors, optionally filtered by type ──
      const where: Record<string, unknown> = { resolved: false }
      if (type) where.type = type

      const result = await db.systemError.updateMany({
        where,
        data: {
          resolved: true,
          resolvedAt: new Date(),
          resolvedBy: user.id,
        },
      })

      return NextResponse.json({ resolved: result.count })
    }

    return NextResponse.json({ success: false, error: 'Provide either id or resolveAll', code: statusToCode(400) }, { status: 400 })
  } catch (error) {
    console.error('Error PATCH error:', error)
    await logSystemError({
      type: 'api_error',
      message: 'Failed to resolve errors',
      severity: 'medium',
      metadata: { error: String(error) },
    })
    return NextResponse.json({ success: false, error: 'Failed to resolve errors', code: statusToCode(500) }, { status: 500 })
  }
}
