import { db } from '@/lib/db'
import { requireAdmin, requireOwner, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'

// GET - Load settings
export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    let settings = await db.siteSettings.findUnique({ where: { id: 'main' } })
    if (!settings) {
      settings = await db.siteSettings.create({ data: {} })
    }

    return NextResponse.json({ settings })
  } catch (error) {
    return handleApiError(error)
  }
}

// PUT - Save settings (OWNER only)
export async function PUT(request: NextRequest) {
  try {
    const admin = await requireOwner()

    const body = await request.json()

    const settings = await db.siteSettings.upsert({
      where: { id: 'main' },
      update: {
        siteName: body.siteName,
        siteDescription: body.siteDescription,
        registrationEnabled: body.registrationEnabled,
        maintenanceMode: body.maintenanceMode,
      },
      create: {
        siteName: body.siteName || 'ميدان الاقتصاد',
        siteDescription: body.siteDescription || 'المرجع الاقتصادي العراقي',
        registrationEnabled: body.registrationEnabled ?? true,
        maintenanceMode: body.maintenanceMode ?? false,
      },
    })

    await logAudit(admin.id, AuditActions.SETTINGS_UPDATE, TargetTypes.SETTING, 'main', body)

    return NextResponse.json({ settings })
  } catch (error) {
    return handleApiError(error)
  }
}
