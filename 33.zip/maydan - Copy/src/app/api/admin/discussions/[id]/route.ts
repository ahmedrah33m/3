import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()

    const { id } = await params

    const discussion = await db.discussion.findUnique({ where: { id } })
    if (!discussion) {
      return NextResponse.json({ success: false, error: 'النقاش غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    // Delete replies first
    await db.discussionReply.deleteMany({ where: { discussionId: id } })
    await db.discussion.delete({ where: { id } })

    await logAudit(admin.id, AuditActions.DISCUSSION_DELETE, TargetTypes.DISCUSSION, id, { title: discussion.title })

    return NextResponse.json({ message: 'تم حذف النقاش بنجاح' })
  } catch (error) {
    return handleApiError(error)
  }
}
