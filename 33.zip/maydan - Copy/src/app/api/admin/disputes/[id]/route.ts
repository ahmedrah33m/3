import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse, validationError } from '@/lib/api-utils'
import { resolveDispute, type DisputeDecision } from '@/services/dispute.service'

const DECISIONS: DisputeDecision[] = [
  'RELEASE_TO_PROVIDER',
  'REFUND_BUYER',
  'PARTIAL_REFUND',
  'DISMISS',
  'WARNING',
  'BAN',
  'OTHER',
]

// PUT /api/admin/disputes/[id] — قرار الإدارة + الإجراء المالي
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireAdmin()
    const { id } = await params
    const body = await req.json()
    const { decision, buyerAmount, sellerAmount, note } = body

    if (!DECISIONS.includes(decision)) return validationError('decision', 'قرار غير صالح')

    const result = await resolveDispute({
      disputeId: id,
      adminId: admin.id,
      decision,
      buyerAmount: buyerAmount ? Number(buyerAmount) : undefined,
      sellerAmount: sellerAmount ? Number(sellerAmount) : undefined,
      note: note ? String(note) : undefined,
    })

    if (!result.success) return validationError('decision', result.error || 'فشل حل النزاع')
    return successResponse({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
