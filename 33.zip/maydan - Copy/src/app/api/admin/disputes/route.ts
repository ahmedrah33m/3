import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { listDisputes } from '@/services/dispute.service'

// GET /api/admin/disputes — كل النزاعات (للإدارة)
export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') as any
    const status = searchParams.get('status')
    const disputes = await listDisputes({ category: category || undefined, status: status || undefined })
    return successResponse({ disputes })
  } catch (error) {
    return handleApiError(error)
  }
}
