import { NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { listSectionsForReview } from '@/services/professional-passport.service'

// GET /api/admin/professional-passport/sections — admin review queue
export async function GET(request: Request) {
  try {
    await requireAdmin()
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') as 'VERIFIED' | 'PENDING' | 'UNVERIFIED' | null
    const sections = await listSectionsForReview(
      status === 'VERIFIED' || status === 'PENDING' || status === 'UNVERIFIED' ? status : undefined,
    )
    return NextResponse.json({ sections })
  } catch (error) {
    return handleApiError(error)
  }
}
