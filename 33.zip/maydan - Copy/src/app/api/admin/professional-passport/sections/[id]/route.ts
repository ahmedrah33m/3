import { NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { reviewSection } from '@/services/professional-passport.service'

// PATCH /api/admin/professional-passport/sections/[id] — admin sets VERIFIED / UNVERIFIED
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const admin = await requireAdmin()
    const { id: sectionId } = await params
    const body = await request.json()
    const { status } = body
    if (!['VERIFIED', 'UNVERIFIED'].includes(status)) {
      return NextResponse.json(
        { error: 'الحالة يجب أن تكون VERIFIED أو UNVERIFIED' },
        { status: 400 },
      )
    }
    await reviewSection(sectionId, status, admin.id)
    return NextResponse.json({ status })
  } catch (error) {
    return handleApiError(error)
  }
}
