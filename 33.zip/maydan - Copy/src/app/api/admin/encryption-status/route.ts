import { NextResponse } from 'next/server'
import { requireOwnerOrAdmin, AuthError } from '@/lib/session'
import { encrypt, decrypt, getEncryptionKey } from '@/lib/encryption'
import { encryptField, decryptField, encryptionExtension } from '@/lib/encrypted-fields'
import { statusToCode } from '@/lib/api-utils'

// GET /api/admin/encryption-status - Verify encryption is working
export async function GET() {
  try {
    await requireOwnerOrAdmin()

    const testText = 'مرحباً بكم في ميدان الاقتصاد - 2024'
    const key = getEncryptionKey()

    // Test encryption/decryption
    const encrypted = encrypt(testText, key)
    const decrypted = decrypt(encrypted, key)

    // Test field helpers
    const encryptedField = encryptField(testText, key)
    const decryptedField = decryptField(encryptedField, key)

    const isWorking = decrypted === testText && decryptedField === testText

    // Check middleware is registered
    const middlewareActive = typeof encryptionExtension === 'object'

    return NextResponse.json({
      status: isWorking ? 'ok' : 'error',
      encryptionEnabled: true,
      middlewareActive,
      encryptedFields: {
        User: ['phone', 'twoFactorSecret'],
        PaymentDestination: ['mastercardNumber', 'mastercardHolder', 'mastercardExpiry', 'zainCashNumber', 'zainCashHolder', 'qiCardNumber', 'qiCardHolder', 'fastPayNumber', 'fastPayHolder', 'bankAccountNumber', 'bankAccountHolder', 'bankIban'],
        WithdrawalRequest: ['accountDetails'],
      },
      keyLength: key.length,
      testResult: {
        original: testText,
        encrypted: encrypted ? '***' : 'FAILED',
        decrypted,
        fieldEncrypted: encryptedField ? '***' : 'FAILED',
        fieldDecrypted: decryptedField,
        match: isWorking,
      },
    })
  } catch (error) {
    if (error instanceof AuthError) {
      return NextResponse.json({ success: false, error: error.message, code: statusToCode(error.statusCode) }, { status: error.statusCode })
    }
    return NextResponse.json({ success: false, error: 'حدث خطأ', code: statusToCode(500) }, { status: 500 })
  }
}
