import { db } from '@/lib/db'
import { requireOwnerOrAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { blacklistAllUserTokens } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireOwnerOrAdmin()

    const { id } = await params

    const body = await request.json()
    const { role } = body

    const validRoles = ['USER', 'EXPERT', 'MODERATOR', 'ADMIN']
    if (!validRoles.includes(role)) {
      return NextResponse.json({ success: false, error: 'دور غير صالح', code: statusToCode(400) }, { status: 400 })
    }

    const targetUser = await db.user.findUnique({ where: { id } })
    if (!targetUser) {
      return NextResponse.json({ success: false, error: 'المستخدم غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    // Prevent changing OWNER role
    if (targetUser.role === 'OWNER') {
      return NextResponse.json({ success: false, error: 'لا يمكن تغيير دور مالك المنصة', code: statusToCode(403) }, { status: 403 })
    }

    const updated = await db.user.update({
      where: { id },
      data: { role },
    })

    await logAudit(admin.id, AuditActions.ROLE_CHANGE, TargetTypes.USER, id, { from: targetUser.role, to: role, userName: targetUser.name })

    // SEC-2 FIX: Invalidate all active sessions for the user so they must re-login with the new role.
    // Fire-and-forget — don't block the admin response.
    blacklistAllUserTokens(id).catch((err) => {
      console.error('[role-change] Failed to blacklist user tokens:', err)
    })

    const { password: _, verificationCode: __, ...userWithoutSensitive } = updated
    return NextResponse.json({
      message: 'تم تغيير الدور بنجاح',
      user: userWithoutSensitive,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
