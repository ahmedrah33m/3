import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { blacklistAllUserTokens } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()

    const { id } = await params

    const body = await request.json()
    const { isBanned, banReason } = body

    const targetUser = await db.user.findUnique({ where: { id } })
    if (!targetUser) {
      return NextResponse.json({ success: false, error: 'المستخدم غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    // Prevent banning owners
    if (targetUser.role === 'OWNER') {
      return NextResponse.json({ success: false, error: 'لا يمكن حظر مالك المنصة', code: statusToCode(403) }, { status: 403 })
    }

    const updated = await db.user.update({
      where: { id },
      data: {
        isBanned: !!isBanned,
        banReason: isBanned ? (banReason || 'انتهكت شروط الاستخدام') : null,
        bannedAt: isBanned ? new Date() : null,
      },
    })

    await logAudit(admin.id, isBanned ? AuditActions.USER_BAN : AuditActions.USER_UNBAN, TargetTypes.USER, id, { banReason, userName: targetUser.name })

    // SEC-2 FIX: Invalidate all active sessions for the user so they cannot keep using the platform after being banned (or after being unbanned with a fresh session).
    // This runs fire-and-forget so it doesn't block the admin response.
    blacklistAllUserTokens(id).catch((err) => {
      // Don't fail the request if blacklist fails — the ban record itself is already saved.
      console.error('[ban] Failed to blacklist user tokens:', err)
    })

    const { password: _, verificationCode: __, ...userWithoutSensitive } = updated
    return NextResponse.json({
      message: isBanned ? 'تم حظر المستخدم' : 'تم إلغاء حظر المستخدم',
      user: userWithoutSensitive,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
