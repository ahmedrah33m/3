import { db } from '@/lib/db'
import { requireOwnerOrAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

// DELETE /api/admin/users/[id] — Permanently delete a user (OWNER/ADMIN only)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireOwnerOrAdmin()

    const { id } = await params

    // Prevent self-deletion
    if (id === admin.id) {
      return NextResponse.json({ success: false, error: 'لا يمكنك حذف حسابك الخاص', code: statusToCode(403) }, { status: 403 })
    }

    const targetUser = await db.user.findUnique({ where: { id } })
    if (!targetUser) {
      return NextResponse.json({ success: false, error: 'المستخدم غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    // Prevent deleting OWNER accounts
    if (targetUser.role === 'OWNER') {
      return NextResponse.json({ success: false, error: 'لا يمكن حذف مالك المنصة', code: statusToCode(403) }, { status: 403 })
    }

    // Anonymize the user instead of hard delete to preserve referential integrity
    // (articles, comments, likes reference this user — deleting would cascade-delete content)
    // We soft-delete: mark as banned + anonymize PII
    await db.user.update({
      where: { id },
      data: {
        email: `deleted_${id}@removed.local`,
        password: null,
        name: 'حساب محذوف',
        phone: null,
        bio: null,
        avatar: null,
        avatarBlurhash: null,
        coverImage: null,
        coverBlurhash: null,
        jobTitle: null,
        organization: null,
        location: null,
        website: null,
        isVerified: false,
        verificationDocument: null,
        isBanned: true,
        banReason: 'تم حذف الحساب من قبل الإدارة',
        bannedAt: new Date(),
        twoFactorEnabled: false,
        twoFactorSecret: null,
        verificationCode: null,
        verificationCodeExpiry: null,
        resumeData: undefined,
        resumeFile: null,
        // Keep counters for historical accuracy
      },
    })

    // Log audit
    await logAudit(admin.id, AuditActions.USER_BAN, TargetTypes.USER, id, {
      action: 'USER_DELETED',
      userEmail: targetUser.email,
      userName: targetUser.name,
    })

    return NextResponse.json({
      message: 'تم حذف المستخدم بنجاح',
      userId: id,
    })
  } catch (error) {
    return handleApiError(error)
  }
}