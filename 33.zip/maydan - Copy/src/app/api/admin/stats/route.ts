import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextRequest, NextResponse } from 'next/server'
import { cache, CACHE_TTL } from '@/lib/cache'

// GET - Platform statistics for admin dashboard
export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    // Check cache first (5 min TTL for admin stats)
    const cached = await cache.get('admin:stats')
    if (cached) {
      return NextResponse.json(cached)
    }

    // ── Date boundaries ──
    const now = new Date()
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000)
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

    // ── Run all independent queries in parallel ──
    const [
      totalUsers,
      totalArticles,
      totalDiscussions,
      totalComments,
      viewSum,
      likeSum,
      newUsersThisMonth,
      newUsersLastMonth,
      newArticlesThisMonth,
      newArticlesLastMonth,
      articlesByCategory,
      topViewedArticles,
      usersByRole,
      topActiveUsers,
      totalConnections,
      totalFollows,
      totalMessages,
      recentArticleAuthors,
      recentDiscussionAuthors,
      recentCommentAuthors,
    ] = await Promise.all([
      // ── 1. Totals ──
      db.user.count(),
      db.article.count(),
      db.discussion.count(),
      db.comment.count(),
      db.article.aggregate({ _sum: { viewCount: true } }),
      db.article.aggregate({ _sum: { likeCount: true } }),

      // ── 2. Growth metrics ──
      db.user.count({ where: { createdAt: { gte: thirtyDaysAgo } } }),
      db.user.count({ where: { createdAt: { gte: sixtyDaysAgo, lt: thirtyDaysAgo } } }),
      db.article.count({ where: { createdAt: { gte: thirtyDaysAgo } } }),
      db.article.count({ where: { createdAt: { gte: sixtyDaysAgo, lt: thirtyDaysAgo } } }),

      // ── 3. Content breakdown ──
      db.article.groupBy({
        by: ['category'],
        _count: { category: true },
      }),
      db.article.findMany({
        orderBy: { viewCount: 'desc' },
        take: 5,
        select: {
          id: true,
          title: true,
          viewCount: true,
          likeCount: true,
          coverImage: true,
        },
      }),

      // ── 4. User breakdown ──
      db.user.groupBy({
        by: ['role'],
        _count: { role: true },
      }),
      db.user.findMany({
        orderBy: { articlesCount: 'desc' },
        take: 5,
        select: {
          id: true,
          name: true,
          avatar: true,
          articlesCount: true,
          role: true,
        },
      }),

      // ── 5. Engagement ──
      db.connection.count(),
      db.follow.count(),
      db.message.count(),

      // Active users this week (users who created content in last 7 days)
      db.article.findMany({
        where: { createdAt: { gte: sevenDaysAgo } },
        select: { authorId: true },
        distinct: ['authorId'],
      }),
      db.discussion.findMany({
        where: { createdAt: { gte: sevenDaysAgo } },
        select: { authorId: true },
        distinct: ['authorId'],
      }),
      db.comment.findMany({
        where: { createdAt: { gte: sevenDaysAgo } },
        select: { authorId: true },
        distinct: ['authorId'],
      }),
    ])

    // ── Calculate derived values ──
    const totalViews = viewSum._sum.viewCount ?? 0
    const totalLikes = likeSum._sum.likeCount ?? 0

    // Growth percentages (guard against division by zero)
    const userGrowthPercent =
      newUsersLastMonth > 0
        ? Math.round(
            ((newUsersThisMonth - newUsersLastMonth) / newUsersLastMonth) * 100
          )
        : newUsersThisMonth > 0
          ? 100
          : 0

    const articleGrowthPercent =
      newArticlesLastMonth > 0
        ? Math.round(
            ((newArticlesThisMonth - newArticlesLastMonth) /
              newArticlesLastMonth) *
              100
          )
        : newArticlesThisMonth > 0
          ? 100
          : 0

    // Active users this week: unique authorIds across articles, discussions, and comments
    const activeUserIds = new Set<string>()
    recentArticleAuthors.forEach((a: any) => activeUserIds.add(a.authorId))
    recentDiscussionAuthors.forEach((d: any) => activeUserIds.add(d.authorId))
    recentCommentAuthors.forEach((c: any) => activeUserIds.add(c.authorId))
    const activeUsersThisWeek = activeUserIds.size

    // ── Transform groupBy results into cleaner objects ──
    const articlesByCategoryMap = Object.fromEntries(
      articlesByCategory.map((item: any) => [
        item.category,
        item._count.category,
      ])
    )

    const usersByRoleMap = Object.fromEntries(
      usersByRole.map((item: any) => [item.role, item._count.role])
    )

    // ── Response ──
    const stats = {
      // 1. Totals
      totalUsers,
      totalArticles,
      totalDiscussions,
      totalComments,
      totalViews,
      totalLikes,

      // 2. Growth metrics
      newUsersThisMonth,
      newUsersLastMonth,
      newArticlesThisMonth,
      newArticlesLastMonth,
      userGrowthPercent,
      articleGrowthPercent,

      // 3. Content breakdown
      articlesByCategory: articlesByCategoryMap,
      topViewedArticles,

      // 4. User breakdown
      usersByRole: usersByRoleMap,
      topActiveUsers,

      // 5. Engagement
      totalConnections,
      totalFollows,
      totalMessages,
      activeUsersThisWeek,
    }

    // Cache for 5 minutes
    await cache.set('admin:stats', stats, CACHE_TTL.MEDIUM)

    return NextResponse.json(stats)
  } catch (error) {
    return handleApiError(error)
  }
}
