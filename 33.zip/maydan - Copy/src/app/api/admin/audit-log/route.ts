import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')
    const action = searchParams.get('action')
    const targetType = searchParams.get('targetType')
    const adminId = searchParams.get('adminId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    const where: any = {}
    if (action) where.action = action
    if (targetType) where.targetType = targetType
    if (adminId) where.adminId = adminId
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) where.createdAt.gte = new Date(startDate)
      if (endDate) where.createdAt.lte = new Date(endDate)
    }

    const [logs, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        include: {
          admin: { select: { id: true, name: true, email: true, avatar: true } },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: (page - 1) * limit,
      }),
      db.auditLog.count({ where }),
    ])

    return NextResponse.json({
      logs: logs.map((log: any) => ({
        id: log.id,
        admin: log.admin,
        action: log.action,
        targetType: log.targetType,
        targetId: log.targetId,
        details: log.details ? JSON.parse(log.details) : null,
        ipAddress: log.ipAddress,
        createdAt: log.createdAt,
      })),
      pagination: { page, limit, total },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
