import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { seedIraqEconomicData } from '@/services/economic.service'

// POST /api/admin/economic/seed — بذر بيانات افتراضية للاقتصاد العراقي + قواعد التنبيهات
export async function POST(req: NextRequest) {
  try {
    await requireAdmin()
    const result = await seedIraqEconomicData()
    return successResponse(result)
  } catch (error) {
    return handleApiError(error)
  }
}
