import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { generateDailyPulse } from '@/services/economic.service'

// POST /api/admin/economic/pulse — إعادة توليد لقطة النبض الاقتصادي
export async function POST(req: NextRequest) {
  try {
    await requireAdmin()
    const pulse = await generateDailyPulse()
    return successResponse({ pulse })
  } catch (error) {
    return handleApiError(error)
  }
}
