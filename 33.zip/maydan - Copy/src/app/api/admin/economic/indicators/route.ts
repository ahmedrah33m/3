import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse, validationError } from '@/lib/api-utils'
import { recordIndicator, getLatestIndicators, seedIraqEconomicData } from '@/services/economic.service'

// GET /api/admin/economic/indicators — عرض المؤشرات
export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const { searchParams } = new URL(req.url)
    const category = (searchParams.get('category') as any) || undefined
    const data = await getLatestIndicators(category)
    return successResponse(data)
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/admin/economic/indicators — تسجيل قيمة مؤشر (يولّد التنبيهات عند تجاوز الحد)
export async function POST(req: NextRequest) {
  try {
    await requireAdmin()
    const body = await req.json()
    const { category, name, value, unit, currency, period, source } = body
    if (!category || value === undefined || value === null) return validationError('category', 'التصنيف والقيمة مطلوبان')
    const indicator = await recordIndicator({
      category,
      name: name || category,
      value: Number(value),
      unit,
      currency,
      period: period ? new Date(period) : undefined,
      source,
    })
    return successResponse({ indicator }, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
