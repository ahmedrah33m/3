import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse, validationError } from '@/lib/api-utils'
import { updateAlertRule, deleteAlertRule } from '@/services/economic.service'

// PUT /api/admin/economic/alert-rules/[id] — تعديل قاعدة
export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin()
    const { id } = await params
    const body = await req.json()
    const rule = await updateAlertRule(id, {
      label: body.label,
      thresholdPct: body.thresholdPct !== undefined ? Number(body.thresholdPct) : undefined,
      direction: body.direction,
      enabled: body.enabled !== undefined ? Boolean(body.enabled) : undefined,
    })
    return successResponse({ rule })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE /api/admin/economic/alert-rules/[id] — حذف قاعدة
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin()
    const { id } = await params
    await deleteAlertRule(id)
    return successResponse({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
