import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse, validationError } from '@/lib/api-utils'
import { getAlertRules, createAlertRule, updateAlertRule, deleteAlertRule } from '@/services/economic.service'

// GET /api/admin/economic/alert-rules — قواعد التنبيهات
export async function GET(req: NextRequest) {
  try {
    await requireAdmin()
    const rules = await getAlertRules()
    return successResponse({ rules })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/admin/economic/alert-rules — إضافة قاعدة
export async function POST(req: NextRequest) {
  try {
    await requireAdmin()
    const body = await req.json()
    const { indicatorCategory, label, thresholdPct, direction } = body
    if (!indicatorCategory || !label) return validationError('indicatorCategory', 'التصنيف والوصف مطلوبان')
    const rule = await createAlertRule({
      indicatorCategory,
      label: String(label),
      thresholdPct: Number(thresholdPct ?? 2),
      direction: direction || 'ANY',
    })
    return successResponse({ rule }, 201)
  } catch (error) {
    return handleApiError(error)
  }
}
