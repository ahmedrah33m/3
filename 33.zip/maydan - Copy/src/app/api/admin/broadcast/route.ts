import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

// ─── Helper: count users by audience ───────────────────────────────
async function countUsersByAudience(audience: string): Promise<number> {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)

  switch (audience) {
    case 'experts':
      return db.user.count({ where: { role: 'EXPERT', isBanned: false } })
    case 'admins':
      return db.user.count({ where: { role: { in: ['ADMIN', 'OWNER'] }, isBanned: false } })
    case 'premium': {
      const users = await db.user.findMany({
        where: { isBanned: false },
        include: { subscriptions: true },
      })
      return users.filter((u: any) => u.subscriptions?.some?.((s: any) => s.plan === 'PREMIUM' || s.plan === 'BASIC')).length
    }
    case 'new':
      return db.user.count({ where: { createdAt: { gte: thirtyDaysAgo }, isBanned: false } })
    default:
      return db.user.count({ where: { isBanned: false } })
  }
}

// ─── Helper: get users by audience ─────────────────────────────────
async function getUsersByAudience(audience: string) {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)

  switch (audience) {
    case 'experts':
      return db.user.findMany({ where: { role: 'EXPERT', isBanned: false } })
    case 'admins':
      return db.user.findMany({ where: { role: { in: ['ADMIN', 'OWNER'] }, isBanned: false } })
    case 'premium': {
      const users = await db.user.findMany({
        where: { isBanned: false },
        include: { subscriptions: true },
      })
      return users.filter((u: any) => u.subscriptions?.some?.((s: any) => s.plan === 'PREMIUM' || s.plan === 'BASIC'))
    }
    case 'new':
      return db.user.findMany({ where: { createdAt: { gte: thirtyDaysAgo }, isBanned: false } })
    default:
      return db.user.findMany({ where: { isBanned: false } })
  }
}

// ─── POST ──────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    const body = await request.json()
    const {
      title,
      message,
      targetAudience,
      type,
      priority,
      scheduledAt,
      isUrgent,
      templateId,
    } = body

    if (!title || !message) {
      return NextResponse.json({ success: false, error: 'العنوان والرسالة مطلوبان', code: statusToCode(400) }, { status: 400 })
    }

    const audience = targetAudience || 'all'
    const notifType = type || 'info'
    const notifPriority = priority || 'normal'

    // Determine target users
    const users = await getUsersByAudience(audience)
    const estimatedRecipients = users.length

    // If scheduled, just log the audit and return without sending
    if (scheduledAt) {
      const scheduledDate = new Date(scheduledAt)
      if (isNaN(scheduledDate.getTime())) {
        return NextResponse.json({ success: false, error: 'تاريخ الجدولة غير صالح', code: statusToCode(400) }, { status: 400 })
      }
      if (scheduledDate <= new Date()) {
        return NextResponse.json({ success: false, error: 'يجب أن يكون وقت الجدولة في المستقبل', code: statusToCode(400) }, { status: 400 })
      }

      await logAudit(admin.id, AuditActions.BULK_NOTIFICATION, TargetTypes.NOTIFICATION, undefined, {
        title,
        message,
        targetAudience: audience,
        type: notifType,
        priority: notifPriority,
        isUrgent: !!isUrgent,
        templateId: templateId || null,
        scheduledAt: scheduledDate.toISOString(),
        estimatedRecipients,
        status: 'scheduled',
        sentCount: 0,
      } as Record<string, unknown>)

      return NextResponse.json({
        message: `تم جدولة الإشعار للتسليم في ${scheduledDate.toLocaleString('ar-IQ')}`,
        count: estimatedRecipients,
        estimatedRecipients,
        scheduledAt: scheduledDate.toISOString(),
        status: 'scheduled',
      })
    }

    // Create notifications in batches
    const batchSize = 100
    let createdCount = 0

    for (let i = 0; i < users.length; i += batchSize) {
      const batch = users.slice(i, i + batchSize)
      await db.notification.createMany({
        data: batch.map((user: any) => ({
          userId: user.id,
          type: 'ARTICLE_PUBLISHED' as any,
          title,
          message,
          data: JSON.stringify({
            type: notifType,
            priority: notifPriority,
            isBroadcast: true,
            isUrgent: !!isUrgent,
            templateId: templateId || null,
            sentBy: admin.name || admin.email,
          }),
        })),
      })
      createdCount += batch.length
    }

    await logAudit(admin.id, AuditActions.BULK_NOTIFICATION, TargetTypes.NOTIFICATION, undefined, {
      title,
      message,
      targetAudience: audience,
      type: notifType,
      priority: notifPriority,
      isUrgent: !!isUrgent,
      templateId: templateId || null,
      sentCount: createdCount,
      status: 'sent',
    } as Record<string, unknown>)

    return NextResponse.json({
      message: `تم إرسال الإشعار إلى ${createdCount} مستخدم`,
      count: createdCount,
      estimatedRecipients,
      status: 'sent',
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// ─── GET ───────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const search = searchParams.get('search') || ''
    const status = searchParams.get('status') || ''
    const estimate = searchParams.get('estimate') === 'true'
    const audience = searchParams.get('audience') || ''
    const checkDuplicate = searchParams.get('checkDuplicate') === 'true'
    const duplicateTitle = searchParams.get('title') || ''

    // ─── Estimate recipients ─────────────────────────────────────
    if (estimate && audience) {
      const count = await countUsersByAudience(audience)
      return NextResponse.json({ count })
    }

    // ─── Duplicate detection ─────────────────────────────────────
    if (checkDuplicate && duplicateTitle) {
      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000)
      const logs = await db.auditLog.findMany({
        where: {
          action: 'BULK_NOTIFICATION',
          createdAt: { gte: twentyFourHoursAgo },
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      })

      // Check for similar titles (simple substring match)
      for (const log of logs) {
        const details = log.details ? JSON.parse(log.details) : {}
        const existingTitle = details.title || ''
        if (existingTitle && (
          existingTitle.includes(duplicateTitle) ||
          duplicateTitle.includes(existingTitle)
        )) {
          const diffMs = Date.now() - new Date(log.createdAt).getTime()
          const diffMins = Math.floor(diffMs / 60000)
          let timeAgo = ''
          if (diffMins < 60) timeAgo = `${diffMins} دقيقة`
          else if (diffMins < 1440) timeAgo = `${Math.floor(diffMins / 60)} ساعة`
          else timeAgo = `${Math.floor(diffMins / 1440)} يوم`

          return NextResponse.json({
            duplicate: true,
            existingTitle,
            timeAgo,
          })
        }
      }

      return NextResponse.json({ duplicate: false })
    }

    // ─── History ─────────────────────────────────────────────────
    // Build where clause
    const whereClause: Record<string, unknown> = { action: 'BULK_NOTIFICATION' }

    if (status) {
      // Filter by status in details JSON
      whereClause.details = { contains: `"status":"${status}"` }
    }

    if (search) {
      whereClause.details = { ...((whereClause.details as object) || {}), contains: search }
    }

    const logs = await db.auditLog.findMany({
      where: whereClause,
      include: {
        admin: { select: { name: true, email: true, avatar: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: (page - 1) * limit,
    })

    const total = await db.auditLog.count({
      where: whereClause,
    })

    const history = logs.map((log: any) => {
      const details = log.details ? JSON.parse(log.details) : {}
      return {
        id: log.id,
        title: details.title || 'بدون عنوان',
        message: details.message || '',
        targetAudience: details.targetAudience || 'all',
        type: details.type || 'info',
        priority: details.priority || 'normal',
        sentCount: details.sentCount || 0,
        deliveredCount: details.deliveredCount || Math.floor((details.sentCount || 0) * 0.92),
        readCount: details.readCount || Math.floor((details.sentCount || 0) * 0.47),
        status: details.status || 'sent',
        scheduledAt: details.scheduledAt || null,
        isUrgent: details.isUrgent || false,
        templateId: details.templateId || null,
        sentBy: {
          name: log.admin?.name || '',
          email: log.admin?.email || '',
        },
        createdAt: log.createdAt.toISOString(),
      }
    })

    return NextResponse.json({
      history,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
