import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireOwner } from '@/lib/session'
import { logSystemError } from '@/lib/logger'
import { statusToCode } from '@/lib/api-utils'

// ── GET: List AI operation logs with filters and stats ──
export async function GET(request: NextRequest) {
  try {
    await requireOwner()

    const { searchParams } = new URL(request.url)
    const operation = searchParams.get('operation') || undefined
    const success = searchParams.get('success')
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)))
    const skip = (page - 1) * limit

    // Build where clause
    const where: Record<string, unknown> = {}
    if (operation) where.operation = operation
    if (success !== null && success !== '') {
      where.success = success === 'true'
    }

    const [logs, total] = await Promise.all([
      db.aIOperationLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.aIOperationLog.count({ where }),
    ])

    // ── Counts by operation type ──
    const countsByOperationRaw = await db.aIOperationLog.groupBy({
      by: ['operation'],
      _count: { id: true },
    })
    const countsByOperation: Record<string, number> = {}
    for (const row of countsByOperationRaw) {
      countsByOperation[row.operation] = row._count.id
    }

    // ── Success rate ──
    const [totalLogs, successLogs] = await Promise.all([
      db.aIOperationLog.count(),
      db.aIOperationLog.count({ where: { success: true } }),
    ])
    const successRate = totalLogs > 0
      ? Math.round((successLogs / totalLogs) * 10000) / 100 // percentage with 2 decimals
      : 0

    // ── Average duration ──
    const durationStats = await db.aIOperationLog.aggregate({
      _avg: { durationMs: true },
      _min: { durationMs: true },
      _max: { durationMs: true },
      where: { durationMs: { not: null } },
    })

    // ── Success rate by operation ──
    const operationStats: Record<string, { count: number; successRate: number; avgDuration: number | null }> = {}
    for (const row of countsByOperationRaw) {
      const op = row.operation
      const [opTotal, opSuccess, opAvg] = await Promise.all([
        db.aIOperationLog.count({ where: { operation: op } }),
        db.aIOperationLog.count({ where: { operation: op, success: true } }),
        db.aIOperationLog.aggregate({
          _avg: { durationMs: true },
          where: { operation: op, durationMs: { not: null } },
        }),
      ])
      operationStats[op] = {
        count: opTotal,
        successRate: opTotal > 0 ? Math.round((opSuccess / opTotal) * 10000) / 100 : 0,
        avgDuration: opAvg._avg.durationMs
          ? Math.round(opAvg._avg.durationMs)
          : null,
      }
    }

    return NextResponse.json({
      logs,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      countsByOperation,
      successRate,
      averageDuration: durationStats._avg.durationMs
        ? Math.round(durationStats._avg.durationMs)
        : null,
      minDuration: durationStats._min.durationMs,
      maxDuration: durationStats._max.durationMs,
      operationStats,
    })
  } catch (error) {
    console.error('AI Logs GET error:', error)
    await logSystemError({
      type: 'api_error',
      message: 'Failed to fetch AI logs',
      severity: 'high',
      metadata: { error: String(error) },
    })
    return NextResponse.json({ success: false, error: 'Failed to fetch AI logs', code: statusToCode(500) }, { status: 500 })
  }
}
