import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse, errorResponse } from '@/lib/api-utils'

// PUT /api/admin/ads/[id] — Update ad
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireAdmin()
    const { id } = await params
    const body = await request.json()
    const { title, description, imageUrl, linkUrl, position, targetCategory, endDate, isActive } = body

    const ad = await db.ad.update({
      where: { id },
      data: {
        ...(title !== undefined && { title }),
        ...(description !== undefined && { description: description || null }),
        ...(imageUrl !== undefined && { imageUrl: imageUrl || null }),
        ...(linkUrl !== undefined && { linkUrl }),
        ...(position !== undefined && { position }),
        ...(targetCategory !== undefined && { targetCategory: targetCategory || null }),
        ...(endDate !== undefined && { endDate: endDate ? new Date(endDate) : null }),
        ...(isActive !== undefined && { isActive }),
      },
    })

    return successResponse({ ad })
  } catch (error) {
    if (error && typeof error === 'object' && 'statusCode' in error) {
      return handleApiError(error)
    }
    console.error('Update ad error:', error)
    return errorResponse('Failed to update ad', 'INTERNAL_ERROR', 500)
  }
}

// DELETE /api/admin/ads/[id] — Delete ad
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireAdmin()
    const { id } = await params
    await db.ad.delete({ where: { id } })
    return successResponse({})
  } catch (error) {
    if (error && typeof error === 'object' && 'statusCode' in error) {
      return handleApiError(error)
    }
    console.error('Delete ad error:', error)
    return errorResponse('Failed to delete ad', 'INTERNAL_ERROR', 500)
  }
}