import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse, errorResponse } from '@/lib/api-utils'

// GET /api/admin/ads — List all ads (admin only)
export async function GET() {
  try {
    await requireAdmin()
    const ads = await db.ad.findMany({
      orderBy: { createdAt: 'desc' },
    })
    return successResponse({ ads })
  } catch (error) {
    if (error && typeof error === 'object' && 'statusCode' in error) {
      return handleApiError(error)
    }
    console.error('Admin ads list error:', error)
    return errorResponse('Failed to fetch ads', 'INTERNAL_ERROR', 500)
  }
}

// POST /api/admin/ads — Create new ad (admin only)
export async function POST(request: NextRequest) {
  try {
    const user = await requireAdmin()
    const body = await request.json()
    const { title, description, imageUrl, linkUrl, position, targetCategory, endDate, isActive } = body

    if (!title || !linkUrl) {
      return errorResponse('Title and link URL are required', 'VALIDATION_ERROR', 400)
    }

    const ad = await db.ad.create({
      data: {
        title,
        description: description || null,
        imageUrl: imageUrl || null,
        linkUrl,
        position: position || 'sidebar',
        targetCategory: targetCategory || null,
        endDate: endDate ? new Date(endDate) : null,
        isActive: isActive !== false,
        advertiserId: user.id,
      },
    })

    return successResponse({ ad }, 201)
  } catch (error) {
    if (error && typeof error === 'object' && 'statusCode' in error) {
      return handleApiError(error)
    }
    console.error('Create ad error:', error)
    return errorResponse('Failed to create ad', 'INTERNAL_ERROR', 500)
  }
}