import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { statusToCode } from '@/lib/api-utils'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()

    const { id } = await params
    const body = await request.json()
    const { isFlagged, flagReason } = body

    const article = await db.article.findUnique({ where: { id } })
    if (!article) {
      return NextResponse.json({ success: false, error: 'المقال غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    const updated = await db.article.update({
      where: { id },
      data: {
        isFlagged: !!isFlagged,
        flagReason: isFlagged ? (flagReason || 'محتوى مخالف') : null,
      },
    })

    await logAudit(admin.id, isFlagged ? AuditActions.ARTICLE_FLAG : AuditActions.ARTICLE_UNFLAG, TargetTypes.ARTICLE, id, { flagReason })

    return NextResponse.json({
      message: isFlagged ? 'تم الإبلاغ عن المقال' : 'تم إزالة الإبلاغ',
      article: updated,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
