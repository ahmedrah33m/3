import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()

    const { id } = await params

    const article = await db.article.findUnique({ where: { id } })
    if (!article) {
      return NextResponse.json({ success: false, error: 'المقال غير موجود', code: statusToCode(404) }, { status: 404 })
    }

    // Delete related comments and likes first
    await db.comment.deleteMany({ where: { articleId: id } })
    await db.like.deleteMany({ where: { articleId: id } })
    await db.article.delete({ where: { id } })

    // Update author article count
    await db.user.update({
      where: { id: article.authorId },
      data: { articlesCount: { decrement: 1 } },
    })

    await logAudit(admin.id, AuditActions.ARTICLE_DELETE, TargetTypes.ARTICLE, id, { title: article.title })

    return NextResponse.json({ message: 'تم حذف المقال بنجاح' })
  } catch (error) {
    return handleApiError(error)
  }
}
