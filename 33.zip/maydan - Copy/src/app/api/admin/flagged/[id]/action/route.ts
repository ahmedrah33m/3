import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const admin = await requireAdmin()
    const { id } = await params
    const body = await request.json()
    const { action, type } = body

    const contentType = type || 'article'
    const validActions = ['approve', 'delete', 'dismiss']
    if (!validActions.includes(action)) {
      return NextResponse.json({ success: false, error: 'إجراء غير صالح', code: statusToCode(400) }, { status: 400 })
    }

    const validTypes = ['article', 'comment', 'discussion']
    if (!validTypes.includes(contentType)) {
      return NextResponse.json({ success: false, error: 'نوع محتوى غير صالح', code: statusToCode(400) }, { status: 400 })
    }

    let targetTitle = ''

    if (contentType === 'article') {
      const article = await db.article.findUnique({ where: { id } })
      if (!article) {
        return NextResponse.json({ success: false, error: 'المقال غير موجود', code: statusToCode(404) }, { status: 404 })
      }
      targetTitle = article.title

      if (action === 'approve') {
        await db.article.update({
          where: { id },
          data: { isFlagged: false, flagReason: null },
        })
        await logAudit(admin.id, AuditActions.REPORT_APPROVE, TargetTypes.ARTICLE, id, {
          action: 'approve',
          title: article.title,
        })
        return NextResponse.json({ message: 'تمت الموافقة على المقال' })
      }

      if (action === 'dismiss') {
        await db.article.update({
          where: { id },
          data: { isFlagged: false, flagReason: null },
        })
        await logAudit(admin.id, AuditActions.REPORT_DISMISS, TargetTypes.ARTICLE, id, {
          action: 'dismiss',
          title: article.title,
        })
        return NextResponse.json({ message: 'تم تجاهل الإبلاغ' })
      }

      if (action === 'delete') {
        await db.comment.deleteMany({ where: { articleId: id } })
        await db.like.deleteMany({ where: { articleId: id } })
        await db.article.delete({ where: { id } })
        await db.user.update({
          where: { id: article.authorId },
          data: { articlesCount: { decrement: 1 } },
        })
        await logAudit(admin.id, AuditActions.REPORT_DELETE, TargetTypes.ARTICLE, id, {
          action: 'delete',
          title: article.title,
        })
        return NextResponse.json({ message: 'تم حذف المقال' })
      }
    }

    if (contentType === 'comment') {
      const comment = await db.comment.findUnique({ where: { id } })
      if (!comment) {
        return NextResponse.json({ success: false, error: 'التعليق غير موجود', code: statusToCode(404) }, { status: 404 })
      }
      targetTitle = `تعليق: ${comment.content.slice(0, 50)}`

      if (action === 'approve' || action === 'dismiss') {
        await logAudit(admin.id, action === 'approve' ? AuditActions.REPORT_APPROVE : AuditActions.REPORT_DISMISS, TargetTypes.COMMENT, id, {
          action,
          content: comment.content.slice(0, 100),
        })
        return NextResponse.json({ message: action === 'approve' ? 'تمت الموافقة على التعليق' : 'تم تجاهل الإبلاغ' })
      }

      if (action === 'delete') {
        await db.like.deleteMany({ where: { commentId: id } })
        await db.comment.delete({ where: { id } })
        await db.article.update({
          where: { id: comment.articleId },
          data: { commentCount: { decrement: 1 } },
        })
        await logAudit(admin.id, AuditActions.REPORT_DELETE, TargetTypes.COMMENT, id, {
          action: 'delete',
          content: comment.content.slice(0, 100),
        })
        return NextResponse.json({ message: 'تم حذف التعليق' })
      }
    }

    if (contentType === 'discussion') {
      const discussion = await db.discussion.findUnique({ where: { id } })
      if (!discussion) {
        return NextResponse.json({ success: false, error: 'النقاش غير موجود', code: statusToCode(404) }, { status: 404 })
      }
      targetTitle = discussion.title

      if (action === 'approve' || action === 'dismiss') {
        await logAudit(admin.id, action === 'approve' ? AuditActions.REPORT_APPROVE : AuditActions.REPORT_DISMISS, TargetTypes.DISCUSSION, id, {
          action,
          title: discussion.title,
        })
        return NextResponse.json({ message: action === 'approve' ? 'تمت الموافقة على النقاش' : 'تم تجاهل الإبلاغ' })
      }

      if (action === 'delete') {
        await db.discussionReply.deleteMany({ where: { discussionId: id } })
        await db.discussion.delete({ where: { id } })
        await logAudit(admin.id, AuditActions.REPORT_DELETE, TargetTypes.DISCUSSION, id, {
          action: 'delete',
          title: discussion.title,
        })
        return NextResponse.json({ message: 'تم حذف النقاش' })
      }
    }

    return NextResponse.json({ success: false, error: 'إجراء غير صالح', code: statusToCode(400) }, { status: 400 })
  } catch (error) {
    return handleApiError(error)
  }
}
