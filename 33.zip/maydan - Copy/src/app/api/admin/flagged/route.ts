import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextRequest, NextResponse } from 'next/server'

// ✅ تم الإصلاح: إزالة كل Math.random واستخدام بيانات حقيقية

// Simulated flagged keywords for highlighting (للتظليل البصري فقط — ليست بيانات)
const FLAGGED_KEYWORDS = [
  'غير لائق', 'محتوى مخالف', 'إساءة', 'تهديد',
  'تحرش', 'احتيال', 'نصب', 'غش', 'مخالف', 'إرهاب', 'عنف',
  'spam', 'scam',
]

// ✅ حساب aiScore بناء على نوع المخالفة (بدون Math.random)
function calculateAIScore(reason: string): number {
  const highConfidenceReasons = ['محتوى مخالف', 'إساءة', 'تهديد', 'إرهاب', 'عنف', 'احتيال']
  const medConfidenceReasons = ['محتوى مسيء', 'مخالفة القوانين', 'غير لائق', 'scam', 'spam']
  if (highConfidenceReasons.some(r => reason.includes(r))) return 90  // درجة ثابتة بدلاً من random
  if (medConfidenceReasons.some(r => reason.includes(r))) return 65
  return 40  // درجة افتراضية للمراجعة
}

function highlightContent(content: string): string {
  let result = content
  FLAGGED_KEYWORDS.forEach(keyword => {
    const regex = new RegExp(`(${keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
    result = result.replace(regex, '<mark class="bg-red-200 dark:bg-red-800 text-red-800 dark:text-red-200 px-0.5 rounded">$1</mark>')
  })
  return result
}

// ✅ جلب إحصائيات حقيقية للمؤلف من DB
async function getAuthorStats(authorId: string | null) {
  if (!authorId) return null
  const [totalArticles, previousViolations, user] = await Promise.all([
    db.article.count({ where: { authorId, isFlagged: true } }),
    db.article.count({ where: { authorId, isFlagged: true, flagReason: { not: null } } }),
    db.user.findUnique({ where: { id: authorId }, select: { createdAt: true } }),
  ])
  return {
    totalArticles,
    previousViolations,
    joinDate: user?.createdAt?.toISOString() || null,
  }
}

export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'all'
    const status = searchParams.get('status') || 'pending'
    const sortBy = searchParams.get('sortBy') || 'date'
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')

    const offset = (page - 1) * limit

    // Build the flagged content query
    const articleWhere: { isFlagged: boolean; flagReason?: { not: null } } = { isFlagged: true }
    if (status === 'reviewed') {
      articleWhere.flagReason = { not: null }
    }

    // Fetch flagged articles (بيانات حقيقية)
    const flaggedArticles = type === 'all' || type === 'article'
      ? await db.article.findMany({
          where: articleWhere,
          include: {
            author: { select: { id: true, name: true, email: true, avatar: true } },
          },
          orderBy: { updatedAt: 'desc' },
        })
      : []

    // Fetch flagged comments (لا توجد حالياً — تحتاج schema update)
    const flaggedComments: Array<{ id: string; content: string; createdAt: Date; updatedAt: Date; authorId: string; author?: { id: string; name: string | null; email: string; avatar?: string | null } | null; article?: { title: string } | null }> = []

    // Fetch flagged discussions (لا توجد حالياً — تحتاج schema update)
    const flaggedDiscussions: Array<{ id: string; title: string; content: string; createdAt: Date; updatedAt: Date; authorId: string; author?: { id: string; name: string | null; email: string; avatar?: string | null } | null }> = []

    // ✅ جلب authorStats حقيقية لكل مقال (بشكل متوازي)
    const articlesWithStats = await Promise.all(
      flaggedArticles.map(async (a) => ({
        article: a,
        authorStats: await getAuthorStats(a.authorId),
      }))
    )

    const items = [
      ...articlesWithStats.map(({ article: a, authorStats }) => ({
        id: a.id,
        title: a.title,
        content: a.summary?.slice(0, 200) || a.content?.slice(0, 200) || '',
        type: 'article' as const,
        status: a.flagReason ? 'reviewed' : 'pending',
        reason: a.flagReason || 'محتوى مخالف',
        author: a.author ? { id: a.author.id, name: a.author.name, email: a.author.email } : null,
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt.toISOString(),
        aiScore: calculateAIScore(a.flagReason || 'محتوى مخالف'),
        authorStats,
        highlightedContent: highlightContent(a.summary?.slice(0, 200) || a.content?.slice(0, 200) || ''),
        // ✅ similarItems: 0 بدلاً من Math.random (لم يُنفّذ بعد)
        similarItems: 0,
      })),
      ...flaggedComments.map(c => ({
        id: c.id,
        title: `تعليق على: ${c.article?.title || 'مقال محذوف'}`,
        content: c.content.slice(0, 200),
        type: 'comment' as const,
        status: 'pending' as const,
        reason: 'محتوى مسيء',
        author: c.author ? { id: c.author.id, name: c.author.name, email: c.author.email } : null,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.createdAt.toISOString(),
        aiScore: calculateAIScore('محتوى مسيء'),
        authorStats: null,
        highlightedContent: highlightContent(c.content.slice(0, 200)),
        similarItems: 0,
      })),
      ...flaggedDiscussions.map(d => ({
        id: d.id,
        title: d.title,
        content: d.content.slice(0, 200),
        type: 'discussion' as const,
        status: 'pending' as const,
        reason: 'مخالفة القوانين',
        author: d.author ? { id: d.author.id, name: d.author.name, email: d.author.email } : null,
        createdAt: d.createdAt.toISOString(),
        updatedAt: d.updatedAt.toISOString(),
        aiScore: calculateAIScore('مخالفة القوانين'),
        authorStats: null,
        highlightedContent: highlightContent(d.content.slice(0, 200)),
        similarItems: 0,
      })),
    ]

    // Filter by status if specified
    const filtered = status === 'all'
      ? items
      : items.filter(item => item.status === status)

    // Sort based on sortBy parameter
    if (sortBy === 'aiScore') {
      filtered.sort((a, b) => b.aiScore - a.aiScore)
    } else if (sortBy === 'type') {
      const typeOrder = { article: 0, comment: 1, discussion: 2 }
      filtered.sort((a, b) => typeOrder[a.type as keyof typeof typeOrder] - typeOrder[b.type as keyof typeof typeOrder])
    } else {
      filtered.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    }

    const total = filtered.length
    const paginated = filtered.slice(offset, offset + limit)

    // ✅ Stats حقيقية: عدد المقالات المُراجعة اليوم (بدلاً من Math.random)
    const today = new Date()
    const todayStart = new Date(today.toDateString())
    const [approvedToday, dismissedToday, autoModerated] = await Promise.all([
      // مقالات تمت مراجعتها اليوم (لها flagReason)
      db.article.count({
        where: {
          isFlagged: true,
          flagReason: { not: null },
          updatedAt: { gte: todayStart },
        },
      }),
      // مقالات لم تعد مُعلّمة اليوم
      db.article.count({
        where: {
          isFlagged: false,
          updatedAt: { gte: todayStart },
        },
      }),
      // مقالات تم تعليمها تلقائياً (لها aiScore) — حالياً 0 حتى يُنفّذ auto-moderation
      Promise.resolve(0),
    ])

    return NextResponse.json({
      items: paginated,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      counts: {
        article: flaggedArticles.length,
        comment: flaggedComments.length,
        discussion: flaggedDiscussions.length,
        total: items.length,
        pending: items.filter(i => i.status === 'pending').length,
        reviewed: items.filter(i => i.status === 'reviewed').length,
      },
      stats: {
        pendingReview: items.filter(i => i.status === 'pending').length,
        approvedToday,
        dismissedToday,
        autoModerated,
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
