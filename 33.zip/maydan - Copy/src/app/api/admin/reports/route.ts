import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { NextRequest, NextResponse } from 'next/server'
import { statusToCode } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  try {
    await requireAdmin()
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const status = searchParams.get('status')
    const targetType = searchParams.get('targetType')
    const offset = (page - 1) * limit

    const where: any = {}
    if (status && status !== 'all') where.status = status
    if (targetType && targetType !== 'all') where.targetType = targetType

    const [reports, total] = await Promise.all([
      db.report.findMany({
        where,
        include: {
          reporter: { select: { id: true, name: true, avatar: true } },
          reviewer: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
      }),
      db.report.count({ where }),
    ])

    const pendingCount = await db.report.count({ where: { status: 'pending' } })

    return NextResponse.json({
      items: reports,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
      pendingCount,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    const { id, status } = await request.json() as { id?: string; status?: string }

    if (!id || !status) {
      return NextResponse.json({ success: false, error: 'id and status required', code: statusToCode(400) }, { status: 400 })
    }

    const allowedStatuses = ['reviewed', 'dismissed', 'action_taken']
    if (!allowedStatuses.includes(status)) {
      return NextResponse.json({ success: false, error: 'Invalid status', code: statusToCode(400) }, { status: 400 })
    }

    const report = await db.report.update({
      where: { id },
      data: {
        status,
        reviewedBy: admin.id,
        reviewedAt: new Date(),
      },
    })

    return NextResponse.json({ success: true, report })
  } catch (error) {
    return handleApiError(error)
  }
}
