import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireOwner } from '@/lib/session'
import { logSystemError } from '@/lib/logger'
import { statusToCode } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  try {
    await requireOwner()

    const now = new Date()

    // ── Current Concurrent Sessions ──
    const activeSessions = await db.userSession.count({
      where: {
        isActive: true,
        expiresAt: { gt: now },
      },
    })

    // ── Total registered users ──
    const totalUsers = await db.user.count()

    // ── Average API Response Time Estimate ──
    // Based on AI operation logs as a proxy for API performance
    const avgDuration = await db.aIOperationLog.aggregate({
      _avg: { durationMs: true },
      where: { durationMs: { not: null } },
    })
    const avgApiResponseTime = avgDuration._avg.durationMs
      ? Math.round(avgDuration._avg.durationMs)
      : null

    // ── Recent activity for load estimation ──
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000)
    const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000)
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

    const [
      activityLastHour,
      activityLast24h,
      activityLast7d,
      activeUsers24h,
      activeUsers7d,
    ] = await Promise.all([
      db.userActivityLog.count({ where: { createdAt: { gte: oneHourAgo } } }),
      db.userActivityLog.count({ where: { createdAt: { gte: twentyFourHoursAgo } } }),
      db.userActivityLog.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
      db.user.count({ where: { lastLoginAt: { gte: twentyFourHoursAgo } } }),
      db.user.count({ where: { lastLoginAt: { gte: sevenDaysAgo } } }),
    ])

    // ── Database Size & Growth (PostgreSQL) ──
    // ✅ تم الإصلاح: استخدم PostgreSQL query بدل فحص ملف SQLite
    let dbSizeBytes = 0
    try {
      const result = await db.$queryRaw<Array<{ pg_database_size_bytes: bigint }>>`
        SELECT pg_database_size(current_database()) AS pg_database_size_bytes
      `
      if (result && result.length > 0) {
        dbSizeBytes = Number(result[0].pg_database_size_bytes)
      }
    } catch (dbSizeError) {
      console.warn('[capacity] Failed to fetch DB size:', dbSizeError)
    }
    const dbSizeMB = Math.round((dbSizeBytes / (1024 * 1024)) * 100) / 100

    // ── Database record counts for growth projections ──
    const [
      totalArticles,
      totalComments,
      totalActivityLogs,
      totalSessions,
      totalErrors,
      totalAiLogs,
    ] = await Promise.all([
      db.article.count(),
      db.comment.count(),
      db.userActivityLog.count(),
      db.userSession.count(),
      db.systemError.count(),
      db.aIOperationLog.count(),
    ])

    // ── Growth rate: new records in last 7 days vs total ──
    const [
      newArticles7d,
      newComments7d,
      newUsers7d,
    ] = await Promise.all([
      db.article.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
      db.comment.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
      db.user.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    ])

    const weeklyArticleGrowthRate = totalArticles > 0 ? newArticles7d / totalArticles : 0
    const weeklyCommentGrowthRate = totalComments > 0 ? newComments7d / totalComments : 0
    const weeklyUserGrowthRate = totalUsers > 0 ? newUsers7d / totalUsers : 0

    // Projected growth: estimate in 30 and 90 days
    const projectedArticles30d = Math.round(totalArticles * (1 + weeklyArticleGrowthRate * 4.3))
    const projectedArticles90d = Math.round(totalArticles * (1 + weeklyArticleGrowthRate * 13))
    const projectedUsers30d = Math.round(totalUsers * (1 + weeklyUserGrowthRate * 4.3))
    const projectedUsers90d = Math.round(totalUsers * (1 + weeklyUserGrowthRate * 13))

    // ── Memory Usage ──
    const memoryUsage = process.memoryUsage()
    const heapUsedMB = Math.round(memoryUsage.heapUsed / (1024 * 1024) * 100) / 100
    const heapTotalMB = Math.round(memoryUsage.heapTotal / (1024 * 1024) * 100) / 100
    const rssMB = Math.round(memoryUsage.rss / (1024 * 1024) * 100) / 100

    // ── Estimated Max Concurrent Users ──
    // PostgreSQL with connection pooling: supports hundreds of concurrent writes/reads
    // Conservative estimate based on current load patterns
    const readWriteRatio = activityLast24h > 0
      ? Math.min(10, Math.max(2, activityLast24h / Math.max(1, activeUsers24h)))
      : 5
    const pgMaxConcurrentWrites = 100 // PostgreSQL supports many concurrent writers with MVCC
    const pgMaxConcurrentReads = 10000 // PostgreSQL handles high concurrent reads with connection pooling
    const estimatedMaxUsers = Math.min(
      50000, // Practical upper bound for PostgreSQL with proper pooling
      Math.max(100, activeSessions * 10) // Scale estimate based on current patterns
    )

    // ── Load factor ──
    const loadFactor = estimatedMaxUsers > 0
      ? Math.round((activeSessions / estimatedMaxUsers) * 10000) / 100
      : 0

    // ── Recommendations ──
    const recommendations: string[] = []
    if (dbSizeMB > 500) {
      recommendations.push('Database size exceeds 500MB. Consider archiving old data or migrating to PostgreSQL.')
    }
    if (activeSessions > 1000) {
      recommendations.push('High concurrent session count. Consider increasing connection pool size or scaling horizontally.')
    }
    if (totalActivityLogs > 1000000) {
      recommendations.push('Activity log table is very large. Implement log rotation or archival strategy.')
    }
    if (loadFactor > 70) {
      recommendations.push('System load is high. Consider scaling horizontally or upgrading infrastructure.')
    }
    if (recommendations.length === 0) {
      recommendations.push('System is operating within normal capacity limits.')
    }

    return NextResponse.json({
      capacity: {
        currentLoad: {
          activeSessions,
          activeUsers24h,
          activeUsers7d,
          activityLastHour,
          activityLast24h,
          activityLast7d,
          loadFactorPercent: loadFactor,
          memoryUsage: {
            heapUsedMB,
            heapTotalMB,
            rssMB,
          },
        },
        estimatedMaxUsers,
        limitations: {
          database: {
            type: 'PostgreSQL',
            concurrentWrites: pgMaxConcurrentWrites,
            concurrentReads: pgMaxConcurrentReads,
            description: 'PostgreSQL is a robust relational database that supports many concurrent readers and writers through MVCC (Multi-Version Concurrency Control). Ideal for production applications with high traffic.',
            maxDatabaseSize: 'PostgreSQL handles very large databases efficiently. Performance depends on indexing, query optimization, and hardware resources.',
            writeContention: 'PostgreSQL uses MVCC to minimize write contention. Writers do not block readers, and row-level locking allows concurrent writes to different rows.',
            connectionPooling: 'Connection pooling (via PgBouncer or Prisma built-in) allows efficient management of database connections under high load.',
          },
          practicalLimits: {
            maxConcurrentUsers: '~50,000+ (with connection pooling)',
            maxWritesPerSecond: '~5,000+ (depending on hardware and query complexity)',
            maxReadsPerSecond: '~100,000+ (with proper indexing)',
            maxDatabaseSizeGB: null,
          },
        },
        performance: {
          avgApiResponseTimeMs: avgApiResponseTime,
          readWriteRatio: Math.round(readWriteRatio * 100) / 100,
        },
        databaseGrowth: {
          currentSizeMB: dbSizeMB,
          totalRecords: {
            users: totalUsers,
            articles: totalArticles,
            comments: totalComments,
            activityLogs: totalActivityLogs,
            sessions: totalSessions,
            errors: totalErrors,
            aiLogs: totalAiLogs,
          },
          weeklyGrowthRates: {
            articles: Math.round(weeklyArticleGrowthRate * 10000) / 100,
            comments: Math.round(weeklyCommentGrowthRate * 10000) / 100,
            users: Math.round(weeklyUserGrowthRate * 10000) / 100,
          },
          projections: {
            articles30d: projectedArticles30d,
            articles90d: projectedArticles90d,
            users30d: projectedUsers30d,
            users90d: projectedUsers90d,
            estimatedDbSize30dMB: Math.round(dbSizeMB * (1 + weeklyArticleGrowthRate * 4.3 + weeklyCommentGrowthRate * 4.3) * 100) / 100,
            estimatedDbSize90dMB: Math.round(dbSizeMB * (1 + weeklyArticleGrowthRate * 13 + weeklyCommentGrowthRate * 13) * 100) / 100,
          },
        },
        recommendations,
      },
    })
  } catch (error) {
    console.error('Capacity GET error:', error)
    await logSystemError({
      type: 'api_error',
      message: 'Failed to fetch capacity analysis',
      severity: 'high',
      metadata: { error: String(error) },
    })
    return NextResponse.json({ success: false, error: 'Failed to fetch capacity analysis', code: statusToCode(500) }, { status: 500 })
  }
}
