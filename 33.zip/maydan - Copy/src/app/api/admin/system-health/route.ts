import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireOwner } from '@/lib/session'
import { logSystemError } from '@/lib/logger'
import { statusToCode } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  try {
    await requireOwner()

    const now = new Date()
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000)

    // ── Active Sessions ──
    const activeSessions = await db.userSession.count({
      where: {
        isActive: true,
        expiresAt: { gt: now },
      },
    })

    // ── Database Size (PostgreSQL) ──
    // ✅ تم الإصلاح: استخدم PostgreSQL query بدل فحص ملف SQLite
    let dbSizeBytes = 0
    let dbSizeMB = 0
    try {
      const result = await db.$queryRaw<Array<{ pg_database_size_bytes: bigint }>>`
        SELECT pg_database_size(current_database()) AS pg_database_size_bytes
      `
      if (result && result.length > 0) {
        dbSizeBytes = Number(result[0].pg_database_size_bytes)
        dbSizeMB = Math.round((dbSizeBytes / (1024 * 1024)) * 100) / 100
      }
    } catch (dbSizeError) {
      console.warn('[system-health] Failed to fetch DB size:', dbSizeError)
      // متابعة بدون قيمة الحجم
    }

    // ── Total Records Count Per Model ──
    const [
      userCount,
      articleCount,
      commentCount,
      likeCount,
      sessionCount,
      activityLogCount,
      errorCount,
      aiLogCount,
      discussionCount,
      discussionReplyCount,
      notificationCount,
      messageCount,
      followCount,
      walletCount,
      walletTransactionCount,
      subscriptionCount,
      passwordResetCount,
      systemHealthCount,
    ] = await Promise.all([
      db.user.count(),
      db.article.count(),
      db.comment.count(),
      db.like.count(),
      db.userSession.count(),
      db.userActivityLog.count(),
      db.systemError.count(),
      db.aIOperationLog.count(),
      db.discussion.count(),
      db.discussionReply.count(),
      db.notification.count(),
      db.message.count(),
      db.follow.count(),
      db.wallet.count(),
      db.walletTransaction.count(),
      db.subscription.count(),
      db.passwordResetCode.count(),
      db.systemHealth.count(),
    ])

    const totalRecords =
      userCount +
      articleCount +
      commentCount +
      likeCount +
      sessionCount +
      activityLogCount +
      errorCount +
      aiLogCount +
      discussionCount +
      discussionReplyCount +
      notificationCount +
      messageCount +
      followCount +
      walletCount +
      walletTransactionCount +
      subscriptionCount +
      passwordResetCount +
      systemHealthCount

    const recordsPerModel = {
      users: userCount,
      articles: articleCount,
      comments: commentCount,
      likes: likeCount,
      sessions: sessionCount,
      activityLogs: activityLogCount,
      errors: errorCount,
      aiLogs: aiLogCount,
      discussions: discussionCount,
      discussionReplies: discussionReplyCount,
      notifications: notificationCount,
      messages: messageCount,
      follows: followCount,
      wallets: walletCount,
      walletTransactions: walletTransactionCount,
      subscriptions: subscriptionCount,
      passwordResets: passwordResetCount,
      systemHealthMetrics: systemHealthCount,
    }

    // ── Recent Error Rate (errors in last hour / total activity logs in last hour) ──
    const [errorsLastHour, activityLastHour] = await Promise.all([
      db.systemError.count({
        where: { createdAt: { gte: oneHourAgo } },
      }),
      db.userActivityLog.count({
        where: { createdAt: { gte: oneHourAgo } },
      }),
    ])
    const errorRate = activityLastHour > 0
      ? Math.round((errorsLastHour / activityLastHour) * 10000) / 100
      : errorsLastHour > 0 ? 100 : 0

    // ── AI Service Status ──
    let aiServiceStatus = 'unavailable'
    let aiServiceLatency: number | null = null
    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default
      const startTime = Date.now()
      await ZAI.create()
      aiServiceLatency = Date.now() - startTime
      aiServiceStatus = 'available'
    } catch {
      aiServiceStatus = 'unavailable'
    }

    // ── Memory Usage ──
    const memoryUsage = process.memoryUsage()
    const memoryStats = {
      rss: Math.round(memoryUsage.rss / (1024 * 1024) * 100) / 100,
      heapTotal: Math.round(memoryUsage.heapTotal / (1024 * 1024) * 100) / 100,
      heapUsed: Math.round(memoryUsage.heapUsed / (1024 * 1024) * 100) / 100,
      external: Math.round(memoryUsage.external / (1024 * 1024) * 100) / 100,
    }

    // ── Uptime ──
    const uptimeSeconds = process.uptime()

    return NextResponse.json({
      health: {
        status: 'operational',
        timestamp: now.toISOString(),
        uptime: {
          seconds: Math.round(uptimeSeconds),
          formatted: `${Math.floor(uptimeSeconds / 86400)}d ${Math.floor((uptimeSeconds % 86400) / 3600)}h ${Math.floor((uptimeSeconds % 3600) / 60)}m`,
        },
        activeSessions,
        database: {
          sizeBytes: dbSizeBytes,
          sizeMB: dbSizeMB,
          totalRecords,
          recordsPerModel,
        },
        errorRate: {
          errorsLastHour,
          activityLastHour,
          rate: errorRate,
          unit: 'percent',
        },
        aiService: {
          status: aiServiceStatus,
          latencyMs: aiServiceLatency,
        },
        memory: memoryStats,
      },
    })
  } catch (error) {
    console.error('System health GET error:', error)
    await logSystemError({
      type: 'api_error',
      message: 'Failed to fetch system health',
      severity: 'critical',
      metadata: { error: String(error) },
    })
    return NextResponse.json({ success: false, error: 'Failed to fetch system health', code: statusToCode(500) }, { status: 500 })
  }
}
