import { db } from '@/lib/db'
import { requireAdmin, handleApiError } from '@/lib/session'
import { logAudit, AuditActions, TargetTypes } from '@/lib/audit'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    await requireAdmin()

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'users'
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const format = searchParams.get('format') || 'csv'

    const whereDate: any = {}
    if (startDate) whereDate.gte = new Date(startDate)
    if (endDate) whereDate.lte = new Date(endDate)

    let data: any[] = []
    let headers: string[] = []

    switch (type) {
      case 'users': {
        headers = ['المعرف', 'الاسم', 'البريد', 'الدور', 'الحالة', 'تاريخ التسجيل']
        const users = await db.user.findMany({
          select: { id: true, name: true, email: true, role: true, isBanned: true, createdAt: true },
          where: { ...(startDate || endDate ? { createdAt: whereDate } : {}) },
          orderBy: { createdAt: 'desc' },
          take: 10000,
        })
        data = users.map((u: any) => ({
          id: u.id,
          name: u.name || '',
          email: u.email,
          role: u.role,
          status: u.isBanned ? 'محظور' : 'نشط',
          createdAt: u.createdAt.toISOString().split('T')[0],
        }))
        break
      }
      case 'articles': {
        headers = ['المعرف', 'العنوان', 'التصنيف', 'الحالة', 'المشاهدات', 'المؤلف', 'تاريخ الإنشاء']
        const articles = await db.article.findMany({
          where: { ...(startDate || endDate ? { createdAt: whereDate } : {}) },
          orderBy: { createdAt: 'desc' },
          take: 10000,
          select: { id: true, title: true, category: true, status: true, viewCount: true, createdAt: true, author: { select: { name: true } } },
        })
        data = articles.map((a: any) => ({
          id: a.id,
          title: a.title,
          category: a.category,
          status: a.status,
          views: a.viewCount,
          author: a.author?.name || '',
          createdAt: a.createdAt.toISOString().split('T')[0],
        }))
        break
      }
      case 'jobs': {
        headers = ['المعرف', 'العنوان', 'الشركة', 'الموقع', 'النوع', 'تاريخ الإنشاء']
        const jobs = await db.job.findMany({
          select: { id: true, title: true, company: true, location: true, type: true, createdAt: true },
          orderBy: { createdAt: 'desc' },
          take: 10000,
        })
        data = jobs.map((j: any) => ({
          id: j.id,
          title: j.title,
          company: j.company,
          location: j.location || '',
          type: j.type,
          createdAt: j.createdAt.toISOString().split('T')[0],
        }))
        break
      }
      case 'comments': {
        headers = ['المعرف', 'المحتوى', 'معرف المقال', 'معرف المؤلف', 'تاريخ الإنشاء']
        const comments = await db.comment.findMany({
          select: { id: true, content: true, articleId: true, authorId: true, createdAt: true },
          orderBy: { createdAt: 'desc' },
          take: 10000,
        })
        data = comments.map((c: any) => ({
          id: c.id,
          content: c.content.slice(0, 200),
          articleId: c.articleId,
          authorId: c.authorId,
          createdAt: c.createdAt.toISOString().split('T')[0],
        }))
        break
      }
      case 'discussions': {
        headers = ['المعرف', 'العنوان', 'التصنيف', 'عدد الردود', 'المشاهدات', 'تاريخ الإنشاء']
        const discussions = await db.discussion.findMany({
          select: { id: true, title: true, category: true, replyCount: true, viewCount: true, createdAt: true },
          orderBy: { createdAt: 'desc' },
          take: 10000,
        })
        data = discussions.map((d: any) => ({
          id: d.id,
          title: d.title,
          category: d.category,
          replies: d.replyCount,
          views: d.viewCount,
          createdAt: d.createdAt.toISOString().split('T')[0],
        }))
        break
      }
      case 'stats': {
        headers = ['المؤشر', 'القيمة']
        const totalUsers = await db.user.count()
        const totalArticles = await db.article.count()
        const totalComments = await db.comment.count()
        const totalDiscussions = await db.discussion.count()
        const totalJobs = await db.job.count()
        data = [
          { metric: 'المستخدمين', value: totalUsers },
          { metric: 'المقالات', value: totalArticles },
          { metric: 'التعليقات', value: totalComments },
          { metric: 'النقاشات', value: totalDiscussions },
          { metric: 'فرص العمل', value: totalJobs },
        ]
        break
      }
    }

    const adminUser = await requireAdmin()
    await logAudit(adminUser.id, AuditActions.DATA_EXPORT, TargetTypes.EXPORT, undefined, {
      type,
      format,
      rowsCount: data.length,
    })

    if (format === 'json') {
      return new Response(JSON.stringify(data, null, 2), {
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="${type}_export.json"`,
        },
      })
    }

    // CSV format
    const bom = '\uFEFF'
    const csvLines = [
      headers.map(h => `"${h}"`).join(','),
      ...data.map(row =>
        headers.map(h => {
          const val = (row as any)[h]
          if (val === null || val === undefined) return '""'
          return `"${String(val).replace(/"/g, '""')}"`
        }).join(',')
      ),
    ]
    const csv = bom + csvLines.join('\n')

    return new Response(csv, {
      headers: {
        'Content-Type': 'text/csv;charset=utf-8',
        'Content-Disposition': `attachment; filename="${type}_export.csv"`,
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
