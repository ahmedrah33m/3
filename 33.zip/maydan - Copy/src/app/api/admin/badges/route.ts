// API: /api/admin/badges
// Returns counts of items pending admin attention.
// Used by the sidebar nav badges + the pending alerts banner.

import { NextRequest, NextResponse } from 'next/server'
import { db as prisma } from '@/lib/db'
import { requireAdmin } from '@/lib/session'
import { statusToCode } from '@/lib/api-utils'

export async function GET(_req: NextRequest) {
  let isAuthorized = false
  try {
    await requireAdmin()
    isAuthorized = true
  } catch {
    return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })
  }
  if (!isAuthorized) return NextResponse.json({ success: false, error: 'Unauthorized', code: statusToCode(401) }, { status: 401 })

  try {

    // Run counts in parallel for speed
    const [
      pendingReports,
      pendingFlagged,
      pendingVerifications,
      pendingPayments,
      pendingPayouts,
      pendingAds,
      pendingAutoPublish,
      unreadAudit,
    ] = await Promise.all([
      // Reported content (uses Report model if it exists, else falls back to flagged articles)
      prisma.report?.count?.({ where: { status: 'PENDING' } }).catch(() => null) ??
        prisma.article.count({ where: { isFlagged: true, deletedAt: null } }).catch(() => 0),

      // Flagged content
      prisma.article.count({ where: { isFlagged: true, deletedAt: null } }).catch(() => 0),

      // Expert verification requests pending
      prisma.expertVerification?.count?.({ where: { status: 'PENDING' } }).catch(() => null) ??
        prisma.user.count({ where: { role: 'EXPERT', isVerified: false } }).catch(() => 0),

      // Pending wallet top-up approvals
      prisma.topUpRequest?.count?.({ where: { status: 'PENDING' } }).catch(() => null) ??
        prisma.walletTransaction?.count?.({ where: { type: 'TOPUP', status: 'PENDING' } }).catch(() => 0),

      // Pending withdrawal approvals
      prisma.withdrawalRequest?.count?.({ where: { status: 'PENDING' } }).catch(() => null) ??
        prisma.walletTransaction?.count?.({ where: { type: 'WITHDRAWAL', status: 'PENDING' } }).catch(() => 0),

      // Pending ad approvals (ads without endDate or endDate in the future, not yet reviewed)
      prisma.ad.count({ where: { isActive: true, endDate: null } }).catch(() => 0),

      // Auto-publish queue size (articles with status DRAFT that were scheduled)
      prisma.article.count({ where: { status: 'DRAFT' } }).catch(() => 0),

      // Unread audit log entries (admin actions not yet reviewed)
      Promise.resolve(0),
    ])

    return NextResponse.json({
      badges: {
        pendingReports: (pendingReports as number) || 0,
        pendingFlagged: (pendingFlagged as number) || 0,
        pendingVerifications: (pendingVerifications as number) || 0,
        pendingPayments: ((pendingPayments as number) || 0) + ((pendingPayouts as number) || 0),
        pendingPayouts: (pendingPayouts as number) || 0,
        pendingAds: (pendingAds as number) || 0,
        pendingAutoPublish: (pendingAutoPublish as number) || 0,
        unreadAudit: (unreadAudit as number) || 0,
      },
    })
  } catch (err) {
    console.error('[admin/badges] error:', err)
    // Return zeros instead of 500 — UI degrades gracefully
    return NextResponse.json({
      badges: {
        pendingReports: 0,
        pendingFlagged: 0,
        pendingVerifications: 0,
        pendingPayments: 0,
        pendingPayouts: 0,
        pendingAds: 0,
        pendingAutoPublish: 0,
        unreadAudit: 0,
      },
    })
  }
}
