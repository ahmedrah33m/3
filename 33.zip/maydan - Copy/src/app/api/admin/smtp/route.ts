import { NextRequest, NextResponse } from 'next/server'
import { requireOwner, handleApiError } from '@/lib/session'
import { isSMTPConfigured } from '@/lib/email'
import { statusToCode } from '@/lib/api-utils'

// GET: Get SMTP status (without exposing password)
export async function GET() {
  try {
    await requireOwner()
    return NextResponse.json({
      configured: isSMTPConfigured(),
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: Number(process.env.SMTP_PORT) || 587,
      email: process.env.SMTP_EMAIL || '',
      hasPassword: !!process.env.SMTP_PASSWORD,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST: Test SMTP connection
export async function POST(request: NextRequest) {
  try {
    await requireOwner()
    const body = await request.json()
    const { host, port, email, password } = body

    if (!email || !password) {
      return NextResponse.json({ success: false, error: 'البريد وكلمة المرور مطلوبان', code: statusToCode(400) }, { status: 400 })
    }

    // Dynamic import to test connection
    const nodemailer = await import('nodemailer')
    const transporter = nodemailer.createTransport({
      host: host || 'smtp.gmail.com',
      port: Number(port) || 587,
      secure: Number(port) === 465,
      auth: { user: email, pass: password },
    })

    try {
      await transporter.verify()
      return NextResponse.json({ success: true, message: 'تم الاتصال بخادم SMTP بنجاح' })
    } catch (verifyError: unknown) {
      const msg = verifyError instanceof Error ? verifyError.message : 'فشل الاتصال'
      return NextResponse.json({ success: false, error: `فشل الاتصال: ${msg}` }, { status: 400 })
    }
  } catch (error) {
    return handleApiError(error)
  }
}
