import { NextRequest } from 'next/server'
import { requireAdmin, handleApiError } from '@/lib/session'
import { successResponse } from '@/lib/api-utils'
import { listVerificationRequests, reviewVerification } from '@/services/social.service'

export async function GET(req: NextRequest) {
  try {
    const user = await requireAdmin()
    const status = req.nextUrl.searchParams.get('status') || 'PENDING'
    return successResponse({ requests: await listVerificationRequests(status) })
  } catch (error) { return handleApiError(error) }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAdmin()
    const body = await req.json().catch(() => ({}))
    if (!body.requestId || !body.decision) return successResponse({ error: 'بيانات ناقصة' }, 400)
    return successResponse(await reviewVerification(body.requestId, user.id, body.decision, body.note))
  } catch (error) { return handleApiError(error) }
}
