import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireOwner } from '@/lib/session'
import { logSystemError } from '@/lib/logger'
import { statusToCode } from '@/lib/api-utils'

export async function GET(request: NextRequest) {
  try {
    await requireOwner()

    const now = new Date()
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const weekStart = new Date(todayStart)
    weekStart.setDate(weekStart.getDate() - 7)
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    const thirtyDaysAgo = new Date(now)
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
    const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000)
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    const thirtyDaysAgoForActive = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

    // ── User Counts ──
    const [totalUsers, newUsersToday, newUsersThisWeek, newUsersThisMonth] =
      await Promise.all([
        db.user.count(),
        db.user.count({ where: { createdAt: { gte: todayStart } } }),
        db.user.count({ where: { createdAt: { gte: weekStart } } }),
        db.user.count({ where: { createdAt: { gte: monthStart } } }),
      ])

    // ── Content Counts ──
    const [totalArticles, totalComments, totalLikes] = await Promise.all([
      db.article.count(),
      db.comment.count(),
      db.like.count(),
    ])

    // ── Login Stats ──
    const [
      loginsToday,
      loginsThisWeek,
      loginsThisMonth,
      totalLoginLogs,
      firstLoginLog,
    ] = await Promise.all([
      db.userActivityLog.count({
        where: { action: 'LOGIN', createdAt: { gte: todayStart } },
      }),
      db.userActivityLog.count({
        where: { action: 'LOGIN', createdAt: { gte: weekStart } },
      }),
      db.userActivityLog.count({
        where: { action: 'LOGIN', createdAt: { gte: monthStart } },
      }),
      db.userActivityLog.count({ where: { action: 'LOGIN' } }),
      db.userActivityLog.findFirst({
        where: { action: 'LOGIN' },
        orderBy: { createdAt: 'asc' },
        select: { createdAt: true },
      }),
    ])

    const daysSinceFirstLogin = firstLoginLog
      ? Math.max(1, Math.ceil((now.getTime() - firstLoginLog.createdAt.getTime()) / (1000 * 60 * 60 * 24)))
      : 1
    const averageLoginsPerDay = Math.round(totalLoginLogs / daysSinceFirstLogin)

    // ── Registration Stats ──
    const [registrationsToday, registrationsThisWeek, registrationsThisMonth] =
      await Promise.all([
        db.user.count({ where: { createdAt: { gte: todayStart } } }),
        db.user.count({ where: { createdAt: { gte: weekStart } } }),
        db.user.count({ where: { createdAt: { gte: monthStart } } }),
      ])

    // ── Active Users ──
    const [
      activeUsers24h,
      activeUsers7d,
      activeUsers30d,
    ] = await Promise.all([
      db.user.count({
        where: { lastLoginAt: { gte: twentyFourHoursAgo } },
      }),
      db.user.count({
        where: { lastLoginAt: { gte: sevenDaysAgo } },
      }),
      db.user.count({
        where: { lastLoginAt: { gte: thirtyDaysAgoForActive } },
      }),
    ])

    // ── Content Stats: Articles by Category ──
    const articlesByCategoryRaw = await db.article.groupBy({
      by: ['category'],
      _count: { id: true },
    })
    const articlesByCategory: Record<string, number> = {}
    for (const row of articlesByCategoryRaw) {
      articlesByCategory[row.category] = row._count.id
    }

    // ── Content Stats: Articles by Status ──
    const articlesByStatusRaw = await db.article.groupBy({
      by: ['status'],
      _count: { id: true },
    })
    const articlesByStatus: Record<string, number> = {}
    for (const row of articlesByStatusRaw) {
      articlesByStatus[row.status] = row._count.id
    }

    // ── User Growth: Last 30 Days — use groupBy instead of fetching all rows ──
    const userGrowthRaw = await db.user.groupBy({
      by: ['createdAt'],
      where: { createdAt: { gte: thirtyDaysAgo } },
      _count: { id: true },
    })
    // Prisma groupBy with DateTime truncates to same second — group by day in JS
    const growthMap = new Map<string, number>()
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now)
      d.setDate(d.getDate() - i)
      growthMap.set(d.toISOString().split('T')[0], 0)
    }
    for (const row of userGrowthRaw) {
      const key = row.createdAt.toISOString().split('T')[0]
      if (growthMap.has(key)) {
        growthMap.set(key, (growthMap.get(key) || 0) + row._count.id)
      }
    }
    const userGrowth = Array.from(growthMap, ([date, count]) => ({ date, count }))

    // ── Login Activity: Last 30 Days — use groupBy instead of fetching all rows ──
    const loginActivityRaw = await db.userActivityLog.groupBy({
      by: ['createdAt'],
      where: { action: 'LOGIN', createdAt: { gte: thirtyDaysAgo } },
      _count: { id: true },
    })
    const loginMap = new Map<string, number>()
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now)
      d.setDate(d.getDate() - i)
      loginMap.set(d.toISOString().split('T')[0], 0)
    }
    for (const row of loginActivityRaw) {
      const key = row.createdAt.toISOString().split('T')[0]
      if (loginMap.has(key)) {
        loginMap.set(key, (loginMap.get(key) || 0) + row._count.id)
      }
    }
    const loginActivity = Array.from(loginMap, ([date, count]) => ({ date, count }))

    // ── Peak Hours: use groupBy for last 30 days instead of ALL logins ──
    const peakHoursRaw = await db.userActivityLog.groupBy({
      by: ['createdAt'],
      where: { action: 'LOGIN', createdAt: { gte: thirtyDaysAgo } },
      _count: { id: true },
    })
    const hourMap = new Map<number, number>()
    for (let h = 0; h < 24; h++) hourMap.set(h, 0)
    for (const row of peakHoursRaw) {
      const hour = row.createdAt.getHours()
      hourMap.set(hour, (hourMap.get(hour) || 0) + row._count.id)
    }
    const peakHours = Array.from({ length: 24 }, (_, h) => ({ hour: h, count: hourMap.get(h) || 0 }))

    // ── Top Active Users by Login Count ──
    const topActiveUsersRaw = await db.user.findMany({
      where: { loginCount: { gt: 0 } },
      orderBy: { loginCount: 'desc' },
      take: 10,
      select: {
        id: true,
        name: true,
        email: true,
        loginCount: true,
        lastLoginAt: true,
        avatar: true,
      },
    })

    // ── Device/Browser Breakdown — use groupBy instead of fetching all sessions ──
    const [deviceRaw, browserRaw, osRaw] = await Promise.all([
      db.userSession.groupBy({ by: ['device'], _count: { id: true } }),
      db.userSession.groupBy({ by: ['browser'], _count: { id: true } }),
      db.userSession.groupBy({ by: ['os'], _count: { id: true } }),
    ])
    const deviceBreakdown: Record<string, number> = {}
    for (const row of deviceRaw) deviceBreakdown[row.device || 'Unknown'] = row._count.id
    const browserBreakdown: Record<string, number> = {}
    for (const row of browserRaw) browserBreakdown[row.browser || 'Unknown'] = row._count.id
    const osBreakdown: Record<string, number> = {}
    for (const row of osRaw) osBreakdown[row.os || 'Unknown'] = row._count.id

    return NextResponse.json({
      analytics: {
        users: {
          total: totalUsers,
          newToday: newUsersToday,
          newThisWeek: newUsersThisWeek,
          newThisMonth: newUsersThisMonth,
        },
        content: {
          totalArticles,
          totalComments,
          totalLikes,
          articlesByCategory,
          articlesByStatus,
        },
        logins: {
          today: loginsToday,
          thisWeek: loginsThisWeek,
          thisMonth: loginsThisMonth,
          averagePerDay: averageLoginsPerDay,
        },
        registrations: {
          today: registrationsToday,
          thisWeek: registrationsThisWeek,
          thisMonth: registrationsThisMonth,
        },
        activeUsers: {
          last24h: activeUsers24h,
          last7d: activeUsers7d,
          last30d: activeUsers30d,
        },
        userGrowth,
        loginActivity,
        peakHours,
        topActiveUsers: topActiveUsersRaw,
        deviceBreakdown,
        browserBreakdown,
        osBreakdown,
      },
    })
  } catch (error) {
    console.error('Analytics error:', error)
    await logSystemError({
      type: 'api_error',
      message: 'Failed to fetch analytics data',
      severity: 'high',
      metadata: { error: String(error) },
    })
    return NextResponse.json({ success: false, error: 'Failed to fetch analytics data', code: statusToCode(500) }, { status: 500 })
  }
}
