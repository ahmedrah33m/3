import { ReactNode, lazy, Suspense } from 'react'
import type { Metadata } from 'next'
import { NavbarServer } from '@/components/NavbarServer'
import Sidebar from '@/components/Sidebar'
import LeftPanel from '@/components/LeftPanel'
import Footer from '@/components/Footer'
import { AuthModals } from '@/components/AuthModals'
import MobileBottomNav from '@/components/MobileBottomNav'
import { MobileTopBar } from '@/components/MobileTopBar'
import { ThemeToggle } from '@/components/theme-toggle'
import { AuthGate } from '@/components/AuthGate'
import { Skeleton } from '@/components/ui/skeleton'

export const metadata: Metadata = {
  title: 'الرئيسية',
  description: 'ميدان — المنصة المهنية العراقية. مقالات، نقاشات، وظائف، استشارات اقتصادية، وأدوات تحليل الاقتصاد العراقي',
  robots: { index: true, follow: true },
}

export default function MainLayout({ children }: { children: ReactNode }) {
  return (
    <AuthGate>
      <div className="min-h-screen flex flex-col bg-background">
        {/* Mobile Top Bar (replaces navbar on mobile) */}
        <MobileTopBar />

        {/* Desktop Navbar (hidden on mobile) */}
        <div className="hidden lg:block">
          <NavbarServer />
        </div>

        {/* Main Content — 3-Column Layout */}
        <main className="flex-1 pb-[calc(3.5rem+env(safe-area-inset-bottom))] lg:pb-0">
          <div className="max-w-[1600px] mx-auto px-3 sm:px-4 lg:px-6 py-4 lg:py-6">
            <div className="flex gap-6 items-start">
              {/* ── Right Column: Navigation Sidebar ── */}
              <div className="hidden lg:block w-64 shrink-0">
                <div className="sticky top-20">
                  <Sidebar />
                </div>
              </div>

              {/* ── Center Column: Page Content ── */}
              <div className="flex-1 min-w-0">
                {children}
              </div>

              {/* ── Left Column: Trending, Ads, Categories, Streak ── */}
              <div className="hidden xl:block w-72 shrink-0">
                <div className="sticky top-20">
                  <LeftPanel />
                </div>
              </div>
            </div>
          </div>
        </main>

        {/* Desktop Footer (hidden on mobile) — lazy loaded */}
        <div className="hidden lg:block">
          <Suspense fallback={<div className="h-48" />}>
            <Footer />
          </Suspense>
        </div>

        {/* Mobile Bottom Nav (with merged Create menu) */}
        <MobileBottomNav />

        <AuthModals />

        {/* Theme Toggle — desktop: fixed bottom-left; mobile: inside MobileNavDrawer */}
        <div className="fixed bottom-4 start-4 z-40 hidden lg:block">
          <ThemeToggle />
        </div>
      </div>
    </AuthGate>
  )
}