import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /ai نسخة قديمة من مساعد الذكاء الاصطناعي — نُوجّه إلى /ai-assistant */
export default function AiPage() {
  redirect('/ai-assistant')
}