'use client'

import { Suspense, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useStore } from '@/lib/store'
import CompanyRegistrationWizard from '@/components/company/CompanyRegistrationWizard'

function RegisterPageInner() {
  const router = useRouter()
  const { currentUser, isAuthenticated, authLoading, checkAuth } = useStore()

  useEffect(() => {
    checkAuth()
  }, [checkAuth])

  // If user already has a company, redirect to dashboard
  useEffect(() => {
    if (!authLoading && currentUser && currentUser.userType === 'company') {
      router.replace('/company-dashboard')
    }
  }, [authLoading, currentUser, router])

  if (authLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  return <CompanyRegistrationWizard />
}

export default function RegisterPage() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      }
    >
      <RegisterPageInner />
    </Suspense>
  )
}
