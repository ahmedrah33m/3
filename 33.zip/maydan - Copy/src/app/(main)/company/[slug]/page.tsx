import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { optionalAuth } from '@/lib/session'
import { getCompanyProfileBySlug } from '@/services/employer-branding.service'
import CompanyPublicProfile from '@/components/CompanyPublicProfile'

interface Props {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  try {
    const profile = await getCompanyProfileBySlug(slug)
    return {
      title: `${profile.company.name} | ميدان جوبز`,
      description: profile.brand?.about || null,
      openGraph: {
        title: profile.company.name,
        description: profile.brand?.about || undefined,
        type: 'profile',
        locale: 'ar_IQ',
      },
      alternates: { canonical: `/company/${slug}` },
    }
  } catch {
    return { title: 'شركة غير موجودة' }
  }
}

export default async function CompanyPublicPage({ params }: Props) {
  const { slug } = await params

  let profile
  try {
    profile = await getCompanyProfileBySlug(slug)
  } catch {
    notFound()
  }

  const user = await optionalAuth()
  const isOwner = user?.role === 'OWNER' && profile.company.ownerId === user.id

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': profile.company.verificationStatus === 'VERIFIED' ? 'Organization' : 'Organization',
    name: profile.company.name,
    url: `https://maydan.jobs/company/${slug}`,
    description: profile.brand?.about || undefined,
    ...(profile.employerScore ? { aggregateRating: { '@type': 'AggregateRating', ratingValue: profile.employerScore, reviewCount: profile.reviewCount } } : {}),
    ...(profile.offices.length ? {
      location: profile.offices.map((o) => ({
        '@type': 'Place',
        name: o.city,
        address: { '@type': 'PostalAddress', addressLocality: o.city, addressCountry: o.country || 'IQ' },
      })),
    } : {}),
  }

  return (
    <>
      <script dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} type="application/ld+json" />
      <div className="max-w-4xl mx-auto py-6" dir="rtl">
        {isOwner && (
          <a href={`/companies/${profile.company.id}/manage`} className="inline-block mb-3 text-sm text-indigo-600">
            إدارة صفحة صاحب العمل ←
          </a>
        )}
        <CompanyPublicProfile companyId={profile.company.id} initialProfile={profile} isOwner={isOwner} />
      </div>
    </>
  )
}
