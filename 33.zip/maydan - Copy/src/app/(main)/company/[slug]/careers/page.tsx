import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import {
  getCompanyProfileBySlug,
  listCompanyOpenJobs,
} from '@/services/employer-branding.service'
import CareersView, { type OpenJobItem } from '@/components/jobs/CareersView'

interface Props {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  try {
    const { slug } = await params
    const profile = await getCompanyProfileBySlug(slug)
    return {
      title: `وظائف ${profile.company.name} | ميدان جوبز`,
      description: `فرص العمل المتاحة لدى ${profile.company.name} — قدّم طلبك مباشرة عبر ميدان جوبز.`,
      alternates: { canonical: `/company/${slug}/careers` },
      openGraph: {
        title: `وظائف ${profile.company.name}`,
        description: `فرص العمل المتاحة لدى ${profile.company.name}`,
        url: `https://maydan.jobs/company/${slug}/careers`,
        type: 'website',
        locale: 'ar_IQ',
      },
    }
  } catch {
    return { title: 'وظائف الشركة' }
  }
}

export default async function CareersPage({ params }: Props) {
  let profile
  let jobs: OpenJobItem[] = []
  const { slug } = await params

  try {
    profile = await getCompanyProfileBySlug(slug)
  } catch {
    notFound()
  }

  try {
    jobs = await listCompanyOpenJobs(profile.company.id, profile.company.ownerId).then((rows) =>
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        slug: r.id,
        city: r.city,
        governorate: null,
        employmentType: r.type,
        workMode: r.workMode,
        department: null,
        isRemote: r.workMode === 'REMOTE',
        isExpired: r.isExpired,
        createdAt: r.createdAt,
      }))
    )
  } catch {
    jobs = []
  }

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'JobPosting',
    title: profile.company.name,
    url: `https://maydan.jobs/company/${slug}/careers`,
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <CareersView
        companyName={profile.company.name}
        slug={slug}
        offices={profile.offices}
        jobs={jobs}
      />
    </>
  )
}
