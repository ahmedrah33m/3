import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'المقالات الاقتصادية والتحليلات | ميدان',
  description: 'تصفح أحدث المقالات الاقتصادية والتحليلات المتخصصة على منصة ميدان. مقالات من خبراء وأكاديميين عراقيين.',
  openGraph: {
    title: 'المقالات الاقتصادية والتحليلات | ميدان',
    description: 'تصفح أحدث المقالات الاقتصادية والتحليلات المتخصصة على منصة ميدان. مقالات من خبراء وأكاديميين عراقيين.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/articles`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'المقالات الاقتصادية والتحليلات | ميدان',
    description: 'تصفح أحدث المقالات الاقتصادية والتحليلات المتخصصة على منصة ميدان. مقالات من خبراء وأكاديميين عراقيين.',
  },
  alternates: {
    canonical: `${SITE_URL}/articles`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
