import { db } from '@/lib/db'
import type { Metadata } from 'next'

const SITE_NAME = 'ميدان الاقتصاد'
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>
}): Promise<Metadata> {
  try {
    const { id } = await params
    const article = await db.article.findUnique({
      where: { id },
      include: {
        author: { select: { name: true, avatar: true, jobTitle: true, organization: true } },
      },
    })

    if (!article) {
      return { title: 'مقال غير موجود | ميدان الاقتصاد' }
    }

    const title = `${article.title} | ${SITE_NAME}`
    const description = article.summary || `مقال تحليلي على منصة ميدان الاقتصاد`
    const imageUrl = article.coverImage
      ? (article.coverImage.startsWith('http') ? article.coverImage : `${SITE_URL}${article.coverImage}`)
      : `${SITE_URL}/logo.jpg`

    return {
      title,
      description,
      openGraph: {
        title,
        description,
        type: 'article',
        publishedTime: new Date(article.createdAt).toISOString(),
        authors: [article.author?.name || SITE_NAME],
        images: [imageUrl],
        locale: 'ar_IQ',
        url: `${SITE_URL}/articles/${article.id}`,
        siteName: SITE_NAME,
      },
      twitter: {
        card: 'summary_large_image',
        title,
        description,
        images: [imageUrl],
      },
      alternates: {
        canonical: `${SITE_URL}/articles/${article.id}`,
      },
    }
  } catch {
    return { title: SITE_NAME }
  }
}

export default function ArticleLayout({ children }: { children: React.ReactNode }) {
  return children
}
