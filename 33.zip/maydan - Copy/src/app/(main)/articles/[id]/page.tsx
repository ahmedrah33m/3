'use client'

import { useEffect } from 'react'
import { useParams } from 'next/navigation'
import { useStore } from '@/lib/store'
import ArticleDetail from '@/components/ArticleDetail'
import { JsonLd } from '@/components/JsonLd'
import { generateArticleJsonLd } from '@/lib/seo'

export default function ArticleDetailPage() {
  const params = useParams()
  const id = params.id as string

  const store = useStore

  useEffect(() => {
    // Set the article ID in store for backward compatibility with ArticleDetail component
    store.setState({ currentArticleId: id })
  }, [id])

  const { articles, currentUser } = useStore.getState()
  const article = articles.find(a => a.id === id)

  return (
    <>
      {article && (
        <JsonLd data={generateArticleJsonLd({
          title: article.title,
          summary: article.summary,
          content: article.content,
          coverImage: article.coverImage,
          createdAt: article.createdAt,
          updatedAt: article.updatedAt,
          author: article.author ? {
            name: article.author.name,
            jobTitle: article.author.jobTitle,
            organization: article.author.organization,
          } : null,
          id: article.id,
        })} />
      )}
      <ArticleDetail />
    </>
  )
}
