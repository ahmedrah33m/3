'use client'

import { useEffect } from 'react'
import { useStore } from '@/lib/store'
import ArticleDetail from '@/components/ArticleDetail'

export default function ArticleDetailClient({ articleId }: { articleId: string }) {
  const store = useStore

  useEffect(() => {
    store.setState({ currentArticleId: articleId })
  }, [articleId])

  return <ArticleDetail />
}