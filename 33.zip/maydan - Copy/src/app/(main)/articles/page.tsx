'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { Search, Loader2 } from 'lucide-react'
import { type Article } from '@/lib/store'
import { Input } from '@/components/ui/input'
import { useStore } from '@/lib/store'
import { ArticleCard } from '@/components/ArticleCard'

const ITEMS_PER_PAGE = 20
const SEARCH_DEBOUNCE = 400

export default function ArticlesPage() {
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [serverSearch, setServerSearch] = useState('')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const observerRef = useRef<IntersectionObserver | null>(null)
  const { navigateTo } = useStore()

  // Fetch articles from server
  const fetchArticles = useCallback(async (pageNum: number, search: string, append: boolean) => {
    if (append) {
      setLoadingMore(true)
    } else {
      setLoading(true)
      setArticles([])
    }

    try {
      const params = new URLSearchParams({
        page: String(pageNum),
        limit: String(ITEMS_PER_PAGE),
      })
      if (search) {
        params.set('search', search)
      }

      const res = await fetch(`/api/articles?${params.toString()}`)
      const data = await res.json()

      if (res.ok) {
        const newArticles = data.articles || []
        const serverTotal = data.total || 0
        const serverPages = data.pages || Math.ceil(serverTotal / ITEMS_PER_PAGE)

        setTotal(serverTotal)
        setTotalPages(serverPages)

        if (append) {
          setArticles(prev => {
            const existingIds = new Set(prev.map(a => a.id))
            const unique = newArticles.filter((a: Article) => !existingIds.has(a.id))
            return [...prev, ...unique]
          })
        } else {
          setArticles(newArticles)
          setPage(1)
        }
      }
    } catch {
      // Keep existing articles on error
    }

    if (append) {
      setLoadingMore(false)
    } else {
      setLoading(false)
    }
  }, [])

  // Initial load and page change
  useEffect(() => {
    fetchArticles(1, serverSearch, false)
  }, [serverSearch])

  // Infinite scroll observer
  useEffect(() => {
    if (observerRef.current) {
      observerRef.current.disconnect()
    }

    const sentinel = document.getElementById('scroll-sentinel')
    if (!sentinel) return

    observerRef.current = new IntersectionObserver(
      (entries) => {
        const entry = entries[0]
        if (entry.isIntersecting && !loadingMore && page < totalPages) {
          const nextPage = page + 1
          setPage(nextPage)
          fetchArticles(nextPage, serverSearch, true)
        }
      },
      { rootMargin: '200px' }
    )

    observerRef.current.observe(sentinel)

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect()
      }
    }
  }, [loadingMore, page, totalPages, serverSearch, fetchArticles])

  // Search debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      setServerSearch(searchTerm.trim())
    }, SEARCH_DEBOUNCE)
    return () => clearTimeout(timer)
  }, [searchTerm])

  if (loading && articles.length === 0) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">المقالات</h1>
          {serverSearch && (
            <p className="text-sm text-muted-foreground mt-1">
              نتائج البحث: {total} مقال
            </p>
          )}
        </div>
        {total > 0 && !serverSearch && (
          <span className="text-sm text-muted-foreground">{total} مقال</span>
        )}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="ابحث في جميع المقالات..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="ps-9 pe-4"
        />
      </div>

      {/* Articles Grid — Consistent ArticleCard styling */}
      {articles.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">
          {serverSearch ? 'لا توجد نتائج مطابقة للبحث' : 'لا توجد مقالات'}
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {articles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>

          {/* Scroll Sentinel for Infinite Scroll */}
          <div id="scroll-sentinel" className="h-4" />

          {/* Loading more indicator */}
          {loadingMore && (
            <div className="flex items-center justify-center gap-2 py-6 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
              <span className="text-sm">جاري تحميل المزيد...</span>
            </div>
          )}

          {/* End of results */}
          {!loadingMore && articles.length >= total && total > 0 && (
            <p className="text-center text-sm text-muted-foreground py-4">
              تم عرض جميع المقالات ({total})
            </p>
          )}
        </div>
      )}
    </div>
  )
}
