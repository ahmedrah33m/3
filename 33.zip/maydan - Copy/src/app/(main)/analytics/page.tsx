'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  LineChart, Line, PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'
import {
  Users, FileText, Briefcase, MessageSquare,
  TrendingUp, Activity, BarChart3, Globe,
} from 'lucide-react'

/* ===== Types ===== */
interface AnalyticsData {
  totalUsers: number
  totalArticles: number
  totalDiscussions: number
  totalJobs: number
  activeUsersToday: number
  newUsersThisWeek: number
  newUsersThisMonth: number
  topCategories: { category: string; count: number }[]
  growthData: { date: string; count: number }[]
  contentDistribution: { type: string; count: number; label: string }[]
}

const BAR_COLORS = ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4']
const DISTRIBUTION_COLORS = ['#10b981', '#8b5cf6', '#f59e0b']

const categoryLabels: Record<string, string> = {
  ANALYSIS: 'تحليلات',
  REPORT: 'تقارير',
  STUDY: 'دراسات',
  OPINION: 'آراء',
  NEWS: 'أخبار',
  RESEARCH: 'أبحاث',
}

/* ===== Custom Tooltip ===== */
function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-popover border border-border rounded-lg shadow-xl p-3 min-w-[120px]">
      <p className="text-xs font-bold text-popover-foreground mb-1 border-b border-border pb-1">{label}</p>
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center justify-between gap-3 text-xs py-0.5">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: entry.color }} />
            {entry.name}
          </span>
          <span className="font-bold tabular-nums">{entry.value.toLocaleString('ar-IQ')}</span>
        </div>
      ))}
    </div>
  )
}

/* ===== Stat Card ===== */
function StatCard({ title, value, icon: Icon, color, subtitle }: { title: string; value: string | number; icon: React.ElementType; color: string; subtitle?: string }) {
  return (
    <Card className="relative overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow">
      <div className="absolute inset-0 bg-gradient-to-bl from-primary/5 via-transparent to-transparent" />
      <CardContent className="relative p-5">
        <div className="flex items-center justify-between mb-3">
          <div className={`p-2.5 rounded-xl ${color}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
        <p className="text-2xl font-bold tabular-nums">{typeof value === 'number' ? value.toLocaleString('ar-IQ') : value}</p>
        <p className="text-sm text-muted-foreground mt-1">{title}</p>
        {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
      </CardContent>
    </Card>
  )
}

/* ===== Pie Legend ===== */
function PieLegend({ data }: { data: { name: string; value: number; color: string }[] }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1
  return (
    <div className="space-y-2 mt-3">
      {data.map((item, i) => (
        <div key={i} className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
            <span className="text-muted-foreground">{item.name}</span>
          </span>
          <div className="flex items-center gap-2">
            <span className="font-bold">{item.value.toLocaleString('ar-IQ')}</span>
            <span className="text-xs text-muted-foreground">({Math.round((item.value / total) * 100)}%)</span>
          </div>
        </div>
      ))}
    </div>
  )
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/analytics/public')
      .then(r => r.json())
      .then(d => setData(d))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 w-64 bg-muted rounded" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-28 bg-muted rounded-xl" />
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="h-80 bg-muted rounded-xl" />
              <div className="h-80 bg-muted rounded-xl" />
            </div>
            <div className="h-80 bg-muted rounded-xl" />
          </div>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">تعذر تحميل الإحصائيات</p>
      </div>
    )
  }

  const contentDistribution = data.contentDistribution.map((c, i) => ({
    name: c.label,
    value: c.count,
    color: DISTRIBUTION_COLORS[i % DISTRIBUTION_COLORS.length],
  }))

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-bl from-primary/10 via-primary/5 to-background border-b">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="flex items-center gap-3 mb-2">
            <BarChart3 className="h-7 w-7 text-primary" />
            <h1 className="text-3xl font-bold">إحصائيات ميدان</h1>
          </div>
          <p className="text-muted-foreground text-sm">لوحة إحصائيات عامة تُظهر نشاط المنصة في الوقت الفعلي</p>

          {/* Active Users Banner */}
          <div className="mt-6 flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
            </span>
            <span className="text-sm font-medium text-emerald-700 dark:text-emerald-400">
              {data.activeUsersToday.toLocaleString('ar-IQ')} مستخدم نشط اليوم (آخر 24 ساعة)
            </span>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard
            title="إجمالي المستخدمين"
            value={data.totalUsers}
            icon={Users}
            color="bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400"
            subtitle={`+${data.newUsersThisMonth.toLocaleString('ar-IQ')} هذا الشهر`}
          />
          <StatCard
            title="المقالات المنشورة"
            value={data.totalArticles}
            icon={FileText}
            color="bg-amber-100 text-amber-600 dark:bg-amber-950 dark:text-amber-400"
          />
          <StatCard
            title="النقاشات"
            value={data.totalDiscussions}
            icon={MessageSquare}
            color="bg-purple-100 text-purple-600 dark:bg-purple-950 dark:text-purple-400"
          />
          <StatCard
            title="الوظائف المتاحة"
            value={data.totalJobs}
            icon={Briefcase}
            color="bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-400"
          />
        </div>

        {/* Growth Summary Row */}
        <div className="grid grid-cols-2 md:grid-cols-2 gap-4 mt-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-sky-100 dark:bg-sky-950">
                <TrendingUp className="h-4 w-4 text-sky-600 dark:text-sky-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">مسجلون هذا الأسبوع</p>
                <p className="text-lg font-bold">{data.newUsersThisWeek.toLocaleString('ar-IQ')}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-100 dark:bg-orange-950">
                <Activity className="h-4 w-4 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">مسجلون هذا الشهر</p>
                <p className="text-lg font-bold">{data.newUsersThisMonth.toLocaleString('ar-IQ')}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
          {/* 30-Day Growth Chart */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                نمو المستخدمين — آخر 30 يوم
                <Badge variant="secondary" className="text-xs me-auto">يومي</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={data.growthData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="lineGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                    tickLine={false}
                    axisLine={false}
                    interval="preserveStartEnd"
                    tickFormatter={(v: string) => v.slice(5)}
                  />
                  <YAxis
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip content={<ChartTooltip />} />
                  <Line
                    type="monotone"
                    dataKey="count"
                    name="تسجيلات جديدة"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 5, fill: '#10b981', stroke: 'white', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Content Distribution Pie */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Globe className="h-5 w-5 text-purple-600" />
                توزيع المحتوى
                <Badge variant="secondary" className="text-xs me-auto">حسب النوع</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-48 h-48 shrink-0">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={contentDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={75}
                        paddingAngle={3}
                        dataKey="value"
                        stroke="none"
                      >
                        {contentDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(value: number, name: string) => [value.toLocaleString('ar-IQ'), name]}
                        contentStyle={{ borderRadius: '8px', fontSize: '12px', direction: 'rtl', border: '1px solid hsl(var(--border))' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex-1 min-w-0">
                  <PieLegend data={contentDistribution} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Top Categories Bar Chart */}
          <Card className="border-0 shadow-sm lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-amber-600" />
                أعلى الفئات
                <Badge variant="secondary" className="text-xs me-auto">حسب عدد المقالات</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={data.topCategories.map((c, i) => ({
                    name: categoryLabels[c.category] || c.category,
                    count: c.count,
                    fill: BAR_COLORS[i % BAR_COLORS.length],
                  }))}
                  margin={{ top: 5, right: 10, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="count" name="عدد المقالات" radius={[6, 6, 0, 0]} maxBarSize={50}>
                    {data.topCategories.map((_, index) => (
                      <Cell key={`bar-${index}`} fill={BAR_COLORS[index % BAR_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <footer className="mt-12 pt-6 border-t border-border text-center">
          <p className="text-xs text-muted-foreground">
            إحصائيات ميدان — آخر تحديث: {new Date().toLocaleDateString('ar-IQ')}
          </p>
        </footer>
      </section>
    </div>
  )
}
