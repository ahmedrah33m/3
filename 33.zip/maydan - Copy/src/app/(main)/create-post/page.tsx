'use client'

import CreatePostView from '@/components/CreatePostView'

export default function CreatePostPage() {
  return <CreatePostView />
}
