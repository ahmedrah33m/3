'use client'

import WriteArticleView from '@/components/WriteArticleView'

export default function WritePage() {
  return <WriteArticleView />
}
