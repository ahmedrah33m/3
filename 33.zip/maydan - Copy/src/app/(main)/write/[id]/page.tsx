import WriteArticleView from '@/components/WriteArticleView'

interface PageProps {
  params: Promise<{ id: string }>
}

export default async function EditArticlePage({ params }: PageProps) {
  const { id } = await params
  return <WriteArticleView editId={id} />
}
