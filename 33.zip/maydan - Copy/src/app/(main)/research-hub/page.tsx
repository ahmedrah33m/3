'use client'

import ResearchHub from '@/components/ResearchHub'

export default function ResearchHubPage() {
  return <ResearchHub />
}
