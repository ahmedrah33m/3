'use client'

import OwnerPanel from '@/components/OwnerPanel'
import { OwnerGate } from '@/components/RoleGate'

export default function OwnerPanelPage() {
  return (
    <OwnerGate>
      <OwnerPanel />
    </OwnerGate>
  )
}
