'use client'
import AIAssistantView from '@/components/AIAssistantView'
export default function AIAssistantPage() {
  return <AIAssistantView />
}
