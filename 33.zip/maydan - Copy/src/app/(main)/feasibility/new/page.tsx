'use client'

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ArrowRight, Loader2, Rocket, Sparkles } from 'lucide-react'
import { GlassCard } from '@/components/ui/glass-card'
import { Button } from '@/components/ui/button'
import { GlassInput } from '@/components/ui/glass-input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { post, get } from '@/components/feasibility/FeasibilityApi'

interface TemplateInfo {
  key: string
  name: string
  emoji: string
  tagline: string
  projectType: string
  sector: string
  governorate: string | null
  description: string
}

export default function NewStudyPage() {
  return (
    <Suspense fallback={<div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل...</div>}>
      <NewStudyForm />
    </Suspense>
  )
}

function NewStudyForm() {
  const router = useRouter()
  const params = useSearchParams()
  const presetKey = params.get('template')
  const [templates, setTemplates] = useState<TemplateInfo[]>([])
  const [selected, setSelected] = useState<string>(presetKey ?? '')
  const [name, setName] = useState('')
  const [governorate, setGovernorate] = useState('')
  const [description, setDescription] = useState('')
  const [projectType, setProjectType] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    void (async () => {
      const res = await get<{ templates: TemplateInfo[] }>('/api/feasibility/templates')
      if (res.ok && res.data?.templates) setTemplates(res.data.templates)
    })()
  }, [])

  const effective = templates.find((t) => t.key === selected)
  const displayName = name.trim() || effective?.name || ''

  const handleTemplate = (key: string) => {
    setSelected(key)
    const t = templates.find((x) => x.key === key)
    if (t) {
      setProjectType(t.projectType)
      if (t.governorate) setGovernorate(t.governorate)
    }
  }

  const create = async () => {
    setBusy(true)
    setError(null)
    const res = await post<{ study: { id: string } }>('/api/feasibility', {
      name: displayName || 'مشروعي',
      description: description.trim() || effective?.description || null,
      templateKey: selected || null,
      projectType: projectType || undefined,
      governorate: governorate || undefined,
    })
    setBusy(false)
    if (res.ok && res.data?.study) {
      router.push(`/feasibility/${res.data.study.id}`)
    } else {
      setError((res.data as { error?: string } | null)?.error ?? 'تعذر إنشاء الدراسة.')
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div>
        <h1 className="text-xl font-extrabold">دراسة جدوى جديدة</h1>
        <p className="text-sm text-muted-foreground">اختر قالبًا جاهزًا لتُملأ 80% من الأرقام مسبقًا، أو ابدأ من الصفر.</p>
      </div>

      {/* القوالب */}
      <div className="grid gap-3 sm:grid-cols-2">
        <GlassCard
          variant={selected === '' ? 'gradient' : 'flat'}
          size="sm"
          hoverable
          onClick={() => handleTemplate('')}
          className="cursor-pointer"
        >
          <div className="flex items-start gap-3">
            <Sparkles className="size-6 shrink-0 text-primary" />
            <div>
              <h3 className="font-bold">قالب مخصص من الصفر</h3>
              <p className="text-sm text-muted-foreground">أدخل كل شيء يدويًا — أنسب للخبراء.</p>
            </div>
          </div>
        </GlassCard>
        {templates.map((t) => (
          <GlassCard
            key={t.key}
            variant={selected === t.key ? 'gradient' : 'flat'}
            size="sm"
            hoverable
            onClick={() => handleTemplate(t.key)}
            className="cursor-pointer"
          >
            <div className="flex items-start gap-3">
              <span className="text-3xl">{t.emoji}</span>
              <div>
                <h3 className="font-bold">{t.name}</h3>
                <p className="text-xs text-muted-foreground">{t.tagline}</p>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* النموذج */}
      <GlassCard size="md">
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="name">اسم الدراسة</Label>
            <GlassInput id="name" dir="rtl" placeholder={effective ? effective.name : 'مثال: معمل الشامبو في بغداد'} value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>المحافظة</Label>
              <GlassInput dir="rtl" placeholder="بغداد" value={governorate} onChange={(e) => setGovernorate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>نوع المشروع</Label>
              <GlassInput dir="rtl" placeholder="مطعم / معمل / خدمات..." value={projectType} onChange={(e) => setProjectType(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="description">وصف مختصر</Label>
            <Textarea id="description" dir="rtl" className="min-h-20" placeholder="فكرة المشروع في سطرين يجري عليها الفهم الذكي لاحقًا..." value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>

          {effective ? (
            <p className="rounded-xl bg-primary/5 p-3 text-xs leading-6 text-muted-foreground">
              سيُعبأ القالب «{effective.name}» بقيم بداية منطقية (منتجات، استثمار، تشغيل، تمويل) — كلها قابلة للتعديل، ومصدرها موثق في سجل الافتراضات.
            </p>
          ) : null}

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <div className="flex justify-end gap-2 border-t border-white/10 pt-4">
            <Button variant="outline" onClick={() => router.push('/feasibility/my-studies')} disabled={busy}>
              إلغاء
            </Button>
            <Button onClick={create} disabled={busy || !displayName}>
              {busy ? <Loader2 className="size-4 animate-spin" /> : <Rocket className="size-4" />}
              إنشاء والبدء
              <ArrowRight className="size-4" />
            </Button>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}