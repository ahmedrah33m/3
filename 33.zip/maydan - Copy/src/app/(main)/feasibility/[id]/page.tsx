import { Suspense } from 'react'
import { Skeleton } from '@/components/ui/skeleton'
import { FeasibilityHub } from '@/components/feasibility/FeasibilityHub'

export default async function FeasibilityStudyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return (
    <Suspense fallback={<Skeleton className="h-[60vh] w-full" />}>
      <FeasibilityHub studyId={id} />
    </Suspense>
  )
}