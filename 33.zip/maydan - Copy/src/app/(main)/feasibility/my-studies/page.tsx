'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Plus, Trash2, FolderOpen, Loader2, CalendarDays, ChevronLeft } from 'lucide-react'
import { GlassCard } from '@/components/ui/glass-card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { get, del } from '@/components/feasibility/FeasibilityApi'

interface StudyRow {
  id: string
  name: string
  projectType: string
  status: string
  currency: string
  templateKey?: string | null
  updatedAt: string
}

const STATUS_LABEL: Record<string, string> = {
  DRAFT: 'مسودة',
  IN_PROGRESS: 'قيد الإدخال',
  COMPLETE: 'مكتملة',
  COMPUTED: 'محسوبة',
  VALIDATED: 'محققة',
  ARCHIVED: 'مؤرشفة',
}

const TYPE_EMOJI: Record<string, string> = {
  RESTAURANT: '🍽️', CAFE: '☕', RETAIL: '🏬', MANUFACTURING: '🏭', AGRICULTURE: '🌾',
  SERVICES: '🛠️', TECH: '💻', MEDICAL: '⚕️', CONSTRUCTION: '🏗️', EDUCATION: '🎓', OTHER: '📦',
}

export default function MyStudiesPage() {
  const router = useRouter()
  const [rows, setRows] = useState<StudyRow[] | null>(null)
  const [deleting, setDeleting] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    const res = await get<{ studies: StudyRow[] }>('/api/feasibility')
    if (res.ok && res.data?.studies) setRows(res.data.studies)
    else setRows([])
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const remove = async (id: string) => {
    setDeleting(id)
    const res = await del(`/api/feasibility/${id}`)
    setDeleting(null)
    if (res.ok) setRows((r) => (r ?? []).filter((s) => s.id !== id))
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold">دراساتي</h1>
          <p className="text-sm text-muted-foreground">نموذج مالي كامل لكل مشروع — بدايته من هنا.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="outline" size="sm">
            <Link href="/feasibility"><ChevronLeft className="size-4" />دراسة الجدوى</Link>
          </Button>
          <Button asChild size="sm">
            <Link href="/feasibility/new"><Plus className="size-4" />دراسة جديدة</Link>
          </Button>
        </div>
      </div>

      {error ? <p className="text-sm text-destructive">{error}</p> : null}

      {rows === null ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-36" />)}
        </div>
      ) : rows.length === 0 ? (
        <GlassCard className="p-10 text-center">
          <FolderOpen className="mx-auto size-10 text-primary" />
          <h3 className="mt-3 text-lg font-bold">لا توجد دراسات بعد</h3>
          <p className="mt-1 text-sm text-muted-foreground">ابدأ أول دراسة: اختر قالبًا جاهزًا أو ابدأ من الصفر.</p>
          <Button asChild className="mt-4">
            <Link href="/feasibility/new"><Plus className="size-4" />إنشاء دراسة</Link>
          </Button>
        </GlassCard>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((s) => (
            <GlassCard key={s.id} variant="interactive" size="md" className="flex h-full flex-col justify-between" onClick={() => router.push(`/feasibility/${s.id}`)}>
              <div>
                <div className="flex items-start justify-between gap-2">
                  <span className="text-3xl">{TYPE_EMOJI[s.projectType] ?? TYPE_EMOJI.OTHER}</span>
                  <Badge variant={s.status === 'COMPUTED' ? 'success' : 'outline'}>{STATUS_LABEL[s.status] ?? s.status}</Badge>
                </div>
                <h3 className="mt-2 font-bold">{s.name}</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">{s.projectType}</p>
              </div>
              <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <CalendarDays className="size-3.5" />
                  {new Date(s.updatedAt).toLocaleDateString('ar-IQ', { year: 'numeric', month: 'short', day: 'numeric' })}
                </span>
                <button
                  className="flex items-center gap-1 rounded-lg p-1 text-destructive transition-colors hover:bg-destructive/10"
                  onClick={(e) => {
                    e.stopPropagation()
                    void remove(s.id)
                  }}
                  disabled={deleting === s.id}
                  aria-label="حذف الدراسة"
                >
                  {deleting === s.id ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  )
}