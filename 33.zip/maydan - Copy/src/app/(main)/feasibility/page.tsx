import Link from 'next/link'
import { Calculator, ListChecks, Rocket, ShieldCheck, Wand2 } from 'lucide-react'
import { GlassCard } from '@/components/ui/glass-card'
import { Button } from '@/components/ui/button'
import { templateCatalog } from '@/services/feasibility.service'

export const metadata = {
  title: 'دراسة الجدوى',
  description: 'ميدان لأداة دراسة الجدوى الذكية — أدخل بيانات مشروعك واحصل على نموذج مالي كامل (NPV، IRR، ROI، نقطة تعادل) عبر محرك مالي مستقل.',
}

const FEATURES = [
  { icon: Calculator, title: 'محرك مالي مستقل', text: 'كل الأرقام (NPV/IRR/الاسترداد/التعادل) تُحسب برمجيًا من مدخلاتك حصرًا — لا أرقام مفترضة.' },
  { icon: Wand2, title: 'فهم ذكي للفكرة', text: 'اكتب فكرتك بلغة طبيعية ويقترح النظام النوع والموقع والمنتجات قبل أن تحفظ الأرقام.' },
  { icon: ListChecks, title: '9 خطوات منظمة', text: 'مسيرة واضحة: المشروع ← الفكرة ← نموذج العمل ← المنتجات ← الطاقة ← الاستثمار ← التشغيل ← الكوادر ← التمويل.' },
  { icon: ShieldCheck, title: 'سجل افتراضات', text: 'توثيق مصدر كل رقم (إدخالك / افتراضي / محسوب) حتى يبقى القرار شفافًا وقابلاً للمراجعة.' },
]

export default function FeasibilityLandingPage() {
  const templates = templateCatalog()
  return (
    <div className="space-y-6">
      {/* البطل */}
      <GlassCard variant="gradient" size="xl">
        <div className="grid items-center gap-6 lg:grid-cols-2">
          <div>
            <h1 className="text-3xl font-black">دراسة الجدوى الذكية</h1>
            <p className="mt-3 max-w-lg leading-8 text-muted-foreground">
              حوّل فكرة مشروعك إلى نموذج مالي كامل بالدينار العراقي: رأس المال المطلوب، نقطة التعادل،
              صافي القيمة الحالية، معدل العائد، وفجوة التمويل — عبر محرك مالي مستقل لا يستخدم إلا أرقامك.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link href="/feasibility/new">
                  <Rocket className="size-5" />
                  ابدأ دراسة جديدة
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/feasibility/my-studies">دراساتي</Link>
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <StatCard big label="المحافظات العراقية" value="18" />
            <StatCard big label="قوالب جاهزة" value={String(templates.length)} />
            <StatCard label="أفق الإسقاط" value="حتى 10 سنوات" />
            <StatCard label="العملة" value="د.ع / $ / €" />
          </div>
        </div>
      </GlassCard>

      {/* المزايا */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((f) => (
          <GlassCard key={f.title} size="sm" className="h-full">
            <f.icon className="size-6 text-primary" />
            <h3 className="mt-2 font-bold">{f.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
          </GlassCard>
        ))}
      </div>

      {/* القوالب */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-extrabold">ابدأ من قالب جاهز</h2>
          <Link href="/feasibility/new" className="text-sm text-primary hover:underline">
            عرض الكل
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {templates.map((t) => (
            <Link key={t.key} href={{ pathname: '/feasibility/new', query: { template: t.key } }}>
              <GlassCard variant="interactive" size="md" className="h-full">
                <div className="flex items-start justify-between">
                  <span className="text-3xl">{t.emoji}</span>
                  <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-[11px] font-medium text-primary">{t.tagline}</span>
                </div>
                <h3 className="mt-2 font-bold">{t.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{t.description}</p>
                <p className="mt-2 text-xs text-muted-foreground">
                  {t.sector} {t.governorate ? `• ${t.governorate}` : ''}
                </p>
              </GlassCard>
            </Link>
          ))}
          <Link href="/feasibility/new">
            <GlassCard variant="interactive" size="md" className="flex h-full min-h-40 items-center justify-center">
              <div className="text-center">
                <Rocket className="mx-auto size-8 text-primary" />
                <p className="mt-2 font-bold">قالب مخصص</p>
                <p className="text-sm text-muted-foreground">من الصفر</p>
              </div>
            </GlassCard>
          </Link>
        </div>
      </div>
    </div>
  )
}

function StatCard({ label, value, big = false }: { label: string; value: string; big?: boolean }) {
  return (
    <GlassCard variant="flat" size="sm" className="justify-center h-full">
      <p className={`${big ? 'text-2xl font-black' : 'text-base font-bold'} text-primary`}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </GlassCard>
  )
}