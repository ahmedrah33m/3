'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PayrollTable, PayrollStatusBadge, formatCurrency, formatDate } from '@/components/payroll/payroll-ui';
import { Clock, Calendar, FileText, TrendingUp } from 'lucide-react';

interface MyPayrollData {
  payslips: Array<{
    id: string;
    payslipNumber: string;
    periodName: string;
    netSalary: number;
    grossSalary: number;
    status: string;
    generatedAt: string;
  }>;
  attendance: {
    summary: {
      total: number;
      present: number;
      absent: number;
      late: number;
      onLeave: number;
      overtimeHours: number;
    };
  };
  leaveBalance: Array<{
    policyId: string;
    name: string;
    type: string;
    totalDays: number;
    usedDays: number;
    remainingDays: number;
  }>;
  overtime: {
    summary: {
      total: number;
      approved: number;
      pending: number;
      rejected: number;
      totalHours: number;
      totalAmount: number;
    };
  };
}

export default function MyPayrollPage() {
  const [selectedPeriod, setSelectedPeriod] = useState<string>('');

  const { data, isLoading } = useQuery({
    queryKey: ['my-payroll'],
    queryFn: async () => {
      const [payslipsRes, attendanceRes, leaveRes, overtimeRes] = await Promise.all([
        fetch('/api/payroll/my-payslips'),
        fetch('/api/payroll/my-attendance'),
        fetch('/api/payroll/my-leave'),
        fetch('/api/payroll/my-overtime'),
      ]);
      const payslips = await payslipsRes.json();
      const attendance = await attendanceRes.json();
      const leave = await leaveRes.json();
      const overtime = await overtimeRes.json();
      return { payslips: payslips.data, attendance: attendance.data, leave: leave.data, overtime: overtime.data };
    },
  });

  const myData: MyPayrollData = (data || {
    payslips: [],
    attendance: { summary: { total: 0, present: 0, absent: 0, late: 0, onLeave: 0, overtimeHours: 0 } },
    leaveBalance: [],
    overtime: { summary: { total: 0, approved: 0, pending: 0, rejected: 0, totalHours: 0, totalAmount: 0 } },
  }) as MyPayrollData;

  if (isLoading) {
    return <MyPayrollSkeleton />;
  }

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <h1 className="text-3xl font-bold">راتبي ومعلوماتي</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الراتب الأخير</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(myData.payslips[0]?.netSalary || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {myData.payslips[0]?.periodName || 'لا يوجد'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">أيام الحضور</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{myData.attendance.summary.present}</div>
            <p className="text-xs text-muted-foreground">
              من أصل {myData.attendance.summary.total} يوم
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">ساعات الإضافي</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{myData.overtime.summary.totalHours.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">
              {formatCurrency(myData.overtime.summary.totalAmount)}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">رصيد الإجازات</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {myData.leaveBalance.reduce((sum, l) => sum + l.remainingDays, 0)}
            </div>
            <p className="text-xs text-muted-foreground">يوم متاح</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payslips" className="w-full">
        <TabsList>
          <TabsTrigger value="payslips">قسائم الراتب</TabsTrigger>
          <TabsTrigger value="attendance">الحضور</TabsTrigger>
          <TabsTrigger value="leave">الإجازات</TabsTrigger>
          <TabsTrigger value="overtime">الإضافي</TabsTrigger>
        </TabsList>

        <TabsContent value="payslips">
          <Card>
            <CardHeader>
              <CardTitle>قسائم الراتب</CardTitle>
            </CardHeader>
            <CardContent>
              <PayrollTable
                headers={['رقم القسيمة', 'الفترة', 'الصافي', 'الإجمالي', 'الحالة', 'التاريخ']}
                emptyMessage="لا توجد قسائم راتب"
              >
                {myData.payslips.map((payslip) => (
                  <tr key={payslip.id} className="border-b transition-colors hover:bg-muted/50">
                    <td className="p-4 align-middle font-mono text-xs">{payslip.payslipNumber}</td>
                    <td className="p-4 align-middle">{payslip.periodName}</td>
                    <td className="p-4 align-middle font-medium">{formatCurrency(payslip.netSalary)}</td>
                    <td className="p-4 align-middle">{formatCurrency(payslip.grossSalary)}</td>
                    <td className="p-4 align-middle">
                      <PayrollStatusBadge status={payslip.status} />
                    </td>
                    <td className="p-4 align-middle text-xs">{formatDate(payslip.generatedAt)}</td>
                  </tr>
                ))}
              </PayrollTable>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leave">
          <Card>
            <CardHeader>
              <CardTitle>رصيد الإجازات</CardTitle>
            </CardHeader>
            <CardContent>
              <PayrollTable
                headers={['نوع الإجازة', 'السنوية', 'المستخدمة', 'المتبقية']}
                emptyMessage="لا توجد إجازات مسجلة"
              >
                {myData.leaveBalance.map((leave) => (
                  <tr key={leave.policyId} className="border-b transition-colors hover:bg-muted/50">
                    <td className="p-4 align-middle">{leave.name}</td>
                    <td className="p-4 align-middle">{leave.totalDays}</td>
                    <td className="p-4 align-middle">{leave.usedDays}</td>
                    <td className="p-4 align-middle font-medium">{leave.remainingDays}</td>
                  </tr>
                ))}
              </PayrollTable>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MyPayrollSkeleton() {
  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="h-10 w-48 bg-muted rounded animate-pulse" />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-24 bg-muted rounded animate-pulse" />
        ))}
      </div>
      <div className="h-64 bg-muted rounded animate-pulse" />
    </div>
  );
}
