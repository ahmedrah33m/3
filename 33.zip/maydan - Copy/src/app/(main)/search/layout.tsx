import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'البحث | ميدان',
  description: 'ابحث في منصة ميدان عن المقالات والنقاشات والخبراء والوظائف.',
  robots: {
    index: false,
    follow: true,
  },
  openGraph: {
    title: 'البحث | ميدان',
    description: 'ابحث في منصة ميدان عن المقالات والنقاشات والخبراء والوظائف.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/search`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'البحث | ميدان',
    description: 'ابحث في منصة ميدان عن المقالات والنقاشات والخبراء والوظائف.',
  },
  alternates: {
    canonical: `${SITE_URL}/search`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
