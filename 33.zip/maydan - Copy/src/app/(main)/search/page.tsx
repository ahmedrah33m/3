'use client'

import AdvancedSearchPage from '@/components/AdvancedSearchView'

export default function SearchPage() {
  return <AdvancedSearchPage />
}
