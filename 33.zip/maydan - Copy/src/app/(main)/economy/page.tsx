'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'

const MarketPricesView = dynamic(() => import('@/components/MarketPricesView'), {
  loading: () => <Skeleton className="h-64 w-full rounded-2xl" />,
})

const CurrencyConverter = dynamic(() => import('@/components/CurrencyConverter'), {
  loading: () => <Skeleton className="h-64 w-full rounded-2xl" />,
})

const EconomicCalendarView = dynamic(() => import('@/components/EconomicCalendarView'), {
  loading: () => <Skeleton className="h-64 w-full rounded-2xl" />,
})

const GisMapPage = dynamic(() => import('@/components/map/GisMapPage'), {
  loading: () => <Skeleton className="h-[calc(100vh-16rem)] min-h-[540px] rounded-3xl" />,
})

export default function EconomyMarketPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">اقتصاد السوق</h1>
        <p className="text-sm text-muted-foreground">أسعار السوق العراقية، محول العملات، التقويم الاقتصادي، وخريطة الاقتصاد في صفحة واحدة</p>
      </div>
      <Tabs defaultValue="market" className="w-full">
        <TabsList className="h-10 w-full flex-wrap justify-start overflow-x-auto">
          <TabsTrigger value="market">أسعار السوق</TabsTrigger>
          <TabsTrigger value="converter">محول العملات</TabsTrigger>
          <TabsTrigger value="calendar">التقويم الاقتصادي</TabsTrigger>
          <TabsTrigger value="map">خريطة الاقتصاد</TabsTrigger>
        </TabsList>
        <TabsContent value="market" className="mt-4">
          <MarketPricesView />
        </TabsContent>
        <TabsContent value="converter" className="mt-4">
          <CurrencyConverter />
        </TabsContent>
        <TabsContent value="calendar" className="mt-4">
          <EconomicCalendarView />
        </TabsContent>
        <TabsContent value="map" className="mt-4">
          <GisMapPage />
        </TabsContent>
      </Tabs>
    </div>
  )
}