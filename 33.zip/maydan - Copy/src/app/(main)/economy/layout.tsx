import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الأدوات الاقتصادية | ميدان',
  description: 'أدوات تحليل الاقتصاد العراقي: أسعار السوق، المؤشرات، التقويم، الخريطة، الرسوم البيانية، المساعد الذكي، الأكاديمية، الفرص الاستثمارية، سوق الخبراء',
  openGraph: {
    title: 'الأدوات الاقتصادية | ميدان',
    description: 'أدوات تحليل الاقتصاد العراقي شاملة: بيانات حية، تحليلات، تعليم، واستشارات',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/economy`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الأدوات الاقتصادية | ميدان',
    description: 'أدوات تحليل الاقتصاد العراقي شاملة',
  },
  alternates: {
    canonical: `${SITE_URL}/economy`,
  },
}

export default function EconomyLayout({ children }: { children: React.ReactNode }) {
  return children
}
