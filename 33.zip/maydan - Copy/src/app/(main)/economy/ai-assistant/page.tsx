import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /economy/ai-assistant يعرض نفس AIAssistantView الموجود في /ai-assistant — نُوجّه إليه */
export default function EconomyAIAssistantPage() {
  redirect('/ai-assistant')
}