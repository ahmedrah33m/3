'use client'

import EconomicIntelligence from '@/components/EconomicIntelligence'

export default function IndicatorsPage() {
  return <EconomicIntelligence />
}