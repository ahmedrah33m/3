import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'التنبيه الاقتصادي | ميدان',
  description: 'لوحة مؤشرات الاقتصاد العراقي، تنبيهات آلية ونبض يومي. الناتج المحلي، التضخم، البطالة والتجارة الخارجية.',
  openGraph: {
    title: 'التنبيه الاقتصادي | ميدان',
    description: 'لوحة مؤشرات الاقتصاد العراقي، تنبيهات آلية ونبض يومي. الناتج المحلي، التضخم، البطالة والتجارة الخارجية.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/economic`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'التنبيه الاقتصادي | ميدان',
    description: 'لوحة مؤشرات الاقتصاد العراقي، تنبيهات آلية ونبض يومي. الناتج المحلي، التضخم، البطالة والتجارة الخارجية.',
  },
  alternates: {
    canonical: `${SITE_URL}/economic`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
