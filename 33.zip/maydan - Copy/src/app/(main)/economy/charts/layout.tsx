import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الرسوم البيانية الاقتصادية | ميدان',
  description: 'رسوم بيانية تفاعلية للبيانات الاقتصادية العراقية. تحليلات مرئية للسوق والعملات.',
  openGraph: {
    title: 'الرسوم البيانية الاقتصادية | ميدان',
    description: 'رسوم بيانية تفاعلية للبيانات الاقتصادية العراقية. تحليلات مرئية للسوق والعملات.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/economy/charts`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الرسوم البيانية الاقتصادية | ميدان',
    description: 'رسوم بيانية تفاعلية للبيانات الاقتصادية العراقية. تحليلات مرئية للسوق والعملات.',
  },
  alternates: {
    canonical: `${SITE_URL}/economy/charts`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
