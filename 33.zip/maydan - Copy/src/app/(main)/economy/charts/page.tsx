'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'
import { useI18n } from '@/lib/i18n'

const InteractiveChartsView = dynamic(() => import('@/components/InteractiveChartsView'), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-10 w-full rounded-lg" />
      <div className="flex gap-2">
        <Skeleton className="h-8 w-28" />
        <Skeleton className="h-8 w-20" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
      <Skeleton className="h-[400px] rounded-lg" />
    </div>
  ),
})

export default function ChartsPage() {
  const { t } = useI18n()
  const tv = t.economy.chartsView
  return (
    <div className="max-w-[1600px] mx-auto space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">{tv.title}</h1>
          <p className="text-sm text-muted-foreground">{tv.subtitle}</p>
        </div>
      </div>
      <InteractiveChartsView />
    </div>
  )
}
