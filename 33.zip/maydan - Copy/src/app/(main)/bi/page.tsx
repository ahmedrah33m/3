import { requireAuth, hasRole } from '@/lib/session'
import { db } from '@/lib/db'
import { getCompanyBI, getPlatformBI } from '@/services/bi.service'
import BusinessIntelligence from '@/components/BusinessIntelligence'

const ADMIN_ROLES = ['OWNER', 'ADMIN', 'MODERATOR']

export default async function BiPage() {
  const user = await requireAuth()
  const isAdmin = hasRole(user, ADMIN_ROLES)
  let platform: any = null
  let companies: { id: string; name: string }[] = []
  let initialCompanyData: any = null
  let initialCompanyId: string | null = null

  if (isAdmin) {
    platform = await getPlatformBI()
    companies = await db.company.findMany({ select: { id: true, name: true }, take: 200 })
  } else {
    const comp = await db.company.findUnique({ where: { ownerId: user.id }, select: { id: true } })
    if (comp) {
      initialCompanyId = comp.id
      initialCompanyData = await getCompanyBI(comp.id)
    }
  }

  return (
    <div className="max-w-5xl mx-auto py-6" dir="rtl">
      <h1 className="text-2xl font-bold mb-4">Business Intelligence — ذكاء الأعمال</h1>
      <BusinessIntelligence platform={platform} companies={companies} isAdmin={isAdmin} initialCompanyData={initialCompanyData} initialCompanyId={initialCompanyId} />
    </div>
  )
}
