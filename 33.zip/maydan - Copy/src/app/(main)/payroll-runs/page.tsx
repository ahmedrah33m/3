'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PayrollTable, PayrollStatusBadge, PayrollActionButtons, formatCurrency, formatDate } from '@/components/payroll/payroll-ui';
import { Plus, Eye, Edit, Trash2 } from 'lucide-react';

interface PayrollRunsData {
  runs: Array<{
    id: string;
    name: string;
    status: string;
    totalEmployees: number;
    totalNet: number;
    totalGross: number;
    runDate: string;
    payrollPeriod: { name: string };
    _count: { payrollEmployees: number };
  }>;
}

export default function PayrollRunsPage() {
  const [selectedRun, setSelectedRun] = useState<string>('');

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['payroll-runs'],
    queryFn: async () => {
      const res = await fetch('/api/payroll/runs?companyId=comp-1');
      return res.json();
    },
  });

  const runsData: PayrollRunsData = data || { runs: [] };

  const handleCalculate = async (runId: string) => {
    await fetch(`/api/payroll/runs/${runId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'calculate' }),
    });
    refetch();
  };

  const handleSubmitForReview = async (runId: string) => {
    await fetch(`/api/payroll/runs/${runId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'submit-for-review' }),
    });
    refetch();
  };

  const handleApprove = async (runId: string) => {
    await fetch(`/api/payroll/runs/${runId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'approve' }),
    });
    refetch();
  };

  const handleProcessPayments = async (runId: string) => {
    await fetch(`/api/payroll/runs/${runId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'process-payments' }),
    });
    refetch();
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">تشغيلات الرواتب</h1>
        <Button>
          <Plus className="ml-2 h-4 w-4" />
          تشغيل جديد
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة التشغيلات</CardTitle>
        </CardHeader>
        <CardContent>
          <PayrollTable
            headers={['التشغيل', 'الفترة', 'الحالة', 'الموظفين', 'الإجمالي', 'الصنديق', 'الإجراءات']}
            emptyMessage="لا توجد تشغيلات رواتب"
          >
            {runsData.runs.map((run) => (
              <tr key={run.id} className="border-b transition-colors hover:bg-muted/50">
                <td className="p-4 align-middle font-medium">{run.name}</td>
                <td className="p-4 align-middle">{run.payrollPeriod?.name}</td>
                <td className="p-4 align-middle">
                  <PayrollStatusBadge status={run.status} />
                </td>
                <td className="p-4 align-middle">{run.totalEmployees}</td>
                <td className="p-4 align-middle">{formatCurrency(run.totalGross)}</td>
                <td className="p-4 align-middle font-bold">{formatCurrency(run.totalNet)}</td>
                <td className="p-4 align-middle">
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <PayrollActionButtons
                      status={run.status}
                      onCalculate={() => handleCalculate(run.id)}
                      onSubmitForReview={() => handleSubmitForReview(run.id)}
                      onApprove={() => handleApprove(run.id)}
                      onProcessPayments={() => handleProcessPayments(run.id)}
                    />
                  </div>
                </td>
              </tr>
            ))}
          </PayrollTable>
        </CardContent>
      </Card>
    </div>
  );
}
