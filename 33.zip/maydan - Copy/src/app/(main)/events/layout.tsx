import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الفعاليات الاقتصادية | ميدان',
  description: 'اكتشف أهم المؤتمرات والندوات والورش والدورات التدريبية الاقتصادية في Iraq. سجّل الآن واحصل على شهادات معتمدة.',
  openGraph: {
    title: 'الفعاليات الاقتصادية | ميدان',
    description: 'اكتشف أهم المؤتمرات والندوات والورش والدورات التدريبية الاقتصادية في العراق.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/events`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary_large_image',
    title: 'الفعاليات الاقتصادية | ميدان',
    description: 'اكتشف أهم المؤتمرات والندوات والورش والدورات التدريبية الاقتصادية في العراق.',
  },
  alternates: {
    canonical: `${SITE_URL}/events`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
