import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الأسئلة والأجوبة الاقتصادية | ميدان',
  description: 'اطرح أسئلتك الاقتصادية واحصل على إجابات من خبراء ومتخصصين في المنصة.',
  openGraph: {
    title: 'الأسئلة والأجوبة الاقتصادية | ميدان',
    description: 'اطرح أسئلتك الاقتصادية واحصل على إجابات من خبراء ومتخصصين في المنصة.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/questions`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الأسئلة والأجوبة الاقتصادية | ميدان',
    description: 'اطرح أسئلتك الاقتصادية واحصل على إجابات من خبراء ومتخصصين في المنصة.',
  },
  alternates: {
    canonical: `${SITE_URL}/questions`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
