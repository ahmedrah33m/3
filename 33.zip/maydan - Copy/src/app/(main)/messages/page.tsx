import MessagesHub, { type MessagesTab } from '@/components/MessagesHub'

export default async function MessagesPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string }>
}) {
  const { tab } = await searchParams
  const valid: MessagesTab[] = ['messages', 'rooms']
  const defaultTab = valid.includes(tab as MessagesTab) ? (tab as MessagesTab) : 'messages'
  return <MessagesHub defaultTab={defaultTab} />
}