'use client'

import FileManager from '@/components/FileManager'

export default function FilesPage() {
  return <FileManager />
}
