'use client'

import { useEffect } from 'react'
import { useParams } from 'next/navigation'
import { useStore } from '@/lib/store'
import DiscussionDetail from '@/components/DiscussionDetail'

export default function DiscussionDetailPage() {
  const params = useParams()
  const id = params.id as string

  useEffect(() => {
    // Set the discussion ID in store for backward compatibility
    useStore.setState({ currentDiscussionId: id })
  }, [id])

  return <DiscussionDetail />
}
