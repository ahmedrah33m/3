'use client'

import { useEffect } from 'react'
import { useStore } from '@/lib/store'
import DiscussionDetail from '@/components/DiscussionDetail'

export default function DiscussionDetailClient({ discussionId }: { discussionId: string }) {
  useEffect(() => {
    useStore.setState({ currentDiscussionId: discussionId })
  }, [discussionId])

  return <DiscussionDetail />
}