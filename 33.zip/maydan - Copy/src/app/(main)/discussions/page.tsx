import DiscussionsHub, { type DiscussionsTab } from '@/components/DiscussionsHub'

export default async function DiscussionsPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string }>
}) {
  const { tab } = await searchParams
  const valid: DiscussionsTab[] = ['discussions', 'questions', 'polls']
  const defaultTab = valid.includes(tab as DiscussionsTab) ? (tab as DiscussionsTab) : 'discussions'
  return <DiscussionsHub defaultTab={defaultTab} />
}