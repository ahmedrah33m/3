import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'النقاشات الاقتصادية | ميدان',
  description: 'شارك في النقاشات الاقتصادية مع خبراء ومتخصصين. آراء وتحليلات حول الوضع الاقتصادي في العراق.',
  openGraph: {
    title: 'النقاشات الاقتصادية | ميدان',
    description: 'شارك في النقاشات الاقتصادية مع خبراء ومتخصصين. آراء وتحليلات حول الوضع الاقتصادي في العراق.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/discussions`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'النقاشات الاقتصادية | ميدان',
    description: 'شارك في النقاشات الاقتصادية مع خبراء ومتخصصين. آراء وتحليلات حول الوضع الاقتصادي في العراق.',
  },
  alternates: {
    canonical: `${SITE_URL}/discussions`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
