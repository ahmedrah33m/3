'use client'

import { useEffect, useState } from 'react'
import { useStore } from '@/lib/store'
import { useI18n } from '@/lib/i18n'
import { UserCheck, UserX, Users, Loader2 } from 'lucide-react'
import { GlassCard } from '@/components/ui/glass-card'
import { Badge } from '@/components/ui/badge'
import { GlassButton } from '@/components/ui/glass-button'
import { GlassAvatar, GlassAvatarImage, GlassAvatarFallback } from '@/components/ui/glass-avatar'
import { useToast } from '@/hooks/use-toast'
import { useRouter } from 'next/navigation'

interface ConnectionRequest {
  id: string
  requesterId: string
  recipientId: string
  status: string
  createdAt: string
  requester: {
    id: string
    name?: string | null
    avatar?: string | null
    jobTitle?: string | null
    organization?: string | null
  }
  recipient: {
    id: string
    name?: string | null
    avatar?: string | null
    jobTitle?: string | null
    organization?: string | null
  }
}

export default function ConnectionsPage() {
  const { currentUser, isAuthenticated, setShowLoginModal } = useStore()
  const { t } = useI18n()
  const { toast } = useToast()
  const router = useRouter()
  const [pendingRequests, setPendingRequests] = useState<ConnectionRequest[]>([])
  const [acceptedConnections, setAcceptedConnections] = useState<ConnectionRequest[]>([])
  const [activeTab, setActiveTab] = useState<'pending' | 'connections'>('pending')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isAuthenticated || !currentUser) {
      setLoading(false)
      return
    }

    async function loadConnections() {
      try {
        // Load pending requests
        const pendingRes = await fetch('/api/connections?status=PENDING')
        if (pendingRes.ok) {
          const pendingData = await pendingRes.json()
          const myPending = (pendingData.connections || []).filter(
            (c: ConnectionRequest) => c.recipientId === currentUser?.id
          )
          setPendingRequests(myPending)
        }

        // Load accepted connections
        const acceptedRes = await fetch('/api/connections?status=ACCEPTED')
        if (acceptedRes.ok) {
          const acceptedData = await acceptedRes.json()
          setAcceptedConnections(acceptedData.connections || [])
        }
      } catch (err) {
        console.error('Failed to load connections:', err)
      }
      setLoading(false)
    }
    loadConnections()
  }, [isAuthenticated, currentUser])

  const handleAccept = async (req: ConnectionRequest) => {
    try {
      const res = await fetch('/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requesterId: req.requesterId,
          recipientId: currentUser?.id,
          status: 'ACCEPTED',
        }),
      })
      if (res.ok) {
        toast({ title: 'تم القبول', description: `تم قبول طلب الصداقة من ${req.requester?.name || 'المستخدم'}` })
        setPendingRequests((prev) => prev.filter((r) => r.id !== req.id))
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في قبول الطلب', variant: 'destructive' })
    }
  }

  const handleReject = async (req: ConnectionRequest) => {
    try {
      const res = await fetch('/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requesterId: req.requesterId,
          recipientId: currentUser?.id,
          status: 'REJECTED',
        }),
      })
      if (res.ok) {
        toast({ title: 'تم الرفض', description: 'تم رفض طلب الصداقة' })
        setPendingRequests((prev) => prev.filter((r) => r.id !== req.id))
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في رفض الطلب', variant: 'destructive' })
    }
  }

  if (!isAuthenticated || !currentUser) {
    return (
      <GlassCard variant="default" size="lg" className="text-center max-w-md mx-auto mt-10">
        <div className="py-8">
          <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground mb-4">يرجى تسجيل الدخول لعرض طلبات الصداقة</p>
          <GlassButton variant="primary" onClick={() => setShowLoginModal(true)}>تسجيل الدخول</GlassButton>
        </div>
      </GlassCard>
    )
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 page-enter">
      <div>
        <h1 className="text-2xl font-bold mb-1 flex items-center gap-2">
          <Users className="w-6 h-6 text-primary" />
          طلبات الصداقة والاتصالات
        </h1>
        <p className="text-muted-foreground">إدارة طلبات الصداقة واتصالاتك المهنية</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <GlassButton
          variant={activeTab === 'pending' ? 'primary' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('pending')}
          className="gap-1.5"
        >
          طلبات معلقة
          {pendingRequests.length > 0 && (
            <Badge className="bg-blue-500 text-white text-2xs ms-1">{pendingRequests.length}</Badge>
          )}
        </GlassButton>
        <GlassButton
          variant={activeTab === 'connections' ? 'primary' : 'ghost'}
          size="sm"
          onClick={() => setActiveTab('connections')}
          className="gap-1.5"
        >
          اتصالاتي
          {acceptedConnections.length > 0 && (
            <Badge variant="secondary" className="text-2xs ms-1">{acceptedConnections.length}</Badge>
          )}
        </GlassButton>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : activeTab === 'pending' ? (
        /* Pending Requests */
        <div className="space-y-3">
          {pendingRequests.length > 0 ? (
            pendingRequests.map((req) => (
              <GlassCard key={req.id} variant="default" size="sm" hoverable className="p-4">
                <div className="flex items-center gap-3">
                  <GlassAvatar variant="ring" size="md" className="h-12 w-12 cursor-pointer" onClick={() => router.push(`/profile/${req.requester.id}`)}>
                    <GlassAvatarImage src={req.requester?.avatar || undefined} />
                    <GlassAvatarFallback className="bg-primary/10 text-primary font-bold">
                      {req.requester?.name?.charAt(0) || '?'}
                    </GlassAvatarFallback>
                  </GlassAvatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold truncate">{req.requester?.name || 'مستخدم'}</p>
                    <p className="text-sm text-muted-foreground truncate">
                      {[req.requester?.jobTitle, req.requester?.organization].filter(Boolean).join(' · ') || 'عضو في المنصة'}
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <GlassButton
                      size="sm"
                      onClick={() => handleAccept(req)}
                      className="gap-1 text-xs bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 border-emerald-500/30"
                    >
                      <UserCheck className="w-4 h-4" />
                      قبول
                    </GlassButton>
                    <GlassButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleReject(req)}
                      className="gap-1 text-xs text-destructive hover:bg-destructive/5 border-destructive/30"
                    >
                      <UserX className="w-4 h-4" />
                      رفض
                    </GlassButton>
                  </div>
                </div>
              </GlassCard>
            ))
          ) : (
            <GlassCard variant="default" size="md" className="text-center py-8">
              <Users className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">لا توجد طلبات صداقة معلقة</p>
            </GlassCard>
          )}
        </div>
      ) : (
        /* Accepted Connections */
        <div className="space-y-3">
          {acceptedConnections.length > 0 ? (
            acceptedConnections.map((conn) => {
              const otherUser = conn.requesterId === currentUser.id ? conn.recipient : conn.requester
              return (
                <GlassCard key={conn.id} variant="default" size="sm" hoverable className="p-4 cursor-pointer" onClick={() => router.push(`/profile/${otherUser.id}`)}>
                  <div className="flex items-center gap-3">
                    <GlassAvatar variant="default" size="md" className="h-11 w-11">
                      <GlassAvatarImage src={otherUser?.avatar || undefined} />
                      <GlassAvatarFallback className="bg-primary/10 text-primary font-bold">
                        {otherUser?.name?.charAt(0) || '?'}
                      </GlassAvatarFallback>
                    </GlassAvatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold truncate">{otherUser?.name || 'مستخدم'}</p>
                      <p className="text-sm text-muted-foreground truncate">
                        {[otherUser?.jobTitle, otherUser?.organization].filter(Boolean).join(' · ') || 'عضو في المنصة'}
                      </p>
                    </div>
                    <Badge variant="secondary" className="text-2xs shrink-0 gap-1">
                      <UserCheck className="w-3 h-3" />
                      متصل
                    </Badge>
                  </div>
                </GlassCard>
              )
            })
          ) : (
            <GlassCard variant="default" size="md" className="text-center py-8">
              <Users className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">لا توجد اتصالات بعد</p>
              <p className="text-xs text-muted-foreground mt-1">ابدأ بإرسال طلبات صداقة للخبراء والأعضاء</p>
            </GlassCard>
          )}
        </div>
      )}
    </div>
  )
}
