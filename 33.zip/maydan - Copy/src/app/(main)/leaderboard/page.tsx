'use client'

import Leaderboard from '@/components/Leaderboard'

export default function LeaderboardPage() {
  return (
    <div className="space-y-6">
      <Leaderboard />
    </div>
  )
}
