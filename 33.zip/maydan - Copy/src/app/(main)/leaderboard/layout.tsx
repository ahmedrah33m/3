import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'لوحة المتصدرين | ميدان',
  description: 'اكتشف أفضل المساهمين والخبراء والباحثين على منصة ميدان经济学. ترتيب شامل بالسمعة والإنجازات.',
  openGraph: {
    title: 'لوحة المتصدرين | ميدان',
    description: 'اكتشف أفضل المساهمين والخبراء على منصة ميدان.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/leaderboard`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'لوحة المتصدرين | ميدان',
    description: 'اكتشف أفضل المساهمين والخبراء على منصة ميدان.',
  },
  alternates: {
    canonical: `${SITE_URL}/leaderboard`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
