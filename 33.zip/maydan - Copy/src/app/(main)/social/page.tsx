'use client'

import SocialHub from '@/components/SocialHub'

export default function SocialHubPage() {
  return <SocialHub />
}
