import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /experts يندمج مع /expert-market (سوق الخبراء الكامل) — نُوجّه إليه */
export default function ExpertsPage() {
  redirect('/expert-market')
}