import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الخبراء والمتخصصون | ميدان',
  description: 'اكتشف خبراء ومتخصصين في الاقتصاد والأعمال على منصة ميدان العراقية.',
  openGraph: {
    title: 'الخبراء والمتخصصون | ميدان',
    description: 'اكتشف خبراء ومتخصصين في الاقتصاد والأعمال على منصة ميدان العراقية.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/experts`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الخبراء والمتخصصون | ميدان',
    description: 'اكتشف خبراء ومتخصصين في الاقتصاد والأعمال على منصة ميدان العراقية.',
  },
  alternates: {
    canonical: `${SITE_URL}/experts`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
