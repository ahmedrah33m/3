import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { requestPageData } from '@/lib/marketplace-seo'
import { RequestDetail } from '@/components/marketplace/RequestsViews'

interface PageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params
  const data = await requestPageData(id)
  return data?.metadata ?? { title: 'غير موجود | ميدان' }
}

export default async function RequestDetailPage({ params }: PageProps) {
  const { id } = await params
  const data = await requestPageData(id)
  if (!data) return notFound()

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data.jsonLd) }} />
      <RequestDetail initial={data.initial} />
    </>
  )
}
