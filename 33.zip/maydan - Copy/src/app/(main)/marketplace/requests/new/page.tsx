'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const NewRequestForm = dynamic(() => import('@/components/marketplace/RequestsViews').then((m) => m.NewRequestForm), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-12 rounded-2xl" />
      <Skeleton className="h-[560px] rounded-2xl max-w-2xl mx-auto" />
    </div>
  ),
})

export default function NewRequestPage() {
  return <NewRequestForm />
}
