'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const MarketplaceHome = dynamic(() => import('@/components/marketplace/MarketplaceHome').then((m) => m.MarketplaceHome), {
  ssr: false,
  loading: () => (
    <div className="space-y-6">
      <div className="h-64 rounded-3xl bg-muted animate-pulse" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-20" />
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-64" />
        ))}
      </div>
    </div>
  ),
})

export default function MarketplacePage() {
  return <MarketplaceHome />
}
