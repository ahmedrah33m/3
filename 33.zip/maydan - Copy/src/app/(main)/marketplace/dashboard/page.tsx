'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'
import { RoleGate } from '@/components/RoleGate'

const DashboardView = dynamic(() => import('@/components/marketplace/DashboardView').then((m) => m.DashboardView), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-12 rounded-2xl" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <Skeleton key={i} className="h-20" />
        ))}
      </div>
    </div>
  ),
})

export default function MarketplaceDashboardPage() {
  return (
    <RoleGate>
      <DashboardView />
    </RoleGate>
  )
}
