'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const ProductsView = dynamic(() => import('@/components/marketplace/ProductsView').then((m) => m.ProductsView), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-12 rounded-2xl" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <Skeleton key={i} className="h-64" />
        ))}
      </div>
    </div>
  ),
})

export default function ProductsPage() {
  return <ProductsView />
}
