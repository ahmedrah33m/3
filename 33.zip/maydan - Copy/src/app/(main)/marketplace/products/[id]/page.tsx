import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { productPageData } from '@/lib/marketplace-seo'
import { ProductDetail } from '@/components/marketplace/DetailViews'

interface PageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params
  const data = await productPageData(id)
  return data?.metadata ?? { title: 'غير موجود | ميدان' }
}

export default async function ProductDetailPage({ params }: PageProps) {
  const { id } = await params
  const data = await productPageData(id)
  if (!data) return notFound()

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data.jsonLd) }} />
      <ProductDetail initial={data.initial} />
    </>
  )
}
