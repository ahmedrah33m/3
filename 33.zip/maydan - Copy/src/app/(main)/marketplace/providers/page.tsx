'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const ProvidersView = dynamic(() => import('@/components/marketplace/StoresProvidersView').then((m) => m.ProvidersView), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-12 rounded-2xl" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-48" />
        ))}
      </div>
    </div>
  ),
})

export default function ProvidersPage() {
  return <ProvidersView />
}
