import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { providerPageData } from '@/lib/marketplace-seo'
import { ProviderDetail } from '@/components/marketplace/DetailViews'

interface PageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params
  const data = await providerPageData(id)
  return data?.metadata ?? { title: 'غير موجود | ميدان' }
}

export default async function ProviderDetailPage({ params }: PageProps) {
  const { id } = await params
  const data = await providerPageData(id)
  if (!data) return notFound()

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data.jsonLd) }} />
      <ProviderDetail initial={data.initial} />
    </>
  )
}
