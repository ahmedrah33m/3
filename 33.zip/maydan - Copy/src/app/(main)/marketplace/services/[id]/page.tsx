import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { servicePageData } from '@/lib/marketplace-seo'
import { ServiceDetail } from '@/components/marketplace/DetailViews'

interface PageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params
  const data = await servicePageData(id)
  return data?.metadata ?? { title: 'غير موجود | ميدان' }
}

export default async function ServiceDetailPage({ params }: PageProps) {
  const { id } = await params
  const data = await servicePageData(id)
  if (!data) return notFound()

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data.jsonLd) }} />
      <ServiceDetail initial={data.initial} />
    </>
  )
}
