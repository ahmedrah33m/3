import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'سوق ميدان — الخدمات والمنتجات والمتاجر',
  description:
    'سوق ميدان: أقوى سوق للأعمال والخدمات والمنتجات في العراق — خدمات، منتجات، متاجر، مقدمو خدمات، وطلبات خدمات بعروض تنافسية.',
}

export default function MarketplaceLayout({ children }: { children: React.ReactNode }) {
  return <div className="min-h-[60vh]">{children}</div>
}
