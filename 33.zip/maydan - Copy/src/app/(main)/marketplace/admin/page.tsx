'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'
import { StaffGate } from '@/components/RoleGate'

const MarketplaceAdmin = dynamic(() => import('@/components/marketplace/MarketplaceAdmin'), {
  ssr: false,
  loading: () => (
    <div className="space-y-6">
      <div className="h-14 rounded-2xl bg-muted animate-pulse" />
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Skeleton key={i} className="h-20" />
        ))}
      </div>
    </div>
  ),
})

export default function MarketplaceAdminPage() {
  return (
    <StaffGate>
      <MarketplaceAdmin />
    </StaffGate>
  )
}
