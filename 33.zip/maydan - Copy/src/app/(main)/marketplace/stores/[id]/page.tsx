import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { storePageData } from '@/lib/marketplace-seo'
import { StoreDetail } from '@/components/marketplace/DetailViews'

interface PageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params
  const data = await storePageData(id)
  return data?.metadata ?? { title: 'غير موجود | ميدان' }
}

export default async function StoreDetailPage({ params }: PageProps) {
  const { id } = await params
  const data = await storePageData(id)
  if (!data) return notFound()

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data.jsonLd) }} />
      <StoreDetail initial={data.initial} />
    </>
  )
}
