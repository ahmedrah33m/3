'use client'

import EconomicIntelligence from '@/components/EconomicIntelligence'

export default function EconomicPage() {
  return <EconomicIntelligence />
}
