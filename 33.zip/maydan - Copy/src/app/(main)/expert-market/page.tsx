'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const ExpertMarketplaceView = dynamic(() => import('@/components/ExpertMarketplaceView'), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-8 w-48" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Skeleton key={i} className="h-64" />
        ))}
      </div>
    </div>
  ),
})

export default function ExpertMarketPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">سوق الخبراء</h1>
        <p className="text-sm text-muted-foreground">تواصل مع الخبراء الاقتصاديين والماليين - استشارات، دراسات، تدريب، وتحليل</p>
      </div>
      <ExpertMarketplaceView />
    </div>
  )
}
