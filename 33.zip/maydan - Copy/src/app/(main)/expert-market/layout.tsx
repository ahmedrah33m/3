import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'سوق الخبراء | ميدان',
  description: 'تصفح خدمات الخبراء والمتخصصين. استفد من خبراتهم في الاقتصاد والأعمال.',
  openGraph: {
    title: 'سوق الخبراء | ميدان',
    description: 'تصفح خدمات الخبراء والمتخصصين. استفد من خبراتهم في الاقتصاد والأعمال.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/expert-market`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'سوق الخبراء | ميدان',
    description: 'تصفح خدمات الخبراء والمتخصصين. استفد من خبراتهم في الاقتصاد والأعمال.',
  },
  alternates: {
    canonical: `${SITE_URL}/expert-market`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
