import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /admin/jobs كان يعرض نفس نظرة عامة /admin — نُوجّه إليه */
export default function AdminJobsPage() {
  redirect('/admin')
}