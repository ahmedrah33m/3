import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /admin/companies مكرر لـ /admin/experts (نفس قسم expert-verifications) — نُوجّه إليه */
export default function AdminCompaniesPage() {
  redirect('/admin/experts')
}