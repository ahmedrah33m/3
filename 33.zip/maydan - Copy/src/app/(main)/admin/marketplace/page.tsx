import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /admin/marketplace كان يعرض نفس نظرة عامة /admin — نُوجّه إليه */
export default function AdminMarketplacePage() {
  redirect('/admin')
}