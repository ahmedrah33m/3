'use client'

import { Suspense, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useStore } from '@/lib/store'
import AdminPanel from '@/components/AdminPanel'

function AdminPageInner() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { currentUser, isAuthenticated, authLoading } = useStore()

  const sectionParam = searchParams.get('section')

  useEffect(() => {
    if (!authLoading && (!isAuthenticated || !currentUser)) {
      router.push('/')
      return
    }
    if (!authLoading && currentUser && !['OWNER', 'ADMIN', 'MODERATOR'].includes(currentUser.role)) {
      router.push('/')
    }
  }, [authLoading, isAuthenticated, currentUser, router])

  if (authLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  return <AdminPanel initialSection={sectionParam} />
}

export default function AdminPage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    }>
      <AdminPageInner />
    </Suspense>
  )
}