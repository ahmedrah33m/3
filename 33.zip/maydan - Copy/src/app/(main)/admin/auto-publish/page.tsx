import AutoPublishDashboard from '@/components/admin/AutoPublishDashboard'
import { StaffGate } from '@/components/RoleGate'

export const metadata = {
  title: 'النشر التلقائي — لوحة الإدارة',
}

export default function AutoPublishPage() {
  return (
    <StaffGate>
      <AutoPublishDashboard />
    </StaffGate>
  )
}