'use client'

import { useEffect, useMemo, useState } from 'react'
import { ShieldCheck, CheckCircle2, XCircle, ExternalLink, User } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useI18n } from '@/lib/i18n'

const SECTION_LABELS: Record<string, string> = {
  IDENTITY: 'الهوية',
  EDUCATION: 'التعليم',
  CERTIFICATES: 'الشهادات',
  EXPERIENCE: 'الخبرة',
  PROJECTS: 'المشاريع',
  SKILLS: 'المهارات',
  LANGUAGES: 'اللغات',
  PUBLICATIONS: 'المنشورات',
  RESEARCH: 'الأبحاث',
  ACHIEVEMENTS: 'الإنجازات',
  RECOMMENDATIONS: 'التوصيات',
  VERIFIED_EXPERIENCE: 'خبرة موثّقة',
  VERIFIED_CERTIFICATES: 'شهادات موثّقة',
  EMPLOYMENT_HISTORY: 'التاريخ الوظيفي',
}

type Filter = 'PENDING' | 'UNVERIFIED' | 'VERIFIED' | 'ALL'

export default function AdminPassportReviewPage() {
  const { t, dir } = useI18n()
  const [sections, setSections] = useState<any[]>([])
  const [filter, setFilter] = useState<Filter>('PENDING')
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState('')

  const load = () => {
    setLoading(true)
    const q = filter === 'ALL' ? '' : `?status=${filter}`
    fetch(`/api/admin/professional-passport/sections${q}`)
      .then((r) => r.json())
      .then((d) => setSections(d.sections || []))
      .finally(() => setLoading(false))
  }

  useEffect(load, [filter])

  const review = async (id: string, status: 'VERIFIED' | 'UNVERIFIED') => {
    setBusyId(id)
    try {
      await fetch(`/api/admin/professional-passport/sections/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })
      load()
    } finally {
      setBusyId('')
    }
  }

  const counts = useMemo(() => {
    const c = { PENDING: 0, UNVERIFIED: 0, VERIFIED: 0 }
    for (const s of sections) if (s.status in c) c[s.status as keyof typeof c]++
    return c
  }, [sections])

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-6" dir={dir}>
      <div className="flex items-center gap-3">
        <ShieldCheck className="h-7 w-7 text-primary" />
        <h1 className="text-2xl font-bold">مراجعة الجوازات المهنية</h1>
      </div>

      <div className="flex gap-2 flex-wrap">
        {(['PENDING', 'UNVERIFIED', 'VERIFIED', 'ALL'] as Filter[]).map((f) => (
          <Button
            key={f}
            variant={filter === f ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(f)}
          >
            {f === 'PENDING' ? `قيد المراجعة (${counts.PENDING})` : f === 'UNVERIFIED' ? `غير موثّق (${counts.UNVERIFIED})` : f === 'VERIFIED' ? `موثّق (${counts.VERIFIED})` : 'الكل'}
          </Button>
        ))}
      </div>

      {loading ? (
        <p className="text-center text-muted-foreground">جاري التحميل...</p>
      ) : sections.length === 0 ? (
        <p className="text-center text-muted-foreground">لا توجد أقسام بهذا التصفية.</p>
      ) : (
        <div className="space-y-3">
          {sections.map((s) => (
            <Card key={s.id}>
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{SECTION_LABELS[s.category] || s.category}</h3>
                    {s.candidate && (
                      <span className="text-sm text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" /> {s.candidate.name}
                        {s.candidate.jobTitle && ` · ${s.candidate.jobTitle}`}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1"
                      onClick={() =>
                        s.publicId && window.open(`/verify/${s.publicId}`, '_blank')
                      }
                    >
                      <ExternalLink className="h-3 w-3" /> عرض الملف
                    </Button>
                    <Button
                      size="sm"
                      className="bg-green-500 hover:bg-green-600 gap-1"
                      disabled={busyId === s.id}
                      onClick={() => review(s.id, 'VERIFIED')}
                    >
                      <CheckCircle2 className="h-3 w-3" /> توثيق
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="gap-1"
                      disabled={busyId === s.id}
                      onClick={() => review(s.id, 'UNVERIFIED')}
                    >
                      <XCircle className="h-3 w-3" /> رفض
                    </Button>
                  </div>
                </div>
                {s.documentUrl && (
                  <a href={s.documentUrl} target="_blank" rel="noreferrer" className="text-xs text-primary break-all">
                    وثيقة الإثبات: {s.documentUrl}
                  </a>
                )}
                {s.data && (
                  <pre className="text-xs text-muted-foreground bg-muted/40 rounded p-2 overflow-auto max-h-40 whitespace-pre-wrap">
                    {JSON.stringify(s.data, null, 2)}
                  </pre>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
