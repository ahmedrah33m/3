import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /admin/consultations كان يعرض نفس نظرة عامة /admin — نُوجّه إليه */
export default function AdminConsultationsPage() {
  redirect('/admin')
}