import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /admin/security مكرر لـ /admin/audit-logs (نفس قسم audit) — نُوجّه إليه */
export default function AdminSecurityPage() {
  redirect('/admin/audit-logs')
}