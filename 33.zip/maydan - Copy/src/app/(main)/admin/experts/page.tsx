import { AdminSubPage } from '@/components/admin/AdminSubPage'

export default function Page() {
  return <AdminSubPage section="expert-verifications" />
}
