import ScraperDashboard from '@/components/admin/ScraperDashboard'
import { StaffGate } from '@/components/RoleGate'

export const metadata = {
  title: 'جالب قنوات تيليجرام — لوحة الإدارة',
}

export default function ScrapePage() {
  return (
    <StaffGate>
      <ScraperDashboard />
    </StaffGate>
  )
}
