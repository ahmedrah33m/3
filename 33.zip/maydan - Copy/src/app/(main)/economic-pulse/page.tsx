'use client'

import IraqEconomicPulse from '@/components/IraqEconomicPulse'

export default function EconomicPulsePage() {
  return <IraqEconomicPulse />
}
