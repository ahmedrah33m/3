'use client'

import InvestmentNetwork from '@/components/InvestmentNetwork'

export default function InvestmentNetworkPage() {
  return <InvestmentNetwork />
}
