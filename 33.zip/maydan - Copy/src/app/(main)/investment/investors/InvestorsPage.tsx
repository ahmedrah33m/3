'use client'

import { useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import { apiFetch } from '@/lib/api-client'
import { motion } from 'framer-motion'
import { useI18n } from '@/lib/i18n'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { EmptyState } from '@/components/ui/feedback-state'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  Search, Users, Building2, Coins, DollarSign, MapPin, Briefcase,
  CheckCircle2, ShieldCheck, Plus, Handshake,
  Zap, Flame, Factory, Leaf, Cpu, ShoppingBag, Heart, GraduationCap,
  Truck, Compass, Wifi, Mountain, TreePine,
  Package, Brain,
} from 'lucide-react'

interface Investor {
  id: string
  userId: string
  companyName: string | null
  investorType: string
  investmentType: string
  preferredCategories: string[]
  preferredProvinces: string[]
  minInvestment: string
  maxInvestment: string
  bio: string | null
  portfolioSize: number
  investmentsMade: number
  isVerified: boolean
  totalInvested: string
  favoritesCount: number
  createdAt: string
  user: {
    id: string
    name: string | null
    avatar: string | null
    companyName: string | null
    isVerified: boolean | null
    userType: string | null
  }
}

interface Stats {
  totalInvestors: number
  totalOpportunities: number
  totalValue: number
}

const SECTORS = [
  { id: 'ENERGY', labelAr: 'الطاقة', labelEn: 'Energy', icon: Zap },
  { id: 'OIL_GAS', labelAr: 'النفط والغاز', labelEn: 'Oil & Gas', icon: Flame },
  { id: 'INDUSTRY', labelAr: 'الصناعة', labelEn: 'Industry', icon: Factory },
  { id: 'AGRICULTURE', labelAr: 'الزراعة', labelEn: 'Agriculture', icon: Leaf },
  { id: 'TECHNOLOGY', labelAr: 'التكنولوجيا', labelEn: 'Technology', icon: Cpu },
  { id: 'TRADE', labelAr: 'التجارة', labelEn: 'Trade', icon: ShoppingBag },
  { id: 'HEALTH', labelAr: 'الصحة', labelEn: 'Health', icon: Heart },
  { id: 'EDUCATION', labelAr: 'التعليم', labelEn: 'Education', icon: GraduationCap },
  { id: 'TRANSPORT', labelAr: 'النقل', labelEn: 'Transport', icon: Truck },
  { id: 'TOURISM', labelAr: 'السياحة', labelEn: 'Tourism', icon: Compass },
  { id: 'REAL_ESTATE', labelAr: 'العقارات', labelEn: 'Real Estate', icon: Building2 },
  { id: 'SERVICES', labelAr: 'الخدمات', labelEn: 'Services', icon: Briefcase },
  { id: 'TELECOM', labelAr: 'الاتصالات', labelEn: 'Telecom', icon: Wifi },
  { id: 'MINING', labelAr: 'التعدين', labelEn: 'Mining', icon: Mountain },
  { id: 'ENVIRONMENT', labelAr: 'البيئة', labelEn: 'Environment', icon: TreePine },
  { id: 'LOGISTICS', labelAr: 'اللوجستيات', labelEn: 'Logistics', icon: Package },
  { id: 'AI', labelAr: 'الذكاء الاصطناعي', labelEn: 'AI', icon: Brain },
]

const PROVINCES = [
  { id: 'baghdad', labelAr: 'بغداد', labelEn: 'Baghdad' },
  { id: 'basra', labelAr: 'البصرة', labelEn: 'Basra' },
  { id: 'erbil', labelAr: 'أربيل', labelEn: 'Erbil' },
  { id: 'sulaymaniyah', labelAr: 'السليمانية', labelEn: 'Sulaymaniyah' },
  { id: 'duhok', labelAr: 'دهوك', labelEn: 'Duhok' },
  { id: 'najaf', labelAr: 'النجف', labelEn: 'Najaf' },
  { id: 'karbala', labelAr: 'كربلاء', labelEn: 'Karbala' },
  { id: 'kirkuk', labelAr: 'كركوك', labelEn: 'Kirkuk' },
  { id: 'diyala', labelAr: 'ديالى', labelEn: 'Diyala' },
  { id: 'anbar', labelAr: 'الأنبار', labelEn: 'Anbar' },
  { id: 'wasit', labelAr: 'واسط', labelEn: 'Wasit' },
  { id: 'babil', labelAr: 'بابل', labelEn: 'Babil' },
  { id: 'dhi_qar', labelAr: 'ذي قار', labelEn: 'Dhi Qar' },
  { id: 'maysan', labelAr: 'ميسان', labelEn: 'Maysan' },
  { id: 'muthanna', labelAr: 'المثنى', labelEn: 'Muthanna' },
  { id: 'al_qadisiyyah', labelAr: 'القادسية', labelEn: 'Al-Qadisiyyah' },
  { id: 'nineveh', labelAr: 'نينوى', labelEn: 'Nineveh' },
]

const INVESTOR_TYPES = [
  { value: 'INDIVIDUAL', labelAr: 'مستثمر فردي', labelEn: 'Individual Investor' },
  { value: 'INSTITUTIONAL', labelAr: 'مستثمر مؤسسي', labelEn: 'Institutional Investor' },
  { value: 'VENTURE_CAPITAL', labelAr: 'رأس مال مغامر', labelEn: 'Venture Capital' },
  { value: 'PRIVATE_EQUITY', labelAr: 'حقوق ملكية خاصة', labelEn: 'Private Equity' },
  { value: 'SOVEREIGN_FUND', labelAr: 'صندوق سيادي', labelEn: 'Sovereign Fund' },
  { value: 'ANGEL', labelAr: 'مستثمر ملاك', labelEn: 'Angel Investor' },
  { value: 'CORPORATE', labelAr: 'شركة استثمارية', labelEn: 'Corporate Investor' },
  { value: 'GOVERNMENT', labelAr: 'جهة حكومية', labelEn: 'Government Entity' },
  { value: 'BANK', labelAr: 'بنك', labelEn: 'Bank' },
]

const INVESTMENT_TYPES = [
  { value: 'EQUITY', labelAr: 'نسبة ملكية', labelEn: 'Equity' },
  { value: 'DEBT', labelAr: 'قرض', labelEn: 'Debt' },
  { value: 'LOAN', labelAr: 'قرض', labelEn: 'Loan' },
  { value: 'CONVERTIBLE', labelAr: 'قابل للتحويل', labelEn: 'Convertible' },
  { value: 'REVENUE_SHARE', labelAr: 'حصة من الإيرادات', labelEn: 'Revenue Share' },
  { value: 'PARTNERSHIP', labelAr: 'شراكة', labelEn: 'Partnership' },
  { value: 'PURCHASE', labelAr: 'شراء', labelEn: 'Purchase' },
]

function normalizeKey(value?: string): string {
  return (value || '').toUpperCase().replace(/\s+/g, '_').replace(/-/g, '_')
}

function investorTypeLabel(type: string, locale: string): string {
  const found = INVESTOR_TYPES.find((t) => t.value === normalizeKey(type) || t.labelEn === type)
  if (found) return locale === 'ar' ? found.labelAr : found.labelEn
  return type || '—'
}

function investmentTypeLabel(type: string, locale: string): string {
  const found = INVESTMENT_TYPES.find((t) => t.value === normalizeKey(type) || t.labelEn === type)
  if (found) return locale === 'ar' ? found.labelAr : found.labelEn
  return type || '—'
}

function formatMoney(value: string): string {
  const num = Number(value)
  if (!num) return ''
  return `$${num.toLocaleString('en-US')}`
}

function sectorInfo(id: string) {
  return SECTORS.find((s) => s.id === id || s.labelEn.toLowerCase() === id.toLowerCase())
}

function provinceLabel(id: string, locale: string): string {
  const p = PROVINCES.find((pr) => pr.id === id)
  if (!p) return id
  return locale === 'ar' ? p.labelAr : p.labelEn
}

export default function InvestorsPage() {
  const { locale, dir } = useI18n()
  const router = useRouter()
  const t = (ar: string, en: string) => (locale === 'ar' ? ar : en)

  const [search, setSearch] = useState('')
  const [type, setType] = useState('')
  const [category, setCategory] = useState('')
  const [province, setProvince] = useState('')
  const [page, setPage] = useState(1)
  const limit = 9

  const queryKey = ['investment-bank', 'investors', search, type, category, province, page, limit]

  const { data, isLoading, isError, refetch } = useQuery<{ investors: Investor[]; total: number; totalPages: number }>({
    queryKey,
    queryFn: async () => {
      const params = new URLSearchParams({ page: String(page), limit: String(limit) })
      if (search.trim()) params.set('search', search.trim())
      if (type) params.set('investorType', type)
      if (category) params.set('category', category)
      if (province) params.set('province', province)
      return apiFetch(`/api/investment-bank/investors?${params}`)
    },
    staleTime: 60 * 1000,
  })

  const { data: stats } = useQuery<Stats>({
    queryKey: ['investment-bank', 'stats'],
    queryFn: () => apiFetch('/api/investment-bank/stats'),
    staleTime: 60 * 1000,
  })

  const investors = data?.investors || []
  const totalPages = data?.totalPages || 1

  const heroStats = useMemo(() => [
    { label: t('المستثمرون', 'Investors'), value: stats?.totalInvestors ?? 0, icon: Users, color: 'text-purple-500' },
    { label: t('فرص استثمارية', 'Opportunities'), value: stats?.totalOpportunities ?? 0, icon: Briefcase, color: 'text-blue-500' },
    { label: t('القيمة الإجمالية', 'Total Value'), value: stats?.totalValue ? `$${(stats.totalValue / 1e6).toFixed(1)}M` : '$0', icon: DollarSign, color: 'text-green-500' },
  ], [stats, t])

  const clearFilters = () => {
    setSearch('')
    setType('')
    setCategory('')
    setProvince('')
    setPage(1)
  }

  return (
    <motion.div dir={dir} className="space-y-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1">{t('المستثمرون', 'Investors')}</h1>
          <p className="text-sm text-muted-foreground">{t('دليل المستثمرين وشركات الاستثمار في العراق', 'Directory of investors and investment firms in Iraq')}</p>
        </div>
        <Button className="gap-2" onClick={() => router.push('/investment-bank')}>
          <Plus className="h-4 w-4" />
          {t('إنشاء ملف مستثمر', 'Create Investor Profile')}
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {heroStats.map((s) => (
          <Card key={s.label}>
            <CardContent className="flex items-center gap-3 p-4">
              <div className={`h-10 w-10 rounded-xl bg-muted flex items-center justify-center ${s.color}`}>
                <s.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xs text-muted-foreground">{s.label}</p>
                <p className="text-xl font-bold">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="relative">
              <Search className="absolute top-1/2 -translate-y-1/2 left-3 rtl:right-3 rtl:left-auto h-4 w-4 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1) }}
                placeholder={t('ابحث بالاسم أو الشركة...', 'Search by name or company...')}
                className="pl-10 rtl:pl-4 rtl:pr-10"
              />
            </div>
            <Select value={type} onValueChange={(v) => { setType(v === 'all' ? '' : v); setPage(1) }}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={t('كل أنواع المستثمرين', 'All investor types')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('كل الأنواع', 'All types')}</SelectItem>
                {INVESTOR_TYPES.map((it) => (
                  <SelectItem key={it.value} value={it.value}>
                    {locale === 'ar' ? it.labelAr : it.labelEn}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={province} onValueChange={(v) => { setProvince(v === 'all' ? '' : v); setPage(1) }}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={t('كل المحافظات', 'All provinces')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('كل المحافظات', 'All provinces')}</SelectItem>
                {PROVINCES.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {locale === 'ar' ? p.labelAr : p.labelEn}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {category ? (
              <Button variant="default" size="xs" className="gap-1 text-2xs" onClick={() => setCategory('')}>
                {(() => { const s = sectorInfo(category); return s ? <s.icon className="h-3 w-3" /> : null })()}
                {sectorInfo(category) ? (locale === 'ar' ? sectorInfo(category)!.labelAr : sectorInfo(category)!.labelEn) : category}
                <span className="ms-1">×</span>
              </Button>
            ) : (
              SECTORS.map((s) => {
                const active = category === s.id
                return (
                  <Button
                    key={s.id}
                    variant={active ? 'default' : 'outline'}
                    size="xs"
                    className="gap-1 text-2xs"
                    onClick={() => { setCategory(active ? '' : s.id); setPage(1) }}
                  >
                    <s.icon className="h-3 w-3" />
                    {locale === 'ar' ? s.labelAr : s.labelEn}
                  </Button>
                )
              })
            )}
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 9 }).map((_, i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      ) : isError ? (
        <EmptyState
          title={t('تعذّر تحميل المستثمرين', 'Failed to load investors')}
          description={t('حاول مرة أخرى', 'Please try again')}
          actionLabel={t('إعادة المحاولة', 'Retry')}
          onAction={() => refetch()}
        />
      ) : investors.length === 0 ? (
        <EmptyState
          title={t('لا يوجد مستثمرون بعد', 'No investors yet')}
          description={t('كن أول من ينضم إلى دليل المستثمرين', 'Be the first to join the investor directory')}
          actionLabel={t('مسح الفلاتر', 'Clear filters')}
          onAction={clearFilters}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {investors.map((investor, i) => {
            const verified = investor.isVerified || investor.user?.isVerified === true
            const categories = investor.preferredCategories.slice(0, 4)
            const provinces = investor.preferredProvinces.slice(0, 3)
            const range = `${formatMoney(investor.minInvestment)} – ${formatMoney(investor.maxInvestment)}`
            return (
              <motion.div key={investor.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                <Card className="h-full hover:shadow-lg transition-all">
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <Avatar size="lg">
                          <AvatarImage src={investor.user?.avatar || ''} alt={investor.companyName || investor.user?.name || ''} />
                          <AvatarFallback>
                            {(investor.companyName || investor.user?.name || '؟').charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <p className="font-semibold text-sm">{investor.companyName || investor.user?.name || t('مستثمر', 'Investor')}</p>
                            {verified && <ShieldCheck className="h-4 w-4 text-sky-500 shrink-0" />}
                          </div>
                          <Badge variant="secondary" className="text-2xs mt-1">
                            {investorTypeLabel(investor.investorType, locale)}
                          </Badge>
                        </div>
                      </div>
                      <Badge className="text-2xs">
                        {investmentTypeLabel(investor.investmentType, locale)}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="rounded-lg bg-muted/60 p-2.5">
                        <div className="flex items-center gap-1 text-2xs text-muted-foreground mb-1">
                          <Coins className="h-3 w-3" />
                          {t('نطاق الاستثمار', 'Range')}
                        </div>
                        <p className="text-sm font-bold">{range || t('غير محدد', 'Unspecified')}</p>
                      </div>
                      <div className="rounded-lg bg-muted/60 p-2.5">
                        <div className="flex items-center gap-1 text-2xs text-muted-foreground mb-1">
                          <CheckCircle2 className="h-3 w-3" />
                          {t('الاستثمارات', 'Investments')}
                        </div>
                        <p className="text-sm font-bold">{investor.investmentsMade}</p>
                      </div>
                    </div>

                    {categories.length > 0 && (
                      <div>
                        <p className="text-2xs text-muted-foreground mb-1.5">{t('القطاعات المفضلة', 'Preferred Sectors')}</p>
                        <div className="flex flex-wrap gap-1.5">
                          {categories.map((c) => {
                            const s = sectorInfo(c)
                            return (
                              <Badge key={c} variant="outline" className="gap-1 text-2xs">
                                {s && <s.icon className="h-3 w-3" />}
                                {s ? (locale === 'ar' ? s.labelAr : s.labelEn) : c}
                              </Badge>
                            )
                          })}
                        </div>
                      </div>
                    )}

                    {provinces.length > 0 && (
                      <div>
                        <p className="text-2xs text-muted-foreground mb-1.5">{t('المحافظات', 'Provinces')}</p>
                        <div className="flex flex-wrap gap-1.5">
                          {provinces.map((pr) => (
                            <Badge key={pr} variant="secondary" className="gap-1 text-2xs">
                              <MapPin className="h-3 w-3" />
                              {provinceLabel(pr, locale)}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {investor.bio && (
                      <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">{investor.bio}</p>
                    )}

                    <div className="flex items-center justify-between border-t pt-3">
                      <span className="text-2xs text-muted-foreground">{t('متاح للتواصل', 'Open to connect')}</span>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1.5 text-2xs"
                        onClick={() => router.push('/investment-bank')}
                      >
                        <Handshake className="h-3.5 w-3.5" />
                        {t('مطابقة ذكية', 'Smart Match')}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}

      {!isLoading && totalPages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
            {t('السابق', 'Previous')}
          </Button>
          <span className="text-xs text-muted-foreground">
            {page} / {totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>
            {t('التالي', 'Next')}
          </Button>
        </div>
      )}
    </motion.div>
  )
}