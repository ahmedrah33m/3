'use client'

/**
 * الفرص الاستثمارية — تعرض InvestmentBankView مع التركيز على tab الفرص
 */

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function OpportunitiesPage() {
  const router = useRouter()

  useEffect(() => {
    // توجيه إلى بنك الاستثمار مع tab محدد
    router.replace('/investment-bank?tab=opportunities')
  }, [router])

  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
    </div>
  )
}
