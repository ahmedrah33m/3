'use client'

/**
 * صفحة الفواتير — تعرض محفظة المستخدم مع التركيز على tab الفواتير
 * مؤقتًا: توجيه إلى صفحة المحفظة (سيتم إنشاء صفحة فواتير مستقلة لاحقًا)
 */

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useStore } from '@/lib/store'

export default function InvoicesPage() {
  const router = useRouter()
  const { isAuthenticated, currentUser, authLoading } = useStore()

  useEffect(() => {
    if (authLoading) return
    if (!isAuthenticated || !currentUser) {
      router.replace('/login?returnUrl=/finance/invoices')
      return
    }
    // مؤقتًا: توجيه إلى المحفظة (يتم تحديثها لعرض الفواتير تحديدًا)
    router.replace('/wallet?tab=invoices')
  }, [authLoading, isAuthenticated, currentUser, router])

  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
    </div>
  )
}
