'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useStore } from '@/lib/store'

export default function FinancePage() {
  const router = useRouter()
  const { isAuthenticated, currentUser, authLoading } = useStore()

  useEffect(() => {
    if (!authLoading && isAuthenticated && currentUser && ['OWNER', 'ADMIN', 'MODERATOR'].includes(currentUser.role)) {
      router.replace('/admin?section=finance')
    } else if (!authLoading) {
      router.replace('/')
    }
  }, [authLoading, isAuthenticated, currentUser, router])

  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
    </div>
  )
}