'use client'

/**
 * صفحة المعاملات — تعرض محفظة المستخدم مع التركيز على tab المعاملات
 */

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useStore } from '@/lib/store'

export default function TransactionsPage() {
  const router = useRouter()
  const { isAuthenticated, currentUser, authLoading } = useStore()

  useEffect(() => {
    if (authLoading) return
    if (!isAuthenticated || !currentUser) {
      router.replace('/login?returnUrl=/finance/transactions')
      return
    }
    // توجيه المستخدم إلى صفحة المحفظة مع تمرير tab
    router.replace('/wallet?tab=transactions')
  }, [authLoading, isAuthenticated, currentUser, router])

  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
    </div>
  )
}
