'use client'

import { useState } from 'react'
import { Award, Search, ShieldCheck, Calendar, User, BookOpen, Hash } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useI18n } from '@/lib/i18n'

export default function VerifyCertificatePage() {
  const { t, dir } = useI18n()
  const [certId, setCertId] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<Record<string, string> | null>(null)
  const [error, setError] = useState('')

  const handleVerify = async () => {
    if (!certId.trim()) return
    setLoading(true)
    setError('')
    setResult(null)
    try {
      const res = await fetch(`/api/academy/certificates/verify?id=${encodeURIComponent(certId)}`)
      const data = await res.json()
      if (data.valid) {
        setResult(data.certificate)
      } else {
        setError('الشهادة غير موجودة أو غير صالحة')
      }
    } catch {
      setError('حدث خطأ أثناء التحقق')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6" dir={dir}>
      <Card>
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <ShieldCheck className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-xl">{t.general?.verifyCertificate || 'التحقق من الشهادة'}</CardTitle>
          <p className="text-sm text-muted-foreground">
            أدخل رقم الشهادة للتحقق من صحتها
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="رقم الشهادة (مثال: CERT-XXXX-XXXX)"
              value={certId}
              onChange={(e) => setCertId(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
              dir="ltr"
              className="flex-1"
            />
            <Button onClick={handleVerify} disabled={loading || !certId.trim()} className="gap-1">
              <Search className="h-4 w-4" />
              {loading ? 'جاري التحقق...' : 'تحقق'}
            </Button>
          </div>

          {error && (
            <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-center">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {result && (
            <Card className="border-green-500/20 bg-green-500/5">
              <CardContent className="p-6 text-center">
                <Award className="h-16 w-16 text-amber-500 fill-amber-500/20 mx-auto mb-3" />
                <Badge className="bg-green-500 text-white mb-3">شهادة صالحة ✓</Badge>
                <h3 className="text-lg font-bold mb-4">{result.title}</h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2 justify-end">
                    <span className="text-muted-foreground">{result.studentName}</span>
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">{result.courseName}</span>
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center gap-2 justify-end">
                    <span className="text-muted-foreground">{result.issuedAt}</span>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground font-mono text-xs">{result.certificateId}</span>
                    <Hash className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <p className="text-2xs text-muted-foreground">صادرة من أكاديمية ميدان الاقتصاد</p>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
