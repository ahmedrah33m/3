'use client'

import EconomicDictionaryView from '@/components/EconomicDictionaryView'

export default function DictionaryPage() {
  return <EconomicDictionaryView />
}
