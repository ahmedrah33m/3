import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'القاموس الاقتصادي | ميدان',
  description: 'قاموس المصطلحات الاقتصادية والمالية. شرح مبسط للمصطلحات المستخدمة في الاقتصاد العراقي.',
  openGraph: {
    title: 'القاموس الاقتصادي | ميدان',
    description: 'قاموس المصطلحات الاقتصادية والمالية. شرح مبسط للمصطلحات المستخدمة في الاقتصاد العراقي.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/dictionary`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'القاموس الاقتصادي | ميدان',
    description: 'قاموس المصطلحات الاقتصادية والمالية. شرح مبسط للمصطلحات المستخدمة في الاقتصاد العراقي.',
  },
  alternates: {
    canonical: `${SITE_URL}/dictionary`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
