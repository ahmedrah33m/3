import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الإنجازات والسمعة | ميدان',
  description: 'نظام الإنجازات والgamification على منصة ميدان. تتبع تقدمك واكتشف إنجازاتك واثبت خبرتك.',
  openGraph: {
    title: 'الإنجازات والسمعة | ميدان',
    description: 'نظام الإنجازات والgamification على منصة ميدان. تتبع تقدمك واكتشف إنجازاتك.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/achievements`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الإنجازات والسمعة | ميدان',
    description: 'نظام الإنجازات والgamification على منصة ميدان.',
  },
  alternates: {
    canonical: `${SITE_URL}/achievements`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
