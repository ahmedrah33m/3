'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { PayrollStatCard, PayrollTable, PayrollStatusBadge } from '@/components/payroll/payroll-ui';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatCurrency } from '@/components/payroll/payroll-ui';
import { Users, DollarSign, TrendingUp, FileText, Plus } from 'lucide-react';

interface PayrollDashboardData {
  totalEmployees: number;
  activeEmployees: number;
  latestPayrollRun: {
    id: string;
    name: string;
    status: string;
    totalNet: number;
    totalEmployees: number;
  } | null;
  pendingApprovals: number;
  monthlyRuns: Array<{
    id: string;
    name: string;
    status: string;
    totalNet: number;
    totalEmployees: number;
  }>;
}

export default function PayrollDashboardPage() {
  const [selectedCompany, setSelectedCompany] = useState<string>('');

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['payroll-dashboard', selectedCompany],
    queryFn: async () => {
      const res = await fetch(`/api/payroll/runs?companyId=${selectedCompany}&dashboard=true`);
      return res.json();
    },
    enabled: !!selectedCompany,
  });

  const dashboardData: PayrollDashboardData = data?.data || {
    totalEmployees: 0,
    activeEmployees: 0,
    latestPayrollRun: null,
    pendingApprovals: 0,
    monthlyRuns: [],
  };

  if (isLoading) {
    return <PayrollDashboardSkeleton />;
  }

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">إدارة الرواتب</h1>
        <Button>
          <Plus className="ml-2 h-4 w-4" />
          تشغيل راتب جديد
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <PayrollStatCard
          title="إجمالي الموظفين"
          value={dashboardData.totalEmployees}
          icon={<Users className="h-4 w-4" />}
        />
        <PayrollStatCard
          title="الموظفون النشطون"
          value={dashboardData.activeEmployees}
          icon={<Users className="h-4 w-4" />}
        />
        <PayrollStatCard
          title="إجمالي الرواتب الأخير"
          value={formatCurrency(dashboardData.latestPayrollRun?.totalNet || 0)}
          subtitle={`${dashboardData.latestPayrollRun?.totalEmployees || 0} موظف`}
          icon={<DollarSign className="h-4 w-4" />}
        />
        <PayrollStatCard
          title="بانتظار الموافقة"
          value={dashboardData.pendingApprovals}
          icon={<FileText className="h-4 w-4" />}
        />
      </div>

      {dashboardData.latestPayrollRun && (
        <Card>
          <CardHeader>
            <CardTitle>آخر تشغيل رواتب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">{dashboardData.latestPayrollRun.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {dashboardData.latestPayrollRun.totalEmployees} موظف
                </p>
              </div>
              <div className="text-left">
                <PayrollStatusBadge status={dashboardData.latestPayrollRun.status} />
                <p className="text-sm font-medium mt-1">
                  {formatCurrency(dashboardData.latestPayrollRun.totalNet)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>تشغيلات هذا الشهر</CardTitle>
        </CardHeader>
        <CardContent>
          <PayrollTable
            headers={['التشغيل', 'الحالة', 'عدد الموظفين', 'الإجمالي']}
            emptyMessage="لا توجد تشغيلات هذا الشهر"
          >
            {dashboardData.monthlyRuns.map((run) => (
              <tr key={run.id} className="border-b transition-colors hover:bg-muted/50">
                <td className="p-4 align-middle">{run.name}</td>
                <td className="p-4 align-middle">
                  <PayrollStatusBadge status={run.status} />
                </td>
                <td className="p-4 align-middle">{run.totalEmployees}</td>
                <td className="p-4 align-middle">{formatCurrency(run.totalNet)}</td>
              </tr>
            ))}
          </PayrollTable>
        </CardContent>
      </Card>
    </div>
  );
}

function PayrollDashboardSkeleton() {
  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="h-10 w-48 bg-muted rounded animate-pulse" />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-24 bg-muted rounded animate-pulse" />
        ))}
      </div>
      <div className="h-64 bg-muted rounded animate-pulse" />
    </div>
  );
}
