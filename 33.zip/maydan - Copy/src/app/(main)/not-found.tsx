import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'الصفحة غير موجودة | ميدان',
  robots: { index: false, follow: true },
}

export default function NotFound() {
  return (
    <div className="py-20 text-center space-y-4">
      <div className="text-7xl font-bold text-primary/20">404</div>
      <h1 className="text-xl font-bold">الصفحة غير موجودة</h1>
      <p className="text-muted-foreground">
        الصفحة التي تبحث عنها غير موجودة.
      </p>
      <Link
        href="/"
        className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
      >
        العودة للرئيسية
      </Link>
    </div>
  )
}
