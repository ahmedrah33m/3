'use client'

import { useState, useEffect } from 'react'
import { useI18n } from '@/lib/i18n'
import { Wallet } from 'lucide-react'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import WalletView from '@/components/wallet/WalletView'
import PremiumView from '@/components/wallet/PremiumView'

export default function MidanWalletPage() {
  const { t } = useI18n()
  const [tab, setTab] = useState<string | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined') return
    const p = new URLSearchParams(window.location.search).get('tab')
    setTab(p === 'premium' ? 'premium' : 'wallet')
  }, [])

  const active = tab || 'wallet'

  return (
    <div className="max-w-5xl mx-auto px-4 py-4 space-y-6">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <Wallet className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-bold">{t.wallet.title}</h1>
          <p className="text-sm text-muted-foreground">{t.wallet.subtitle}</p>
        </div>
      </div>

      <Tabs value={active} onValueChange={setTab} className="w-full">
        <TabsList className="h-10 w-full flex-wrap justify-start overflow-x-auto">
          <TabsTrigger value="wallet">المحفظة</TabsTrigger>
          <TabsTrigger value="premium">الاشتراك المميز</TabsTrigger>
        </TabsList>
        <TabsContent value="wallet" className="mt-4">
          <WalletView />
        </TabsContent>
        <TabsContent value="premium" className="mt-4">
          <PremiumView />
        </TabsContent>
      </Tabs>
    </div>
  )
}