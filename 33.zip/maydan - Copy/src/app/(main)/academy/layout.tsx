import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'أكاديمية ميدان | ميدان',
  description: 'تعلم الاقتصاد والأعمال مع أكاديمية ميدان. دورات ومسارات تعليمية من خبراء عراقيين.',
  openGraph: {
    title: 'أكاديمية ميدان | ميدان',
    description: 'تعلم الاقتصاد والأعمال مع أكاديمية ميدان. دورات ومسارات تعليمية من خبراء عراقيين.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/academy`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'أكاديمية ميدان | ميدان',
    description: 'تعلم الاقتصاد والأعمال مع أكاديمية ميدان. دورات ومسارات تعليمية من خبراء عراقيين.',
  },
  alternates: {
    canonical: `${SITE_URL}/academy`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
