import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /control-center/branches لا يوجد قسم فروع في لوحة المالك — نُوجّه إلى /control-center */
export default function ControlCenterBranchesPage() {
  redirect('/control-center')
}