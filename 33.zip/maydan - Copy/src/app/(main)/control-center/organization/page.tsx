import { OwnerSubPage } from '@/components/owner/OwnerSubPage'

export default function Page() {
  return <OwnerSubPage section="settings" />
}
