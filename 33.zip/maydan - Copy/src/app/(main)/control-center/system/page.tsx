import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /control-center/system مكرر لـ /control-center/organization (نفس قسم settings) — نُوجّه إليه */
export default function ControlCenterSystemPage() {
  redirect('/control-center/organization')
}