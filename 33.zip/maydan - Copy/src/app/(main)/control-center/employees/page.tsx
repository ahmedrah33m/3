import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /control-center/employees لا يوجد قسم موظفين في لوحة المالك — نُوجّه إلى /control-center */
export default function ControlCenterEmployeesPage() {
  redirect('/control-center')
}