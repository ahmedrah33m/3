'use client'

import DataRoom from '@/components/DataRoom'

export default function DataRoomPage() {
  return <DataRoom />
}
