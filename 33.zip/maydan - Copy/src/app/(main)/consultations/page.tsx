import { ConsultationsMarketplace } from '@/components/ConsultationsMarketplace'

export default function ConsultationsPage() {
  return <ConsultationsMarketplace />
}
