import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الاستشارات الاقتصادية | ميدان',
  description: 'احصل على استشارات من خبراء ومتخصصين في الاقتصاد والأعمال.',
  openGraph: {
    title: 'الاستشارات الاقتصادية | ميدان',
    description: 'احصل على استشارات من خبراء ومتخصصين في الاقتصاد والأعمال.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/consultations`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الاستشارات الاقتصادية | ميدان',
    description: 'احصل على استشارات من خبراء ومتخصصين في الاقتصاد والأعمال.',
  },
  alternates: {
    canonical: `${SITE_URL}/consultations`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
