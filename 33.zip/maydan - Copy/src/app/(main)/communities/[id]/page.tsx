'use client'

import { useState, useEffect, useCallback } from 'react'
import { buildSrcSet } from '@/lib/image-url'
import { useParams, useRouter } from 'next/navigation'
import {
  Users,
  MessageSquare,
  Plus,
  Send,
  ChevronLeft,
  Globe,
  Lock,
  Eye,
  Trash2,
  Shield,
  Crown,
  UserCog,
  Clock,
  LogOut,
  CheckCircle,
  XCircle,
  Loader2,
  Sparkles,
  Settings,
  Heart,
  MessageCircle,
  X,
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'
import Link from 'next/link'
import { useStore } from '@/lib/store'
import { apiFetch } from '@/lib/api-client'
import { csrfFetch } from '@/hooks/useCsrf'
import { CommunityImagePicker } from '@/components/communities/community-image-picker'

const ROLE_LABELS: Record<string, string> = {
  owner: 'المالك',
  admin: 'مسؤول',
  moderator: 'مشرف',
  member: 'عضو',
  pending: 'قيد المراجعة',
}

const ROLE_COLORS: Record<string, string> = {
  owner: 'warning',
  admin: 'success',
  moderator: 'info',
  member: 'secondary',
  pending: 'outline',
} as const

interface CommunityData {
  id: string
  name: string
  description: string
  category: string
  visibility: string
  icon: string | null
  coverImage: string | null
  memberCount: number
  postCount: number
  createdAt: string
  owner: { id: string; name: string | null; avatar: string | null }
  _count: { members: number; posts: number }
  stats: { memberCount: number; postCount: number; activeToday: number }
}

interface Member {
  id: string
  userId: string
  role: string
  joinedAt: string
  user: { id: string; name: string | null; avatar: string | null; jobTitle?: string | null }
}

interface Post {
  id: string
  title: string
  content: string
  createdAt: string
  user: { id: string; name: string | null; avatar: string | null }
  likeCount?: number
  commentCount?: number
  likedByMe?: boolean
  _count?: { likes?: number; comments?: number }
}

interface Comment {
  id: string
  content: string
  createdAt: string
  userId: string
  user: { id: string; name: string | null; avatar: string | null }
}

interface PendingMember {
  id: string
  userId: string
  joinedAt: string
  user: { id: string; name: string | null; avatar: string | null; jobTitle?: string | null }
}

const CATEGORIES = ['عام','اقتصاد','تكنولوجيا','تعليم','صحة','ريادة أعمال','تجارة','استثمار','وظائف','سياحة','صناعة']
const VISIBILITY_OPTIONS = [
  { value: 'public', label: 'عام', icon: Globe },
  { value: 'private', label: 'خاص', icon: Lock },
  { value: 'restricted', label: 'مقيّد', icon: Eye },
]

export default function CommunityDetailPage() {
  const params = useParams()
  const router = useRouter()
  const communityId = params.id as string
  const { currentUser } = useStore()

  const [community, setCommunity] = useState<CommunityData | null>(null)
  const [loading, setLoading] = useState(true)
  const [members, setMembers] = useState<Member[]>([])
  const [pendingMembers, setPendingMembers] = useState<PendingMember[]>([])
  const [posts, setPosts] = useState<Post[]>([])
  const [postsPage, setPostsPage] = useState(1)
  const [postsTotalPages, setPostsTotalPages] = useState(0)
  const [myRole, setMyRole] = useState<string | null>(null)
  const [isMember, setIsMember] = useState(false)
  const [activeTab, setActiveTab] = useState('posts')
  const [membersPage, setMembersPage] = useState(1)
  const [membersTotalPages, setMembersTotalPages] = useState(0)

  // Create post dialog
  const [createPostOpen, setCreatePostOpen] = useState(false)
  const [postTitle, setPostTitle] = useState('')
  const [postContent, setPostContent] = useState('')
  const [submitting, setSubmitting] = useState(false)

  // Comments state per post
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({})
  const [commentsMap, setCommentsMap] = useState<Record<string, Comment[]>>({})
  const [commentsLoading, setCommentsLoading] = useState<Record<string, boolean>>({})
  const [commentTexts, setCommentTexts] = useState<Record<string, string>>({})
  const [commentSubmitting, setCommentSubmitting] = useState<Record<string, boolean>>({})

  // Settings dialog
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [editName, setEditName] = useState('')
  const [editDescription, setEditDescription] = useState('')
  const [editCategory, setEditCategory] = useState('عام')
  const [editVisibility, setEditVisibility] = useState('public')
  const [editCover, setEditCover] = useState<string | null>(null)
  const [editIcon, setEditIcon] = useState<string | null>(null)
  const [savingSettings, setSavingSettings] = useState(false)

  // Delete community confirm
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [deletingCommunity, setDeletingCommunity] = useState(false)

  const isAdmin = myRole === 'owner' || myRole === 'admin' || myRole === 'moderator'
  const isOwner = myRole === 'owner'

  const fetchCommunity = useCallback(async () => {
    try {
      const data = await apiFetch<{ community: CommunityData }>(`/api/communities/${communityId}`)
      setCommunity(data.community)
    } catch {
      toast.error('تعذر تحميل المجتمع')
    } finally {
      setLoading(false)
    }
  }, [communityId])

  const fetchMembership = useCallback(async () => {
    try {
      const data = await apiFetch<{ communities: { id: string; myRole: string }[] }>('/api/communities?my=true')
      const match = data.communities?.find((c) => c.id === communityId)
      if (match) {
        setMyRole(match.myRole)
        setIsMember(true)
      } else {
        setIsMember(false)
      }
    } catch {
      // not logged in or error
    }
  }, [communityId])

  const fetchPosts = useCallback(async () => {
    try {
      const data = await apiFetch<{ posts: Post[]; totalPages: number }>(
        `/api/communities/${communityId}/posts?page=${postsPage}&limit=10`
      )
      setPosts(data.posts || [])
      setPostsTotalPages(data.totalPages || 0)
    } catch {
      // non-critical
    }
  }, [communityId, postsPage])

  const fetchMembers = useCallback(async () => {
    try {
      const data = await apiFetch<{ members: Member[]; pending: PendingMember[]; totalPages: number }>(
        `/api/communities/${communityId}/members?page=${membersPage}&limit=20&pending=true`
      )
      setMembers(data.members || [])
      setPendingMembers(data.pending || [])
      setMembersTotalPages(data.totalPages || 0)
    } catch {
      // non-critical
    }
  }, [communityId, membersPage])

  useEffect(() => {
    if (communityId) { setLoading(true); fetchCommunity() }
  }, [communityId, fetchCommunity])

  useEffect(() => { fetchMembership() }, [fetchMembership])
  useEffect(() => { if (activeTab === 'posts') fetchPosts() }, [activeTab, fetchPosts])
  useEffect(() => { if (activeTab === 'members') fetchMembers() }, [activeTab, fetchMembers])

  // ── Actions ──

  const handleJoin = async () => {
    if (!community) return
    try {
      const action = community.visibility === 'public' ? 'join' : 'request'
      const res = await csrfFetch(`/api/communities/${communityId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      })
      const data = await res.json()
      if (res.ok) {
        if (data.action === 'joined') {
          toast.success('تم الانضمام بنجاح!')
          setIsMember(true)
          setMyRole('member')
          fetchCommunity()
        } else if (data.action === 'requested') {
          toast.success('تم إرسال طلب الانضمام')
        }
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    }
  }

  const handleLeave = async () => {
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'leave' }),
      })
      const data = await res.json()
      if (res.ok) {
        toast.success('تم مغادرة المجتمع')
        setIsMember(false)
        setMyRole(null)
        fetchCommunity()
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    }
  }

  const handleCreatePost = async () => {
    if (!postTitle.trim() || !postContent.trim()) {
      toast.error('العنوان والمحتوى مطلوبان')
      return
    }
    setSubmitting(true)
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/posts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: postTitle.trim(), content: postContent.trim() }),
      })
      const data = await res.json()
      if (res.ok) {
        toast.success('تم نشر المنشور بنجاح!')
        setCreatePostOpen(false)
        setPostTitle('')
        setPostContent('')
        setPostsPage(1)
        fetchPosts()
        fetchCommunity()
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDeletePost = async (postId: string) => {
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/posts?postId=${postId}`, {
        method: 'DELETE',
      })
      const data = await res.json()
      if (res.ok) {
        toast.success('تم حذف المنشور')
        fetchPosts()
        fetchCommunity()
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    }
  }

  // ── Likes ──
  const handleToggleLike = async (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p
        const liked = !p.likedByMe
        const count = (p.likeCount ?? 0) + (liked ? 1 : -1)
        return { ...p, likedByMe: liked, likeCount: count }
      })
    )
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/posts/${postId}/like`, {
        method: 'POST',
      })
      const data = await res.json()
      if (res.ok) {
        setPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, likedByMe: data.liked, likeCount: data.likeCount } : p
          )
        )
      }
    } catch {
      fetchPosts()
    }
  }

  // ── Comments ──
  const toggleComments = async (postId: string) => {
    setExpandedComments((prev) => ({ ...prev, [postId]: !prev[postId] }))
    if (!commentsMap[postId]) {
      setCommentsLoading((prev) => ({ ...prev, [postId]: true }))
      try {
        const data = await apiFetch<{ comments: Comment[] }>(
          `/api/communities/${communityId}/posts/${postId}/comments?limit=50`
        )
        setCommentsMap((prev) => ({ ...prev, [postId]: data.comments || [] }))
      } catch {
        setCommentsMap((prev) => ({ ...prev, [postId]: [] }))
      } finally {
        setCommentsLoading((prev) => ({ ...prev, [postId]: false }))
      }
    }
  }

  const handleAddComment = async (postId: string) => {
    const text = commentTexts[postId]?.trim()
    if (!text) return
    setCommentSubmitting((prev) => ({ ...prev, [postId]: true }))
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/posts/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: text }),
      })
      const data = await res.json()
      if (res.ok && data.comment) {
        setCommentsMap((prev) => ({
          ...prev,
          [postId]: [...(prev[postId] || []), data.comment],
        }))
        setCommentTexts((prev) => ({ ...prev, [postId]: '' }))
        setPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, commentCount: (p.commentCount ?? 0) + 1 } : p
          )
        )
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    } finally {
      setCommentSubmitting((prev) => ({ ...prev, [postId]: false }))
    }
  }

  const handleDeleteComment = async (postId: string, commentId: string) => {
    try {
      const res = await csrfFetch(
        `/api/communities/${communityId}/posts/${postId}/comments/${commentId}`,
        { method: 'DELETE' }
      )
      const data = await res.json()
      if (res.ok) {
        setCommentsMap((prev) => ({
          ...prev,
          [postId]: (prev[postId] || []).filter((c) => c.id !== commentId),
        }))
        setPosts((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, commentCount: Math.max((p.commentCount ?? 1) - 1, 0) } : p
          )
        )
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    }
  }

  // ── Settings ──
  const openSettings = () => {
    if (!community) return
    setEditName(community.name)
    setEditDescription(community.description)
    setEditCategory(community.category)
    setEditVisibility(community.visibility)
    setEditCover(community.coverImage)
    setEditIcon(community.icon)
    setSettingsOpen(true)
  }

  const handleSaveSettings = async () => {
    if (!editName.trim() || editName.trim().length < 3) {
      toast.error('اسم المجتمع مطلوب (3 أحرف على الأقل)')
      return
    }
    setSavingSettings(true)
    try {
      const res = await csrfFetch(`/api/communities/${communityId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName.trim(),
          description: editDescription.trim(),
          category: editCategory,
          visibility: editVisibility,
          coverImage: editCover,
          icon: editIcon,
        }),
      })
      const data = await res.json()
      if (res.ok) {
        toast.success('تم حفظ التغييرات')
        setSettingsOpen(false)
        fetchCommunity()
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    } finally {
      setSavingSettings(false)
    }
  }

  const handleDeleteCommunity = async () => {
    setDeletingCommunity(true)
    try {
      const res = await csrfFetch(`/api/communities/${communityId}`, {
        method: 'DELETE',
      })
      const data = await res.json()
      if (res.ok) {
        toast.success('تم حذف المجتمع')
        router.push('/communities')
      } else {
        toast.error(data.error || 'حدث خطأ')
      }
    } catch {
      toast.error('حدث خطأ في الاتصال')
    } finally {
      setDeletingCommunity(false)
      setDeleteConfirmOpen(false)
    }
  }

  // ── Members management ──
  const handleApproveMember = async (userId: string) => {
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, action: 'approve' }),
      })
      const data = await res.json()
      if (res.ok) { toast.success('تم قبول العضو'); fetchMembers(); fetchCommunity() }
      else toast.error(data.error || 'حدث خطأ')
    } catch { toast.error('حدث خطأ في الاتصال') }
  }

  const handleRejectMember = async (userId: string) => {
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, action: 'reject' }),
      })
      const data = await res.json()
      if (res.ok) { toast.success('تم رفض الطلب'); fetchMembers() }
      else toast.error(data.error || 'حدث خطأ')
    } catch { toast.error('حدث خطأ في الاتصال') }
  }

  const handleChangeRole = async (userId: string, role: string) => {
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role }),
      })
      const data = await res.json()
      if (res.ok) { toast.success('تم تغيير الدور'); fetchMembers() }
      else toast.error(data.error || 'حدث خطأ')
    } catch { toast.error('حدث خطأ في الاتصال') }
  }

  const handleRemoveMember = async (userId: string) => {
    try {
      const res = await csrfFetch(`/api/communities/${communityId}/members?userId=${userId}`, {
        method: 'DELETE',
      })
      const data = await res.json()
      if (res.ok) { toast.success('تم إزالة العضو'); fetchMembers(); fetchCommunity() }
      else toast.error(data.error || 'حدث خطأ')
    } catch { toast.error('حدث خطأ في الاتصال') }
  }

  const getVisibilityIcon = (visibility: string) => {
    switch (visibility) {
      case 'public': return <Globe className="h-3.5 w-3.5" />
      case 'private': return <Lock className="h-3.5 w-3.5" />
      case 'restricted': return <Eye className="h-3.5 w-3.5" />
      default: return <Globe className="h-3.5 w-3.5" />
    }
  }

  const getVisibilityLabel = (visibility: string) => {
    switch (visibility) {
      case 'public': return 'عام'
      case 'private': return 'خاص'
      case 'restricted': return 'مقيّد'
      default: return visibility
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-48 w-full rounded-xl" />
        <div className="flex items-end gap-4 -mt-12 px-6">
          <Skeleton className="h-20 w-20 rounded-2xl" />
          <div className="flex-1 space-y-2 pt-6"><Skeleton className="h-6 w-48" /><Skeleton className="h-4 w-32" /></div>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-lg" />)}
        </div>
        <Skeleton className="h-64 rounded-lg" />
      </div>
    )
  }

  if (!community) {
    return (
      <div className="text-center py-20">
        <Sparkles className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
        <h2 className="text-lg font-medium text-muted-foreground">المجتمع غير موجود</h2>
        <Button variant="outline" className="mt-4" onClick={() => router.push('/communities')}>
          العودة للمجتمعات
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Cover Image */}
      <div className="relative h-40 sm:h-52 rounded-xl overflow-hidden">
        {community.coverImage ? (
          <img src={community.coverImage} alt="" srcSet={buildSrcSet(community.coverImage) || undefined} sizes="100vw" decoding="async" loading="lazy" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-l from-primary/15 to-primary/5" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
      </div>

      {/* Community Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 -mt-12 sm:-mt-14 px-2 sm:px-6 relative z-10">
        <div className="relative">
          {community.icon ? (
            <img src={community.icon} alt={community.name} className="h-20 sm:h-24 w-20 sm:w-24 rounded-2xl border-4 border-background object-cover shadow-lg" />
          ) : (
            <div className="h-20 sm:h-24 w-20 sm:w-24 rounded-2xl border-4 border-background bg-primary/10 flex items-center justify-center shadow-lg">
              <span className="text-2xl sm:text-3xl font-bold text-primary">{community.name.charAt(0)}</span>
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-bold text-foreground">{community.name}</h1>
            <Badge variant={community.visibility === 'public' ? 'secondary' : 'outline'} size="sm">
              {getVisibilityIcon(community.visibility)}
              {getVisibilityLabel(community.visibility)}
            </Badge>
            <Badge variant="outline" size="sm">{community.category}</Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
            {community.description || 'لا يوجد وصف'}
          </p>
        </div>
        <div className="flex gap-2 sm:self-start sm:mt-0 mt-2">
          {isMember ? (
            <>
              {isAdmin && (
                <Button variant="outline" size="sm" onClick={openSettings}>
                  <Settings className="h-4 w-4 ms-1" />
                  إعدادات
                </Button>
              )}
              <Button variant="outline" size="sm" onClick={() => setCreatePostOpen(true)}>
                <Plus className="h-4 w-4 ms-1" />
                منشور جديد
              </Button>
              {!isOwner && (
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={handleLeave}>
                  <LogOut className="h-4 w-4 ms-1" />
                  مغادرة
                </Button>
              )}
            </>
          ) : (
            <Button size="sm" onClick={handleJoin}>
              <Users className="h-4 w-4 ms-1" />
              {community.visibility === 'public' ? 'انضمام' : 'طلب انضمام'}
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-3 text-center">
            <Users className="h-5 w-5 mx-auto text-primary mb-1" />
            <p className="text-lg font-bold text-foreground">{community._count?.members || community.memberCount}</p>
            <p className="text-xs text-muted-foreground">عضو</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <MessageSquare className="h-5 w-5 mx-auto text-primary mb-1" />
            <p className="text-lg font-bold text-foreground">{community._count?.posts || community.postCount}</p>
            <p className="text-xs text-muted-foreground">منشور</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <Clock className="h-5 w-5 mx-auto text-primary mb-1" />
            <p className="text-lg font-bold text-foreground">{community.stats?.activeToday || 0}</p>
            <p className="text-xs text-muted-foreground">نشط اليوم</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs dir="rtl" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full justify-start">
          <TabsTrigger value="posts" className="gap-1.5">
            <MessageSquare className="h-4 w-4" />
            المنشورات
          </TabsTrigger>
          <TabsTrigger value="members" className="gap-1.5">
            <Users className="h-4 w-4" />
            الأعضاء
            {pendingMembers.length > 0 && isAdmin && (
              <Badge variant="destructive" size="xs">{pendingMembers.length}</Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── Posts Tab ── */}
        <TabsContent value="posts" className="mt-4 space-y-4">
          {isMember && (
            <Card className="cursor-pointer hover:shadow-sm transition-shadow" onClick={() => setCreatePostOpen(true)}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-secondary flex items-center justify-center shrink-0">
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-sm text-muted-foreground flex-1">اكتب منشوراً جديداً في {community.name}...</p>
              </CardContent>
            </Card>
          )}

          {posts.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquare className="h-8 w-8 mx-auto text-muted-foreground/40 mb-3" />
              <p className="text-sm text-muted-foreground">
                {isMember ? 'لا توجد منشورات بعد — كن أول من ينشر!' : 'لا توجد منشورات في هذا المجتمع بعد'}
              </p>
            </div>
          ) : (
            <>
              {posts.map((post) => (
                <Card key={post.id} className="hover:shadow-sm transition-shadow">
                  <CardContent className="p-4 space-y-3">
                    {/* Author */}
                    <div className="flex items-center gap-2">
                      <Link href={`/profile/${post.user.id}`}>
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={post.user.avatar || undefined} />
                          <AvatarFallback>{post.user.name?.charAt(0) || '?'}</AvatarFallback>
                        </Avatar>
                      </Link>
                      <div className="flex-1 min-w-0">
                        <Link href={`/profile/${post.user.id}`}>
                          <p className="text-sm font-medium text-foreground hover:text-primary transition-colors truncate">{post.user.name}</p>
                        </Link>
                        <p className="text-xs text-muted-foreground">
                          {new Date(post.createdAt).toLocaleDateString('ar-IQ', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </p>
                      </div>
                      {(isAdmin || post.user.id === currentUser?.id) && (
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive" onClick={() => handleDeletePost(post.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <h3 className="font-semibold text-foreground text-sm">{post.title}</h3>
                    <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">{post.content}</p>

                    {/* Like + Comment buttons */}
                    <div className="flex items-center gap-4 pt-1 border-t border-border/50">
                      {currentUser ? (
                        <button
                          className={`flex items-center gap-1.5 text-xs font-medium transition-colors ${
                            post.likedByMe ? 'text-red-500' : 'text-muted-foreground hover:text-red-500'
                          }`}
                          onClick={() => handleToggleLike(post.id)}
                        >
                          <Heart className={`h-4 w-4 ${post.likedByMe ? 'fill-current' : ''}`} />
                          {post.likeCount ? `${post.likeCount} إعجاب` : 'إعجاب'}
                        </button>
                      ) : (
                        <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Heart className="h-4 w-4" />
                          {post.likeCount ? `${post.likeCount} إعجاب` : 'إعجاب'}
                        </span>
                      )}
                      <button
                        className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-primary transition-colors"
                        onClick={() => toggleComments(post.id)}
                      >
                        <MessageCircle className="h-4 w-4" />
                        {post.commentCount ?? 0} تعليق
                      </button>
                    </div>

                    {/* Comments section */}
                    {expandedComments[post.id] && (
                      <div className="space-y-3 pt-2 border-t border-border/50">
                        {commentsLoading[post.id] ? (
                          <div className="flex justify-center py-3">
                            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                          </div>
                        ) : (
                          <>
                            {(commentsMap[post.id] || []).map((comment) => (
                              <div key={comment.id} className="flex items-start gap-2 ps-2">
                                <Link href={`/profile/${comment.user.id}`}>
                                  <Avatar className="h-7 w-7 mt-0.5">
                                    <AvatarImage src={comment.user.avatar || undefined} />
                                    <AvatarFallback>{comment.user.name?.charAt(0) || '?'}</AvatarFallback>
                                  </Avatar>
                                </Link>
                                <div className="flex-1 min-w-0 bg-secondary/50 rounded-lg px-3 py-2">
                                  <div className="flex items-center gap-2">
                                    <Link href={`/profile/${comment.user.id}`}>
                                      <p className="text-xs font-medium text-foreground hover:text-primary">{comment.user.name}</p>
                                    </Link>
                                    <span className="text-2xs text-muted-foreground">
                                      {new Date(comment.createdAt).toLocaleDateString('ar-IQ')}
                                    </span>
                                    {(comment.userId === currentUser?.id || isAdmin) && (
                                      <button
                                        className="text-2xs text-destructive hover:underline ms-auto"
                                        onClick={() => handleDeleteComment(post.id, comment.id)}
                                      >
                                        حذف
                                      </button>
                                    )}
                                  </div>
                                  <p className="text-sm text-foreground/80 mt-1 leading-relaxed">{comment.content}</p>
                                </div>
                              </div>
                            ))}

                            {/* Add comment input */}
                            {isMember && (
                              <div className="flex items-center gap-2 ps-2">
                                <Avatar className="h-7 w-7 shrink-0">
                                  <AvatarImage src={currentUser?.avatar || undefined} />
                                  <AvatarFallback>{currentUser?.name?.charAt(0) || '?'}</AvatarFallback>
                                </Avatar>
                                <div className="flex-1 flex items-center gap-2">
                                  <Input
                                    aria-label="اكتب تعليقاً..."
                                    placeholder="اكتب تعليقاً..."
                                    value={commentTexts[post.id] || ''}
                                    onChange={(e) => setCommentTexts((prev) => ({ ...prev, [post.id]: e.target.value }))}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter' && !e.shiftKey) {
                                        e.preventDefault()
                                        handleAddComment(post.id)
                                      }
                                    }}
                                    className="h-8 text-xs"
                                  />
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8 w-8 p-0 shrink-0"
                                    disabled={commentSubmitting[post.id] || !commentTexts[post.id]?.trim()}
                                    onClick={() => handleAddComment(post.id)}
                                  >
                                    {commentSubmitting[post.id] ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <Send className="h-4 w-4" />
                                    )}
                                  </Button>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              {postsTotalPages > 1 && (
                <div className="flex justify-center gap-2 pt-2">
                  <Button variant="outline" size="sm" disabled={postsPage <= 1} onClick={() => setPostsPage((p) => p - 1)}>
                    <ChevronLeft className="h-4 w-4" /> السابق
                  </Button>
                  <span className="flex items-center px-3 text-sm text-muted-foreground">{postsPage} / {postsTotalPages}</span>
                  <Button variant="outline" size="sm" disabled={postsPage >= postsTotalPages} onClick={() => setPostsPage((p) => p + 1)}>
                    التالي <ChevronLeft className="h-4 w-4 rotate-180" />
                  </Button>
                </div>
              )}
            </>
          )}
        </TabsContent>

        {/* ── Members Tab ── */}
        <TabsContent value="members" className="mt-4 space-y-4">
          {isAdmin && pendingMembers.length > 0 && (
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  طلبات الانضمام ({pendingMembers.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {pendingMembers.map((pending) => (
                  <div key={pending.id} className="flex items-center gap-3 p-2 rounded-lg bg-background">
                    <Link href={`/profile/${pending.user.id}`}>
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={pending.user.avatar || undefined} />
                        <AvatarFallback>{pending.user.name?.charAt(0) || '?'}</AvatarFallback>
                      </Avatar>
                    </Link>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{pending.user.name}</p>
                      {pending.user.jobTitle && <p className="text-xs text-muted-foreground truncate">{pending.user.jobTitle}</p>}
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50" onClick={() => handleApproveMember(pending.userId)}>
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-destructive hover:bg-destructive/10" onClick={() => handleRejectMember(pending.userId)}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {members.length === 0 ? (
            <div className="text-center py-12">
              <Users className="h-8 w-8 mx-auto text-muted-foreground/40 mb-3" />
              <p className="text-sm text-muted-foreground">لا يوجد أعضاء بعد</p>
            </div>
          ) : (
            <>
              {members.map((member) => (
                <Card key={member.id} className="hover:shadow-sm transition-shadow">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-3">
                      <Link href={`/profile/${member.user.id}`}>
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={member.user.avatar || undefined} />
                          <AvatarFallback>{member.user.name?.charAt(0) || '?'}</AvatarFallback>
                        </Avatar>
                      </Link>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Link href={`/profile/${member.user.id}`}>
                            <p className="text-sm font-medium text-foreground truncate hover:text-primary transition-colors">{member.user.name}</p>
                          </Link>
                          <Badge variant={ROLE_COLORS[member.role] as any || 'secondary'} size="xs">
                            {member.role === 'owner' && <Crown className="h-2.5 w-2.5 ms-0.5" />}
                            {member.role === 'admin' && <Shield className="h-2.5 w-2.5 ms-0.5" />}
                            {member.role === 'moderator' && <UserCog className="h-2.5 w-2.5 ms-0.5" />}
                            {ROLE_LABELS[member.role] || member.role}
                          </Badge>
                        </div>
                        {member.user.jobTitle && <p className="text-xs text-muted-foreground truncate">{member.user.jobTitle}</p>}
                        <p className="text-2xs text-muted-foreground/60 mt-0.5">انضم في {new Date(member.joinedAt).toLocaleDateString('ar-IQ')}</p>
                      </div>
                      {isAdmin && member.role !== 'owner' && (
                        <div className="flex gap-1">
                          <Select onValueChange={(value) => handleChangeRole(member.userId, value)}>
                            <SelectTrigger className="h-7 w-24 text-[11px]">
                              <SelectValue placeholder={ROLE_LABELS[member.role]} />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="admin">مسؤول</SelectItem>
                              <SelectItem value="moderator">مشرف</SelectItem>
                              <SelectItem value="member">عضو</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive hover:bg-destructive/10" onClick={() => handleRemoveMember(member.userId)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
              {membersTotalPages > 1 && (
                <div className="flex justify-center gap-2 pt-2">
                  <Button variant="outline" size="sm" disabled={membersPage <= 1} onClick={() => setMembersPage((p) => p - 1)}>
                    <ChevronLeft className="h-4 w-4" /> السابق
                  </Button>
                  <span className="flex items-center px-3 text-sm text-muted-foreground">{membersPage} / {membersTotalPages}</span>
                  <Button variant="outline" size="sm" disabled={membersPage >= membersTotalPages} onClick={() => setMembersPage((p) => p + 1)}>
                    التالي <ChevronLeft className="h-4 w-4 rotate-180" />
                  </Button>
                </div>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* ── Create Post Dialog ── */}
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent aria-label="إنشاء منشور جديد">
          <DialogHeader>
            <DialogTitle>منشور جديد في {community.name}</DialogTitle>
            <DialogDescription>شارك أفكارك ومحتواك مع أعضاء المجتمع</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">العنوان <span className="text-destructive">*</span></label>
              <Input aria-label="عنوان المنشور..." placeholder="عنوان المنشور..." value={postTitle} onChange={(e) => setPostTitle(e.target.value)} maxLength={120} className="text-start" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">المحتوى <span className="text-destructive">*</span></label>
              <Textarea aria-label="اكتب محتوى المنشور..." placeholder="اكتب محتوى المنشور..." value={postContent} onChange={(e) => setPostContent(e.target.value)} rows={5} maxLength={5000} className="text-start resize-none" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreatePostOpen(false)} disabled={submitting}>إلغاء</Button>
            <Button onClick={handleCreatePost} disabled={submitting || !postTitle.trim() || !postContent.trim()}>
              {submitting ? <><Loader2 className="h-4 w-4 ms-1 animate-spin" /> جارٍ النشر...</> : <><Send className="h-4 w-4 ms-1" /> نشر</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Settings Dialog ── */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent aria-label="إعدادات المجتمع" className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              إعدادات المجتمع
            </DialogTitle>
            <DialogDescription>تعديل معلومات المجتمع وإعداداته</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">اسم المجتمع <span className="text-destructive">*</span></label>
              <Input aria-label="اسم المجتمع" value={editName} onChange={(e) => setEditName(e.target.value)} maxLength={80} className="text-start" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">الوصف</label>
              <Textarea aria-label="وصف المجتمع" value={editDescription} onChange={(e) => setEditDescription(e.target.value)} rows={3} maxLength={500} className="text-start resize-none" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <CommunityImagePicker label="غلاف المجتمع" value={editCover} onChange={setEditCover} />
              <CommunityImagePicker label="أيقونة المجتمع" value={editIcon} onChange={setEditIcon} avatar aspectClass="h-28 rounded-lg" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">التصنيف</label>
              <Select value={editCategory} onValueChange={setEditCategory}>
                <SelectTrigger className="text-start"><SelectValue placeholder="اختر التصنيف" /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">نوع الظهور</label>
              <div className="grid grid-cols-3 gap-2">
                {VISIBILITY_OPTIONS.map((opt) => {
                  const Icon = opt.icon
                  return (
                    <button key={opt.value} type="button" onClick={() => setEditVisibility(opt.value)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border-2 transition-colors text-center ${editVisibility === opt.value ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/50'}`}>
                      <Icon className="h-4 w-4" />
                      <span className="text-xs font-medium">{opt.label}</span>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            {isOwner && (
              <Button variant="destructive" onClick={() => { setSettingsOpen(false); setDeleteConfirmOpen(true) }} className="me-auto">
                <Trash2 className="h-4 w-4 ms-1" />
                حذف المجتمع
              </Button>
            )}
            <Button variant="outline" onClick={() => setSettingsOpen(false)} disabled={savingSettings}>إلغاء</Button>
            <Button onClick={handleSaveSettings} disabled={savingSettings || !editName.trim()}>
              {savingSettings ? <><Loader2 className="h-4 w-4 ms-1 animate-spin" /> جارٍ الحفظ...</> : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete Community Confirm Dialog ── */}
      <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <DialogContent aria-label="تأكيد حذف المجتمع" className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-destructive flex items-center gap-2">
              <Trash2 className="h-5 w-5" />
              حذف المجتمع
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف مجتمع "{community.name}"؟ لا يمكن التراجع عن هذا الإجراء.
              سيُحذف جميع المنشورات والأعضاء نهائياً.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)} disabled={deletingCommunity}>إلغاء</Button>
            <Button variant="destructive" onClick={handleDeleteCommunity} disabled={deletingCommunity}>
              {deletingCommunity ? <><Loader2 className="h-4 w-4 ms-1 animate-spin" /> جارٍ الحذف...</> : 'نعم، احذف المجتمع'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
