'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import {
  Search,
  Users,
  Plus,
  MessageSquare,
  ChevronLeft,
  Globe,
  Lock,
  Eye,
  Loader2,
  Sparkles,
  Image as ImageIcon,
  X,
  Star,
  Flame,
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'
import Link from 'next/link'
import { buildSrcSet } from '@/lib/image-url'
import { apiFetch, apiPost } from '@/lib/api-client'
import { useStore } from '@/lib/store'
import { CommunityImagePicker } from '@/components/communities/community-image-picker'

const CATEGORIES = [
  'all',
  'عام',
  'اقتصاد',
  'تكنولوجيا',
  'تعليم',
  'صحة',
  'ريادة أعمال',
  'تجارة',
  'استثمار',
  'وظائف',
  'سياحة',
  'صناعة',
]

const VISIBILITY_OPTIONS = [
  { value: 'public', label: 'عام', icon: Globe },
  { value: 'private', label: 'خاص', icon: Lock },
  { value: 'restricted', label: 'مقيّد', icon: Eye },
]

const SORT_OPTIONS = [
  { value: 'popular', label: 'الأكثر شعبية', icon: Flame },
  { value: 'recent', label: 'الأحدث', icon: Sparkles },
  { value: 'active', label: 'الأكثر نشاطاً', icon: MessageSquare },
]

interface Community {
  id: string
  name: string
  description: string
  category: string
  visibility: string
  icon: string | null
  coverImage: string | null
  memberCount: number
  postCount: number
  createdAt: string
  owner: { id: string; name: string | null; avatar: string | null }
  _count: { members: number; posts: number }
  myRole?: string
}

function CommunityCardRow({ community }: { community: Community }) {
  return (
    <Link href={`/communities/${community.id}`}>
      <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer group h-full">
        <div className="h-28 bg-gradient-to-l from-primary/10 to-primary/5 relative overflow-hidden">
          {community.coverImage ? (
            <img
              src={community.coverImage}
              alt=""
              srcSet={buildSrcSet(community.coverImage) || undefined}
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
              decoding="async"
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Sparkles className="h-8 w-8 text-primary/20" />
            </div>
          )}
          {community.visibility !== 'public' && (
            <div className="absolute top-2 start-2">
              <Badge
                size="xs"
                className="backdrop-blur-sm bg-background/80"
              >
                {community.visibility === 'private' ? <Lock className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                {community.visibility === 'private' ? 'خاص' : 'مقيّد'}
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-4">
          <div className="flex items-start gap-3 -mt-8">
            <div className="h-12 w-12 rounded-xl border-2 border-background bg-secondary flex items-center justify-center shadow-sm shrink-0 overflow-hidden">
              {community.icon ? (
                <img src={community.icon} alt="" className="h-full w-full object-cover" />
              ) : (
                <span className="text-lg font-bold text-primary">
                  {community.name.charAt(0)}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0 pt-4">
              <h3 className="font-semibold text-foreground truncate text-sm">
                {community.name}
              </h3>
              <p className="text-xs text-muted-foreground truncate mt-0.5">
                {community.category}
                {community.myRole && (
                  <span className="text-primary ms-1">· أنا عضو</span>
                )}
              </p>
            </div>
          </div>

          {community.description && (
            <p className="text-xs text-muted-foreground mt-3 line-clamp-2 leading-relaxed">
              {community.description}
            </p>
          )}

          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Users className="h-3.5 w-3.5" />
              {community._count?.members || community.memberCount} عضو
            </span>
            <span className="flex items-center gap-1">
              <MessageSquare className="h-3.5 w-3.5" />
              {community._count?.posts || community.postCount} منشور
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

export default function CommunitiesPage() {
  const { isAuthenticated } = useStore()
  const [communities, setCommunities] = useState<Community[]>([])
  const [myCommunities, setMyCommunities] = useState<Community[]>([])
  const [featured, setFeatured] = useState<Community[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')
  const [sort, setSort] = useState('popular')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [total, setTotal] = useState(0)

  // Create dialog state
  const [createOpen, setCreateOpen] = useState(false)
  const [creating, setCreating] = useState(false)
  const [newName, setNewName] = useState('')
  const [newDescription, setNewDescription] = useState('')
  const [newCategory, setNewCategory] = useState('عام')
  const [newVisibility, setNewVisibility] = useState('public')
  const [newCover, setNewCover] = useState<string | null>(null)
  const [newIcon, setNewIcon] = useState<string | null>(null)

  const fetchCommunities = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(page), limit: '12', sort })
      if (search) params.set('search', search)
      if (category !== 'all') params.set('category', category)
      const data = await apiFetch<{ communities: Community[]; totalPages: number; total: number }>(
        `/api/communities?${params}`
      )
      setCommunities(data.communities || [])
      setTotalPages(data.totalPages || 0)
      setTotal(data.total || 0)
    } catch {
      toast.error('تعذر تحميل المجتمعات')
    } finally {
      setLoading(false)
    }
  }, [search, category, page, sort])

  const fetchSidebar = useCallback(async () => {
    try {
      const [feat, mine] = await Promise.all([
        apiFetch<{ communities: Community[] }>('/api/communities?featured=true&limit=5'),
        isAuthenticated
          ? apiFetch<{ communities: Community[] }>('/api/communities?my=true')
          : Promise.resolve({ communities: [] }),
      ])
      setFeatured(feat.communities || [])
      setMyCommunities(mine.communities || [])
    } catch {
      // non-critical — grid still loads
    }
  }, [isAuthenticated])

  useEffect(() => {
    fetchCommunities()
  }, [fetchCommunities])

  useEffect(() => {
    fetchSidebar()
  }, [fetchSidebar])

  const handleSearch = (value: string) => {
    setSearch(value)
    setPage(1)
  }

  const handleCreate = async () => {
    if (!newName.trim() || newName.trim().length < 3) {
      toast.error('اسم المجتمع مطلوب (3 أحرف على الأقل)')
      return
    }
    setCreating(true)
    try {
      await apiPost('/api/communities', {
        name: newName.trim(),
        description: newDescription.trim(),
        category: newCategory,
        visibility: newVisibility,
        icon: newIcon,
        coverImage: newCover,
      })
      toast.success('تم إنشاء المجتمع بنجاح!')
      setCreateOpen(false)
      setNewName('')
      setNewDescription('')
      setNewCategory('عام')
      setNewVisibility('public')
      setNewCover(null)
      setNewIcon(null)
      setPage(1)
      fetchCommunities()
      fetchSidebar()
    } catch (err: any) {
      toast.error(err?.message || 'حدث خطأ أثناء إنشاء المجتمع')
    } finally {
      setCreating(false)
    }
  }

  const getVisibilityIcon = (visibility: string) => {
    switch (visibility) {
      case 'public': return <Globe className="h-3.5 w-3.5" />
      case 'private': return <Lock className="h-3.5 w-3.5" />
      case 'restricted': return <Eye className="h-3.5 w-3.5" />
      default: return <Globe className="h-3.5 w-3.5" />
    }
  }

  const getVisibilityLabel = (visibility: string) => {
    switch (visibility) {
      case 'public': return 'عام'
      case 'private': return 'خاص'
      case 'restricted': return 'مقيّد'
      default: return visibility
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            المجتمعات
          </h1>
          {total > 0 && (
            <p className="text-sm text-muted-foreground mt-1">
              {total} مجتمع نشط
            </p>
          )}
        </div>
        <Button onClick={() => setCreateOpen(true)} size="sm">
          <Plus className="h-4 w-4 ms-1" />
          إنشاء مجتمع
        </Button>
      </div>

      {/* Featured communities */}
      {!loading && featured.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground flex items-center gap-1.5 mb-3">
            <Star className="h-4 w-4 text-primary" />
            مجتمعات مناسبة لك
          </h2>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {featured.map((c) => (
              <Link
                key={c.id}
                href={`/communities/${c.id}`}
                className="shrink-0 w-52 group"
              >
                <Card className="overflow-hidden hover:shadow-md transition-shadow h-full">
                  <div className="h-20 bg-gradient-to-l from-primary/15 to-primary/5 relative overflow-hidden">
                    {c.coverImage ? (
                      <img src={c.coverImage} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Sparkles className="h-6 w-6 text-primary/20" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center overflow-hidden shrink-0">
                        {c.icon ? (
                          <img src={c.icon} alt="" className="h-full w-full object-cover" />
                        ) : (
                          <span className="text-sm font-bold text-primary">{c.name.charAt(0)}</span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{c.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {c._count?.members || c.memberCount} عضو
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* My communities */}
      {isAuthenticated && myCommunities.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground flex items-center gap-1.5 mb-3">
            <Users className="h-4 w-4 text-primary" />
            مجتمعاتي
          </h2>
          <div className="flex gap-2.5 flex-wrap">
            {myCommunities.map((c) => (
              <Link key={c.id} href={`/communities/${c.id}`}>
                <Card className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-2.5 flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center overflow-hidden shrink-0">
                      {c.icon ? (
                        <img src={c.icon} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <span className="text-sm font-bold text-primary">{c.name.charAt(0)}</span>
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate max-w-[140px]">{c.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {c._count?.members || c.memberCount} عضو
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Search & Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            aria-label="ابحث عن مجتمع..." placeholder="ابحث عن مجتمع..."
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
            className="ps-10 text-start"
          />
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none flex-1">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => { handleSearch(''); setCategory(cat); setPage(1) }}
                className={`whitespace-nowrap px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                  category === cat
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                }`}
              >
                {cat === 'all' ? 'الكل' : cat}
              </button>
            ))}
          </div>
          <Select value={sort} onValueChange={(v) => { setSort(v); setPage(1) }}>
            <SelectTrigger className="w-[140px] shrink-0 text-sm">
              <SelectValue placeholder="الترتيب" />
            </SelectTrigger>
            <SelectContent>
              {SORT_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-28 w-full" />
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-10 w-10 rounded-xl" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : communities.length === 0 ? (
        <div className="text-center py-16">
          <Sparkles className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">لا توجد مجتمعات</h3>
          <p className="text-sm text-muted-foreground/70 mt-1">
            {search || category !== 'all'
              ? 'لم يتم العثور على نتائج تطابق بحثك'
              : 'كن أول من ينشئ مجتمعاً!'}
          </p>
          {!search && category === 'all' && (
            <Button
              onClick={() => setCreateOpen(true)}
              variant="outline"
              className="mt-4"
              size="sm"
            >
              <Plus className="h-4 w-4 ms-1" />
              إنشاء مجتمع جديد
            </Button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {communities.map((community) => (
              <CommunityCardRow key={community.id} community={community} />
            ))}
          </div>

          {totalPages > 1 && (
            <div className="flex justify-center gap-2 pt-4">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
              >
                <ChevronLeft className="h-4 w-4" />
                السابق
              </Button>
              <span className="flex items-center px-3 text-sm text-muted-foreground">
                {page} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                التالي
                <ChevronLeft className="h-4 w-4 rotate-180" />
              </Button>
            </div>
          )}
        </>
      )}

      {/* Create Community Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent aria-label="إنشاء مجتمع جديد" className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>إنشاء مجتمع جديد</DialogTitle>
            <DialogDescription>
              أنشئ مجتمعاً خاصاً بك وابدأ بجمع الأعضاء والمحادثات
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                اسم المجتمع <span className="text-destructive">*</span>
              </label>
              <Input
                aria-label="مثال: مجتمع رواد الأعمال العراقيين" placeholder="مثال: مجتمع رواد الأعمال العراقيين"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                maxLength={80}
                className="text-start"
              />
              <p className="text-xs text-muted-foreground">
                3 أحرف على الأقل
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                الوصف
              </label>
              <Textarea
                aria-label="اكتب وصفاً مختصراً عن المجتمع..." placeholder="اكتب وصفاً مختصراً عن المجتمع..."
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                rows={3}
                maxLength={500}
                className="text-start resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <CommunityImagePicker label="غلاف المجتمع" value={newCover} onChange={setNewCover} />
              <CommunityImagePicker label="أيقونة المجتمع" value={newIcon} onChange={setNewIcon} avatar aspectClass="h-28 rounded-lg" />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                التصنيف
              </label>
              <Select value={newCategory} onValueChange={setNewCategory}>
                <SelectTrigger className="text-start">
                  <SelectValue placeholder="اختر التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.filter((c) => c !== 'all').map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                نوع الظهور
              </label>
              <div className="grid grid-cols-3 gap-2">
                {VISIBILITY_OPTIONS.map((opt) => {
                  const Icon = opt.icon
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setNewVisibility(opt.value)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border-2 transition-colors text-center ${
                        newVisibility === opt.value
                          ? 'border-primary bg-primary/5 text-primary'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span className="text-xs font-medium">{opt.label}</span>
                    </button>
                  )
                })}
              </div>
              <p className="text-xs text-muted-foreground">
                {newVisibility === 'public'
                  ? 'يمكن للجميع الانضمام مباشرة'
                  : newVisibility === 'private'
                  ? 'يجب تقديم طلب انضمام وعرضه من الإدارة'
                  : 'يمكن رؤية المجتمع لكن الانضمام يتطلب موافقة'}
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)} disabled={creating}>
              إلغاء
            </Button>
            <Button onClick={handleCreate} disabled={creating || !newName.trim()}>
              {creating ? (
                <>
                  <Loader2 className="h-4 w-4 ms-1 animate-spin" />
                  جارٍ الإنشاء...
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 ms-1" />
                  إنشاء
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}