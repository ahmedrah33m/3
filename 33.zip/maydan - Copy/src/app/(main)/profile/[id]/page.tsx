'use client'

import { useEffect } from 'react'
import { useParams } from 'next/navigation'
import { useStore } from '@/lib/store'
import ProfileView from '@/components/ProfileView'

export default function ProfilePage() {
  const params = useParams()
  const id = params.id as string

  useEffect(() => {
    // Set the profile ID in store for backward compatibility
    useStore.setState({ currentProfileId: id })
  }, [id])

  return <ProfileView />
}
