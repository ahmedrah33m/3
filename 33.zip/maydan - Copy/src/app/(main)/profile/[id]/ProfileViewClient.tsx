'use client'

import { useEffect } from 'react'
import { useStore } from '@/lib/store'
import ProfileView from '@/components/ProfileView'

export default function ProfileViewClient({ profileId }: { profileId: string }) {
  useEffect(() => {
    useStore.setState({ currentProfileId: profileId })
  }, [profileId])

  return <ProfileView />
}