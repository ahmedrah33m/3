import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/session'

// PROFILE-001 FIX: The sidebar links to `/profile/me` as a literal string
// (5 references in navigation-config.ts). Without this page, those links 404.
// This server component resolves "me" to the authenticated user's ID and
// redirects to the canonical `/profile/<id>` route.
//
// All query params (e.g. `?tab=settings`) are preserved.

export default async function ProfileMePage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const user = await getCurrentUser()

  if (!user) {
    // Unauthenticated — send to login.
    const sp = await searchParams
    const query = new URLSearchParams()
    for (const [k, v] of Object.entries(sp)) {
      if (typeof v === 'string') query.set(k, v)
      else if (Array.isArray(v) && v.length) query.set(k, v[0])
    }
    const qs = query.toString()
    redirect(`/login${qs ? `?${qs}` : ''}`)
  }

  // Forward query string so `?tab=settings` survives the redirect.
  const sp = await searchParams
  const query = new URLSearchParams()
  for (const [k, v] of Object.entries(sp)) {
    if (typeof v === 'string') query.set(k, v)
    else if (Array.isArray(v) && v.length) query.set(k, v[0])
  }
  const qs = query.toString()
  redirect(`/profile/${user.id}${qs ? `?${qs}` : ''}`)
}
