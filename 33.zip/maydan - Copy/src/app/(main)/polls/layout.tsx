import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'استطلاعات الرأي | ميدان',
  description: 'شارك رأيك في استطلاعات الرأي الاقتصادية على منصة ميدان.',
  openGraph: {
    title: 'استطلاعات الرأي | ميدان',
    description: 'شارك رأيك في استطلاعات الرأي الاقتصادية على منصة ميدان.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/polls`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'استطلاعات الرأي | ميدان',
    description: 'شارك رأيك في استطلاعات الرأي الاقتصادية على منصة ميدان.',
  },
  alternates: {
    canonical: `${SITE_URL}/polls`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
