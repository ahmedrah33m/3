'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { QRCodeSVG } from 'qrcode.react'
import { ShieldCheck, CheckCircle2, Clock, XCircle, User, Briefcase, MapPin } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useI18n } from '@/lib/i18n'

const SECTION_LABELS: Record<string, string> = {
  IDENTITY: 'الهوية',
  EDUCATION: 'التعليم',
  CERTIFICATES: 'الشهادات',
  EXPERIENCE: 'الخبرة',
  PROJECTS: 'المشاريع',
  SKILLS: 'المهارات',
  LANGUAGES: 'اللغات',
  PUBLICATIONS: 'المنشورات',
  RESEARCH: 'الأبحاث',
  ACHIEVEMENTS: 'الإنجازات',
  RECOMMENDATIONS: 'التوصيات',
  VERIFIED_EXPERIENCE: 'خبرة موثّقة',
  VERIFIED_CERTIFICATES: 'شهادات موثّقة',
  EMPLOYMENT_HISTORY: 'التاريخ الوظيفي',
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'VERIFIED')
    return (
      <Badge className="bg-green-500 text-white gap-1">
        <CheckCircle2 className="h-3 w-3" /> موثّق
      </Badge>
    )
  if (status === 'PENDING')
    return (
      <Badge className="bg-amber-500 text-white gap-1">
        <Clock className="h-3 w-3" /> قيد المراجعة
      </Badge>
    )
  return (
    <Badge className="bg-red-500 text-white gap-1">
      <XCircle className="h-3 w-3" /> غير موثّق
    </Badge>
  )
}

export default function PublicPassportPage() {
  const { t, dir } = useI18n()
  const params = useParams<{ publicId: string }>()
  const publicId = params.publicId
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!publicId) return
    setLoading(true)
    fetch(`/api/verify/${publicId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) setError(d.error)
        else setData(d)
      })
      .catch(() => setError('تعذّر تحميل الملف المهني'))
      .finally(() => setLoading(false))
  }, [publicId])

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto py-16 text-center text-muted-foreground" dir={dir}>
        جاري التحميل...
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="max-w-3xl mx-auto py-16 text-center" dir={dir}>
        <XCircle className="h-12 w-12 text-red-500 mx-auto mb-3" />
        <p className="text-red-600">{error || 'الملف المهني غير موجود'}</p>
      </div>
    )
  }

  const verifyUrl = typeof window !== 'undefined' ? `${window.location.origin}/verify/${publicId}` : data.verifyUrl

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 space-y-6" dir={dir}>
      <Card className="border-primary/20">
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <ShieldCheck className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">جواز ميدان المهني</CardTitle>
          <div className="flex items-center justify-center gap-3 mt-2 text-sm text-muted-foreground">
            <User className="h-4 w-4" /> {data.candidate?.name || 'مرشّح'}
            {data.candidate?.jobTitle && (
              <>
                <Briefcase className="h-4 w-4" /> {data.candidate.jobTitle}
              </>
            )}
            {data.candidate?.location && (
              <>
                <MapPin className="h-4 w-4" /> {data.candidate.location}
              </>
            )}
          </div>
          <div className="flex items-center justify-center gap-2 mt-3">
            <StatusBadge status="VERIFIED" />
            <span className="text-xs text-muted-foreground">
              {data.summary.verified} موثّق · {data.summary.pending} قيد المراجعة · {data.summary.unverified} غير موثّق
            </span>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col items-center gap-3">
          <div className="p-3 bg-white rounded-lg">
            <QRCodeSVG value={verifyUrl} size={160} />
          </div>
          <p className="text-xs text-muted-foreground text-center break-all">{verifyUrl}</p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {data.sections.map((s: any) => (
          <Card key={s.category}>
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{SECTION_LABELS[s.category] || s.category}</h3>
                <StatusBadge status={s.status} />
              </div>
              {s.data && (
                <pre className="text-xs text-muted-foreground bg-muted/40 rounded p-2 overflow-auto max-h-40 whitespace-pre-wrap">
                  {JSON.stringify(s.data, null, 2)}
                </pre>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
