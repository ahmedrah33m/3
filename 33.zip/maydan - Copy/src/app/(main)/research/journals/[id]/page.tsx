import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import {
  ArrowRight, BookOpen, Building2, Calendar, Clock, DollarSign, FileCheck2,
  Globe, Mail, Percent, Send, Tag, CheckCircle2,
} from 'lucide-react'
import { db } from '@/lib/db'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'

export const dynamic = 'force-dynamic'

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params
  const journal = await db.researchJournal.findUnique({ where: { id }, select: { name: true, nameAr: true, publisherAr: true } })
  if (!journal) return { title: 'المجلة غير موجودة | ميدان' }
  const title = journal.nameAr || journal.name
  return {
    title: `${title} | ميدان`,
    description: `دليل النشر في مجلة ${title} — المعامل والمؤشرات وشروط القبول وطريقة التقديم.`,
  }
}

export default async function JournalDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const [journal, others] = await Promise.all([
    db.researchJournal.findUnique({ where: { id } }),
    db.researchJournal.findMany({ where: { id: { not: id }, status: 'ACTIVE' }, orderBy: { createdAt: 'asc' }, take: 4 }),
  ])

  if (!journal) notFound()

  const indexedIn = (journal.indexedIn as string[]) ?? []
  const langLabel = journal.language === 'ar' ? 'عربي' : journal.language === 'en' ? 'English' : journal.language === 'ku' ? 'الكوردية' : journal.language

  const meta = [
    { icon: Calendar, label: 'الإصدار', val: journal.frequency },
    { icon: Clock, label: 'مدة التحكيم', val: journal.reviewTime },
    { icon: Percent, label: 'نسبة القبول', val: journal.acceptanceRate },
    { icon: DollarSign, label: 'رسوم النشر المفتوح', val: journal.apcFee },
    { icon: Building2, label: 'الناشر', val: journal.publisherAr || journal.publisher },
    { icon: Globe, label: 'اللغة', val: langLabel },
  ].filter(m => m.val)

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-5 pb-10" dir="rtl">
      {/* Back link */}
      <Link href="/research?tab=journals" className="inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors">
        <ArrowRight className="h-4 w-4 rotate-180" /> العودة إلى دليل المجلات
      </Link>

      {/* ═══ HERO ═══ */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-blue-600 to-cyan-600 p-6 md:p-10 text-white shadow-2xl">
        <div className="absolute inset-0 opacity-10"><div className="absolute top-0 right-0 w-80 h-80 bg-white rounded-full -translate-x-1/3 -translate-y-1/3" /><div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full translate-x-1/4 translate-y-1/4" /></div>
        <div className="relative">
          <div className="flex items-center gap-2 mb-2"><div className="h-8 w-8 rounded-lg bg-white/20 flex items-center justify-center"><BookOpen className="h-4 w-4" /></div><Badge className="bg-white/20 text-white border-0 text-2xs">مجلة علمية</Badge></div>
          <h1 className="text-2xl md:text-4xl font-bold mb-1">{journal.nameAr || journal.name}</h1>
          {journal.nameAr && journal.name !== journal.nameAr && <p className="text-base text-white/80 font-medium" dir="ltr">{journal.name}</p>}
          <p className="text-sm text-white/60 mt-2">ISSN: {journal.issn || '—'} · {journal.publisherAr || journal.publisher} · {journal.country}</p>
          <div className="flex flex-wrap gap-2 mt-5">
            {journal.scopus && <Badge className="bg-white/20 text-white border-0 text-2xs">Scopus</Badge>}
            {journal.openAccess && <Badge className="bg-emerald-400/30 text-white border-0 text-2xs">Open Access</Badge>}
            {journal.impactFactor && <Badge className="bg-white/20 text-white border-0 text-2xs">Impact Factor: {journal.impactFactor}</Badge>}
          </div>
        </div>
      </div>

      {/* ═══ ACTIONS ═══ */}
      <div className="flex flex-wrap gap-2">
        {journal.submissionUrl && (
          <a href={journal.submissionUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-l from-blue-500 to-indigo-600 text-white text-sm font-medium hover:shadow-lg hover:shadow-blue-500/20 transition-all">
            <Send className="h-4 w-4" /> صفحة التقديم للنشر
          </a>
        )}
        {journal.website && (
          <a href={journal.website} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm font-medium hover:bg-muted transition-all">
            <Globe className="h-4 w-4" /> موقع المجلة
          </a>
        )}
        {journal.email && (
          <a href={`mailto:${journal.email}`} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border text-sm font-medium hover:bg-muted transition-all">
            <Mail className="h-4 w-4" /> مراسلة المجلة
          </a>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-5">
        <div className="space-y-5">
          {/* ═══ الوصف والنطاق ═══ */}
          {journal.description && (
            <Card className="border-0 shadow-md bg-card/80">
              <CardContent className="p-6">
                <h2 className="text-base font-bold mb-3 flex items-center gap-2"><BookOpen className="h-4 w-4 text-blue-500" /> عن المجلة</h2>
                <p className="text-sm leading-relaxed text-muted-foreground">{journal.description}</p>
              </CardContent>
            </Card>
          )}

          {journal.scope && (
            <Card className="border-0 shadow-md bg-card/80">
              <CardContent className="p-6">
                <h2 className="text-base font-bold mb-3 flex items-center gap-2"><FileCheck2 className="h-4 w-4 text-violet-500" /> نطاق الأبحاث</h2>
                <p className="text-sm leading-relaxed text-muted-foreground">{journal.scope}</p>
              </CardContent>
            </Card>
          )}

          {/* ═══ الفهرسة ═══ */}
          {(indexedIn.length > 0 || journal.apcFee) && (
            <Card className="border-0 shadow-md bg-card/80">
              <CardContent className="p-6 space-y-4">
                {indexedIn.length > 0 && (
                  <div>
                    <h2 className="text-base font-bold mb-3 flex items-center gap-2"><Tag className="h-4 w-4 text-amber-500" /> قواعد الفهرسة</h2>
                    <div className="flex flex-wrap gap-2">
                      {indexedIn.map(idx => <Badge key={idx} variant="secondary" className="text-xs rounded-lg">{idx}</Badge>)}
                    </div>
                  </div>
                )}
                {journal.apcFee && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><DollarSign className="h-3.5 w-3.5" /> رسوم النشر المفتوح (APC)</span>
                    <span className="font-bold text-foreground">{journal.apcFee}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* ═══ سايد بار: معلومات النشر ═══ */}
        <div className="space-y-5">
          <Card className="border-0 shadow-md bg-card/80">
            <CardContent className="p-6 space-y-3.5">
              <h2 className="text-base font-bold flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-500" /> معلومات النشر</h2>
              {meta.map(m => { const Icon = m.icon; return (
                <div key={m.label} className="flex items-center justify-between gap-2 text-xs">
                  <span className="flex items-center gap-2 text-muted-foreground"><Icon className="h-3.5 w-3.5" /> {m.label}</span>
                  <span className="font-semibold truncate">{m.val}</span>
                </div>
              )})}
              {journal.issn && (
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="flex items-center gap-2 text-muted-foreground"><Tag className="h-3.5 w-3.5" /> ISSN</span>
                  <span className="font-semibold font-mono" dir="ltr">{journal.issn}</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-card/80">
            <CardContent className="p-6">
              <h2 className="text-base font-bold mb-4 flex items-center gap-2"><Tag className="h-4 w-4 text-blue-500" /> مجلات أخرى</h2>
              <div className="space-y-2">
                {others.map(j => (
                  <Link key={j.id} href={`/research/journals/${j.id}`} className="block p-3 rounded-xl border hover:shadow-md hover:border-indigo-200 dark:hover:border-indigo-800 transition-all">
                    <p className="text-sm font-medium line-clamp-1">{j.nameAr || j.name}</p>
                    <p className="text-2xs text-muted-foreground mt-0.5">ISSN: {j.issn || '—'}{j.impactFactor ? ` · IF ${j.impactFactor}` : ''}</p>
                  </Link>
                ))}
                {others.length === 0 && <p className="text-xs text-muted-foreground">لا توجد مجلات أخرى بعد.</p>}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}