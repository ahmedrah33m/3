import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'مركز الأبحاث الاقتصادية العراقي | ميدان',
  description: ' أكبر قاعدة بيانات للأبحاث الاقتصادية في العراق. اربط الباحثين بصناع القرار وحول الأبحاث إلى قيمة اقتصادية حقيقية.',
  openGraph: {
    title: 'مركز الأبحاث الاقتصادية العراقي | ميدان',
    description: ' أكبر قاعدة بيانات للأبحاث الاقتصادية في العراق. اربط الباحثين بصناع القرار وحول الأبحاث إلى قيمة اقتصادية حقيقية.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/research`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary_large_image',
    title: 'مركز الأبحاث الاقتصادية العراقي | ميدان',
    description: ' أكبر قاعدة بيانات للأبحاث الاقتصادية في العراق.',
  },
  alternates: {
    canonical: `${SITE_URL}/research`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
