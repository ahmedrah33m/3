import { redirect } from 'next/navigation'

export default function ChatRoomsPage() {
  redirect('/messages?tab=rooms')
}