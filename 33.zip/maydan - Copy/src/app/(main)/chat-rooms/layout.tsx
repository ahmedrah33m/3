import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'غرف المحادثة | ميدان',
  description: 'انضم إلى غرف المحادثة الاقتصادية وتحدث مع خبراء ومهتمين.',
  openGraph: {
    title: 'غرف المحادثة | ميدان',
    description: 'انضم إلى غرف المحادثة الاقتصادية وتحدث مع خبراء ومهتمين.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/chat-rooms`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'غرف المحادثة | ميدان',
    description: 'انضم إلى غرف المحادثة الاقتصادية وتحدث مع خبراء ومهتمين.',
  },
  alternates: {
    canonical: `${SITE_URL}/chat-rooms`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
