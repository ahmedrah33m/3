'use client'

import { MidanCalendar } from '@/components/MidanCalendar'

export default function CalendarPage() {
  return <MidanCalendar />
}
