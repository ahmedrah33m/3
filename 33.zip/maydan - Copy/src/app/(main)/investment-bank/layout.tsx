import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'بنك الفرص الاستثمارية | ميدان',
  description: 'اكتشف فرص الاستثمار في العراق. مشاريع وشراكات استثمارية واعدة.',
  openGraph: {
    title: 'بنك الفرص الاستثمارية | ميدان',
    description: 'اكتشف فرص الاستثمار في العراق. مشاريع وشراكات استثمارية واعدة.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/investment-bank`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'بنك الفرص الاستثمارية | ميدان',
    description: 'اكتشف فرص الاستثمار في العراق. مشاريع وشراكات استثمارية واعدة.',
  },
  alternates: {
    canonical: `${SITE_URL}/investment-bank`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
