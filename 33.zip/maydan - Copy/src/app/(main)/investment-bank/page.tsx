'use client'

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const InvestmentBankView = dynamic(() => import('@/components/InvestmentBankView'), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-8 w-48" />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-48" />
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Skeleton key={i} className="h-64" />
        ))}
      </div>
    </div>
  ),
})

export default function InvestmentBankPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">بنك الفرص الاستثمارية</h1>
        <p className="text-sm text-muted-foreground">استكشف فرص الاستثمار في العراق - تحليل المخاطرة والعائد والجدوى بالذكاء الاصطناعي</p>
      </div>
      <InvestmentBankView {...({} as any)} />
    </div>
  )
}
