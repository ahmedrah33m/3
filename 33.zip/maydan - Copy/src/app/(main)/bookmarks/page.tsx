'use client'

import { useState, useEffect } from 'react'
import { Bookmark, Eye, Heart, Calendar, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { GlassCard } from '@/components/ui/glass-card'
import { GlassAvatar, GlassAvatarImage, GlassAvatarFallback } from '@/components/ui/glass-avatar'
import { buildSrcSet } from '@/lib/image-url'
import { useStore } from '@/lib/store'

const categoryColors: Record<string, string> = {
  ANALYSIS: 'bg-blue-500/15 text-blue-600 border-blue-500/30 dark:text-blue-400',
  REPORT: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30 dark:text-emerald-400',
  STUDY: 'bg-purple-500/15 text-purple-600 border-purple-500/30 dark:text-purple-400',
  OPINION: 'bg-amber-500/15 text-amber-600 border-amber-500/30 dark:text-amber-400',
  NEWS: 'bg-red-500/15 text-red-600 border-red-500/30 dark:text-red-400',
  RESEARCH: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30 dark:text-cyan-400',
}

const categoryLabels: Record<string, string> = {
  ANALYSIS: 'تحليل',
  REPORT: 'تقرير',
  STUDY: 'دراسة',
  OPINION: 'رأي',
  NEWS: 'أخبار',
  RESEARCH: 'بحث',
}

function formatNumber(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`
  return String(n)
}

interface BookmarkItem {
  id: string
  createdAt: string
  article: {
    id: string
    title: string
    summary?: string
    coverImage?: string
    category: string
    viewCount: number
    likeCount: number
    commentCount: number
    createdAt: string
    author?: { id: string; name: string; avatar?: string }
  }
}

export default function BookmarksPage() {
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([])
  const [loading, setLoading] = useState(true)
  const { navigateTo } = useStore()

  const fetchBookmarks = async () => {
    try {
      const res = await fetch('/api/bookmarks')
      const data = await res.json()
      setBookmarks(data.bookmarks || [])
    } catch {}
    setLoading(false)
  }

  useEffect(() => {
    fetchBookmarks()
  }, [])

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('ar-IQ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const handleRemoveBookmark = async (e: React.MouseEvent, articleId: string) => {
    e.stopPropagation()
    try {
      await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleId, type: 'BOOKMARK' }),
      })
      setBookmarks((prev) => prev.filter((b) => b.article.id !== articleId))
    } catch {}
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-2">
        <Bookmark className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">المحفوظات</h1>
          <p className="text-sm text-muted-foreground">المقالات التي حفظتها للقراءة لاحقاً</p>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <GlassCard key={i} variant="default" size="md">
              <div className="animate-pulse space-y-2 p-1">
                <div className="h-4 bg-muted rounded w-2/3" />
                <div className="h-3 bg-muted rounded w-full" />
                <div className="h-3 bg-muted rounded w-1/3" />
              </div>
            </GlassCard>
          ))}
        </div>
      ) : bookmarks.length === 0 ? (
        <GlassCard variant="default" size="lg" className="text-center">
          <div className="py-12">
            <Bookmark className="h-12 w-12 mx-auto mb-3 text-muted-foreground/30" />
            <p className="text-muted-foreground mb-4">لا توجد مقالات محفوظة</p>
            <Button onClick={() => navigateTo('home')} className="gap-1">
              تصفح المقالات
            </Button>
          </div>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {bookmarks.map((bm) => (
            <GlassCard
              key={bm.id}
              variant="default"
              size="md"
              hoverable
              className="cursor-pointer group"
              onClick={() => navigateTo('article', bm.article.id)}
            >
              <div className="flex items-start gap-3">
                {bm.article.coverImage && (
                  <div className="w-20 h-20 rounded-2xl overflow-hidden shrink-0 hidden sm:block bg-muted">
                    <img
                      src={bm.article.coverImage}
                      alt={bm.article.title}
                      srcSet={buildSrcSet(bm.article.coverImage, [48, 96, 192, 384]) || undefined}
                      sizes="80px"
                      decoding="async"
                      loading="lazy"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-2xs font-semibold border ${categoryColors[bm.article.category] || 'bg-primary/10 text-primary border-primary/20'}`}>
                      {categoryLabels[bm.article.category] || bm.article.category}
                    </span>
                    <span className="text-2xs text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(bm.article.createdAt)}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold line-clamp-2 group-hover:text-primary transition-colors mb-1">
                    {bm.article.title}
                  </h3>
                  {bm.article.summary && (
                    <p className="text-xs text-muted-foreground line-clamp-1">{bm.article.summary}</p>
                  )}
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      {bm.article.author && (
                        <div className="flex items-center gap-1.5">
                          <GlassAvatar variant="default" size="xs" className="h-5 w-5">
                            <GlassAvatarImage src={bm.article.author.avatar || undefined} alt={bm.article.author.name} />
                            <GlassAvatarFallback className="text-[8px]">
                              {bm.article.author.name?.charAt(0)}
                            </GlassAvatarFallback>
                          </GlassAvatar>
                          <span>{bm.article.author.name}</span>
                        </div>
                      )}
                      <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" />{formatNumber(bm.article.viewCount)}</span>
                      <span className="flex items-center gap-0.5"><Heart className="h-3 w-3" />{formatNumber(bm.article.likeCount)}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => handleRemoveBookmark(e, bm.article.id)}
                      className="text-destructive hover:text-destructive text-xs h-7 gap-1"
                    >
                      <X className="h-3.5 w-3.5" />
                      إزالة
                    </Button>
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  )
}
