'use client'

import AssessmentCenterView from '@/components/AssessmentCenterView'

export default function QuizzesPage() {
  return <AssessmentCenterView />
}
