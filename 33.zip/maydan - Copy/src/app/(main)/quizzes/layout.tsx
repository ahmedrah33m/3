import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'الاختبارات المعرفية | ميدان',
  description: 'اختبر معرفتك الاقتصادية والمهنية مع اختبارات ميدان التفاعلية.',
  openGraph: {
    title: 'الاختبارات المعرفية | ميدان',
    description: 'اختبر معرفتك الاقتصادية والمهنية مع اختبارات ميدان التفاعلية.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/quizzes`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'الاختبارات المعرفية | ميدان',
    description: 'اختبر معرفتك الاقتصادية والمهنية مع اختبارات ميدان التفاعلية.',
  },
  alternates: {
    canonical: `${SITE_URL}/quizzes`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
