'use client'

import { useParams } from 'next/navigation'
import { QuizPlayer } from '@/components/education/Quizzes'
import { Brain } from 'lucide-react'

export default function QuizDetailPage() {
  const params = useParams()
  const quizId = params.id as string

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
          <Brain className="h-6 w-6 text-purple-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">الاختبار</h1>
          <p className="text-sm text-muted-foreground">أجب عن الأسئلة واختبر معرفتك</p>
        </div>
      </div>

      <QuizPlayer
        quizId={quizId}
        onFinish={() => {
          window.location.href = '/quizzes'
        }}
      />
    </div>
  )
}
