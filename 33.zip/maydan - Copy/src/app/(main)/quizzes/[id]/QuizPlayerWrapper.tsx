'use client'

import { QuizPlayer } from '@/components/education/Quizzes'

export default function QuizPlayerWrapper({ quizId }: { quizId: string }) {
  return (
    <QuizPlayer
      quizId={quizId}
      onFinish={() => {
        window.location.href = '/quizzes'
      }}
    />
  )
}