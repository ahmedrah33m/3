'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  Gift,
  Building2,
  MapPin,
  Clock,
  TrendingUp,
  Eye,
  Check,
  X,
  MessageSquare,
  DollarSign,
  Briefcase,
  PartyPopper,
  Sparkles,
  Trophy,
  CalendarDays,
  Edit3,
  CheckCircle,
  Quote,
  ArrowLeft,
  Send,
  AlertTriangle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  GlassCard,
  GlassCardContent,
  GlassCardHeader,
  GlassCardTitle,
} from '@/components/ui/glass-card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { useToast } from '@/hooks/use-toast'

// ═══════════════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════════════

interface OfferApplication {
  id: string
  jobId: string
  job: {
    id: string
    title: string
    company: string
    location: string | null
    type: string
    salary: string | null
    image: string | null
    startDate?: string | null
    publisher: {
      name: string
      companyLogo: string | null
    } | null
  }
  pipelineStage: string
  matchScore: number
  createdAt: string
  stageChanges: {
    fromStage: string
    toStage: string
    changedAt: string
    note: string | null
  }[]
  companyMessage?: string | null
  offerDetails?: {
    salary?: string
    currency?: string
    type?: string
    location?: string
    startDate?: string
  } | null
}

// ═══════════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════════

const GOLD = '#D4A853'
const GOLD_DARK = '#B8892F'
const GOLD_LIGHT = '#F5E6C8'

const DECLINE_REASONS = [
  { value: 'salary', label: 'الراتب غير مناسب' },
  { value: 'location', label: 'الموقع بعيد' },
  { value: 'better_offer', label: 'لدي عرض أفضل' },
  { value: 'other', label: 'أخرى' },
]

// ═══════════════════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════════════════

function getJobTypeLabel(type: string): string {
  const map: Record<string, string> = {
    FULL_TIME: 'دوام كامل',
    PART_TIME: 'دوام جزئي',
    REMOTE: 'عن بُعد',
    CONTRACT: 'عقد',
    INTERNSHIP: 'تدريب',
    'full-time': 'دوام كامل',
    'part-time': 'دوام جزئي',
    remote: 'عن بُعد',
    contract: 'عقد',
    internship: 'تدريب',
  }
  return map[type] || type
}

function formatDate(dateStr: string): string {
  if (!dateStr) return ''
  return new Date(dateStr).toLocaleDateString('ar-IQ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

function formatDateShort(dateStr: string): string {
  if (!dateStr) return ''
  return new Date(dateStr).toLocaleDateString('ar-IQ', {
    month: 'short',
    day: 'numeric',
  })
}

// ═══════════════════════════════════════════════════════════════════════════════
// Offer Card - Premium Design
// ═══════════════════════════════════════════════════════════════════════════════

function OfferCard({
  offer,
  onAccept,
  onDecline,
  onModify,
  actionLoading,
}: {
  offer: OfferApplication
  onAccept: (offer: OfferApplication) => void
  onDecline: (offer: OfferApplication) => void
  onModify: (offer: OfferApplication) => void
  actionLoading: boolean
}) {
  const router = useRouter()
  const isHired = offer.pipelineStage === 'HIRED'
  const logo = offer.job.publisher?.companyLogo || offer.job.image

  const salary =
    offer.offerDetails?.salary ||
    offer.job.salary ||
    'غير محدد'
  const currency =
    offer.offerDetails?.currency || 'د.ع'
  const workType =
    offer.offerDetails?.type ||
    getJobTypeLabel(offer.job.type)
  const location =
    offer.offerDetails?.location ||
    offer.job.location ||
    'غير محدد'
  const startDate =
    offer.offerDetails?.startDate ||
    offer.job.startDate ||
    offer.createdAt

  return (
    <div
      className={`relative overflow-hidden rounded-2xl ${
        isHired
          ? 'border-2 border-green-300 bg-gradient-to-br from-green-50 via-white to-emerald-50 dark:border-green-800 dark:from-green-950/20 dark:via-gray-900 dark:to-emerald-950/20'
          : ''
      }`}
      style={
        !isHired
          ? {
              background: `linear-gradient(135deg, ${GOLD_LIGHT}22 0%, white 40%, ${GOLD_LIGHT}15 100%)`,
              border: `2px solid ${GOLD}40`,
            }
          : undefined
      }
    >
      {/* Shimmer effect for pending offers */}
      {!isHired && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-2xl">
          <div
            className="absolute -top-1/2 -start-1/2 h-[200%] w-[200%] animate-spin"
            style={{
              animationDuration: '20s',
              background: `conic-gradient(from 0deg, transparent, ${GOLD}08, transparent, ${GOLD}06, transparent)`,
            }}
          />
        </div>
      )}

      {/* Content */}
      <div className="relative p-5 sm:p-6">
        {/* Top Badge */}
        <div className="flex items-center justify-between">
          {isHired ? (
            <div className="flex items-center gap-1.5 rounded-full bg-green-100 px-3 py-1.5 dark:bg-green-900/40">
              <Trophy className="h-3.5 w-3.5 text-green-600" />
              <span className="text-xs font-bold text-green-700 dark:text-green-400">
                تم القبول
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5" style={{ background: `${GOLD}20`, color: GOLD_DARK }}>
              <Sparkles className="h-3.5 w-3.5" />
              <span className="text-xs font-bold">عرض جديد</span>
            </div>
          )}
          {!isHired && (
            <div className="flex items-center gap-1 text-xs text-gray-400">
              <Clock className="h-3 w-3" />
              {formatDate(offer.createdAt)}
            </div>
          )}
        </div>

        {/* Header: Logo + Title + Company */}
        <div className="mt-4 flex items-start gap-4">
          <Avatar
            className="h-14 w-14 shrink-0 rounded-xl border-2"
            style={{ borderColor: isHired ? '#86efac' : `${GOLD}60` }}
          >
            <AvatarImage
              src={logo || undefined}
              alt={offer.job.company}
              className="object-cover"
            />
            <AvatarFallback
              className="rounded-xl text-lg font-bold"
              style={{
                backgroundColor: isHired ? '#dcfce7' : `${GOLD}15`,
                color: isHired ? '#15803d' : GOLD_DARK,
              }}
            >
              {offer.job.company.slice(0, 2)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <Link
              href={`/jobs/${offer.jobId}`}
              className="block text-lg font-extrabold leading-tight line-clamp-2 transition-colors sm:text-xl"
              style={{ color: isHired ? '#15803d' : GOLD_DARK }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.color = isHired ? '#166534' : GOLD)
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.color = isHired ? '#15803d' : GOLD_DARK)
              }
            >
              {offer.job.title}
            </Link>
            <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
              <span className="flex items-center gap-1.5 font-medium">
                <Building2 className="h-4 w-4" />
                {offer.job.company}
              </span>
            </div>
          </div>
        </div>

        {/* Offer Details Grid */}
        <div
          className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4"
        >
          {/* Salary */}
          <div
            className="rounded-xl p-3 backdrop-blur-sm"
            style={{
              background: isHired
                ? 'rgba(220, 252, 231, 0.6)'
                : `${GOLD}0D`,
            }}
          >
            <p className="flex items-center gap-1 text-2xs font-medium text-gray-400 uppercase tracking-wider">
              <DollarSign className="h-3 w-3" />
              الراتب
            </p>
            <p className="mt-1 text-sm font-bold text-gray-900 dark:text-white">
              {salary}
              <span className="ms-0.5 text-xs font-normal text-gray-500">
                {currency}
              </span>
            </p>
          </div>

          {/* Work Type */}
          <div
            className="rounded-xl p-3 backdrop-blur-sm"
            style={{
              background: isHired
                ? 'rgba(220, 252, 231, 0.6)'
                : `${GOLD}0D`,
            }}
          >
            <p className="flex items-center gap-1 text-2xs font-medium text-gray-400 uppercase tracking-wider">
              <Briefcase className="h-3 w-3" />
              نوع العمل
            </p>
            <p className="mt-1 text-sm font-bold text-gray-900 dark:text-white">
              {workType}
            </p>
          </div>

          {/* Location */}
          <div
            className="rounded-xl p-3 backdrop-blur-sm"
            style={{
              background: isHired
                ? 'rgba(220, 252, 231, 0.6)'
                : `${GOLD}0D`,
            }}
          >
            <p className="flex items-center gap-1 text-2xs font-medium text-gray-400 uppercase tracking-wider">
              <MapPin className="h-3 w-3" />
              الموقع
            </p>
            <p className="mt-1 text-sm font-bold text-gray-900 dark:text-white">
              {location}
            </p>
          </div>

          {/* Start Date */}
          <div
            className="rounded-xl p-3 backdrop-blur-sm"
            style={{
              background: isHired
                ? 'rgba(220, 252, 231, 0.6)'
                : `${GOLD}0D`,
            }}
          >
            <p className="flex items-center gap-1 text-2xs font-medium text-gray-400 uppercase tracking-wider">
              <CalendarDays className="h-3 w-3" />
              تاريخ البدء
            </p>
            <p className="mt-1 text-sm font-bold text-gray-900 dark:text-white">
              {formatDateShort(startDate)}
            </p>
          </div>
        </div>

        {/* Match Score - Large and Prominent */}
        {offer.matchScore > 0 && (
          <div className="mt-4 flex items-center gap-3 rounded-xl bg-white/70 p-3 dark:bg-gray-800/50">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl" style={{ backgroundColor: `${GOLD}15` }}>
              <span className="text-lg font-extrabold" style={{ color: GOLD_DARK }}>
                {offer.matchScore}%
              </span>
            </div>
            <div className="flex-1">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                  درجة التطابق
                </span>
                <TrendingUp className="h-4 w-4" style={{ color: GOLD }} />
              </div>
              <Progress
                value={offer.matchScore}
                className="h-2.5"
              />
            </div>
          </div>
        )}

        {/* Company Message Quote Block */}
        {offer.companyMessage && (
          <div
            className="mt-4 rounded-xl border p-4"
            style={{
              borderColor: isHired ? '#86efac' : `${GOLD}30`,
              backgroundColor: isHired
                ? 'rgba(220, 252, 231, 0.4)'
                : `${GOLD}08`,
            }}
          >
            <div className="flex items-start gap-2">
              <Quote
                className="mt-0.5 h-5 w-5 shrink-0"
                style={{ color: GOLD }}
              />
              <div>
                <p className="mb-1 text-xs font-semibold" style={{ color: GOLD_DARK }}>
                  رسالة من الشركة
                </p>
                <p className="text-sm leading-relaxed text-gray-700 dark:text-gray-300">
                  {offer.companyMessage}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons (only for pending offers) */}
        {!isHired && (
          <>
            <Separator className="my-4" />
            <div className="flex flex-wrap gap-2">
              {/* Accept - Green Filled */}
              <Button
                size="lg"
                onClick={() => onAccept(offer)}
                disabled={actionLoading}
                className="flex-1 rounded-xl bg-green-600 px-5 text-white shadow-lg shadow-green-200 transition-all hover:bg-green-700 hover:shadow-xl hover:shadow-green-300 dark:shadow-green-900/30 sm:flex-initial"
              >
                <CheckCircle className="ms-1.5 h-5 w-5" />
                قبول العرض
              </Button>

              {/* Request Modification - Outline */}
              <Button
                variant="outline"
                size="lg"
                onClick={() => onModify(offer)}
                disabled={actionLoading}
                className="flex-1 rounded-xl border-gray-200 px-5 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800 sm:flex-initial"
              >
                <MessageSquare className="ms-1.5 h-5 w-5" />
                طلب تعديل
              </Button>

              {/* Decline - Red Outline */}
              <Button
                variant="outline"
                size="lg"
                onClick={() => onDecline(offer)}
                disabled={actionLoading}
                className="flex-1 rounded-xl border-red-200 px-5 text-red-600 hover:bg-red-50 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-950/30 sm:flex-initial"
              >
                <X className="ms-1.5 h-5 w-5" />
                رفض العرض
              </Button>
            </div>
          </>
        )}

        {/* Accepted: View Profile CTA */}
        {isHired && (
          <>
            <Separator className="my-4" />
            <Button
              asChild
              className="w-full rounded-xl bg-green-600 text-white hover:bg-green-700"
            >
              <Link href="/jobs/candidate/profile">
                <ArrowLeft className="ms-1.5 h-4 w-4" />
                الانتقال إلى الملف الشخصي
              </Link>
            </Button>
          </>
        )}
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Loading Skeleton
// ═══════════════════════════════════════════════════════════════════════════════

function OfferSkeleton() {
  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-5 sm:p-6 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-center justify-between">
        <Skeleton className="h-6 w-20 rounded-full" />
        <Skeleton className="h-4 w-24" />
      </div>
      <div className="mt-4 flex items-start gap-4">
        <Skeleton className="h-14 w-14 rounded-xl" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-7 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      </div>
      <div className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-16 rounded-xl" />
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        <Skeleton className="h-11 w-32 rounded-xl" />
        <Skeleton className="h-11 w-28 rounded-xl" />
        <Skeleton className="h-11 w-24 rounded-xl" />
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main Page
// ═══════════════════════════════════════════════════════════════════════════════

export default function OffersPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [offers, setOffers] = useState<OfferApplication[]>([])
  const [loading, setLoading] = useState(true)

  // Dialog states
  const [acceptDialog, setAcceptDialog] = useState<{
    open: boolean
    offer: OfferApplication | null
    confirmed: boolean
  }>({ open: false, offer: null, confirmed: false })

  const [declineDialog, setDeclineDialog] = useState<{
    open: boolean
    offer: OfferApplication | null
  }>({ open: false, offer: null })

  const [modifyDialog, setModifyDialog] = useState<{
    open: boolean
    offer: OfferApplication | null
  }>({ open: false, offer: null })

  const [declineReason, setDeclineReason] = useState('')
  const [declineOtherText, setDeclineOtherText] = useState('')
  const [modifyText, setModifyText] = useState('')
  const [actionLoading, setActionLoading] = useState(false)

  // ── Fetch ─────────────────────────────────────────────────────────────────
  const fetchOffers = useCallback(async () => {
    try {
      setLoading(true)
      let jobs: unknown[] = []

      try {
        const res = await fetch('/api/jobs/candidate/applications')
        if (res.ok) {
          const json = await res.json()
          jobs = Array.isArray(json.applications)
            ? json.applications
            : Array.isArray(json.jobs)
              ? json.jobs
              : []
        } else {
          throw new Error('fallback')
        }
      } catch {
        const res = await fetch('/api/jobs?applied=true&limit=200')
        if (!res.ok) throw new Error('fetch failed')
        const data = await res.json()
        jobs = Array.isArray(data.jobs) ? data.jobs : []
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const offerJobs: OfferApplication[] = (jobs as any[])
        .filter((j: any) => {
          const stage = j.pipelineStage as string | undefined
          return stage === 'OFFERED' || stage === 'HIRED'
        })
        .map((j: any) => ({
          id: String(j.id || ''),
          jobId: String(j.id || ''),
          job: {
            id: String(j.id || ''),
            title: String(j.title || ''),
            company: String(j.company || ''),
            location: j.location || null,
            type: String(j.type || ''),
            salary: j.salary || null,
            image: j.image || null,
            startDate: j.startDate || null,
            publisher: j.publisher || null,
          },
          pipelineStage: (j.pipelineStage as string) || 'OFFERED',
          matchScore: (j.matchScore as number) || 0,
          createdAt: String(j.createdAt || ''),
          stageChanges: (j.stageChanges as OfferApplication['stageChanges']) || [],
          companyMessage: j.companyMessage || null,
          offerDetails: j.offerDetails || null,
        }))
      setOffers(offerJobs)
    } catch {
      // Handle gracefully with empty state
      setOffers([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchOffers()
  }, [fetchOffers])

  // ── Stats ─────────────────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const available = offers.filter(
      (o) => o.pipelineStage === 'OFFERED'
    ).length
    const accepted = offers.filter((o) => o.pipelineStage === 'HIRED').length
    const declined = 0 // Client-side tracking if needed
    return { available, accepted, declined }
  }, [offers])

  // ── Actions ───────────────────────────────────────────────────────────────
  const handleAccept = async () => {
    if (!acceptDialog.offer) return
    setActionLoading(true)
    try {
      const res = await fetch(
        `/api/jobs/${acceptDialog.offer.jobId}/pipeline`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'accept_offer' }),
        }
      )
      if (res.ok) {
        setOffers((prev) =>
          prev.map((o) =>
            o.jobId === acceptDialog.offer!.jobId
              ? { ...o, pipelineStage: 'HIRED' }
              : o
          )
        )
        setAcceptDialog({ open: true, offer: acceptDialog.offer, confirmed: true })
        toast({
          title: 'تهانينا!',
          description: 'تم قبول العرض الوظيفي بنجاح. نتمنى لك التوفيق!',
        })
      } else {
        toast({
          title: 'خطأ',
          description: 'حدث خطأ أثناء قبول العرض',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء قبول العرض',
        variant: 'destructive',
      })
    } finally {
      setActionLoading(false)
    }
  }

  const handleDecline = async () => {
    if (!declineDialog.offer) return
    setActionLoading(true)
    try {
      const reason =
        declineReason === 'other'
          ? declineOtherText.trim() || declineReason
          : declineReason
      const res = await fetch(
        `/api/jobs/${declineDialog.offer.jobId}/pipeline`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'decline_offer', reason }),
        }
      )
      if (res.ok) {
        setOffers((prev) =>
          prev.filter((o) => o.jobId !== declineDialog.offer!.jobId)
        )
        toast({ title: 'تم الرفض', description: 'تم رفض العرض الوظيفي' })
      } else {
        toast({
          title: 'خطأ',
          description: 'حدث خطأ أثناء رفض العرض',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء رفض العرض',
        variant: 'destructive',
      })
    } finally {
      setActionLoading(false)
      setDeclineDialog({ open: false, offer: null })
      setDeclineReason('')
      setDeclineOtherText('')
    }
  }

  const handleModify = async () => {
    if (!modifyDialog.offer || !modifyText.trim()) return
    setActionLoading(true)
    try {
      const res = await fetch(
        `/api/jobs/${modifyDialog.offer.jobId}/pipeline`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'request_modification',
            message: modifyText.trim(),
          }),
        }
      )
      if (res.ok) {
        toast({
          title: 'تم الإرسال',
          description: 'تم إرسال طلب التعديل إلى الشركة بنجاح',
        })
      } else {
        toast({
          title: 'خطأ',
          description: 'حدث خطأ أثناء إرسال طلب التعديل',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء إرسال طلب التعديل',
        variant: 'destructive',
      })
    } finally {
      setActionLoading(false)
      setModifyDialog({ open: false, offer: null })
      setModifyText('')
    }
  }

  const openAcceptDialog = (offer: OfferApplication) => {
    setAcceptDialog({ open: true, offer, confirmed: false })
  }

  const closeAcceptDialog = () => {
    setAcceptDialog({ open: false, offer: null, confirmed: false })
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════════════════════

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          عروضي الوظيفية
        </h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          راجع العروض الوظيفية واتخذ قرارك
        </p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-3">
        <GlassCard variant="flat" size="sm" className="text-center">
          <div className="flex items-center justify-center gap-1.5">
            <Gift className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            <span className="text-[11px] text-gray-500 dark:text-gray-400">
              عروض متاحة
            </span>
          </div>
          <p className="mt-1 text-2xl font-bold text-amber-600 dark:text-amber-400">
            {stats.available}
          </p>
        </GlassCard>
        <GlassCard variant="flat" size="sm" className="text-center">
          <div className="flex items-center justify-center gap-1.5">
            <Trophy className="h-4 w-4 text-green-600 dark:text-green-400" />
            <span className="text-[11px] text-gray-500 dark:text-gray-400">
              مقبولة
            </span>
          </div>
          <p className="mt-1 text-2xl font-bold text-green-600 dark:text-green-400">
            {stats.accepted}
          </p>
        </GlassCard>
        <GlassCard variant="flat" size="sm" className="text-center">
          <div className="flex items-center justify-center gap-1.5">
            <X className="h-4 w-4 text-red-600 dark:text-red-400" />
            <span className="text-[11px] text-gray-500 dark:text-gray-400">
              مرفوضة
            </span>
          </div>
          <p className="mt-1 text-2xl font-bold text-red-600 dark:text-red-400">
            {stats.declined}
          </p>
        </GlassCard>
      </div>

      {/* Loading */}
      {loading && (
        <div className="space-y-5">
          {Array.from({ length: 2 }).map((_, i) => (
            <OfferSkeleton key={i} />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && offers.length === 0 && (
        <GlassCard
          variant="flat"
          size="lg"
          className="flex flex-col items-center justify-center py-16 text-center"
        >
          <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full" style={{ backgroundColor: `${GOLD}15` }}>
            <Gift className="h-10 w-10" style={{ color: GOLD }} />
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-700 dark:text-gray-300">
            لم تتلقَ أي عروض وظيفية بعد
          </h3>
          <p className="max-w-sm text-sm text-gray-400">
            استمر في التقديم على الوظائف. العروض تصل عندما يتطابق ملفك مع
            متطلبات الوظيفة
          </p>
        </GlassCard>
      )}

      {/* Offer Cards */}
      {!loading && offers.length > 0 && (
        <div className="space-y-5">
          {offers.map((offer) => (
            <OfferCard
              key={offer.id}
              offer={offer}
              onAccept={openAcceptDialog}
              onDecline={(o) => setDeclineDialog({ open: true, offer: o })}
              onModify={(o) => setModifyDialog({ open: true, offer: o })}
              actionLoading={actionLoading}
            />
          ))}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          ACCEPT CONFIRMATION DIALOG
          ═══════════════════════════════════════════════════════════════════ */}
      <Dialog open={acceptDialog.open} onOpenChange={closeAcceptDialog}>
        <DialogContent className="max-w-md text-center">
          {acceptDialog.confirmed ? (
            /* ── Success State ── */
            <>
              <DialogHeader className="items-center">
                <div
                  className="mb-3 flex h-16 w-16 items-center justify-center rounded-full"
                  style={{ backgroundColor: `${GOLD}20` }}
                >
                  <PartyPopper className="h-8 w-8 text-green-600" />
                </div>
                <DialogTitle className="text-xl">
                  تهانينا! لقد قبلت عرض الوظيفة
                </DialogTitle>
                <DialogDescription className="text-base text-gray-500">
                  نتمنى لك التوفيق في مسيرتك المهنية الجديدة
                </DialogDescription>
              </DialogHeader>

              {acceptDialog.offer && (
                <div
                  className="rounded-xl p-4 text-start"
                  style={{
                    background: `linear-gradient(135deg, ${GOLD}0D, white)`,
                    border: `1px solid ${GOLD}30`,
                  }}
                >
                  <p className="font-bold text-gray-900 dark:text-white">
                    {acceptDialog.offer.job.title}
                  </p>
                  <p className="mt-0.5 text-sm text-gray-500">
                    {acceptDialog.offer.job.company}
                  </p>
                  {acceptDialog.offer.job.salary && (
                    <p className="mt-1.5 text-sm font-semibold text-green-600">
                      {acceptDialog.offer.job.salary}
                    </p>
                  )}
                </div>
              )}

              <DialogFooter className="sm:justify-center">
                <Button
                  asChild
                  onClick={closeAcceptDialog}
                  className="rounded-xl bg-green-600 px-6 text-white hover:bg-green-700"
                >
                  <Link href="/jobs/candidate/profile">
                    <ArrowLeft className="ms-1.5 h-4 w-4" />
                    الانتقال إلى الملف الشخصي
                  </Link>
                </Button>
              </DialogFooter>
            </>
          ) : (
            /* ── Confirmation State ── */
            <>
              <DialogHeader className="items-center">
                <div
                  className="mb-3 flex h-16 w-16 items-center justify-center rounded-full"
                  style={{ backgroundColor: `${GOLD}20` }}
                >
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <DialogTitle className="text-xl">
                  هل تريد قبول هذا العرض؟
                </DialogTitle>
                <DialogDescription className="text-base">
                  تأكد من مراجعة تفاصيل العرض قبل القبول
                </DialogDescription>
              </DialogHeader>

              {acceptDialog.offer && (
                <div className="rounded-xl bg-gray-50 p-4 text-start dark:bg-gray-800">
                  <p className="font-bold text-gray-900 dark:text-white">
                    {acceptDialog.offer.job.title}
                  </p>
                  <p className="text-sm text-gray-500">
                    {acceptDialog.offer.job.company}
                  </p>
                </div>
              )}

              <DialogFooter className="gap-2 sm:gap-0 sm:justify-center">
                <Button
                  variant="outline"
                  onClick={closeAcceptDialog}
                  className="rounded-xl"
                >
                  مراجعة لاحقاً
                </Button>
                <Button
                  onClick={handleAccept}
                  disabled={actionLoading}
                  className="rounded-xl bg-green-600 px-6 text-white hover:bg-green-700"
                >
                  {actionLoading
                    ? 'جارٍ القبول...'
                    : 'نعم، أقبل العرض!'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════════════
          DECLINE DIALOG
          ═══════════════════════════════════════════════════════════════════ */}
      <Dialog
        open={declineDialog.open}
        onOpenChange={(open) =>
          setDeclineDialog({ open, offer: null })
        }
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              هل أنت متأكد من رفض هذا العرض؟
            </DialogTitle>
            <DialogDescription>
              يرجى اختيار سبب الرفض لمساعدتنا في تحسين تجربتك
            </DialogDescription>
          </DialogHeader>

          {declineDialog.offer && (
            <div className="rounded-xl bg-gray-50 p-3 text-sm dark:bg-gray-800">
              <p className="font-bold text-gray-900 dark:text-white">
                {declineDialog.offer.job.title}
              </p>
              <p className="text-gray-500">
                {declineDialog.offer.job.company}
              </p>
            </div>
          )}

          {/* Radio Reasons */}
          <RadioGroup
            value={declineReason}
            onValueChange={setDeclineReason}
            className="space-y-2"
          >
            {DECLINE_REASONS.map((reason) => (
              <label
                key={reason.value}
                className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition-colors ${
                  declineReason === reason.value
                    ? 'border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950/20'
                    : 'border-gray-100 hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50'
                }`}
              >
                <RadioGroupItem value={reason.value} />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {reason.label}
                </span>
              </label>
            ))}
          </RadioGroup>

          {/* Additional reason textarea */}
          <div className="space-y-2">
            <Label htmlFor="decline-additional" className="text-xs text-gray-500">
              سبب إضافي (اختياري)
            </Label>
            <Textarea
              id="decline-additional"
              value={declineOtherText}
              onChange={(e) => setDeclineOtherText(e.target.value)}
              placeholder="اذكر التفاصيل الإضافية..."
              rows={2}
              className="resize-none"
            />
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() =>
                setDeclineDialog({ open: false, offer: null })
              }
              className="rounded-xl"
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDecline}
              disabled={actionLoading || !declineReason}
              className="rounded-xl bg-red-600 hover:bg-red-700"
            >
              {actionLoading ? 'جارٍ الإرسال...' : 'تأكيد الرفض'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════════════
          REQUEST MODIFICATION DIALOG
          ═══════════════════════════════════════════════════════════════════ */}
      <Dialog
        open={modifyDialog.open}
        onOpenChange={(open) =>
          setModifyDialog({ open, offer: null })
        }
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit3 className="h-5 w-5" style={{ color: GOLD }} />
              طلب تعديل العرض
            </DialogTitle>
            <DialogDescription>
              اذكر التعديلات التي ترغب فيها لمراجعتها من قبل الشركة
            </DialogDescription>
          </DialogHeader>

          {modifyDialog.offer && (
            <div className="rounded-xl bg-gray-50 p-3 text-sm dark:bg-gray-800">
              <p className="font-bold text-gray-900 dark:text-white">
                {modifyDialog.offer.job.title}
              </p>
              <p className="text-gray-500">
                {modifyDialog.offer.job.company}
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="modify-message">التعديلات المطلوبة</Label>
            <Textarea
              id="modify-message"
              value={modifyText}
              onChange={(e) => setModifyText(e.target.value)}
              placeholder="اذكر التعديلات المطلوبة... مثال: أرغب في مراجعة الراتب أو ساعات العمل"
              rows={4}
              className="resize-none"
            />
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() =>
                setModifyDialog({ open: false, offer: null })
              }
              className="rounded-xl"
            >
              إلغاء
            </Button>
            <Button
              onClick={handleModify}
              disabled={actionLoading || !modifyText.trim()}
              className="rounded-xl px-5"
              style={{
                backgroundColor: GOLD,
                color: '#fff',
              }}
            >
              <Send className="ms-1.5 h-4 w-4" />
              {actionLoading ? 'جارٍ الإرسال...' : 'إرسال الطلب'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}