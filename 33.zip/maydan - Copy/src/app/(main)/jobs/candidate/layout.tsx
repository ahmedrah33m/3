'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { GraduationCap, Briefcase, FileText, CalendarCheck, Gift, UserCircle, FileStack } from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  GlassCard,
  GlassCardContent,
} from '@/components/ui/glass-card'

// ═══════════════════════════════════════════════════════════════════════════════
// Navigation Configuration
// ═══════════════════════════════════════════════════════════════════════════════

const NAV_ITEMS = [
  { label: 'المحفوظة', href: '/jobs/candidate/saved', icon: Briefcase },
  { label: 'طلباتي', href: '/jobs?tab=applications', icon: FileText },
  { label: 'المقابلات', href: '/jobs?tab=interviews', icon: CalendarCheck },
  { label: 'العروض', href: '/jobs/candidate/offers', icon: Gift },
  { label: 'ملفي المهني', href: '/jobs/candidate/profile', icon: UserCircle },
  { label: 'السيرة الذاتية', href: '/jobs/candidate/resume', icon: FileStack },
]

function isActiveTab(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(href + '/')
}

// ═══════════════════════════════════════════════════════════════════════════════
// Layout Component
// ═══════════════════════════════════════════════════════════════════════════════

export default function CandidatePortalLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()

  return (
    <div className="flex flex-col gap-5">
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-3">
        <div className="flex size-11 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-crimson shadow-lg shadow-red-500/20">
          <GraduationCap className="size-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight text-foreground md:text-xl">
            بوابة الباحث عن عمل
          </h1>
          <p className="text-xs text-muted-foreground">
            تتبع طلباتك، مقابلاتك، وعروضك الوظيفية
          </p>
        </div>
      </div>

      {/* ── Desktop Navigation (GlassCard pill bar) ─────────────────────── */}
      <div className="hidden md:block">
        <GlassCard variant="strong" size="sm" className="p-1.5">
          <nav className="flex items-center gap-1 overflow-x-auto scrollbar-none" role="navigation" aria-label="بوابة الباحث عن عمل">
            {NAV_ITEMS.map((item) => {
              const active = isActiveTab(pathname, item.href)
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-all duration-200',
                    active
                      ? 'bg-gradient-to-l from-red-500/15 to-red-500/5 text-red-600 shadow-sm dark:from-red-500/25 dark:to-red-500/10 dark:text-red-400'
                      : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                  )}
                >
                  <Icon className={cn('size-4 shrink-0', active && 'text-red-500 dark:text-red-400')} />
                  <span>{item.label}</span>
                  {active && (
                    <span className="ms-auto size-1.5 rounded-full bg-red-500" />
                  )}
                </Link>
              )
            })}
          </nav>
        </GlassCard>
      </div>

      {/* ── Mobile Navigation (horizontal scrollable pills) ─────────────── */}
      <div className="md:hidden">
        <nav className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none" role="navigation" aria-label="بوابة الباحث عن عمل">
          {NAV_ITEMS.map((item) => {
            const active = isActiveTab(pathname, item.href)
            const Icon = item.icon
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-medium whitespace-nowrap shrink-0 transition-all duration-200',
                  active
                    ? 'bg-red-500 text-white shadow-md shadow-red-500/25'
                    : 'bg-accent/40 text-muted-foreground hover:bg-accent/60'
                )}
              >
                <Icon className="size-3.5" />
                <span>{item.label}</span>
              </Link>
            )
          })}
        </nav>
      </div>

      {/* ── Page Content ─────────────────────────────────────────────────── */}
      <div className="min-h-0 flex-1">
        {children}
      </div>
    </div>
  )
}