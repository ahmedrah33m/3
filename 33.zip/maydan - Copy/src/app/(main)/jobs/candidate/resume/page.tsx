'use client'

import { useState, useEffect, useCallback, useMemo, useRef } from 'react'
import Link from 'next/link'
import {
  FileUp,
  FileText,
  Download,
  Trash2,
  RefreshCw,
  Eye,
  ExternalLink,
  Check,
  AlertTriangle,
  File,
  LayoutTemplate,
  Sparkles,
  Target,
  User,
  Briefcase,
  GraduationCap,
  Globe,
  Star,
  Languages,
  Lightbulb,
  Upload,
  X,
  Loader2,
  ChevronDown,
  ChevronUp,
  ArrowLeft,
  PenLine,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Progress } from '@/components/ui/progress'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import {
  GlassCard,
  GlassCardContent,
  GlassCardHeader,
  GlassCardTitle,
  GlassCardDescription,
} from '@/components/ui/glass-card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'

// ═══════════════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════════════

interface UserProfile {
  id: string
  name: string | null
  email: string
  phone: string | null
  avatar: string | null
  jobTitle: string | null
  bio: string | null
  sector: string | null
  experience: number | null
  educationLevel: string | null
  university: string | null
  gpa: string | null
  skills: string[]
  languages: { language: string; proficiency: string }[]
  openToWork: boolean
  cvVisibleInBank: boolean
  salaryMin: number | null
  salaryMax: number | null
  salaryCurrency: string
  resumeFile: string | null
  resumeFileSize: number | null
  resumeUploadDate: string | null
  resumeData: unknown
  location: string | null
  gender: string | null
  dateOfBirth: string | null
  nationality: string | null
  militaryStatus: string | null
  jobTypes: string[]
}

// ═══════════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════════

const TEMPLATES = [
  {
    id: 'classic',
    name: 'كلاسيكي',
    description: 'بسيط وأنيق',
    color: 'from-blue-500 to-blue-700',
    borderHover: 'hover:border-blue-400',
    icon: FileText,
  },
  {
    id: 'modern',
    name: 'عصري',
    description: 'عصري ومرتب',
    color: 'from-emerald-500 to-green-600',
    borderHover: 'hover:border-emerald-400',
    icon: Sparkles,
  },
  {
    id: 'elegant',
    name: 'أنيق',
    description: 'فاخر ومميز',
    color: 'from-purple-500 to-violet-600',
    borderHover: 'hover:border-purple-400',
    icon: LayoutTemplate,
  },
]

const CV_WRITING_TIPS = [
  'استخدم كلمات مفتاحية من إعلان الوظيفة',
  'ابدأ بملخص مهني قوي',
  'ركّز على الإنجازات وليس المسؤوليات',
  'استخدم أرقام وإحصائيات',
  'حافظ على السيرة في صفحة واحدة أو اثنتين',
  'تأكد من خلوها من الأخطاء الإملائية',
]

const SCORE_ITEMS = [
  { key: 'avatar', label: 'الصورة الشخصية', max: 10 },
  { key: 'bio', label: 'النبذة المهنية', max: 10 },
  { key: 'jobTitle', label: 'المسمى الوظيفي', max: 10 },
  { key: 'skills', label: 'المهارات', max: 15 },
  { key: 'educationLevel', label: 'التعليم', max: 15 },
  { key: 'university', label: 'الجامعة', max: 10 },
  { key: 'experience', label: 'الخبرة', max: 10 },
  { key: 'resumeFile', label: 'السيرة الذاتية', max: 10 },
  { key: 'languages', label: 'اللغات', max: 10 },
]

const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB
const ALLOWED_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]

function defaultProfile(): UserProfile {
  return {
    id: '',
    name: '',
    email: '',
    phone: null,
    avatar: null,
    jobTitle: null,
    bio: null,
    sector: null,
    experience: null,
    educationLevel: null,
    university: null,
    gpa: null,
    skills: [],
    languages: [],
    openToWork: true,
    cvVisibleInBank: true,
    salaryMin: null,
    salaryMax: null,
    salaryCurrency: 'IQD',
    resumeFile: null,
    resumeFileSize: null,
    resumeUploadDate: null,
    resumeData: null,
    location: null,
    gender: null,
    dateOfBirth: null,
    nationality: null,
    militaryStatus: null,
    jobTypes: [],
  }
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1048576).toFixed(1)} MB`
}

function getFileExtensionColor(name: string) {
  const ext = name.split('.').pop()?.toLowerCase()
  switch (ext) {
    case 'pdf':
      return { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-600 dark:text-red-400', label: 'PDF' }
    case 'doc':
    case 'docx':
      return { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400', label: 'DOC' }
    default:
      return { bg: 'bg-gray-100 dark:bg-gray-800', text: 'text-gray-600 dark:text-gray-400', label: 'FILE' }
  }
}

function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr)
    return date.toLocaleDateString('ar-IQ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  } catch {
    return dateStr
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Circular Score Component (simplified for sidebar)
// ═══════════════════════════════════════════════════════════════════════════════

function ScoreDisplay({ profile }: { profile: UserProfile }) {
  const score = useMemo(() => {
    let s = 0
    if (profile.avatar) s += 10
    if (profile.bio && profile.bio.trim().length > 20) s += 10
    if (profile.jobTitle) s += 10
    if (profile.skills.length > 0) s += 15
    if (profile.educationLevel) s += 15
    if (profile.university) s += 10
    if (profile.experience !== null && profile.experience > 0) s += 10
    if (profile.resumeFile || profile.resumeData) s += 10
    if (profile.languages.length > 0) s += 10
    return s
  }, [profile])

  const color = score >= 70 ? '#10B981' : score >= 40 ? '#F59E0B' : '#EF4444'
  const radius = 36
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference

  // Top 3 missing items
  const missingItems = useMemo(() => {
    return SCORE_ITEMS.filter(item => {
      switch (item.key) {
        case 'avatar': return !profile.avatar
        case 'bio': return !(profile.bio && profile.bio.trim().length > 20)
        case 'jobTitle': return !profile.jobTitle
        case 'skills': return profile.skills.length === 0
        case 'educationLevel': return !profile.educationLevel
        case 'university': return !profile.university
        case 'experience': return profile.experience === null || profile.experience <= 0
        case 'resumeFile': return !profile.resumeFile && !profile.resumeData
        case 'languages': return profile.languages.length === 0
        default: return true
      }
    }).slice(0, 3)
  }, [profile])

  return (
    <div className="text-center">
      {/* Circular Score */}
      <div className="relative mx-auto mb-3 flex items-center justify-center">
        <svg width="88" height="88" className="-rotate-90">
          <circle
            cx="44"
            cy="44"
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth="5"
            className="text-gray-200 dark:text-gray-700"
          />
          <circle
            cx="44"
            cy="44"
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-700 ease-out"
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className="text-xl font-bold text-gray-900 dark:text-white">
            {score}
          </span>
          <span className="text-[9px] text-gray-500">من 100</span>
        </div>
      </div>

      <p className="mb-1 text-xs font-medium text-gray-600 dark:text-gray-400">
        {score >= 70
          ? 'ملف ممتاز! 🔥'
          : score >= 40
            ? 'ملف جيد'
            : 'يحتاج تحسين'}
      </p>

      {/* Top Missing Items */}
      {missingItems.length > 0 && (
        <div className="mt-3 space-y-1.5 text-start">
          <p className="text-2xs font-medium text-gray-500 dark:text-gray-500">
            أنجز التالي لتحسين درجتك:
          </p>
          {missingItems.map(item => (
            <div
              key={item.key}
              className="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400"
            >
              <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400" />
              {item.label}
              <span className="text-2xs text-gray-400">(+{item.max})</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main Page
// ═══════════════════════════════════════════════════════════════════════════════

export default function ResumePage() {
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [profile, setProfile] = useState<UserProfile>(defaultProfile())
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [dragOver, setDragOver] = useState(false)
  const [deleteDialog, setDeleteDialog] = useState(false)
  const [tipsExpanded, setTipsExpanded] = useState(false)

  // ── Fetch Profile ─────────────────────────────────────────────────────────
  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/auth/me')
      if (!res.ok) throw new Error()
      const data = await res.json()
      const u = data.user || data
      setProfile({
        id: u.id || '',
        name: u.name || '',
        email: u.email || '',
        phone: u.phone || null,
        avatar: u.avatar || null,
        jobTitle: u.jobTitle || null,
        bio: u.bio || null,
        sector: u.sector || null,
        experience: u.experience ?? null,
        educationLevel: u.educationLevel || null,
        university: u.university || null,
        gpa: u.gpa || null,
        skills: Array.isArray(u.skills) ? u.skills : [],
        languages: Array.isArray(u.languages) ? u.languages : [],
        openToWork: u.openToWork ?? true,
        cvVisibleInBank: u.cvVisibleInBank ?? true,
        salaryMin: u.salaryMin ?? null,
        salaryMax: u.salaryMax ?? null,
        salaryCurrency: u.salaryCurrency || 'IQD',
        resumeFile: u.resumeFile || null,
        resumeFileSize: u.resumeFileSize ?? null,
        resumeUploadDate: u.resumeUploadDate || null,
        resumeData: u.resumeData || null,
        location: u.location || null,
        gender: u.gender || null,
        dateOfBirth: u.dateOfBirth || null,
        nationality: u.nationality || null,
        militaryStatus: u.militaryStatus || null,
        jobTypes: Array.isArray(u.jobTypes) ? u.jobTypes : [],
      })
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء تحميل البيانات',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    fetchProfile()
  }, [fetchProfile])

  // ── Upload ────────────────────────────────────────────────────────────────
  const handleUpload = async (file: File) => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      toast({
        title: 'نوع ملف غير مدعوم',
        description: 'يرجى رفع ملف PDF أو DOC أو DOCX',
        variant: 'destructive',
      })
      return
    }
    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: 'حجم الملف كبير جداً',
        description: 'الحد الأقصى 5 ميجابايت',
        variant: 'destructive',
      })
      return
    }

    setUploading(true)
    setUploadProgress(0)

    // Simulate progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + Math.random() * 15
      })
    }, 200)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const res = await fetch('/api/profile/resume', {
        method: 'POST',
        body: formData,
      })

      clearInterval(progressInterval)
      setUploadProgress(100)

      if (res.ok) {
        setProfile(prev => ({
          ...prev,
          resumeFile: file.name,
          resumeFileSize: file.size,
          resumeUploadDate: new Date().toISOString(),
        }))
        toast({ title: 'تم الرفع', description: 'تم رفع السيرة الذاتية بنجاح' })
      } else {
        const data = await res.json()
        toast({
          title: 'خطأ',
          description: data.error || 'حدث خطأ أثناء رفع الملف',
          variant: 'destructive',
        })
      }
    } catch {
      clearInterval(progressInterval)
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء رفع الملف',
        variant: 'destructive',
      })
    } finally {
      setTimeout(() => {
        setUploading(false)
        setUploadProgress(0)
      }, 600)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleUpload(file)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files?.[0]
    if (file) handleUpload(file)
  }

  // ── Delete ────────────────────────────────────────────────────────────────
  const handleDelete = async () => {
    setUploading(true)
    try {
      const res = await fetch('/api/profile/resume', { method: 'DELETE' })
      if (res.ok) {
        setProfile(prev => ({
          ...prev,
          resumeFile: null,
          resumeFileSize: null,
          resumeUploadDate: null,
        }))
        toast({ title: 'تم الحذف', description: 'تم حذف السيرة الذاتية' })
      } else {
        toast({
          title: 'خطأ',
          description: 'حدث خطأ أثناء الحذف',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ',
        variant: 'destructive',
      })
    } finally {
      setUploading(false)
      setDeleteDialog(false)
    }
  }

  // ── CV Bank Toggle ────────────────────────────────────────────────────────
  const handleCvBankToggle = async (checked: boolean) => {
    setProfile(prev => ({ ...prev, cvVisibleInBank: checked }))
    try {
      await fetch('/api/auth/me', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cvVisibleInBank: checked }),
      })
      toast({
        title: 'تم التحديث',
        description: checked
          ? 'تم تفعيل الظهور في بنك السير'
          : 'تم إخفاء سيرتك من بنك السير',
      })
    } catch {
      setProfile(prev => ({ ...prev, cvVisibleInBank: !checked }))
      toast({ title: 'خطأ', description: 'حدث خطأ', variant: 'destructive' })
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Render — Loading
  // ═══════════════════════════════════════════════════════════════════════════

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-72" />
        </div>
        <Skeleton className="h-72 w-full rounded-xl" />
        <Skeleton className="h-56 w-full rounded-xl" />
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
    )
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════════════════════

  const fileColorInfo = profile.resumeFile
    ? getFileExtensionColor(profile.resumeFile)
    : null

  return (
    <div className="space-y-6">
      {/* ─── Title ─── */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          السيرة الذاتية
        </h2>
        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
          ارفع سيرتك الذاتية أو استخدم البنّاء لإنشاء واحدة
        </p>
      </div>

      {/* ═══ Section 1: Uploaded Resume ═══ */}
      <GlassCard variant="flat" size="md">
        <GlassCardHeader>
          <GlassCardTitle className="flex items-center gap-2 text-base">
            <FileUp className="h-5 w-5 text-red-500" />
            السيرة الذاتية المرفوعة
          </GlassCardTitle>
          <GlassCardDescription>
            {profile.resumeFile
              ? 'ملفك الحالي مرفوع وجاهز للاستخدام'
              : 'ارفع ملف السيرة الذاتية الخاص بك'}
          </GlassCardDescription>
        </GlassCardHeader>
        <GlassCardContent>
          {profile.resumeFile ? (
            /* ─── File Card ─── */
            <div className="rounded-xl border border-green-200 bg-green-50/50 p-4 dark:border-green-900/50 dark:bg-green-950/10">
              <div className="flex items-start gap-3">
                {/* File Icon */}
                <div
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${fileColorInfo?.bg}`}
                >
                  <span className={`text-lg font-bold ${fileColorInfo?.text}`}>
                    {fileColorInfo?.label}
                  </span>
                </div>

                {/* File Info */}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-gray-900 dark:text-white">
                    {profile.resumeFile}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-gray-500">
                    {profile.resumeFileSize && (
                      <span>{formatFileSize(profile.resumeFileSize)}</span>
                    )}
                    {profile.resumeUploadDate && (
                      <>
                        <span className="text-gray-300 dark:text-gray-600">•</span>
                        <span>{formatDate(profile.resumeUploadDate)}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-1">
                  <TooltipWrapper text="تحميل">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-gray-500 hover:text-green-600"
                      aria-label="تحميل"
                      onClick={() =>
                        window.open('/api/profile/resume/download', '_blank')
                      }
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </TooltipWrapper>
                  <TooltipWrapper text="استبدال">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-gray-500 hover:text-blue-600"
                      aria-label="استبدال"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </TooltipWrapper>
                  <TooltipWrapper text="حذف">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-gray-500 hover:text-red-500"
                      aria-label="حذف"
                      onClick={() => setDeleteDialog(true)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TooltipWrapper>
                </div>
              </div>
            </div>
          ) : (
            /* ─── Upload Area ─── */
            <div
              onDragOver={e => {
                e.preventDefault()
                setDragOver(true)
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => !uploading && fileInputRef.current?.click()}
              className={`flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 text-center transition-all ${
                dragOver
                  ? 'border-red-400 bg-red-50 dark:border-red-600 dark:bg-red-950/20'
                  : 'border-gray-200 bg-gray-50/50 hover:border-red-300 hover:bg-red-50/30 dark:border-gray-700 dark:bg-gray-900/50 dark:hover:border-red-800 dark:hover:bg-red-950/10'
              }`}
            >
              {uploading ? (
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="h-8 w-8 animate-spin text-red-500" />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    جارٍ رفع الملف...
                  </p>
                  <div className="w-48">
                    <Progress value={uploadProgress} className="h-1.5" />
                  </div>
                </div>
              ) : (
                <>
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-red-50 dark:bg-red-950/30">
                    <Upload className="h-7 w-7 text-red-400" />
                  </div>
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    اسحب الملف هنا أو انقر للاختيار
                  </p>
                  <p className="mt-1 text-xs text-gray-400">
                    أو{' '}
                    <span className="font-medium text-red-600 dark:text-red-400">
                      اختر ملفاً من جهازك
                    </span>
                  </p>
                  <p className="mt-2 text-2xs text-gray-400">
                    PDF, DOC, DOCX — حد أقصى 5MB
                  </p>
                </>
              )}
            </div>
          )}

          {/* Hidden File Input */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.doc,.docx"
            onChange={handleFileChange}
            className="hidden"
          />
        </GlassCardContent>
      </GlassCard>

      {/* ═══ Section 2: CV Builder ═══ */}
      <GlassCard variant="flat" size="md">
        <GlassCardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <LayoutTemplate className="h-5 w-5 text-blue-500" />
              <div>
                <GlassCardTitle className="text-base">
                  بنّاء السيرة الذاتية
                </GlassCardTitle>
                <GlassCardDescription>
                  أنشئ سيرة ذاتية احترافية باستخدام بنّاء السيرة الذاتية
                </GlassCardDescription>
              </div>
            </div>
          </div>
        </GlassCardHeader>
        <GlassCardContent>
          {/* Template Cards */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {TEMPLATES.map(template => {
              const Icon = template.icon
              return (
                <Link
                  key={template.id}
                  href={`/jobs?tab=cv&template=${template.id}`}
                  className={`group relative overflow-hidden rounded-xl border border-gray-100 transition-all hover:shadow-lg ${template.borderHover} dark:border-gray-800`}
                >
                  {/* Preview Area */}
                  <div
                    className={`relative flex h-28 items-center justify-center bg-gradient-to-br ${template.color}`}
                  >
                    <Icon className="h-10 w-10 text-white/70 transition-transform group-hover:scale-110" />
                    {/* Hover Overlay */}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/0 transition-all group-hover:bg-black/40">
                      <span className="flex items-center gap-1.5 rounded-full bg-white/0 px-4 py-2 text-sm font-medium text-white opacity-0 transition-all group-hover:bg-white/90 group-hover:text-gray-900 group-hover:opacity-100">
                        <ExternalLink className="h-4 w-4" />
                        استخدام القالب
                      </span>
                    </div>
                  </div>
                  {/* Info */}
                  <div className="p-3">
                    <p className="text-sm font-bold text-gray-900 group-hover:text-red-700 dark:text-white dark:group-hover:text-red-400">
                      {template.name}
                    </p>
                    <p className="mt-0.5 text-[11px] text-gray-500">
                      {template.description}
                    </p>
                  </div>
                </Link>
              )
            })}
          </div>

          {/* Create New Button */}
          <div className="mt-4 flex justify-center">
            <Link href="/jobs?tab=cv">
              <Button className="gap-2 rounded-full bg-red-600 hover:bg-red-700">
                <PenLine className="h-4 w-4" />
                إنشاء سيرة ذاتية جديدة
              </Button>
            </Link>
          </div>
        </GlassCardContent>
      </GlassCard>

      {/* ═══ Section 3: CV Writing Tips (Expandable) ═══ */}
      <GlassCard variant="flat" size="md">
        <button
          onClick={() => setTipsExpanded(!tipsExpanded)}
          className="flex w-full items-center justify-between text-start"
        >
          <GlassCardHeader className="flex-1 p-0">
            <GlassCardTitle className="flex items-center gap-2 text-base">
              <Lightbulb className="h-5 w-5 text-amber-500" />
              نصائح لكتابة سيرة ذاتية متميزة
            </GlassCardTitle>
            <GlassCardDescription>
              {tipsExpanded
                ? 'اضغط للإغلاق'
                : 'اضغط لعرض النصائح'}
            </GlassCardDescription>
          </GlassCardHeader>
          {tipsExpanded ? (
            <ChevronUp className="h-5 w-5 shrink-0 text-gray-400" />
          ) : (
            <ChevronDown className="h-5 w-5 shrink-0 text-gray-400" />
          )}
        </button>

        {tipsExpanded && (
          <GlassCardContent className="pt-4">
            <ul className="space-y-3">
              {CV_WRITING_TIPS.map((tip, i) => (
                <li
                  key={i}
                  className="flex items-start gap-3 text-sm text-gray-600 dark:text-gray-400"
                >
                  <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-50 text-xs font-bold text-amber-600 dark:bg-amber-900/30 dark:text-amber-400">
                    {i + 1}
                  </div>
                  <span className="leading-relaxed">{tip}</span>
                </li>
              ))}
            </ul>
          </GlassCardContent>
        )}
      </GlassCard>

      {/* ═══ Section 4: Improve Your Profile ═══ */}
      <GlassCard variant="default" size="md">
        <GlassCardHeader>
          <GlassCardTitle className="flex items-center gap-2 text-base">
            <Target className="h-5 w-5 text-amber-500" />
            تحسين ملفك
          </GlassCardTitle>
          <GlassCardDescription>
            أكمل ملفك المهني لتحسين فرصك في بنك السير الذاتية
          </GlassCardDescription>
        </GlassCardHeader>
        <GlassCardContent>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {/* Score */}
            <ScoreDisplay profile={profile} />

            {/* CV Bank Toggle */}
            <div className="flex flex-col justify-center space-y-4">
              <div className="rounded-xl border border-gray-100 bg-gray-50/50 p-4 dark:border-gray-800 dark:bg-gray-900/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-purple-500" />
                    <div>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        إظهار سيرتي في بنك السير الذاتية
                      </p>
                      <p className="text-2xs text-gray-400">
                        الشركات تستطيع البحث عنك والتواصل معك
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={profile.cvVisibleInBank}
                    onCheckedChange={handleCvBankToggle}
                  />
                </div>
              </div>

              {/* Quick Actions */}
              <div className="space-y-2">
                <Link href="/jobs/candidate/profile" className="block">
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-2"
                  >
                    <User className="h-4 w-4 text-blue-500" />
                    أكمل الملف المهني
                    <ArrowLeft className="ms-auto h-4 w-4 text-gray-400" />
                  </Button>
                </Link>
                <Link href="/jobs?tab=cv" className="block">
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-2"
                  >
                    <PenLine className="h-4 w-4 text-green-500" />
                    بناء سيرة ذاتية
                    <ArrowLeft className="ms-auto h-4 w-4 text-gray-400" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </GlassCardContent>
      </GlassCard>

      {/* ═══ Delete Confirmation Dialog ═══ */}
      <Dialog open={deleteDialog} onOpenChange={setDeleteDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              حذف السيرة الذاتية
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف السيرة الذاتية المرفوعة؟ لا يمكن التراجع
              عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setDeleteDialog(false)}>
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={uploading}
              className="bg-red-600 hover:bg-red-700"
            >
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  جارٍ الحذف...
                </>
              ) : (
                'حذف'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Tooltip Wrapper (simple, avoids dependency issues)
// ═══════════════════════════════════════════════════════════════════════════════

function TooltipWrapper({
  children,
  text,
}: {
  children: React.ReactNode
  text: string
}) {
  const [show, setShow] = useState(false)
  return (
    <div
      className="relative"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      {children}
      {show && (
        <div className="absolute bottom-full end-1/2 z-50 mb-1 translate-x-1/2 rounded-md bg-gray-900 px-2 py-1 text-2xs text-white shadow-lg dark:bg-gray-100 dark:text-gray-900">
          {text}
          <div className="absolute start-1/2 top-full -translate-x-1/2 border-4 border-transparent border-t-gray-900 dark:border-t-gray-100" />
        </div>
      )}
    </div>
  )
}