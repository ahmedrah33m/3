'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  Heart,
  MapPin,
  Building2,
  Clock,
  DollarSign,
  Users,
  Search,
  LayoutGrid,
  List,
  ArrowUpDown,
  BookmarkX,
  Send,
  Eye,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  GlassCard,
  GlassCardContent,
} from '@/components/ui/glass-card'
import { useToast } from '@/hooks/use-toast'

// ═══════════════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════════════

interface SavedJob {
  id: string
  jobId: string
  createdAt: string
  job: {
    id: string
    title: string
    company: string
    location: string | null
    type: string
    salary: string | null
    image: string | null
    isFeatured: boolean
    viewsCount: number
    category: string | null
    salaryMin: string | null
    salaryMax: string | null
    salaryCurrency: string
    skillsRequired: string | null
    sector: string | null
    createdAt: string
    publisher: {
      id: string
      name: string
      avatar: string | null
      companyLogo: string | null
      companyName: string | null
    } | null
    _count: { applications: number }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════════════════

const JOB_TYPE_MAP: Record<string, string> = {
  FULL_TIME: 'دوام كامل',
  PART_TIME: 'دوام جزئي',
  REMOTE: 'عن بُعد',
  CONTRACT: 'عقد',
  INTERNSHIP: 'تدريب',
  'full-time': 'دوام كامل',
  'part-time': 'دوام جزئي',
  remote: 'عن بُعد',
  contract: 'عقد',
  internship: 'تدريب',
}

function getJobTypeLabel(type: string): string {
  return JOB_TYPE_MAP[type] || type
}

function timeAgo(dateStr: string): string {
  if (!dateStr) return ''
  const now = new Date()
  const date = new Date(dateStr)
  const diffMs = now.getTime() - date.getTime()
  const diffMin = Math.floor(diffMs / 60000)
  const diffHr = Math.floor(diffMin / 60)
  const diffDay = Math.floor(diffHr / 24)
  const diffWeek = Math.floor(diffDay / 7)
  if (diffMin < 1) return 'الآن'
  if (diffMin < 60) return `منذ ${diffMin} دقيقة`
  if (diffHr < 24) return `منذ ${diffHr} ساعة`
  if (diffDay < 7) return `منذ ${diffDay} يوم`
  if (diffWeek < 4) return `منذ ${diffWeek} أسبوع`
  return `منذ ${Math.floor(diffDay / 30)} شهر`
}

function getCompanyInitial(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase()
}

function formatSalary(job: SavedJob['job']): string | null {
  const parts: string[] = []
  if (job.salary) return job.salary
  if (job.salaryMin) parts.push(job.salaryMin)
  if (job.salaryMax) parts.push(job.salaryMax)
  if (parts.length) return `${parts.join(' - ')} ${job.salaryCurrency || ''}`.trim()
  return null
}

// ═══════════════════════════════════════════════════════════════════════════════
// Skeleton
// ═══════════════════════════════════════════════════════════════════════════════

function SavedJobSkeleton() {
  return (
    <GlassCard variant="flat" className="p-4">
      <div className="flex items-start gap-3">
        <Skeleton className="size-10 shrink-0 rounded-lg" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
        <Skeleton className="size-8 rounded-full" />
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Skeleton className="h-6 w-20 rounded-full" />
        <Skeleton className="h-6 w-16 rounded-full" />
        <Skeleton className="h-6 w-24 rounded-full" />
      </div>
      <div className="mt-3 flex justify-between">
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-4 w-20" />
      </div>
    </GlassCard>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Saved Job Card — Grid Variant
// ═══════════════════════════════════════════════════════════════════════════════

function SavedJobCardGrid({
  item,
  isApplied,
  onUnsave,
  onQuickApply,
}: {
  item: SavedJob
  isApplied: boolean
  onUnsave: (jobId: string, e: React.MouseEvent) => void
  onQuickApply: (jobId: string, e: React.MouseEvent) => void
}) {
  const job = item.job
  const logo = job.publisher?.companyLogo || job.image || job.publisher?.avatar
  const companyName = job.publisher?.companyName || job.company
  const salaryText = formatSalary(job)

  return (
    <GlassCard
      variant="interactive"
      size="sm"
      hoverable
      className="group relative"
    >
      {/* ── Header ──────────────────────────────────────────────────────── */}
      <div className="flex items-start gap-3">
        <Link href={`/jobs/${job.id}`} className="shrink-0">
          <Avatar className="size-10 rounded-lg border border-border/50">
            <AvatarImage src={logo || undefined} alt={companyName} className="object-cover" />
            <AvatarFallback className="rounded-lg bg-red-50 text-xs font-bold text-red-700 dark:bg-red-950/40 dark:text-red-400">
              {getCompanyInitial(companyName || '؟')}
            </AvatarFallback>
          </Avatar>
        </Link>
        <div className="min-w-0 flex-1">
          <Link href={`/jobs/${job.id}`}>
            <h3 className="truncate text-sm font-bold leading-tight text-foreground transition-colors group-hover:text-red-600 dark:group-hover:text-red-400">
              {job.title}
            </h3>
          </Link>
          <Link href={`/jobs/${job.id}`} className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
            <Building2 className="size-3 shrink-0" />
            <span className="truncate">{companyName}</span>
          </Link>
        </div>
        <button
          onClick={(e) => onUnsave(job.id, e)}
          className="flex size-8 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-500 transition-all hover:scale-110 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-950/60"
          aria-label="إزالة من المحفوظات"
        >
          <Heart className="size-4" fill="currentColor" />
        </button>
      </div>

      {/* ── Tags ─────────────────────────────────────────────────────────── */}
      <div className="mt-3 flex flex-wrap gap-1.5">
        <Badge variant="outline" className="border-red-200 bg-red-50 px-2.5 py-0 text-2xs font-medium text-red-700 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-400">
          <Clock className="ms-1 size-2.5" />
          {getJobTypeLabel(job.type)}
        </Badge>
        {job.location && (
          <Badge variant="outline" className="border-border px-2.5 py-0 text-2xs font-medium text-muted-foreground">
            <MapPin className="ms-1 size-2.5" />
            {job.location}
          </Badge>
        )}
        {salaryText && (
          <Badge variant="outline" className="border-emerald-200 bg-emerald-50 px-2.5 py-0 text-2xs font-medium text-emerald-700 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-400">
            <DollarSign className="ms-1 size-2.5" />
            {salaryText}
          </Badge>
        )}
      </div>

      {/* ── Salary prominent ─────────────────────────────────────────────── */}
      {salaryText && (
        <div className="mt-3 flex items-center gap-2">
          <DollarSign className="size-4 shrink-0 text-red-500" />
          <span className="text-sm font-semibold text-red-700 dark:text-red-400">{salaryText}</span>
        </div>
      )}

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <div className="mt-4 flex items-center justify-between border-t border-border/50 pt-3">
        <div className="flex items-center gap-3 text-2xs text-muted-foreground">
          <span>{timeAgo(job.createdAt)}</span>
          {job._count?.applications > 0 && (
            <span className="flex items-center gap-0.5">
              <Users className="size-2.5" />
              {job._count.applications} متقدم
            </span>
          )}
        </div>
        {!isApplied ? (
          <Button
            size="sm"
            onClick={(e) => onQuickApply(job.id, e)}
            className="h-7 rounded-full bg-red-600 px-3 text-xs hover:bg-red-700"
          >
            <Send className="ms-1 size-3" />
            تقديم سريع
          </Button>
        ) : (
          <Badge className="rounded-full bg-emerald-100 text-2xs font-medium text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
            تم التقديم ✓
          </Badge>
        )}
      </div>
    </GlassCard>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Saved Job Card — List Variant
// ═══════════════════════════════════════════════════════════════════════════════

function SavedJobCardList({
  item,
  isApplied,
  onUnsave,
  onQuickApply,
}: {
  item: SavedJob
  isApplied: boolean
  onUnsave: (jobId: string, e: React.MouseEvent) => void
  onQuickApply: (jobId: string, e: React.MouseEvent) => void
}) {
  const job = item.job
  const logo = job.publisher?.companyLogo || job.image || job.publisher?.avatar
  const companyName = job.publisher?.companyName || job.company
  const salaryText = formatSalary(job)

  return (
    <GlassCard
      variant="interactive"
      size="sm"
      hoverable
      className="group"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Avatar */}
        <Link href={`/jobs/${job.id}`} className="shrink-0">
          <Avatar className="size-11 rounded-lg border border-border/50">
            <AvatarImage src={logo || undefined} alt={companyName} className="object-cover" />
            <AvatarFallback className="rounded-lg bg-red-50 text-xs font-bold text-red-700 dark:bg-red-950/40 dark:text-red-400">
              {getCompanyInitial(companyName || '؟')}
            </AvatarFallback>
          </Avatar>
        </Link>

        {/* Info */}
        <div className="min-w-0 flex-1">
          <Link href={`/jobs/${job.id}`}>
            <h3 className="truncate text-sm font-bold text-foreground transition-colors group-hover:text-red-600 dark:group-hover:text-red-400">
              {job.title}
            </h3>
          </Link>
          <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Building2 className="size-3" />
              {companyName}
            </span>
            {job.location && (
              <span className="flex items-center gap-1">
                <MapPin className="size-3" />
                {job.location}
              </span>
            )}
            <span>{timeAgo(job.createdAt)}</span>
          </div>
        </div>

        {/* Salary */}
        {salaryText && (
          <span className="hidden shrink-0 text-sm font-semibold text-red-700 dark:text-red-400 md:block">
            {salaryText}
          </span>
        )}

        {/* Type badge */}
        <Badge variant="outline" className="hidden shrink-0 border-red-200 bg-red-50 text-2xs text-red-700 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-400 sm:inline-flex">
          {getJobTypeLabel(job.type)}
        </Badge>

        {/* Applicants */}
        {job._count?.applications > 0 && (
          <span className="hidden shrink-0 items-center gap-1 text-xs text-muted-foreground lg:flex">
            <Users className="size-3" />
            {job._count.applications}
          </span>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={(e) => onUnsave(job.id, e)}
            className="flex size-8 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-500 transition-all hover:scale-110 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-950/60"
            aria-label="إزالة من المحفوظات"
          >
            <Heart className="size-4" fill="currentColor" />
          </button>
          {!isApplied ? (
            <Button
              size="sm"
              onClick={(e) => onQuickApply(job.id, e)}
              className="h-7 rounded-full bg-red-600 px-3 text-xs hover:bg-red-700"
            >
              <Send className="ms-1 size-3" />
              تقديم
            </Button>
          ) : (
            <Badge className="hidden shrink-0 rounded-full bg-emerald-100 text-2xs font-medium text-emerald-700 sm:inline-flex dark:bg-emerald-950/40 dark:text-emerald-400">
              تم التقديم
            </Badge>
          )}
        </div>
      </div>
    </GlassCard>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main Page
// ═══════════════════════════════════════════════════════════════════════════════

export default function SavedJobsPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [savedJobs, setSavedJobs] = useState<SavedJob[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sortBy, setSortBy] = useState<'saveDate' | 'postedDate'>('saveDate')
  const [appliedJobs, setAppliedJobs] = useState<Set<string>>(new Set())

  // ── Fetch saved jobs ─────────────────────────────────────────────────────
  const fetchSavedJobs = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/jobs/saved')
      if (!res.ok) throw new Error()
      const data = await res.json()
      setSavedJobs(Array.isArray(data) ? data : [])
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء تحميل الوظائف المحفوظة',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  // ── Track which jobs user already applied to ─────────────────────────────
  const fetchAppliedJobs = useCallback(async () => {
    try {
      const res = await fetch('/api/jobs?applied=true&limit=200')
      if (res.ok) {
        const data = await res.json()
        if (Array.isArray(data.jobs)) {
          setAppliedJobs(new Set(data.jobs.map((j: { id: string }) => j.id)))
        }
      }
    } catch {
      /* silent */
    }
  }, [])

  useEffect(() => {
    fetchSavedJobs()
    fetchAppliedJobs()
  }, [fetchSavedJobs, fetchAppliedJobs])

  // ── Unsave ───────────────────────────────────────────────────────────────
  const handleUnsave = async (jobId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    try {
      const res = await fetch('/api/jobs/saved', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId }),
      })
      if (res.ok) {
        setSavedJobs((prev) => prev.filter((s) => s.jobId !== jobId))
        toast({ title: 'تم الإزالة', description: 'تمت إزالة الوظيفة من المحفوظات' })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء إزالة الوظيفة',
        variant: 'destructive',
      })
    }
  }

  // ── Quick Apply ──────────────────────────────────────────────────────────
  const handleQuickApply = async (jobId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    try {
      const res = await fetch(`/api/jobs/${jobId}/apply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ coverLetter: '' }),
      })
      if (res.ok) {
        setAppliedJobs((prev) => new Set(prev).add(jobId))
        toast({ title: 'تم التقديم', description: 'تم إرسال طلبك بنجاح' })
      } else {
        const data = await res.json()
        toast({
          title: 'خطأ',
          description: data.error || 'حدث خطأ أثناء التقديم',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء التقديم',
        variant: 'destructive',
      })
    }
  }

  // ── Filtered & Sorted ────────────────────────────────────────────────────
  const filteredJobs = useMemo(() => {
    let result = [...savedJobs]

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase()
      result = result.filter(
        (s) =>
          s.job.title.toLowerCase().includes(q) ||
          s.job.company.toLowerCase().includes(q) ||
          (s.job.location || '').toLowerCase().includes(q)
      )
    }

    // Sort
    result.sort((a, b) => {
      switch (sortBy) {
        case 'saveDate':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        case 'postedDate':
          return new Date(b.job.createdAt).getTime() - new Date(a.job.createdAt).getTime()
        default:
          return 0
      }
    })

    return result
  }, [savedJobs, searchQuery, sortBy])

  // ═══════════════════════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════════════════════

  return (
    <div className="space-y-5">
      {/* ── Page Title ─────────────────────────────────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">الوظائف المحفوظة</h2>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {savedJobs.length} وظيفة محفوظة
          </p>
        </div>
      </div>

      {/* ── Toolbar: Search + Sort + View ──────────────────────────────────── */}
      <GlassCard variant="flat" size="sm">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="ابحث في الوظائف المحفوظة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-10 ps-10"
            />
          </div>

          <div className="flex items-center gap-2">
            {/* Sort */}
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
              <SelectTrigger className="h-9 w-auto gap-1.5 text-sm">
                <ArrowUpDown className="size-3.5 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="saveDate">تاريخ الحفظ</SelectItem>
                <SelectItem value="postedDate">تاريخ النشر</SelectItem>
              </SelectContent>
            </Select>

            {/* View toggle */}
            <div className="flex rounded-lg border border-border">
              <button
                onClick={() => setViewMode('grid')}
                className={`flex size-9 items-center justify-center rounded-s-lg transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-accent text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                aria-label="عرض شبكي"
              >
                <LayoutGrid className="size-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`flex size-9 items-center justify-center rounded-e-lg transition-colors ${
                  viewMode === 'list'
                    ? 'bg-accent text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                aria-label="عرض قائمة"
              >
                <List className="size-4" />
              </button>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* ── Loading ────────────────────────────────────────────────────────── */}
      {loading && (
        <div
          className={
            viewMode === 'grid'
              ? 'grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3'
              : 'space-y-3'
          }
        >
          {Array.from({ length: 6 }).map((_, i) => (
            <SavedJobSkeleton key={i} />
          ))}
        </div>
      )}

      {/* ── Empty State ────────────────────────────────────────────────────── */}
      {!loading && filteredJobs.length === 0 && (
        <GlassCard variant="flat" size="lg" className="flex flex-col items-center justify-center py-16 text-center">
          <div className="mb-4 flex size-20 items-center justify-center rounded-full bg-red-50 dark:bg-red-950/30">
            <BookmarkX className="size-10 text-red-300 dark:text-red-700" />
          </div>
          <h3 className="mb-2 text-lg font-semibold text-foreground">
            {searchQuery ? 'لا توجد نتائج مطابقة' : 'لم تقم بحفظ أي وظيفة بعد'}
          </h3>
          <p className="mb-6 max-w-sm text-sm text-muted-foreground">
            {searchQuery
              ? 'جرّب البحث بكلمات مختلفة'
              : 'احفظ الوظائف التي تهمك للرجوع إليها لاحقاً'}
          </p>
          {!searchQuery && (
            <Button
              onClick={() => router.push('/jobs')}
              className="rounded-full bg-red-600 hover:bg-red-700"
            >
              <Eye className="ms-1.5 size-4" />
              تصفح الوظائف
            </Button>
          )}
        </GlassCard>
      )}

      {/* ── Grid View ──────────────────────────────────────────────────────── */}
      {!loading && filteredJobs.length > 0 && viewMode === 'grid' && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredJobs.map((item) => (
            <SavedJobCardGrid
              key={item.id}
              item={item}
              isApplied={appliedJobs.has(item.job.id)}
              onUnsave={handleUnsave}
              onQuickApply={handleQuickApply}
            />
          ))}
        </div>
      )}

      {/* ── List View ──────────────────────────────────────────────────────── */}
      {!loading && filteredJobs.length > 0 && viewMode === 'list' && (
        <div className="space-y-3">
          {filteredJobs.map((item) => (
            <SavedJobCardList
              key={item.id}
              item={item}
              isApplied={appliedJobs.has(item.job.id)}
              onUnsave={handleUnsave}
              onQuickApply={handleQuickApply}
            />
          ))}
        </div>
      )}
    </div>
  )
}