'use client'

import { useState, useEffect, useCallback, useMemo, useRef } from 'react'
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  GraduationCap,
  Globe,
  Shield,
  X,
  Plus,
  Check,
  Save,
  Building2,
  Star,
  Target,
  Languages,
  DollarSign,
  FileSearch,
  Loader2,
  ChevronDown,
  Lightbulb,
  Settings,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  GlassCard,
  GlassCardContent,
  GlassCardHeader,
  GlassCardTitle,
  GlassCardDescription,
} from '@/components/ui/glass-card'
import { useToast } from '@/hooks/use-toast'
import {
  WORK_MODES,
  AVAILABILITY_OPTIONS,
  SEARCH_STATUS_OPTIONS,
  SUPPORTED_CURRENCIES,
  SECTORS as TAXONOMY_SECTORS,
  IRAQI_PROVINCES,
} from '@/lib/jobs/taxonomy'
import {
  DEFAULT_TIMEZONES,
  getProfessional,
  type ProfessionalProfileCore,
} from '@/lib/jobs/professional-profile'
import { computeProfileCompletion } from '@/lib/jobs/profile-completion'

// ═══════════════════════════════════════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════════════════════════════════════

interface UserProfile {
  id: string
  name: string | null
  email: string
  phone: string | null
  avatar: string | null
  jobTitle: string | null
  bio: string | null
  sector: string | null
  experience: number | null
  educationLevel: string | null
  university: string | null
  gpa: string | null
  skills: string[]
  languages: { language: string; proficiency: string }[]
  openToWork: boolean
  cvVisibleInBank: boolean
  salaryMin: number | null
  salaryMax: number | null
  salaryCurrency: string
  resumeFile: string | null
  location: string | null
  gender: string | null
  dateOfBirth: string | null
  nationality: string | null
  militaryStatus: string | null
  jobTypes: string[]
  resumeData: unknown
  emailVerified: boolean
  verifiedSections: number
}

// ═══════════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════════

const SECTOR_OPTIONS = [
  { value: 'تكنولوجيا', label: 'تكنولوجيا' },
  { value: 'مالي', label: 'مالي' },
  { value: 'نفط وغاز', label: 'نفط وغاز' },
  { value: 'تعليم', label: 'تعليم' },
  { value: 'صحة', label: 'صحة' },
  { value: 'إنشاءات', label: 'إنشاءات' },
  { value: 'حكومي', label: 'حكومي' },
  { value: 'آخر', label: 'آخر' },
]

const EDUCATION_LEVELS = [
  { value: 'ثانوية', label: 'ثانوية' },
  { value: 'دبلوم', label: 'دبلوم' },
  { value: 'بكالوريوس', label: 'بكالوريوس / إجازة' },
  { value: 'ماجستير', label: 'ماجستير' },
  { value: 'دكتوراه', label: 'دكتوراه' },
]

const GENDER_OPTIONS = [
  { value: 'ذكر', label: 'ذكر' },
  { value: 'أنثى', label: 'أنثى' },
]

const MILITARY_STATUS_OPTIONS = [
  { value: 'معفى', label: 'معفى' },
  { value: 'أدى الخدمة', label: 'أدى الخدمة' },
  { value: 'لم يؤدِ', label: 'لم يؤدِ' },
]

const JOB_TYPES = [
  { value: 'دوام كامل', label: 'دوام كامل' },
  { value: 'دوام جزئي', label: 'دوام جزئي' },
  { value: 'عن بُعد', label: 'عن بُعد' },
  { value: 'عقد', label: 'عقد' },
  { value: 'تدريب', label: 'تدريب' },
]

const PROFICIENCY_LEVELS = [
  { value: 'مبتدئ', label: 'مبتدئ' },
  { value: 'متوسط', label: 'متوسط' },
  { value: 'متقدم', label: 'متقدم' },
  { value: 'طلاقة', label: 'طلاقة' },
  { value: 'لغة أم', label: 'لغة أم' },
]

const SKILL_SUGGESTIONS = [
  'JavaScript',
  'Python',
  'Excel',
  'تحليل بيانات',
  'إدارة مشاريع',
  'محاسبة',
  'تسويق رقمي',
  'إدارة مبيعات',
  'React',
  'TypeScript',
  'SQL',
  'Node.js',
  'Java',
  'C++',
  'تصميم جرافيك',
  'كتابة محتوى',
  'إدارة موارد بشرية',
  'تحليل مالي',
  'قانون',
  'هندسة برمجيات',
  'UI/UX',
  'Power BI',
  'AWS',
  'Docker',
  'Git',
]

const LANGUAGE_SUGGESTIONS = [
  'العربية',
  'الإنجليزية',
  'الكردية',
  'التركية',
  'الفارسية',
  'الفرنسية',
]

const MAX_BIO_LENGTH = 500

function defaultProfessional(): ProfessionalProfileCore {
  return {
    basic: { country: 'العراق', timezone: 'Asia/Baghdad' },
    preferences: { salaryCurrency: 'IQD', preferredSectors: [] },
  }
}

function defaultProfile(): UserProfile {
  return {
    id: '',
    name: '',
    email: '',
    phone: null,
    avatar: null,
    jobTitle: null,
    bio: null,
    sector: null,
    experience: null,
    educationLevel: null,
    university: null,
    gpa: null,
    skills: [],
    languages: [],
    openToWork: true,
    cvVisibleInBank: true,
    salaryMin: null,
    salaryMax: null,
    salaryCurrency: 'IQD',
    resumeFile: null,
    location: null,
    gender: null,
    dateOfBirth: null,
    nationality: null,
    militaryStatus: null,
    jobTypes: [],
    resumeData: null,
    emailVerified: false,
    verifiedSections: 0,
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Circular Score Component
// ═══════════════════════════════════════════════════════════════════════════════

function CircularScore({ score }: { score: number }) {
  const radius = 42
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference
  const color = score >= 70 ? '#10B981' : score >= 40 ? '#F59E0B' : '#EF4444'

  return (
    <div className="relative flex items-center justify-center">
      <svg width="100" height="100" className="-rotate-90">
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="6"
          className="text-gray-200 dark:text-gray-700"
        />
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-700 ease-out"
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-2xl font-bold text-gray-900 dark:text-white">
          {score}
        </span>
        <span className="text-2xs text-gray-500 dark:text-gray-400">
          من 100
        </span>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Skill Input with Suggestions
// ═══════════════════════════════════════════════════════════════════════════════

function SkillInput({
  skills,
  onAdd,
  onRemove,
}: {
  skills: string[]
  onAdd: (skill: string) => void
  onRemove: (skill: string) => void
}) {
  const [value, setValue] = useState('')
  const [showSuggestions, setShowSuggestions] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  const filteredSuggestions = useMemo(() => {
    if (!value.trim()) return SKILL_SUGGESTIONS.filter(s => !skills.includes(s)).slice(0, 8)
    return SKILL_SUGGESTIONS.filter(
      s =>
        !skills.includes(s) &&
        s.toLowerCase().includes(value.trim().toLowerCase())
    ).slice(0, 8)
  }, [value, skills])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleAdd = (skill?: string) => {
    const s = (skill || value).trim()
    if (s && !skills.includes(s)) {
      onAdd(s)
      setValue('')
      setShowSuggestions(false)
    }
  }

  return (
    <div className="space-y-3" ref={containerRef}>
      {/* Existing Skills */}
      <div className="flex flex-wrap gap-1.5">
        {skills.map(skill => (
          <Badge
            key={skill}
            variant="secondary"
            className="gap-1 rounded-lg px-2.5 py-1 text-xs"
          >
            {skill}
            <button
              onClick={() => onRemove(skill)}
              className="ms-0.5 rounded-full p-0.5 transition-colors hover:bg-gray-200 dark:hover:bg-gray-700"
              aria-label={`حذف ${skill}`}
            >
              <X className="h-3 w-3" />
            </button>
          </Badge>
        ))}
        {skills.length === 0 && (
          <p className="text-xs text-gray-400">لم تضف مهارات بعد</p>
        )}
      </div>

      {/* Input + Suggestions */}
      <div className="relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Input
              value={value}
              onChange={e => {
                setValue(e.target.value)
                setShowSuggestions(true)
              }}
              onFocus={() => setShowSuggestions(true)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  handleAdd()
                }
              }}
              placeholder="أضف مهارة..."
              className="h-9"
            />
          </div>
          <Button
            size="sm"
            onClick={() => handleAdd()}
            variant="outline"
            className="shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span className="ms-1">إضافة</span>
          </Button>
        </div>

        {/* Suggestions Dropdown */}
        {showSuggestions && filteredSuggestions.length > 0 && (
          <div className="absolute start-0 end-0 top-full z-20 mt-1 max-h-48 overflow-y-auto rounded-lg border border-gray-200 bg-white shadow-lg dark:border-gray-700 dark:bg-gray-900">
            {filteredSuggestions.map(suggestion => (
              <button
                key={suggestion}
                onClick={() => handleAdd(suggestion)}
                className="flex w-full items-center gap-2 px-3 py-2 text-sm text-gray-700 transition-colors hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800 first:rounded-t-lg last:rounded-b-lg"
              >
                <Plus className="h-3.5 w-3.5 text-gray-400" />
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Language Input with Common Languages
// ═══════════════════════════════════════════════════════════════════════════════

function LanguageInput({
  languages,
  onAdd,
  onRemove,
}: {
  languages: { language: string; proficiency: string }[]
  onAdd: (language: string, proficiency: string) => void
  onRemove: (idx: number) => void
}) {
  const [lang, setLang] = useState('')
  const [prof, setProf] = useState('متوسط')
  const [showLangSuggestions, setShowLangSuggestions] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  const availableLangs = useMemo(() => {
    return LANGUAGE_SUGGESTIONS.filter(
      s => !languages.some(l => l.language === s)
    )
  }, [languages])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowLangSuggestions(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleAdd = (language?: string) => {
    const l = (language || lang).trim()
    if (l && !languages.some(existing => existing.language === l)) {
      onAdd(l, prof)
      setLang('')
      setProf('متوسط')
      setShowLangSuggestions(false)
    }
  }

  return (
    <div className="space-y-3" ref={containerRef}>
      {/* Existing Languages */}
      <div className="space-y-2">
        {languages.map((entry, idx) => (
          <div
            key={idx}
            className="flex items-center justify-between rounded-lg border border-gray-100 bg-gray-50/50 px-3 py-2.5 dark:border-gray-800 dark:bg-gray-900/50"
          >
            <div className="flex items-center gap-2">
              <Languages className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {entry.language}
              </span>
              <Badge variant="outline" className="text-2xs">
                {entry.proficiency}
              </Badge>
            </div>
            <button
              onClick={() => onRemove(idx)}
              className="rounded-full p-1 text-gray-400 transition-colors hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-950/30"
              aria-label={`حذف ${entry.language}`}
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
        {languages.length === 0 && (
          <p className="text-xs text-gray-400">لم تضف لغات بعد</p>
        )}
      </div>

      {/* Add Language */}
      <div className="relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Input
              value={lang}
              onChange={e => {
                setLang(e.target.value)
                setShowLangSuggestions(true)
              }}
              onFocus={() => setShowLangSuggestions(true)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  handleAdd()
                }
              }}
              placeholder="اسم اللغة..."
              className="h-9"
            />
            {showLangSuggestions && availableLangs.length > 0 && !lang.trim() && (
              <div className="absolute start-0 end-0 top-full z-20 mt-1 max-h-40 overflow-y-auto rounded-lg border border-gray-200 bg-white shadow-lg dark:border-gray-700 dark:bg-gray-900">
                {availableLangs.map(suggestion => (
                  <button
                    key={suggestion}
                    onClick={() => handleAdd(suggestion)}
                    className="flex w-full items-center gap-2 px-3 py-2 text-sm text-gray-700 transition-colors hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-800"
                  >
                    <Plus className="h-3.5 w-3.5 text-gray-400" />
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
          </div>
          <Select value={prof} onValueChange={setProf}>
            <SelectTrigger className="h-9 w-28 shrink-0 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PROFICIENCY_LEVELS.map(p => (
                <SelectItem key={p.value} value={p.value} className="text-xs">
                  {p.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            size="sm"
            onClick={() => handleAdd()}
            variant="outline"
            className="shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span className="ms-1">إضافة</span>
          </Button>
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main Page
// ═══════════════════════════════════════════════════════════════════════════════

export default function ProfilePage() {
  const { toast } = useToast()

  const [profile, setProfile] = useState<UserProfile>(defaultProfile())
  const [professional, setProfessional] = useState<ProfessionalProfileCore>(defaultProfessional())
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState('basic')

  // ── Fetch Profile ─────────────────────────────────────────────────────────
  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/jobs/candidate/profile')
      if (res.status === 401) {
        toast({ title: 'تسجيل الدخول', description: 'يرجى تسجيل الدخول أولاً', variant: 'destructive' })
        return
      }
      if (!res.ok) throw new Error()
      const data = await res.json()
      const u = data.profile || data
      let rd: unknown = null
      if (u.resumeData) {
        try {
          rd = typeof u.resumeData === 'string' ? JSON.parse(u.resumeData) : u.resumeData
        } catch {
          rd = null
        }
      }
      setProfessional(getProfessional(rd) || defaultProfessional())
      setProfile({
        id: u.id || '',
        name: u.name || '',
        email: u.email || '',
        phone: u.phone || null,
        avatar: u.avatar || null,
        jobTitle: u.jobTitle || null,
        bio: u.bio || null,
        sector: u.sector || null,
        experience: u.experience ?? null,
        educationLevel: u.educationLevel || null,
        university: u.university || null,
        gpa: u.gpa ?? null,
        skills: Array.isArray(u.skills) ? u.skills : [],
        languages: Array.isArray(u.languages) ? u.languages : [],
        openToWork: u.openToWork ?? true,
        cvVisibleInBank: u.cvVisibleInBank ?? true,
        salaryMin: u.salaryMin ?? null,
        salaryMax: u.salaryMax ?? null,
        salaryCurrency: u.salaryCurrency || 'IQD',
        resumeFile: u.resumeFile || null,
        location: u.location || null,
        gender: u.gender || null,
        dateOfBirth: u.dateOfBirth || null,
        nationality: u.nationality || null,
        militaryStatus: u.militaryStatus || null,
        jobTypes: Array.isArray(u.jobTypes) ? u.jobTypes : [],
        resumeData: rd,
        emailVerified: !!u.emailVerified,
        verifiedSections: u.verifiedSections ?? 0,
      })
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء تحميل الملف الشخصي',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    fetchProfile()
  }, [fetchProfile])

  // ── Profile Completion (§6) ───────────────────────────────────────────────
  const completion = useMemo(
    () =>
      computeProfileCompletion({
        name: profile.name,
        avatar: profile.avatar,
        jobTitle: profile.jobTitle,
        bio: profile.bio,
        resumeFile: profile.resumeFile,
        experience: profile.experience,
        educationLevel: profile.educationLevel,
        university: profile.university,
        skills: profile.skills,
        languages: profile.languages,
        salaryMin: profile.salaryMin,
        emailVerified: profile.emailVerified,
        verifiedSections: profile.verifiedSections,
        resumeData: profile.resumeData,
      }),
    [profile],
  )

  // ── Update Field ──────────────────────────────────────────────────────────
  const updateField = <K extends keyof UserProfile>(key: K, value: UserProfile[K]) => {
    setProfile(prev => ({ ...prev, [key]: value }))
  }

  // ── Skills ────────────────────────────────────────────────────────────────
  const addSkill = (skill: string) => {
    if (skill.trim() && !profile.skills.includes(skill.trim())) {
      updateField('skills', [...profile.skills, skill.trim()])
    }
  }

  const removeSkill = (skill: string) => {
    updateField('skills', profile.skills.filter(s => s !== skill))
  }

  // ── Languages ─────────────────────────────────────────────────────────────
  const addLanguage = (language: string, proficiency: string) => {
    if (!language.trim()) return
    updateField('languages', [
      ...profile.languages,
      { language: language.trim(), proficiency },
    ])
  }

  const removeLanguage = (idx: number) => {
    updateField('languages', profile.languages.filter((_, i) => i !== idx))
  }

  // ── Job Types Toggle ──────────────────────────────────────────────────────
  const toggleJobType = (type: string) => {
    updateField(
      'jobTypes',
      profile.jobTypes.includes(type)
        ? profile.jobTypes.filter(t => t !== type)
        : [...profile.jobTypes, type]
    )
  }

  // ── Professional Profile Helpers ──────────────────────────────────────────
  const updateProfessional = (patch: Partial<ProfessionalProfileCore>) => {
    setProfessional(prev => ({ ...prev, ...patch }))
  }

  const updateProfessionalBasic = (key: keyof NonNullable<ProfessionalProfileCore['basic']>, value: string) => {
    setProfessional(prev => ({
      ...prev,
      basic: { ...(prev.basic || {}), [key]: value },
    }))
  }

  const togglePreferredSector = (sector: string) => {
    setProfessional(prev => {
      const current = prev.preferences?.preferredSectors || []
      return {
        ...prev,
        preferences: {
          ...(prev.preferences || {}),
          preferredSectors: current.includes(sector)
            ? current.filter(s => s !== sector)
            : [...current, sector],
        },
      }
    })
  }

  const setExpectedSalary = (value: number | null) => {
    setProfessional(prev => ({
      ...prev,
      preferences: { ...(prev.preferences || {}), expectedSalary: value },
    }))
  }

  // ── Save ──────────────────────────────────────────────────────────────────
  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/jobs/candidate/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: profile.name,
          phone: profile.phone,
          location: profile.location,
          gender: profile.gender,
          dateOfBirth: profile.dateOfBirth,
          nationality: profile.nationality,
          militaryStatus: profile.militaryStatus,
          jobTitle: profile.jobTitle,
          bio: profile.bio,
          sector: profile.sector,
          experience: profile.experience,
          educationLevel: profile.educationLevel,
          university: profile.university,
          gpa: profile.gpa,
          skills: profile.skills,
          languages: profile.languages,
          openToWork: profile.openToWork,
          cvVisibleInBank: profile.cvVisibleInBank,
          salaryMin: profile.salaryMin,
          salaryMax: profile.salaryMax,
          salaryCurrency: profile.salaryCurrency,
          jobTypes: profile.jobTypes,
          professional,
        }),
      })
      if (res.ok) {
        const data = await res.json().catch(() => null)
        if (data?.profile && data.profile.resumeData) {
          let rd: unknown = null
          try {
            rd = typeof data.profile.resumeData === 'string' ? JSON.parse(data.profile.resumeData) : data.profile.resumeData
          } catch {
            rd = null
          }
          setProfessional(getProfessional(rd) || professional)
          setProfile(prev => ({ ...prev, resumeData: rd }))
        }
        toast({
          title: 'تم بنجاح',
          description: 'تم تحديث الملف المهني بنجاح',
        })
      } else {
        const data = await res.json().catch(() => null)
        toast({
          title: 'خطأ',
          description: data.error || 'حدث خطأ أثناء الحفظ',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء الحفظ',
        variant: 'destructive',
      })
    } finally {
      setSaving(false)
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Render — Loading
  // ═══════════════════════════════════════════════════════════════════════════

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-72" />
          </div>
          <Skeleton className="h-10 w-36 rounded-full" />
        </div>
        <div className="flex gap-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-9 w-28 rounded-lg" />
          ))}
        </div>
        <Skeleton className="h-64 w-full rounded-xl" />
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
    )
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════════════════════

  return (
    <div className="space-y-6">
      {/* ─── Header ─── */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            الملف المهني
          </h2>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            أكمل ملفك لتحسين فرصك في الحصول على الوظائف
          </p>
        </div>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="rounded-full bg-red-600 hover:bg-red-700"
        >
          {saving ? (
            <Loader2 className="ms-1.5 h-4 w-4 animate-spin" />
          ) : (
            <Save className="ms-1.5 h-4 w-4" />
          )}
          {saving ? 'جارٍ الحفظ...' : 'حفظ التغييرات'}
        </Button>
      </div>

      {/* ─── Main Layout: Tabs + Score Sidebar ─── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        {/* ─── Tabs Content (3/4) ─── */}
        <div className="lg:col-span-3">
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            dir="rtl"
          >
            <TabsList className="mb-6 flex w-full flex-wrap gap-1 bg-gray-100/80 p-1 dark:bg-gray-800/60">
              <TabsTrigger
                value="basic"
                className="flex-1 gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900"
              >
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">المعلومات الأساسية</span>
                <span className="sm:hidden">أساسية</span>
              </TabsTrigger>
              <TabsTrigger
                value="professional"
                className="flex-1 gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900"
              >
                <Briefcase className="h-4 w-4" />
                <span className="hidden sm:inline">الملف المهني</span>
                <span className="sm:hidden">مهني</span>
              </TabsTrigger>
              <TabsTrigger
                value="skills"
                className="flex-1 gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900"
              >
                <Star className="h-4 w-4" />
                <span className="hidden sm:inline">المهارات واللغات</span>
                <span className="sm:hidden">مهارات</span>
              </TabsTrigger>
              <TabsTrigger
                value="salary"
                className="flex-1 gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900"
              >
                <DollarSign className="h-4 w-4" />
                <span className="hidden sm:inline">الراتب المطلوب</span>
                <span className="sm:hidden">راتب</span>
              </TabsTrigger>
              <TabsTrigger
                value="preferences"
                className="flex-1 gap-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-900"
              >
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline">تفضيلات البحث</span>
                <span className="sm:hidden">تفضيلات</span>
              </TabsTrigger>
            </TabsList>

            {/* ═══ Tab 1: Basic Info ═══ */}
            <TabsContent value="basic">
              <GlassCard variant="flat" size="md">
                <GlassCardHeader>
                  <GlassCardTitle className="flex items-center gap-2 text-base">
                    <User className="h-5 w-5 text-blue-500" />
                    المعلومات الأساسية
                  </GlassCardTitle>
                  <GlassCardDescription>
                    المعلومات الشخصية الأساسية التي تظهر في ملفك
                  </GlassCardDescription>
                </GlassCardHeader>
                <GlassCardContent>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {/* Full Name */}
                    <div className="space-y-1.5">
                      <Label htmlFor="name">الاسم الكامل</Label>
                      <div className="relative">
                        <User className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="name"
                          value={profile.name ?? ''}
                          onChange={e => updateField('name', e.target.value)}
                          className="ps-10"
                        />
                      </div>
                    </div>

                    {/* Email (disabled) */}
                    <div className="space-y-1.5">
                      <Label htmlFor="email">البريد الإلكتروني</Label>
                      <div className="relative">
                        <Mail className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="email"
                          value={profile.email}
                          disabled
                          className="ps-10 bg-gray-50 dark:bg-gray-800/60"
                        />
                      </div>
                    </div>

                    {/* Phone */}
                    <div className="space-y-1.5">
                      <Label htmlFor="phone">رقم الهاتف</Label>
                      <div className="relative">
                        <Phone className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="phone"
                          value={profile.phone || ''}
                          onChange={e => updateField('phone', e.target.value)}
                          className="ps-10"
                          placeholder="07XX XXX XXXX"
                        />
                      </div>
                    </div>

                    {/* Address / Location */}
                    <div className="space-y-1.5">
                      <Label htmlFor="location">العنوان</Label>
                      <div className="relative">
                        <MapPin className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="location"
                          value={profile.location || ''}
                          onChange={e => updateField('location', e.target.value)}
                          className="ps-10"
                          placeholder="مثال: بغداد، الكرادة"
                        />
                      </div>
                    </div>

                    {/* Gender */}
                    <div className="space-y-1.5">
                      <Label>الجنس</Label>
                      <Select
                        value={profile.gender || ''}
                        onValueChange={v => updateField('gender', v)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="اختر الجنس" />
                        </SelectTrigger>
                        <SelectContent>
                          {GENDER_OPTIONS.map(g => (
                            <SelectItem key={g.value} value={g.value}>
                              {g.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Date of Birth */}
                    <div className="space-y-1.5">
                      <Label htmlFor="dob">تاريخ الميلاد</Label>
                      <div className="relative">
                        <Calendar className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="dob"
                          type="date"
                          value={profile.dateOfBirth || ''}
                          onChange={e => updateField('dateOfBirth', e.target.value)}
                          className="ps-10"
                        />
                      </div>
                    </div>

                    {/* Nationality */}
                    <div className="space-y-1.5">
                      <Label htmlFor="nationality">الجنسية</Label>
                      <div className="relative">
                        <Globe className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="nationality"
                          value={profile.nationality || ''}
                          onChange={e => updateField('nationality', e.target.value)}
                          className="ps-10"
                          placeholder="عراقي"
                        />
                      </div>
                    </div>

                    {/* Military Status */}
                    <div className="space-y-1.5">
                      <Label>الحالة العسكرية</Label>
                      <Select
                        value={profile.militaryStatus || ''}
                        onValueChange={v => updateField('militaryStatus', v)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="اختر الحالة" />
                        </SelectTrigger>
                        <SelectContent>
                          {MILITARY_STATUS_OPTIONS.map(s => (
                            <SelectItem key={s.value} value={s.value}>
                              {s.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Separator className="my-5" />

                  {/* Location & Timezone (professional.basic) */}
                  <div className="space-y-2.5">
                    <Label className="text-sm font-semibold flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-blue-500" /> الموقع والمنطقة الزمنية
                    </Label>
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      <div className="space-y-1.5">
                        <Label>الدولة</Label>
                        <Input
                          value={professional.basic?.country || ''}
                          onChange={e => updateProfessionalBasic('country', e.target.value)}
                          placeholder="العراق"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label>المحافظة</Label>
                        <Select
                          value={professional.basic?.province || ''}
                          onValueChange={v => updateProfessionalBasic('province', v)}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="اختر المحافظة" />
                          </SelectTrigger>
                          <SelectContent>
                            {IRAQI_PROVINCES.map(p => (
                              <SelectItem key={p} value={p}>
                                {p}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label>المدينة</Label>
                        <Input
                          value={professional.basic?.city || ''}
                          onChange={e => updateProfessionalBasic('city', e.target.value)}
                          placeholder="بغداد"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label>المنطقة الزمنية</Label>
                        <Select
                          value={professional.basic?.timezone || 'Asia/Baghdad'}
                          onValueChange={v => updateProfessionalBasic('timezone', v)}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {DEFAULT_TIMEZONES.map(tz => (
                              <SelectItem key={tz} value={tz}>
                                {tz}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </GlassCardContent>
              </GlassCard>
            </TabsContent>

            {/* ═══ Tab 2: Professional Profile ═══ */}
            <TabsContent value="professional">
              <GlassCard variant="flat" size="md">
                <GlassCardHeader>
                  <GlassCardTitle className="flex items-center gap-2 text-base">
                    <Briefcase className="h-5 w-5 text-red-500" />
                    الملف المهني
                  </GlassCardTitle>
                  <GlassCardDescription>
                    معلوماتك المهنية والأكاديمية
                  </GlassCardDescription>
                </GlassCardHeader>
                <GlassCardContent>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    {/* Job Title */}
                    <div className="space-y-1.5">
                      <Label htmlFor="jobTitle">المسمى الوظيفي</Label>
                      <div className="relative">
                        <Briefcase className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="jobTitle"
                          value={profile.jobTitle || ''}
                          onChange={e => updateField('jobTitle', e.target.value)}
                          className="ps-10"
                          placeholder="مثال: محلل اقتصادي أول"
                        />
                      </div>
                    </div>

                    {/* Sector */}
                    <div className="space-y-1.5">
                      <Label>القطاع</Label>
                      <Select
                        value={profile.sector || ''}
                        onValueChange={v => updateField('sector', v)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="اختر القطاع" />
                        </SelectTrigger>
                        <SelectContent>
                          {SECTOR_OPTIONS.map(s => (
                            <SelectItem key={s.value} value={s.value}>
                              {s.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Experience Years */}
                    <div className="space-y-1.5">
                      <Label htmlFor="experience">سنوات الخبرة</Label>
                      <div className="relative">
                        <Star className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="experience"
                          type="number"
                          min="0"
                          max="50"
                          value={profile.experience ?? ''}
                          onChange={e =>
                            updateField(
                              'experience',
                              e.target.value ? Number(e.target.value) : null
                            )
                          }
                          className="ps-10"
                          placeholder="0"
                        />
                      </div>
                    </div>

                    {/* Education Level */}
                    <div className="space-y-1.5">
                      <Label>المستوى التعليمي</Label>
                      <Select
                        value={profile.educationLevel || ''}
                        onValueChange={v => updateField('educationLevel', v)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="اختر المستوى" />
                        </SelectTrigger>
                        <SelectContent>
                          {EDUCATION_LEVELS.map(e => (
                            <SelectItem key={e.value} value={e.value}>
                              {e.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* University */}
                    <div className="space-y-1.5">
                      <Label htmlFor="university">الجامعة</Label>
                      <div className="relative">
                        <GraduationCap className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="university"
                          value={profile.university || ''}
                          onChange={e => updateField('university', e.target.value)}
                          className="ps-10"
                          placeholder="مثال: جامعة بغداد"
                        />
                      </div>
                    </div>

                    {/* GPA */}
                    <div className="space-y-1.5">
                      <Label htmlFor="gpa">المعدل</Label>
                      <Input
                        id="gpa"
                        type="number"
                        min="0"
                        max="100"
                        value={profile.gpa || ''}
                        onChange={e => {
                          const val = e.target.value
                          if (val === '') {
                            updateField('gpa', null)
                          } else {
                            const num = Number(val)
                            if (num >= 0 && num <= 100) {
                              updateField('gpa', String(num))
                            }
                          }
                        }}
                        placeholder="0 - 100"
                      />
                    </div>
                  </div>

                  {/* Bio */}
                  <div className="mt-5 space-y-1.5">
                    <Label htmlFor="bio">نبذة مهنية</Label>
                    <Textarea
                      id="bio"
                      value={profile.bio || ''}
                      onChange={e => {
                        if (e.target.value.length <= MAX_BIO_LENGTH) {
                          updateField('bio', e.target.value)
                        }
                      }}
                      placeholder="اكتب نبذة مختصرة عن خبراتك ومهاراتك وأهدافك المهنية..."
                      rows={5}
                      className="resize-y"
                    />
                    <div className="flex items-center justify-between">
                      <p className="text-2xs text-gray-400">
                        أقصى حد {MAX_BIO_LENGTH} حرف
                      </p>
                      <p
                        className={`text-2xs font-medium ${
                          (profile.bio || '').length > MAX_BIO_LENGTH * 0.9
                            ? 'text-amber-500'
                            : 'text-gray-400'
                        }`}
                      >
                        {(profile.bio || '').length}/{MAX_BIO_LENGTH}
                      </p>
                    </div>
                  </div>

                  <Separator className="my-5" />

                  {/* Open to Work Toggle */}
                  <div className="flex items-center justify-between rounded-xl border border-gray-100 bg-gray-50/50 p-4 dark:border-gray-800 dark:bg-gray-900/30">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-green-100 dark:bg-green-900/30">
                        <Briefcase className="h-4.5 w-4.5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          حالياً أبحث عن عمل
                        </p>
                        <p className="text-xs text-gray-400">
                          سيظهر ملفك في نتائج البحث للشركات
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={profile.openToWork}
                      onCheckedChange={checked => updateField('openToWork', checked)}
                    />
                  </div>

                  {/* Job Types */}
                  <div className="mt-5 space-y-2.5">
                    <Label>أنواع الوظائف المطلوبة</Label>
                    <div className="flex flex-wrap gap-2">
                      {JOB_TYPES.map(jt => {
                        const isActive = profile.jobTypes.includes(jt.value)
                        return (
                          <button
                            key={jt.value}
                            onClick={() => toggleJobType(jt.value)}
                            className={`flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-medium transition-all ${
                              isActive
                                ? 'bg-red-600 text-white shadow-sm shadow-red-200 dark:shadow-red-900/30'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                            }`}
                          >
                            {isActive && <Check className="h-3 w-3" />}
                            {jt.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>
                </GlassCardContent>
              </GlassCard>
            </TabsContent>

            {/* ═══ Tab 3: Skills & Languages ═══ */}
            <TabsContent value="skills">
              <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                {/* Skills */}
                <GlassCard variant="flat" size="md">
                  <GlassCardHeader>
                    <GlassCardTitle className="flex items-center gap-2 text-base">
                      <Star className="h-5 w-5 text-amber-500" />
                      المهارات
                    </GlassCardTitle>
                    <GlassCardDescription>
                      أضف مهاراتك التقنية والشخصية
                    </GlassCardDescription>
                  </GlassCardHeader>
                  <GlassCardContent>
                    <SkillInput
                      skills={profile.skills}
                      onAdd={addSkill}
                      onRemove={removeSkill}
                    />
                  </GlassCardContent>
                </GlassCard>

                {/* Languages */}
                <GlassCard variant="flat" size="md">
                  <GlassCardHeader>
                    <GlassCardTitle className="flex items-center gap-2 text-base">
                      <Languages className="h-5 w-5 text-blue-500" />
                      اللغات
                    </GlassCardTitle>
                    <GlassCardDescription>
                      اللغات التي تتقنها مع مستوى الإتقان
                    </GlassCardDescription>
                  </GlassCardHeader>
                  <GlassCardContent>
                    <LanguageInput
                      languages={profile.languages}
                      onAdd={addLanguage}
                      onRemove={removeLanguage}
                    />
                  </GlassCardContent>
                </GlassCard>
              </div>
            </TabsContent>

            {/* ═══ Tab 4: Expected Salary ═══ */}
            <TabsContent value="salary">
              <GlassCard variant="flat" size="md">
                <GlassCardHeader>
                  <GlassCardTitle className="flex items-center gap-2 text-base">
                    <DollarSign className="h-5 w-5 text-green-500" />
                    الراتب المطلوب
                  </GlassCardTitle>
                  <GlassCardDescription>
                    حدد نطاق الراتب المتوقع (اختياري)
                  </GlassCardDescription>
                </GlassCardHeader>
                <GlassCardContent>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    {/* Min Salary */}
                    <div className="space-y-1.5">
                      <Label htmlFor="salaryMin">الحد الأدنى</Label>
                      <div className="relative">
                        <DollarSign className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="salaryMin"
                          type="number"
                          min="0"
                          value={profile.salaryMin ?? ''}
                          onChange={e =>
                            updateField(
                              'salaryMin',
                              e.target.value ? Number(e.target.value) : null
                            )
                          }
                          className="ps-10"
                          placeholder="500,000"
                        />
                      </div>
                    </div>

                    {/* Max Salary */}
                    <div className="space-y-1.5">
                      <Label htmlFor="salaryMax">الحد الأعلى</Label>
                      <div className="relative">
                        <DollarSign className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                        <Input
                          id="salaryMax"
                          type="number"
                          min="0"
                          value={profile.salaryMax ?? ''}
                          onChange={e =>
                            updateField(
                              'salaryMax',
                              e.target.value ? Number(e.target.value) : null
                            )
                          }
                          className="ps-10"
                          placeholder="2,000,000"
                        />
                      </div>
                    </div>

                    {/* Currency */}
                    <div className="space-y-1.5">
                      <Label>العملة</Label>
                      <Select
                        value={profile.salaryCurrency}
                        onValueChange={v => updateField('salaryCurrency', v)}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="IQD">دينار عراقي (د.ع)</SelectItem>
                          <SelectItem value="USD">دولار أمريكي ($)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </GlassCardContent>
              </GlassCard>
            </TabsContent>

            {/* ═══ Tab 5: Search Preferences (§5) ═══ */}
            <TabsContent value="preferences">
              <GlassCard variant="flat" size="md">
                <GlassCardHeader>
                  <GlassCardTitle className="flex items-center gap-2 text-base">
                    <Settings className="h-5 w-5 text-purple-500" />
                    تفضيلات البحث
                  </GlassCardTitle>
                  <GlassCardDescription>
                    هدفك المهني، أوضاع العمل المتاحة وحالتك الحالية — تُستخدم للمطابقة والفرص
                  </GlassCardDescription>
                </GlassCardHeader>
                <GlassCardContent className="space-y-6">
                  {/* Preferences */}
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="targetRole">الوظيفة المستهدفة</Label>
                      <Input
                        id="targetRole"
                        value={professional.preferences?.targetRole || ''}
                        onChange={e =>
                          updateProfessional({
                            preferences: { ...(professional.preferences || {}), targetRole: e.target.value },
                          })
                        }
                        placeholder="مثال: مدير مشاريع IT"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>الراتب المتوقع (شهري)</Label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          min="0"
                          value={professional.preferences?.expectedSalary ?? ''}
                          onChange={e => setExpectedSalary(e.target.value ? Number(e.target.value) : null)}
                          placeholder="1,000,000"
                        />
                        <Select
                          value={professional.preferences?.salaryCurrency || 'IQD'}
                          onValueChange={v =>
                            updateProfessional({
                              preferences: { ...(professional.preferences || {}), salaryCurrency: v },
                            })
                          }
                        >
                          <SelectTrigger className="w-28 shrink-0">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {SUPPORTED_CURRENCIES.map(c => (
                              <SelectItem key={c} value={c}>
                                {c}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Preferred Sectors */}
                  <div className="space-y-2.5">
                    <Label>القطاعات المفضلة</Label>
                    <div className="flex flex-wrap gap-2">
                      {TAXONOMY_SECTORS.map(s => {
                        const isActive = (professional.preferences?.preferredSectors || []).includes(s.value)
                        return (
                          <button
                            key={s.value}
                            type="button"
                            onClick={() => togglePreferredSector(s.value)}
                            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                              isActive
                                ? 'bg-purple-600 text-white shadow-sm'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                            }`}
                          >
                            {isActive && <Check className="h-3 w-3" />}
                            {s.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Work Mode (§16) */}
                  <div className="space-y-2.5">
                    <Label>وضع العمل المفضل</Label>
                    <div className="flex flex-wrap gap-2">
                      {WORK_MODES.map(mode => {
                        const isActive = professional.workMode === mode.value
                        return (
                          <button
                            key={mode.value}
                            type="button"
                            onClick={() => updateProfessional({ workMode: isActive ? undefined : mode.value })}
                            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                              isActive
                                ? 'bg-emerald-600 text-white shadow-sm'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                            }`}
                          >
                            {isActive && <Check className="h-3 w-3" />}
                            {mode.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Availability */}
                  <div className="space-y-2.5">
                    <Label>حالة التوفر</Label>
                    <div className="flex flex-wrap gap-2">
                      {AVAILABILITY_OPTIONS.map(opt => {
                        const isActive = professional.availability === opt.value
                        return (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => updateProfessional({ availability: isActive ? undefined : opt.value })}
                            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                              isActive
                                ? 'bg-blue-600 text-white shadow-sm'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                            }`}
                          >
                            {isActive && <Check className="h-3 w-3" />}
                            {opt.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Search Status */}
                  <div className="space-y-2.5">
                    <Label>حالة البحث عن عمل</Label>
                    <div className="flex flex-wrap gap-2">
                      {SEARCH_STATUS_OPTIONS.map(opt => {
                        const isActive = professional.searchStatus === opt.value
                        return (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => updateProfessional({ searchStatus: isActive ? undefined : opt.value })}
                            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                              isActive
                                ? 'bg-red-600 text-white shadow-sm'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700'
                            }`}
                          >
                            {isActive && <Check className="h-3 w-3" />}
                            {opt.label}
                          </button>
                        )
                      })}
                    </div>
                  </div>
                </GlassCardContent>
              </GlassCard>
            </TabsContent>
          </Tabs>
        </div>

        {/* ─── CV Bank Score Sidebar (1/4) ─── */}
        <div className="space-y-6 lg:col-span-1">
          {/* Score Card */}
          <GlassCard variant="default" size="md" className="lg:sticky lg:top-24">
            <GlassCardHeader>
              <GlassCardTitle className="flex items-center gap-2 text-sm">
                <Target className="h-4 w-4 text-amber-500" />
                نسبة اكتمال الملف
              </GlassCardTitle>
              <GlassCardDescription className="text-2xs">
                {completion.message}
              </GlassCardDescription>
            </GlassCardHeader>
            <GlassCardContent>
              {/* Circular Score */}
              <div className="mb-4 flex justify-center">
                <CircularScore score={completion.percent} />
              </div>

              {/* Status Text */}
              <p className="mb-4 text-center text-xs font-medium text-gray-600 dark:text-gray-400">
                {completion.percent >= 70
                  ? 'ملف ممتاز! فرصك عالية في الظهور'
                  : completion.percent >= 40
                    ? 'ملف جيد، يمكنك التحسين أكثر'
                    : 'أكمل ملفك لتحسين فرصك'}
              </p>

              <Separator className="my-3" />

              {/* Completion Categories (§6) */}
              <div className="space-y-2">
                {completion.categories.map(cat => {
                  const done = cat.score >= cat.max
                  return (
                    <div
                      key={cat.key}
                      className="flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
                            done
                              ? 'bg-green-100 dark:bg-green-900/40'
                              : 'bg-gray-100 dark:bg-gray-800'
                          }`}
                        >
                          {done ? (
                            <Check className="h-3 w-3 text-green-600 dark:text-green-400" />
                          ) : (
                            <span className="h-1.5 w-1.5 rounded-full bg-gray-300 dark:bg-gray-600" />
                          )}
                        </div>
                        <span
                          className={
                            done
                              ? 'text-gray-400 dark:text-gray-500'
                              : 'text-gray-700 dark:text-gray-300'
                          }
                        >
                          {cat.label}
                        </span>
                      </div>
                      <span
                        className={`text-2xs font-bold ${
                          done
                            ? 'text-green-600 dark:text-green-400'
                            : 'text-gray-300 dark:text-gray-600'
                        }`}
                      >
                        {cat.score}/{cat.max}
                      </span>
                    </div>
                  )
                })}
              </div>

              <Separator className="my-3" />

              {/* CV Bank Toggle */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-gray-700 dark:text-gray-300">
                    إظهار في بنك السير
                  </p>
                  <p className="text-2xs text-gray-400">
                    الشركات تستطيع البحث عنك
                  </p>
                </div>
                <Switch
                  checked={profile.cvVisibleInBank}
                  onCheckedChange={checked =>
                    updateField('cvVisibleInBank', checked)
                  }
                />
              </div>
            </GlassCardContent>
          </GlassCard>

          {/* Tips Card */}
          <GlassCard variant="flat" size="md">
            <GlassCardHeader>
              <GlassCardTitle className="flex items-center gap-2 text-sm">
                <Lightbulb className="h-4 w-4 text-amber-500" />
                نصيحة
              </GlassCardTitle>
            </GlassCardHeader>
            <GlassCardContent>
              <p className="text-xs leading-relaxed text-gray-600 dark:text-gray-400">
                لتحسين ظهورك في بنك السير الذاتية، أكمل جميع الحقول.
                الملفات المكتملة تظهر أولاً في نتائج البحث وتحصل على
                فرص أكبر للتوظيف.
              </p>
            </GlassCardContent>
          </GlassCard>
        </div>
      </div>

      {/* ─── Bottom Save Button ─── */}
      <div className="flex justify-end pb-4">
        <Button
          onClick={handleSave}
          disabled={saving}
          size="lg"
          className="rounded-full bg-red-600 px-8 hover:bg-red-700"
        >
          {saving ? (
            <Loader2 className="ms-1.5 h-5 w-5 animate-spin" />
          ) : (
            <Save className="ms-1.5 h-5 w-5" />
          )}
          {saving ? 'جارٍ الحفظ...' : 'حفظ جميع التغييرات'}
        </Button>
      </div>
    </div>
  )
}