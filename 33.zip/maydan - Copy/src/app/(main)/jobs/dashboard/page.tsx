'use client'

import { useState, useEffect } from 'react'
import CompanyDashboard from '@/components/jobs/CompanyDashboard'

export default function CompanyDashboardPage() {
  const [companyId, setCompanyId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/auth/me')
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data?.user?.id) {
          setCompanyId(data.user.id)
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500" />
      </div>
    )
  }

  if (!companyId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-8 text-center">
        <p className="text-lg text-gray-500">يجب تسجيل الدخول كحساب شركة للوصول إلى لوحة التحكم</p>
      </div>
    )
  }

  return <CompanyDashboard companyId={companyId} />
}