'use client'

import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'
import {
  Briefcase, FileText, CalendarCheck, FileStack, ShieldCheck, Award,
} from 'lucide-react'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Skeleton } from '@/components/ui/skeleton'
import JobsPage from '@/components/jobs/JobsPage'
import AppliedJobsView from '@/components/jobs/AppliedJobsView'
import InterviewsView from '@/components/jobs/InterviewsView'
import ProfessionalPassportView from '@/components/jobs/ProfessionalPassportView'
import Reputation from '@/components/Reputation'

const CVBuilder = dynamic(() => import('@/components/CVBuilder'), {
  ssr: false,
  loading: () => <Skeleton className="h-[60vh] w-full" />,
})

const VALID_TABS = ['jobs', 'applications', 'interviews', 'cv', 'passport', 'reputation'] as const

export default function JobsHubPage() {
  const [tab, setTab] = useState<string | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined') return
    const p = new URLSearchParams(window.location.search).get('tab')
    setTab(p && (VALID_TABS as readonly string[]).includes(p) ? p : 'jobs')
  }, [])

  const active = tab || 'jobs'

  return (
    <div className="space-y-5">
      <Tabs value={active} onValueChange={setTab} className="w-full">
        <TabsList className="h-auto min-h-10 w-full flex-wrap justify-start gap-1 p-1.5">
          <TabsTrigger value="jobs" className="gap-2">
            <Briefcase className="size-4" />
            الوظائف
          </TabsTrigger>
          <TabsTrigger value="applications" className="gap-2">
            <FileText className="size-4" />
            طلباتي
          </TabsTrigger>
          <TabsTrigger value="interviews" className="gap-2">
            <CalendarCheck className="size-4" />
            المقابلات
          </TabsTrigger>
          <TabsTrigger value="cv" className="gap-2">
            <FileStack className="size-4" />
            السيرة الذاتية
          </TabsTrigger>
          <TabsTrigger value="passport" className="gap-2">
            <ShieldCheck className="size-4" />
            الجواز المهني
          </TabsTrigger>
          <TabsTrigger value="reputation" className="gap-2">
            <Award className="size-4" />
            السمعة المهنية
          </TabsTrigger>
        </TabsList>

        <TabsContent value="jobs" className="mt-4">
          <JobsPage />
        </TabsContent>
        <TabsContent value="applications" className="mt-4">
          <AppliedJobsView />
        </TabsContent>
        <TabsContent value="interviews" className="mt-4">
          <InterviewsView />
        </TabsContent>
        <TabsContent value="cv" className="mt-4">
          <CVBuilder />
        </TabsContent>
        <TabsContent value="passport" className="mt-4">
          <ProfessionalPassportView />
        </TabsContent>
        <TabsContent value="reputation" className="mt-4">
          <Reputation />
        </TabsContent>
      </Tabs>
    </div>
  )
}