import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'وظائف العراق | ميدان',
  description: 'ابحث عن أفضل الوظائف في العراق. فرص عمل في القطاعين العام والخاص من شركات ومؤسسات عراقية.',
  openGraph: {
    title: 'وظائف العراق | ميدان',
    description: 'ابحث عن أفضل الوظائف في العراق. فرص عمل في القطاعين العام والخاص من شركات ومؤسسات عراقية.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/jobs`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'وظائف العراق | ميدان',
    description: 'ابحث عن أفضل الوظائف في العراق. فرص عمل في القطاعين العام والخاص من شركات ومؤسسات عراقية.',
  },
  alternates: {
    canonical: `${SITE_URL}/jobs`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
