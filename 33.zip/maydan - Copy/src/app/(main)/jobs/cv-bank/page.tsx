'use client'

import CvBankPage from '@/components/jobs/CvBankPage'
import { RoleGate } from '@/components/RoleGate'

export default function CvBankPageWrapper() {
  return (
    <RoleGate>
      <CvBankPage />
    </RoleGate>
  )
}