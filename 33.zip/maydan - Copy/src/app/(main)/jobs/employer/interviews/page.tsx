'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react'
import {
  CalendarDays,
  Video,
  Phone,
  MapPin,
  Clock,
  CheckCircle2,
  XCircle,
  MoreVertical,
  MessageSquare,
  Calendar,
  ChevronLeft,
  ChevronRight,
  StickyNote,
  Filter,
  CalendarRange,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

// ===== Types =====

type InterviewType = 'VIDEO' | 'PHONE' | 'ONSITE'
type InterviewStatus = 'SCHEDULED' | 'COMPLETED' | 'CANCELLED'

interface Interview {
  id: string
  candidateName: string
  candidateAvatar: string | null
  jobTitle: string
  jobId: string
  type: InterviewType
  status: InterviewStatus
  scheduledAt: string
  duration?: number
  notes?: string
  location?: string
  link?: string
}

// ===== Constants =====

const TYPE_CONFIG: Record<InterviewType, { label: string; icon: React.ElementType; color: string }> = {
  VIDEO: { label: 'فيديو', icon: Video, color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400' },
  PHONE: { label: 'هاتف', icon: Phone, color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  ONSITE: { label: 'حضور', icon: MapPin, color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
}

const STATUS_CONFIG: Record<InterviewStatus, { label: string; variant: 'default' | 'success' | 'destructive' | 'secondary' }> = {
  SCHEDULED: { label: 'مجدول', variant: 'secondary' },
  COMPLETED: { label: 'مكتمل', variant: 'success' },
  CANCELLED: { label: 'ملغى', variant: 'destructive' },
}

type FilterTab = 'upcoming' | 'past' | 'all'

// ===== Helpers =====

function formatDateTime(dateStr: string) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('ar-IQ', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function formatTime(dateStr: string) {
  return new Date(dateStr).toLocaleTimeString('ar-IQ', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

// ===== Skeleton =====

function InterviewsSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex gap-3">
        {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-9 w-28 rounded-lg" />)}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {[...Array(6)].map((_, i) => (
          <Skeleton key={i} className="h-40 rounded-2xl" />
        ))}
      </div>
    </div>
  )
}

// ===== Calendar Grid Component =====

function CalendarGrid({ interviews, onDateClick }: { interviews: Interview[]; onDateClick: (date: Date) => void }) {
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const today = new Date()

  const year = currentMonth.getFullYear()
  const month = currentMonth.getMonth()
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  const startPadding = (firstDay.getDay() + 6) % 7 // RTL: Saturday = 0

  const interviewDates = useMemo(() => {
    const map = new Map<string, number>()
    interviews.forEach((i) => {
      if (i.status !== 'CANCELLED') {
        const d = new Date(i.scheduledAt).toDateString()
        map.set(d, (map.get(d) || 0) + 1)
      }
    })
    return map
  }, [interviews])

  const days: (Date | null)[] = []
  for (let i = 0; i < startPadding; i++) days.push(null)
  for (let d = 1; d <= lastDay.getDate(); d++) days.push(new Date(year, month, d))

  const monthName = currentMonth.toLocaleDateString('ar-IQ', { year: 'numeric', month: 'long' })

  const prevMonth = () => setCurrentMonth(new Date(year, month - 1, 1))
  const nextMonth = () => setCurrentMonth(new Date(year, month + 1, 1))

  const weekDays = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة']

  return (
    <GlassCard variant="flat">
      <GlassCardHeader>
        <div className="flex items-center justify-between w-full">
          <button onClick={prevMonth} className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors">
            <ChevronRight className="size-4" />
          </button>
          <h3 className="text-sm font-semibold">{monthName}</h3>
          <button onClick={nextMonth} className="p-1.5 rounded-lg hover:bg-accent/50 transition-colors">
            <ChevronLeft className="size-4" />
          </button>
        </div>
      </GlassCardHeader>
      <GlassCardContent size="sm">
        <div className="grid grid-cols-7 gap-1">
          {weekDays.map((d) => (
            <div key={d} className="text-center text-2xs font-medium text-muted-foreground py-1">
              {d}
            </div>
          ))}
          {days.map((day, i) => {
            if (!day) return <div key={`empty-${i}`} />
            const dateStr = day.toDateString()
            const count = interviewDates.get(dateStr) || 0
            const isToday = day.toDateString() === today.toDateString()
            return (
              <button
                key={dateStr}
                onClick={() => count > 0 && onDateClick(day)}
                className={cn(
                  'relative flex flex-col items-center justify-center h-9 rounded-lg text-xs transition-colors',
                  isToday && 'bg-red-500/10 text-red-600 dark:text-red-400 font-bold',
                  count > 0 && !isToday && 'bg-accent/50 hover:bg-accent font-medium cursor-pointer',
                  count === 0 && 'text-muted-foreground'
                )}
              >
                <span>{day.getDate()}</span>
                {count > 0 && (
                  <span className="absolute bottom-0.5 size-1.5 rounded-full bg-red-500" />
                )}
              </button>
            )
          })}
        </div>
      </GlassCardContent>
    </GlassCard>
  )
}

// ===== Interview Card =====

function InterviewCard({
  interview,
  onReschedule,
  onCancel,
  onComplete,
  onAddNotes,
}: {
  interview: Interview
  onReschedule: (i: Interview) => void
  onCancel: (i: Interview) => void
  onComplete: (i: Interview) => void
  onAddNotes: (i: Interview) => void
}) {
  const typeConfig = TYPE_CONFIG[interview.type]
  const statusConfig = STATUS_CONFIG[interview.status]
  const TypeIcon = typeConfig.icon
  const isPast = new Date(interview.scheduledAt) < new Date()

  return (
    <GlassCard variant="flat" size="sm" className={cn(
      interview.status === 'CANCELLED' && 'opacity-60'
    )}>
      <div className="flex items-start gap-3">
        <div className={cn('flex size-9 items-center justify-center rounded-lg shrink-0', typeConfig.color)}>
          <TypeIcon className="size-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-sm font-medium truncate">{interview.candidateName}</p>
              <p className="text-xs text-muted-foreground truncate mt-0.5">
                {interview.jobTitle}
              </p>
            </div>
            <Badge variant={statusConfig.variant} size="xs" className="shrink-0">
              {statusConfig.label}
            </Badge>
          </div>

          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <CalendarDays className="size-3" />
              {formatDateTime(interview.scheduledAt)}
            </span>
            {interview.duration && (
              <span className="flex items-center gap-1">
                <Clock className="size-3" />
                {interview.duration} دقيقة
              </span>
            )}
          </div>

          {interview.type === 'ONSITE' && interview.location && (
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <MapPin className="size-3" />
              {interview.location}
            </p>
          )}

          {interview.type === 'VIDEO' && interview.link && (
            <a
              href={interview.link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-blue-500 hover:underline mt-1 flex items-center gap-1"
            >
              <Video className="size-3" />
              رابط المقابلة
            </a>
          )}
        </div>
      </div>

      {/* Actions */}
      {interview.status === 'SCHEDULED' && (
        <div className="flex items-center justify-end gap-1 mt-3 pt-2 border-t border-border/30">
          <Button variant="ghost" size="sm" className="gap-1 text-xs h-7" onClick={() => onAddNotes(interview)}>
            <StickyNote className="size-3" />
            ملاحظات
          </Button>
          {isPast && (
            <Button
              variant="ghost"
              size="sm"
              className="gap-1 text-xs h-7 text-green-600"
              onClick={() => onComplete(interview)}
            >
              <CheckCircle2 className="size-3" />
              مكتمل
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="size-7">
                <MoreVertical className="size-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onReschedule(interview)} className="gap-2 text-xs">
                <CalendarDays className="size-3.5" />
                إعادة جدولة
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => onComplete(interview)}
                className="gap-2 text-xs text-green-600"
              >
                <CheckCircle2 className="size-3.5" />
                تحديد كمكتمل
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => onCancel(interview)}
                className="gap-2 text-xs text-destructive"
              >
                <XCircle className="size-3.5" />
                إلغاء
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}
    </GlassCard>
  )
}

// ===== Main Component =====

export default function InterviewsPage() {
  const { toast } = useToast()

  const [interviews, setInterviews] = useState<Interview[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<FilterTab>('upcoming')
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [jobFilter, setJobFilter] = useState<string>('all')

  // Reschedule Dialog
  const [rescheduleOpen, setRescheduleOpen] = useState(false)
  const [rescheduleInterview, setRescheduleInterview] = useState<Interview | null>(null)
  const [newDateTime, setNewDateTime] = useState('')
  const [rescheduling, setRescheduling] = useState(false)

  // Notes Dialog
  const [notesOpen, setNotesOpen] = useState(false)
  const [notesInterview, setNotesInterview] = useState<Interview | null>(null)
  const [notesText, setNotesText] = useState('')
  const [savingNotes, setSavingNotes] = useState(false)

  // Unique jobs for filter
  const uniqueJobs = useMemo(() => {
    const map = new Map<string, string>()
    interviews.forEach((i) => map.set(i.jobId, i.jobTitle))
    return Array.from(map.entries())
  }, [interviews])

  const fetchInterviews = useCallback(async () => {
    try {
      setLoading(true)
      // Fetch from jobs and applications to build interview data
      const res = await fetch('/api/jobs')
      if (!res.ok) throw new Error()
      const data = await res.json()
      const jobs = Array.isArray(data?.jobs) ? data.jobs : []

      const allInterviews: Interview[] = []
      for (const job of jobs) {
        try {
          const appRes = await fetch(`/api/jobs/${job.id}/applications`)
          if (appRes.ok) {
            const appData = await appRes.json()
            const apps = Array.isArray(appData?.applications) ? appData.applications : []
            const interviewApps = apps.filter(
              (a: { stage: string }) =>
                a.stage === 'INTERVIEW_INVITED' ||
                a.stage === 'FIRST_INTERVIEW' ||
                a.stage === 'SECOND_INTERVIEW'
            )
            for (const app of interviewApps) {
              allInterviews.push({
                id: app.id,
                candidateName: app.applicant?.name || 'مستخدم',
                candidateAvatar: app.applicant?.avatar || null,
                jobTitle: job.title,
                jobId: job.id,
                type: 'VIDEO' as InterviewType,
                status: 'SCHEDULED' as InterviewStatus,
                scheduledAt: app.updatedAt || app.createdAt,
                notes: app.notes || null,
              })
            }
          }
        } catch {
          // skip
        }
      }

      // Add some mock data if no interviews found (for demo purposes)
      // ✅ FIX: Removed mock demo data — now shows empty state instead
      // if (allInterviews.length === 0) { ... } removed

      setInterviews(allInterviews)
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحميل المقابلات', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    fetchInterviews()
  }, [fetchInterviews])

  // Filtered interviews
  const filteredInterviews = useMemo(() => {
    const now = new Date()
    let result = interviews

    if (activeTab === 'upcoming') {
      result = result.filter((i) => new Date(i.scheduledAt) >= now && i.status !== 'CANCELLED')
    } else if (activeTab === 'past') {
      result = result.filter((i) => new Date(i.scheduledAt) < now || i.status === 'COMPLETED')
    }

    if (selectedDate) {
      result = result.filter(
        (i) => new Date(i.scheduledAt).toDateString() === selectedDate.toDateString()
      )
    }

    if (jobFilter !== 'all') {
      result = result.filter((i) => i.jobId === jobFilter)
    }

    result.sort((a, b) => new Date(b.scheduledAt).getTime() - new Date(a.scheduledAt).getTime())

    return result
  }, [interviews, activeTab, selectedDate, jobFilter])

  // Handlers — ✅ Now using real /api/interviews API calls instead of setTimeout
  const handleComplete = async (interview: Interview) => {
    try {
      const res = await fetch(`/api/interviews/${interview.id}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      })
      if (!res.ok) throw new Error('فشل الإكمال')
      setInterviews((prev) =>
        prev.map((i) => (i.id === interview.id ? { ...i, status: 'COMPLETED' as InterviewStatus } : i))
      )
      toast({ title: 'تم التحديث', description: 'تم تحديد المقابلة كمكتملة' })
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحديث المقابلة', variant: 'destructive' })
    }
  }

  const handleCancel = async (interview: Interview) => {
    try {
      const res = await fetch(`/api/interviews/${interview.id}?reason=cancelled_by_employer`, {
        method: 'DELETE',
      })
      if (!res.ok) throw new Error('فشل الإلغاء')
      setInterviews((prev) =>
        prev.map((i) => (i.id === interview.id ? { ...i, status: 'CANCELLED' as InterviewStatus } : i))
      )
      toast({ title: 'تم الإلغاء', description: 'تم إلغاء المقابلة' })
    } catch {
      toast({ title: 'خطأ', description: 'فشل في إلغاء المقابلة', variant: 'destructive' })
    }
  }

  const handleReschedule = (interview: Interview) => {
    setRescheduleInterview(interview)
    setNewDateTime(interview.scheduledAt.slice(0, 16))
    setRescheduleOpen(true)
  }

  const handleSaveReschedule = async () => {
    if (!rescheduleInterview || !newDateTime) return
    setRescheduling(true)
    try {
      // ✅ FIX: Real API call instead of setTimeout
      const res = await fetch(`/api/interviews/${rescheduleInterview.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scheduledAt: new Date(newDateTime).toISOString(),
        }),
      })
      if (!res.ok) throw new Error('فشل إعادة الجدولة')
      setInterviews((prev) =>
        prev.map((i) =>
          i.id === rescheduleInterview.id
            ? { ...i, scheduledAt: new Date(newDateTime).toISOString() }
            : i
        )
      )
      toast({ title: 'تم التحديث', description: 'تم إعادة جدولة المقابلة' })
      setRescheduleOpen(false)
    } catch {
      toast({ title: 'خطأ', description: 'فشل في إعادة الجدولة', variant: 'destructive' })
    } finally {
      setRescheduling(false)
    }
  }

  const handleAddNotes = (interview: Interview) => {
    setNotesInterview(interview)
    setNotesText(interview.notes || '')
    setNotesOpen(true)
  }

  const handleSaveNotes = async () => {
    if (!notesInterview) return
    setSavingNotes(true)
    try {
      // ✅ FIX: Real API call instead of setTimeout
      const res = await fetch(`/api/interviews/${notesInterview.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          notes: notesText,
        }),
      })
      if (!res.ok) throw new Error('فشل الحفظ')
      setInterviews((prev) =>
        prev.map((i) =>
          i.id === notesInterview!.id ? { ...i, notes: notesText } : i
        )
      )
      toast({ title: 'تم الحفظ', description: 'تم حفظ الملاحظات' })
      setNotesOpen(false)
    } catch {
      toast({ title: 'خطأ', description: 'فشل في حفظ الملاحظات', variant: 'destructive' })
    } finally {
      setSavingNotes(false)
    }
  }

  if (loading) return <InterviewsSkeleton />

  return (
    <div className="space-y-5">
      {/* Tabs */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-2">
          {([
            { key: 'upcoming' as FilterTab, label: 'القادمة' },
            { key: 'past' as FilterTab, label: 'السابقة' },
            { key: 'all' as FilterTab, label: 'الكل' },
          ]).map((tab) => (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key)
                setSelectedDate(null)
              }}
              className={cn(
                'rounded-lg px-4 py-2 text-sm font-medium transition-all',
                activeTab === tab.key
                  ? 'bg-red-500/10 text-red-600 dark:bg-red-500/20 dark:text-red-400'
                  : 'bg-accent/30 text-muted-foreground hover:bg-accent/50'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {uniqueJobs.length > 1 && (
          <Select value={jobFilter} onValueChange={setJobFilter}>
            <SelectTrigger className="w-full sm:w-44">
              <Filter className="size-4 ms-2 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الوظائف</SelectItem>
              {uniqueJobs.map(([id, title]) => (
                <SelectItem key={id} value={id}>{title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {selectedDate && (
          <Button
            variant="ghost"
            size="sm"
            className="gap-1.5 text-xs"
            onClick={() => setSelectedDate(null)}
          >
            <X className="size-3" />
            إزالة تصفية التاريخ
          </Button>
        )}
      </div>

      {/* Calendar */}
      <CalendarGrid
        interviews={interviews}
        onDateClick={(date) => setSelectedDate(date)}
      />

      {/* Selected Date Label */}
      {selectedDate && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <CalendarRange className="size-4" />
          <span>
            مقابلات يوم{' '}
            <strong className="text-foreground">
              {selectedDate.toLocaleDateString('ar-IQ', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </strong>
          </span>
        </div>
      )}

      {/* Interview Cards */}
      {filteredInterviews.length === 0 ? (
        <GlassCard variant="flat" size="lg" className="text-center">
          <CalendarDays className="size-12 text-muted-foreground/20 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">لا توجد مقابلات</p>
          <p className="text-xs text-muted-foreground mt-1">ستظهر المقابلات هنا عندما يتم دعوة المتقدمين</p>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredInterviews.map((interview) => (
            <InterviewCard
              key={interview.id}
              interview={interview}
              onReschedule={handleReschedule}
              onCancel={handleCancel}
              onComplete={handleComplete}
              onAddNotes={handleAddNotes}
            />
          ))}
        </div>
      )}

      {/* Reschedule Dialog */}
      <Dialog open={rescheduleOpen} onOpenChange={setRescheduleOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarDays className="size-5 text-red-500" />
              إعادة جدولة المقابلة
            </DialogTitle>
            <DialogDescription>
              مقابلة {rescheduleInterview?.candidateName} - {rescheduleInterview?.jobTitle}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Label htmlFor="datetime">التاريخ والوقت الجديد</Label>
            <Input
              id="datetime"
              type="datetime-local"
              value={newDateTime}
              onChange={(e) => setNewDateTime(e.target.value)}
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setRescheduleOpen(false)} disabled={rescheduling}>
              إلغاء
            </Button>
            <Button onClick={handleSaveReschedule} disabled={rescheduling || !newDateTime}>
              {rescheduling ? 'جاري التحديث...' : 'حفظ'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Notes Dialog */}
      <Dialog open={notesOpen} onOpenChange={setNotesOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <StickyNote className="size-5 text-red-500" />
              ملاحظات المقابلة
            </DialogTitle>
            <DialogDescription>
              {notesInterview?.candidateName} - {notesInterview?.jobTitle}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Label htmlFor="interview-notes">الملاحظات</Label>
            <Textarea
              id="interview-notes"
              placeholder="أضف ملاحظاتك عن المقابلة..."
              value={notesText}
              onChange={(e) => setNotesText(e.target.value)}
              rows={5}
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setNotesOpen(false)} disabled={savingNotes}>
              إلغاء
            </Button>
            <Button onClick={handleSaveNotes} disabled={savingNotes}>
              {savingNotes ? 'جاري الحفظ...' : 'حفظ الملاحظات'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}