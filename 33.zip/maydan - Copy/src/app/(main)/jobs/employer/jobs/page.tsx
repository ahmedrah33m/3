'use client'

import React, { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  Search,
  Plus,
  Eye,
  Pencil,
  Archive,
  Trash2,
  Briefcase,
  Users,
  Eye as EyeIcon,
  Clock,
  MoreVertical,
  AlertTriangle,
  Inbox,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

// ===== Types =====

interface Job {
  id: string
  title: string
  company: string
  type: string
  location: string | null
  category: string | null
  status: string
  isPaid: boolean
  isExpired: boolean
  createdAt: string
  expiresAt: string
  views: number
  _count?: { applications: number }
}

type JobStatus = 'ACTIVE' | 'DRAFT' | 'PENDING_REVIEW' | 'EXPIRED' | 'ARCHIVED'

// ===== Constants =====

const statusTabs: { key: JobStatus; label: string }[] = [
  { key: 'ACTIVE', label: 'النشطة' },
  { key: 'DRAFT', label: 'المسودات' },
  { key: 'PENDING_REVIEW', label: 'بانتظار المراجعة' },
  { key: 'EXPIRED', label: 'المنتهية' },
  { key: 'ARCHIVED', label: 'المؤرشفة' },
]

const typeLabels: Record<string, { label: string; color: string }> = {
  'full-time': { label: 'دوام كامل', color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400' },
  'part-time': { label: 'دوام جزئي', color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400' },
  contract: { label: 'عقد', color: 'bg-purple-500/10 text-purple-600 dark:text-purple-400' },
  remote: { label: 'عن بُعد', color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' },
  internship: { label: 'تدريب', color: 'bg-pink-500/10 text-pink-600 dark:text-pink-400' },
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('ar-IQ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

function getJobStatus(job: Job): JobStatus {
  if (job.status === 'ARCHIVED') return 'ARCHIVED'
  if (job.status === 'DRAFT') return 'DRAFT'
  if (job.status === 'PENDING_REVIEW') return 'PENDING_REVIEW'
  if (job.isExpired || new Date(job.expiresAt) < new Date()) return 'EXPIRED'
  return 'ACTIVE'
}

// ===== Skeleton =====

function JobsSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex gap-3">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-9 w-24 rounded-lg" />
        ))}
      </div>
      <Skeleton className="h-10 w-full max-w-sm rounded-lg" />
      <div className="space-y-3">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-20 w-full rounded-xl" />
        ))}
      </div>
    </div>
  )
}

// ===== Main Component =====

export default function JobManagementPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<JobStatus>('ACTIVE')
  const [searchQuery, setSearchQuery] = useState('')
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [jobToDelete, setJobToDelete] = useState<Job | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [archiving, setArchiving] = useState<string | null>(null)

  const fetchJobs = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/jobs')
      if (!res.ok) throw new Error('فشل تحميل الوظائف')
      const data = await res.json()
      const allJobs = Array.isArray(data?.jobs) ? data.jobs : []
      setJobs(allJobs)
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحميل الوظائف', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    fetchJobs()
  }, [fetchJobs])

  const filteredJobs = jobs
    .filter((j) => getJobStatus(j) === activeTab)
    .filter((j) => !searchQuery || j.title.includes(searchQuery) || (j.company && j.company.includes(searchQuery)))

  const tabCounts = statusTabs.reduce<Record<JobStatus, number>>((acc, tab) => {
    acc[tab.key] = jobs.filter((j) => getJobStatus(j) === tab.key).length
    return acc
  }, {} as Record<JobStatus, number>)

  const handleArchive = async (jobId: string) => {
    setArchiving(jobId)
    try {
      const res = await fetch(`/api/jobs/${jobId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'ARCHIVED' }),
      })
      if (res.ok) {
        toast({ title: 'تمت الأرشفة', description: 'تم أرشفة الوظيفة بنجاح' })
        fetchJobs()
      } else {
        throw new Error()
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في أرشفة الوظيفة', variant: 'destructive' })
    } finally {
      setArchiving(null)
    }
  }

  const handleDelete = async () => {
    if (!jobToDelete) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/jobs/${jobToDelete.id}`, { method: 'DELETE' })
      if (res.ok) {
        toast({ title: 'تم الحذف', description: 'تم حذف الوظيفة بنجاح' })
        setDeleteDialogOpen(false)
        setJobToDelete(null)
        fetchJobs()
      } else {
        throw new Error()
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في حذف الوظيفة', variant: 'destructive' })
    } finally {
      setDeleting(false)
    }
  }

  if (loading) return <JobsSkeleton />

  return (
    <div className="space-y-5">
      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {statusTabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium whitespace-nowrap transition-all duration-200 shrink-0',
              activeTab === tab.key
                ? 'bg-red-500/10 text-red-600 dark:bg-red-500/20 dark:text-red-400 shadow-sm'
                : 'bg-accent/30 text-muted-foreground hover:bg-accent/50 hover:text-foreground'
            )}
          >
            <span>{tab.label}</span>
            <Badge
              variant={activeTab === tab.key ? 'default' : 'secondary'}
              size="xs"
              className={cn(
                activeTab === tab.key && 'bg-red-500/80 text-white'
              )}
            >
              {tabCounts[tab.key] || 0}
            </Badge>
          </button>
        ))}
      </div>

      {/* Search + Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="relative flex-1 w-full sm:max-w-sm">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="ابحث عن وظيفة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="ps-9"
          />
        </div>
        <Button asChild className="gap-2 bg-gradient-to-l from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 shadow-lg shadow-red-500/20 shrink-0">
          <Link href="/jobs/new">
            <Plus className="size-4" />
            نشر وظيفة جديدة
          </Link>
        </Button>
      </div>

      {/* Jobs List */}
      {filteredJobs.length === 0 ? (
        <GlassCard variant="flat" size="lg" className="text-center">
          <Inbox className="size-12 text-muted-foreground/20 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">
            {searchQuery ? 'لا توجد نتائج' : `لا توجد وظائف ${statusTabs.find((t) => t.key === activeTab)?.label}`}
          </p>
          {!searchQuery && activeTab === 'ACTIVE' && (
            <Button asChild size="sm" className="mt-3 gap-2">
              <Link href="/jobs/new">
                <Plus className="size-3.5" />
                نشر وظيفة
              </Link>
            </Button>
          )}
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {filteredJobs.map((job) => {
            const typeInfo = typeLabels[job.type] || { label: job.type, color: 'bg-gray-500/10 text-gray-600' }
            const daysLeft = Math.ceil(
              (new Date(job.expiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
            )
            return (
              <GlassCard key={job.id} variant="flat" size="sm">
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  {/* Main Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Link
                        href={`/jobs/${job.id}`}
                        className="font-medium hover:text-red-500 transition-colors truncate"
                      >
                        {job.title}
                      </Link>
                      <span className={cn('text-2xs px-2 py-0.5 rounded-full font-medium', typeInfo.color)}>
                        {typeInfo.label}
                      </span>
                      {job.category && (
                        <Badge variant="outline" size="xs">{job.category}</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 mt-1.5 text-xs text-muted-foreground flex-wrap">
                      {job.location && (
                        <span className="flex items-center gap-1">
                          <Briefcase className="size-3" />
                          {job.location}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Users className="size-3" />
                        {job._count?.applications || 0} متقدم
                      </span>
                      <span className="flex items-center gap-1">
                        <EyeIcon className="size-3" />
                        {job.views || 0} مشاهدة
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="size-3" />
                        {formatDate(job.createdAt)}
                      </span>
                      {activeTab === 'ACTIVE' && (
                        <span className={cn(
                          'flex items-center gap-1',
                          daysLeft <= 7 ? 'text-red-500 font-medium' : ''
                        )}>
                          <AlertTriangle className={cn('size-3', daysLeft > 7 && 'hidden')} />
                          {daysLeft > 0 ? `${daysLeft} يوم متبقي` : 'منتهية'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <Button asChild variant="ghost" size="icon" className="size-8">
                      <Link href={`/jobs/${job.id}`}>
                        <Eye className="size-4" />
                      </Link>
                    </Button>
                    {activeTab !== 'ARCHIVED' && (
                      <Button asChild variant="ghost" size="icon" className="size-8">
                        <Link href={`/jobs/new?id=${job.id}`}>
                          <Pencil className="size-4" />
                        </Link>
                      </Button>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="size-8">
                          <MoreVertical className="size-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link href={`/jobs/${job.id}`} className="gap-2">
                            <Eye className="size-4" /> عرض التفاصيل
                          </Link>
                        </DropdownMenuItem>
                        {activeTab !== 'ARCHIVED' && (
                          <DropdownMenuItem asChild>
                            <Link href={`/jobs/new?id=${job.id}`} className="gap-2">
                              <Pencil className="size-4" /> تعديل
                            </Link>
                          </DropdownMenuItem>
                        )}
                        {activeTab !== 'ARCHIVED' && activeTab !== 'DRAFT' && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => handleArchive(job.id)}
                              disabled={archiving === job.id}
                              className="gap-2 text-amber-600"
                            >
                              <Archive className="size-4" />
                              {archiving === job.id ? 'جاري الأرشفة...' : 'أرشفة'}
                            </DropdownMenuItem>
                          </>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => {
                            setJobToDelete(job)
                            setDeleteDialogOpen(true)
                          }}
                          className="gap-2 text-destructive"
                        >
                          <Trash2 className="size-4" />
                          حذف
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                {/* Mini Pipeline Progress */}
                {job._count && job._count.applications > 0 && (
                  <div className="mt-2 pt-2 border-t border-border/50">
                    <div className="flex items-center gap-1.5">
                      <span className="text-2xs text-muted-foreground">قمع التوظيف</span>
                      <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-l from-red-500 to-red-400 rounded-full transition-all" style={{ width: `${Math.min(100, (job._count.applications / 10) * 100)}%` }} />
                      </div>
                      <span className="text-2xs text-muted-foreground font-medium">{job._count.applications}</span>
                    </div>
                  </div>
                )}
              </GlassCard>
            )
          })}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <Trash2 className="size-5" />
              حذف الوظيفة
            </DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف وظيفة &quot;{jobToDelete?.title}&quot؛؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              disabled={deleting}
            >
              إلغاء
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleting}
            >
              {deleting ? 'جاري الحذف...' : 'حذف نهائي'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}