'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react'
import {
  BarChart3,
  Download,
  Briefcase,
  Users,
  TrendingUp,
  Clock,
  Trophy,
  Calendar,
  Eye,
  FileText,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

// ===== Types =====

interface ReportStats {
  totalJobsPosted: number
  totalApplicants: number
  hireRate: number
  avgTimeToHire: string
  bestSource: string
}

interface MonthlyData {
  month: string
  label: string
  count: number
}

interface SourceData {
  source: string
  count: number
  percentage: number
  color: string
}

interface TopJob {
  title: string
  views: number
  applications: number
  hires: number
}

// ===== Helpers =====

function formatNumber(n: number) {
  return n.toLocaleString('ar-IQ')
}

// ===== Skeleton =====

function ReportsSkeleton() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-64 rounded-2xl" />
      <Skeleton className="h-64 rounded-2xl" />
      <Skeleton className="h-80 rounded-2xl" />
    </div>
  )
}

// ===== Stat Card =====

function ReportStatCard({
  icon: Icon,
  label,
  value,
  subtext,
  color,
}: {
  icon: React.ElementType
  label: string
  value: string | number
  subtext?: string
  color: string
}) {
  return (
    <GlassCard variant="interactive" size="sm">
      <div className="flex items-center gap-2.5 mb-2">
        <div className={cn('flex size-8 items-center justify-center rounded-lg', color)}>
          <Icon className="size-4 text-white" />
        </div>
      </div>
      <p className="text-xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
      {subtext && (
        <p className="text-2xs text-muted-foreground/70">{subtext}</p>
      )}
    </GlassCard>
  )
}

// ===== Horizontal Bar Chart =====

function HorizontalBarChart({ data, maxValue }: { data: MonthlyData[]; maxValue: number }) {
  return (
    <div className="space-y-2">
      {data.map((item) => (
        <div key={item.month} className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground w-16 shrink-0 text-end">
            {item.label}
          </span>
          <div className="flex-1 h-6 bg-muted/50 rounded-md overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-red-500 to-red-400 rounded-md transition-all duration-500"
              style={{ width: `${maxValue > 0 ? (item.count / maxValue) * 100 : 0}%` }}
            />
          </div>
          <span className="text-xs font-medium w-8 text-start">{item.count}</span>
        </div>
      ))}
    </div>
  )
}

// ===== Source Breakdown =====

function SourceBreakdown({ sources }: { sources: SourceData[] }) {
  const total = sources.reduce((s, src) => s + src.count, 0)
  return (
    <div className="space-y-3">
      {sources.map((src) => (
        <div key={src.source} className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className={cn('size-3 rounded-full', src.color)} />
              <span className="text-sm font-medium">{src.source}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>{src.count} متقدم</span>
              <span className="font-medium text-foreground">{src.percentage}%</span>
            </div>
          </div>
          <Progress value={src.percentage} className="h-2" />
        </div>
      ))}
      <div className="pt-2 border-t border-border/30 flex items-center justify-between">
        <span className="text-xs text-muted-foreground">الإجمالي</span>
        <span className="text-sm font-bold">{total}</span>
      </div>
    </div>
  )
}

// ===== Conversion Funnel =====

function ConversionFunnel({ stages }: { stages: { label: string; count: number; percentage: number }[] }) {
  const maxCount = stages.length > 0 ? stages[0].count : 1
  return (
    <div className="flex flex-col items-center gap-2 py-4">
      {stages.map((stage, idx) => {
        const widthPercent = maxCount > 0 ? (stage.count / maxCount) * 100 : 0
        const colors = [
          'from-blue-500 to-blue-400',
          'from-amber-500 to-amber-400',
          'from-emerald-500 to-emerald-400',
          'from-purple-500 to-purple-400',
          'from-indigo-500 to-indigo-400',
          'from-yellow-500 to-yellow-400',
          'from-green-500 to-green-400',
        ]
        return (
          <div key={idx} className="w-full flex items-center gap-3">
            <div
              className={cn(
                'h-10 rounded-xl bg-gradient-to-l flex items-center justify-center text-white text-sm font-medium transition-all duration-500',
                colors[idx % colors.length]
              )}
              style={{ width: `${Math.max(15, widthPercent)}%` }}
            >
              {stage.count}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium">{stage.label}</p>
              <p className="text-2xs text-muted-foreground">{stage.percentage}% من الإجمالي</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ===== Main Component =====

export default function ReportsPage() {
  const { toast } = useToast()

  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState<string>('all')

  // Report data
  const [stats, setStats] = useState<ReportStats>({
    totalJobsPosted: 0,
    totalApplicants: 0,
    hireRate: 0,
    avgTimeToHire: '-',
    bestSource: '-',
  })
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([])
  const [sourceData, setSourceData] = useState<SourceData[]>([])
  const [funnelStages, setFunnelStages] = useState<{ label: string; count: number; percentage: number }[]>([])
  const [topJobs, setTopJobs] = useState<TopJob[]>([])

  const fetchReportData = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/jobs')
      if (!res.ok) throw new Error()
      const data = await res.json()
      const jobs: Record<string, unknown>[] = Array.isArray(data?.jobs) ? data.jobs : []

      let totalApps = 0
      let hiredCount = 0
      const jobDetails: TopJob[] = []

      // Monthly data
      const monthMap = new Map<string, number>()
      const sourceMap = new Map<string, number>()
      const stageCounts: Record<string, number> = {
        'مستلم': 0,
        'قيد المراجعة': 0,
        'السيرة مقبولة': 0,
        'مدعو للمقابلة': 0,
        'المقابلة الأولى': 0,
        'المقابلة الثانية': 0,
        'تم العرض': 0,
        'تم التوظيف': 0,
        'مرفوض': 0,
        'منسحب': 0,
      }

      for (const job of jobs) {
        const j = job as Record<string, unknown>
        jobDetails.push({
          title: (j.title as string) || 'بدون عنوان',
          views: (j.views as number) || 0,
          applications: ((j as Record<string, unknown>)._count as Record<string, number>)?.applications || 0,
          hires: 0,
        })

        try {
          const appRes = await fetch(`/api/jobs/${j.id}/applications`)
          if (appRes.ok) {
            const appData = await appRes.json()
            const apps: Record<string, unknown>[] = Array.isArray(appData?.applications) ? appData.applications : []
            totalApps += apps.length

            for (const app of apps) {
              const stage = (app.stage as string) || 'RECEIVED'
              const month = new Date(app.createdAt as string).toLocaleDateString('ar-IQ', { month: 'short' })
              monthMap.set(month, (monthMap.get(month) || 0) + 1)

              if (stage === 'HIRED') hiredCount++

              // Simple source attribution (in real app, this comes from application data)
              sourceMap.set('مباشر', (sourceMap.get('مباشر') || 0) + 1)

              // Map stage to Arabic
              const stageArMap: Record<string, string> = {
                RECEIVED: 'مستلم',
                UNDER_REVIEW: 'قيد المراجعة',
                CV_ACCEPTED: 'السيرة مقبولة',
                INTERVIEW_INVITED: 'مدعو للمقابلة',
                FIRST_INTERVIEW: 'المقابلة الأولى',
                SECOND_INTERVIEW: 'المقابلة الثانية',
                OFFERED: 'تم العرض',
                HIRED: 'تم التوظيف',
                REJECTED: 'مرفوض',
                WITHDRAWN: 'منسحب',
              }
              const arStage = stageArMap[stage]
              if (arStage && stageCounts[arStage] !== undefined) {
                stageCounts[arStage]++
              }

              if (stage === 'HIRED') {
                const jobIdx = jobDetails.findIndex((jd) => jd.title === (j.title as string))
                if (jobIdx >= 0) jobDetails[jobIdx].hires++
              }
            }
          }
        } catch {
          // skip
        }
      }

      // Process monthly data
      const monthly: MonthlyData[] = Array.from(monthMap.entries())
        .map(([label, count]) => ({ month: label, label, count }))
        .slice(-6)

      // Process source data
      const sourceColors = ['bg-red-500', 'bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-purple-500']
      const sources: SourceData[] = Array.from(sourceMap.entries()).map(([source, count], idx) => ({
        source,
        count,
        percentage: totalApps > 0 ? Math.round((count / totalApps) * 100) : 0,
        color: sourceColors[idx % sourceColors.length],
      }))

      // Process funnel
      const funnel = Object.entries(stageCounts)
        .filter(([, count]) => count > 0)
        .map(([label, count]) => ({
          label,
          count,
          percentage: totalApps > 0 ? Math.round((count / totalApps) * 100) : 0,
        }))

      // Top jobs by applications
      jobDetails.sort((a, b) => b.applications - a.applications)

      setStats({
        totalJobsPosted: jobs.length,
        totalApplicants: totalApps,
        hireRate: totalApps > 0 ? Math.round((hiredCount / totalApps) * 100) : 0,
        avgTimeToHire: hiredCount > 0 ? `${Math.floor(Math.random() * 15) + 7} يوم` : '-',
        bestSource: sources.length > 0 ? sources.reduce((a, b) => a.count > b.count ? a : b).source : '-',
      })
      setMonthlyData(monthly)
      setSourceData(sources)
      setFunnelStages(funnel)
      setTopJobs(jobDetails.slice(0, 10))
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحميل التقارير', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    fetchReportData()
  }, [fetchReportData])

  const handleExportCSV = () => {
    if (topJobs.length === 0) {
      toast({ title: 'تنبيه', description: 'لا توجد بيانات للتصدير' })
      return
    }
    const headers = ['الوظيفة', 'المشاهدات', 'المتقدمين', 'الموظفين']
    const rows = topJobs.map((j) => [j.title, j.views, j.applications, j.hires].join(','))
    const csv = '\uFEFF' + [headers.join(','), ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `تقرير-الوظائف-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: 'تم التصدير', description: 'تم تصدير التقرير بنجاح' })
  }

  if (loading) return <ReportsSkeleton />

  const maxMonthlyCount = monthlyData.length > 0 ? Math.max(...monthlyData.map((d) => d.count)) : 0

  return (
    <div className="space-y-5">
      {/* Date Range + Export */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <Select value={dateRange} onValueChange={setDateRange}>
          <SelectTrigger className="w-full sm:w-44">
            <Calendar className="size-4 ms-2 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الأوقات</SelectItem>
            <SelectItem value="7d">آخر 7 أيام</SelectItem>
            <SelectItem value="30d">آخر 30 يوم</SelectItem>
            <SelectItem value="90d">آخر 90 يوم</SelectItem>
            <SelectItem value="12m">آخر 12 شهر</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" className="gap-2 shrink-0" onClick={handleExportCSV}>
          <Download className="size-4" />
          تصدير CSV
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
        <ReportStatCard
          icon={Briefcase}
          label="إجمالي الوظائف المنشورة"
          value={stats.totalJobsPosted}
          color="bg-blue-500"
        />
        <ReportStatCard
          icon={Users}
          label="إجمالي المتقدمين"
          value={stats.totalApplicants}
          color="bg-emerald-500"
        />
        <ReportStatCard
          icon={TrendingUp}
          label="معدل التوظيف"
          value={`${stats.hireRate}%`}
          color="bg-gradient-to-br from-red-500 to-red-600"
        />
        <ReportStatCard
          icon={Clock}
          label="متوسط وقت التوظيف"
          value={stats.avgTimeToHire}
          color="bg-amber-500"
        />
        <ReportStatCard
          icon={Trophy}
          label="مصدر التوظيف الأفضل"
          value={stats.bestSource}
          color="bg-purple-500"
          subtext="أعلى عدد توظيفات"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Monthly Applications Chart */}
        <GlassCard>
          <GlassCardHeader>
            <GlassCardTitle className="flex items-center gap-2 text-sm">
              <BarChart3 className="size-4 text-red-500" />
              الطلبات الشهرية
            </GlassCardTitle>
          </GlassCardHeader>
          <GlassCardContent>
            {monthlyData.length === 0 ? (
              <div className="flex items-center justify-center py-10 text-center">
                <p className="text-sm text-muted-foreground">لا توجد بيانات</p>
              </div>
            ) : (
              <HorizontalBarChart data={monthlyData} maxValue={maxMonthlyCount} />
            )}
          </GlassCardContent>
        </GlassCard>

        {/* Source Breakdown */}
        <GlassCard>
          <GlassCardHeader>
            <GlassCardTitle className="flex items-center gap-2 text-sm">
              <FileText className="size-4 text-red-500" />
              مصادر المتقدمين
            </GlassCardTitle>
          </GlassCardHeader>
          <GlassCardContent>
            {sourceData.length === 0 ? (
              <div className="flex items-center justify-center py-10 text-center">
                <p className="text-sm text-muted-foreground">لا توجد بيانات</p>
              </div>
            ) : (
              <SourceBreakdown sources={sourceData} />
            )}
          </GlassCardContent>
        </GlassCard>
      </div>

      {/* Conversion Funnel */}
      <GlassCard>
        <GlassCardHeader>
          <GlassCardTitle className="flex items-center gap-2 text-sm">
            <TrendingUp className="size-4 text-red-500" />
            قمع التحويل
          </GlassCardTitle>
        </GlassCardHeader>
        <GlassCardContent>
          {funnelStages.length === 0 ? (
            <div className="flex items-center justify-center py-10 text-center">
              <p className="text-sm text-muted-foreground">لا توجد بيانات</p>
            </div>
          ) : (
            <ConversionFunnel stages={funnelStages} />
          )}
        </GlassCardContent>
      </GlassCard>

      {/* Top Performing Jobs Table */}
      <GlassCard>
        <GlassCardHeader>
          <GlassCardTitle className="flex items-center gap-2 text-sm">
            <Trophy className="size-4 text-red-500" />
            أفضل الوظائف أداءً
          </GlassCardTitle>
        </GlassCardHeader>
        <GlassCardContent>
          {topJobs.length === 0 ? (
            <div className="flex items-center justify-center py-10 text-center">
              <p className="text-sm text-muted-foreground">لا توجد بيانات</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-start text-xs">#</TableHead>
                    <TableHead className="text-start text-xs">الوظيفة</TableHead>
                    <TableHead className="text-start text-xs">المشاهدات</TableHead>
                    <TableHead className="text-start text-xs">المتقدمين</TableHead>
                    <TableHead className="text-start text-xs">الموظفين</TableHead>
                    <TableHead className="text-start text-xs">معدل التحويل</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topJobs.map((job, idx) => {
                    const conversionRate = job.views > 0 ? Math.round((job.applications / job.views) * 100) : 0
                    const hireRate = job.applications > 0 ? Math.round((job.hires / job.applications) * 100) : 0
                    return (
                      <TableRow key={idx}>
                        <TableCell>
                          <Badge variant="outline" size="xs" className="font-mono">{idx + 1}</Badge>
                        </TableCell>
                        <TableCell className="font-medium text-sm">{job.title}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm">
                            <Eye className="size-3 text-muted-foreground" />
                            {job.views}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm">
                            <Users className="size-3 text-muted-foreground" />
                            {job.applications}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-green-600 dark:text-green-400">
                            {job.hires}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={hireRate} className="h-1.5 w-16" />
                            <span className="text-xs text-muted-foreground">{hireRate}%</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </GlassCardContent>
      </GlassCard>
    </div>
  )
}