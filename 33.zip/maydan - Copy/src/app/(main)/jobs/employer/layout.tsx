'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Briefcase,
  LayoutDashboard,
  FileText,
  Users,
  CalendarDays,
  BarChart3,
  Settings,
  Menu,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from '@/components/ui/sheet'
import { Separator } from '@/components/ui/separator'

const navItems = [
  {
    label: 'لوحة التحكم',
    href: '/jobs/employer',
    icon: LayoutDashboard,
    exact: true,
  },
  {
    label: 'إدارة الوظائف',
    href: '/jobs/employer/jobs',
    icon: FileText,
  },
  {
    label: 'المتقدمين',
    href: '/jobs/employer/applicants',
    icon: Users,
  },
  {
    label: 'المقابلات',
    href: '/jobs/employer/interviews',
    icon: CalendarDays,
  },
  {
    label: 'التقارير',
    href: '/jobs/employer/reports',
    icon: BarChart3,
  },
  {
    label: 'الإعدادات',
    href: '/jobs/employer/settings',
    icon: Settings,
  },
]

function isActive(pathname: string, href: string, exact?: boolean) {
  if (exact) return pathname === href
  return pathname.startsWith(href)
}

function NavContent({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <nav className="flex flex-col gap-1" role="navigation" aria-label="بوابة صاحب العمل">
      {navItems.map((item) => {
        const active = isActive(pathname, item.href, item.exact)
        const Icon = item.icon
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              'flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition-all duration-200',
              active
                ? 'bg-gradient-to-l from-red-500/10 to-red-500/5 text-red-600 dark:from-red-500/20 dark:to-red-500/10 dark:text-red-400 shadow-sm'
                : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
            )}
          >
            <Icon className={cn('size-4 shrink-0', active && 'text-red-500 dark:text-red-400')} />
            <span>{item.label}</span>
            {active && (
              <span className="me-auto size-1.5 rounded-full bg-red-500" />
            )}
          </Link>
        )
      })}
    </nav>
  )
}

export default function EmployerPortalLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-600 shadow-lg shadow-red-500/20">
            <Briefcase className="size-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">بوابة صاحب العمل</h1>
            <p className="text-xs text-muted-foreground">إدارة الوظائف والمتقدمين</p>
          </div>
        </div>

        {/* Mobile menu trigger */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              aria-label="القائمة"
            >
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-4">
            <SheetTitle className="flex items-center gap-2 px-2 mb-4 text-base">
              <Briefcase className="size-4 text-red-500" />
              بوابة صاحب العمل
            </SheetTitle>
            <Separator className="mb-3" />
            <NavContent
              pathname={pathname}
              onNavigate={() => setMobileOpen(false)}
            />
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop horizontal tabs */}
      <div className="hidden md:block">
        <div className="glass-card rounded-xl p-1.5">
          <div className="flex items-center gap-1 overflow-x-auto">
            {navItems.map((item) => {
              const active = isActive(pathname, item.href, item.exact)
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium whitespace-nowrap transition-all duration-200',
                    active
                      ? 'bg-gradient-to-l from-red-500/15 to-red-500/5 text-red-600 dark:from-red-500/25 dark:to-red-500/10 dark:text-red-400 shadow-sm'
                      : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                  )}
                >
                  <Icon className={cn('size-4', active && 'text-red-500')} />
                  <span>{item.label}</span>
                </Link>
              )
            })}
          </div>
        </div>
      </div>

      {/* Mobile tabs - horizontal scrollable */}
      <div className="md:hidden">
        <div className="flex items-center gap-1 overflow-x-auto pb-2 scrollbar-none">
          {navItems.map((item) => {
            const active = isActive(pathname, item.href, item.exact)
            const Icon = item.icon
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium whitespace-nowrap transition-all duration-200 shrink-0',
                  active
                    ? 'bg-red-500/10 text-red-600 dark:bg-red-500/20 dark:text-red-400'
                    : 'bg-accent/30 text-muted-foreground'
                )}
              >
                <Icon className="size-3.5" />
                <span>{item.label}</span>
              </Link>
            )
          })}
        </div>
      </div>

      {/* Content */}
      <div className="min-h-0 flex-1">{children}</div>
    </div>
  )
}