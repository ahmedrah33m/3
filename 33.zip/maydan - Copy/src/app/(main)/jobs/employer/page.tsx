'use client'

import React, { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  Briefcase,
  Users,
  CalendarDays,
  TrendingUp,
  Plus,
  ArrowLeft,
  Eye,
  Clock,
  FileText,
  Building2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { ErrorState, EmptyState } from '@/components/ui/feedback-state'

// ===== Types =====

interface Job {
  id: string
  title: string
  company: string
  type: string
  location: string | null
  status: string
  createdAt: string
  expiresAt: string
  _count?: { applications: number }
  views?: number
}

interface Application {
  id: string
  applicantId: string
  applicant: { id: string; name: string | null; avatar: string | null }
  job: { id: string; title: string }
  matchScore: number | null
  stage: string
  createdAt: string
  coverLetter: string | null
}

interface DashboardStats {
  totalJobs: number
  totalApplicants: number
  totalInterviews: number
  hireRate: number
}

// ===== Skeleton Loaders =====

function StatsSkeleton() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {[...Array(4)].map((_, i) => (
        <Skeleton key={i} className="h-28 rounded-2xl" />
      ))}
    </div>
  )
}

function TableSkeleton() {
  return (
    <GlassCard>
      <GlassCardHeader>
        <Skeleton className="h-5 w-48" />
      </GlassCardHeader>
      <GlassCardContent>
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-12 w-full rounded-lg" />
          ))}
        </div>
      </GlassCardContent>
    </GlassCard>
  )
}

function ActiveJobsSkeleton() {
  return (
    <GlassCard>
      <GlassCardHeader>
        <Skeleton className="h-5 w-40" />
      </GlassCardHeader>
      <GlassCardContent>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-lg" />
          ))}
        </div>
      </GlassCardContent>
    </GlassCard>
  )
}

// ===== Stat Card =====

function StatCard({
  icon: Icon,
  label,
  value,
  color,
  subtext,
}: {
  icon: React.ElementType
  label: string
  value: string | number
  color: string
  subtext?: string
}) {
  return (
    <GlassCard variant="interactive" size="sm">
      <div className="flex items-start justify-between">
        <div
          className={cn(
            'flex size-10 items-center justify-center rounded-xl',
            color
          )}
        >
          <Icon className="size-5 text-white" />
        </div>
        <p className="text-2xl font-bold tracking-tight">{value}</p>
      </div>
      <p className="text-sm font-medium text-foreground mt-2">{label}</p>
      {subtext && (
        <p className="text-xs text-muted-foreground">{subtext}</p>
      )}
    </GlassCard>
  )
}

// ===== Stage Badge =====

function stageBadge(stage: string) {
  const map: Record<string, { label: string; variant: 'default' | 'secondary' | 'success' | 'warning' | 'destructive' | 'info' | 'outline' }> = {
    RECEIVED: { label: 'مستلم', variant: 'info' },
    UNDER_REVIEW: { label: 'قيد المراجعة', variant: 'warning' },
    CV_ACCEPTED: { label: 'السيرة مقبولة', variant: 'success' },
    INTERVIEW_INVITED: { label: 'مدعو للمقابلة', variant: 'secondary' },
    FIRST_INTERVIEW: { label: 'المقابلة الأولى', variant: 'info' },
    SECOND_INTERVIEW: { label: 'المقابلة الثانية', variant: 'info' },
    OFFERED: { label: 'تم العرض', variant: 'warning' },
    HIRED: { label: 'تم التوظيف', variant: 'success' },
    REJECTED: { label: 'مرفوض', variant: 'destructive' },
    WITHDRAWN: { label: 'منسحب', variant: 'outline' },
  }
  const info = map[stage] || { label: stage, variant: 'outline' as const }
  return <Badge variant={info.variant} size="sm">{info.label}</Badge>
}

// ===== Date Helpers =====

function formatDate(dateStr: string) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('ar-IQ', { year: 'numeric', month: 'short', day: 'numeric' })
}

function daysRemaining(expiresAt: string) {
  const diff = new Date(expiresAt).getTime() - Date.now()
  const days = Math.ceil(diff / (1000 * 60 * 60 * 24))
  return days > 0 ? days : 0
}

// ===== Main Component =====

export default function EmployerDashboardPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [jobs, setJobs] = useState<Job[]>([])
  const [applications, setApplications] = useState<Application[]>([])
  const [stats, setStats] = useState<DashboardStats>({
    totalJobs: 0,
    totalApplicants: 0,
    totalInterviews: 0,
    hireRate: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch('/api/jobs/employer/dashboard')
      if (!res.ok) throw new Error(res.status === 401 ? 'غير مصرح' : 'فشل تحميل البيانات')
      const data = await res.json()

      setJobs(
        (Array.isArray(data?.activeJobs) ? data.activeJobs : []).map(
          (j: { id: string; title: string; applicantCount: number; expiresAt: string }) => ({
            id: j.id,
            title: j.title,
            company: '',
            type: '',
            location: null,
            status: 'ACTIVE',
            createdAt: '',
            expiresAt: j.expiresAt,
            _count: { applications: j.applicantCount },
          })
        )
      )

      setApplications(
        (Array.isArray(data?.recentApplications) ? data.recentApplications : []).map(
          (a: {
            id: string
            jobTitle: string
            applicantName: string | null
            applicantAvatar: string | null
            matchScore: number | null
            stage: string
            date: string
          }) => ({
            id: a.id,
            applicantId: '',
            applicant: { id: '', name: a.applicantName, avatar: a.applicantAvatar },
            job: { id: '', title: a.jobTitle },
            matchScore: a.matchScore,
            stage: a.stage,
            createdAt: a.date,
            coverLetter: null,
          })
        )
      )

      setStats({
        totalJobs: data?.totalJobs ?? 0,
        totalApplicants: data?.totalApplicants ?? 0,
        totalInterviews: data?.totalInterviews ?? 0,
        hireRate: data?.hireRate ?? 0,
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'حدث خطأ غير متوقع')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  if (loading) {
    return (
      <div className="space-y-5">
        <StatsSkeleton />
        <TableSkeleton />
        <ActiveJobsSkeleton />
      </div>
    )
  }

  if (error) {
    return (
      <ErrorState title={error} onRetry={fetchData} retryLabel="إعادة المحاولة" />
    )
  }

  return (
    <div className="space-y-5">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <StatCard
          icon={Briefcase}
          label="إجمالي الوظائف"
          value={stats.totalJobs}
          color="bg-blue-500"
          subtext="الوظائف النشطة والمسودات"
        />
        <StatCard
          icon={Users}
          label="المتقدمين"
          value={stats.totalApplicants}
          color="bg-emerald-500"
          subtext="إجمالي الطلبات"
        />
        <StatCard
          icon={CalendarDays}
          label="المقابلات"
          value={stats.totalInterviews}
          color="bg-amber-500"
          subtext="مقابلات مجدولة"
        />
        <StatCard
          icon={TrendingUp}
          label="نسبة التوظيف"
          value={`${stats.hireRate}%`}
          color="bg-gradient-to-br from-red-500 to-red-600"
          subtext="معدل النجاح"
        />
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2">
        <Button asChild className="gap-2 bg-gradient-to-l from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 shadow-lg shadow-red-500/20">
          <Link href="/jobs/new">
            <Plus className="size-4" />
            نشر وظيفة جديدة
          </Link>
        </Button>
        <Button asChild variant="outline" className="gap-2">
          <Link href="/jobs/cv-bank">
            <FileText className="size-4" />
            بنك السير الذاتية
          </Link>
        </Button>
        <Button asChild variant="outline" className="gap-2">
          <Link href="/jobs/employer/applicants">
            <Users className="size-4" />
            إدارة المتقدمين
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Applications Table */}
        <GlassCard className="lg:col-span-1">
          <GlassCardHeader>
            <div className="flex items-center justify-between">
              <GlassCardTitle className="flex items-center gap-2">
                <Users className="size-4 text-red-500" />
                آخر الطلبات
              </GlassCardTitle>
              <Button asChild variant="ghost" size="sm" className="gap-1 text-xs">
                <Link href="/jobs/employer/applicants">
                  عرض الكل
                  <ArrowLeft className="size-3" />
                </Link>
              </Button>
            </div>
          </GlassCardHeader>
          <GlassCardContent size="none">
            {applications.length === 0 ? (
              <EmptyState
                title="لا توجد طلبات بعد"
                description="ستظهر هنا طلبات المتقدمين لوظائفك بمجرد وصولها"
              />
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-start text-xs">المتقدم</TableHead>
                      <TableHead className="text-start text-xs">الوظيفة</TableHead>
                      <TableHead className="text-start text-xs">التوافق</TableHead>
                      <TableHead className="text-start text-xs">الحالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {applications.slice(0, 5).map((app) => (
                      <TableRow key={app.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="size-7">
                              <AvatarImage src={app.applicant?.avatar || undefined} />
                              <AvatarFallback className="text-2xs">
                                {app.applicant?.name?.charAt(0) || 'م'}
                              </AvatarFallback>
                            </Avatar>
                            <span className="text-xs font-medium truncate max-w-[80px] sm:max-w-[120px]">
                              {app.applicant?.name || 'مستخدم'}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-xs text-muted-foreground truncate max-w-[80px] sm:max-w-[120px] block">
                            {app.job?.title}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 min-w-[80px]">
                            <Progress
                              value={app.matchScore || 0}
                              className="h-1.5 w-16"
                            />
                            <span className="text-xs font-medium text-muted-foreground">
                              {app.matchScore || 0}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>{stageBadge(app.stage)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </GlassCardContent>
        </GlassCard>

        {/* Active Jobs List */}
        <GlassCard className="lg:col-span-1">
          <GlassCardHeader>
            <div className="flex items-center justify-between">
              <GlassCardTitle className="flex items-center gap-2">
                <Building2 className="size-4 text-red-500" />
                الوظائف النشطة
              </GlassCardTitle>
              <Button asChild variant="ghost" size="sm" className="gap-1 text-xs">
                <Link href="/jobs/employer/jobs">
                  عرض الكل
                  <ArrowLeft className="size-3" />
                </Link>
              </Button>
            </div>
          </GlassCardHeader>
          <GlassCardContent size="none">
            {jobs.length === 0 ? (
              <EmptyState
                title="لم تنشر أي وظيفة بعد"
                description="ابدأ بنشر أول وظيفة ليتمكن المرشحون من التقديم"
                actionLabel="نشر وظيفة"
                onAction={() => router.push('/jobs/new')}
              />
            ) : (
              <div className="space-y-2">
                {jobs.slice(0, 5).map((job) => {
                  const remaining = daysRemaining(job.expiresAt)
                  return (
                    <Link
                      key={job.id}
                      href={`/jobs/${job.id}`}
                      className="flex items-center gap-3 rounded-xl p-3 transition-colors hover:bg-accent/50 group"
                    >
                      <div className="flex size-10 items-center justify-center rounded-lg bg-blue-500/10 shrink-0">
                        <Briefcase className="size-4 text-blue-500" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate group-hover:text-red-500 transition-colors">
                          {job.title}
                        </p>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Users className="size-3" />
                            {job._count?.applications || 0} متقدم
                          </span>
                          <span className={cn(
                            'text-xs flex items-center gap-1',
                            remaining <= 7 ? 'text-red-500' : 'text-muted-foreground'
                          )}>
                            <Clock className="size-3" />
                            {remaining} يوم متبقي
                          </span>
                        </div>
                      </div>
                      <Eye className="size-4 text-muted-foreground/40 group-hover:text-red-500 transition-colors shrink-0" />
                    </Link>
                  )
                })}
              </div>
            )}
          </GlassCardContent>
        </GlassCard>
      </div>
    </div>
  )
}