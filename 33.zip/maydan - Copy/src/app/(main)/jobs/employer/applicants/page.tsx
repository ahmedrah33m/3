'use client'

import React, { useState, useEffect, useCallback, useMemo } from 'react'
import Link from 'next/link'
import {
  Search,
  Users,
  ArrowLeft,
  Briefcase,
  Calendar,
  ChevronDown,
  ChevronUp,
  MoreVertical,
  Eye,
  CheckCheck,
  ListFilter,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { GlassCard, GlassCardContent } from '@/components/ui/glass-card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

// ===== Types =====

interface JobWithApps {
  id: string
  title: string
  company: string
  type: string
  location: string | null
  status?: string
  createdAt: string
  expiresAt: string
  _count?: { applications: number }
}

interface PipelineStage {
  key: string
  labelAr: string
  count: number
  color: string
  bgColor: string
}

// ===== Constants =====

const STAGE_CONFIG: Record<string, { labelAr: string; color: string; bgColor: string }> = {
  RECEIVED: { labelAr: 'مستلم', color: 'text-blue-600 dark:text-blue-400', bgColor: 'bg-blue-500' },
  UNDER_REVIEW: { labelAr: 'قيد المراجعة', color: 'text-amber-600 dark:text-amber-400', bgColor: 'bg-amber-500' },
  CV_ACCEPTED: { labelAr: 'السيرة مقبولة', color: 'text-emerald-600 dark:text-emerald-400', bgColor: 'bg-emerald-500' },
  INTERVIEW_INVITED: { labelAr: 'مدعو للمقابلة', color: 'text-purple-600 dark:text-purple-400', bgColor: 'bg-purple-500' },
  FIRST_INTERVIEW: { labelAr: 'المقابلة الأولى', color: 'text-blue-600 dark:text-blue-400', bgColor: 'bg-blue-500' },
  SECOND_INTERVIEW: { labelAr: 'المقابلة الثانية', color: 'text-indigo-600 dark:text-indigo-400', bgColor: 'bg-indigo-500' },
  OFFERED: { labelAr: 'تم العرض', color: 'text-yellow-600 dark:text-yellow-400', bgColor: 'bg-yellow-500' },
  HIRED: { labelAr: 'تم التوظيف', color: 'text-green-600 dark:text-green-400', bgColor: 'bg-green-500' },
  REJECTED: { labelAr: 'مرفوض', color: 'text-red-600 dark:text-red-400', bgColor: 'bg-red-500' },
  WITHDRAWN: { labelAr: 'منسحب', color: 'text-gray-500 dark:text-gray-400', bgColor: 'bg-gray-500' },
}

type SortOption = 'newest' | 'most_applicants' | 'least_applicants'

// ===== Skeleton =====

function ApplicantsOverviewSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex gap-3">
        <Skeleton className="h-10 flex-1 max-w-sm rounded-lg" />
        <Skeleton className="h-10 w-32 rounded-lg" />
      </div>
      {[...Array(4)].map((_, i) => (
        <Skeleton key={i} className="h-40 w-full rounded-2xl" />
      ))}
    </div>
  )
}

// ===== Pipeline Mini Bar =====

function PipelineMiniBar({ stages }: { stages: PipelineStage[] }) {
  const total = stages.reduce((s, st) => s + st.count, 0)
  if (total === 0) return <span className="text-xs text-muted-foreground">لا يوجد متقدمين</span>

  return (
    <div className="flex gap-0.5 h-6 rounded-lg overflow-hidden">
      {stages
        .filter((s) => s.count > 0)
        .map((stage) => (
          <div
            key={stage.key}
            className={cn('relative flex items-center justify-center transition-all', stage.bgColor)}
            style={{ width: `${Math.max(8, (stage.count / total) * 100)}%` }}
            title={`${stage.labelAr}: ${stage.count}`}
          >
            {(stage.count / total) > 0.12 && (
              <span className="text-[9px] font-bold text-white leading-none px-0.5">
                {stage.count}
              </span>
            )}
          </div>
        ))}
    </div>
  )
}

// ===== Main Component =====

export default function ApplicantsOverviewPage() {
  const { toast } = useToast()

  const [jobs, setJobs] = useState<JobWithApps[]>([])
  const [pipelineData, setPipelineData] = useState<Record<string, PipelineStage[]>>({})
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState<SortOption>('newest')
  const [expandedJobs, setExpandedJobs] = useState<Set<string>>(new Set())
  const [markingAllReviewed, setMarkingAllReviewed] = useState<string | null>(null)

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/jobs')
      if (!res.ok) throw new Error('فشل تحميل الوظائف')
      const data = await res.json()
      const allJobs: JobWithApps[] = Array.isArray(data?.jobs) ? data.jobs : []
      const activeJobs = allJobs.filter((j) => j.status !== 'ARCHIVED')
      setJobs(activeJobs)

      // Fetch pipeline data for each job
      const pipelineMap: Record<string, PipelineStage[]> = {}
      for (const job of activeJobs) {
        try {
          const appRes = await fetch(`/api/jobs/${job.id}/applications`)
          if (appRes.ok) {
            const appData = await appRes.json()
            const applications: { stage: string }[] = Array.isArray(appData?.applications) ? appData.applications : []

            const stageCounts: Record<string, number> = {}
            applications.forEach((app) => {
              stageCounts[app.stage] = (stageCounts[app.stage] || 0) + 1
            })

            pipelineMap[job.id] = Object.entries(stageCounts).map(([key, count]) => ({
              key,
              labelAr: STAGE_CONFIG[key]?.labelAr || key,
              count,
              color: STAGE_CONFIG[key]?.color || 'text-gray-500',
              bgColor: STAGE_CONFIG[key]?.bgColor || 'bg-gray-500',
            }))
          }
        } catch {
          pipelineMap[job.id] = []
        }
      }
      setPipelineData(pipelineMap)
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحميل البيانات', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const toggleExpanded = (jobId: string) => {
    setExpandedJobs((prev) => {
      const next = new Set(prev)
      if (next.has(jobId)) next.delete(jobId)
      else next.add(jobId)
      return next
    })
  }

  const filteredJobs = useMemo(() => {
    const result = jobs.filter(
      (j) => !searchQuery || j.title.includes(searchQuery)
    )
    switch (sortBy) {
      case 'newest':
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        break
      case 'most_applicants':
        result.sort((a, b) => (b._count?.applications || 0) - (a._count?.applications || 0))
        break
      case 'least_applicants':
        result.sort((a, b) => (a._count?.applications || 0) - (b._count?.applications || 0))
        break
    }
    return result
  }, [jobs, searchQuery, sortBy])

  const handleMarkAllReviewed = async (jobId: string) => {
    setMarkingAllReviewed(jobId)
    try {
      const appRes = await fetch(`/api/jobs/${jobId}/applications`)
      if (!appRes.ok) throw new Error()
      const appData = await appRes.json()
      const applications = Array.isArray(appData?.applications) ? appData.applications : []

      const receivedApps = applications.filter(
        (a: { id: string; stage: string }) => a.stage === 'RECEIVED'
      )

      for (const app of receivedApps) {
        await fetch(`/api/jobs/${jobId}/pipeline`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ applicationId: app.id, stage: 'UNDER_REVIEW' }),
        })
      }

      toast({
        title: 'تم التحديث',
        description: `تم تحديث ${receivedApps.length} طلب إلى قيد المراجعة`,
      })
      fetchData()
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحديث الحالات', variant: 'destructive' })
    } finally {
      setMarkingAllReviewed(null)
    }
  }

  if (loading) return <ApplicantsOverviewSkeleton />

  return (
    <div className="space-y-5">
      {/* Search & Sort */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="relative flex-1 w-full sm:max-w-sm">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="ابحث حسب عنوان الوظيفة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="ps-9"
          />
        </div>
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
          <SelectTrigger className="w-full sm:w-44">
            <ListFilter className="size-4 ms-2 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">الأحدث أولاً</SelectItem>
            <SelectItem value="most_applicants">الأكثر متقدمين</SelectItem>
            <SelectItem value="least_applicants">الأقل متقدمين</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Jobs List */}
      {filteredJobs.length === 0 ? (
        <GlassCard variant="flat" size="lg" className="text-center">
          <Users className="size-12 text-muted-foreground/20 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">
            {searchQuery ? 'لا توجد نتائج' : 'لا توجد وظائف'}
          </p>
        </GlassCard>
      ) : (
        <div className="space-y-3">
          {filteredJobs.map((job) => {
            const isExpanded = expandedJobs.has(job.id)
            const stages = pipelineData[job.id] || []
            const totalApplicants = job._count?.applications || 0

            return (
              <GlassCard key={job.id} variant="flat" size="sm">
                {/* Job Header Row */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => toggleExpanded(job.id)}
                    className="flex-1 text-start min-w-0 flex items-center gap-3 group"
                  >
                    <div className="flex size-9 items-center justify-center rounded-lg bg-red-500/10 shrink-0">
                      <Briefcase className="size-4 text-red-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate group-hover:text-red-500 transition-colors">
                        {job.title}
                      </p>
                      <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="size-3" />
                          {new Date(job.createdAt).toLocaleDateString('ar-IQ', { year: 'numeric', month: 'short', day: 'numeric' })}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="size-3" />
                          {totalApplicants} متقدم
                        </span>
                      </div>
                    </div>
                    {isExpanded ? (
                      <ChevronUp className="size-4 text-muted-foreground shrink-0" />
                    ) : (
                      <ChevronDown className="size-4 text-muted-foreground shrink-0" />
                    )}
                  </button>

                  {/* Quick Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    <Button asChild variant="ghost" size="sm" className="gap-1 text-xs">
                      <Link href={`/jobs/employer/applicants/${job.id}/kanban`}>
                        <Users className="size-3.5" />
                        <span className="hidden sm:inline">عرض المتقدمين</span>
                      </Link>
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="size-8">
                          <MoreVertical className="size-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link href={`/jobs/employer/applicants/${job.id}/kanban`} className="gap-2">
                            <Users className="size-4" />
                            لوحة المتقدمين
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/jobs/${job.id}`} className="gap-2">
                            <Eye className="size-4" />
                            تفاصيل الوظيفة
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleMarkAllReviewed(job.id)}
                          disabled={markingAllReviewed === job.id}
                          className="gap-2"
                        >
                          <CheckCheck className="size-4" />
                          {markingAllReviewed === job.id ? 'جاري التحديث...' : 'تحديد الكل كمراجعة'}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                {/* Expanded Pipeline Details */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-border/50 space-y-3">
                    {/* Pipeline Bar */}
                    <PipelineMiniBar stages={stages} />

                    {/* Stage Breakdown Grid */}
                    {stages.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {stages
                          .sort((a, b) => b.count - a.count)
                          .map((stage) => (
                            <div
                              key={stage.key}
                              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-accent/30 text-xs"
                            >
                              <span className={cn('size-2 rounded-full', stage.bgColor)} />
                              <span className="font-medium">{stage.labelAr}</span>
                              <span className="text-muted-foreground">{stage.count}</span>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground text-center py-2">
                        لا توجد طلبات لهذه الوظيفة بعد
                      </p>
                    )}

                    {/* CTA */}
                    {totalApplicants > 0 && (
                      <div className="flex justify-end">
                        <Button asChild variant="outline" size="sm" className="gap-1.5 text-xs">
                          <Link href={`/jobs/employer/applicants/${job.id}/kanban`}>
                            إدارة خط التوظيف
                            <ArrowLeft className="size-3" />
                          </Link>
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </GlassCard>
            )
          })}
        </div>
      )}
    </div>
  )
}