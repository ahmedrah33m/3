'use client'

import React, { useState, useEffect, useCallback, useMemo, use } from 'react'
import Link from 'next/link'
import {
  Search,
  Star,
  MessageSquarePlus,
  ChevronLeft,
  ChevronRight,
  Filter,
  User,
  Briefcase,
  TrendingUp,
  Users,
  StickyNote,
  MoveRight,
  Eye,
  FileText,
  GraduationCap,
  MapPin,
  Clock,
  Mail,
  Phone,
  CheckCircle2,
  XCircle,
  MinusCircle,
  Bookmark,
  ExternalLink,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { GlassCard, GlassCardHeader, GlassCardTitle, GlassCardContent } from '@/components/ui/glass-card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

// ===== Types =====

interface MatchDetail {
  label: string
  status: 'match' | 'partial' | 'miss'
  detail: string
}

interface SnapshotData {
  name?: string | null
  email?: string | null
  phone?: string | null
  avatar?: string | null
  resumeFile?: string | null
  skills?: string[]
  experience?: number | null
  education?: string | null
  university?: string | null
  jobTitle?: string | null
  location?: string | null
  languages?: unknown
  resumeData?: unknown
}

interface Applicant {
  id: string
  applicantId: string
  applicant?: { id: string; name: string | null; avatar: string | null; phone?: string | null; email?: string | null }
  stage: string
  pipelineStage?: string
  matchScore: number | null
  coverLetter: string | null
  skills: string[]
  createdAt: string
  rating?: number | null
  applicantSnapshot?: SnapshotData | null
  matchDetails?: MatchDetail[] | null
  _count?: { notes: number; stageChanges: number }
}

interface JobDetail {
  id: string
  title: string
  company: string
}

// ===== Pipeline Stage Config =====

const PIPELINE_STAGES = [
  { key: 'RECEIVED', labelAr: 'مستلم', color: 'bg-blue-500/10 border-blue-500/30', badgeColor: 'bg-blue-500/10 text-blue-600 dark:text-blue-400', dotColor: 'bg-blue-500' },
  { key: 'UNDER_REVIEW', labelAr: 'قيد المراجعة', color: 'bg-amber-500/10 border-amber-500/30', badgeColor: 'bg-amber-500/10 text-amber-600 dark:text-amber-400', dotColor: 'bg-amber-500' },
  { key: 'CV_ACCEPTED', labelAr: 'السيرة مقبولة', color: 'bg-emerald-500/10 border-emerald-500/30', badgeColor: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400', dotColor: 'bg-emerald-500' },
  { key: 'INTERVIEW_INVITED', labelAr: 'مدعو للمقابلة', color: 'bg-purple-500/10 border-purple-500/30', badgeColor: 'bg-purple-500/10 text-purple-600 dark:text-purple-400', dotColor: 'bg-purple-500' },
  { key: 'FIRST_INTERVIEW', labelAr: 'المقابلة الأولى', color: 'bg-blue-500/10 border-blue-400/30', badgeColor: 'bg-blue-500/10 text-blue-600 dark:text-blue-400', dotColor: 'bg-blue-400' },
  { key: 'SECOND_INTERVIEW', labelAr: 'المقابلة الثانية', color: 'bg-indigo-500/10 border-indigo-500/30', badgeColor: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400', dotColor: 'bg-indigo-500' },
  { key: 'OFFERED', labelAr: 'تم العرض', color: 'bg-yellow-500/10 border-yellow-500/30', badgeColor: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400', dotColor: 'bg-yellow-500' },
  { key: 'HIRED', labelAr: 'تم التوظيف', color: 'bg-green-500/10 border-green-500/30', badgeColor: 'bg-green-500/10 text-green-600 dark:text-green-400', dotColor: 'bg-green-500' },
  { key: 'REJECTED', labelAr: 'مرفوض', color: 'bg-red-500/10 border-red-500/30', badgeColor: 'bg-red-500/10 text-red-600 dark:text-red-400', dotColor: 'bg-red-500' },
  { key: 'WITHDRAWN', labelAr: 'منسحب', color: 'bg-gray-500/10 border-gray-500/30', badgeColor: 'bg-gray-500/10 text-gray-600 dark:text-gray-400', dotColor: 'bg-gray-500' },
] as const

type PipelineStage = (typeof PIPELINE_STAGES)[number]['key']

// ===== Helpers =====

function getSnapshotValue(applicant: Applicant, field: keyof SnapshotData): string | null {
  return (applicant.applicantSnapshot?.[field] as string) || null
}

const EDUCATION_LABELS: Record<string, string> = {
  bachelor: 'بكالوريوس',
  master: 'ماجستير',
  phd: 'دكتوراه',
  diploma: 'دبلوم',
}

function educationLabel(level: string | null | undefined): string {
  if (!level) return 'غير محدد'
  const key = level.toLowerCase().trim()
  for (const [k, v] of Object.entries(EDUCATION_LABELS)) {
    if (key.includes(k)) return v
  }
  if (key.includes('بكالوريوس') || key.includes('إجازة')) return 'بكالوريوس'
  if (key.includes('ماجستير')) return 'ماجستير'
  if (key.includes('دكتوراه')) return 'دكتوراه'
  if (key.includes('دبلوم')) return 'دبلوم'
  return level
}

function MatchDetailIcon({ status }: { status: string }) {
  if (status === 'match') return <CheckCircle2 className="size-3.5 text-emerald-500 shrink-0" />
  if (status === 'partial') return <MinusCircle className="size-3.5 text-amber-500 shrink-0" />
  return <XCircle className="size-3.5 text-red-500 shrink-0" />
}

// ===== Skeleton =====

function KanbanSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex gap-3">
        <Skeleton className="h-10 flex-1 max-w-sm rounded-lg" />
        <Skeleton className="h-10 w-28 rounded-lg" />
        <Skeleton className="h-10 w-28 rounded-lg" />
      </div>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="min-w-[280px] max-w-[280px] space-y-3">
            <Skeleton className="h-8 w-32 rounded-lg" />
            {[...Array(3)].map((_, j) => (
              <Skeleton key={j} className="h-36 w-full rounded-xl" />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

// ===== Applicant Card =====

function ApplicantCard({
  applicant,
  stageKey,
  stages,
  jobId,
  onMoveStage,
  onAddNote,
  onRate,
  onViewProfile,
}: {
  applicant: Applicant
  stageKey: string
  stages: typeof PIPELINE_STAGES
  jobId: string
  onMoveStage: (applicationId: string, stage: string) => void
  onAddNote: (applicationId: string, applicantName: string) => void
  onRate: (applicationId: string, rating: number) => void
  onViewProfile: (applicant: Applicant) => void
}) {
  const currentIdx = stages.findIndex((s) => s.key === stageKey)
  const canMoveForward = currentIdx < stages.length - 1 && stageKey !== 'WITHDRAWN'
  const canMoveBack = currentIdx > 0 && stageKey !== 'WITHDRAWN'
  const nextStage = canMoveForward ? stages[currentIdx + 1] : null
  const prevStage = canMoveBack ? stages[currentIdx - 1] : null

  const name = applicant.applicant?.name || 'مستخدم'
  const exp = getSnapshotValue(applicant, 'experience') || (applicant.applicant as any)?.jobTitle ? null : null
  const experienceYears = getSnapshotValue(applicant, 'experience')
  const education = getSnapshotValue(applicant, 'education') || (applicant.applicant as any)?.jobTitle ? null : null
  const educationLevel = getSnapshotValue(applicant, 'education')
  const location = getSnapshotValue(applicant, 'location')
  const jobTitle = getSnapshotValue(applicant, 'jobTitle')
  const university = getSnapshotValue(applicant, 'university')
  const resumeFile = getSnapshotValue(applicant, 'resumeFile')
  const hasNotes = (applicant._count?.notes || 0) > 0

  return (
    <div className="rounded-xl border border-border/50 bg-card/50 backdrop-blur-sm p-3 space-y-2.5 transition-all hover:shadow-md">
      {/* Header: Avatar + Name + Score */}
      <div className="flex items-start justify-between gap-2">
        <button
          onClick={() => onViewProfile(applicant)}
          className="flex items-center gap-2.5 min-w-0 text-start hover:opacity-80 transition-opacity"
        >
          <Avatar className="size-9 shrink-0">
            <AvatarImage src={applicant.applicant?.avatar || undefined} />
            <AvatarFallback className="text-xs">
              {name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="text-sm font-medium truncate">{name}</p>
            {jobTitle && (
              <p className="text-2xs text-muted-foreground truncate">{jobTitle}</p>
            )}
            {!jobTitle && (applicant.applicant as any)?.jobTitle && (
              <p className="text-2xs text-muted-foreground truncate">{(applicant.applicant as any).jobTitle}</p>
            )}
          </div>
        </button>
        {applicant.matchScore != null && (
          <Badge
            variant={applicant.matchScore >= 70 ? 'success' : applicant.matchScore >= 40 ? 'warning' : 'destructive'}
            size="sm"
            className="shrink-0"
          >
            {applicant.matchScore}%
          </Badge>
        )}
      </div>

      {/* Profile Quick Info */}
      <div className="flex flex-wrap gap-x-3 gap-y-1 text-2xs text-muted-foreground">
        {experienceYears && (
          <span className="flex items-center gap-1">
            <Briefcase className="size-2.5" />
            {experienceYears} سنة خبرة
          </span>
        )}
        {educationLevel && (
          <span className="flex items-center gap-1">
            <GraduationCap className="size-2.5" />
            {educationLabel(educationLevel)}
          </span>
        )}
        {location && (
          <span className="flex items-center gap-1">
            <MapPin className="size-2.5" />
            {location}
          </span>
        )}
      </div>

      {/* Cover Letter Preview */}
      {applicant.coverLetter && (
        <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
          &ldquo;{applicant.coverLetter.slice(0, 80)}{applicant.coverLetter.length > 80 ? '...' : ''}&rdquo;
        </p>
      )}

      {/* Skills Tags */}
      {applicant.skills && applicant.skills.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {applicant.skills.slice(0, 3).map((skill, i) => (
            <span
              key={i}
              className="px-1.5 py-0.5 text-2xs rounded bg-accent/50 text-muted-foreground"
            >
              {skill}
            </span>
          ))}
          {applicant.skills.length > 3 && (
            <span className="text-2xs text-muted-foreground">
              +{applicant.skills.length - 3}
            </span>
          )}
        </div>
      )}

      {/* Rating Stars */}
      {applicant.rating != null && applicant.rating > 0 && (
        <div className="flex items-center gap-0.5">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={cn(
                'size-3',
                star <= (applicant.rating || 0)
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-muted-foreground/30'
              )}
            />
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pt-1 border-t border-border/30">
        <div className="flex items-center gap-1">
          {prevStage && (
            <Button
              variant="ghost"
              size="icon"
              className="size-7"
              onClick={() => onMoveStage(applicant.id, prevStage.key)}
              title={`نقل إلى ${prevStage.labelAr}`}
            >
              <ChevronRight className="size-3.5" />
            </Button>
          )}
          {nextStage && (
            <Button
              variant="ghost"
              size="icon"
              className="size-7"
              onClick={() => onMoveStage(applicant.id, nextStage.key)}
              title={`نقل إلى ${nextStage.labelAr}`}
            >
              <ChevronLeft className="size-3.5" />
            </Button>
          )}
        </div>
        <div className="flex items-center gap-1">
          {/* View Profile / CV Button */}
          <Button
            variant="ghost"
            size="icon"
            className="size-7"
            onClick={() => onViewProfile(applicant)}
            title="عرض السيرة الذاتية"
          >
            <Eye className="size-3.5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="size-7">
                <MoveRight className="size-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              {stages
                .filter((s) => s.key !== stageKey && s.key !== 'WITHDRAWN')
                .map((s) => (
                  <DropdownMenuItem
                    key={s.key}
                    onClick={() => onMoveStage(applicant.id, s.key)}
                    className="gap-2 text-xs"
                  >
                    <span className={cn('size-2 rounded-full', s.dotColor)} />
                    {s.labelAr}
                  </DropdownMenuItem>
                ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => onMoveStage(applicant.id, 'WITHDRAWN')}
                className="gap-2 text-xs text-muted-foreground"
              >
                <span className="size-2 rounded-full bg-gray-500" />
                منسحب
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => onMoveStage(applicant.id, 'REJECTED')}
                className="gap-2 text-xs text-red-500"
              >
                <span className="size-2 rounded-full bg-red-500" />
                مرفوض
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="ghost"
            size="icon"
            className={cn('size-7', hasNotes && 'text-amber-500')}
            onClick={() => onAddNote(applicant.id, name)}
            title="إضافة ملاحظة"
          >
            <StickyNote className="size-3.5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="size-7">
                <Star className={cn('size-3.5', applicant.rating && applicant.rating > 0 && 'fill-yellow-400 text-yellow-400')} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-36">
              {[5, 4, 3, 2, 1].map((r) => (
                <DropdownMenuItem
                  key={r}
                  onClick={() => onRate(applicant.id, r)}
                  className="gap-1.5 text-xs"
                >
                  <div className="flex gap-0.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={cn(
                          'size-3',
                          s <= r
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-muted-foreground/30'
                        )}
                      />
                    ))}
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  )
}

// ===== Column Component (Desktop) =====

function KanbanColumn({
  stage,
  applicants,
  stages,
  jobId,
  onMoveStage,
  onAddNote,
  onRate,
  onViewProfile,
}: {
  stage: (typeof PIPELINE_STAGES)[number]
  applicants: Applicant[]
  stages: typeof PIPELINE_STAGES
  jobId: string
  onMoveStage: (applicationId: string, stage: string) => void
  onAddNote: (applicationId: string, applicantName: string) => void
  onRate: (applicationId: string, rating: number) => void
  onViewProfile: (applicant: Applicant) => void
}) {
  return (
    <div className="min-w-[280px] max-w-[300px] flex-1 shrink-0">
      {/* Column Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <span className={cn('size-2.5 rounded-full', stage.dotColor)} />
          <h3 className="text-sm font-semibold">{stage.labelAr}</h3>
          <Badge variant="secondary" size="xs">{applicants.length}</Badge>
        </div>
      </div>

      {/* Cards */}
      <div className="space-y-2.5 max-h-[calc(100vh-300px)] overflow-y-auto pe-1 scrollbar-thin">
        {applicants.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border/50 p-6 text-center">
            <User className="size-6 text-muted-foreground/20 mx-auto mb-2" />
            <p className="text-xs text-muted-foreground">لا يوجد متقدمين</p>
          </div>
        ) : (
          applicants.map((app) => (
            <ApplicantCard
              key={app.id}
              applicant={app}
              stageKey={stage.key}
              stages={stages}
              jobId={jobId}
              onMoveStage={onMoveStage}
              onAddNote={onAddNote}
              onRate={onRate}
              onViewProfile={onViewProfile}
            />
          ))
        )}
      </div>
    </div>
  )
}

// ===== Applicant Profile Dialog =====

function ApplicantProfileDialog({
  applicant,
  open,
  onClose,
}: {
  applicant: Applicant | null
  open: boolean
  onClose: () => void
}) {
  if (!applicant) return null

  const snap = applicant.applicantSnapshot
  const name = snap?.name || applicant.applicant?.name || 'مستخدم'
  const email = snap?.email || applicant.applicant?.email
  const phone = snap?.phone || applicant.applicant?.email
  const jobTitle = snap?.jobTitle
  const location = snap?.location
  const experience = snap?.experience
  const education = snap?.education
  const university = snap?.university
  const resumeFile = snap?.resumeFile
  const skills = snap?.skills || applicant.skills || []
  const resumeData = snap?.resumeData
  const matchDetails = applicant.matchDetails || []
  const matchScore = applicant.matchScore

  const hasContactInfo = !!(email || phone)
  const hasResume = !!(resumeFile || resumeData)

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <Avatar className="size-10">
              <AvatarImage src={snap?.avatar || applicant.applicant?.avatar || undefined} />
              <AvatarFallback>{name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="text-start">
              <p>{name}</p>
              {jobTitle && (
                <p className="text-sm font-normal text-muted-foreground">{jobTitle}</p>
              )}
            </div>
            {matchScore != null && (
              <Badge
                variant={matchScore >= 70 ? 'success' : matchScore >= 40 ? 'warning' : 'destructive'}
                className="ms-auto"
              >
                {matchScore}%
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>ملف المرشح عند التقديم (نسخة محفوظة)</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Contact Info */}
          {hasContactInfo && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {email && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="size-4 text-muted-foreground shrink-0" />
                  <a href={`mailto:${email}`} className="text-red-500 hover:underline truncate">
                    {email}
                  </a>
                </div>
              )}
              {phone && (
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="size-4 text-muted-foreground shrink-0" />
                  <a href={`tel:${phone}`} className="text-red-500 hover:underline" dir="ltr">
                    {phone}
                  </a>
                </div>
              )}
            </div>
          )}

          {/* Profile Details Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {experience != null && (
              <div className="flex items-center gap-2 text-sm rounded-lg bg-accent/30 p-2.5">
                <Briefcase className="size-4 text-blue-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">الخبرة</p>
                  <p className="font-medium">{experience} سنة</p>
                </div>
              </div>
            )}
            {education && (
              <div className="flex items-center gap-2 text-sm rounded-lg bg-accent/30 p-2.5">
                <GraduationCap className="size-4 text-emerald-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">الشهادة</p>
                  <p className="font-medium truncate">{educationLabel(education)}</p>
                </div>
              </div>
            )}
            {university && (
              <div className="flex items-center gap-2 text-sm rounded-lg bg-accent/30 p-2.5">
                <FileText className="size-4 text-purple-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">الجامعة</p>
                  <p className="font-medium truncate">{university}</p>
                </div>
              </div>
            )}
            {location && (
              <div className="flex items-center gap-2 text-sm rounded-lg bg-accent/30 p-2.5">
                <MapPin className="size-4 text-amber-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">الموقع</p>
                  <p className="font-medium truncate">{location}</p>
                </div>
              </div>
            )}
            {applicant._count?.notes ? (
              <div className="flex items-center gap-2 text-sm rounded-lg bg-accent/30 p-2.5">
                <StickyNote className="size-4 text-amber-500 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">الملاحظات</p>
                  <p className="font-medium">{applicant._count.notes}</p>
                </div>
              </div>
            ) : null}
            {applicant.rating && applicant.rating > 0 ? (
              <div className="flex items-center gap-2 text-sm rounded-lg bg-accent/30 p-2.5">
                <Star className="size-4 text-yellow-500 fill-yellow-400 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">التقييم</p>
                  <p className="font-medium">{applicant.rating}/5</p>
                </div>
              </div>
            ) : null}
          </div>

          {/* Match Score Details */}
          {matchDetails.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                <TrendingUp className="size-4 text-red-500" />
                تفاصيل نسبة التوافق
              </h4>
              <div className="space-y-1.5">
                {matchDetails.map((detail, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <MatchDetailIcon status={detail.status} />
                    <span className="font-medium w-20 shrink-0">{detail.label}</span>
                    <span className="text-muted-foreground text-xs truncate">{detail.detail}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          {skills.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-2">المهارات</h4>
              <div className="flex flex-wrap gap-1.5">
                {skills.map((skill, i) => (
                  <Badge key={i} variant="secondary" size="sm">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Cover Letter */}
          {applicant.coverLetter && (
            <div>
              <h4 className="text-sm font-semibold mb-2">رسالة التقديم</h4>
              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {applicant.coverLetter}
              </p>
            </div>
          )}

          {/* Resume Section */}
          {hasResume && (
            <div>
              <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                <FileText className="size-4 text-red-500" />
                السيرة الذاتية
              </h4>
              {resumeFile && (
                <a
                  href={resumeFile}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm text-red-500 hover:underline"
                >
                  <ExternalLink className="size-3.5" />
                  فتح ملف السيرة الذاتية (PDF)
                </a>
              )}
              {(resumeData as any) && typeof resumeData === 'object' && (
                <div className="mt-3 rounded-lg border border-border/50 bg-accent/20 p-4 space-y-2">
                  <p className="text-xs text-muted-foreground">بيانات السيرة المحفوظة عند التقديم</p>
                  {Object.entries(resumeData as Record<string, unknown>).map(([key, value]) => {
                    if (value === null || value === undefined || key === 'skills') return null
                    if (typeof value === 'string' || typeof value === 'number') {
                      return (
                        <div key={key} className="flex gap-2 text-sm">
                          <span className="text-muted-foreground font-medium min-w-[100px]">{key}:</span>
                          <span>{String(value)}</span>
                        </div>
                      )
                    }
                    if (Array.isArray(value)) {
                      return (
                        <div key={key} className="flex gap-2 text-sm">
                          <span className="text-muted-foreground font-medium min-w-[100px]">{key}:</span>
                          <span>{value.join(', ')}</span>
                        </div>
                      )
                    }
                    return null
                  })}
                </div>
              )}
            </div>
          )}

          {/* Applied Date */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t border-border/30">
            <Clock className="size-3" />
            <span>تاريخ التقديم: {new Date(applicant.createdAt).toLocaleDateString('ar-IQ', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ===== Main Page =====

export default function KanbanPage({
  params,
}: {
  params: Promise<{ jobId: string }>
}) {
  const { jobId } = use(params)
  const { toast } = useToast()

  const [job, setJob] = useState<JobDetail | null>(null)
  const [applications, setApplications] = useState<Applicant[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [skillFilter, setSkillFilter] = useState('')
  const [scoreFilter, setScoreFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all')
  const [movingId, setMovingId] = useState<string | null>(null)

  // Mobile: selected stage for tab view
  const [mobileStage, setMobileStage] = useState<string>('RECEIVED')

  // Note dialog
  const [noteDialogOpen, setNoteDialogOpen] = useState(false)
  const [noteText, setNoteText] = useState('')
  const [noteAppId, setNoteAppId] = useState<string | null>(null)
  const [noteAppName, setNoteAppName] = useState('')
  const [noteSaving, setNoteSaving] = useState(false)

  // Profile dialog
  const [profileApplicant, setProfileApplicant] = useState<Applicant | null>(null)
  const [profileDialogOpen, setProfileDialogOpen] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)

      const [jobRes, appRes] = await Promise.all([
        fetch(`/api/jobs/${jobId}`),
        fetch(`/api/jobs/${jobId}/applications`),
      ])

      if (!jobRes.ok) throw new Error('فشل تحميل الوظيفة')

      const jobData = await jobRes.json()
      setJob({ id: jobData?.id, title: jobData?.title, company: jobData?.company })

      if (appRes.ok) {
        const appData = await appRes.json()
        const apps: Applicant[] = Array.isArray(appData?.applications)
          ? appData.applications.map((a: Record<string, unknown>) => ({
              id: a.id as string,
              applicantId: (a.applicantId || a.userId || '') as string,
              applicant: a.applicant as Applicant['applicant'] || undefined,
              stage: (a.pipelineStage || a.stage || 'RECEIVED') as string,
              matchScore: (a.matchScore ?? null) as number | null,
              coverLetter: (a.coverLetter ?? null) as string | null,
              skills: (a.skills ?? []) as string[],
              createdAt: (a.createdAt || new Date().toISOString()) as string,
              rating: (a.rating ?? null) as number | null,
              applicantSnapshot: (a.applicantSnapshot ?? null) as SnapshotData | null,
              matchDetails: (a.matchDetails ?? null) as MatchDetail[] | null,
              _count: a._count as Applicant['_count'],
            }))
          : []
        setApplications(apps)
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في تحميل البيانات', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [jobId, toast])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  // Group applications by stage
  const filteredApps = useMemo(() => {
    let result = applications

    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      result = result.filter(
        (a) =>
          (a.applicant?.name || '').toLowerCase().includes(q) ||
          a.skills?.some((s) => s.toLowerCase().includes(q)) ||
          (a.applicantSnapshot?.jobTitle || '').toLowerCase().includes(q) ||
          (a.applicantSnapshot?.location || '').toLowerCase().includes(q)
      )
    }

    if (skillFilter) {
      result = result.filter((a) =>
        a.skills?.some((s) => s.includes(skillFilter))
      )
    }

    if (scoreFilter !== 'all') {
      result = result.filter((a) => {
        const score = a.matchScore ?? 0
        switch (scoreFilter) {
          case 'high': return score >= 70
          case 'medium': return score >= 40 && score < 70
          case 'low': return score < 40
          default: return true
        }
      })
    }

    return result
  }, [applications, searchQuery, skillFilter, scoreFilter])

  const appsByStage = useMemo(() => {
    const map: Record<string, Applicant[]> = {}
    for (const stage of PIPELINE_STAGES) {
      map[stage.key] = filteredApps.filter((a) => a.stage === stage.key)
    }
    return map
  }, [filteredApps])

  // Stats
  const totalApps = applications.length
  const avgScore = totalApps > 0
    ? Math.round(applications.reduce((s, a) => s + (a.matchScore || 0), 0) / totalApps)
    : 0
  const hiredCount = applications.filter((a) => a.stage === 'HIRED').length
  const hireRate = totalApps > 0 ? Math.round((hiredCount / totalApps) * 100) : 0

  // All unique skills for filter
  const allSkills = useMemo(() => {
    const set = new Set<string>()
    applications.forEach((a) => a.skills?.forEach((s) => set.add(s)))
    return Array.from(set).sort()
  }, [applications])

  // Move stage
  const handleMoveStage = async (applicationId: string, newStage: string) => {
    setMovingId(applicationId)
    try {
      const res = await fetch(`/api/jobs/${jobId}/pipeline`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ applicationId, stage: newStage }),
      })
      if (res.ok) {
        setApplications((prev) =>
          prev.map((a) =>
            a.id === applicationId ? { ...a, stage: newStage, pipelineStage: newStage } : a
          )
        )
        const stageLabel = PIPELINE_STAGES.find((s) => s.key === newStage)?.labelAr || newStage
        toast({ title: 'تم النقل', description: `تم نقل المتقدم إلى: ${stageLabel}` })
      } else {
        throw new Error()
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في نقل المتقدم', variant: 'destructive' })
    } finally {
      setMovingId(null)
    }
  }

  // Add note
  const handleOpenNote = (appId: string, name: string) => {
    setNoteAppId(appId)
    setNoteAppName(name)
    setNoteText('')
    setNoteDialogOpen(true)
  }

  const handleSaveNote = async () => {
    if (!noteAppId || !noteText.trim()) return
    setNoteSaving(true)
    try {
      const res = await fetch(`/api/jobs/${jobId}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ applicationId: noteAppId, content: noteText.trim() }),
      })
      if (res.ok) {
        toast({ title: 'تم الحفظ', description: 'تم إضافة الملاحظة بنجاح' })
        setNoteDialogOpen(false)
      } else {
        throw new Error()
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في حفظ الملاحظة', variant: 'destructive' })
    } finally {
      setNoteSaving(false)
    }
  }

  // Rate
  const handleRate = async (applicationId: string, rating: number) => {
    try {
      const res = await fetch(`/api/jobs/${jobId}/pipeline`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ applicationId, rating }),
      })
      if (res.ok) {
        setApplications((prev) =>
          prev.map((a) =>
            a.id === applicationId ? { ...a, rating } : a
          )
        )
        toast({ title: 'تم التقييم', description: `تم تقييم المتقدم: ${rating}/5` })
      }
    } catch {
      toast({ title: 'خطأ', description: 'فشل في التقييم', variant: 'destructive' })
    }
  }

  // View profile
  const handleViewProfile = (applicant: Applicant) => {
    setProfileApplicant(applicant)
    setProfileDialogOpen(true)
  }

  if (loading) return <KanbanSkeleton />

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Link href="/jobs/employer/applicants" className="hover:text-foreground transition-colors">
          المتقدمين
        </Link>
        <ChevronLeft className="size-3.5" />
        <span className="text-foreground font-medium truncate">{job?.title}</span>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-3 gap-3">
        <GlassCard variant="flat" size="sm" className="text-center">
          <p className="text-xl font-bold">{totalApps}</p>
          <p className="text-2xs text-muted-foreground">إجمالي المتقدمين</p>
        </GlassCard>
        <GlassCard variant="flat" size="sm" className="text-center">
          <p className="text-xl font-bold">{avgScore}%</p>
          <p className="text-2xs text-muted-foreground">متوسط التوافق</p>
        </GlassCard>
        <GlassCard variant="flat" size="sm" className="text-center">
          <p className="text-xl font-bold text-green-500">{hireRate}%</p>
          <p className="text-2xs text-muted-foreground">معدل التوظيف</p>
        </GlassCard>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
        <div className="relative flex-1 w-full sm:max-w-xs">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="ابحث بالاسم أو المهارة أو الموقع..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="ps-9 h-9 text-sm"
          />
        </div>
        {allSkills.length > 0 && (
          <Select value={skillFilter} onValueChange={(v) => setSkillFilter(v === '__all__' ? '' : v)}>
            <SelectTrigger className="w-full sm:w-40 h-9 text-sm">
              <SelectValue placeholder="تصفية المهارات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">كل المهارات</SelectItem>
              {allSkills.map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        <Select value={scoreFilter} onValueChange={(v) => setScoreFilter(v as typeof scoreFilter)}>
          <SelectTrigger className="w-full sm:w-36 h-9 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الدرجات</SelectItem>
            <SelectItem value="high">عالي (70%+)</SelectItem>
            <SelectItem value="medium">متوسط (40-69%)</SelectItem>
            <SelectItem value="low">منخفض (&lt;40%)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Mobile Stage Selector */}
      <div className="md:hidden">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
          {PIPELINE_STAGES.map((stage) => (
            <button
              key={stage.key}
              onClick={() => setMobileStage(stage.key)}
              className={cn(
                'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-all',
                mobileStage === stage.key
                  ? 'bg-red-500/10 text-red-600 dark:bg-red-500/20 dark:text-red-400'
                  : 'bg-accent/30 text-muted-foreground'
              )}
            >
              <span className={cn('size-2 rounded-full', stage.dotColor)} />
              {stage.labelAr}
              <Badge variant="secondary" size="xs">{appsByStage[stage.key]?.length || 0}</Badge>
            </button>
          ))}
        </div>
      </div>

      {/* Kanban Board - Desktop */}
      <div className="hidden md:flex gap-3 overflow-x-auto pb-4">
        {PIPELINE_STAGES.map((stage) => (
          <KanbanColumn
            key={stage.key}
            stage={stage}
            applicants={appsByStage[stage.key] || []}
            stages={PIPELINE_STAGES}
            jobId={jobId}
            onMoveStage={handleMoveStage}
            onAddNote={handleOpenNote}
            onRate={handleRate}
            onViewProfile={handleViewProfile}
          />
        ))}
      </div>

      {/* Kanban Board - Mobile (single column) */}
      <div className="md:hidden space-y-3">
        {(() => {
          const stage = PIPELINE_STAGES.find((s) => s.key === mobileStage)
          if (!stage) return null
          return (
            <KanbanColumn
              stage={stage}
              applicants={appsByStage[stage.key] || []}
              stages={PIPELINE_STAGES}
              jobId={jobId}
              onMoveStage={handleMoveStage}
              onAddNote={handleOpenNote}
              onRate={handleRate}
              onViewProfile={handleViewProfile}
            />
          )
        })()}
      </div>

      {/* Note Dialog */}
      <Dialog open={noteDialogOpen} onOpenChange={setNoteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquarePlus className="size-5 text-red-500" />
              إضافة ملاحظة
            </DialogTitle>
            <DialogDescription>
              أضف ملاحظة لـ {noteAppName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Label htmlFor="note-text">الملاحظة</Label>
            <Textarea
              id="note-text"
              placeholder="اكتب ملاحظتك هنا..."
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              rows={4}
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setNoteDialogOpen(false)}
              disabled={noteSaving}
            >
              إلغاء
            </Button>
            <Button
              onClick={handleSaveNote}
              disabled={noteSaving || !noteText.trim()}
              className="gap-2"
            >
              {noteSaving ? 'جاري الحفظ...' : 'حفظ الملاحظة'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Applicant Profile / CV Dialog */}
      <ApplicantProfileDialog
        applicant={profileApplicant}
        open={profileDialogOpen}
        onClose={() => setProfileDialogOpen(false)}
      />
    </div>
  )
}