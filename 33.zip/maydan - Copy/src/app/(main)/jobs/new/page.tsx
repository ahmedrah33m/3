'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import JobCreationForm from '@/components/jobs/JobCreationForm'

export default function CreateJobPage() {
  const router = useRouter()
  const [created, setCreated] = useState(false)

  const handleSuccess = (job: any) => {
    setCreated(true)
    setTimeout(() => {
      router.push(`/jobs/${job.id}`)
    }, 1500)
  }

  const handleCancel = () => {
    router.push('/jobs')
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <JobCreationForm
        onSuccess={handleSuccess}
        onCancel={handleCancel}
      />
    </div>
  )
}