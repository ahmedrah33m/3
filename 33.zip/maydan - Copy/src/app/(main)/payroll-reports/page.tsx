'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PayrollTable, formatCurrency } from '@/components/payroll/payroll-ui';
import { BarChart3, PieChart, TrendingUp, Download } from 'lucide-react';

interface PayrollReportsData {
  monthly: Array<{
    id: string;
    name: string;
    totalNet: number;
    totalGross: number;
    totalEmployees: number;
  }>;
  department: Array<{
    name: string;
    count: number;
    totalNet: number;
  }>;
}

export default function PayrollReportsPage() {
  const [reportPeriod, setReportPeriod] = useState<string>('monthly');

  const { data, isLoading } = useQuery({
    queryKey: ['payroll-reports', reportPeriod],
    queryFn: async () => {
      const res = await fetch(`/api/payroll/reports?companyId=comp-1&type=${reportPeriod}`);
      return res.json();
    },
  });

  const reportsData: PayrollReportsData = data || { monthly: [], department: [] };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">تقارير الرواتب</h1>
        <Button variant="outline">
          <Download className="ml-2 h-4 w-4" />
          تصدير التقرير
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الرواتب الشهرية</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(reportsData.monthly.reduce((sum, m) => sum + m.totalNet, 0))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">عدد الأقسام</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reportsData.department.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">متوسط الراتب</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(
                reportsData.monthly.length > 0
                  ? reportsData.monthly.reduce((sum, m) => sum + m.totalNet, 0) /
                      reportsData.monthly.reduce((sum, m) => sum + m.totalEmployees, 0) || 0
                  : 0
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="monthly" className="w-full">
        <TabsList>
          <TabsTrigger value="monthly">شهري</TabsTrigger>
          <TabsTrigger value="department">حسب القسم</TabsTrigger>
        </TabsList>

        <TabsContent value="monthly">
          <Card>
            <CardHeader>
              <CardTitle>تقرير الرواتب الشهري</CardTitle>
            </CardHeader>
            <CardContent>
              <PayrollTable
                headers={['التشغيل', 'عدد الموظفين', 'الإجمالي الصافي', 'الإجمالي الكلي']}
                emptyMessage="لا توجد بيانات"
              >
                {reportsData.monthly.map((run) => (
                  <tr key={run.id} className="border-b transition-colors hover:bg-muted/50">
                    <td className="p-4 align-middle">{run.name}</td>
                    <td className="p-4 align-middle">{run.totalEmployees}</td>
                    <td className="p-4 align-middle font-bold">{formatCurrency(run.totalNet)}</td>
                    <td className="p-4 align-middle">{formatCurrency(run.totalGross)}</td>
                  </tr>
                ))}
              </PayrollTable>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="department">
          <Card>
            <CardHeader>
              <CardTitle>تقرير الأقسام</CardTitle>
            </CardHeader>
            <CardContent>
              <PayrollTable
                headers={['القسم', 'عدد الموظفين', 'إجمالي الرواتب']}
                emptyMessage="لا توجد بيانات"
              >
                {reportsData.department.map((dept) => (
                  <tr key={dept.name} className="border-b transition-colors hover:bg-muted/50">
                    <td className="p-4 align-middle">{dept.name}</td>
                    <td className="p-4 align-middle">{dept.count}</td>
                    <td className="p-4 align-middle font-bold">{formatCurrency(dept.totalNet)}</td>
                  </tr>
                ))}
              </PayrollTable>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
