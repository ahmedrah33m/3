import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /owner مكرر تمامًا لـ /owner-panel — نُوجّه إلى /owner-panel */
export default function OwnerPage() {
  redirect('/owner-panel')
}