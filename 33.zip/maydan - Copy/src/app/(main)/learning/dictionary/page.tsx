'use client'

/**
 * القاموس الاقتصادي — توجيه إلى صفحة /dictionary الموجودة
 */

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function LearningDictionaryPage() {
  const router = useRouter()

  useEffect(() => {
    // توجيه إلى صفحة القاموس الموجودة
    router.replace('/dictionary')
  }, [router])

  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
    </div>
  )
}
