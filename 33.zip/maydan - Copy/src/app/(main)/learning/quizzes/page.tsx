'use client'

/**
 * الاختبارات — توجيه إلى صفحة /quizzes الموجودة (للتوافق مع البنية الحالية)
 * سيتم تحديثها لاحقًا لعرضها بشكل مستقل ضمن /learning
 */

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function LearningQuizzesPage() {
  const router = useRouter()

  useEffect(() => {
    // توجيه إلى صفحة الاختبارات الموجودة
    router.replace('/quizzes')
  }, [router])

  return (
    <div className="flex items-center justify-center py-20">
      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" />
    </div>
  )
}
