'use client'

import { useParams } from 'next/navigation'
import LearningPathDetail from '@/components/education/LearningPathDetail'

export default function LearningPathPage() {
  const params = useParams()
  const id = params.id as string

  return (
    <div className="max-w-5xl mx-auto">
      <LearningPathDetail pathId={id} onBack={() => {
        window.location.href = '/learning'
      }} />
    </div>
  )
}
