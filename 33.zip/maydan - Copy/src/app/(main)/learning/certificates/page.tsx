'use client'

/**
 * الشهادات — تعرض MidanAcademyView مع التركيز على tab الشهادات
 */

import dynamic from 'next/dynamic'
import { Skeleton } from '@/components/ui/skeleton'

const MidanAcademyView = dynamic(() => import('@/components/MidanAcademyView'), {
  ssr: false,
  loading: () => (
    <div className="space-y-4">
      <Skeleton className="h-8 w-48" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    </div>
  ),
})

export default function LearningCertificatesPage() {
  return (
    <div className="max-w-7xl mx-auto">
      <MidanAcademyView initialTab="certificates" />
    </div>
  )
}
