import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /learning مكرر لـ /academy — نُوجّه إلى /academy */
export default function LearningPage() {
  redirect('/academy')
}