import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'المسارات التعليمية | ميدان',
  description: 'مسارات تعليمية منظمة في الاقتصاد والأعمال. تعلّم خطوة بخطوة مع ميدان.',
  openGraph: {
    title: 'المسارات التعليمية | ميدان',
    description: 'مسارات تعليمية منظمة في الاقتصاد والأعمال. تعلّم خطوة بخطوة مع ميدان.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/learning`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'المسارات التعليمية | ميدان',
    description: 'مسارات تعليمية منظمة في الاقتصاد والأعمال. تعلّم خطوة بخطوة مع ميدان.',
  },
  alternates: {
    canonical: `${SITE_URL}/learning`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
