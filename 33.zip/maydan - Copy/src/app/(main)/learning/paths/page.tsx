import { redirect } from 'next/navigation'

export const dynamic = 'force-dynamic'

/** /learning/paths كان يعرض MidanAcademyView مع initialTab="courses" وهو التبويب الافتراضي لـ /academy — نُوجّه إليه */
export default function LearningPathsPage() {
  redirect('/academy')
}