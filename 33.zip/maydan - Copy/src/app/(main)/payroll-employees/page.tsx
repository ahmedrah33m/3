'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PayrollTable, PayrollStatusBadge, formatCurrency } from '@/components/payroll/payroll-ui';
import { Search, UserPlus, Eye, FileText, MoreHorizontal } from 'lucide-react';

interface PayrollEmployeesData {
  employees: Array<{
    id: string;
    employeeNumber: string;
    jobTitle: string;
    status: string;
    userId: string | null;
    salary: number;
    startDate: string;
  }>;
}

export default function PayrollEmployeesPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');

  const { data, isLoading } = useQuery({
    queryKey: ['payroll-employees', search, statusFilter],
    queryFn: async () => {
      const res = await fetch(`/api/payroll/employees?search=${search}&status=${statusFilter}`);
      return res.json();
    },
  });

  const employeesData: PayrollEmployeesData = data || { employees: [] };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">الموظفون</h1>
        <Button>
          <UserPlus className="ml-2 h-4 w-4" />
          إضافة موظف
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="بحث عن موظف..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
        <select
          className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">كل الحالات</option>
          <option value="ACTIVE">نشط</option>
          <option value="ON_LEAVE">في إجازة</option>
          <option value="TERMINATED">منتهي</option>
        </select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>قائمة الموظفين ({employeesData.employees.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <PayrollTable
            headers={['الرقم', 'المستخدم', 'المسمى', 'الراتب', 'الحالة', 'إجراءات']}
            emptyMessage="لا يوجد موظفون"
          >
            {employeesData.employees.map((emp) => (
              <tr key={emp.id} className="border-b transition-colors hover:bg-muted/50">
                <td className="p-4 align-middle font-mono text-xs">{emp.employeeNumber || '—'}</td>
                <td className="p-4 align-middle font-medium">{emp.userId || '—'}</td>
                <td className="p-4 align-middle">{emp.jobTitle || '—'}</td>
                <td className="p-4 align-middle">{formatCurrency(emp.salary || 0)}</td>
                <td className="p-4 align-middle">
                  <PayrollStatusBadge status={emp.status} />
                </td>
                <td className="p-4 align-middle">
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <FileText className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </PayrollTable>
        </CardContent>
      </Card>
    </div>
  );
}