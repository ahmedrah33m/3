import HashtagView from '@/components/HashtagView'

interface PageProps {
  params: Promise<{ tag: string }>
}

export default async function TagPage({ params }: PageProps) {
  const { tag } = await params
  return <HashtagView tag={decodeURIComponent(tag)} />
}
