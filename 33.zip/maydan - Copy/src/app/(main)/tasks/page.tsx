'use client'

import TaskPanel from '@/components/TaskPanel'
import { CheckSquare } from 'lucide-react'

export default function TaskCenterPage() {
  return (
    <div className="max-w-5xl mx-auto space-y-4">
      <div className="flex items-center gap-2">
        <CheckSquare className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">مركز المهام</h1>
          <p className="text-muted-foreground text-sm">نظام مهام موحّد عبر الشركات، التوظيف، الاستشارات، الأبحاث والاستثمار</p>
        </div>
      </div>
      <TaskPanel />
    </div>
  )
}
