'use client'

import RecommendationEngine from '@/components/RecommendationEngine'

export default function RecommendationEnginePage() {
  return <RecommendationEngine />
}
