'use client'

import { useState } from 'react'
import { useI18n } from "@/lib/i18n"
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { BookOpen, Brain, Search } from 'lucide-react'
import LearningPaths from '@/components/education/LearningPaths'
import LearningPathDetail from '@/components/education/LearningPathDetail'
import Quizzes, { QuizPlayer } from '@/components/education/Quizzes'
import EconomicDictionary from '@/components/education/EconomicDictionary'

export default function LearnPage() {
  const [selectedPathId, setSelectedPathId] = useState<string | null>(null)
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null)

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <BookOpen className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">مركز التعلم</h1>
          <p className="text-sm text-muted-foreground">تعلم أساسيات الاقتصاد العراقي من خلال المسارات التعليمية والاختبارات والقاموس</p>
        </div>
      </div>

      {selectedPathId ? (
        <LearningPathDetail
          pathId={selectedPathId}
          onBack={() => setSelectedPathId(null)}
        />
      ) : selectedQuizId ? (
        <QuizPlayer
          quizId={selectedQuizId}
          onFinish={() => setSelectedQuizId(null)}
        />
      ) : (
        <Tabs defaultValue="paths">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="paths" className="gap-1 text-xs">
              <BookOpen className="h-3.5 w-3.5" />مسارات تعلم
            </TabsTrigger>
            <TabsTrigger value="quizzes" className="gap-1 text-xs">
              <Brain className="h-3.5 w-3.5" />اختبارات معرفية
            </TabsTrigger>
            <TabsTrigger value="dictionary" className="gap-1 text-xs">
              <Search className="h-3.5 w-3.5" />القاموس الاقتصادي
            </TabsTrigger>
          </TabsList>

          <TabsContent value="paths" className="mt-6">
            <LearningPaths onSelectPath={(path) => setSelectedPathId(path.id)} />
          </TabsContent>

          <TabsContent value="quizzes" className="mt-6">
            <Quizzes onStartQuiz={(id) => setSelectedQuizId(id)} />
          </TabsContent>

          <TabsContent value="dictionary" className="mt-6">
            <EconomicDictionary onTermClick={() => {}} />
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
