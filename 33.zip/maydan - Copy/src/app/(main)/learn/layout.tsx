import type { Metadata } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'
const SITE_NAME = 'ميدان الاقتصاد'

export const metadata: Metadata = {
  title: 'تعلّم | ميدان',
  description: 'مصادر تعليمية في الاقتصاد والأعمال. تعلّم من خبراء ومتخصصين عراقيين.',
  openGraph: {
    title: 'تعلّم | ميدان',
    description: 'مصادر تعليمية في الاقتصاد والأعمال. تعلّم من خبراء ومتخصصين عراقيين.',
    type: 'website',
    locale: 'ar_IQ',
    url: `${SITE_URL}/learn`,
    siteName: SITE_NAME,
  },
  twitter: {
    card: 'summary',
    title: 'تعلّم | ميدان',
    description: 'مصادر تعليمية في الاقتصاد والأعمال. تعلّم من خبراء ومتخصصين عراقيين.',
  },
  alternates: {
    canonical: `${SITE_URL}/learn`,
  },
}

export default function PageLayout({ children }: { children: React.ReactNode }) {
  return children
}
