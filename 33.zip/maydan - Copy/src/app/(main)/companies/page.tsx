'use client'

import { useState, useEffect, useCallback } from 'react'
import { buildSrcSet } from '@/lib/image-url'
import { Search, Building2, MapPin, Users, Briefcase, BadgeCheck, ChevronLeft, SlidersHorizontal } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import Link from 'next/link'

const SIZE_LABELS: Record<string, string> = {
  STARTUP: 'ناشئة',
  SMALL: 'صغيرة',
  MEDIUM: 'متوسطة',
  LARGE: 'كبيرة',
  ENTERPRISE: 'مؤسسة كبيرة',
}

const INDUSTRIES = [
  'all', 'تكنولوجيا', 'مالية', 'نفط وغاز', 'بناء وتشييد', 'صحة', 'تعليم', 'تجارة', 'صناعة', 'اتصالات', 'زراعة', 'سياحة',
]

const SIZES = ['all', 'STARTUP', 'SMALL', 'MEDIUM', 'LARGE', 'ENTERPRISE']

interface Company {
  id: string
  name: string
  logo: string | null
  banner: string | null
  industry: string | null
  size: string | null
  headquarterLocation: string | null
  employeeCount: number | null
  verified: boolean
  jobCount: number
  owner: { id: string; name: string | null; avatar: string | null }
  createdAt: string
}

export default function CompaniesPage() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [industry, setIndustry] = useState('all')
  const [size, setSize] = useState('all')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [total, setTotal] = useState(0)

  const fetchCompanies = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(page), limit: '12' })
      if (search) params.set('search', search)
      if (industry !== 'all') params.set('industry', industry)
      if (size !== 'all') params.set('size', size)

      const res = await fetch(`/api/companies?${params}`)
      const data = await res.json()
      if (data.success) {
        setCompanies(data.companies)
        setTotalPages(data.pages)
        setTotal(data.total)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [search, industry, size, page])

  useEffect(() => {
    fetchCompanies()
  }, [fetchCompanies])

  const handleSearch = (value: string) => { setSearch(value); setPage(1) }
  const handleIndustryChange = (value: string) => { setIndustry(value); setPage(1) }
  const handleSizeChange = (value: string) => { setSize(value); setPage(1) }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            الشركات
          </h1>
          {total > 0 && (
            <p className="text-sm text-muted-foreground mt-1">{total} شركة مسجلة</p>
          )}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="ابحث عن شركة..."
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
            className="ps-10 text-start"
          />
        </div>

        <div className="flex flex-wrap gap-3 items-center">
          <Select value={size} onValueChange={handleSizeChange}>
            <SelectTrigger className="w-40">
              <SlidersHorizontal className="h-4 w-4 ms-2" />
              <SelectValue placeholder="حجم الشركة" />
            </SelectTrigger>
            <SelectContent>
              {SIZES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s === 'all' ? 'كل الأحجام' : SIZE_LABELS[s] || s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
          {INDUSTRIES.map((ind) => (
            <button
              key={ind}
              onClick={() => handleIndustryChange(ind)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                industry === ind
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              {ind === 'all' ? 'الكل' : ind}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-24 w-full" />
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <Skeleton className="h-3 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : companies.length === 0 ? (
        <div className="text-center py-16">
          <Building2 className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">لا توجد شركات</h3>
          <p className="text-sm text-muted-foreground/70 mt-1">لم يتم العثور على نتائج تطابق بحثك</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {companies.map((company) => (
              <Link key={company.id} href={`/companies/${company.id}`}>
                <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer group h-full">
                  <div className="h-24 bg-gradient-to-l from-primary/10 to-primary/5 relative overflow-hidden">
                    {company.banner ? (
                      <img src={company.banner} alt="" srcSet={buildSrcSet(company.banner) || undefined} sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw" decoding="async" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Building2 className="h-8 w-8 text-primary/20" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3 -mt-8">
                      <div className="relative">
                        {company.logo ? (
                          <img src={company.logo} alt={company.name} srcSet={buildSrcSet(company.logo, [48, 96, 192, 384]) || undefined} sizes="56px" decoding="async" loading="lazy" className="h-14 w-14 rounded-xl border-2 border-background object-cover shadow-sm" />
                        ) : (
                          <div className="h-14 w-14 rounded-xl border-2 border-background bg-secondary flex items-center justify-center shadow-sm">
                            <Building2 className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                        {company.verified && (
                          <div className="absolute -bottom-1 -left-1 bg-background rounded-full p-0.5">
                            <BadgeCheck className="h-4 w-4 text-emerald-500" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0 pt-6">
                        <h3 className="font-semibold text-foreground truncate text-sm">{company.name}</h3>
                        <p className="text-xs text-muted-foreground truncate mt-0.5">{company.industry || 'لم تحدد المجال'}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mt-3">
                      {company.size && (
                        <Badge variant="secondary" size="xs">{SIZE_LABELS[company.size] || company.size}</Badge>
                      )}
                      {company.headquarterLocation && (
                        <Badge variant="outline" size="xs">
                          <MapPin className="h-3 w-3 ms-0.5" />
                          {company.headquarterLocation}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Briefcase className="h-3.5 w-3.5" />
                        {company.jobCount} وظيفة
                      </span>
                      {company.employeeCount && (
                        <span className="flex items-center gap-1">
                          <Users className="h-3.5 w-3.5" />
                          {company.employeeCount} موظف
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {totalPages > 1 && (
            <div className="flex justify-center gap-2 pt-4">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                <ChevronLeft className="h-4 w-4" />
                السابق
              </Button>
              <span className="flex items-center px-3 text-sm text-muted-foreground">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                التالي
                <ChevronLeft className="h-4 w-4 rotate-180" />
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}
