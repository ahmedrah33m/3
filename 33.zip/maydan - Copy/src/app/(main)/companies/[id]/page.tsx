import { notFound } from 'next/navigation'
import { optionalAuth } from '@/lib/session'
import { getCompanyProfile } from '@/services/employer-branding.service'
import CompanyPublicProfile from '@/components/CompanyPublicProfile'

export default async function CompanyProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  let profile
  try { profile = await getCompanyProfile(id) } catch { notFound() }
  const user = await optionalAuth()
  const isOwner = !!user && user.id === profile.company.ownerId
  return (
    <div className="max-w-4xl mx-auto py-6" dir="rtl">
      {isOwner && <a href={`/companies/${id}/manage`} className="inline-block mb-3 text-sm text-indigo-600">إدارة صفحة صاحب العمل ←</a>}
      <CompanyPublicProfile companyId={id} initialProfile={profile} isOwner={isOwner} />
    </div>
  )
}
