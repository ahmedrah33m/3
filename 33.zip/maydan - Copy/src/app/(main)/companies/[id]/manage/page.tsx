import { notFound } from 'next/navigation'
import { optionalAuth } from '@/lib/session'
import { getCompanyProfile } from '@/services/employer-branding.service'
import { getLifecycleState } from '@/services/lifecycle.service'
import EmployerBrandManager from '@/components/EmployerBrandManager'
import LifecycleControl from '@/components/LifecycleControl'

export default async function CompanyManagePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  let profile
  try { profile = await getCompanyProfile(id) } catch { notFound() }
  const user = await optionalAuth()
  if (!user || user.id !== profile.company.ownerId) notFound()
  const current = await getLifecycleState('company', id)
  return (
    <div className="max-w-3xl mx-auto py-6" dir="rtl">
      <h1 className="text-2xl font-bold mb-2">إدارة صفحة صاحب العمل: {profile.company.name}</h1>
      <div className="mb-4 p-3 border rounded">
        <div className="text-sm text-gray-500 mb-1">دورة حياة الكيان (Lifecycle)</div>
        <LifecycleControl entity="company" id={id} current={current} />
      </div>
      <EmployerBrandManager companyId={id} initialProfile={profile} />
    </div>
  )
}
