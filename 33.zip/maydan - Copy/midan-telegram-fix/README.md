# إصلاح خطأ Telegram: "Forbidden: bot can't send messages to bot"

## 🎯 المشكلة

عند محاولة إرسال رسالة اختبار من لوحة النشر التلقائي، يظهر الخطأ:

```
فشل إرسال الرسالة: Forbidden: the bot can't send messages to the bot
```

## 🔍 السبب الجذري

هذا الخطأ يحدث عندما يكون `chat_id` (المعرّف) الذي أدخلته في إعدادات القناة يخص **بوت آخر** وليس قناة (Channel).

**منطق تيليجرام:**
- ✅ البوت يمكنه إرسال رسائل إلى: القنوات (Channels)، المجموعات (Groups)، والمحادثات الخاصة مع المستخدمين
- ❌ البوت **لا يمكنه** إرسال رسائل إلى بوت آخر (بما في ذلك نفسه)

**الأسباب الشائعة:**
1. أدخل المستخدم `@SomeBotName` بدلاً من `@ChannelName` في حقل المعرّف
2. أدخل المستخدم معرّف البوت نفسه (chat_id موجب)
3. حاول المستخدم استخدام البوت لإرسال رسائل لنفسه

## ✅ الحل

### الحل العاجل (دون تعديل الكود)

افتح **لوحة الإدارة ← النشر التلقائي ← تعديل القناة**، وفي حقل **"المعرّف"** أدخل أحد الخيارات التالية:

| نوع القناة | الصيغة الصحيحة | مثال |
|---|---|---|
| قناة عامة | `@channel_username` | `@midan_jobs` |
| قناة خاصة | `-1001234567890` | `-1001234567890` |
| مجموعة | `-123456789` | `-123456789` |

**⚠️ تجنب:**
- ❌ `@SomeBotName` — بوت، ليس قناة
- ❌ `123456789` (موجب) — محادثة خاصة، البوت لا يمكنه بدءها
- ❌ `@YourOwnBotName` — البوت نفسه

### الحل الدائم (مع تعديل الكود)

طبّق هذا الإصلاح للحصول على:

1. **كشف فوري** عند إدخال معرّف بوت في حقل القناة (UI warning)
2. **تحقق قبل الإرسال** — يفحص الـ chat_id قبل استدعاء API تيليجرام
3. **رسائل خطأ عربية واضحة** — تشرح السبب والحل لكل خطأ
4. **فحص `getMe`** للتأكد من صحة Bot Token قبل الإرسال
5. **منع حفظ معرّفات غير صالحة** — التحقق قبل بدء الإرسال

---

## 📁 الملفات المُعدَّلة

```
midan-telegram-fix/
├── src/
│   ├── lib/
│   │   ├── telegram.ts                          ← مُحدَّث (إضافات: validateChannelId, verifyBotToken, translateTelegramError)
│   │   └── auto-publish-service.ts              ← مُحدَّث (testChannelConnection مع كشف البوت)
│   ├── app/
│   │   └── api/admin/auto-publish/
│   │       └── test/
│   │           └── route.ts                     ← مُحدَّث (تحقق قبل الإرسال + رسائل عربية)
│   └── components/
│       └── admin/
│           └── AutoPublishDashboard.tsx         ← مُحدَّث (warning فوري في الـ form)
└── README.md                                    ← هذا الملف
```

---

## 🚀 خطوات التطبيق

### الطريقة 1: استبدال الملفات مباشرة

```bash
# في جذر مشروعك
cd /path/to/your/project

# انسخ الملفات من هذه الحزمة إلى المسارات المناسبة:
cp src/lib/telegram.ts                          src/lib/telegram.ts
cp src/lib/auto-publish-service.ts              src/lib/auto-publish-service.ts
cp src/app/api/admin/auto-publish/test/route.ts src/app/api/admin/auto-publish/test/route.ts
cp src/components/admin/AutoPublishDashboard.tsx src/components/admin/AutoPublishDashboard.tsx

# أعد تشغيل خادم التطوير
npm run dev
```

### الطريقة 2: فك الضغط فوق المشروع

```bash
cd /path/to/your/project
unzip -o midan-telegram-fix.zip
npm run dev
```

---

## 🧪 الاختبار بعد التطبيق

### سيناريو 1: إدخال معرّف بوت (خطأ)

1. افتح لوحة الإدارة ← النشر التلقائي ← تعديل القناة
2. في حقل المعرّف، أدخل: `@some_bot_name` (ينتهي بـ "bot")
3. **النتيجة المتوقعة:**
   - إطار أحمر يظهر حول الحقل فوراً
   - رسالة تحذير: "⚠️ تحذير: هذا المعرّف يبدو أنه بوت وليس قناة!"
   - شرح الخطأ والحل

### سيناريو 2: إدخال معرّف قناة صحيح

1. في حقل المعرّف، أدخل: `@your_channel_name`
2. **النتيجة المتوقعة:**
   - رسالة خضراء: "✓ الصيغة تبدو صحيحة"
3. اضغط "اختبار الاتصال"
4. **النتيجة المتوقعة:**
   - "✅ متصل بنجاح: @your_bot_name"

### سيناريو 3: إرسال رسالة اختبار

1. بعد التأكد من الاتصال، اضغط "إرسال رسالة اختبار"
2. **النتيجة المتوقعة:**
   - رسالة في قناتك: "【رسالة اختبار】مطور واجهات أمامية..."
   - في الـ UI: "✅ تم إرسال رسالة اختبار بنجاح"

---

## 📋 الميزات الجديدة

### 1. `validateChannelId(chatId: string)`

دالة تتحقق من صحة معرّف القناة وترجع:
- `valid: boolean` — هل المعرّف صالح؟
- `type: 'public_channel' | 'private_channel' | 'private_chat' | 'group' | 'bot' | 'unknown' | 'empty'`
- `message: string` — وصف بالعربية
- `suggestion?: string` — اقتراح للحل

**أمثلة:**

```typescript
validateChannelId('@midan_jobs')
// → { valid: true, type: 'public_channel', message: 'قناة عامة: @midan_jobs' }

validateChannelId('@midan_bot')
// → { valid: false, type: 'bot', message: 'المعرّف "@midan_bot" يبدو أنه بوت وليس قناة...',
//     suggestion: 'استخدم معرّف قناة (Channel) وليس بوت. أنشئ قناة من تيليجرام: New Channel.' }

validateChannelId('-1001234567890')
// → { valid: true, type: 'private_channel', message: 'قناة/مجموعة خاصة: -1001234567890' }

validateChannelId('123456789')
// → { valid: false, type: 'private_chat', message: 'المعرّف "123456789" هو محادثة خاصة (رقم موجب)...' }
```

### 2. `verifyBotToken(token: string)`

دالة تفحص الـ Token عبر `getMe` API:
- `ok: boolean`
- `botInfo?: { id, username, first_name }`
- `error?: string` — رسالة عربية

### 3. `translateTelegramError(description: string, chatId?: string)`

دالة تترجم رسائل خطأ تيليجرام الشائعة للعربية:

| الخطأ الأصلي | الترجمة |
|---|---|
| `Forbidden: bot can't send messages to bots` | شرح كامل بالعربية مع الحل |
| `Chat not found` | "القناة غير موجودة" + شرح |
| `Not enough rights` | "البوت ليس مسؤولاً في القناة" + خطوات الإصلاح |
| `Unauthorized` | "Bot Token غير صالح" |
| `Too many requests` | "تجاوز حد الإرسال" + شرح |

### 4. UI Warning في الـ Form

عند كتابة معرّف ينتهي بـ "bot" في حقل القناة:
- إطار أحمر حول الحقل
- صندوق تحذير أحمر يشرح المشكلة
- عندما يكون المعرّف صحيحاً: رسالة خضراء "✓ الصيغة تبدو صحيحة"

### 5. خطوات إعداد أوضح

تم تحديث خطوات الإعداد في الـ UI لتشمل:
- ⚠️ تحذير صريح: "لا تستخدم معرّف بوت هنا"
- خطوة واضحة: "أنشئ قناة جديدة (New Channel)"
- خطوة واضحة: "أضف البوت كمدير في القناة"

---

## 🔧 استكشاف أخطاء إضافية

### الخطأ: "❌ Bot Token غير صالح أو منتهي الصلاحية"

**السبب:** الـ Token خاطئ أو تم إبطاله.
**الحل:**
1. افتح تيليجرام، ابحث عن `@BotFather`
2. أرسل `/mybots`
3. اختر البوت الخاص بك
4. اضغط `API Token` ← `Revoke current token`
5. انسخ الـ Token الجديد وأدخله في لوحة الإدارة

### الخطأ: "❌ البوت ليس مسؤولاً في القناة"

**السبب:** البوت لم يُضَف كمدير في القناة.
**الحل:**
1. افتح قناتك في تيليجرام
2. اضغط على اسم القناة ← `Administrators` ← `Add Admin`
3. ابحث عن اسم البوت الخاص بك
4. أضفه مع صلاحية `Post Messages`

### الخطأ: "❌ القناة غير موجودة"

**السبب:** اسم القناة خاطئ أو البوت ليس عضواً.
**الحل:**
- تأكد من كتابة اسم القناة بشكل صحيح (مع @)
- تأكد من أن البوت عضو في القناة

---

## 📚 كيف تحصل على Chat ID لقناة خاصة؟

1. أضف البوت كمدير في القناة
2. أرسل أي رسالة في القناة
3. افتح في المتصفح:
   ```
   https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates
   ```
4. ابحث في الاستجابة عن `"chat":{"id":-100xxxxxxxxxx"`
5. انسخ الرقم السالب كاملاً (يبدأ بـ `-100`)
6. استخدمه في حقل المعرّف

---

## 🎯 ملخص

قبل الإصلاح:
- ❌ خطأ غامض: "Forbidden: the bot can't send messages to the bot"
- ❌ المستخدم لا يعرف السبب
- ❌ لا توجد طريقة لكشف المشكلة قبل الإرسال

بعد الإصلاح:
- ✅ كشف فوري في الـ UI عند إدخال معرّف بوت
- ✅ تحقق قبل الإرسال مع رسالة عربية واضحة
- ✅ شرح السبب والحل لكل خطأ شائع
- ✅ خطوات إعداد أوضح في الـ UI

---

## 📞 معلومات تقنية

- **التقنية:** Next.js 16 + TypeScript + Prisma
- **API المُعدَّل:** `/api/admin/auto-publish/test`
- **المكتبة المُعدَّلة:** `src/lib/telegram.ts`، `src/lib/auto-publish-service.ts`
- **الـ UI المُعدَّل:** `src/components/admin/AutoPublishDashboard.tsx`
- **التوافق:** يعمل مع PostgreSQL و SQLite
