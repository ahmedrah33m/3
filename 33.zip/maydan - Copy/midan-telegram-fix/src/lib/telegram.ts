/**
 * Telegram Bot Service (مُحسَّن)
 * وظائف: نشر الوظائف والمقالات تلقائياً على قناة تيليجرام
 *
 * إصلاحات:
 * 1. كشف محاولة إرسال لبوت آخر (Forbidden: bot can't send messages to bot)
 * 2. فحص getMe قبل الإرسال للتأكد من صحة الـ Token
 * 3. التحقق من صحة format الـ chat_id قبل الإرسال
 * 4. رسائل خطأ عربية واضحة لكل حالة
 * 5. دالة validateChannelId للتحقق قبل الحفظ
 */

import { logger } from '@/lib/app-logger'

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || ''
const TELEGRAM_CHANNEL_ID = process.env.TELEGRAM_CHANNEL_ID || ''
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://midaniq.com'

interface TelegramMessage {
  chat_id: string
  text: string
  parse_mode?: 'HTML' | 'Markdown'
  disable_web_page_preview?: boolean
  reply_markup?: {
    inline_keyboard: Array<Array<{
      text: string
      url?: string
      callback_data?: string
    }>>
  }
}

/**
 * نتيجة التحقق من معرّف القناة
 */
export interface ChatIdValidation {
  valid: boolean
  type: 'public_channel' | 'private_channel' | 'private_chat' | 'group' | 'bot' | 'unknown' | 'empty'
  message: string
  suggestion?: string
}

/**
 * التحقق من صحة معرّف القناة (chat_id) قبل استخدامه
 *
 * الأنواع المدعومة:
 * - قناة عامة: @channel_username
 * - قناة/مجموعة خاصة: -1001234567890 (يبدأ بـ -100)
 * - محادثة خاصة: 123456789 (رقم موجب - لكن البوت لا يمكنه البدء بها)
 * - مجموعة: -123456789 (يبدأ بـ - بدون 100)
 *
 * غير مسموح:
 * - @SomeBotName (بوت) → Forbidden: bot can't send messages to the bot
 */
export function validateChannelId(chatId: string): ChatIdValidation {
  if (!chatId || !chatId.trim()) {
    return {
      valid: false,
      type: 'empty',
      message: 'معرّف القناة فارغ. يرجى إدخال معرّف القناة.',
      suggestion: 'استخدم @channel_username للقنوات العامة أو -100... للقنوات الخاصة',
    }
  }

  const trimmed = chatId.trim()

  // Case 1: @username format
  if (trimmed.startsWith('@')) {
    const username = trimmed.slice(1)

    // Must be at least 5 chars (Telegram minimum)
    if (username.length < 5) {
      return {
        valid: false,
        type: 'public_channel',
        message: `اسم المستخدم "@${username}" قصير جداً. أسماء تيليجرام يجب أن تكون 5 أحرف على الأقل.`,
      }
    }

    // Must match valid Telegram username pattern
    if (!/^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(username)) {
      return {
        valid: false,
        type: 'public_channel',
        message: `اسم المستخدم "@${username}" غير صالح. يجب أن يبدأ بحرف ويتضمن أحرف وأرقام و_ فقط (5-32 حرف).`,
      }
    }

    // Detect bot usernames — most bots end with "bot"
    // This is a heuristic; some bots don't follow this convention but most do
    if (/bot$/i.test(username)) {
      return {
        valid: false,
        type: 'bot',
        message: `المعرّف "@${username}" يبدو أنه بوت وليس قناة. لا يمكن للبوت إرسال رسائل إلى بوت آخر.`,
        suggestion: 'استخدم معرّف قناة (Channel) وليس بوت. أنشئ قناة من تيليجرام: New Channel.',
      }
    }

    return {
      valid: true,
      type: 'public_channel',
      message: `قناة عامة: @${username}`,
    }
  }

  // Case 2: Numeric chat_id
  if (/^-?\d+$/.test(trimmed)) {
    const num = parseInt(trimmed, 10)

    // Negative number starting with -100 = supergroup or channel
    if (trimmed.startsWith('-100')) {
      return {
        valid: true,
        type: 'private_channel',
        message: `قناة/مجموعة خاصة: ${trimmed}`,
      }
    }

    // Negative number (group, not super-group)
    if (num < 0) {
      return {
        valid: true,
        type: 'group',
        message: `مجموعة: ${trimmed}`,
      }
    }

    // Positive number = private chat with a user (or bot)
    // Bots cannot initiate chats with users — they must message the bot first
    return {
      valid: false,
      type: 'private_chat',
      message: `المعرّف "${trimmed}" هو محادثة خاصة (رقم موجب). البوتات لا يمكنها بدء محادثة مع مستخدم لم يبدأ بالحديث معها أولاً.`,
      suggestion: 'لإرسال رسائل لمستخدم محدد، اطلب منه أولاً إرسال /start لبوتك. للقنوات استخدم @username أو -100... format.',
    }
  }

  // Case 3: Anything else
  return {
    valid: false,
    type: 'unknown',
    message: `صيغة المعرّف "${trimmed}" غير معروفة. استخدم @username أو رقم سالب (مثل -1001234567890).`,
    suggestion: 'القنوات العامة: @channel_name | القنوات الخاصة: -1001234567890',
  }
}

/**
 * فحص البوت عبر getMe للتأكد من صحة الـ Token
 * يرجع معلومات البوت أو يرمي خطأ وصفي
 */
export async function verifyBotToken(token: string): Promise<{
  ok: boolean
  botInfo?: { id: number; username: string; first_name: string }
  error?: string
}> {
  if (!token || !token.trim()) {
    return { ok: false, error: 'Bot Token فارغ. احصل على Token من @BotFather.' }
  }

  // Validate token format: <bot_id>:<hash>
  const trimmed = token.trim()
  if (!/^\d{8,12}:[A-Za-z0-9_-]{30,45}$/.test(trimmed)) {
    return {
      ok: false,
      error: 'صيغة Bot Token غير صحيحة. يجب أن تكون بالشكل: 123456789:ABCdefGHIjklMNOpqrSTUvwxYZ',
    }
  }

  try {
    const url = `https://api.telegram.org/bot${trimmed}/getMe`
    const response = await fetch(url, { method: 'GET' })
    const data = await response.json()

    if (!data.ok) {
      // Common errors
      if (data.description?.includes('Unauthorized')) {
        return { ok: false, error: 'Bot Token غير صالح أو منتهي الصلاحية. تأكد من نسخ الـ Token كاملاً من @BotFather.' }
      }
      return { ok: false, error: data.description || 'فشل التحقق من البوت' }
    }

    return {
      ok: true,
      botInfo: {
        id: data.result.id,
        username: data.result.username,
        first_name: data.result.first_name,
      },
    }
  } catch (error: any) {
    return { ok: false, error: `خطأ في الاتصال بخوادم تيليجرام: ${error.message}` }
  }
}

/**
 * ترجمة رسائل خطأ تيليجرام إلى عربية واضحة
 */
export function translateTelegramError(description: string, chatId?: string): string {
  const desc = (description || '').toLowerCase()

  if (desc.includes("bot can't send messages to bots") || desc.includes("forbidden: bot can't send messages to bot")) {
    return `❌ لا يمكن للبوت إرسال رسائل إلى بوت آخر.
السبب: المعرّف "${chatId}" الذي أدخلته يخص بوت وليس قناة.
الحل: استخدم معرّف قناة (Channel) بدلاً من ذلك.
   - قناة عامة: @channel_username
   - قناة خاصة: -1001234567890`
  }

  if (desc.includes('chat not found')) {
    return `❌ القناة غير موجودة.
السبب: المعرّف "${chatId}" غير صحيح أو البوت ليس عضواً في القناة.
الحل:
   1. للقنوات العامة: تأكد من اسم المستخدم الصحيح
   2. للقنوات الخاصة: أضف البوت كمسؤول في القناة أولاً`
  }

  if (desc.includes('not enough rights') || desc.includes('forbidden: bot is not a member')) {
    return `❌ البوت ليس مسؤولاً في القناة.
الحل:
   1. افتح القناة في تيليجرام
   2. اذهب إلى إعدادات القناة → Administrators
   3. أضف البوت كمسؤول (Add Admin)
   4. فعّل صلاحية "Post Messages"`
  }

  if (desc.includes('forbidden') && desc.includes('bot was blocked by the user')) {
    return `❌ المستخدم حظر البوت.
الحل: المستخدم يجب أن يفتح البوت ويضغط /start ثم Unblock.`
  }

  if (desc.includes('chat write forbidden')) {
    return `❌ البوت لا يملك صلاحية الكتابة في هذه المحادثة.
الحل: أضف البوت كمسؤول في القناة/المجموعة مع صلاحية Post Messages.`
  }

  if (desc.includes('bad request: chat_id is empty')) {
    return `❌ معرّف القناة فارغ.
الحل: أدخل معرّف القناة في حقل "identifier".`
  }

  if (desc.includes('bad request: message text is empty')) {
    return `❌ نص الرسالة فارغ. تحقق من القالب (template) المستخدم.`
  }

  if (desc.includes('too many requests') || desc.includes('429')) {
    return `❌ تم تجاوز حد الإرسال (Rate limit).
الحل: انتظر دقيقة ثم حاول مرة أخرى. تيليجرام يسمح بـ ~30 رسالة/ثانية للبوت الواحد.`
  }

  if (desc.includes('unauthorized')) {
    return `❌ Bot Token غير صالح أو منتهي الصلاحية.
الحل: احصل على Token جديد من @BotFather.`
  }

  // Default
  return `❌ خطأ في تيليجرام: ${description}`
}

/**
 * إرسال رسالة إلى قناة تيليجرام (مُحسَّن)
 *
 * التغييرات:
 * - يتحقق من chat_id قبل الإرسال
 * - يترجم رسائل الخطأ للعربية
 * - يسجّل تفاصيل أكثر للتشخيص
 */
export async function sendTelegramMessage(message: TelegramMessage): Promise<boolean> {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHANNEL_ID) {
    logger.warn('Telegram not configured: missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHANNEL_ID')
    return false
  }

  // Validate chat_id before sending
  const validation = validateChannelId(message.chat_id)
  if (!validation.valid) {
    logger.error('Telegram chat_id validation failed', {
      chat_id: message.chat_id,
      type: validation.type,
      message: validation.message,
    })
    return false
  }

  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...message,
      }),
    })

    const data = await response.json()

    if (!response.ok || !data.ok) {
      const arabicError = translateTelegramError(data.description || `HTTP ${response.status}`, message.chat_id)
      logger.error('Telegram API error', {
        status: response.status,
        error: data.description,
        arabicError,
        chat_id: message.chat_id,
      })
      return false
    }

    logger.info('Telegram message sent successfully', { messageId: data.result?.message_id })
    return true
  } catch (error) {
    logger.error('Failed to send Telegram message', { error })
    return false
  }
}

/**
 * إرسال صورة مع نص إلى قناة تيليجرام
 */
export async function sendTelegramPhoto(
  photoUrl: string,
  caption: string,
  parseMode: 'HTML' | 'Markdown' = 'HTML'
): Promise<boolean> {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHANNEL_ID) {
    logger.warn('Telegram not configured')
    return false
  }

  // Validate chat_id
  const validation = validateChannelId(TELEGRAM_CHANNEL_ID)
  if (!validation.valid) {
    logger.error('Telegram chat_id validation failed', {
      chat_id: TELEGRAM_CHANNEL_ID,
      type: validation.type,
      message: validation.message,
    })
    return false
  }

  try {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHANNEL_ID,
        photo: photoUrl.startsWith('http') ? photoUrl : `${SITE_URL}${photoUrl}`,
        caption,
        parse_mode: parseMode,
      }),
    })

    const data = await response.json()

    if (!response.ok || !data.ok) {
      const arabicError = translateTelegramError(data.description || `HTTP ${response.status}`, TELEGRAM_CHANNEL_ID)
      logger.error('Telegram photo send error', {
        status: response.status,
        error: data.description,
        arabicError,
      })
      return false
    }

    logger.info('Telegram photo sent successfully')
    return true
  } catch (error) {
    logger.error('Failed to send Telegram photo', { error })
    return false
  }
}

/**
 * نشر وظيفة جديدة على قناة تيليجرام
 */
export async function publishJobToTelegram(job: {
  id: string
  title: string
  company: string
  location?: string | null
  type?: string | null
  salary?: string | null
  description: string
  category?: string | null
  image?: string | null
  expiresAt: Date
}): Promise<boolean> {
  const typeLabels: Record<string, string> = {
    'full-time': 'دوام كامل',
    'part-time': 'دوام جزئي',
    'contract': 'عقد',
    'remote': 'عن بُعد',
    'internship': 'تدريب',
  }

  const typeLabel = typeLabels[job.type || ''] || ''
  const locationText = job.location ? `📍 ${job.location}` : ''
  const salaryText = job.salary ? `💰 ${job.salary}` : ''
  const typeText = typeLabel ? `🕐 ${typeLabel}` : ''
  const categoryText = job.category ? `📂 ${job.category}` : ''
  const expiryText = `⏰ ينتهي: ${new Date(job.expiresAt).toLocaleDateString('ar-IQ')}`

  const header = `🔥 <b>فرصة عمل جديدة</b>\n\n`
  const titleLine = `📋 <b>${escapeHtml(job.title)}</b>\n`
  const companyLine = `🏢 ${escapeHtml(job.company)}\n\n`
  const details = [typeText, locationText, salaryText, categoryText].filter(Boolean).join(' | ')
  const detailsLine = details ? `${details}\n` : ''

  const shortDesc = job.description.length > 300
    ? job.description.substring(0, 300) + '...'
    : job.description
  const descLine = `\n📝 <i>${escapeHtml(shortDesc)}</i>\n\n`

  const expiryLine = `${expiryText}\n\n`

  const jobUrl = `${SITE_URL}/jobs`

  const text = `${header}${titleLine}${companyLine}${detailsLine}${descLine}${expiryLine}🔗 <a href="${jobUrl}">تقدم على هذه الوظيفة</a>`

  if (job.image) {
    const imageUrl = job.image.startsWith('http') ? job.image : `${SITE_URL}${job.image}`
    return sendTelegramPhoto(imageUrl, text)
  }

  return sendTelegramMessage({
    chat_id: TELEGRAM_CHANNEL_ID,
    text,
    parse_mode: 'HTML',
    disable_web_page_preview: false,
  })
}

/**
 * نشر مقال جديد على قناة تيليجرام
 */
export async function publishArticleToTelegram(article: {
  id: string
  title: string
  summary?: string | null
  coverImage?: string | null
  author?: { name?: string | null } | null
  viewCount?: number
}): Promise<boolean> {
  const authorText = article.author?.name ? `✍️ ${escapeHtml(article.author.name)}` : ''
  const viewsText = article.viewCount ? `👁️ ${article.viewCount} مشاهدة` : ''
  const meta = [authorText, viewsText].filter(Boolean).join(' | ')
  const metaLine = meta ? `\n${meta}\n` : ''

  const shortSummary = article.summary
    ? (article.summary.length > 200 ? article.summary.substring(0, 200) + '...' : article.summary)
    : ''
  const summaryLine = shortSummary ? `\n📝 <i>${escapeHtml(shortSummary)}</i>\n` : ''

  const articleUrl = `${SITE_URL}/articles/${article.id}`
  const text = `📰 <b>مقال جديد</b>\n\n✨ <b>${escapeHtml(article.title)}</b>${metaLine}${summaryLine}\n🔗 <a href="${articleUrl}">اقرأ المقال كاملاً</a>`

  if (article.coverImage) {
    const imageUrl = article.coverImage.startsWith('http') ? article.coverImage : `${SITE_URL}${article.coverImage}`
    return sendTelegramPhoto(imageUrl, text)
  }

  return sendTelegramMessage({
    chat_id: TELEGRAM_CHANNEL_ID,
    text,
    parse_mode: 'HTML',
  })
}

/**
 * التحقق من إعداد تيليجرام
 */
export function isTelegramConfigured(): boolean {
  return !!(TELEGRAM_BOT_TOKEN && TELEGRAM_CHANNEL_ID)
}

/**
 * تهريب HTML لمنع حقن الأكواد
 */
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}
