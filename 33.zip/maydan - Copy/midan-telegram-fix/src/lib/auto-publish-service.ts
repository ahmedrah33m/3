/**
 * Auto-Publishing Service — خدمة النشر التلقائي
 * 
 * ينشر الوظائف تلقائياً على:
 * - Telegram (Bot API)
 * - WhatsApp Business API
 * - Facebook Pages (Graph API)
 * 
 * الميزات:
 * - قوالب رسائل مخصصة لكل منصة
 * - إعادة المحاولة التلقائية
 * - تسجيل مفصل لكل عملية نشر
 * - تحليلات الأداء
 * - تصنيف القنوات حسب فئات الوظائف
 */

import { db } from '@/lib/db'

// ═══════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════

export type Platform = 'telegram' | 'whatsapp' | 'facebook'
export type PublishStatus = 'pending' | 'publishing' | 'published' | 'failed' | 'deleted'

export interface PublishChannel {
  id: string
  name: string
  platform: Platform
  identifier: string
  accessToken?: string | null
  webhookUrl?: string | null
  isActive: boolean
  autoPublish: boolean
  categories: string[]       // JSON parsed
  template: string
  logoUrl?: string | null
  metadata: Record<string, unknown>
  publishCount: number
  lastPublishedAt?: Date | null
  createdAt: Date
  updatedAt: Date
}

export interface PublishLog {
  id: string
  channelId: string
  jobId?: string | null
  jobTitle: string
  platform: Platform
  status: PublishStatus
  message?: string | null
  externalPostId?: string | null
  externalUrl?: string | null
  response?: string | null
  errorMessage?: string | null
  retryCount: number
  maxRetries: number
  publishedAt?: Date | null
  scheduledAt?: Date | null
  createdAt: Date
  channel?: PublishChannel
}

export interface JobData {
  id: string
  title: string
  description: string
  category: string
  location: string
  salary?: string | null
  company?: string | null
  type?: string | null       // full-time, part-time, remote...
  experience?: string | null
  requirements?: string[] | null
  url: string                 // رابط الوظيفة في المنصة
  logoUrl?: string | null
}

// ═══════════════════════════════════════════════
// Default Message Templates
// ═══════════════════════════════════════════════

const DEFAULT_TEMPLATES: Record<Platform, string> = {
  telegram: `🏢 {company}
📌 {title}

📍 {location} | 💼 {type} | 💰 {salary}

📋 {description}

🔹 {requirements}

🔗 التقديم: {url}

──────────────
📢 منصة ميدان الاقتصاد | وظائف`,

  whatsapp: `*{title}*

🏢 *{company}*
📍 {location} | 💼 {type}
💰 {salary}

{description}

🔹 المتطلبات:
{requirements}

🔗 التقديم: {url}

_منصة ميدان الاقتصاد_`,

  facebook: `🔷 وظيفة شاغرة: {title}

🏢 {company}
📍 {location}
💼 {type} | 💰 {salary}

📋 {description}

🔹 المتطلبات:
{requirements}

🔗 قدم الآن: {url}

──────────
📢 منصة ميدان الاقتصادية — أكبر منصة وظائف اقتصادية في العراق
#وظائف #توظيف #ميدان #العراق`,
}

// ═══════════════════════════════════════════════
// Template Engine
// ═══════════════════════════════════════════════

export function renderTemplate(template: string, job: JobData, platform: Platform): string {
  const requirements = job.requirements?.join('\n🔹 ') || 'لا يوجد متطلبات محددة'

  return template
    .replace(/{title}/g, job.title)
    .replace(/{company}/g, job.company || 'شركة')
    .replace(/{location}/g, job.location)
    .replace(/{type}/g, job.type || 'دوام كامل')
    .replace(/{salary}/g, job.salary || 'يحدد في المقابلة')
    .replace(/{description}/g, truncate(job.description, platform === 'telegram' ? 200 : 300))
    .replace(/{requirements}/g, requirements)
    .replace(/{url}/g, job.url)
    .replace(/{category}/g, job.category)
}

function truncate(text: string, maxLen: number): string {
  if (!text || text.length <= maxLen) return text || ''
  return text.slice(0, maxLen).trim() + '...'
}

// ═══════════════════════════════════════════════
// Main: Auto-Publish a Job
// ═══════════════════════════════════════════════

/**
 * Publish a job to all matching auto-publish channels
 * Called after a job is created/published on the platform
 */
export async function autoPublishJob(job: JobData): Promise<{
  total: number
  published: number
  failed: number
  results: { channel: string; platform: Platform; status: PublishStatus; error?: string }[]
}> {
  // 1. Get all active auto-publish channels
  const channels = await getActiveChannels()

  // 2. Filter by category match
  const matchedChannels = channels.filter(ch => {
    if (ch.categories.length === 0) return true // empty = all categories
    return ch.categories.includes(job.category)
  })

  if (matchedChannels.length === 0) {
    return { total: 0, published: 0, failed: 0, results: [] }
  }

  // 3. Publish to each channel
  const results: { channel: string; platform: Platform; status: PublishStatus; error?: string }[] = []
  let published = 0
  let failed = 0

  for (const channel of matchedChannels) {
    try {
      const template = channel.template || DEFAULT_TEMPLATES[channel.platform]
      const message = renderTemplate(template, job, channel.platform)

      const result = await publishToPlatform({
        channel,
        message,
        job,
      })

      results.push({
        channel: channel.name,
        platform: channel.platform,
        status: result.status,
        error: result.errorMessage || undefined,
      })

      if (result.status === 'published') published++
      else failed++
    } catch (err: any) {
      failed++
      results.push({
        channel: channel.name,
        platform: channel.platform,
        status: 'failed',
        error: err.message,
      })
    }
  }

  return { total: matchedChannels.length, published, failed, results }
}

// ═══════════════════════════════════════════════
// Platform Publishers
// ═══════════════════════════════════════════════

interface PublishParams {
  channel: PublishChannel
  message: string
  job: JobData
}

async function publishToPlatform(params: PublishParams): Promise<PublishLog> {
  const { channel, message, job } = params

  // Create log entry
  const log = await db.publishLog.create({
    data: {
      channelId: channel.id,
      jobId: job.id,
      jobTitle: job.title,
      platform: channel.platform,
      status: 'publishing',
      message,
    },
  })

  try {
    let result: { externalPostId?: string; externalUrl?: string; response: string }

    switch (channel.platform) {
      case 'telegram':
        result = await publishToTelegram(channel, message, job)
        break
      case 'whatsapp':
        result = await publishToWhatsApp(channel, message, job)
        break
      case 'facebook':
        result = await publishToFacebook(channel, message, job)
        break
      default:
        throw new Error(`Unsupported platform: ${channel.platform}`)
    }

    // Update log as published
    const updated = await db.publishLog.update({
      where: { id: log.id },
      data: {
        status: 'published',
        externalPostId: result.externalPostId,
        externalUrl: result.externalUrl,
        response: result.response,
        publishedAt: new Date(),
      },
    })

    // Update channel stats
    await db.publishChannel.update({
      where: { id: channel.id },
      data: {
        publishCount: { increment: 1 },
        lastPublishedAt: new Date(),
      },
    })

    return updated
  } catch (error: any) {
    // Update log as failed
    const updated = await db.publishLog.update({
      where: { id: log.id },
      data: {
        status: 'failed',
        errorMessage: error.message?.slice(0, 500),
        retryCount: { increment: 1 },
      },
    })

    // Auto-retry if under max retries
    if (updated.retryCount < updated.maxRetries) {
      setTimeout(() => retryPublish(updated.id), 5000 * updated.retryCount)
    }

    return updated
  }
}

// ─── Telegram Bot API ───
async function publishToTelegram(
  channel: PublishChannel,
  message: string,
  job: JobData
): Promise<{ externalPostId?: string; externalUrl?: string; response: string }> {
  const token = channel.accessToken
  if (!token) throw new Error('Telegram bot token not configured')

  const url = `https://api.telegram.org/bot${token}/sendMessage`

  const body: any = {
    chat_id: channel.identifier,
    text: message,
    parse_mode: 'HTML',
    disable_web_page_preview: false,
  }

  // Add logo/image if available
  if (job.logoUrl) {
    body.photo = job.logoUrl
    body.caption = message
    body.parse_mode = 'HTML'
  }

  const endpoint = job.logoUrl ? `${url.replace('sendMessage', 'sendPhoto')}` : url

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })

  const data = await res.json()

  if (!data.ok) {
    throw new Error(data.description || `Telegram API error: ${res.status}`)
  }

  const result = data.result
  return {
    externalPostId: String(result.message_id),
    externalUrl: channel.identifier.startsWith('@')
      ? `https://t.me/${channel.identifier.slice(1)}/${result.message_id}`
      : undefined,
    response: JSON.stringify(data),
  }
}

// ─── WhatsApp Business API ───
async function publishToWhatsApp(
  channel: PublishChannel,
  message: string,
  job: JobData
): Promise<{ externalPostId?: string; externalUrl?: string; response: string }> {
  const token = channel.accessToken
  const phoneId = channel.identifier
  if (!token || !phoneId) throw new Error('WhatsApp credentials not configured')

  // WhatsApp Business API v18.0
  const url = `https://graph.facebook.com/v18.0/${phoneId}/messages`

  // Clean markdown for WhatsApp
  const cleanMessage = message
    .replace(/[*_~`]/g, '')
    .replace(/\n/g, '\n')

  const body = {
    messaging_product: 'whatsapp',
    to: channel.metadata?.targetPhone || channel.identifier,
    type: 'text',
    text: {
      body: cleanMessage,
      preview_url: true,
    },
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  })

  const data = await res.json()

  if (data.error) {
    throw new Error(data.error.message || 'WhatsApp API error')
  }

  return {
    externalPostId: data.messages?.[0]?.id,
    response: JSON.stringify(data),
  }
}

// ─── Facebook Graph API ───
async function publishToFacebook(
  channel: PublishChannel,
  message: string,
  job: JobData
): Promise<{ externalPostId?: string; externalUrl?: string; response: string }> {
  const token = channel.accessToken
  const pageId = channel.identifier
  if (!token || !pageId) throw new Error('Facebook credentials not configured')

  const url = `https://graph.facebook.com/v18.0/${pageId}/feed`

  const body: any = {
    message,
    link: job.url,
    published: true,
  }

  // Add image if available
  if (job.logoUrl) {
    body.picture = job.logoUrl
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  })

  const data = await res.json()

  if (data.error) {
    throw new Error(data.error.message || 'Facebook API error')
  }

  return {
    externalPostId: data.id,
    externalUrl: data.id ? `https://facebook.com/${data.id}` : undefined,
    response: JSON.stringify(data),
  }
}

// ═══════════════════════════════════════════════
// Retry Failed Publications
// ═══════════════════════════════════════════════

export async function retryPublish(logId: string): Promise<void> {
  const log = await db.publishLog.findUnique({
    where: { id: logId },
    include: { channel: true },
  })

  if (!log || !log.channel) return
  if (log.status !== 'failed' || log.retryCount >= log.maxRetries) return

  // Create new log entry for retry
  await db.publishLog.update({
    where: { id: logId },
    data: {
      status: 'publishing',
      errorMessage: null,
    },
  })

  try {
    const platformPublisher = {
      telegram: publishToTelegram,
      whatsapp: publishToWhatsApp,
      facebook: publishToFacebook,
    }[log.platform]

    if (!platformPublisher) throw new Error(`Unknown platform: ${log.platform}`)

    const result = await platformPublisher(log.channel, log.message || '', {
      id: log.jobId || '',
      title: log.jobTitle,
      description: '',
      category: '',
      location: '',
      url: '',
    })

    await db.publishLog.update({
      where: { id: logId },
      data: {
        status: 'published',
        externalPostId: result.externalPostId,
        externalUrl: result.externalUrl,
        response: result.response,
        publishedAt: new Date(),
      },
    })

    await db.publishChannel.update({
      where: { id: log.channel.id },
      data: { publishCount: { increment: 1 }, lastPublishedAt: new Date() },
    })
  } catch (err: any) {
    await db.publishLog.update({
      where: { id: logId },
      data: {
        status: 'failed',
        errorMessage: err.message?.slice(0, 500),
        retryCount: { increment: 1 },
      },
    })
  }
}

// ═══════════════════════════════════════════════
// Channel Management Helpers
// ═══════════════════════════════════════════════

export async function getActiveChannels(): Promise<PublishChannel[]> {
  const channels = await db.publishChannel.findMany({
    where: { isActive: true, autoPublish: true },
    orderBy: { createdAt: 'asc' },
  })

  return channels.map(ch => ({
    ...ch,
    categories: parseJSON(ch.categories),
    metadata: parseJSON(ch.metadata),
  }))
}

export async function getAllChannels(): Promise<PublishChannel[]> {
  const channels = await db.publishChannel.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      _count: {
        select: {
          logs: { where: { status: 'published' } },
        },
      },
    },
  })

  return channels.map(ch => ({
    ...ch,
    categories: parseJSON(ch.categories),
    metadata: parseJSON(ch.metadata),
    publishedCount: (ch as any)._count?.logs || 0,
  }))
}

export function getDefaultTemplate(platform: Platform): string {
  return DEFAULT_TEMPLATES[platform]
}

// ═══════════════════════════════════════════════
// Analytics
// ═══════════════════════════════════════════════

export interface PublishDashboardStats {
  totalChannels: number
  activeChannels: number
  totalPublished: number
  totalFailed: number
  todayPublished: number
  todayFailed: number
  platformBreakdown: { platform: Platform; published: number; failed: number }[]
  recentLogs: PublishLog[]
}

export async function getDashboardStats(): Promise<PublishDashboardStats> {
  const now = new Date()
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  const [channels, totalPublished, totalFailed, todayPublished, todayFailed, recentLogs] =
    await Promise.all([
      db.publishChannel.findMany({ select: { id: true, isActive: true } }),
      db.publishLog.count({ where: { status: 'published' } }),
      db.publishLog.count({ where: { status: 'failed' } }),
      db.publishLog.count({ where: { status: 'published', createdAt: { gte: startOfDay } } }),
      db.publishLog.count({ where: { status: 'failed', createdAt: { gte: startOfDay } } }),
      db.publishLog.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: { channel: { select: { name: true, platform: true } } },
      }),
    ])

  // Platform breakdown
  const platformStats = await db.publishLog.groupBy({
    by: ['platform', 'status'],
    where: { createdAt: { gte: startOfDay } },
    _count: true,
  })

  const platformBreakdown: { platform: Platform; published: number; failed: number }[] = []
  const seen = new Set<Platform>()

  for (const ps of platformStats) {
    if (!seen.has(ps.platform as Platform)) {
      seen.add(ps.platform as Platform)
      platformBreakdown.push({ platform: ps.platform as Platform, published: 0, failed: 0 })
    }
    const entry = platformBreakdown.find(p => p.platform === ps.platform)!
    if (ps.status === 'published') entry.published = ps._count
    else if (ps.status === 'failed') entry.failed = ps._count
  }

  return {
    totalChannels: channels.length,
    activeChannels: channels.filter(c => c.isActive).length,
    totalPublished,
    totalFailed,
    todayPublished,
    todayFailed,
    platformBreakdown,
    recentLogs: recentLogs.map(l => ({
      ...l,
      channel: l.channel ? { name: l.channel.name, platform: l.channel.platform } : undefined,
    })),
  }
}

// ═══════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════

function parseJSON(str: any): any {
  if (!str) return str === '' ? [] : {}
  if (typeof str === 'object') return str
  try { return JSON.parse(str) } catch { return str === '' ? [] : {} }
}

// ═══════════════════════════════════════════════
// Test Connection to a Platform
// ═══════════════════════════════════════════════

export async function testChannelConnection(channel: PublishChannel): Promise<{
  success: boolean
  message: string
  platformInfo?: Record<string, string>
}> {
  try {
    switch (channel.platform) {
      case 'telegram': {
        // التحقق من المعرّف قبل الاتصال
        // نستخدم validateChannelId من telegram.ts لكن لتجنب الاعتماد الدائري ننفذها هنا
        const chatId = channel.identifier
        if (chatId && /bot$/i.test(chatId.replace(/^@/, ''))) {
          return {
            success: false,
            message: `⚠️ المعرّف "${chatId}" يبدو أنه بوت وليس قناة. لا يمكن للبوت إرسال رسائل إلى بوت آخر.\n\nاستخدم معرّف قناة (Channel) مثل @your_channel_name أو -1001234567890.`,
          }
        }

        const res = await fetch(`https://api.telegram.org/bot${channel.accessToken}/getMe`)
        const data = await res.json()
        if (data.ok) {
          // البوت متصل — لكن تحقق إن كان chat_id صالح للإرسال
          const botUsername = data.result.username
          const warning = ''
          if (chatId && chatId.startsWith('@')) {
            const targetName = chatId.slice(1)
            // إذا كان المعرّف = نفس البوت، فهذا خطأ شائع
            if (targetName.toLowerCase() === botUsername.toLowerCase()) {
              return {
                success: false,
                message: `⚠️ المعرّف "@${targetName}" هو نفس بوتك! لا يمكن للبوت إرسال رسائل لنفسه.\n\nاستخدم معرّف قناة (Channel) مختلفة.`,
                platformInfo: {
                  name: data.result.first_name,
                  username: botUsername,
                  id: String(data.result.id),
                },
              }
            }
          }

          return {
            success: true,
            message: `✅ متصل بنجاح: @${botUsername}${warning}`,
            platformInfo: {
              name: data.result.first_name,
              username: botUsername,
              id: String(data.result.id),
            },
          }
        }

        // ترجمة الأخطاء الشائعة
        const desc = data.description || ''
        if (desc.includes('Unauthorized')) {
          return { success: false, message: '❌ Bot Token غير صالح أو منتهي. احصل على Token جديد من @BotFather.' }
        }
        return { success: false, message: `❌ فشل الاتصال: ${desc}` }
      }

      case 'facebook': {
        const res = await fetch(
          `https://graph.facebook.com/v18.0/${channel.identifier}?fields=name,id&access_token=${channel.accessToken}`
        )
        const data = await res.json()
        if (data.name) {
          return {
            success: true,
            message: `متصل: ${data.name}`,
            platformInfo: { name: data.name, id: data.id },
          }
        }
        return { success: false, message: data.error?.message || 'فشل الاتصال' }
      }

      case 'whatsapp': {
        const res = await fetch(
          `https://graph.facebook.com/v18.0/${channel.identifier}?fields=id&access_token=${channel.accessToken}`,
          { headers: { 'Authorization': `Bearer ${channel.accessToken}` } }
        )
        const data = await res.json()
        if (data.id) {
          return { success: true, message: 'الحساب متصل بنجاح', platformInfo: { id: data.id } }
        }
        return { success: false, message: data.error?.message || 'فشل الاتصال' }
      }

      default:
        return { success: false, message: 'منصة غير مدعومة' }
    }
  } catch (err: any) {
    return { success: false, message: err.message || 'خطأ في الاتصال' }
  }
}