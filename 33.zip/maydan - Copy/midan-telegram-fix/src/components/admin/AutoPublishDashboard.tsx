'use client'

import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import {
  Send, Plus, Trash2, Edit3, RefreshCw, Wifi, WifiOff,
  CheckCircle, XCircle, Clock, AlertTriangle, ExternalLink,
  Settings, BarChart3, Zap, MessageSquare, Bell,
  Copy, Loader2, Globe, Bot, Radio, TrendingUp, Megaphone,
  ChevronDown, ChevronUp, Link2, Shield, FileText
} from 'lucide-react'

// ═══════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════

interface Channel {
  id: string
  name: string
  platform: string
  identifier: string
  accessToken?: string | null
  isActive: boolean
  autoPublish: boolean
  categories: string[]
  template: string
  logoUrl?: string | null
  publishCount: number
  lastPublishedAt?: string | null
  createdAt: string
}

interface LogEntry {
  id: string
  channelId: string
  jobTitle: string
  platform: string
  status: string
  externalUrl?: string | null
  errorMessage?: string | null
  retryCount: number
  publishedAt?: string | null
  createdAt: string
  channel?: { name: string; platform: string; logoUrl?: string | null }
}

interface DashboardStats {
  totalChannels: number
  activeChannels: number
  totalPublished: number
  todayPublished: number
  todayFailed: number
}

interface ConnectionTestResult {
  success: boolean
  message: string
  testResult?: boolean
  externalUrl?: string
  platformInfo?: Record<string, string>
}

const PLATFORM_CONFIG: Record<string, {
  label: string; icon: typeof Bot; color: string; bg: string; border: string
  placeholder: string; helpText: string; tokenLabel: string; tokenPlaceholder: string
  steps: string[]
}> = {
  telegram: {
    label: 'تليغرام',
    icon: Send,
    color: 'text-sky-600 dark:text-sky-400',
    bg: 'bg-sky-50 dark:bg-sky-900/20',
    border: 'border-sky-200 dark:border-sky-800',
    placeholder: '@channel_username أو -1001234567890',
    helpText: '⚠️ استخدم معرّف قناة (Channel) وليس بوت! القنوات العامة تبدأ بـ @، الخاصة برقم سالب -100...',
    tokenLabel: 'Bot Token',
    tokenPlaceholder: '7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
    steps: [
      '⚠️ مهم: لا تستخدم معرّف بوت (@SomeBot) هنا — البوت لا يمكنه إرسال رسائل لبوت آخر',
      'افتح تليغرام وابحث عن @BotFather',
      'أرسل /newbot واختر اسم ومعرّف البوت (هذا البوت الذي سيرسل الرسائل)',
      'انسخ Bot Token من الرد',
      'أنشئ قناة جديدة في تيليجرام (New Channel) أو استخدم قناة موجودة',
      'أضف البوت كمدير في القناة: إعدادات القناة ← Administrators ← Add Admin',
      'فعّل صلاحية "Post Messages" للبوت',
      'في حقل المعرّف بالأعلى، أدخل اسم القناة: @your_channel_name',
      'للقنوات الخاصة: استخدم Chat ID (رقم يبدأ بـ -100) — احصل عليه من getUpdates API',
    ],
  },
  whatsapp: {
    label: 'واتساب',
    icon: MessageSquare,
    color: 'text-green-600 dark:text-green-400',
    bg: 'bg-green-50 dark:bg-green-900/20',
    border: 'border-green-200 dark:border-green-800',
    placeholder: 'Phone Number ID من Meta (مثل 123456789012345)',
    helpText: 'تحتاج حساب Meta Business + WhatsApp Business API مفعّل',
    tokenLabel: 'Access Token',
    tokenPlaceholder: 'EAAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
    steps: [
      'اذهب إلى developers.facebook.com وسجل دخول',
      'اضغط My Apps ← Create App ← اختر Business',
      'من القائمة الجانبية اختر WhatsApp ← Get Started',
      'أضف رقم واتساب العمل واستقبل رمز التحقق',
      'انسخ Phone Number ID من صفحة API Setup',
      'اضغط Generate Access Token وانسخه',
    ],
  },
  facebook: {
    label: 'فيسبوك',
    icon: Globe,
    color: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-50 dark:bg-blue-900/20',
    border: 'border-blue-200 dark:border-blue-800',
    placeholder: 'Page ID (مثل 123456789012345)',
    helpText: 'تحتاج Page Access Token مع صلاحية pages_manage_posts',
    tokenLabel: 'Page Access Token',
    tokenPlaceholder: 'EAAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
    steps: [
      'اذهب إلى developers.facebook.com ← My Apps',
      'افتح Tools ← Graph API Explorer',
      'اختر تطبيقك واختر Page Access Token',
      'أضف الصلاحيات: pages_manage_posts, pages_read_engagement',
      'اضغط Generate Access Token',
      'اعرف Page ID من: صفحتك ← المعلومات ← معرف الصفحة',
    ],
  },
}

const STATUS_CONFIG: Record<string, { label: string; icon: typeof CheckCircle; color: string }> = {
  published: { label: 'تم النشر', icon: CheckCircle, color: 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20' },
  failed: { label: 'فشل', icon: XCircle, color: 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20' },
  publishing: { label: 'جاري النشر', icon: Loader2, color: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20' },
  pending: { label: 'في الانتظار', icon: Clock, color: 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/20' },
  deleted: { label: 'محذوف', icon: Trash2, color: 'text-gray-500 bg-gray-50 dark:bg-gray-900/10' },
}

// ═══════════════════════════════════════════════
// Main Component
// ═══════════════════════════════════════════════

export default function AutoPublishDashboard() {
  const { toast } = useToast()
  const [channels, setChannels] = useState<Channel[]>([])
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [defaultTemplates, setDefaultTemplates] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'channels' | 'logs' | 'settings'>('channels')

  // Dialog states
  const [showChannelDialog, setShowChannelDialog] = useState(false)
  const [showTemplateDialog, setShowTemplateDialog] = useState(false)
  const [editingChannel, setEditingChannel] = useState<Channel | null>(null)
  const [testingId, setTestingId] = useState<string | null>(null)
  const [sendingTestId, setSendingTestId] = useState<string | null>(null)
  const [showSetupGuide, setShowSetupGuide] = useState(false)

  // Connection test results per channel
  const [connectionResults, setConnectionResults] = useState<Record<string, ConnectionTestResult>>({})

  // Form state
  const [formName, setFormName] = useState('')
  const [formPlatform, setFormPlatform] = useState('telegram')
  const [formIdentifier, setFormIdentifier] = useState('')
  const [formToken, setFormToken] = useState('')
  const [formCategories, setFormCategories] = useState<string[]>([])
  const [formTemplate, setFormTemplate] = useState('')
  const [formAutoPublish, setFormAutoPublish] = useState(true)
  const [saving, setSaving] = useState(false)

  // Filter state
  const [logFilter, setLogFilter] = useState<string>('all')
  const [logPlatformFilter, setLogPlatformFilter] = useState<string>('all')

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/auto-publish')
      if (res.ok) {
        const data = await res.json()
        setChannels(data.channels || [])
        setLogs(data.recentLogs || [])
        setStats(data.stats || null)
        setDefaultTemplates(data.defaultTemplates || {})
      }
    } catch { /* silent */ }
    setLoading(false)
  }, [])

  useEffect(() => { fetchData() }, [fetchData])

  // Auto-refresh logs every 15 seconds
  useEffect(() => {
    const interval = setInterval(fetchData, 15000)
    return () => clearInterval(interval)
  }, [fetchData])

  // ═══ Channel Dialog ═══

  const openAddChannel = () => {
    setEditingChannel(null)
    setFormName('')
    setFormPlatform('telegram')
    setFormIdentifier('')
    setFormToken('')
    setFormCategories([])
    setFormTemplate(defaultTemplates.telegram || '')
    setFormAutoPublish(true)
    setShowSetupGuide(true)
    setShowChannelDialog(true)
  }

  const openEditChannel = (ch: Channel) => {
    setEditingChannel(ch)
    setFormName(ch.name)
    setFormPlatform(ch.platform)
    setFormIdentifier(ch.identifier)
    setFormToken('')
    setFormCategories(ch.categories || [])
    setFormTemplate(ch.template || '')
    setFormAutoPublish(ch.autoPublish)
    setShowSetupGuide(false)
    setShowChannelDialog(true)
  }

  const openTemplateEditor = (ch: Channel) => {
    setEditingChannel(ch)
    setFormPlatform(ch.platform)
    setFormTemplate(ch.template || defaultTemplates[ch.platform] || '')
    setShowTemplateDialog(true)
  }

  const handleSaveChannel = async () => {
    if (!formName || !formIdentifier) {
      toast({ title: 'الاسم والمعرّف مطلوبان', variant: 'destructive' })
      return
    }
    if (!editingChannel && !formToken) {
      toast({ title: 'رمز الوصول مطلوب لقناة جديدة', variant: 'destructive' })
      return
    }

    setSaving(true)
    try {
      const url = editingChannel
        ? `/api/admin/auto-publish/${editingChannel.id}`
        : '/api/admin/auto-publish'
      const method = editingChannel ? 'PUT' : 'POST'

      const body: any = {
        name: formName,
        platform: formPlatform,
        identifier: formIdentifier,
        categories: formCategories,
        template: formTemplate,
        autoPublish: formAutoPublish,
      }
      if (formToken) body.accessToken = formToken

      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      if (res.ok) {
        toast({ title: editingChannel ? 'تم تحديث القناة' : 'تم إضافة القناة بنجاح' })
        setShowChannelDialog(false)
        fetchData()
      } else {
        const data = await res.json()
        toast({ title: data.error || 'حدث خطأ', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'خطأ في الاتصال', variant: 'destructive' })
    }
    setSaving(false)
  }

  const handleDeleteChannel = async (id: string) => {
    if (!confirm('هل تريد حذف هذه القناة وجميع سجلات النشر؟')) return
    try {
      const res = await fetch(`/api/admin/auto-publish/${id}`, { method: 'DELETE' })
      if (res.ok) {
        toast({ title: 'تم حذف القناة' })
        fetchData()
      }
    } catch { /* silent */ }
  }

  const handleTestConnection = async (id: string) => {
    setTestingId(id)
    setConnectionResults(prev => ({ ...prev, [id]: { success: false, message: 'جاري الفحص...' } }))
    try {
      const res = await fetch('/api/admin/auto-publish/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId: id, sendMessage: false }),
      })
      const data = await res.json()
      setConnectionResults(prev => ({ ...prev, [id]: data }))
      if (data.success) {
        toast({ title: 'اتصال ناجح!', description: data.message })
      } else {
        toast({ title: 'فشل الاتصال', description: data.message, variant: 'destructive' })
      }
    } catch {
      setConnectionResults(prev => ({ ...prev, [id]: { success: false, message: 'خطأ في الاتصال بالخادم' } }))
      toast({ title: 'خطأ في الاتصال', variant: 'destructive' })
    }
    setTestingId(null)
  }

  const handleSendTestMessage = async (id: string) => {
    if (!confirm('سيتم إرسال رسالة اختبار إلى هذه القناة. متابعة؟')) return
    setSendingTestId(id)
    setConnectionResults(prev => ({ ...prev, [id]: { success: false, message: 'جاري إرسال الرسالة...' } }))
    try {
      const res = await fetch('/api/admin/auto-publish/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId: id, sendMessage: true }),
      })
      const data = await res.json()
      setConnectionResults(prev => ({ ...prev, [id]: data }))
      if (data.success) {
        toast({ title: 'تم إرسال الرسالة!', description: data.message })
        fetchData()
      } else {
        toast({ title: 'فشل الإرسال', description: data.message, variant: 'destructive' })
      }
    } catch {
      setConnectionResults(prev => ({ ...prev, [id]: { success: false, message: 'خطأ في الاتصال بالخادم' } }))
      toast({ title: 'خطأ', variant: 'destructive' })
    }
    setSendingTestId(null)
  }

  const handleToggle = async (ch: Channel, field: 'isActive' | 'autoPublish') => {
    try {
      const res = await fetch(`/api/admin/auto-publish/${ch.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [field]: !ch[field] }),
      })
      if (res.ok) fetchData()
    } catch { /* silent */ }
  }

  const handleSaveTemplate = async () => {
    if (!editingChannel) return
    setSaving(true)
    try {
      const res = await fetch(`/api/admin/auto-publish/${editingChannel.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ template: formTemplate }),
      })
      if (res.ok) {
        toast({ title: 'تم حفظ القالب' })
        setShowTemplateDialog(false)
        fetchData()
      }
    } catch { /* silent */ }
    setSaving(false)
  }

  const handleRetry = async (logId: string) => {
    try {
      const res = await fetch('/api/admin/auto-publish/retry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ logId }),
      })
      if (res.ok) {
        toast({ title: 'تمت جدولة إعادة المحاولة' })
        fetchData()
      }
    } catch { /* silent */ }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({ title: 'تم النسخ' })
  }

  // Filtered logs
  const filteredLogs = logs.filter(l => {
    if (logFilter !== 'all' && l.status !== logFilter) return false
    if (logPlatformFilter !== 'all' && l.platform !== logPlatformFilter) return false
    return true
  })

  const timeAgo = (date: string) => {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000)
    if (seconds < 60) return 'الآن'
    if (seconds < 3600) return `منذ ${Math.floor(seconds / 60)} دقيقة`
    if (seconds < 86400) return `منذ ${Math.floor(seconds / 3600)} ساعة`
    return `منذ ${Math.floor(seconds / 86400)} يوم`
  }

  // ═══════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* ─── Header ─── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-primary" />
            لوحة النشر التلقائي
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            انشر الوظائف تلقائياً على تليغرام ووتساب وفيسبوك عند نشرها في المنصة
          </p>
        </div>
        <Button onClick={openAddChannel} className="gap-2">
          <Plus className="w-4 h-4" />
          إضافة قناة جديدة
        </Button>
      </div>

      {/* ─── Stats Cards ─── */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={Radio}
            label="القنوات النشطة"
            value={`${stats.activeChannels} / ${stats.totalChannels}`}
            color="text-primary"
            bg="bg-primary/10"
          />
          <StatCard
            icon={Send}
            label="إجمالي المنشورات"
            value={stats.totalPublished.toLocaleString('en-US')}
            color="text-green-600 dark:text-green-400"
            bg="bg-green-50 dark:bg-green-900/20"
          />
          <StatCard
            icon={TrendingUp}
            label="منشورات اليوم"
            value={stats.todayPublished.toLocaleString('en-US')}
            color="text-sky-600 dark:text-sky-400"
            bg="bg-sky-50 dark:bg-sky-900/20"
          />
          <StatCard
            icon={AlertTriangle}
            label="فشل اليوم"
            value={stats.todayFailed.toLocaleString('en-US')}
            color={stats.todayFailed > 0 ? 'text-red-600 dark:text-red-400' : 'text-muted-foreground'}
            bg={stats.todayFailed > 0 ? 'bg-red-50 dark:bg-red-900/20' : 'bg-muted/30'}
          />
        </div>
      )}

      {/* ─── How it works ─── */}
      <div className="rounded-2xl border bg-gradient-to-l from-primary/5 via-transparent to-primary/5 p-5">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-sm">كيف يعمل النشر التلقائي؟</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs text-muted-foreground">
          <StepBadge num={1} text="تنشر وظيفة جديدة في منصة ميدان" />
          <StepBadge num={2} text="يتم مطابقة فئة الوظيفة مع القنوات" />
          <StepBadge num={3} text="تُحوَّل لنص حسب قالب كل منصة" />
          <StepBadge num={4} text="تُنشر تلقائياً + إشعار نجاح/فشل" />
        </div>
      </div>

      {/* ─── Tabs ─── */}
      <div className="flex gap-1 p-1 bg-muted rounded-xl w-fit">
        {[
          { key: 'channels' as const, label: 'القنوات', icon: Radio },
          { key: 'logs' as const, label: 'سجل النشر', icon: BarChart3 },
          { key: 'settings' as const, label: 'إعدادات عامة', icon: Settings },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.key
                ? 'bg-background shadow-sm text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* ═══════════════════════════════════════ */}
      {/* TAB: Channels */}
      {/* ═══════════════════════════════════════ */}
      {activeTab === 'channels' && (
        <div className="space-y-4">
          {channels.length === 0 ? (
            <EmptyState
              icon={Radio}
              title="لا توجد قنوات مضافة"
              description="أضف قنوات تليغرام أو واتساب أو فيسبوك لبدء النشر التلقائي للوظائف"
              actionLabel="إضافة أول قناة"
              onAction={openAddChannel}
            />
          ) : (
            <div className="grid gap-4">
              {channels.map(ch => {
                const config = PLATFORM_CONFIG[ch.platform] || PLATFORM_CONFIG.telegram
                const Icon = config.icon
                const testResult = connectionResults[ch.id]

                return (
                  <Card key={ch.id} className={`border ${ch.isActive ? config.border : 'border-muted'}`}>
                    <CardContent className="p-5">
                      <div className="flex flex-col gap-4">
                        {/* Row 1: Info */}
                        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                          {/* Platform Icon + Info */}
                          <div className="flex items-center gap-3 min-w-0">
                            <div className={`p-2.5 rounded-xl ${ch.isActive ? config.bg : 'bg-muted/50'}`}>
                              <Icon className={`w-5 h-5 ${ch.isActive ? config.color : 'text-muted-foreground'}`} />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h3 className="font-semibold text-sm truncate">{ch.name}</h3>
                                <Badge variant="outline" className="text-[10px] shrink-0">{config.label}</Badge>
                                {!ch.isActive && <Badge variant="secondary" className="text-[10px] shrink-0">معطّل</Badge>}
                                {/* Connection status indicator */}
                                {testResult ? (
                                  testResult.success ? (
                                    <Badge className="text-[10px] bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-green-200 shrink-0">
                                      <CheckCircle className="w-3 h-3 me-1" />
                                      {testResult.testResult ? 'رسالة أُرسلت' : 'متصل'}
                                    </Badge>
                                  ) : (
                                    <Badge variant="destructive" className="text-[10px] shrink-0">
                                      <XCircle className="w-3 h-3 me-1" />
                                      غير متصل
                                    </Badge>
                                  )
                                ) : (
                                  <Badge variant="secondary" className="text-[10px] shrink-0">
                                    <Clock className="w-3 h-3 me-1" />
                                    لم يُفحص
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground truncate mt-0.5">{ch.identifier}</p>
                              {ch.lastPublishedAt && (
                                <p className="text-[10px] text-muted-foreground mt-0.5">
                                  آخر نشر: {timeAgo(ch.lastPublishedAt)} — {ch.publishCount} منشور
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Category Tags */}
                          <div className="flex flex-wrap gap-1">
                            {(ch.categories || []).length === 0 ? (
                              <Badge variant="secondary" className="text-[10px]">جميع الفئات</Badge>
                            ) : (
                              (ch.categories || []).map(cat => (
                                <Badge key={cat} variant="outline" className="text-[10px]">{cat}</Badge>
                              ))
                            )}
                          </div>
                        </div>

                        {/* Row 2: Test Result Message */}
                        {testResult && testResult.message && (
                          <div className={`text-xs p-3 rounded-xl ${
                            testResult.success
                              ? 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400 border border-green-200 dark:border-green-800'
                              : 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400 border border-red-200 dark:border-red-800'
                          }`}>
                            <div className="flex items-start gap-2">
                              {testResult.success ? <CheckCircle className="w-4 h-4 mt-0.5 shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 shrink-0" />}
                              <div>
                                <p>{testResult.message}</p>
                                {testResult.externalUrl && (
                                  <a href={testResult.externalUrl} target="_blank" className="inline-flex items-center gap-1 mt-1 text-primary hover:underline">
                                    <ExternalLink className="w-3 h-3" />
                                    عرض المنشور على المنصة
                                  </a>
                                )}
                                {testResult.platformInfo && (
                                  <div className="mt-1 flex gap-3 text-[10px] opacity-80">
                                    {Object.entries(testResult.platformInfo).map(([k, v]) => (
                                      <span key={k}><strong>{k}:</strong> {v}</span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Row 3: Actions */}
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Test Connection Button — VISIBLE */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTestConnection(ch.id)}
                            disabled={testingId === ch.id}
                            className="gap-1.5 text-xs"
                          >
                            {testingId === ch.id
                              ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              : <Shield className="w-3.5 h-3.5" />
                            }
                            {testingId === ch.id ? 'جاري الفحص...' : 'فحص الاتصال'}
                          </Button>

                          {/* Send Test Message Button */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSendTestMessage(ch.id)}
                            disabled={sendingTestId === ch.id || testingId === ch.id}
                            className="gap-1.5 text-xs"
                          >
                            {sendingTestId === ch.id
                              ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              : <Send className="w-3.5 h-3.5" />
                            }
                            {sendingTestId === ch.id ? 'جاري الإرسال...' : 'إرسال رسالة اختبار'}
                          </Button>

                          {/* Divider */}
                          <div className="w-px h-6 bg-border" />

                          {/* Auto-publish toggle */}
                          <button
                            onClick={() => handleToggle(ch, 'autoPublish')}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                              ch.autoPublish
                                ? 'bg-primary/10 text-primary hover:bg-primary/20'
                                : 'bg-muted text-muted-foreground hover:bg-muted/80'
                            }`}
                          >
                            <Zap className="w-3 h-3" />
                            تلقائي
                          </button>

                          {/* Active toggle */}
                          <button
                            onClick={() => handleToggle(ch, 'isActive')}
                            className={`p-1.5 rounded-lg transition-all ${ch.isActive ? 'text-green-600' : 'text-muted-foreground'}`}
                          >
                            {ch.isActive ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
                          </button>

                          {/* Edit template */}
                          <button
                            onClick={() => openTemplateEditor(ch)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground transition-all"
                            title="تعديل القالب"
                          >
                            <FileText className="w-4 h-4" />
                          </button>

                          {/* Edit */}
                          <button
                            onClick={() => openEditChannel(ch)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground transition-all"
                            title="تعديل القناة"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Delete */}
                          <button
                            onClick={() => handleDeleteChannel(ch.id)}
                            className="p-1.5 rounded-lg text-muted-foreground hover:text-red-500 transition-all"
                            title="حذف القناة"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════ */}
      {/* TAB: Logs */}
      {/* ═══════════════════════════════════════ */}
      {activeTab === 'logs' && (
        <div className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-2">
            <select
              value={logFilter}
              onChange={e => setLogFilter(e.target.value)}
              className="px-3 py-1.5 rounded-lg border bg-background text-sm"
            >
              <option value="all">كل الحالات</option>
              <option value="published">تم النشر</option>
              <option value="failed">فشل</option>
              <option value="publishing">جاري النشر</option>
              <option value="pending">في الانتظار</option>
            </select>
            <select
              value={logPlatformFilter}
              onChange={e => setLogPlatformFilter(e.target.value)}
              className="px-3 py-1.5 rounded-lg border bg-background text-sm"
            >
              <option value="all">كل المنصات</option>
              <option value="telegram">تليغرام</option>
              <option value="whatsapp">واتساب</option>
              <option value="facebook">فيسبوك</option>
            </select>
            <Button variant="outline" size="sm" onClick={fetchData} className="gap-1.5">
              <RefreshCw className="w-3.5 h-3.5" />
              تحديث
            </Button>
          </div>

          {filteredLogs.length === 0 ? (
            <EmptyState
              icon={BarChart3}
              title="لا توجد سجلات"
              description="ستظهر هنا سجلات النشر التلقائي للوظائف"
            />
          ) : (
            <div className="space-y-2">
              {filteredLogs.map(log => {
                const sConfig = STATUS_CONFIG[log.status] || STATUS_CONFIG.pending
                const SIcon = sConfig.icon
                return (
                  <div
                    key={log.id}
                    className="flex items-center gap-3 p-3 rounded-xl border bg-card hover:bg-muted/30 transition-all"
                  >
                    <div className={`p-2 rounded-lg ${sConfig.color}`}>
                      <SIcon className={`w-4 h-4 ${log.status === 'publishing' ? 'animate-spin' : ''}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm truncate">{log.jobTitle}</p>
                        <Badge variant="outline" className="text-[10px] shrink-0">
                          {PLATFORM_CONFIG[log.platform]?.label || log.platform}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] text-muted-foreground">
                          {log.channel?.name || '—'}
                        </span>
                        <span className="text-[10px] text-muted-foreground">•</span>
                        <span className="text-[10px] text-muted-foreground">{timeAgo(log.createdAt)}</span>
                        {log.externalUrl && (
                          <>
                            <span className="text-[10px] text-muted-foreground">•</span>
                            <a href={log.externalUrl} target="_blank" className="text-[10px] text-primary hover:underline flex items-center gap-0.5">
                              <ExternalLink className="w-2.5 h-2.5" />
                              عرض المنشور
                            </a>
                          </>
                        )}
                      </div>
                      {log.errorMessage && (
                        <p className="text-[11px] text-red-500 mt-1 truncate">{log.errorMessage}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      {log.status === 'failed' && (
                        <button
                          onClick={() => handleRetry(log.id)}
                          className="p-1.5 rounded-lg text-muted-foreground hover:text-amber-500 transition-all"
                          title="إعادة المحاولة"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════ */}
      {/* TAB: Settings */}
      {/* ═══════════════════════════════════════ */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          <Card>
            <CardContent className="p-5 space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Bell className="w-4 h-4 text-primary" />
                إعدادات الإشعارات
              </h3>
              <p className="text-sm text-muted-foreground">
                عند نشر وظيفة تلقائياً، يتم إرسال إشعار للمسؤول يوضح نتيجة النشر
              </p>
              <div className="space-y-3">
                <SettingRow label="إشعار عند نجاح النشر" description="يتم إرسال إشعار لكل قناة تم النشر عليها بنجاح" defaultChecked />
                <SettingRow label="إشعار عند فشل النشر" description="تنبيه فوري عند فشل النشر على أي منصة" defaultChecked />
                <SettingRow label="إعادة المحاولة التلقائية" description="إعادة محاولة النشر تلقائياً عند الفشل (حتى 3 مرات)" defaultChecked />
                <SettingRow label="نشر فوري بدون تأخير" description="نشر الوظيفة فوراً عند إنشائها، أو انتظار موافقة المسؤول" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Settings className="w-4 h-4 text-primary" />
                إعدادات عامة
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label className="text-sm">الحد الأقصى لإعادة المحاولة</Label>
                  <Input type="number" defaultValue={3} min={1} max={10} className="mt-1.5" />
                </div>
                <div>
                  <Label className="text-sm">تأخير إعادة المحاولة (ثواني)</Label>
                  <Input type="number" defaultValue={5} min={1} max={60} className="mt-1.5" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5 space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Copy className="w-4 h-4 text-primary" />
                القوالب الافتراضية
              </h3>
              <p className="text-sm text-muted-foreground">
                يمكن تخصيص القالب لكل قناة على حدة من خلال زر التعديل بجانب القناة
              </p>
              <div className="space-y-3">
                {Object.entries(PLATFORM_CONFIG).map(([key, cfg]) => (
                  <button
                    key={key}
                    onClick={() => copyToClipboard(defaultTemplates[key] || '')}
                    className="w-full text-start p-3 rounded-xl border hover:bg-muted/30 transition-all"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium flex items-center gap-1.5">
                        <cfg.icon className={`w-4 h-4 ${cfg.color}`} />
                        {cfg.label}
                      </span>
                      <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                    </div>
                    <p className="text-xs text-muted-foreground truncate font-mono">
                      {(defaultTemplates[key] || '').slice(0, 120)}...
                    </p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ═══════════════════════════════════════ */}
      {/* DIALOG: Add/Edit Channel */}
      {/* ═══════════════════════════════════════ */}
      <Dialog open={showChannelDialog} onOpenChange={setShowChannelDialog}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {editingChannel ? 'تعديل القناة' : 'إضافة قناة جديدة'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-2">
            {/* Platform Selection */}
            <div>
              <Label className="text-sm mb-2 block">المنصة</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {Object.entries(PLATFORM_CONFIG).map(([key, cfg]) => {
                  const PIcon = cfg.icon
                  return (
                    <button
                      key={key}
                      onClick={() => {
                        setFormPlatform(key)
                        setFormTemplate(defaultTemplates[key] || '')
                        setShowSetupGuide(true)
                      }}
                      className={`p-3 rounded-xl text-center text-xs transition-all ${
                        formPlatform === key
                          ? `${cfg.bg} ${cfg.border} ring-1 ${cfg.border.split(' ')[0]}`
                          : 'bg-muted/30 hover:bg-muted/50'
                      }`}
                    >
                      <PIcon className={`w-5 h-5 mx-auto mb-1 ${formPlatform === key ? cfg.color : 'text-muted-foreground'}`} />
                      {cfg.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Setup Guide — Collapsible */}
            <div className="rounded-xl border overflow-hidden">
              <button
                onClick={() => setShowSetupGuide(!showSetupGuide)}
                className="w-full flex items-center justify-between p-3 bg-muted/30 hover:bg-muted/50 transition-all text-sm font-medium"
              >
                <span className="flex items-center gap-2">
                  <Link2 className="w-4 h-4 text-primary" />
                  دليل إعداد {PLATFORM_CONFIG[formPlatform]?.label}
                </span>
                {showSetupGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {showSetupGuide && (
                <div className="p-4 space-y-2 border-t">
                  {PLATFORM_CONFIG[formPlatform]?.steps.map((step, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs">
                      <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary/10 text-primary text-[10px] font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span className="text-muted-foreground leading-relaxed">{step}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Channel Name */}
            <div>
              <Label className="text-sm">اسم القناة</Label>
              <Input
                value={formName}
                onChange={e => setFormName(e.target.value)}
                placeholder="مثال: قناة وظائف بغداد"
                className="mt-1.5"
              />
            </div>

            {/* Identifier */}
            <div>
              <Label className="text-sm">المعرّف (Channel ID / Phone ID / Page ID)</Label>
              <Input
                value={formIdentifier}
                onChange={e => setFormIdentifier(e.target.value)}
                placeholder={PLATFORM_CONFIG[formPlatform]?.placeholder}
                className={`mt-1.5 ${
                  formPlatform === 'telegram' && formIdentifier && /bot$/i.test(formIdentifier.replace(/^@/, ''))
                    ? 'border-red-500 focus-visible:ring-red-500'
                    : ''
                }`}
                dir="ltr"
              />
              <p className="text-[11px] text-muted-foreground mt-1">
                {PLATFORM_CONFIG[formPlatform]?.helpText}
              </p>
              {/* Warning for bot usernames */}
              {formPlatform === 'telegram' && formIdentifier && /bot$/i.test(formIdentifier.replace(/^@/, '')) && (
                <div className="mt-2 rounded-md border border-red-300 bg-red-50 dark:bg-red-900/20 dark:border-red-800 p-2.5">
                  <p className="text-xs text-red-700 dark:text-red-300 font-medium">
                    ⚠️ تحذير: هذا المعرّف يبدو أنه بوت وليس قناة!
                  </p>
                  <p className="text-[11px] text-red-600 dark:text-red-400 mt-1">
                    البوت لا يمكنه إرسال رسائل إلى بوت آخر (Forbidden: bot can't send messages to bot).
                    استخدم معرّف قناة (Channel) بدلاً من ذلك.
                  </p>
                </div>
              )}
              {/* Hint for valid format */}
              {formPlatform === 'telegram' && formIdentifier && !/bot$/i.test(formIdentifier.replace(/^@/, '')) && (
                <p className="text-[11px] text-green-600 dark:text-green-400 mt-1">
                  ✓ الصيغة تبدو صحيحة
                </p>
              )}
            </div>

            {/* Access Token */}
            <div>
              <Label className="text-sm">
                {PLATFORM_CONFIG[formPlatform]?.tokenLabel || 'رمز الوصول'}
                {editingChannel && <span className="text-muted-foreground font-normal"> — اتركه فارغاً للإبقاء على الحالي</span>}
              </Label>
              <Input
                type="password"
                value={formToken}
                onChange={e => setFormToken(e.target.value)}
                placeholder={editingChannel ? '••••••••' : PLATFORM_CONFIG[formPlatform]?.tokenPlaceholder}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Auto-publish toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
              <div>
                <p className="text-sm font-medium">نشر تلقائي</p>
                <p className="text-[11px] text-muted-foreground">نشر الوظائف الجديدة تلقائياً على هذه القناة</p>
              </div>
              <button
                onClick={() => setFormAutoPublish(!formAutoPublish)}
                className={`relative w-11 h-6 rounded-full transition-colors ${formAutoPublish ? 'bg-primary' : 'bg-muted'}`}
              >
                <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${formAutoPublish ? 'start-0.5' : 'start-5'}`} />
              </button>
            </div>

            {/* Template */}
            <div>
              <Label className="text-sm">قالب الرسالة</Label>
              <p className="text-[10px] text-muted-foreground mb-1.5">
                المتغيرات: {'{title}'} {'{company}'} {'{location}'} {'{type}'} {'{salary}'} {'{description}'} {'{requirements}'} {'{url}'} {'{category}'}
              </p>
              <Textarea
                value={formTemplate}
                onChange={e => setFormTemplate(e.target.value)}
                rows={6}
                className="text-xs font-mono"
                dir="ltr"
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowChannelDialog(false)}>
                إلغاء
              </Button>
              <Button className="flex-1 gap-2" onClick={handleSaveChannel} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editingChannel ? 'تحديث' : 'إضافة'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════ */}
      {/* DIALOG: Template Editor */}
      {/* ═══════════════════════════════════════ */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              تعديل قالب — {editingChannel?.name} ({PLATFORM_CONFIG[formPlatform]?.label})
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-2">
            <p className="text-[11px] text-muted-foreground bg-muted/30 p-3 rounded-xl">
              المتغيرات المتاحة: <code>{'{title}'}</code> <code>{'{company}'}</code> <code>{'{location}'}</code>{' '}
              <code>{'{type}'}</code> <code>{'{salary}'}</code> <code>{'{description}'}</code>{' '}
              <code>{'{requirements}'}</code> <code>{'{url}'}</code> <code>{'{category}'}</code>
            </p>
            <Textarea
              value={formTemplate}
              onChange={e => setFormTemplate(e.target.value)}
              rows={12}
              className="text-sm font-mono"
              dir="ltr"
            />

            {/* Preview */}
            <div>
              <Label className="text-sm mb-2 block">معاينة القالب</Label>
              <div className="p-4 rounded-xl bg-muted/30 text-sm whitespace-pre-wrap" dir="rtl">
                {formTemplate
                  .replace(/{title}/g, 'مدير مالي')
                  .replace(/{company}/g, 'شركة النخبة للاستشارات')
                  .replace(/{location}/g, 'بغداد، الكرادة')
                  .replace(/{type}/g, 'دوام كامل')
                  .replace(/{salary}/g, '2,500,000 د.ع')
                  .replace(/{description}/g, 'نبحث عن مدير مالي ذو خبرة لإدارة قسم المالية...')
                  .replace(/{requirements}/g, '🔹 بكالوريوس محاسبة\n🔹 خبرة 5 سنوات')
                  .replace(/{url}/g, 'https://midan.iq/jobs/123')
                  .replace(/{category}/g, 'محاسبة')}
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowTemplateDialog(false)}>
                إلغاء
              </Button>
              <Button className="flex-1 gap-2" onClick={handleSaveTemplate} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                حفظ القالب
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ═══════════════════════════════════════════════
// Sub-Components
// ═══════════════════════════════════════════════

function StatCard({ icon: Icon, label, value, color, bg }: {
  icon: any; label: string; value: string; color: string; bg: string
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-xl ${bg}`}>
            <Icon className={`w-5 h-5 ${color}`} />
          </div>
          <div>
            <p className="text-xl font-bold">{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StepBadge({ num, text }: { num: number; text: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold shrink-0">
        {num}
      </span>
      <span>{text}</span>
    </div>
  )
}

function EmptyState({ icon: Icon, title, description, actionLabel, onAction }: {
  icon: any; title: string; description: string; actionLabel?: string; onAction?: () => void
}) {
  return (
    <div className="text-center py-16">
      <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
        <Icon className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="font-semibold mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground mb-4">{description}</p>
      {actionLabel && onAction && (
        <Button variant="outline" onClick={onAction}>{actionLabel}</Button>
      )}
    </div>
  )
}

function SettingRow({ label, description, defaultChecked = false }: {
  label: string; description: string; defaultChecked?: boolean
}) {
  const [checked, setChecked] = useState(defaultChecked)
  return (
    <div className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="text-[11px] text-muted-foreground">{description}</p>
      </div>
      <button
        onClick={() => setChecked(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors ${checked ? 'bg-primary' : 'bg-muted'}`}
      >
        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${checked ? 'start-0.5' : 'start-5'}`} />
      </button>
    </div>
  )
}