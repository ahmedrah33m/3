const fs = require('fs');

console.log('=== تحليل وبناء خريطة العلاقات ===\n');

// Read all files
const base = fs.readFileSync('prisma/schema.base.prisma', 'utf8');
const payroll = fs.readFileSync('prisma/schema-additions-payroll.prisma', 'utf8');
const verification = fs.readFileSync('prisma/schema-additions-employment-verification.prisma', 'utf8');
const onboarding = fs.readFileSync('prisma/schema-additions-onboarding.prisma', 'utf8');
const live = fs.readFileSync('prisma/schema-additions-live-rooms.prisma', 'utf8');

// Extract existing model names
const existingModels = new Set();
for (const line of base.split('\n')) {
  const m = line.trim().match(/^model (\w+) \{/);
  if (m) existingModels.add(m[1]);
}
console.log('النماذج الموجودة:', existingModels.size);

// Parse models from additions
function parseModels(content) {
  const lines = content.split('\n');
  const models = [];
  let current = null;
  let braceCount = 0;
  
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed === '') continue;
    
    const match = trimmed.match(/^model (\w+) \{/);
    if (match) {
      if (current) models.push(current);
      current = { name: match[1], lines: [line], relations: [] };
      braceCount = 1;
    } else if (current) {
      current.lines.push(line);
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      
      // Check for relation fields
      const relMatch = trimmed.match(/^\s+(\w+)\s+(\w+)(\??)\s*@relation/);
      if (relMatch) {
        current.relations.push({
          field: relMatch[1],
          target: relMatch[2],
          isOptional: relMatch[3] === '?',
          isList: trimmed.includes(`${relMatch[2]}[]`)
        });
      }
      
      if (braceCount === 0) {
        models.push(current);
        current = null;
      }
    }
  }
  if (current) models.push(current);
  return models;
}

const allNew = [
  ...parseModels(payroll),
  ...parseModels(verification),
  ...parseModels(onboarding),
  ...parseModels(live),
];

// Filter out Payment (exists in base)
const newModels = allNew.filter(m => !existingModels.has(m.name) && m.name !== 'Payment');
console.log('النماذج الجديدة:', newModels.length);

// Build relation pairs
console.log('\n=== أزواج العلاقات ===\n');

const relationPairs = [];

for (const model of newModels) {
  for (const rel of model.relations) {
    if (existingModels.has(rel.target)) {
      // Relation to existing model
      const relationName = `${model.name}_${rel.field}`;
      relationPairs.push({
        from: model.name,
        fromField: rel.field,
        target: rel.target,
        relationName: relationName,
        reverseField: `${model.name.charAt(0).toLowerCase() + model.name.slice(1)}s`,
        isList: !rel.isList
      });
      console.log(`${model.name}.${rel.field} → ${rel.target} (@relation("${relationName}"))`);
    }
  }
}

console.log(`\nإجمالي الأزواج: ${relationPairs.length}`);
